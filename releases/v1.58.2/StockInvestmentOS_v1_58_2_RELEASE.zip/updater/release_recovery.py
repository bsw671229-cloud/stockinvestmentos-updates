from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import json
import tempfile
import zipfile

from updater.release_manager import (
    ensure_runtime_dirs,
    is_safe_member,
    read_current_version,
    status_report,
)


RECOVERY_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        ) + "\n",
        encoding="utf-8",
    )
    tmp.replace(path)


def _latest_backup(root: Path) -> Path | None:
    dirs = ensure_runtime_dirs(root)
    backups = sorted(
        dirs["backups"].glob("UPD-*.zip"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return backups[0] if backups else None


def _load_backup_meta(backup: Path) -> tuple[dict[str, Any], str]:
    try:
        with zipfile.ZipFile(backup) as z:
            data = json.loads(
                z.read("_update_backup_meta.json")
            )
    except Exception as exc:
        return {}, f"{type(exc).__name__}: {exc}"

    if not isinstance(data, dict):
        return {}, "backup metadata is not an object"

    return data, ""


def _check(
    layer: str,
    check: str,
    status: str,
    detail: str,
    action: str = "",
) -> dict[str, str]:
    return {
        "layer": layer,
        "check": check,
        "status": status,
        "detail": detail,
        "action": action if status != "PASS" else "",
    }


def _backup_integrity(
    backup: Path,
) -> dict[str, Any]:
    if not backup.is_file():
        return {
            "status": "FAIL",
            "errors": ["backup file missing"],
        }

    errors: list[str] = []
    warnings: list[str] = []
    meta, meta_error = _load_backup_meta(backup)

    if meta_error:
        errors.append(meta_error)
        return {
            "status": "FAIL",
            "errors": errors,
            "warnings": warnings,
            "meta": {},
        }

    try:
        with zipfile.ZipFile(backup) as z:
            names = z.namelist()

            unsafe = [
                name
                for name in names
                if not is_safe_member(name)
            ]
            if unsafe:
                errors.append(
                    "unsafe ZIP members: " + ", ".join(unsafe[:10])
                )

            bad_crc = z.testzip()
            if bad_crc:
                errors.append(
                    f"ZIP CRC failure: {bad_crc}"
                )

            sensitive = [
                name
                for name in names
                if (
                    name in {
                        ".env",
                        ".env.local",
                        ".env.production",
                    }
                    or name.startswith("data/")
                    or name.startswith("secrets/")
                    or name.startswith("runtime-data/")
                )
            ]
            if sensitive:
                errors.append(
                    "sensitive paths present in backup: "
                    + ", ".join(sensitive[:10])
                )

            old_manifest = meta.get("old_manifest") or {}
            backed_up = set(meta.get("backed_up") or [])

            if not isinstance(old_manifest, dict) or not old_manifest:
                errors.append("old_manifest missing or empty")
                old_manifest = {}

            missing = [
                rel
                for rel in old_manifest
                if rel not in backed_up
                or rel not in names
            ]
            if missing:
                errors.append(
                    "old manifest files missing from backup: "
                    + ", ".join(missing[:10])
                )

            hash_mismatch: list[str] = []
            compile_errors: list[str] = []

            for rel, expected in old_manifest.items():
                if rel not in names:
                    continue

                data = z.read(rel)
                actual = _sha256_bytes(data)
                if actual.lower() != _text(expected).lower():
                    hash_mismatch.append(rel)
                    continue

                if rel.endswith(".py"):
                    try:
                        compile(
                            data.decode("utf-8"),
                            rel,
                            "exec",
                        )
                    except Exception as exc:
                        compile_errors.append(
                            f"{rel}: {type(exc).__name__}: {exc}"
                        )

            if hash_mismatch:
                errors.append(
                    "backup hash mismatch: "
                    + ", ".join(hash_mismatch[:10])
                )

            if compile_errors:
                errors.append(
                    "backup Python compile errors: "
                    + " | ".join(compile_errors[:10])
                )

            required_meta = {
                "txid",
                "created_at",
                "source_version",
                "target_version",
                "old_manifest",
                "new_manifest",
                "existed_before",
                "backed_up",
            }
            missing_meta = sorted(
                required_meta.difference(meta)
            )
            if missing_meta:
                errors.append(
                    "backup metadata fields missing: "
                    + ", ".join(missing_meta)
                )

            manifest_target = "manifest_sha256.json"
            version_target = "VERSION"
            for rel in (manifest_target, version_target):
                if meta.get("existed_before", {}).get(rel) is True:
                    if rel not in names:
                        errors.append(
                            f"required rollback artifact missing: {rel}"
                        )

    except Exception as exc:
        errors.append(
            f"{type(exc).__name__}: {exc}"
        )

    return {
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "warnings": warnings,
        "meta": meta,
        "old_manifest_count": len(meta.get("old_manifest") or {}),
        "backed_up_count": len(meta.get("backed_up") or []),
    }


def _last_drill_state(
    root: Path,
) -> dict[str, Any]:
    dirs = ensure_runtime_dirs(root)
    p = dirs["logs"] / "recovery_drill_state.json"
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def trusted_release_recovery_status(
    root: str | Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    current = read_current_version(root)
    rm_status = status_report(root, include_candidates=False)
    backup = _latest_backup(root)
    checks: list[dict[str, str]] = []

    managed_clean = rm_status.get("managed_code_clean") is True
    checks.append(
        _check(
            "TECHNICAL",
            "Managed Code Clean",
            "PASS" if managed_clean else "FAIL",
            (
                f"managed_code_clean={rm_status.get('managed_code_clean')} · "
                f"manifest_entries={rm_status.get('managed_manifest_entries')}"
            ),
            "Repair managed-code drift before relying on rollback readiness.",
        )
    )

    if backup is None:
        checks.append(
            _check(
                "TECHNICAL",
                "Release Manager Backup",
                "FAIL",
                "no UPD-*.zip backup available",
                "Apply a validated release through Release Manager so a transactional backup is created.",
            )
        )
        integrity = {
            "status": "FAIL",
            "meta": {},
            "errors": ["no backup"],
        }
    else:
        integrity = _backup_integrity(backup)
        checks.append(
            _check(
                "TECHNICAL",
                "Release Manager Backup",
                "PASS" if integrity.get("status") == "PASS" else "FAIL",
                (
                    f"backup={backup.name} · "
                    f"old_manifest={integrity.get('old_manifest_count', 0)} · "
                    f"backed_up={integrity.get('backed_up_count', 0)}"
                ),
                (
                    "Do not execute rollback until backup integrity is repaired."
                ),
            )
        )

    meta = integrity.get("meta") or {}
    source_version = _text(meta.get("source_version"))
    target_version = _text(meta.get("target_version"))

    lineage_ok = bool(
        backup is not None
        and source_version
        and target_version
        and current == target_version
    )

    checks.append(
        _check(
            "TECHNICAL",
            "Current / Backup Version Lineage",
            "PASS" if lineage_ok else "REVIEW",
            (
                f"current={current} · "
                f"backup_source={source_version or 'NONE'} · "
                f"backup_target={target_version or 'NONE'}"
            ),
            (
                "Review backup lineage. The latest rollback point should normally target the running version."
            ),
        )
    )

    last_state = rm_status.get("last_state") or {}
    state_backup = _text(last_state.get("backup"))
    state_matches = (
        backup is not None
        and state_backup
        and Path(state_backup).resolve() == backup.resolve()
    )

    checks.append(
        _check(
            "TECHNICAL",
            "Update State / Backup Link",
            "PASS" if state_matches else "REVIEW",
            (
                f"state_status={last_state.get('status','NONE')} · "
                f"state_backup={Path(state_backup).name if state_backup else 'NONE'}"
            ),
            "Review update_state.json lineage before rollback.",
        )
    )

    last_drill = _last_drill_state(root)
    drill_status = _text(last_drill.get("status")).upper()
    drill_backup = _text(last_drill.get("backup"))
    drill_current = (
        backup is not None
        and drill_status == "RECOVERY_DRILL_PASS"
        and drill_backup
        and Path(drill_backup).resolve() == backup.resolve()
    )

    checks.append(
        _check(
            "OPERATING",
            "Latest Non-mutating Recovery Drill",
            "PASS" if drill_current else "REVIEW",
            (
                f"status={drill_status or 'NOT_RUN'} · "
                f"backup={Path(drill_backup).name if drill_backup else 'NONE'}"
            ),
            "Run Non-mutating Recovery Drill after each successful release apply.",
        )
    )

    checks.append(
        _check(
            "TECHNICAL",
            "Execution Authorization Boundary",
            "PASS",
            "software recovery only · execution_authorization=NONE",
            "",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL"
        and row["status"] == "FAIL"
    )
    technical_review = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL"
        and row["status"] == "REVIEW"
    )
    operating_review = sum(
        1
        for row in checks
        if row["layer"] == "OPERATING"
        and row["status"] == "REVIEW"
    )

    technical_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    recovery_status = (
        "PASS"
        if (
            technical_gate == "PASS"
            and technical_review == 0
            and operating_review == 0
        )
        else (
            "REVIEW"
            if technical_gate == "PASS"
            else "BLOCKED"
        )
    )

    return {
        "status": recovery_status,
        "technical_gate": technical_gate,
        "current_version": current,
        "recovery_point_version": source_version or "-",
        "backup_target_version": target_version or "-",
        "backup": str(backup) if backup else "",
        "backup_name": backup.name if backup else "-",
        "backup_integrity": integrity.get("status", "FAIL"),
        "last_drill_status": drill_status or "NOT_RUN",
        "checks": checks,
        "execution_authorization": "NONE",
    }


def trusted_release_recovery_drill(
    root: str | Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    dirs = ensure_runtime_dirs(root)
    backup = _latest_backup(root)

    if backup is None:
        return {
            "status": "BLOCKED",
            "blockers": ["No release-manager backup is available."],
            "execution_authorization": "NONE",
        }

    integrity = _backup_integrity(backup)
    if integrity.get("status") != "PASS":
        return {
            "status": "BLOCKED",
            "backup": str(backup),
            "blockers": integrity.get("errors") or ["Backup integrity failed."],
            "execution_authorization": "NONE",
        }

    meta = integrity.get("meta") or {}
    old_manifest = meta.get("old_manifest") or {}
    errors: list[str] = []

    with tempfile.TemporaryDirectory(
        prefix="recovery-drill-",
        dir=str(dirs["staging"]),
    ) as td:
        sandbox = Path(td)

        with zipfile.ZipFile(backup) as z:
            names = set(z.namelist())

            for rel in sorted(old_manifest):
                if rel not in names:
                    errors.append(
                        f"missing backup member: {rel}"
                    )
                    continue

                target = sandbox / rel
                target.parent.mkdir(
                    parents=True,
                    exist_ok=True,
                )
                target.write_bytes(
                    z.read(rel)
                )

        for rel, expected in old_manifest.items():
            target = sandbox / rel
            if not target.is_file():
                continue

            actual = hashlib.sha256(
                target.read_bytes()
            ).hexdigest()

            if actual.lower() != _text(expected).lower():
                errors.append(
                    f"hash mismatch: {rel}"
                )
                continue

            if rel.endswith(".py"):
                try:
                    compile(
                        target.read_text(
                            encoding="utf-8"
                        ),
                        rel,
                        "exec",
                    )
                except Exception as exc:
                    errors.append(
                        f"compile error {rel}: {type(exc).__name__}: {exc}"
                    )

    result = {
        "created_at": _now(),
        "status": (
            "RECOVERY_DRILL_PASS"
            if not errors
            else "RECOVERY_DRILL_FAIL"
        ),
        "backup": str(backup),
        "source_version": meta.get(
            "source_version",
            "",
        ),
        "target_version": meta.get(
            "target_version",
            "",
        ),
        "verified_manifest_entries": len(
            old_manifest
        ),
        "errors": errors,
        "live_root_modified": False,
        "rollback_executed": False,
        "execution_authorization": "NONE",
    }

    _write_json(
        dirs["logs"] / "recovery_drill_state.json",
        result,
    )

    journal_name = (
        "RECOVERY-DRILL-"
        + datetime.now().astimezone().strftime(
            "%Y%m%dT%H%M%S%f"
        )
        + ".json"
    )
    _write_json(
        dirs["logs"] / journal_name,
        result,
    )

    return result
