from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any

from migration.work_ready_paths import resolve_control_root


FINAL_RELEASE_RE = re.compile(
    r"^StockInvestmentOS_v(\d+)_(\d+)_(\d+)_RELEASE\.zip$",
    re.IGNORECASE,
)

VERSION_RE = re.compile(
    r"^v?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+([0-9A-Za-z.-]+))?$",
    re.IGNORECASE,
)

PROTECTED_PREFIXES = (
    "data/",
    "backups/",
    "releases/",
    "update_logs/",
    ".update_staging/",
)

PROTECTED_EXACT = {
    ".env",
    ".env.local",
    ".env.production",
    "WORK_READY_LAYOUT.json",
    "managed_code_manifest.json",
}

FORBIDDEN_PACKAGE_PREFIXES = (
    "data/",
    "__pycache__/",
)

FORBIDDEN_PACKAGE_EXACT = {
    ".env",
    ".env.local",
    ".env.production",
    "WORK_READY_LAYOUT.json",
    "managed_code_manifest.json",
}


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _tx_id(prefix: str = "UPD") -> str:
    stamp = datetime.now().astimezone().strftime("%Y%m%dT%H%M%S%f")
    return f"{prefix}-{stamp}-{os.getpid()}"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_version(value: str) -> tuple[int, int, int]:
    text = str(value or "").strip()
    m = VERSION_RE.match(text)

    if not m:
        raise ValueError(
            f"Invalid VERSION: {text!r}"
        )

    return tuple(
        int(x)
        for x in m.groups()[:3]
    )


def _natural_prerelease_key(
    value: str,
) -> tuple[tuple[int, object], ...]:
    text = str(
        value
        or ""
    ).strip().lower()

    if not text:
        return tuple()

    tokens = re.findall(
        r"[a-z]+|\d+",
        text,
    )

    out = []

    for token in tokens:
        if token.isdigit():
            out.append(
                (
                    0,
                    int(token),
                )
            )
        else:
            out.append(
                (
                    1,
                    token,
                )
            )

    return tuple(
        out
    )


def version_precedence_key(
    value: str,
) -> tuple:
    text = str(
        value
        or ""
    ).strip()

    m = VERSION_RE.match(
        text
    )

    if not m:
        raise ValueError(
            f"Invalid VERSION: {text!r}"
        )

    major, minor, patch = (
        int(m.group(1)),
        int(m.group(2)),
        int(m.group(3)),
    )

    prerelease = (
        m.group(4)
        or ""
    )

    # A final release outranks every prerelease of the same core version.
    # Example:
    # v1.50.0-dev2-hotfix1 < v1.50.0
    final_rank = (
        1
        if not prerelease
        else 0
    )

    return (
        major,
        minor,
        patch,
        final_rank,
        _natural_prerelease_key(
            prerelease
        ),
    )


def is_version_newer(
    target: str,
    current: str,
) -> bool:
    return (
        version_precedence_key(
            target
        )
        > version_precedence_key(
            current
        )
    )


def version_text(value: tuple[int, int, int]) -> str:
    return "v" + ".".join(
        str(x)
        for x in value[:3]
    )


def is_safe_member(name: str) -> bool:
    if not name or "\\" in name:
        return False
    p = PurePosixPath(name)
    if p.is_absolute():
        return False
    if any(part in {"", ".", ".."} for part in p.parts):
        return False
    return True


def is_protected_rel(rel: str) -> bool:
    rel = str(rel).replace("\\", "/").lstrip("/")
    low = rel.lower()
    if low in PROTECTED_EXACT:
        return True
    return any(low.startswith(prefix.lower()) for prefix in PROTECTED_PREFIXES)


def package_path_forbidden(rel: str) -> bool:
    rel = str(rel).replace("\\", "/").lstrip("/")
    low = rel.lower()
    if low in FORBIDDEN_PACKAGE_EXACT:
        return True
    if low.endswith(".pyc") or "/__pycache__/" in f"/{low}/":
        return True
    return any(low.startswith(prefix.lower()) for prefix in FORBIDDEN_PACKAGE_PREFIXES)


def ensure_runtime_dirs(root: Path) -> dict[str, Path]:
    root = Path(root).resolve()
    control = resolve_control_root(root)
    dirs = {
        "control": control,
        "inbox": control / "releases" / "inbox",
        "approved": control / "releases" / "approved",
        "archive": control / "releases" / "archive",
        "backups": control / "backups" / "release_manager",
        "logs": control / "update_logs",
        "staging": control / ".update_staging",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs

def read_current_version(root: Path) -> str:
    p = root / "VERSION"
    if not p.is_file():
        return "v0.0.0"
    return p.read_text(encoding="utf-8").strip()


def read_local_manifest(root: Path) -> dict[str, str]:
    root = Path(root).resolve()

    dev = root / "managed_code_manifest.json"

    if dev.is_file():
        try:
            data = json.loads(dev.read_text(encoding="utf-8"))
        except Exception:
            data = {}

        if (
            isinstance(data, dict)
            and data.get("version") == read_current_version(root)
            and isinstance(data.get("files"), dict)
        ):
            return {
                str(k).replace("\\", "/"): str(v).strip().lower()
                for k, v in data["files"].items()
            }

    p = root / "manifest_sha256.json"

    if not p.is_file():
        return {}

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}

    if not isinstance(data, dict):
        return {}

    return {
        str(k).replace("\\", "/"): str(v).strip().lower()
        for k, v in data.items()
    }

def _zip_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return (mode & 0o170000) == 0o120000


def _read_package(package: Path) -> dict[str, Any]:
    with zipfile.ZipFile(package) as z:
        names = z.namelist()

        unsafe = [
            n for n in names
            if not is_safe_member(n.rstrip("/"))
        ]
        symlinks = [
            info.filename
            for info in z.infolist()
            if _zip_is_symlink(info)
        ]

        required = {
            "VERSION",
            "app.py",
            "manifest_sha256.json",
        }

        missing_required = sorted(required - set(names))

        version = (
            z.read("VERSION").decode("utf-8").strip()
            if "VERSION" in names
            else ""
        )

        try:
            manifest = json.loads(
                z.read("manifest_sha256.json")
            )
        except Exception:
            manifest = {}

        if not isinstance(manifest, dict):
            manifest = {}

        manifest = {
            str(k).replace("\\", "/"): str(v).strip().lower()
            for k, v in manifest.items()
        }

        forbidden = sorted(
            n for n in names
            if package_path_forbidden(n)
        )

        protected = sorted(
            rel for rel in manifest
            if is_protected_rel(rel)
        )

        manifest_missing = []
        hash_mismatch = []
        python_errors = []

        for rel, expected in manifest.items():
            if rel not in names:
                manifest_missing.append(rel)
                continue
            actual = sha256_bytes(z.read(rel))
            if actual != expected:
                hash_mismatch.append(rel)

        for rel in names:
            if rel.endswith(".py"):
                try:
                    compile(
                        z.read(rel).decode("utf-8"),
                        rel,
                        "exec",
                    )
                except Exception as exc:
                    python_errors.append(
                        f"{rel}: {type(exc).__name__}: {exc}"
                    )

    return {
        "names": names,
        "version": version,
        "manifest": manifest,
        "unsafe_paths": unsafe,
        "symlinks": symlinks,
        "missing_required": missing_required,
        "forbidden_paths": forbidden,
        "protected_manifest_paths": protected,
        "manifest_missing": manifest_missing,
        "hash_mismatch": hash_mismatch,
        "python_errors": python_errors,
    }


def find_validation_report(package: Path) -> Path | None:
    folder = package.parent
    candidates = sorted(
        [
            p for p in folder.glob("*VALIDATION*.txt")
            if p.is_file()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    try:
        version = _read_package(package)["version"]
        parsed = parse_version(version)
        tag = f"V{parsed[0]}{parsed[1]:02d}"
        matching = [
            p for p in candidates
            if tag.lower() in p.name.lower()
        ]
        if matching:
            return matching[0]
    except Exception:
        pass

    return candidates[0] if candidates else None


def validation_report_passes(path: Path | None) -> bool:
    if path is None or not path.is_file():
        return False
    try:
        text = path.read_text(
            encoding="utf-8",
            errors="replace",
        )
    except Exception:
        return False
    return "RESULT: PASS" in text.upper()


def verify_release_package(
    root: Path,
    package: Path,
    *,
    require_final_release_name: bool = False,
    require_validation_report: bool = False,
    require_target_newer: bool = True,
) -> dict[str, Any]:
    root = root.resolve()
    package = package.resolve()

    blockers: list[str] = []
    warnings: list[str] = []

    if not package.is_file():
        return {
            "eligible": False,
            "blockers": [f"Package not found: {package}"],
            "warnings": [],
        }

    if not zipfile.is_zipfile(package):
        return {
            "eligible": False,
            "blockers": ["Package is not a valid ZIP."],
            "warnings": [],
        }

    package_data = _read_package(package)

    final_name_ok = bool(
        FINAL_RELEASE_RE.match(
            package.name
        )
    )

    if require_final_release_name and not final_name_ok:
        blockers.append(
            "Automatic apply accepts final *_RELEASE.zip packages only."
        )

    for label, values in [
        ("unsafe ZIP paths", package_data["unsafe_paths"]),
        ("ZIP symlinks", package_data["symlinks"]),
        ("missing required files", package_data["missing_required"]),
        ("forbidden package paths", package_data["forbidden_paths"]),
        ("protected manifest paths", package_data["protected_manifest_paths"]),
        ("manifest entries missing from ZIP", package_data["manifest_missing"]),
        ("manifest SHA-256 mismatches", package_data["hash_mismatch"]),
        ("Python compile errors", package_data["python_errors"]),
    ]:
        if values:
            blockers.append(
                f"{label}: {values[:10]}"
            )

    manifest = package_data["manifest"]

    if not manifest:
        blockers.append(
            "manifest_sha256.json is empty or invalid."
        )

    if "VERSION" not in manifest:
        blockers.append(
            "VERSION must be covered by the release manifest."
        )

    if "app.py" not in manifest:
        blockers.append(
            "app.py must be covered by the release manifest."
        )

    current_version_text = read_current_version(root)

    try:
        current_version = parse_version(
            current_version_text
        )
    except Exception:
        current_version = (0, 0, 0)
        warnings.append(
            f"Current VERSION could not be parsed: {current_version_text!r}"
        )

    try:
        target_version = parse_version(
            package_data["version"]
        )
    except Exception as exc:
        target_version = (0, 0, 0)
        blockers.append(
            f"Target VERSION invalid: {exc}"
        )

    target_is_newer = False

    if require_target_newer:
        try:
            target_is_newer = is_version_newer(
                package_data["version"],
                current_version_text,
            )
        except Exception as exc:
            blockers.append(
                f"Version precedence comparison failed: {exc}"
            )

        if not target_is_newer:
            blockers.append(
                f"Target {package_data['version']} is not newer than current "
                f"{current_version_text} under prerelease/final precedence."
            )
    else:
        # Publisher validation is a publication decision, not an install
        # decision. A final RELEASE may legitimately be published from a
        # workstation already running that same final version. Publication
        # ordering is enforced against the existing trusted feed instead.
        try:
            target_is_newer = is_version_newer(
                package_data["version"],
                current_version_text,
            )
        except Exception:
            target_is_newer = False

    validation_report = find_validation_report(
        package
    )

    validation_ok = validation_report_passes(
        validation_report
    )

    if require_validation_report and not validation_ok:
        blockers.append(
            "Automatic apply requires a sidecar validation report containing 'RESULT: PASS'."
        )
    elif not validation_ok:
        warnings.append(
            "No passing sidecar validation report was found. Preview is allowed, auto-apply is not."
        )

    return {
        "eligible": len(blockers) == 0,
        "blockers": blockers,
        "warnings": warnings,
        "package": str(package),
        "package_name": package.name,
        "package_sha256": sha256_file(package),
        "current_version": current_version_text,
        "target_version": package_data["version"],
        "final_release_name": final_name_ok,
        "validation_report": (
            str(validation_report)
            if validation_report
            else ""
        ),
        "validation_report_pass": validation_ok,
        "manifest_entries": len(manifest),
        "manifest": manifest,
    }


def current_drift_report(
    root: Path,
    manifest: dict[str, str] | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    manifest = manifest or read_local_manifest(root)

    missing = []
    mismatch = []
    ok = 0

    for rel, expected in manifest.items():
        target = root / rel

        if not target.is_file():
            missing.append(rel)
            continue

        actual = sha256_file(target)

        if actual != expected:
            mismatch.append(rel)
        else:
            ok += 1

    return {
        "tracked": len(manifest),
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
        "clean": not missing and not mismatch,
    }


def preview_release(
    root: Path,
    package: Path,
    *,
    for_auto_apply: bool = False,
    require_target_newer: bool = True,
) -> dict[str, Any]:
    root = root.resolve()
    package = package.resolve()

    verify = verify_release_package(
        root,
        package,
        require_final_release_name=for_auto_apply,
        require_validation_report=for_auto_apply,
        require_target_newer=require_target_newer,
    )

    blockers = list(
        verify.get("blockers", [])
    )
    warnings = list(
        verify.get("warnings", [])
    )

    if not package.is_file() or not zipfile.is_zipfile(package):
        return {
            **verify,
            "blockers": blockers,
            "warnings": warnings,
        }

    new_manifest = verify.get(
        "manifest",
        {},
    )
    old_manifest = read_local_manifest(
        root
    )

    drift = current_drift_report(
        root,
        old_manifest,
    )

    if old_manifest and not drift["clean"]:
        blockers.append(
            "Current managed-code drift detected. "
            f"missing={drift['missing'][:10]}, mismatch={drift['mismatch'][:10]}. "
            "Automatic overwrite is blocked to protect local modifications."
        )

    added = []
    changed = []
    unchanged = []
    collisions = []

    for rel, expected in new_manifest.items():
        target = root / rel

        if rel in old_manifest:
            if target.is_file() and sha256_file(target) == expected:
                unchanged.append(rel)
            else:
                changed.append(rel)
        else:
            if target.exists():
                collisions.append(rel)
            else:
                added.append(rel)

    if collisions:
        blockers.append(
            f"New release would overwrite unmanaged existing files: {collisions[:10]}"
        )

    removed = sorted(
        rel
        for rel in old_manifest
        if rel not in new_manifest
        and not is_protected_rel(rel)
    )

    protected_removals = sorted(
        rel
        for rel in old_manifest
        if rel not in new_manifest
        and is_protected_rel(rel)
    )

    critical_self_update_paths = {
        "updater/release_manager.py",
        "updater/update_manager.py",
        "updater/SELF_UPDATE_POLICY.json",
        "migration/work_ready_paths.py",
        "migration/work_ready_migrator.py",
        "migration/migrate_work_ready.py",
    }

    critical_removed = sorted(
        rel
        for rel in critical_self_update_paths
        if rel in old_manifest
        and rel not in new_manifest
    )

    if critical_removed:
        blockers.append(
            "Target release would remove the installed Release Manager: "
            + ", ".join(critical_removed)
        )

    if protected_removals:
        warnings.append(
            f"Protected old paths will not be deleted: {protected_removals[:10]}"
        )

    return {
        **verify,
        "eligible": len(blockers) == 0,
        "blockers": blockers,
        "warnings": warnings,
        "current_drift": drift,
        "actions": {
            "added": added,
            "changed": changed,
            "unchanged": unchanged,
            "removed": removed,
            "collisions": collisions,
        },
        "counts": {
            "added": len(added),
            "changed": len(changed),
            "unchanged": len(unchanged),
            "removed": len(removed),
            "collisions": len(collisions),
        },
    }


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    path.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        )
        + "\n",
        encoding="utf-8",
    )


def _backup_current(
    root: Path,
    *,
    txid: str,
    preview: dict[str, Any],
) -> tuple[Path, dict[str, Any]]:
    dirs = ensure_runtime_dirs(root)

    old_manifest = read_local_manifest(root)
    new_manifest = preview.get("manifest", {})

    backup_path = (
        dirs["backups"]
        / f"{txid}_{read_current_version(root).replace('.', '_')}.zip"
    )

    candidates = set(old_manifest)
    # Track every target release path, including files that do not exist yet.
    # This lets rollback remove files introduced only by the failed/new release.
    candidates.update(new_manifest)

    candidates.update(
        {
            "manifest_sha256.json",
            "managed_code_manifest.json",
            "VERSION",
        }
    )

    backed_up = []
    existed_before = {}

    with zipfile.ZipFile(
        backup_path,
        "w",
        compression=zipfile.ZIP_DEFLATED,
    ) as z:
        for rel in sorted(candidates):
            target = root / rel
            existed = target.is_file()
            existed_before[rel] = existed

            if existed:
                z.write(
                    target,
                    arcname=rel,
                )
                backed_up.append(rel)

        meta = {
            "txid": txid,
            "created_at": _now(),
            "source_version": read_current_version(root),
            "target_version": preview.get("target_version", ""),
            "old_manifest": old_manifest,
            "new_manifest": new_manifest,
            "existed_before": existed_before,
            "backed_up": backed_up,
        }

        z.writestr(
            "_update_backup_meta.json",
            json.dumps(
                meta,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n",
        )

    return backup_path, meta


def _verify_installed(
    root: Path,
    expected_manifest: dict[str, str],
) -> list[str]:
    errors = []

    for rel, expected in expected_manifest.items():
        target = root / rel

        if not target.is_file():
            errors.append(
                f"missing installed file: {rel}"
            )
            continue

        actual = sha256_file(target)

        if actual != expected:
            errors.append(
                f"installed hash mismatch: {rel}"
            )

    for rel in expected_manifest:
        if rel.endswith(".py"):
            try:
                compile(
                    (root / rel).read_text(
                        encoding="utf-8"
                    ),
                    str(root / rel),
                    "exec",
                )
            except Exception as exc:
                errors.append(
                    f"installed Python compile error {rel}: {exc}"
                )

    return errors


def _restore_backup(
    root: Path,
    backup_path: Path,
) -> dict[str, Any]:
    root = root.resolve()
    backup_path = backup_path.resolve()

    with zipfile.ZipFile(backup_path) as z:
        meta = json.loads(
            z.read(
                "_update_backup_meta.json"
            )
        )

        existed_before = meta.get(
            "existed_before",
            {},
        )

        # Remove files introduced by the failed/new release.
        for rel, existed in existed_before.items():
            if existed:
                continue
            if is_protected_rel(rel):
                continue
            target = root / rel
            if target.is_file():
                target.unlink()

        # Restore all backed-up files.
        for rel in meta.get(
            "backed_up",
            [],
        ):
            if not is_safe_member(rel):
                raise RuntimeError(
                    f"Unsafe backup member: {rel}"
                )
            target = root / rel
            target.parent.mkdir(
                parents=True,
                exist_ok=True,
            )
            data = z.read(rel)
            tmp = target.with_name(
                target.name + ".rollback_tmp"
            )
            tmp.write_bytes(data)
            os.replace(tmp, target)

    old_manifest = meta.get(
        "old_manifest",
        {},
    )

    errors = _verify_installed(
        root,
        old_manifest,
    )

    return {
        "restored": not errors,
        "errors": errors,
        "source_version": meta.get(
            "source_version",
            "",
        ),
        "target_version": meta.get(
            "target_version",
            "",
        ),
        "txid": meta.get("txid", ""),
    }


def apply_release(
    root: Path,
    package: Path,
    *,
    require_approved_folder: bool = True,
) -> dict[str, Any]:
    root = root.resolve()
    package = package.resolve()
    dirs = ensure_runtime_dirs(root)

    if require_approved_folder:
        try:
            package.relative_to(
                dirs["approved"].resolve()
            )
        except Exception:
            return {
                "status": "BLOCKED",
                "blockers": [
                    "Automatic apply only accepts packages inside releases/approved."
                ],
            }

        approval_ok, approval_error = _approval_valid(
            package
        )

        if not approval_ok:
            return {
                "status": "BLOCKED",
                "blockers": [
                    approval_error
                ],
            }

    preview = preview_release(
        root,
        package,
        for_auto_apply=require_approved_folder,
    )

    if not preview.get(
        "eligible",
        False,
    ):
        return {
            "status": "BLOCKED",
            "preview": preview,
            "blockers": preview.get(
                "blockers",
                [],
            ),
        }

    txid = _tx_id()
    journal_path = (
        dirs["logs"]
        / f"{txid}.json"
    )

    journal = {
        "txid": txid,
        "started_at": _now(),
        "status": "STARTED",
        "current_version": preview.get("current_version"),
        "target_version": preview.get("target_version"),
        "package": str(package),
        "package_sha256": preview.get("package_sha256"),
        "preview_counts": preview.get("counts"),
    }

    _write_json(
        journal_path,
        journal,
    )

    backup_path = None

    try:
        backup_path, backup_meta = _backup_current(
            root,
            txid=txid,
            preview=preview,
        )

        journal["backup"] = str(
            backup_path
        )
        journal["status"] = "BACKED_UP"
        _write_json(
            journal_path,
            journal,
        )

        stage = (
            dirs["staging"]
            / txid
        )

        if stage.exists():
            shutil.rmtree(stage)

        stage.mkdir(
            parents=True,
            exist_ok=True,
        )

        with zipfile.ZipFile(package) as z:
            manifest = preview["manifest"]

            for rel in manifest:
                if is_protected_rel(rel):
                    raise RuntimeError(
                        f"Protected path in target manifest: {rel}"
                    )

                data = z.read(rel)
                staged = stage / rel
                staged.parent.mkdir(
                    parents=True,
                    exist_ok=True,
                )
                staged.write_bytes(data)

            # Stage the new manifest itself.
            (stage / "manifest_sha256.json").write_bytes(
                z.read(
                    "manifest_sha256.json"
                )
            )

        # Apply all new tracked files atomically per file.
        for rel in sorted(
            preview["manifest"]
        ):
            src = stage / rel
            target = root / rel

            target.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            tmp = target.with_name(
                target.name + f".{txid}.update_tmp"
            )

            shutil.copy2(
                src,
                tmp,
            )
            os.replace(
                tmp,
                target,
            )

        # Remove files that were tracked by the old release but are no longer
        # part of the new release. Protected paths are never removed.
        for rel in preview[
            "actions"
        ][
            "removed"
        ]:
            if is_protected_rel(rel):
                continue
            target = root / rel
            if target.is_file():
                target.unlink()

        # Manifest last: it becomes the committed managed-file contract.
        manifest_target = (
            root
            / "manifest_sha256.json"
        )
        manifest_tmp = manifest_target.with_name(
            manifest_target.name
            + f".{txid}.update_tmp"
        )
        shutil.copy2(
            stage / "manifest_sha256.json",
            manifest_tmp,
        )
        os.replace(
            manifest_tmp,
            manifest_target,
        )

        post_errors = _verify_installed(
            root,
            preview["manifest"],
        )

        if post_errors:
            raise RuntimeError(
                "Post-apply verification failed: "
                + " | ".join(
                    post_errors[:20]
                )
            )

        dev_baseline = root / "managed_code_manifest.json"

        if dev_baseline.is_file():
            try:
                dev_data = json.loads(
                    dev_baseline.read_text(encoding="utf-8")
                )
            except Exception:
                dev_data = {}

            if dev_data.get("version") != read_current_version(root):
                dev_baseline.unlink()

        journal.update(
            {
                "finished_at": _now(),
                "status": "APPLIED",
                "restart_required": True,
                "post_apply_verification": "PASS",
            }
        )

        _write_json(
            journal_path,
            journal,
        )

        state = {
            "last_transaction": txid,
            "status": "APPLIED",
            "current_version": read_current_version(
                root
            ),
            "package": str(package),
            "backup": str(backup_path),
            "restart_required": True,
            "updated_at": _now(),
        }

        _write_json(
            dirs["logs"]
            / "update_state.json",
            state,
        )

        # Archive the consumed approved package and matching validation report.
        archive_target = (
            dirs["archive"]
            / package.name
        )

        if archive_target.exists():
            archive_target.unlink()

        shutil.copy2(
            package,
            archive_target,
        )

        report = find_validation_report(
            package
        )

        if report and report.is_file():
            shutil.copy2(
                report,
                dirs["archive"] / report.name,
            )

        shutil.rmtree(
            stage,
            ignore_errors=True,
        )

        return {
            "status": "APPLIED",
            "txid": txid,
            "current_version": read_current_version(
                root
            ),
            "target_version": preview.get(
                "target_version"
            ),
            "backup": str(backup_path),
            "restart_required": True,
            "journal": str(journal_path),
        }

    except Exception as exc:
        rollback_result = None

        if backup_path and backup_path.is_file():
            try:
                rollback_result = _restore_backup(
                    root,
                    backup_path,
                )
            except Exception as rollback_exc:
                rollback_result = {
                    "restored": False,
                    "errors": [
                        f"{type(rollback_exc).__name__}: {rollback_exc}"
                    ],
                }

        journal.update(
            {
                "finished_at": _now(),
                "status": "ROLLED_BACK"
                if rollback_result
                and rollback_result.get(
                    "restored"
                )
                else "FAILED",
                "error": (
                    f"{type(exc).__name__}: {exc}"
                ),
                "rollback": rollback_result,
            }
        )

        _write_json(
            journal_path,
            journal,
        )

        return {
            "status": journal["status"],
            "txid": txid,
            "error": journal["error"],
            "rollback": rollback_result,
            "journal": str(journal_path),
        }


def approve_release(
    root: Path,
    package: Path,
    validation_report: Path,
    expected_sha256: str,
) -> dict[str, Any]:
    root = root.resolve()
    package = package.resolve()
    validation_report = validation_report.resolve()
    dirs = ensure_runtime_dirs(root)

    blockers = []

    if not package.is_file():
        blockers.append(
            f"Package not found: {package}"
        )

    if not validation_report.is_file():
        blockers.append(
            f"Validation report not found: {validation_report}"
        )

    expected = str(
        expected_sha256
    ).strip().lower()

    if not re.fullmatch(
        r"[0-9a-f]{64}",
        expected,
    ):
        blockers.append(
            "Expected SHA-256 must be exactly 64 hex characters."
        )

    if blockers:
        return {
            "status": "BLOCKED",
            "blockers": blockers,
        }

    actual = sha256_file(
        package
    )

    if actual != expected:
        blockers.append(
            f"Package SHA-256 mismatch. expected={expected}, actual={actual}"
        )

    if not validation_report_passes(
        validation_report
    ):
        blockers.append(
            "Validation report does not contain RESULT: PASS."
        )

    verify = verify_release_package(
        root,
        package,
        require_final_release_name=True,
        require_validation_report=False,
    )

    blockers.extend(
        verify.get("blockers", [])
    )

    if blockers:
        return {
            "status": "BLOCKED",
            "blockers": blockers,
            "package_sha256": actual,
            "verify": verify,
        }

    approved_package = (
        dirs["approved"]
        / package.name
    )

    approved_report = (
        dirs["approved"]
        / validation_report.name
    )

    shutil.copy2(
        package,
        approved_package,
    )
    shutil.copy2(
        validation_report,
        approved_report,
    )

    approval = {
        "approved_at": _now(),
        "package": approved_package.name,
        "package_sha256": actual,
        "validation_report": approved_report.name,
        "validation_report_sha256": sha256_file(
            approved_report
        ),
        "target_version": verify.get(
            "target_version"
        ),
        "approval_mode": "EXPECTED_SHA256_PLUS_PASSING_VALIDATION_REPORT",
    }

    approval_path = (
        dirs["approved"]
        / (
            approved_package.stem
            + ".approval.json"
        )
    )

    _write_json(
        approval_path,
        approval,
    )

    return {
        "status": "APPROVED",
        "approved_package": str(
            approved_package
        ),
        "approved_report": str(
            approved_report
        ),
        "approval": str(
            approval_path
        ),
        "target_version": verify.get(
            "target_version"
        ),
        "package_sha256": actual,
    }


def retire_approved_release(
    root: Path,
    package: Path,
    *,
    reason: str = "",
) -> dict[str, Any]:
    root = root.resolve()
    package = package.resolve()
    dirs = ensure_runtime_dirs(
        root
    )

    approved_root = dirs[
        "approved"
    ].resolve()

    try:
        package.relative_to(
            approved_root
        )
    except Exception:
        return {
            "status": "BLOCKED",
            "blockers": [
                "Only packages inside releases/approved can be retired."
            ],
        }

    if not package.is_file():
        return {
            "status": "BLOCKED",
            "blockers": [
                f"Approved package not found: {package}"
            ],
        }

    txid = _tx_id(
        "RETIRE"
    )

    retirement_dir = (
        dirs["archive"]
        / "retired"
        / txid
    )

    retirement_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    approval_path = (
        package.parent
        / (
            package.stem
            + ".approval.json"
        )
    )

    approval = {}

    if approval_path.is_file():
        try:
            approval = json.loads(
                approval_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception:
            approval = {}

    report_name = _text(
        approval.get(
            "validation_report"
        )
    )

    report_path = (
        package.parent
        / report_name
        if report_name
        else None
    )

    package_sha = sha256_file(
        package
    )

    target_version = ""

    try:
        target_version = _read_package(
            package
        ).get(
            "version",
            "",
        )
    except Exception:
        target_version = ""

    moved = []

    def _move_if_file(
        source: Path | None,
    ) -> None:
        if (
            source is None
            or not source.is_file()
        ):
            return

        destination = (
            retirement_dir
            / source.name
        )

        shutil.move(
            str(source),
            str(destination),
        )

        moved.append(
            str(destination)
        )

    _move_if_file(
        package
    )
    _move_if_file(
        approval_path
    )
    _move_if_file(
        report_path
    )

    retirement_record = {
        "retirement_id": txid,
        "retired_at": _now(),
        "status": "RETIRED",
        "package_name": package.name,
        "package_sha256": package_sha,
        "target_version": target_version,
        "reason": (
            str(reason).strip()
            or "Operator retired approved release from automatic-update eligibility."
        ),
        "moved_files": moved,
        "auto_update_eligible": False,
    }

    retirement_record_path = (
        retirement_dir
        / "retirement.json"
    )

    _write_json(
        retirement_record_path,
        retirement_record,
    )

    journal_path = (
        dirs["logs"]
        / f"{txid}.json"
    )

    _write_json(
        journal_path,
        retirement_record,
    )

    return {
        "status": "RETIRED",
        "retirement_id": txid,
        "target_version": target_version,
        "package_sha256": package_sha,
        "archive_dir": str(
            retirement_dir
        ),
        "retirement_record": str(
            retirement_record_path
        ),
        "journal": str(
            journal_path
        ),
        "moved_files": moved,
        "auto_update_eligible": False,
    }


def _approval_valid(
    package: Path,
) -> tuple[bool, str]:
    approval_path = (
        package.parent
        / (
            package.stem
            + ".approval.json"
        )
    )

    if not approval_path.is_file():
        return (
            False,
            "approval.json missing",
        )

    try:
        approval = json.loads(
            approval_path.read_text(
                encoding="utf-8"
            )
        )
    except Exception as exc:
        return (
            False,
            f"approval.json invalid: {exc}",
        )

    expected = _text(
        approval.get(
            "package_sha256"
        )
    ).lower()

    actual = sha256_file(
        package
    )

    if expected != actual:
        return (
            False,
            "approved package SHA-256 no longer matches approval record",
        )

    report_name = _text(
        approval.get(
            "validation_report"
        )
    )

    report = (
        package.parent
        / report_name
    )

    if not validation_report_passes(
        report
    ):
        return (
            False,
            "approved validation report missing or not PASS",
        )

    report_expected = _text(
        approval.get(
            "validation_report_sha256"
        )
    ).lower()

    if (
        report_expected
        and sha256_file(
            report
        )
        != report_expected
    ):
        return (
            False,
            "validation report SHA-256 no longer matches approval record",
        )

    return (
        True,
        "",
    )


def candidate_inventory(root: Path) -> list[dict[str, Any]]:
    """Filename inventory only. Never establishes approval or eligibility.

    Does not open ZIPs, compile Python or read approval/validation content.
    Full action gates use scan_candidates / verify_release_package instead.
    """
    root = root.resolve()
    dirs = ensure_runtime_dirs(root)
    current = read_current_version(root)
    rows = []
    for scope in ("inbox", "approved"):
        for package in sorted(dirs[scope].glob("*.zip")):
            if package.is_symlink() or not package.is_file():
                continue
            match = FINAL_RELEASE_RE.fullmatch(package.name)
            target = "v" + ".".join(match.groups()) if match else ""
            try:
                newer = bool(target and is_version_newer(target, current))
            except ValueError:
                newer = False
            rows.append({
                "scope": scope, "package": package.name, "path": str(package),
                "current_version": current, "target_version": target,
                "version_source": "FILENAME_ONLY", "newer_than_current": newer,
                "eligible": None, "approval_ok": None,
                "verification": "NOT_CHECKED", "package_sha256": "",
                "blockers": [], "warnings": ["Inventory only; select and validate before an action."],
            })
    return rows


def scan_candidates(
    root: Path,
    *,
    selected_package: Path | None = None,
) -> list[dict[str, Any]]:
    root = root.resolve()
    dirs = ensure_runtime_dirs(
        root
    )

    rows = []

    for scope in [
        "inbox",
        "approved",
    ]:
        folder = dirs[scope]

        if selected_package is None:
            packages = sorted(folder.glob("*.zip"))
        else:
            selected = Path(selected_package)
            packages = [selected.resolve()] if (
                not selected.is_symlink()
                and selected.resolve().parent == folder.resolve()
                and selected.suffix.lower() == ".zip"
                and selected.is_file()
            ) else []
        for package in packages:
            verify = verify_release_package(
                root,
                package,
                require_final_release_name=(
                    scope == "approved"
                ),
                require_validation_report=(
                    scope == "approved"
                ),
            )

            approval_ok = None
            approval_error = ""

            if scope == "approved":
                approval_ok, approval_error = _approval_valid(
                    package
                )

            rows.append(
                {
                    "scope": scope,
                    "package": package.name,
                    "path": str(package),
                    "current_version": verify.get(
                        "current_version",
                        "",
                    ),
                    "target_version": verify.get(
                        "target_version",
                        "",
                    ),
                    "eligible": bool(
                        verify.get(
                            "eligible",
                            False,
                        )
                    )
                    and (
                        approval_ok
                        if approval_ok is not None
                        else True
                    ),
                    "approval_ok": approval_ok,
                    "approval_error": approval_error,
                    "package_sha256": verify.get(
                        "package_sha256",
                        "",
                    ),
                    "blockers": verify.get(
                        "blockers",
                        [],
                    ),
                    "warnings": verify.get(
                        "warnings",
                        [],
                    ),
                }
            )

    return rows


def auto_update_once(
    root: Path,
) -> dict[str, Any]:
    root = root.resolve()
    dirs = ensure_runtime_dirs(root)

    candidates = []

    for package in dirs[
        "approved"
    ].glob(
        "StockInvestmentOS_v*_RELEASE.zip"
    ):
        approval_ok, approval_error = _approval_valid(
            package
        )

        if not approval_ok:
            continue

        preview = preview_release(
            root,
            package,
            for_auto_apply=True,
        )

        if not preview.get(
            "eligible",
            False,
        ):
            continue

        try:
            version = version_precedence_key(
                preview.get(
                    "target_version",
                    "",
                )
            )
        except Exception:
            continue

        candidates.append(
            (
                version,
                package,
                preview,
            )
        )

    if not candidates:
        return {
            "status": "NO_ELIGIBLE_UPDATE",
            "current_version": read_current_version(
                root
            ),
        }

    candidates.sort(
        key=lambda item: item[0],
        reverse=True,
    )

    _, package, _ = candidates[0]

    return apply_release(
        root,
        package,
        require_approved_folder=True,
    )


def rollback_latest(
    root: Path,
) -> dict[str, Any]:
    root = root.resolve()
    dirs = ensure_runtime_dirs(root)

    backups = sorted(
        dirs["backups"].glob(
            "UPD-*.zip"
        ),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not backups:
        return {
            "status": "BLOCKED",
            "blockers": [
                "No release-manager backup is available."
            ],
        }

    backup = backups[0]

    result = _restore_backup(
        root,
        backup,
    )

    txid = _tx_id(
        "ROLLBACK"
    )

    journal = {
        "txid": txid,
        "created_at": _now(),
        "status": (
            "ROLLED_BACK"
            if result.get(
                "restored"
            )
            else "FAILED"
        ),
        "backup": str(
            backup
        ),
        "result": result,
        "restart_required": bool(
            result.get(
                "restored"
            )
        ),
    }

    journal_path = (
        dirs["logs"]
        / f"{txid}.json"
    )

    _write_json(
        journal_path,
        journal,
    )

    if result.get(
        "restored"
    ):
        _write_json(
            dirs["logs"] / "update_state.json",
            {
                "last_transaction": txid,
                "status": "ROLLED_BACK",
                "current_version": read_current_version(
                    root
                ),
                "backup": str(backup),
                "restart_required": True,
                "updated_at": _now(),
            },
        )

    return {
        "status": journal["status"],
        "backup": str(backup),
        "current_version": read_current_version(
            root
        ),
        "restart_required": journal[
            "restart_required"
        ],
        "journal": str(journal_path),
        "errors": result.get(
            "errors",
            [],
        ),
    }


def acknowledge_running_version(
    root: Path,
    running_version: str | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    dirs = ensure_runtime_dirs(
        root
    )

    current = (
        str(
            running_version
        ).strip()
        if running_version is not None
        else read_current_version(
            root
        )
    )

    state_path = (
        dirs["logs"]
        / "update_state.json"
    )

    if not state_path.is_file():
        return {
            "status": "NO_STATE",
            "current_version": current,
            "restart_required": False,
        }

    try:
        state = json.loads(
            state_path.read_text(
                encoding="utf-8"
            )
        )
    except Exception as exc:
        return {
            "status": "STATE_READ_FAILED",
            "current_version": current,
            "restart_required": True,
            "error": (
                f"{type(exc).__name__}: {exc}"
            ),
        }

    restart_required = bool(
        state.get(
            "restart_required"
        )
    )

    state_version = str(
        state.get(
            "current_version",
            ""
        )
    ).strip()

    if not restart_required:
        return {
            "status": "ALREADY_ACKNOWLEDGED",
            "current_version": current,
            "restart_required": False,
        }

    if state_version != current:
        return {
            "status": "VERSION_MISMATCH",
            "current_version": current,
            "state_version": state_version,
            "restart_required": True,
        }

    txid = _tx_id(
        "RESTART-ACK"
    )

    state.update(
        {
            "restart_required": False,
            "restart_acknowledged_at": _now(),
            "restart_acknowledged_version": current,
            "restart_acknowledged_by":
                "APPLICATION_STARTUP",
            "last_restart_ack_transaction":
                txid,
        }
    )

    _write_json(
        state_path,
        state,
    )

    journal = {
        "txid": txid,
        "created_at": _now(),
        "status": "RESTART_ACKNOWLEDGED",
        "current_version": current,
        "source_update_status": state.get(
            "status",
            "",
        ),
        "restart_required": False,
    }

    journal_path = (
        dirs["logs"]
        / f"{txid}.json"
    )

    _write_json(
        journal_path,
        journal,
    )

    return {
        "status": "RESTART_ACKNOWLEDGED",
        "current_version": current,
        "restart_required": False,
        "journal": str(
            journal_path
        ),
    }


def status_report(
    root: Path,
    *,
    include_candidates: bool = True,
) -> dict[str, Any]:
    root = root.resolve()
    dirs = ensure_runtime_dirs(root)

    current_manifest = read_local_manifest(
        root
    )

    drift = current_drift_report(
        root,
        current_manifest,
    )

    state_path = (
        dirs["logs"]
        / "update_state.json"
    )

    state = {}

    if state_path.is_file():
        try:
            state = json.loads(
                state_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception:
            state = {}

    candidates = scan_candidates(root) if include_candidates else candidate_inventory(root)

    return {
        "root": str(root),
        "current_version": read_current_version(
            root
        ),
        "managed_manifest_entries": len(
            current_manifest
        ),
        "managed_code_clean": drift[
            "clean"
        ],
        "drift": drift,
        "candidate_count": len(
            candidates
        ),
        "candidate_verification": "VERIFIED" if include_candidates else "NOT_CHECKED",
        "approved_eligible_count": sum(
            1
            for row in candidates
            if row["scope"] == "approved"
            and row["eligible"]
        ) if include_candidates else None,
        "last_state": state,
        "paths": {
            key: str(value)
            for key, value in dirs.items()
        },
    }


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _print_json(data: Any) -> None:
    print(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        )
    )


def cli(
    argv: list[str] | None = None,
) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Stock Investment OS transactional release manager. "
            "Designed for Work/Codex/manual orchestration."
        )
    )

    parser.add_argument(
        "--root",
        default=".",
        help="Project root. Default: current directory.",
    )

    sub = parser.add_subparsers(
        dest="command",
        required=True,
    )

    sub.add_parser(
        "status"
    )

    sub.add_parser(
        "scan"
    )

    preview_p = sub.add_parser(
        "preview"
    )
    preview_p.add_argument(
        "--package",
        required=True,
    )
    preview_p.add_argument(
        "--auto",
        action="store_true",
        help="Use strict automatic-update eligibility rules.",
    )

    approve_p = sub.add_parser(
        "approve"
    )
    approve_p.add_argument(
        "--package",
        required=True,
    )
    approve_p.add_argument(
        "--validation-report",
        required=True,
    )
    approve_p.add_argument(
        "--expected-sha256",
        required=True,
    )

    apply_p = sub.add_parser(
        "apply"
    )
    apply_p.add_argument(
        "--package",
        required=True,
    )

    retire_p = sub.add_parser(
        "retire"
    )
    retire_p.add_argument(
        "--package",
        required=True,
    )
    retire_p.add_argument(
        "--reason",
        default="",
    )

    feed_config_p = sub.add_parser(
        "feed-config"
    )
    feed_config_p.add_argument(
        "--url",
        default="",
    )
    feed_config_p.add_argument(
        "--host",
        action="append",
        default=[],
    )
    feed_config_p.add_argument(
        "--channel",
        default="stable",
    )
    feed_config_p.add_argument(
        "--auto-sync",
        action="store_true",
    )
    feed_config_p.add_argument(
        "--interval-minutes",
        type=int,
        default=60,
    )
    feed_config_p.add_argument(
        "--timeout-seconds",
        type=int,
        default=15,
    )
    feed_config_p.add_argument(
        "--disable",
        action="store_true",
    )
    feed_config_p.add_argument(
        "--allow-file-source",
        action="store_true",
        help="Controlled local testing only.",
    )

    sub.add_parser(
        "feed-status"
    )

    sub.add_parser(
        "feed-check"
    )

    sub.add_parser(
        "feed-sync"
    )

    publisher_status_p = sub.add_parser(
        "publisher-status"
    )
    publisher_status_p.add_argument(
        "--repository",
        default="",
    )

    publisher_preview_p = sub.add_parser(
        "publisher-preview"
    )
    publisher_preview_p.add_argument(
        "--package",
        required=True,
    )
    publisher_preview_p.add_argument(
        "--repository",
        default="",
    )
    publisher_preview_p.add_argument(
        "--base-url",
        required=True,
    )
    publisher_preview_p.add_argument(
        "--channel",
        default="stable",
    )
    publisher_preview_p.add_argument(
        "--feed-id",
        default="stock-investment-os-stable",
    )
    publisher_preview_p.add_argument(
        "--allow-file-public-url",
        action="store_true",
    )

    deploy_config_p = sub.add_parser(
        "deploy-config"
    )
    deploy_config_p.add_argument(
        "--repository",
        default="",
    )
    deploy_config_p.add_argument(
        "--remote-url",
        required=True,
    )
    deploy_config_p.add_argument(
        "--remote-name",
        default="origin",
    )
    deploy_config_p.add_argument(
        "--branch",
        default="main",
    )
    deploy_config_p.add_argument(
        "--public-base-url",
        required=True,
    )
    deploy_config_p.add_argument(
        "--interval-minutes",
        type=int,
        default=60,
    )
    deploy_config_p.add_argument(
        "--allow-file-remote",
        action="store_true",
    )
    deploy_config_p.add_argument(
        "--allow-file-public-url",
        action="store_true",
    )

    sub.add_parser(
        "deploy-status"
    )

    sub.add_parser(
        "deploy-connect"
    )

    sub.add_parser(
        "deploy-preview"
    )

    sub.add_parser(
        "deploy-push"
    )

    sub.add_parser(
        "deploy-verify"
    )

    sub.add_parser(
        "deploy-bootstrap"
    )

    sub.add_parser(
        "operations-status"
    )

    sub.add_parser(
        "operations-live-check"
    )

    sub.add_parser(
        "recovery-status"
    )

    sub.add_parser(
        "recovery-drill"
    )

    sub.add_parser(
        "orchestrator-status"
    )

    orchestrator_preflight_p = sub.add_parser(
        "orchestrator-preflight"
    )
    orchestrator_preflight_p.add_argument(
        "--package",
        required=True,
    )
    orchestrator_preflight_p.add_argument(
        "--expected-sha256",
        required=True,
    )

    orchestrator_release_p = sub.add_parser(
        "orchestrator-release"
    )
    orchestrator_release_p.add_argument(
        "--package",
        required=True,
    )
    orchestrator_release_p.add_argument(
        "--expected-sha256",
        required=True,
    )

    orchestrator_install_preview_p = sub.add_parser(
        "orchestrator-install-preview"
    )
    orchestrator_install_preview_p.add_argument(
        "--package",
        required=True,
    )
    orchestrator_install_preview_p.add_argument(
        "--live-verify",
        action="store_true",
    )

    orchestrator_install_p = sub.add_parser(
        "orchestrator-install"
    )
    orchestrator_install_p.add_argument(
        "--package",
        required=True,
    )

    sub.add_parser(
        "orchestrator-finalize"
    )

    publisher_publish_p = sub.add_parser(
        "publisher-publish"
    )
    publisher_publish_p.add_argument(
        "--package",
        required=True,
    )
    publisher_publish_p.add_argument(
        "--repository",
        default="",
    )
    publisher_publish_p.add_argument(
        "--base-url",
        required=True,
    )
    publisher_publish_p.add_argument(
        "--channel",
        default="stable",
    )
    publisher_publish_p.add_argument(
        "--feed-id",
        default="stock-investment-os-stable",
    )
    publisher_publish_p.add_argument(
        "--allow-file-public-url",
        action="store_true",
    )

    sub.add_parser(
        "auto-update"
    )

    sub.add_parser(
        "rollback"
    )

    args = parser.parse_args(
        argv
    )

    root = Path(
        args.root
    ).resolve()

    if args.command == "status":
        result = status_report(
            root
        )

    elif args.command == "scan":
        result = scan_candidates(
            root
        )

    elif args.command == "preview":
        result = preview_release(
            root,
            Path(
                args.package
            ),
            for_auto_apply=bool(
                args.auto
            ),
        )

    elif args.command == "approve":
        result = approve_release(
            root,
            Path(
                args.package
            ),
            Path(
                args.validation_report
            ),
            args.expected_sha256,
        )

    elif args.command == "apply":
        package = Path(
            args.package
        ).resolve()

        approval_ok, approval_error = _approval_valid(
            package
        )

        if not approval_ok:
            result = {
                "status": "BLOCKED",
                "blockers": [
                    approval_error
                ],
            }
        else:
            result = apply_release(
                root,
                package,
                require_approved_folder=True,
            )

    elif args.command == "retire":
        result = retire_approved_release(
            root,
            Path(
                args.package
            ),
            reason=args.reason,
        )

    elif args.command == "feed-config":
        from updater.release_feed import (
            save_trusted_feed_config,
        )

        result = save_trusted_feed_config(
            root,
            feed_url=args.url,
            allowed_hosts=args.host,
            channel=args.channel,
            enabled=not bool(
                args.disable
            ),
            auto_sync=bool(
                args.auto_sync
            ),
            check_interval_minutes=int(
                args.interval_minutes
            ),
            request_timeout_seconds=int(
                args.timeout_seconds
            ),
            allow_file_source=bool(
                args.allow_file_source
            ),
        )

    elif args.command == "feed-status":
        from updater.release_feed import (
            trusted_release_feed_status,
        )

        result = trusted_release_feed_status(
            root
        )

    elif args.command == "feed-check":
        from updater.release_feed import (
            check_trusted_release_feed,
        )

        result = check_trusted_release_feed(
            root
        )

    elif args.command == "feed-sync":
        from updater.release_feed import (
            sync_trusted_release_to_inbox,
        )

        result = sync_trusted_release_to_inbox(
            root
        )

    elif args.command == "deploy-config":
        from updater.repository_deployer import (
            save_deployment_config,
        )

        result = save_deployment_config(
            root,
            repository_root=(
                args.repository
                or None
            ),
            remote_url=args.remote_url,
            public_base_url=args.public_base_url,
            remote_name=args.remote_name,
            branch=args.branch,
            enabled=True,
            auto_bootstrap_client_feed=True,
            client_check_interval_minutes=int(
                args.interval_minutes
            ),
            allow_file_remote=bool(
                args.allow_file_remote
            ),
            allow_file_public_url=bool(
                args.allow_file_public_url
            ),
        )

    elif args.command == "deploy-status":
        from updater.repository_deployer import (
            deployment_status,
        )

        result = deployment_status(
            root
        )

    elif args.command == "deploy-connect":
        from updater.repository_deployer import (
            connect_git_repository,
        )

        result = connect_git_repository(
            root
        )

    elif args.command == "deploy-preview":
        from updater.repository_deployer import (
            preview_deployment,
        )

        result = preview_deployment(
            root
        )

    elif args.command == "deploy-push":
        from updater.repository_deployer import (
            deploy_repository,
        )

        result = deploy_repository(
            root
        )

    elif args.command == "deploy-verify":
        from updater.repository_deployer import (
            verify_public_deployment,
        )

        result = verify_public_deployment(
            root
        )

    elif args.command == "deploy-bootstrap":
        from updater.repository_deployer import (
            bootstrap_client_feed,
        )

        result = bootstrap_client_feed(
            root
        )

    elif args.command == "operations-status":
        from updater.trusted_release_operations import (
            trusted_release_operations_status,
        )

        result = trusted_release_operations_status(
            root
        )

    elif args.command == "operations-live-check":
        from updater.trusted_release_operations import (
            trusted_release_operations_live_check,
        )

        result = trusted_release_operations_live_check(
            root
        )

    elif args.command == "recovery-status":
        from updater.release_recovery import (
            trusted_release_recovery_status,
        )

        result = trusted_release_recovery_status(
            root
        )

    elif args.command == "recovery-drill":
        from updater.release_recovery import (
            trusted_release_recovery_drill,
        )

        result = trusted_release_recovery_drill(
            root
        )

    elif args.command == "orchestrator-status":
        from updater.safe_update_orchestrator import (
            safe_update_orchestrator_status,
        )

        result = safe_update_orchestrator_status(
            root
        )

    elif args.command == "orchestrator-preflight":
        from updater.safe_update_orchestrator import (
            preflight_inbox_release,
        )

        result = preflight_inbox_release(
            root,
            Path(args.package),
            args.expected_sha256,
        )

    elif args.command == "orchestrator-release":
        from updater.safe_update_orchestrator import (
            approve_publish_deploy,
        )

        result = approve_publish_deploy(
            root,
            Path(args.package),
            args.expected_sha256,
        )

    elif args.command == "orchestrator-install-preview":
        from updater.safe_update_orchestrator import (
            install_readiness,
        )

        result = install_readiness(
            root,
            Path(args.package),
            live_verify=bool(
                args.live_verify
            ),
        )

    elif args.command == "orchestrator-install":
        from updater.safe_update_orchestrator import (
            install_verified_release,
        )

        result = install_verified_release(
            root,
            Path(args.package),
        )

    elif args.command == "orchestrator-finalize":
        from updater.safe_update_orchestrator import (
            finalize_after_restart,
        )

        result = finalize_after_restart(
            root
        )

    elif args.command == "publisher-status":
        from updater.release_publisher import (
            publisher_status,
        )

        result = publisher_status(
            root,
            repository_root=(
                args.repository
                or None
            ),
        )

    elif args.command == "publisher-preview":
        from updater.release_publisher import (
            preview_release_publish,
        )

        result = preview_release_publish(
            root,
            Path(
                args.package
            ),
            repository_root=(
                args.repository
                or None
            ),
            public_base_url=args.base_url,
            channel=args.channel,
            feed_id=args.feed_id,
            allow_file_public_url=bool(
                args.allow_file_public_url
            ),
        )

    elif args.command == "publisher-publish":
        from updater.release_publisher import (
            publish_release_repository,
        )

        result = publish_release_repository(
            root,
            Path(
                args.package
            ),
            repository_root=(
                args.repository
                or None
            ),
            public_base_url=args.base_url,
            channel=args.channel,
            feed_id=args.feed_id,
            allow_file_public_url=bool(
                args.allow_file_public_url
            ),
        )

    elif args.command == "auto-update":
        result = auto_update_once(
            root
        )

    elif args.command == "rollback":
        result = rollback_latest(
            root
        )

    else:
        result = {
            "status": "BLOCKED",
            "blockers": [
                "Unknown command"
            ],
        }

    _print_json(
        result
    )

    status = (
        result.get(
            "status"
        )
        if isinstance(
            result,
            dict,
        )
        else ""
    )

    if status in {
        "BLOCKED",
        "FAILED",
    }:
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(
        cli()
    )
