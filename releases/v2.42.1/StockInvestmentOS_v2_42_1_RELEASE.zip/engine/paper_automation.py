"""Bounded, session-owned PAPER automation. No credentials, workers or auto-resume."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo
import hashlib
import json
import secrets
import time

from connectors.kis_broker import BrokerError, number, whole, validate_order
from engine.broker_execution import (ACTIVE, canonical, validate_limits, prepare_order,
                                     submit_order, confirmation_text, reconcile_order)
from engine.paper_calendar import session_status
from engine.broker_fills import fill_view

PROCESS = secrets.token_hex(32)
PAPER_URL = 'https://openapivts.koreainvestment.com:29443'
MAX_GAP = 60


@dataclass(frozen=True)
class Permit:
    run_id: str
    account: str
    token: str = field(repr=False)


def _owner(token):
    return hashlib.sha256(token.encode()).hexdigest()


def _day():
    return datetime.fromtimestamp(time.time(), timezone(timedelta(hours=9))).strftime('%Y-%m-%d')


def paper_only(client, account=None):
    if client.credentials.mode != 'PAPER' or client.base_url != PAPER_URL:
        raise BrokerError('자동매매는 모의투자 연결에서만 가능합니다.')
    if account is not None and client.credentials.identity != account:
        raise BrokerError('연결 계좌가 바뀌었습니다. 자동매매를 다시 설정하세요.')


def session_open(market, stamp):
    return session_status(market, stamp)['open']


def validate_rule(value):
    order = validate_order(value['order'])
    if value.get('comparison') not in ('LE', 'GE'):
        raise BrokerError('가격 조건을 확인하세요.')
    trigger = number(value['trigger'], positive=True)
    if trigger > Decimal('1000000000'):
        raise BrokerError('조건 가격을 확인하세요.')
    limits = value['limits']
    validate_limits(order, limits)
    # Keep only engine-used, nonsecret fields; do not persist caller extras.
    clean_limits = {key: limits[key] for key in ('max_notional', 'fee_buffer_pct',
        'max_quote_gap_pct', 'downside_pct', 'max_scenario_loss', 'risk_attested')}
    clean = dict(order=order, comparison=value['comparison'], trigger=str(trigger), limits=clean_limits)
    if 'after_buy' in value:
        parent = value['after_buy']
        if type(parent) is not int or not 0 <= parent < 9 or order['side'] != 'SELL':
            raise BrokerError('연결 매도는 앞서 등록한 매수 조건을 선택하세요.')
        clean['after_buy'] = parent
    return clean


def validate_rules(values):
    if not 1 <= len(values) <= 10:
        raise BrokerError('조건을 1~10개 등록하세요.')
    rules = [validate_rule(value) for value in values]
    if len({canonical(r) for r in rules}) != len(rules):
        raise BrokerError('같은 조건이 중복 등록되어 있습니다.')
    linked = {}
    for idx, rule in enumerate(rules):
        if 'after_buy' not in rule:
            continue
        parent = rule['after_buy']
        if parent >= idx:
            raise BrokerError('앞서 등록한 매수에만 연결할 수 있습니다.')
        buy, sell = rules[parent]['order'], rule['order']
        if (buy['side'] != 'BUY' or sell['quantity'] > buy['quantity']
                or any(buy[k] != sell[k] for k in ('market','exchange','symbol','currency'))):
            raise BrokerError('연결 매도는 같은 종목의 매수 수량 이내로 등록하세요.')
        linked.setdefault(parent, []).append(rule)
    for exits in linked.values():
        if len(exits) > 2:
            raise BrokerError('매수 하나에 연결 매도는 최대 두 개입니다.')
        if len(exits) == 2:
            lower = next((r for r in exits if r['comparison']=='LE'), None)
            upper = next((r for r in exits if r['comparison']=='GE'), None)
            if (not lower or not upper or number(lower['trigger']) >= number(upper['trigger'])
                    or lower['order']['quantity'] != upper['order']['quantity']):
                raise BrokerError('두 매도는 같은 수량의 하단 이하·상단 이상 조건이며 하단 가격이 더 낮아야 합니다.')
    return rules


def remove_rule(values, idx):
    rules = validate_rules(values)
    if type(idx) is not int or not 0 <= idx < len(rules):
        raise BrokerError('삭제할 조건을 다시 선택하세요.')
    if any(r.get('after_buy') == idx for r in rules):
        raise BrokerError('이 매수에 연결된 매도 조건부터 삭제하세요.')
    rules.pop(idx)
    for rule in rules:
        if rule.get('after_buy', -1) > idx:
            rule['after_buy'] -= 1
    return rules


def matches(rule, price):
    return price <= number(rule['trigger']) if rule['comparison'] == 'LE' else price >= number(rule['trigger'])


def checked_quote(client, rule):
    value = client.quote(rule['order'])
    fetched = datetime.fromisoformat(str(value.get('fetched_at', '')).replace('Z', '+00:00'))
    if fetched.tzinfo is None or not -2 <= time.time() - fetched.timestamp() <= 15:
        raise BrokerError('시세 조회 시점을 확인할 수 없습니다.')
    if value.get('currency') != rule['order']['currency']:
        raise BrokerError('시세 통화가 주문 통화와 다릅니다.')
    price = number(value['price'], positive=True)
    return dict(price=str(price), currency=value['currency'], fetched_at=fetched.isoformat())


class Automation:
    mode = 'PAPER'

    def _check_client(self, client, account=None):
        paper_only(client, account)

    def check_order_session(self, client, order):
        pass  # LIVE subclass additionally validates the broker opening calendar.

    def __init__(self, journal):
        self.journal = journal
        with journal.transaction() as db:
            db.execute('CREATE TABLE IF NOT EXISTS paper_runs (id TEXT PRIMARY KEY, account TEXT NOT NULL, owner TEXT NOT NULL, process TEXT NOT NULL, expires REAL NOT NULL, heartbeat REAL NOT NULL, busy INTEGER NOT NULL, state TEXT NOT NULL, config TEXT NOT NULL, note TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS paper_rules (run_id TEXT NOT NULL, idx INTEGER NOT NULL, payload TEXT NOT NULL, state TEXT NOT NULL, order_id TEXT NOT NULL, price TEXT NOT NULL, PRIMARY KEY(run_id,idx))')
            db.execute('CREATE TABLE IF NOT EXISTS paper_attempts (run_id TEXT NOT NULL, idx INTEGER NOT NULL, account TEXT NOT NULL, day TEXT NOT NULL, currency TEXT NOT NULL, cost TEXT NOT NULL, loss TEXT NOT NULL, state TEXT NOT NULL, order_id TEXT NOT NULL, PRIMARY KEY(run_id,idx))')
            # A separate table preserves positional INSERT compatibility on rollback.
            db.execute('CREATE TABLE IF NOT EXISTS paper_prepare_protocol (run_id TEXT NOT NULL, idx INTEGER NOT NULL, protocol TEXT NOT NULL, PRIMARY KEY(run_id,idx))')
            db.execute('CREATE TABLE IF NOT EXISTS paper_exit_choices (run_id TEXT NOT NULL, parent_idx INTEGER NOT NULL, selected_idx INTEGER NOT NULL, PRIMARY KEY(run_id,parent_idx))')

    @staticmethod
    def _valid(row, permit):
        return (row is not None and row['account'] == permit.account
                and secrets.compare_digest(row['owner'], _owner(permit.token))
                and row['process'] == PROCESS)

    def _run(self, db, permit):
        row = db.execute('SELECT * FROM paper_runs WHERE id=?', (permit.run_id,)).fetchone()
        if not self._valid(row, permit):
            raise BrokerError('현재 세션의 시작 확인이 없습니다. 자동 재개하지 않습니다.')
        if json.loads(row['config']).get('mode', 'PAPER') != self.mode:
            raise BrokerError('현재 연결 환경의 실행 확인이 아닙니다.')
        return row

    def arm(self, client, rules, budgets, minutes, *, confirmed=False, plan_reference=None):
        self._check_client(client)
        if confirmed is not True or not 1 <= whole(minutes) <= 60:
            raise BrokerError('조건을 확인하고 1~60분의 실행 시간을 선택하세요.')
        if not 1 <= len(rules) <= 10:
            raise BrokerError('조건을 1~10개 등록하세요.')
        rules = validate_rules(rules)
        config = {'budgets': {}, 'day': _day(), 'mode': self.mode}
        for currency in {r['order']['currency'] for r in rules}:
            budget = budgets[currency]
            config['budgets'][currency] = dict(cost=str(number(budget['cost'], positive=True)),
                loss=str(number(budget['loss'])), count=whole(budget['count']))
            if not 1 <= config['budgets'][currency]['count'] <= 10:
                raise BrokerError('하루 주문 시도 수는 통화별 1~10회입니다.')
        account = client.credentials.identity
        from engine.plan_origin import resolve
        config['plan_origin'] = resolve(self.journal, client, rules, budgets, minutes,
                                        plan_reference, mode=self.mode)
        self._check_client(client, account)
        permit = Permit(secrets.token_hex(16), account, secrets.token_hex(32))
        now = time.time()
        with self.journal.transaction() as db:
            self._no_active(db, account)
            # Manual reconciliation may have resolved a stopped run's known order.
            for old in db.execute("SELECT run_id,idx,order_id FROM paper_attempts WHERE account=? AND state IN ('CLAIMED','PENDING','UNKNOWN')", (account,)).fetchall():
                resolved = db.execute("SELECT status FROM orders WHERE id=? AND account=? AND status IN ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK')", (old['order_id'], account)).fetchone()
                if resolved:
                    for table in ('paper_rules', 'paper_attempts'):
                        db.execute(f'UPDATE {table} SET state=? WHERE run_id=? AND idx=?', (resolved['status'], old['run_id'], old['idx']))
            # Unfinished reservations survive process loss and never become eligible again.
            if db.execute("SELECT 1 FROM paper_attempts WHERE account=? AND state IN ('CLAIMED','PENDING','UNKNOWN')", (account,)).fetchone():
                raise BrokerError('이전 자동 주문의 확인이 필요합니다. 주문·체결 관리에서 확인하세요.')
            if db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (account,)).fetchone():
                raise BrokerError('신규 주문이 중지되어 있습니다.')
            if db.execute("SELECT 1 FROM paper_runs WHERE account=? AND state='ARMED' AND process=? AND heartbeat>? AND expires>?", (account, PROCESS, now-MAX_GAP, now)).fetchone():
                raise BrokerError('다른 화면에서 자동매매가 실행 중입니다. 먼저 중지하세요.')
            db.execute("UPDATE paper_runs SET state='STOPPED',note='이전 실행 만료' WHERE account=? AND state='ARMED'", (account,))
            db.execute('INSERT INTO paper_runs VALUES(?,?,?,?,?,?,0,?,?,?)',
                (permit.run_id, account, _owner(permit.token), PROCESS, now+60*minutes, now, 'ARMED', canonical(config), '가격 조건 대기'))
            db.executemany("INSERT INTO paper_rules VALUES(?,?,?,'WAITING','','')",
                [(permit.run_id, i, canonical(r)) for i, r in enumerate(rules)])
            self.journal._event(db, None, self.mode+'_AUTO_ARMED', permit.run_id)
        return permit

    def _no_active(self, db, account):
        expired = db.execute("SELECT id FROM orders WHERE account=? AND status='PREPARED' AND expires<=?", (account, time.time())).fetchall()
        for row in expired:
            db.execute("UPDATE orders SET status='EXPIRED' WHERE id=?", (row['id'],))
            self.journal._event(db, row['id'], 'EXPIRED')
        states = (*ACTIVE, 'PREPARED')
        if db.execute('SELECT 1 FROM orders WHERE account=? AND status IN ('+','.join('?' for _ in states)+')', (account, *states)).fetchone():
            raise BrokerError('미완료 주문이 있습니다. 주문·체결 관리에서 먼저 확인하세요.')

    def stop(self, account, note='사용자가 중지했습니다.', *, halt=True):
        with self.journal.transaction() as db:
            db.execute("UPDATE paper_runs SET state='STOPPED',note=? WHERE account=? AND state='ARMED'", (note, account))
            if halt:
                db.execute('INSERT INTO controls VALUES(?,1) ON CONFLICT(account) DO UPDATE SET halted=1', (account,))
            self.journal._event(db, None, self.mode+'_AUTO_STOPPED', account)

    def guard(self, client, permit):
        self._check_client(client, permit.account)
        with self.journal.transaction() as db:
            row = self._run(db, permit)
            now = time.time()
            if (row['state'] != 'ARMED' or now >= row['expires']
                    or not 0 <= now-row['heartbeat'] <= MAX_GAP
                    or json.loads(row['config'])['day'] != _day()
                    or db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (permit.account,)).fetchone()):
                raise BrokerError('실행 시간이 끝났거나 자동매매가 중지되었습니다.')

    def snapshot(self, permit):
        from engine.rule_waiting import explain
        with self.journal.transaction() as db:
            run = dict(self._run(db, permit))
            observed_at = time.time()
            run_valid = (run['state'] == 'ARMED' and observed_at < run['expires']
                and 0 <= observed_at-run['heartbeat'] <= MAX_GAP
                and json.loads(run['config'])['day'] == _day()
                and not db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (permit.account,)).fetchone())
            rules = [dict(r) for r in db.execute('SELECT * FROM paper_rules WHERE run_id=? ORDER BY idx', (permit.run_id,))]
            for rule in rules:
                record = db.execute('SELECT result FROM orders WHERE id=? AND account=?', (rule['order_id'],permit.account)).fetchone()
                rule['fill_details'] = fill_view(json.loads(rule['payload'])['order'],json.loads(record['result']) if record else {})
            for item in rules:
                payload = json.loads(item['payload'])
                dependency, market_open = 'READY', None
                if item['state'] == 'WAITING' and run_valid:
                    try:
                        dependency = self._dependency(db, permit, item['idx'], payload)
                    except (BrokerError, ValueError, KeyError, TypeError):
                        dependency = 'REVIEW'
                    try:
                        market_open = session_open(payload['order']['market'], observed_at)
                    except (ValueError, KeyError, TypeError):
                        market_open = None
                item['waiting_info'] = explain(dict(item, rule=payload), rules,
                    run_state=run['state'], run_valid=bool(run_valid),
                    dependency=dependency, market_open=market_open)
            day = datetime.fromtimestamp(time.time(), timezone(timedelta(hours=9))).strftime('%Y-%m-%d')
            totals = {}
            for r in db.execute('SELECT * FROM paper_attempts WHERE account=? AND day=?', (permit.account, day)):
                total = totals.setdefault(r['currency'], {'cost': Decimal(0), 'loss': Decimal(0), 'count': 0})
                total['cost'] += number(r['cost']); total['loss'] += number(r['loss']); total['count'] += 1
        return dict(state=run['state'], note=run['note'], expires=run['expires'], busy=bool(run['busy']),
            observed_at=datetime.fromtimestamp(observed_at, timezone.utc).isoformat(),
            plan_origin=json.loads(run['config']).get('plan_origin'),
            rules=[dict(idx=r['idx'], rule=json.loads(r['payload']), state=r['state'], order_id=r['order_id'], price=r['price'], fill_details=r['fill_details'], waiting_info=r['waiting_info']) for r in rules],
            totals={c: {k: str(v) if isinstance(v, Decimal) else v for k, v in t.items()} for c, t in totals.items()})

    def _dependency(self, db, permit, idx, rule):
        """Trust the same-run linked order and matched fill quantities, not a UI label."""
        if 'after_buy' not in rule:
            return 'READY'
        parent_idx = rule['after_buy']
        if type(parent_idx) is not int or not 0 <= parent_idx < idx:
            raise BrokerError('연결 매수 기록을 확인하세요.')
        choice = db.execute('SELECT selected_idx FROM paper_exit_choices WHERE run_id=? AND parent_idx=?', (permit.run_id,parent_idx)).fetchone()
        if choice and choice['selected_idx'] != idx:
            raise BrokerError('같은 매수의 다른 매도 조건이 이미 선택되었습니다.')
        parent = db.execute('SELECT * FROM paper_rules WHERE run_id=? AND idx=?', (permit.run_id,parent_idx)).fetchone()
        if parent is None:
            raise BrokerError('연결 매수 기록이 없습니다.')
        buy = json.loads(parent['payload'])['order']
        sell = rule['order']
        if (buy['side'] != 'BUY' or sell['side'] != 'SELL' or sell['quantity'] > buy['quantity']
                or any(buy[k] != sell[k] for k in ('market','exchange','symbol','currency'))):
            raise BrokerError('연결된 종목·수량이 달라졌습니다.')
        if parent['state'] == 'WAITING':
            return 'WAIT'
        attempt = db.execute('SELECT * FROM paper_attempts WHERE run_id=? AND idx=? AND account=?',
            (permit.run_id,parent_idx,permit.account)).fetchone()
        record = db.execute('SELECT * FROM orders WHERE id=? AND account=?', (parent['order_id'],permit.account)).fetchone()
        if (not attempt or not record or attempt['order_id'] != parent['order_id']
                or json.loads(record['payload']).get('mode') != self.mode
                or canonical(json.loads(record['payload'])['order']) != canonical(buy)):
            raise BrokerError('매수 주문과 체결 기록의 연결을 확인할 수 없습니다.')
        if parent['state'] == attempt['state'] == record['status'] == 'CANCELLED':
            return 'SKIP'
        if parent['state'] == attempt['state'] == record['status'] == 'FILLED':
            receipt = json.loads(record['result'])
            stamp = datetime.fromisoformat(str(receipt.get('last_checked_at','')))
            if (type(receipt.get('filled_quantity')) is not int or receipt['filled_quantity'] != buy['quantity']
                    or type(receipt.get('remaining_quantity')) is not int or receipt['remaining_quantity'] != 0
                    or not receipt.get('order_no') or stamp.tzinfo is None):
                raise BrokerError('전량 체결 수량을 확인하지 못했습니다.')
            return 'READY'
        raise BrokerError('선행 매수의 최종 체결 확인이 필요합니다.')

    def _exit_rows(self, db, permit, idx, rule):
        rows = db.execute('SELECT * FROM paper_rules WHERE run_id=? ORDER BY idx', (permit.run_id,)).fetchall()
        if [r['idx'] for r in rows] != list(range(len(rows))):
            raise BrokerError('등록 조건의 순서가 달라졌습니다.')
        rules = validate_rules([json.loads(r['payload']) for r in rows])
        if type(idx) is not int or not 0 <= idx < len(rules) or canonical(rules[idx]) != canonical(rule):
            raise BrokerError('실행 조건이 달라졌습니다.')
        return [row for row,r in zip(rows,rules) if r.get('after_buy') == rule['after_buy']]

    def _claim_exit(self, db, permit, idx, rule):
        if 'after_buy' not in rule:
            return
        rows = self._exit_rows(db, permit, idx, rule)
        # A durable unique choice is committed with the attempt and peer skip.
        # Failure rolls back all three; an ambiguous send never releases its peer.
        for row in rows:
            if (row['state'] != 'WAITING' or row['order_id']
                    or db.execute('SELECT 1 FROM paper_attempts WHERE run_id=? AND idx=?', (permit.run_id,row['idx'])).fetchone()):
                raise BrokerError('연결 매도에 이미 처리된 시도가 있습니다.')
        db.execute('INSERT INTO paper_exit_choices VALUES(?,?,?)', (permit.run_id,rule['after_buy'],idx))
        for row in rows:
            if row['idx'] != idx:
                db.execute("UPDATE paper_rules SET state='ALTERNATIVE_SKIPPED' WHERE run_id=? AND idx=?", (permit.run_id,row['idx']))
        self.journal._event(db, None, self.mode+'_EXIT_SELECTED', permit.run_id+':'+str(idx))

    def _exit_guard(self, db, permit, idx, rule):
        if 'after_buy' not in rule:
            return
        choice = db.execute('SELECT selected_idx FROM paper_exit_choices WHERE run_id=? AND parent_idx=?', (permit.run_id,rule['after_buy'])).fetchone()
        if not choice or choice['selected_idx'] != idx:
            raise BrokerError('선택된 연결 매도 기록을 확인할 수 없습니다.')
        for row in self._exit_rows(db, permit, idx, rule):
            if row['idx'] == idx:
                attempt = db.execute('SELECT state,order_id FROM paper_attempts WHERE run_id=? AND idx=? AND account=?', (permit.run_id,idx,permit.account)).fetchone()
                if not attempt or row['state'] != 'CLAIMED' or attempt['state'] != 'CLAIMED' or row['order_id'] != attempt['order_id']:
                    raise BrokerError('선택된 매도의 주문 시도 기록을 확인할 수 없습니다.')
            if row['idx'] != idx and (row['state'] != 'ALTERNATIVE_SKIPPED' or row['order_id']
                    or db.execute('SELECT 1 FROM paper_attempts WHERE run_id=? AND idx=?', (permit.run_id,row['idx'])).fetchone()):
                raise BrokerError('다른 연결 매도의 중복 방지 기록을 확인할 수 없습니다.')

    def dependency_guard(self, permit, idx, rule):
        with self.journal.transaction() as db:
            self._run(db, permit)
            saved = db.execute('SELECT payload FROM paper_rules WHERE run_id=? AND idx=?', (permit.run_id,idx)).fetchone()
            if not saved or canonical(json.loads(saved['payload'])) != canonical(rule):
                raise BrokerError('실행 조건이 달라졌습니다.')
            self._exit_guard(db, permit, idx, rule)
            if self._dependency(db, permit, idx, rule) != 'READY':
                raise BrokerError('선행 매수 전량 체결을 기다려야 합니다.')

    def _reserve(self, permit, idx, rule):
        cost = validate_limits(rule['order'], rule['limits'])
        currency = rule['order']['currency']
        day = datetime.fromtimestamp(time.time(), timezone(timedelta(hours=9))).strftime('%Y-%m-%d')
        with self.journal.transaction() as db:
            run = self._run(db, permit)
            if run['state'] != 'ARMED':
                raise BrokerError('자동매매가 중지되었습니다.')
            if self._dependency(db, permit, idx, rule) != 'READY':
                raise BrokerError('선행 매수 전량 체결을 기다려야 합니다.')
            self._no_active(db, permit.account)
            cap = json.loads(run['config'])['budgets'][currency]
            past = list(db.execute('SELECT cost,loss FROM paper_attempts WHERE account=? AND day=? AND currency=?', (permit.account, day, currency)))
            if (len(past) >= cap['count']
                    or sum((number(p['cost']) for p in past), Decimal(0))+number(cost['estimated_cost']) > number(cap['cost'])
                    or sum((number(p['loss']) for p in past), Decimal(0))+number(cost['scenario_loss']) > number(cap['loss'])):
                raise BrokerError('오늘의 통화별 주문 시도 예산을 초과했습니다.')
            self._claim_exit(db, permit, idx, rule)
            updated = db.execute("UPDATE paper_rules SET state='CLAIMED' WHERE run_id=? AND idx=? AND state='WAITING'", (permit.run_id, idx))
            if updated.rowcount != 1:
                raise BrokerError('이미 처리된 조건입니다.')
            db.execute("INSERT INTO paper_attempts VALUES(?,?,?,?,?,?,?,'CLAIMED','')", (permit.run_id, idx, permit.account, day, currency, cost['estimated_cost'], cost['scenario_loss']))
            db.execute("INSERT INTO paper_prepare_protocol VALUES(?,?,'ATOMIC_V1')", (permit.run_id, idx))

    def _prepare_link(self, permit, idx):
        def link(db, order_id, payload):
            run = self._run(db, permit)
            now = time.time()
            if (run['state'] != 'ARMED' or now >= run['expires']
                    or not 0 <= now-run['heartbeat'] <= MAX_GAP
                    or json.loads(run['config'])['day'] != _day()):
                raise BrokerError('자동매매가 중지되었거나 만료되었습니다.')
            rule = db.execute('SELECT * FROM paper_rules WHERE run_id=? AND idx=?', (permit.run_id,idx)).fetchone()
            attempt = db.execute('SELECT * FROM paper_attempts WHERE run_id=? AND idx=? AND account=?', (permit.run_id,idx,permit.account)).fetchone()
            if (not rule or not attempt or rule['state'] != 'CLAIMED' or attempt['state'] != 'CLAIMED'
                    or rule['order_id'] or attempt['order_id'] or payload['mode'] != self.mode
                    or canonical(json.loads(rule['payload'])['order']) != canonical(payload['order'])):
                raise BrokerError('주문 준비 기록의 연결을 확인할 수 없습니다.')
            self._exit_guard(db, permit, idx, json.loads(rule['payload']))
            if self._dependency(db, permit, idx, json.loads(rule['payload'])) != 'READY':
                raise BrokerError('선행 매수 전량 체결을 기다려야 합니다.')
            for table in ('paper_rules', 'paper_attempts'):
                db.execute(f'UPDATE {table} SET order_id=? WHERE run_id=? AND idx=?', (order_id,permit.run_id,idx))
        return link

    def _record(self, permit, idx, state, order_id=''):
        with self.journal.transaction() as db:
            previous = db.execute('SELECT state,order_id FROM paper_attempts WHERE run_id=? AND idx=? AND account=?', (permit.run_id,idx,permit.account)).fetchone()
            if previous is None:
                raise BrokerError('주문 시도 기록이 없습니다.')
            order_id = previous['order_id'] or order_id
            if order_id:
                current = db.execute('SELECT status FROM orders WHERE id=? AND account=?', (order_id,permit.account)).fetchone()
                if current and current['status'] in ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK'):
                    state = current['status']
            elif previous['state'] == 'FAILED_PRECHECK':
                state = previous['state']
            db.execute('UPDATE paper_rules SET state=?,order_id=? WHERE run_id=? AND idx=?', (state, order_id, permit.run_id, idx))
            db.execute('UPDATE paper_attempts SET state=?,order_id=? WHERE run_id=? AND idx=?', (state, order_id, permit.run_id, idx))

    def _reconcile_record(self, permit, idx, record):
        status = record['status']
        if status in ('SENDING', 'UNKNOWN', 'CANCEL_UNKNOWN', 'REJECTED', 'FAILED_PRECHECK', 'EXPIRED'):
            self._record(permit, idx, 'UNKNOWN' if status in ('SENDING', 'UNKNOWN', 'CANCEL_UNKNOWN') else status, record['id'])
            self.stop(permit.account, '주문 결과를 확인해야 합니다. 주문·체결 관리에서 확인하세요.')
        else:
            self._record(permit, idx, status if status in ('FILLED', 'CANCELLED') else 'PENDING', record['id'])

    def tick(self, client, permit):
        """One serialized cycle. Never retry a send or take over a crashed cycle."""
        acquired = False
        phase = '실행 시간·연결·신규 주문 차단 확인'
        try:
            self.guard(client, permit)
            with self.journal.transaction() as db:
                row = self._run(db, permit)
                if row['busy']:
                    return None  # another cycle owns the durable lease; never take it over
                db.execute('UPDATE paper_runs SET busy=1,heartbeat=? WHERE id=?', (time.time(), permit.run_id))
                acquired = True
            state = self.snapshot(permit)
            guarded = _PaperClient(client, self, permit)
            for item in state['rules']:
                if item['state'] == 'PENDING':
                    phase = '접수·체결 결과 확인'
                    record = reconcile_order(guarded, self.journal, item['order_id'])
                    self._reconcile_record(permit, item['idx'], record)
                    return self.snapshot(permit)
                if item['state'] in ('CLAIMED', 'UNKNOWN'):
                    raise BrokerError('이전 시도의 결과를 확인해야 합니다.')
            for item in state['rules']:
                if item['state'] != 'WAITING':
                    continue
                rule = item['rule']
                with self.journal.transaction() as db:
                    dependency = self._dependency(db, permit, item['idx'], rule)
                    if dependency == 'SKIP':
                        db.execute("UPDATE paper_rules SET state='SKIPPED' WHERE run_id=? AND idx=? AND state='WAITING'", (permit.run_id,item['idx']))
                if dependency != 'READY':
                    continue
                self.guard(client, permit)
                if not session_open(rule['order']['market'], time.time()):
                    continue
                quote = checked_quote(guarded, rule)
                with self.journal.transaction() as db:
                    db.execute('UPDATE paper_rules SET price=? WHERE run_id=? AND idx=?', (quote['price'], permit.run_id, item['idx']))
                if not matches(rule, number(quote['price'])):
                    continue
                phase = '하루 예산·이전 주문 상태 확인'
                self._reserve(permit, item['idx'], rule)
                record = None
                try:
                    phase = '가격 조건·잔고 점검 및 주문 결과 확인'
                    guarded.rule = rule
                    guarded.rule_idx = item['idx']
                    record = prepare_order(guarded, self.journal, rule['order'], rule['limits'],
                        on_prepared=self._prepare_link(permit, item['idx']))
                    record = submit_order(guarded, self.journal, record['id'], confirmation_text(record), allow_live=self.mode == 'LIVE')
                    self._reconcile_record(permit, item['idx'], record)
                except Exception:
                    if record is None:
                        with self.journal.transaction() as db:
                            linked = db.execute('SELECT order_id FROM paper_attempts WHERE run_id=? AND idx=?', (permit.run_id,item['idx'])).fetchone()
                        if linked and linked['order_id']:
                            record = self.journal.get(linked['order_id'], permit.account)
                    if record is not None:
                        record = self.journal.get(record['id'], permit.account)
                        if record['status'] == 'PREPARED':
                            self.journal.update(record['id'], permit.account, 'FAILED_PRECHECK', {}, expected=record)
                            record = self.journal.get(record['id'], permit.account)
                        state_name = 'UNKNOWN' if record['status'] in ACTIVE else 'FAILED_PRECHECK'
                    else:
                        state_name = 'FAILED_PRECHECK'
                    self._record(permit, item['idx'], state_name, record['id'] if record else '')
                    raise
                break  # at most one new order in a cycle
            state = self.snapshot(permit)
            if all(r['state'] in ('FILLED', 'CANCELLED', 'SKIPPED', 'ALTERNATIVE_SKIPPED') for r in state['rules']):
                with self.journal.transaction() as db:
                    db.execute("UPDATE paper_runs SET state='COMPLETE',note='등록 조건 처리 완료' WHERE id=? AND state='ARMED'", (permit.run_id,))
            return self.snapshot(permit)
        except Exception:
            # Do not log arbitrary exception strings, API bodies or credentials.
            # An invalid capability must not stop another session/account.
            with self.journal.transaction() as db:
                row = db.execute('SELECT * FROM paper_runs WHERE id=?', (permit.run_id,)).fetchone()
                owned = self._valid(row, permit)
                # A formerly valid retired owner must not halt a newer run.
                # Keep the ownership/state check and fail-closed stop atomic.
                if owned and row['state'] == 'ARMED':
                    db.execute("UPDATE paper_runs SET state='STOPPED',note=? WHERE id=?", ('자동매매 중지 · '+phase+'이 필요합니다.', permit.run_id))
                    db.execute('INSERT INTO controls VALUES(?,1) ON CONFLICT(account) DO UPDATE SET halted=1', (permit.account,))
                    self.journal._event(db, None, self.mode+'_AUTO_STOPPED', permit.account)
            if owned:
                return self.snapshot(permit)
            raise
        finally:
            if acquired:
                with self.journal.transaction() as db:
                    db.execute('UPDATE paper_runs SET busy=0 WHERE id=?', (permit.run_id,))


class _PaperClient:
    """Recheck mode/account/session before every operation, including the final POST."""
    def __init__(self, client, automation, permit):
        self.client, self.automation, self.permit = client, automation, permit
        self.rule = None
        self.rule_idx = None
        self.last_quote = None

    @property
    def credentials(self):
        self.automation.guard(self.client, self.permit)
        return self.client.credentials

    def quote(self, order):
        self.automation.guard(self.client, self.permit)
        if not session_open(order['market'], time.time()):
            raise BrokerError('기본 정규 거래시간 밖입니다.')
        rule = self.rule or dict(order=order)
        value = checked_quote(self.client, rule)
        self.automation.guard(self.client, self.permit)
        if self.rule and not matches(self.rule, number(value['price'])):
            raise BrokerError('가격 조건이 달라졌습니다.')
        self.last_quote = value
        return value

    def buying_power(self, order):
        self.automation.guard(self.client, self.permit)
        return self.client.buying_power(order)

    def sellable(self, order):
        self.automation.guard(self.client, self.permit)
        return self.client.sellable(order)

    def send_limit(self, order):
        self.automation.guard(self.client, self.permit)
        if self.rule is not None:
            if canonical(order) != canonical(self.rule['order']):
                raise BrokerError('전송할 조건이 달라졌습니다.')
            self.automation.dependency_guard(self.permit, self.rule_idx, self.rule)
        if self.last_quote is None or not -2 <= time.time() - datetime.fromisoformat(self.last_quote['fetched_at']).timestamp() <= 15:
            raise BrokerError('전송 전에 시세 조회 시점이 만료되었습니다.')
        if not session_open(order['market'], time.time()):
            raise BrokerError('기본 정규 거래시간 밖입니다.')
        self.automation.check_order_session(self.client, order)
        self.automation.guard(self.client, self.permit)
        return self.client.send_limit(order)

    def kr_open_day(self, day):
        self.automation.guard(self.client, self.permit)
        result = self.client.kr_open_day(day)
        self.automation.guard(self.client, self.permit)
        return result

    def order_history(self, *args):
        self.automation.guard(self.client, self.permit)
        return self.client.order_history(*args)
