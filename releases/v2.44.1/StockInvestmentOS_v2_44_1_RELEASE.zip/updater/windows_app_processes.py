"""Narrow Windows app-process ownership and handle-based termination.

No process memory, environment variables, credentials or unrelated command logs.
PID plus kernel creation ticks, image, exact argv and parent bind the identity.
"""
from contextlib import contextmanager
from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import hashlib
import os
import socket
import subprocess
import sys

from engine.update_execution_guard import InstallBlocked


def _path(value):
    return os.path.normcase(str(Path(value).resolve()))


class WindowsAppProcesses:
    def __init__(self, *, port=8501, legacy_proof=None):
        if sys.platform!='win32' or type(port) is not int or not 1<=port<=65535:
            raise InstallBlocked('Windows 앱 전환 환경 또는 포트를 확인하세요.')
        self.port=port
        self.base=_path(sys._base_executable)
        self.legacy_proof=legacy_proof
        if legacy_proof is not None:
            bound=Path(legacy_proof['root']).resolve()
            if (legacy_proof.get('origin')!='OBSERVED_LOCAL_APP_UI_AND_KERNEL'
                    or _path(legacy_proof.get('observed_control_root',''))!=_path(bound.parent/'control')
                    or legacy_proof.get('source_version')!=(bound/'VERSION').read_text(encoding='utf-8-sig').strip()
                    or legacy_proof.get('source_manifest_sha256')!=hashlib.sha256((bound/'manifest_sha256.json').read_bytes()).hexdigest()):
                raise InstallBlocked('기존 앱의 화면·운영 폴더 확인 근거가 현재 파일과 일치하지 않습니다.')
            for process in legacy_proof['processes']:
                args=process['argv'][1:]
                if args and args[0]=='-B':args=args[1:]
                options=['--server.address=127.0.0.1',f'--server.port={port}','--server.headless=true']
                if args not in (['-m','streamlit','run','app.py'],['-m','streamlit','run','app.py']+options):
                    raise InstallBlocked('기존 앱의 표준 실행 인자가 아닙니다.')
        self.k=ctypes.WinDLL('kernel32',use_last_error=True)
        self.k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        self.k.OpenProcess.restype=wintypes.HANDLE
        self.k.CloseHandle.argtypes=[wintypes.HANDLE]
        self.k.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
        self.k.GetProcessTimes.restype=wintypes.BOOL
        self.k.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
        self.k.QueryFullProcessImageNameW.restype=wintypes.BOOL
        self.k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]
        self.k.WaitForSingleObject.restype=wintypes.DWORD
        self.k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT]
        self.k.TerminateProcess.restype=wintypes.BOOL

    def expected(self,root):
        python=str(Path(root).resolve()/'.venv/Scripts/python.exe')
        return [python,'-B','-m','streamlit','run',str(Path(root).resolve()/'app.py'),'--server.address=127.0.0.1',f'--server.port={self.port}','--server.headless=true']

    def _argv(self,command):
        shell=ctypes.WinDLL('shell32',use_last_error=True)
        shell.CommandLineToArgvW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_int)]
        shell.CommandLineToArgvW.restype=ctypes.POINTER(wintypes.LPWSTR)
        count=ctypes.c_int();values=shell.CommandLineToArgvW(command,ctypes.byref(count))
        if not values:raise InstallBlocked('앱 실행 인자를 확인하지 못했습니다.')
        self.k.LocalFree.argtypes=[wintypes.HLOCAL];self.k.LocalFree.restype=wintypes.HLOCAL
        try:return [values[i] for i in range(count.value)]
        finally:self.k.LocalFree(values)

    def _records(self,pid=None):
        query=(f'ProcessId={int(pid)}' if pid is not None else "Name='python.exe' OR Name='pythonw.exe'")
        script=f"$ErrorActionPreference='Stop'; @(Get-CimInstance Win32_Process -Filter \"{query}\" | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine) | ConvertTo-Json -Compress"
        try:
            p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,text=True,encoding='utf-8',timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
            if p.returncode:raise InstallBlocked('실행 중인 앱 목록을 확인하지 못했습니다.')
            rows=json.loads(p.stdout.strip() or '[]')
        except (subprocess.SubprocessError,ValueError,OSError):
            raise InstallBlocked('실행 중인 앱 목록을 확인하지 못했습니다.') from None
        return [rows] if isinstance(rows,dict) else rows

    @contextmanager
    def _handle(self,pid,*,terminate=False):
        if type(pid) is not int or pid<=0:raise InstallBlocked('앱 프로세스 번호가 잘못됐습니다.')
        h=self.k.OpenProcess(0x1000|0x100000|(1 if terminate else 0),False,pid)
        if not h:
            if ctypes.get_last_error()==87:
                yield None;return
            raise InstallBlocked('앱 프로세스 접근을 확인하지 못했습니다.')
        try:
            alive=self.k.WaitForSingleObject(h,0)
            if alive==0:
                yield None;return
            if alive!=258:raise InstallBlocked('앱 종료 상태를 확인하지 못했습니다.')
            times=[wintypes.FILETIME() for _ in range(4)]
            if not self.k.GetProcessTimes(h,*[ctypes.byref(t) for t in times]):
                if self.k.WaitForSingleObject(h,0)==0:
                    yield None;return
                raise InstallBlocked('앱 시작 시각을 확인하지 못했습니다.')
            size=wintypes.DWORD(32768);buffer=ctypes.create_unicode_buffer(size.value)
            if not self.k.QueryFullProcessImageNameW(h,0,buffer,ctypes.byref(size)):
                if self.k.WaitForSingleObject(h,0)==0:
                    yield None;return
                raise InstallBlocked('앱 실행파일을 확인하지 못했습니다.')
            yield dict(handle=h,born=(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime,image=_path(buffer.value))
        finally:self.k.CloseHandle(h)

    def inventory(self,root):
        expected=self.expected(root);selected=[]
        for row in self._records():
            command=row.get('CommandLine') or ''
            if 'streamlit' not in command.lower() or 'app.py' not in command.lower():continue
            argv=self._argv(command)
            actual_module=any(argv[i:i+2]==['-m','streamlit'] for i in range(len(argv)-1))
            actual_cli=any(Path(a).name.lower() in {'streamlit.exe','streamlit-script.py'} for a in argv[:2])
            if not actual_module and not actual_cli:
                continue  # A Python -c source string is not an app launch.
            legacy=None
            if self.legacy_proof and _path(self.legacy_proof['root'])==_path(root):
                legacy=next((p for p in self.legacy_proof['processes'] if p['pid']==int(row['ProcessId'])),None)
            # A different absolute virtual environment is a different app.
            if argv and Path(argv[0]).is_absolute() and _path(argv[0]) not in {_path(expected[0]),self.base}:
                continue
            if argv and _path(argv[0])==self.base:
                script_args=[a for a in argv if a.lower().endswith('app.py')]
                if script_args and Path(script_args[0]).is_absolute() and _path(script_args[0])!=_path(Path(root)/'app.py'):continue
            if argv!=expected and (legacy is None or argv!=legacy['argv']):
                raise InstallBlocked('앱 실행 위치·인자가 불명확합니다. 직접 종료 후 다시 검사하세요.')
            pid=int(row['ProcessId'])
            with self._handle(pid) as owned:
                if owned is None:continue
                if legacy is not None and (owned['born']!=legacy['born'] or owned['image']!=legacy['image']):
                    raise InstallBlocked('기존 앱 확인 이후 프로세스가 변경되었습니다.')
                # Hold the kernel object while re-reading argv; reject a stale CIM row.
                fresh=self._records(pid)
                if len(fresh)!=1 or self._argv(fresh[0].get('CommandLine') or '')!=argv:
                    raise InstallBlocked('앱 프로세스 정보가 변경되었습니다.')
                parent=int(fresh[0]['ParentProcessId'])
                if legacy is not None and parent!=legacy['parent']:
                    raise InstallBlocked('기존 앱 부모가 변경되었습니다.')
                selected.append(dict(pid=pid,parent=parent,born=owned['born'],image=owned['image'],argv=argv,legacy=legacy is not None))
        return selected

    def validate(self,root,process,selected):
        expected=self.expected(root);allowed={_path(expected[0]),self.base}
        legacy=next((p for p in (self.legacy_proof or {}).get('processes',[]) if p['pid']==process['pid']),None)
        valid_legacy=(legacy is not None and _path(self.legacy_proof['root'])==_path(root)
                      and all(process[k]==legacy[k] for k in ('pid','parent','born','image','argv')))
        if process['pid']==os.getpid() or (process['argv']!=expected and not valid_legacy) or process['image'] not in allowed:
            raise InstallBlocked('종료할 앱의 실행 근거가 일치하지 않습니다.')
        if process['image']==self.base:
            parent=next((p for p in selected if p['pid']==process['parent']),None)
            if not parent or parent['image']!=_path(expected[0]) or parent['born']>process['born']:
                raise InstallBlocked('앱 부모 프로세스를 확인하지 못했습니다.')

    def stop(self,process):
        if process['pid']==os.getpid():raise InstallBlocked('설치 도구 자신은 종료할 수 없습니다.')
        with self._handle(process['pid'],terminate=True) as owned:
            if owned is None:return
            if owned['born']!=process['born'] or owned['image']!=process['image']:
                raise InstallBlocked('프로세스 번호가 재사용됐거나 실행파일이 변경되었습니다.')
            fresh=self._records(process['pid'])
            if self.k.WaitForSingleObject(owned['handle'],0)==0:
                return  # The known launcher can exit naturally after its child.
            if len(fresh)!=1 or self._argv(fresh[0].get('CommandLine') or '')!=process['argv']:
                raise InstallBlocked('종료 직전 앱 인자가 변경되었습니다.')
            if not self.k.TerminateProcess(owned['handle'],0):raise InstallBlocked('앱 종료가 거부됐습니다.')
            if self.k.WaitForSingleObject(owned['handle'],5000)!=0:raise InstallBlocked('앱 종료를 확인하지 못했습니다.')

    def start(self,root):
        with socket.socket() as check:
            check.settimeout(.5)
            if check.connect_ex(('127.0.0.1',self.port))==0:
                raise InstallBlocked('기존 포트 사용이 확인되어 중복 시작하지 않습니다.')
        p=subprocess.Popen(self.expected(root),cwd=root,creationflags=subprocess.CREATE_NO_WINDOW,
                           stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return dict(launcher_pid=p.pid,port=self.port,final_health_check='NOT_RUN')
