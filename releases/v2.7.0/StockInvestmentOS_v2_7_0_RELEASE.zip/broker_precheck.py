"""Explicit order precheck UI without an order journal or send controls."""
from datetime import datetime, timezone
import streamlit as st

from broker_inquiries import format_time
from broker_precheck_service import run_precheck
from broker_session_status import render as render_session_status


def clear_precheck():
    for key in list(st.session_state):
        if key.startswith(('_kis_precheck', 'kis_pc_')):
            st.session_state.pop(key, None)


def render(client):
    st.subheader('주문 전 점검')
    mode = client.credentials.mode
    st.info(('실전투자 (LIVE)' if mode == 'LIVE' else '모의투자 (PAPER)')
            + ' · 조회만 수행 · 주문 전송 없음')
    st.caption('입력한 주문 조건의 금액·가정 손실·시세·현금 또는 보유 수량을 확인합니다. '
               '주문 준비 기록을 만들지 않으며, 주문 중지 상태·미확인 주문·거래시간·호가 규칙·체결 가능 여부는 이 화면의 통과 판정에 포함되지 않습니다.')
    account_context = (client.credentials.identity, mode)
    if st.session_state.get('_kis_precheck_account') != account_context:
        clear_precheck()
        st.session_state['_kis_precheck_account'] = account_context
    market = st.selectbox('점검 시장', ['KR', 'US'],
        format_func=lambda v: '국내 주식·ETF' if v == 'KR' else '미국 주식·ETF', key='kis_pc_market')
    exchange = st.selectbox('점검 거래소', ['KRX'] if market == 'KR' else ['NASD', 'NYSE', 'AMEX'],
                            key='kis_pc_exchange_' + market)
    render_session_status(client, market)
    side = st.radio('점검 방향', ['BUY', 'SELL'],
        format_func=lambda v: '매수' if v == 'BUY' else '매도', key='kis_pc_side', horizontal=True, index=None)
    st.caption('방향·시장을 먼저 선택한 뒤 숫자를 입력하세요. 화면을 떠나면 점검 입력은 초기화됩니다.')
    if side is None: st.info('매수 또는 매도를 직접 선택해 주세요.')
    else: st.info('선택한 점검 방향: ' + ('매수' if side == 'BUY' else '매도'))
    selection = (market, exchange, side)
    if st.session_state.get('_kis_precheck_selection') != selection:
        st.session_state.pop('_kis_precheck_result', None)
        st.session_state['kis_pc_attested'] = False
        st.session_state['_kis_precheck_selection'] = selection
    currency = 'KRW' if market == 'KR' else 'USD'
    with st.form('kis_precheck', enter_to_submit=False):
        st.caption('숫자 입력 예: 263000 / 1850205 / 0.5. 쉼표·원·% 기호를 넣지 마세요.')
        symbol = st.text_input('점검 종목코드', key='kis_pc_symbol_' + market,
                               placeholder='6자리 코드' if market == 'KR' else '티커')
        quantity = st.number_input('점검 수량 (주)', min_value=1, max_value=1000000,
                                    value=1, step=1, key='kis_pc_quantity')
        price = st.text_input('점검 지정가 (' + currency + ')', value='0', key='kis_pc_price_' + market)
        cap = st.text_input('금액 상한 (' + currency + ')', value='0', key='kis_pc_cap_' + market)
        fee = st.text_input('비용 여유율 (%)', value='0.5', key='kis_pc_fee')
        gap = st.text_input('조회 가격과 지정가 차이 한도 (%)', value='3', key='kis_pc_gap')
        downside = st.text_input('하락 가정 (%)', value='0', key='kis_pc_downside', disabled=side == 'SELL')
        loss = st.text_input('가정 손실 예산 (' + currency + ')', value='0',
                             key='kis_pc_loss_' + market, disabled=side == 'SELL')
        st.caption('가정 손실 = 지정가 × 수량 × 하락 가정 + 비용 여유. 실제 손실의 상한이나 손절 주문이 아닙니다. '
                   '미국 점검은 USD 기준이며 자동 환전하지 않습니다.')
        attested = st.checkbox('입력한 종목·가격·수량·상한과 손실 가정을 확인했습니다', key='kis_pc_attested')
        submitted = st.form_submit_button('입력·조회 점검만 실행', disabled=side is None)
    order = dict(market=market, exchange=exchange, symbol=symbol, side=side,
                 quantity=quantity, limit_price=price)
    limits = dict(max_notional=cap, fee_buffer_pct=fee, max_quote_gap_pct=gap,
                  downside_pct=downside, max_scenario_loss=loss, risk_attested=attested)
    context = (account_context, tuple(order.items()), tuple(limits.items()))
    if st.session_state.get('_kis_precheck_context') != context:
        st.session_state.pop('_kis_precheck_result', None)
        st.session_state['_kis_precheck_context'] = context
    if submitted:
        st.session_state.pop('_kis_precheck_result', None)
        with st.spinner('입력 조건과 증권사 조회값을 점검하고 있습니다…'):
            st.session_state['_kis_precheck_result'] = run_precheck(client, order, limits)
    result = st.session_state.get('_kis_precheck_result')
    if result is None:
        return
    st.caption('마지막으로 점검 버튼을 눌렀을 때의 기록입니다. 입력란을 편집한 뒤에는 다시 점검하세요.')
    st.caption(f"점검: {format_time(result['checked_at'])} · {result['elapsed_ms']}ms")
    if result['status'] != 'PASS':
        st.error(result['message'])
        with st.expander('점검 진단'):
            st.write({'환경': mode, '단계': result['stage'], **result['diagnostic']})
        return
    checked = result['order']; snapshot = result['snapshot']
    age = (datetime.now(timezone.utc) - datetime.fromisoformat(result['checked_at'])).total_seconds()
    if 0 <= age <= 60:
        st.success('입력·조회 점검 통과 (점검 당시)')
    else:
        st.warning('이전 점검 기록입니다. 현재 상태를 확인하려면 다시 점검하세요.')
    st.table([{'환경': '실전투자 (LIVE)' if mode == 'LIVE' else '모의투자 (PAPER)',
               '시장': '국내' if checked['market'] == 'KR' else '미국',
               '거래소': checked['exchange'], '종목': checked['symbol'],
               '방향': '매수' if checked['side'] == 'BUY' else '매도',
               '수량': checked['quantity'], '지정가': checked['limit_price'], '통화': checked['currency']}])
    st.write(f"증권사 조회 가격: {snapshot['quote']['price']} {currency}")
    st.caption('시세 조회: ' + format_time(snapshot['quote']['fetched_at']))
    st.write(f"비용 여유 포함 금액: {snapshot['estimated_cost']} {currency}")
    if checked['side'] == 'BUY':
        st.write(f"가정 손실: {snapshot['scenario_loss']} {currency}")
        st.write(f"조회된 주문 가능금액: {snapshot['availability']['cash']} {currency}")
    st.write(f"조회된 {'매수' if checked['side'] == 'BUY' else '매도'} 가능 수량: {snapshot['availability']['quantity']}주")
    st.info('점검 통과는 주문 허용이나 체결 보장이 아닙니다. 주문하려면 주문·체결 관리에서 별도로 준비하고 확인해야 합니다.')
