"""Read-only Streamlit panel for the last explicit local operation batch."""
from pathlib import Path
import streamlit as st
from updater.operations_report import load_view, export_view, APPLY_LABELS


def render(root, *, key, expanded=False):
    view = load_view(root)
    label = {'SAVED_PASS':'통과 기록', 'BLOCKED':'실패 항목 확인', 'REVIEW':'버전·시각 확인',
        'MISSING':'기록 없음', 'INVALID':'기록 확인 필요', 'UNAVAILABLE':'경로 확인 필요'}[view['display_status']]
    with st.expander('최근 로컬 운영 점검 · ' + label, expanded=expanded):
        st.button('저장된 결과 새로 읽기', key=key + '_refresh')
        st.caption('저장된 결과를 읽습니다. 새 점검·설치·복구 연습을 실행하는 버튼은 아닙니다.')
        show = st.success if view['display_status'] == 'SAVED_PASS' else (
            st.error if view['display_status'] == 'BLOCKED' else st.info if view['display_status'] == 'MISSING' else st.warning)
        show(view['message'])
        report = view['report']
        if report:
            st.caption('점검 시각: ' + view['report_time_kst'])
            st.caption('현재 앱: ' + view['running_version'] + ' · 기록의 버전: ' + (report['current_version'] or '미확인'))
            st.caption(('설치 후 점검' if report['mode'] == 'INSTALL' else '운영 점검') + ' · ' + APPLY_LABELS[report['apply_status']])
            if report.get('recovery_point_version'): st.caption('기록의 복구 대상 버전: ' + report['recovery_point_version'])
            for notice in view['notices']: st.warning(notice)
            st.table(view['rows'])
            st.download_button('운영 점검 결과 저장', data=export_view(view),
                file_name='StockInvestmentOS_operations_summary.json', mime='application/json',
                key=key + '_download', on_click='ignore')
            st.caption('저장 파일에는 점검 상태·버전·시각만 담습니다. 로컬 경로·계좌·잔고·원문 오류는 담지 않습니다.')
        st.info('다음 조치: ' + view['next_action'])
        st.caption('점검 당시의 로컬 소프트웨어 기록입니다. 현재 상태의 재검사, 공개 배포 확인, 증권사 연결·주문·체결 확인을 뜻하지 않습니다.')
        with st.expander('새 운영 점검이 필요할 때 · PowerShell 명령'):
            quoted = str(Path(root).resolve()).replace("'", "''")
            st.code("Set-Location -LiteralPath '" + quoted + "'\n& '.\\.venv\\Scripts\\python.exe' -m updater.operator_batch --root . --drill", language='powershell')
