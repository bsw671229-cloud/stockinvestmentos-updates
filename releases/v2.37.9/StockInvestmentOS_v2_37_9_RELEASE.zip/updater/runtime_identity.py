"""Read-only evidence that this app process started after installation.

Disk VERSION, a rerun, or a cleared restart flag is not process evidence.
No environment secrets, portfolio data, remote requests or process control.
"""
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys

from migration.work_ready_paths import resolve_control_root


@lru_cache(maxsize=4)
def _process_start(pid):
    if pid != os.getpid():
        return None
    try:
        if sys.platform == 'win32':
            import ctypes
            from ctypes import wintypes
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.GetCurrentProcess.restype = wintypes.HANDLE
            kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
            kernel.GetProcessTimes.restype = wintypes.BOOL
            created, exited, kernel_time, user_time = (wintypes.FILETIME() for _ in range(4))
            if not kernel.GetProcessTimes(kernel.GetCurrentProcess(), ctypes.byref(created),
                                          ctypes.byref(exited), ctypes.byref(kernel_time), ctypes.byref(user_time)):
                return None
            return ((created.dwHighDateTime << 32) | created.dwLowDateTime) / 10_000_000 - 11_644_473_600
        if sys.platform.startswith('linux'):
            stat = Path('/proc/self/stat').read_text()
            ticks = int(stat[stat.rfind(')') + 2:].split()[19])
            boot = next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines()
                        if line.startswith('btime '))
            return boot + ticks / os.sysconf('SC_CLK_TCK')
    except (OSError, ValueError, IndexError, StopIteration, AttributeError):
        pass
    return None


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@lru_cache(maxsize=16)
def _capture(root_text, pid):
    root = Path(root_text)
    result = {'root': root_text, 'pid': pid, 'process_started_at': _process_start(pid),
              'captured_at': datetime.now(timezone.utc).timestamp()}
    try:
        result.update(loaded_version=(root / 'VERSION').read_text(encoding='utf-8-sig').strip(),
                      loaded_manifest_sha256=_sha(root / 'manifest_sha256.json'))
    except (OSError, UnicodeError):
        result.update(loaded_version='', loaded_manifest_sha256='')
    return result


def capture_runtime_identity(root):
    """Capture once per process/root, independent of browser/session/rerun."""
    return dict(_capture(str(Path(root).resolve()), os.getpid()))


def _timestamp(value):
    parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Installation time must include timezone')
    return parsed.timestamp()


def restart_status(root, runtime_identity=None):
    root = Path(root).resolve()
    result = {'status': 'CHECK_REQUIRED', 'eligible': False, 'restart_required': True,
              'blockers': [], 'execution_authorization': 'NONE'}

    def block(code, message, status='CHECK_REQUIRED'):
        return {**result, 'status': status, 'reason': code, 'blockers': [message]}

    if not isinstance(runtime_identity, dict) or not runtime_identity:
        return block('MISSING_RUNTIME', '실행 중인 앱의 재시작 근거가 없습니다. 앱 화면에서 최종 점검을 실행하세요.')
    actual = capture_runtime_identity(root)
    if runtime_identity != actual:
        return block('RUNTIME_IDENTITY_MISMATCH', '다른 프로세스·폴더의 실행 근거입니다. 올바른 프로그램을 다시 실행하세요.')
    born = actual.get('process_started_at')
    captured = actual.get('captured_at')
    if (not isinstance(born, (int, float)) or isinstance(born, bool) or not math.isfinite(born)
            or born <= 0 or born > captured):
        return block('PROCESS_TIME_UNAVAILABLE', '실제 프로그램 시작 시각을 확인하지 못했습니다. 재시작 확인이 필요합니다.')
    result.update(pid=actual['pid'], process_started_at=datetime.fromtimestamp(born, timezone.utc).isoformat(),
                  loaded_version=actual['loaded_version'])
    try:
        current = (root / 'VERSION').read_text(encoding='utf-8-sig').strip()
        result['installed_version'] = current
        if current != actual['loaded_version'] or _sha(root / 'manifest_sha256.json') != actual['loaded_manifest_sha256']:
            return block('LOADED_RELEASE_CHANGED', '실행 후 설치 파일이 바뀌었습니다. 프로그램을 완전히 종료하고 다시 실행하세요.', 'RESTART_REQUIRED')
        logs = resolve_control_root(root) / 'update_logs'
        state = json.loads((logs / 'update_state.json').read_text(encoding='utf-8'))
        txid = state.get('last_transaction', '')
        if not isinstance(txid, str) or not re.fullmatch(r'UPD-[A-Za-z0-9-]+', txid):
            return block('INSTALL_TRANSACTION_UNVERIFIED', '확인 가능한 설치 기록이 없습니다. 설치 기록을 점검하세요.')
        journal = json.loads((logs / (txid + '.json')).read_text(encoding='utf-8'))
        if (state.get('status') != 'APPLIED' or journal.get('status') != 'APPLIED'
                or journal.get('txid') != txid or journal.get('post_apply_verification') != 'PASS'
                or state.get('current_version') != current or journal.get('target_version') != current):
            return block('INSTALL_LINEAGE_MISMATCH', '설치 버전과 완료 기록이 일치하지 않습니다. 설치 기록을 점검하세요.')
        finished = _timestamp(journal['finished_at'])
        if not math.isfinite(finished) or finished <= 0:
            raise ValueError('Invalid installation time')
        result.update(installation_transaction=txid, installed_at=journal['finished_at'])
    except (OSError, ValueError, TypeError, KeyError, AttributeError, UnicodeError):
        return block('INSTALL_EVIDENCE_UNAVAILABLE', '설치 완료 시각 또는 기록을 확인하지 못했습니다. 재시작 확인이 필요합니다.')
    # OS time can be sub-microsecond; the persisted ISO timestamp is microsecond.
    # Require separation beyond that rounding interval before acknowledging restart.
    if born <= finished + 0.000001:
        return block('PROCESS_PREDATES_INSTALL', '설치 전부터 실행 중인 프로그램입니다. 완전히 종료한 뒤 다시 실행하세요. 브라우저 새로고침만으로는 완료되지 않습니다.', 'RESTART_REQUIRED')
    return {**result, 'status': 'PASS', 'eligible': True, 'restart_required': False, 'reason': 'PROCESS_STARTED_AFTER_INSTALL'}


def guarded_finalize(root, runtime_identity, finalizer):
    """Protect the first upgrade even while an old finalizer remains imported."""
    gate = restart_status(root, runtime_identity)
    if not gate['eligible']:
        return {'status': 'FINAL_REVIEW', 'stage': 'RESTART_GATE', 'runtime_restart': gate,
                'operations_pass': False, 'recovery_pass': False,
                'checks_executed': False, 'blockers': gate['blockers'],
                'auto_approval': False, 'auto_apply': False, 'execution_authorization': 'NONE'}
    return finalizer(root, runtime_identity=runtime_identity)
