"""Bounded, read-only projection of a saved local operations report.

No updater imports, network, credential/data access, hashing of release ZIPs or writes.
A saved PASS is historical evidence, never a fresh execution/approval gate.
"""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import re
import stat

MAX_BYTES = 65536
MAX_AGE_SECONDS = 86400
KST = timezone(timedelta(hours=9))
VERSION_RE = re.compile(r'v\d{1,4}\.\d{1,4}\.\d{1,4}\Z')
CHECKS = {
    'python_streamlit': ('앱 실행 환경', '앱 폴더의 .venv와 Streamlit 설치 상태를 확인하세요.'),
    'managed_code': ('관리 파일 무결성', '변경·누락된 관리 파일을 확인하세요. 강제 덮어쓰기로 통과시키지 마세요.'),
    'version': ('실행 버전', '현재 버전에 맞는 설치 묶음을 사용하세요.'),
    'package_binding': ('설치 파일·검증 보고서', '같은 설치 묶음의 ZIP과 검증 보고서를 사용하고 SHA-256을 확인하세요.'),
    'install_preview': ('설치 사전 점검', '업데이트 설치 화면의 선택 패키지 Preview에서 차단 사유를 확인하세요.'),
    'install_approval': ('설치 파일 승인', '검증 보고서와 SHA-256이 해당 패키지와 일치하는지 확인하세요.'),
    'install_apply': ('설치 적용', '설치 결과를 확인하고 앱 버전·무결성을 점검하세요. 반복 설치 전에 실패 원인을 확인하세요.'),
    'installed_integrity': ('설치 후 버전·무결성', '설치된 버전과 관리 파일을 확인하세요. 후속 점검 실패만으로 다시 덮어쓰지 마세요.'),
    'installed_target_identity': ('기존 설치본 일치', '같은 버전이라도 배포 파일이 일치하는지 확인하세요.'),
    'recovery_drill': ('복구 연습', '백업 상태와 비변경 복구 연습 결과를 확인하세요. 실제 롤백은 별도 결정입니다.'),
    'recovery_readiness': ('백업·복구 준비', '최신 백업의 버전 연결과 복구 연습 기록을 확인하세요.'),
    'batch_exception': ('점검 실행 오류', '앱·control 경로와 파일 권한을 확인하고 운영 결과를 저장해 전달하세요.'),
}
DETAILS = {
    'APP_VENV_REQUIRED': '시스템 Python이 사용되었거나 앱 가상환경을 확인하지 못했습니다.',
    'STREAMLIT_IMPORT_FAILED': '앱 가상환경에서 Streamlit을 불러오지 못했습니다.',
    'STREAMLIT_IMPORT_FAILED_OR_TIMEOUT': 'Streamlit 확인이 실패했거나 제한 시간을 넘었습니다.',
    'MANAGED_CODE_DRIFT_OR_EMPTY_MANIFEST': '관리 파일 변경·누락 또는 비어 있는 관리 목록이 있습니다.',
    'UNEXPECTED_VERSION': '운영 도구가 지원하는 버전과 현재 버전이 다릅니다.',
    'PACKAGE_REPORT_OR_SHA_MISMATCH': '설치 파일·검증 보고서·SHA-256을 함께 확인하지 못했습니다.',
    'PREVIEW_BLOCKED': '설치 사전 점검에서 차단되었습니다.',
    'TARGET_MANIFEST_MISMATCH': '이미 설치된 버전의 파일 목록이 배포본과 다릅니다.',
    'POST_INSTALL_CHECK_FAILED': '설치 후 대상 버전 또는 파일 무결성 확인이 실패했습니다.',
    'ROLLED_BACK': '설치가 실패하여 해당 설치 이전 상태로 자동 복원되었습니다.',
    'FAILED': '작업이 실패했습니다. 복원 완료 여부도 확인해야 합니다.',
    'BLOCKED': '필수 조건을 충족하지 못해 작업이 중단되었습니다.',
    'REVIEW': '백업과 현재 버전의 연결 또는 복구 연습 기록에 확인할 항목이 있습니다.',
    'RECOVERY_DRILL_FAIL': '비변경 복구 연습을 통과하지 못했습니다.',
}
PASS_DETAILS = {'APP_VENV_STREAMLIT_IMPORT_PASS', 'MANAGED_HASHES_PASS',
    'EXACT_PACKAGE_REPORT_SHA_PASS', 'ELIGIBLE', 'APPROVED', 'APPLIED',
    'TARGET_VERSION_AND_HASHES_PASS', 'EXACT_TARGET_MANIFEST', 'RECOVERY_DRILL_PASS', 'PASS'}
EXPECTED_PASS = dict(zip(
    ('python_streamlit', 'managed_code', 'package_binding', 'install_preview', 'install_approval',
     'install_apply', 'installed_integrity', 'installed_target_identity', 'recovery_drill', 'recovery_readiness'),
    ('APP_VENV_STREAMLIT_IMPORT_PASS', 'MANAGED_HASHES_PASS', 'EXACT_PACKAGE_REPORT_SHA_PASS', 'ELIGIBLE',
     'APPROVED', 'APPLIED', 'TARGET_VERSION_AND_HASHES_PASS', 'EXACT_TARGET_MANIFEST', 'RECOVERY_DRILL_PASS', 'PASS')))
APPLY_LABELS = {'NOT_REQUESTED': '설치 적용 없음', 'APPLIED': '설치 적용됨',
    'ALREADY_INSTALLED': '이미 설치된 동일 버전 확인', 'BLOCKED': '설치 중단',
    'ROLLED_BACK': '설치 실패 후 자동 복원', 'FAILED': '설치·복원 결과 확인 필요', 'UNKNOWN': '설치 결과 미확인'}


def _version(value, nullable=False):
    if nullable and value is None: return None
    if not isinstance(value, str) or not VERSION_RE.fullmatch(value):
        raise ValueError('VERSION_FORMAT')
    return value


def _time(value):
    if not isinstance(value, str) or len(value) > 40: raise ValueError('TIMESTAMP_FORMAT')
    stamp = datetime.fromisoformat(value)
    if stamp.utcoffset() is None: raise ValueError('TIMEZONE_REQUIRED')
    return stamp.astimezone(timezone.utc)


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError('DUPLICATE_FIELD')
        result[key] = value
    return result


def _no_constants(value):
    raise ValueError('NONFINITE_NUMBER')


def _read(path, limit):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
        raise ValueError('LINK_NOT_ALLOWED')
    if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
        raise ValueError('FILE_TYPE_OR_SIZE')
    with path.open('rb') as handle:
        data = handle.read(limit + 1)
    if len(data) > limit: raise ValueError('FILE_SIZE')
    return data.decode('utf-8-sig')


def _json(text):
    return json.loads(text, object_pairs_hook=_unique, parse_constant=_no_constants)


def sanitize_report(raw):
    """Validate coherent PASS branches; export only recognized, bounded metadata."""
    if not isinstance(raw, dict) or type(raw.get('schema_version')) is not int or raw['schema_version'] != 1:
        raise ValueError('SCHEMA')
    mode, status = raw.get('mode'), raw.get('status')
    if mode not in ('CHECK', 'INSTALL') or status not in ('LOCAL_CHECK_PASS', 'LOCAL_INSTALL_CHECK_PASS', 'BLOCKED'):
        raise ValueError('STATUS')
    if raw.get('execution_authorization') != 'NONE': raise ValueError('AUTHORIZATION')
    if any(raw.get(key) != value for key, value in {'broker_access':'NOT_PERFORMED',
            'public_feed':'NOT_VERIFIED', 'browser_ui':'NOT_VERIFIED'}.items()):
        raise ValueError('SCOPE')
    current = _version(raw.get('current_version'), nullable=True)
    target = _version(raw.get('target_version'), nullable=True)
    stamp = _time(raw.get('created_at'))
    applied = raw.get('apply_status')
    changed = raw.get('live_code_applied')
    if applied not in APPLY_LABELS or type(changed) is not bool or changed != (applied == 'APPLIED'):
        raise ValueError('APPLY_STATE')
    checks = raw.get('checks')
    if not isinstance(checks, list) or not 1 <= len(checks) <= len(CHECKS): raise ValueError('CHECK_COUNT')
    clean_checks, seen = [], set()
    for row in checks:
        if not isinstance(row, dict): raise ValueError('CHECK_TYPE')
        name, state = row.get('name'), row.get('status')
        if not isinstance(name, str) or name not in CHECKS or name in seen or state not in ('PASS', 'FAIL'):
            raise ValueError('CHECK_CONTENT')
        seen.add(name)
        detail = row.get('detail')
        if state == 'PASS':
            if name == 'version': _version(detail)
            elif name not in EXPECTED_PASS or detail != EXPECTED_PASS[name]: raise ValueError('CONTRADICTORY_PASS_DETAIL')
        safe_detail = detail if isinstance(detail, str) and (
            detail in DETAILS or detail in PASS_DETAILS or VERSION_RE.fullmatch(detail)) else 'UNRECOGNIZED_DETAIL'
        clean_checks.append(dict(name=name, status=state, detail=safe_detail))
    if status != 'BLOCKED':
        required = {'python_streamlit', 'managed_code', 'version', 'recovery_readiness'}
        if mode == 'CHECK':
            if status != 'LOCAL_CHECK_PASS' or applied != 'NOT_REQUESTED': raise ValueError('CHECK_PASS_STATE')
            if target is not None and target != current: raise ValueError('CHECK_TARGET')
            if any(name.startswith('install') or name == 'package_binding' for name in seen): raise ValueError('CHECK_INSTALL_MIX')
        else:
            if status != 'LOCAL_INSTALL_CHECK_PASS' or current != target or target is None:
                raise ValueError('INSTALL_PASS_VERSION')
            required |= {'package_binding', 'recovery_drill'}
            if applied == 'APPLIED':
                required |= {'install_preview', 'install_approval', 'install_apply', 'installed_integrity'}
                if 'installed_target_identity' in seen: raise ValueError('INSTALL_BRANCH_MIX')
            elif applied == 'ALREADY_INSTALLED':
                required.add('installed_target_identity')
                if seen & {'install_preview','install_approval','install_apply','installed_integrity'}: raise ValueError('INSTALL_BRANCH_MIX')
            else: raise ValueError('INSTALL_PASS_STATE')
        if current is None or not required <= seen or any(row['status'] != 'PASS' for row in clean_checks):
            raise ValueError('INCOMPLETE_PASS')
    elif not any(row['status'] == 'FAIL' for row in clean_checks):
        raise ValueError('BLOCKED_WITHOUT_FAILURE')
    clean = dict(schema_version=1, created_at=stamp.isoformat(), mode=mode, status=status,
        current_version=current, target_version=target, apply_status=applied,
        live_code_applied=changed, checks=clean_checks, execution_authorization='NONE',
        broker_access='NOT_PERFORMED', public_feed='NOT_VERIFIED', browser_ui='NOT_VERIFIED')
    point = raw.get('recovery_point_version')
    if isinstance(point, str) and VERSION_RE.fullmatch(point): clean['recovery_point_version'] = point
    return clean


def _empty(code, message, action):
    return dict(display_status=code, message=message, next_action=action, report=None,
        rows=[], notices=[], running_version=None, observed_at=None, report_time_kst=None)


def load_view(root, now=None):
    """Read only VERSION, separated layout and the one fixed operations JSON file."""
    root = Path(root).resolve()
    try:
        if root.name.lower() != 'app' or root.parent.name.lower() != 'work': raise ValueError('LAYOUT')
        current = _version(_read(root / 'VERSION', 64).strip())
        layout = _json(_read(root / 'WORK_READY_LAYOUT.json', 16384))
        if not isinstance(layout, dict) or type(layout.get('schema_version')) is not int or layout.get('schema_version') != 1 or layout.get('mode') != 'WORK_READY_SEPARATED':
            raise ValueError('LAYOUT')
        control = root.parent / 'control'
        rel = layout.get('control_rel')
        if not isinstance(rel, str) or (root / rel).resolve() != control:
            raise ValueError('CONTROL_PATH')
        for path in (control, control / 'update_logs'):
            info = path.lstat()
            if not stat.S_ISDIR(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                raise ValueError('LINK_OR_DIRECTORY')
    except (OSError, ValueError, TypeError, OverflowError, RecursionError):
        return _empty('UNAVAILABLE', '운영 기록 위치를 확인할 수 없습니다.', '현재 work/app과 분리된 control 폴더의 설정·권한을 확인하세요.')
    try:
        report = sanitize_report(_json(_read(control / 'update_logs/operations_latest.json', MAX_BYTES)))
    except FileNotFoundError:
        return _empty('MISSING', '아직 저장된 일괄 운영 점검 결과가 없습니다.', '현재 설치 묶음의 Check 모드로 운영 점검을 실행하세요.')
    except (OSError, ValueError, TypeError, KeyError, OverflowError, RecursionError):
        return _empty('INVALID', '운영 기록의 형식이나 항목을 확인할 수 없습니다.', '기록을 임의로 수정하지 말고 운영 점검을 다시 실행해 새 결과를 저장하세요.')
    try:
        observed = now or datetime.now(timezone.utc)
        if observed.utcoffset() is None: raise ValueError('CLOCK')
        age = (observed - _time(report['created_at'])).total_seconds()
    except (ValueError, TypeError, OverflowError):
        return _empty('INVALID', '점검 시각을 확인할 수 없습니다.', 'PC의 날짜·시간·시간대를 확인하세요.')
    notices = []
    if age < 0: notices.append('기록 시각이 현재보다 미래입니다. PC의 날짜·시간·시간대를 확인하세요.')
    elif age >= MAX_AGE_SECONDS: notices.append('24시간 이상 지난 기록입니다. 현재 상태는 새 운영 점검으로 확인하세요.')
    if report['current_version'] != current: notices.append('현재 앱 버전과 다른 버전에서 만든 기록입니다. 현재 버전으로 다시 점검하세요.')
    if report['status'] == 'BLOCKED':
        code, message = 'BLOCKED', '저장된 운영 점검에 실패한 항목이 있습니다.'
        action = '아래 실패 항목의 원인과 다음 조치를 확인하세요.'
        if report['apply_status'] == 'APPLIED': action = '설치는 적용되었지만 후속 점검이 실패했습니다. 실패 항목을 해결한 뒤 Check로 다시 점검하세요.'
        elif report['apply_status'] == 'ROLLED_BACK': action = '설치 실패 후 자동 복원된 기록입니다. 현재 버전과 실패 원인을 먼저 확인하세요.'
    elif notices:
        code, message, action = 'REVIEW', '저장된 통과 기록의 버전·시각 확인이 필요합니다.', '현재 버전에서 운영 점검을 다시 실행하세요.'
    else:
        code, message = 'SAVED_PASS', '저장된 로컬 운영 점검: 통과'
        action = '이 기록의 점검 항목은 통과했습니다. 이후 변경 여부를 확인할 때 운영 점검을 다시 실행하세요.'
    rows = [dict(항목=CHECKS[row['name']][0], 결과='통과' if row['status'] == 'PASS' else '실패',
        원인='점검 당시 통과' if row['status'] == 'PASS' else DETAILS.get(row['detail'], '이 항목을 확인하지 못했습니다.'),
        다음조치='—' if row['status'] == 'PASS' else CHECKS[row['name']][1]) for row in report['checks']]
    return dict(display_status=code, message=message, next_action=action, report=report,
        rows=rows, notices=notices, running_version=current,
        observed_at=observed.astimezone(timezone.utc).isoformat(),
        report_time_kst=_time(report['created_at']).astimezone(KST).strftime('%Y-%m-%d %H:%M:%S KST'))


def export_view(view):
    if not isinstance(view, dict) or view.get('report') is None: return None
    # Revalidate the report projection; never offer the original JSON bytes for download.
    report = sanitize_report(view['report'])
    return json.dumps(dict(export_schema_version=1, evidence_scope='SAVED_LOCAL_REPORT',
        display_status=view['display_status'], running_version=view['running_version'],
        observed_at=view['observed_at'], report=report), ensure_ascii=False, indent=2)
