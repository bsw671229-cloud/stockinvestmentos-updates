"""Translate exact engine reason templates only when canonical state agrees."""
from ui_decision_status import status_label

FIELDS = (
 ("Integration Consistency", "integration_status", "통합 일치성", ("REVIEW", "BLOCKED", "FAIL")),
 ("Assumption Approval", "assumption_approval", "가정 검토 승인", ("REVIEW", "PENDING", "BLOCKED")),
 ("Lifecycle", "lifecycle", "투자 단계", ("ADD FREEZE", "TRIM", "EXIT")),
 ("Add Freeze", "add_freeze", "추가 투자 보류", ("ON", "REVIEW")),
 ("Portfolio Fit", "portfolio_fit", "포트폴리오 적합성", ("REVIEW", "BLOCKED")),
 ("Proof Clock", "proof_status", "근거 점검 기한", ("OVERDUE",)),
 ("Invalidation", "invalidation_status", "가설 무효화", ("TRIGGERED", "CHECK")),
)

def reason_label(value, summary):
    if not isinstance(value, str):return value
    if value == "Lifecycle = OBSERVE · 아직 관찰 단계입니다." and summary.get("lifecycle") == "OBSERVE":
        return "투자 단계 = 관찰 · 아직 관찰 단계입니다."
    for prefix, field, label, allowed in FIELDS:
        code = summary.get(field)
        if code in allowed and value == f"{prefix} = {code}":
            translated = {"TRIGGERED":"발동", "CHECK":"점검 필요"}.get(code, status_label(code))
            return f"{label} = {translated}"
    return value
