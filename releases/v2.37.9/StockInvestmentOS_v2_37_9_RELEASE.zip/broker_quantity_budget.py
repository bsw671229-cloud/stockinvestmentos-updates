"""Local budget arithmetic; no broker calls, orders, persistence or authority."""
from broker_amount_preview import decimal_text
from connectors.kis_broker import BrokerError, input_number, validate_order

INPUT_QUANTITY_LIMIT = 1_000_000


def _budget(value, label, maximum=None):
    if value is None or (isinstance(value, str) and not value.strip()):
        return None, 'MISSING', label + '을 입력하세요.'
    try:
        amount = input_number(value, label)
        if amount == 0:
            return None, 'MISSING', label + '은 0보다 커야 합니다.'
        if maximum is not None and amount > maximum:
            raise BrokerError(label + ': ' + str(maximum) + '% 이하여야 합니다.')
        return amount, 'READY', ''
    except BrokerError as exc:
        return None, 'INVALID', str(exc)


def _largest_quantity(budget, total):
    # Compare the same arithmetic as validate_limits, including its rounding.
    # Binary search also keeps huge budgets within the existing UI input range.
    low, high = 0, INPUT_QUANTITY_LIMIT
    while low < high:
        middle = (low + high + 1) // 2
        if total(middle) <= budget:
            low = middle
        else:
            high = middle - 1
    return low


def calculate_budget_quantities(order, limits):
    """Return input-based ceilings, never a buy/sell recommendation or PASS gate."""
    checked = validate_order(order)
    price = input_number(checked['limit_price'], '지정가', positive=True)
    fee = input_number(limits.get('fee_buffer_pct'), '비용 여유율')
    if fee > 5:
        raise BrokerError('비용 여유율: 0~5% 범위의 숫자를 입력하세요')
    quantity = checked['quantity']
    cost = lambda qty: price * qty * (1 + fee / 100)
    cap, cap_status, cap_message = _budget(limits.get('max_notional'), '금액 상한')
    result = dict(currency=checked['currency'], side=checked['side'],
        input_quantity=quantity, input_quantity_limit=INPUT_QUANTITY_LIMIT,
        current_cost=decimal_text(cost(quantity)), cap_status=cap_status,
        cap_message=cap_message, amount_limit=None, loss_limit=None,
        combined_limit=None, binding_constraints=[], comparison='UNAVAILABLE',
        loss_status='NOT_APPLICABLE', loss_messages=[], current_loss=None)
    if cap is not None:
        result.update(amount_limit=_largest_quantity(cap, cost),
            cost_remaining=decimal_text(cap - cost(quantity)))
    if checked['side'] == 'BUY':
        downside, ds, dm = _budget(limits.get('downside_pct'), '하락 가정', 100)
        loss_cap, ls, lm = _budget(limits.get('max_scenario_loss'), '가정 손실 예산')
        result['loss_messages'] = [message for message in (dm, lm) if message]
        result['loss_status'] = ('INVALID' if 'INVALID' in (ds, ls)
                                 else 'MISSING' if 'MISSING' in (ds, ls) else 'READY')
        if downside is not None:
            loss = lambda qty: price * qty * downside / 100 + price * qty * fee / 100
            result['current_loss'] = decimal_text(loss(quantity))
            if loss_cap is not None:
                result.update(loss_limit=_largest_quantity(loss_cap, loss),
                    loss_remaining=decimal_text(loss_cap - loss(quantity)))
    limits_by_name = {'AMOUNT': result['amount_limit']}
    if checked['side'] == 'BUY':
        limits_by_name['LOSS'] = result['loss_limit']
    if all(value is not None for value in limits_by_name.values()):
        ceiling = min(limits_by_name.values())
        result.update(combined_limit=ceiling,
            binding_constraints=[name for name, value in limits_by_name.items() if value == ceiling],
            comparison='WITHIN' if quantity <= ceiling else 'EXCEEDS',
            excess_quantity=max(0, quantity - ceiling))
        if ceiling == INPUT_QUANTITY_LIMIT:
            result['binding_constraints'] = ['INPUT_RANGE']
    return result
