"""Presentation-only translations for the app-owned start checklist."""
from ui_korean import ko_text

_LABELS = {
    'Start Here':'처음 시작', 'CHECK':'확인 필요',
    'Portfolio Reconciliation':'보유 내역 대조', 'DART Key':'전자공시 연결 키',
    'DART Corp Codes':'전자공시 기업 고유번호', 'API key detected':'연결 키 등록됨',
    'DART API key missing':'전자공시 연결 키 없음', 'corp code cache ready':'기업 고유번호 목록 준비됨',
    'System Integration':'시스템 통합 점검', 'Decision Summary':'투자 판단 요약',
    'Save Health':'저장 상태', 'Save Center':'저장 관리',
    'Monitoring & Review Queue':'모니터링·검토 대기 목록', 'Review Queue':'검토 대기 목록',
    'Integrated Action Planner':'통합 실행 계획', 'Action Planner':'실행 계획',
    'Stability / E2E Audit':'안정성·전체 작동 점검', 'Stability Audit':'안정성 점검',
    'TODAY+NOW':'오늘·즉시 확인', 'NEXT 7D':'7일 이내',
}

def start_text(value):
    if not isinstance(value,str):return value
    # Start-page phrases are owned by the app; no user-entered narrative is passed.
    for source in sorted(_LABELS,key=len,reverse=True):
        value=value.replace(source,_LABELS[source])
    return ko_text(value)

def start_frame(frame):
    result=frame.copy(deep=True)
    for column in ('Check','Status','Detail','Go To'):
        if column in result.columns:result[column]=result[column].map(start_text)
    return result.rename(columns={'Check':'점검 항목','Status':'상태','Detail':'상세 내용','Go To':'확인할 화면'})
