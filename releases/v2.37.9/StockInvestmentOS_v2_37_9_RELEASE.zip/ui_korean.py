"""Korean presentation helpers. Never translate persisted fields or engine codes."""
import re
import pandas as pd

TERMS = {
    'DART 공시':'전자공시',
    '현재 Capital Productivity Assumption Review Queue가 비어 있습니다.':'현재 자본 효율 가정 검토 목록이 비어 있습니다.',
    '현재 저장 데이터로 Snapshot 만들기':'현재 데이터의 저장 시점 기록 만들기',
    'Daily Briefing':'일일 브리핑', 'Daily Check':'일일 점검',
    'Reconciliation':'보유 내역 대조', 'Data Quality':'데이터 품질',
    'Rebalance Planner':'비중 조정 계획', 'Trade Planner':'매매 계획',
    'Decision Journal':'투자 판단 기록', 'Forecast Calibration':'예측 정확도 점검',
    'Proof Clock':'투자 근거 유효기간', 'OpenDART Auto':'전자공시 자동 수집',
    'Primary Source Monitor':'공식 원문 점검', 'Evidence Candidate Inbox':'투자 근거 후보함',
    'Price OK':'가격 조회 정상', 'Critical Alerts':'중요 위험 알림',
    'Proof Due/Overdue':'점검 기한 도래·초과', 'Assumption NOW':'지금 확인할 투자 가정',
    'Recent DART Disclosures':'최근 전자공시', 'Recent DART':'최근 전자공시',
    'Risk / Evidence Alerts':'위험·투자 근거 알림', 'Lifecycle Preview':'투자 상태 미리보기',
    'Price Update Preview':'가격 갱신 미리보기',
    'Capital Productivity Assumption Clock':'자본 효율 가정 점검 일정',
    'Capital Productivity Assumption Review Queue':'자본 효율 가정 검토 목록',
    'P1 Drift/Integrity':'1순위 변경·무결성', 'P2 Expiry':'2순위 유효기간',
    'P3 Holding Review':'3순위 보유자산 검토', 'P4 Watchlist Review':'4순위 관심종목 검토',
    'Reference Drift':'기준 자료 변경', 'Input mismatch':'입력 불일치', 'Expiry Clock':'유효기간 점검',
    'Declared Total':'등록 총자산', 'Known Portfolio':'보유자산 합계', 'Gap':'차이',
    'Price freshness days':'가격 유효기간(일)', 'Total':'전체',
    'Evidence Source Bridge':'투자 근거 출처 연결', 'Legacy Register':'기존 근거 목록',
    'Evidence Packet':'투자 근거 자료', 'source URL':'출처 주소', 'evidence_status':'근거 상태',
    'Initial Pilot Fraction of Risk Max':'위험 한도 대비 최초 투자 비율',
    'Minimum Cash Weight':'최소 현금 비중', 'Current Cash':'현재 현금', 'Minimum Cash':'최소 필요 현금',
    'Funding Status':'자금 확보 상태', 'Estimated Sells':'예상 매도액',
    'Final Estimated Buys':'최종 예상 매수액', 'Post-plan Cash Proxy':'계획 반영 후 예상 현금',
    'Portfolio-level cash reserve':'포트폴리오 최소 현금', 'Funding layer':'자금 확보 점검',
    'Rebalance Review':'비중 조정 검토', 'Overdue Proof':'점검 기한 초과 근거',
    'Current Snapshot':'현재 상태 요약', 'APPROVED Decisions':'승인된 판단 기록',
    'Open Outcomes':'결과 확인 대기', 'Overdue Outcomes':'결과 확인 기한 초과',
    'Integrity Issues':'무결성 문제', 'Risk Ceiling':'위험 한도 수량', 'Executable':'실행 가능 수량',
    'Add Freeze':'추가 투자 중지', 'Portfolio Fit':'포트폴리오 적합성',
    'Evidence Link':'투자 근거 연결', 'Impact Link':'영향 검토 연결',
    'Pre-decision Record':'판단 전 기록', 'Outcome Review':'결과 검토',
    'Execution / Learning Lineage':'실행·학습 연결 이력', 'Learning Feedback':'학습 결과 반영',
    'Expected Proof Date':'예상 확인일', 'Decision Date':'판단일', 'Decision Type':'판단 유형',
    'Decision Action':'판단 행동', 'Strongest Counter Case':'가장 강한 반대 가설',
    'Expected Outcome':'기대 결과', 'Actual Outcome':'실제 결과',
    'Invalidation':'가설 무효화 조건', 'Proof Date':'확인일', 'Proof Status':'확인 상태',
    'Draft Gate':'초안 점검', 'Approval Gate':'승인 점검', 'Snapshot Link':'저장 시점 연결',
    'Decision Record':'투자 판단 기록', 'Forecast Error Class':'예측 오차 유형',
    'Forecast Error':'예측 오차', 'Outcome Classification':'결과 분류',
    'Process Adherence':'절차 준수', 'New Learning':'새로 확인한 교훈', 'Next Action':'다음 검토 행동',
    'Good Outcome ≠ Good Decision.':'좋은 결과가 좋은 판단을 뜻하지는 않습니다.',
    'append-only':'추가 기록 전용', 'Legacy':'기존', 'History':'기록 이력',
    'Watchlist DART Scan':'관심종목 전자공시 조회', 'Lookback Days':'조회 기간(일)',
    'Corp Code Cache':'기업 고유번호 목록', 'Candidate Inbox':'공시 후보함',
    'Candidate Review':'공시 후보 검토', 'HIGH Open':'높은 우선순위 검토 대기',
    'IN REVIEW':'검토 중', 'Dismiss Reason':'검토 제외 사유', 'Why Review':'검토 이유',
    'Monitoring Priority':'점검 우선순위', 'Evidence Intake':'투자 근거 등록',
    'Evidence Signal':'투자 근거 신호', 'Contrary Evidence':'반대 근거',
    'Interpretation':'해석', 'Fact':'사실', 'Valuation':'가치 평가',
    'FINANCIAL / PERIODIC':'재무·정기 보고', 'CAPITAL / FINANCING':'자본·자금 조달',
    'COMMERCIAL / CONTRACT':'영업·계약', 'GOVERNANCE':'지배구조',
    'Factor Concentration':'투자 요인 집중 위험', 'Capital-at-Risk':'예상 손실 위험',
    'Concentration':'집중 위험', 'Survival':'재무 생존', 'Lifecycle':'투자 상태',
    'Korea Semiconductor Cycle':'한국 반도체 업황',
    'Capital Productivity Integrity':'자본 효율 무결성',
    'Capital Productivity Holding Review':'보유자산 자본 효율 검토',
    'Capital Productivity Watchlist Review':'관심종목 자본 효율 검토',
    'Capital Productivity Expiry Clock':'자본 효율 가정 유효기간',
    'P1_INTEGRITY_OR_DRIFT':'1순위 무결성·기준 변경', 'P2_EXPIRY':'2순위 유효기간',
    'P3_HOLDING_REVIEW':'3순위 보유자산 검토', 'P4_WATCHLIST_REVIEW':'4순위 관심종목 검토',
    'PASS-PROXY':'간접 자료 기준 통과', 'DUE SOON':'기한 임박', 'NO DATE':'날짜 미등록',
    'NEXT 30 DAYS':'30일 이내', 'CASH_RESERVE_BLOCK':'최소 현금 부족으로 차단',
    'CRITICAL':'중요 경고', 'WARNING':'주의', 'INFO':'참고', 'PASS':'정상',
    'REVIEW':'재검토 필요', 'BLOCKED':'진행 차단', 'READY':'준비 완료',
    'DRAFT':'초안', 'APPROVED':'승인됨', 'PROVISIONAL':'잠정 근거', 'STRONG':'강한 근거',
    'OPEN':'확인 대기', 'CLOSED':'확인 종료', 'OVERDUE':'기한 초과',
    'CORE':'핵심 투자 후보', 'OBSERVE':'관찰', 'TRIM':'비중 축소 검토',
    'PILOT':'소규모 투자 검토', 'EXIT':'투자 종료 검토', 'HOLD':'유지',
    'WAIT':'대기', 'BUY':'매수', 'SELL':'매도', 'FREEZE':'추가 투자 중지',
    'FUNDED':'자금 확보', 'ON':'켜짐', 'OFF':'꺼짐', 'OK':'정상',
    'ERROR':'오류', 'SKIP':'건너뜀', 'NONE':'없음', 'NEW':'신규', 'HIGH':'높음',
    'MEDIUM':'보통', 'LOW':'낮음', 'PROMOTED':'근거 등록됨', 'DISMISSED':'검토 제외',
    'NOW':'지금 확인', 'MATCH':'일치', 'MISMATCH':'불일치',
    'Reviewed':'검토 완료', 'Severity':'위험 수준', 'Status':'상태', 'Priority':'우선순위',
    'Category':'분류', 'Integrity':'무결성', 'Filter':'필터', 'Candidate':'후보',
    'Packet':'자료', 'Snapshot':'저장 시점 기록', 'Preview':'미리보기',
    'Portfolio':'포트폴리오', 'Watchlist':'관심종목', 'Settings':'설정',
    'Evidence':'투자 근거', 'Thesis':'투자 가설', 'Decision':'판단',
    'Outcome':'결과', 'Proof':'근거 확인', 'Gate':'점검', 'Hash':'무결성 해시',
    'Alerts':'위험 알림', 'Alert':'알림', 'Price':'가격', 'Cash':'현금',
    'DART Scan':'전자공시 조회', 'DART':'전자공시',
    'due_date':'확인 기한', 'refinancing gate':'차환 위험 점검',
    'evidence':'투자 근거', 'price stale':'가격 경과', 'missing':'없음',
    'No disclosure in period':'조회 기간 내 공시 없음',
    'Wait for price or evidence':'가격 또는 투자 근거 확인 대기',
    'Risk Alerts':'위험 알림', 'Canonical':'기준 데이터', 'Journal':'기록부',
    'Decision Records':'투자 판단 기록', 'Decision Link':'판단 기록 연결',
    'Post-Trade Audit':'매매 후 점검', 'Fill Reconciliation':'체결 내역 대조',
    'Post-Trade':'매매 후 점검', 'Fill':'체결', 'Lineage':'연결 이력',
    'Assumption Change Proposal':'투자 가정 변경 제안',
    'Execution Authorization':'투자 실행 권한', 'Process Adherence':'절차 준수',
    'Forward ER':'예상 수익률', 'Risk Penalty':'위험 차감치', 'Hurdle':'최소 요구수익률',
    'Position Size':'투자 규모', 'Risk Budget':'위험 예산',
    'Revalidation':'재검증', 'Human Review':'직접 검토',
    'Model':'모형', 'Parameter':'매개변수', 'Execution':'실행', 'Exogenous':'외부 요인',
    'MODEL':'모형', 'PARAMETER':'매개변수', 'EXECUTION':'실행', 'EXOGENOUS':'외부 요인',
    'Assumption':'투자 가정', 'Process':'절차', 'Learning':'학습 결과',
    'Forecast':'예측', 'Cohort':'비교 집단', 'Recurring':'반복', 'Recurrence':'반복 발생',
    'Error Recurrence Monitor':'오류 반복 점검', 'Forecast Audit':'예측 검증',
    'Valid Learning':'유효한 학습 결과', 'Recurring Patterns':'반복 유형',
    'Implementation Review':'변경 이행 검토', 'Implementation Event':'변경 이행 기록',
    'Before-After Cohort Lock':'변경 전후 비교 집단 고정',
    'Observed Effect Classification':'관찰된 효과 분류', 'Change Effect Classification':'변경 효과 분류',
    'Effect Interpretation':'효과 해석', 'Alternative Explanations / Confounders':'다른 설명·교란 요인',
    'Second-order Learning':'변경 효과에서 얻은 교훈', 'Next Review Action':'다음 검토 행동',
    'Before Error Share':'변경 전 오류 비율', 'Post Error Share':'변경 후 오류 비율',
    'Baseline Error Share':'기준 오류 비율', 'Baseline Samples':'기준 표본 수',
    'Post Samples':'변경 후 표본 수', 'Comparison':'비교 결과',
    'Change Area':'변경 영역', 'Change Target':'변경 대상',
    'Baseline Description':'기준 상태 설명', 'Proposed Change':'제안 변경 사항',
    'Expected Improvement':'기대 개선 효과', 'Repeat Count':'반복 횟수',
    'Error Class':'오류 유형', 'Expected Change Area':'예상 변경 영역',
    'Source Integrity':'출처 무결성', 'Plan Integrity':'계획 무결성',
    'Review Lane':'검토 경로', 'Feedback Target':'개선 대상', 'Change Direction':'변경 방향',
    'Proposed Delta (decimal)':'제안 변경량(소수)', 'Feedback Rationale':'개선 제안 근거',
    'Actual Implementation':'실제 변경 이행', 'Source Review Reference':'출처 검토 근거',
    'Before Baseline':'변경 전 기준', 'Before / After':'변경 전후', 'Before/After':'변경 전후',
    'Before/Post':'변경 전후', 'Error Share':'오류 비율', 'Proof Ready':'근거 확인 준비',
    'Carry-forward':'다음 판단에 반영', 'LEARNING_COMPLETE':'학습 연결 완료',
    'OUTCOME_PENDING':'결과 확인 대기', 'INVALIDATED':'무효화됨', 'PROOF_READY':'근거 확인 준비',
    'REGISTERED_FOR_IMPLEMENTATION_REVIEW':'변경 이행 검토 등록됨',
    'LOWER/HIGHER_ERROR_SHARE':'오류 비율 감소·증가',
    'Candidate Integrity Repair':'공시 후보 무결성 복구',
    'API Key':'연결 키', 'Key':'연결 키', 'Lookback':'조회', 'URL':'주소',
    'Saved':'저장된', 'Source':'출처', 'Target':'대상', 'Feedback':'개선 제안',
    'Proposal':'제안', 'Change':'변경', 'Plan':'계획', 'Registry':'등록부',
    'Implementation':'변경 이행', 'Review':'검토', 'Audit':'검증', 'Error':'오류',
    'Class':'유형', 'Count':'건수', 'Summary':'요약', 'Date':'날짜', 'Due Date':'기한',
    'Save':'저장', 'Next':'다음', 'Locked':'고정된', 'Event':'기록', 'Effect':'효과',
    'Before':'변경 전', 'After':'변경 후', 'Monitor':'점검',
    'mismatch':'불일치', 'logic':'로직', 'parameter':'매개변수', 'process':'절차',
    'monitoring':'점검', 'rule':'규칙', 'pattern':'유형', 'sample':'표본',
    'source':'출처', 'error count':'오류 건수', 'error share':'오류 비율',
    'append':'추가 기록', 'upstream execution lineage':'상위 실행 연결 이력',
}

COLUMNS = dict(line.split('=', 1) for line in '''name=종목명
company=기업명
ticker=종목코드
market=시장
asset_type=자산 유형
currency=통화
quantity=수량
manual_price=수동 입력 가격
current_value_krw=평가액(원)
severity=위험 수준
category=분류
subject=대상
message=안내
status=상태
issues=확인할 사항
issue=확인할 사항
price=가격
lifecycle_state=투자 상태
state_reason=상태 판단 근거
evidence_status=투자 근거 상태
thesis_status=투자 가설 상태
row=행
old_price=기존 가격
new_price=조회 가격
timestamp=자료 기준 시각
source=출처
proof_item=확인할 근거
due_date=확인 기한
invalidation_signal=가설 무효화 신호
clock_status=기한 상태
days_left=남은 일수
priority=우선순위
bucket=점검 시기
next_action=다음 행동
stock_code=종목코드
watch_name=관심종목명
corp_code=기업 고유번호
corp_name=기업명
report_nm=공시 제목
report_name=공시 제목
receipt_date=접수일
rcept_dt=접수일
rcept_no=접수번호
dart_url=전자공시 원문
monitor_priority=점검 우선순위
action=행동
shares=수량
current_price=현재 등록 가격
limit_price=지정 가격
estimated_value=추정 금액
decision_date=판단일
decision_type=판단 유형
review_status=검토 상태
decision_id=판단 기록 번호
content_hash=내용 무결성 해시
proof_date=근거 확인일
outcome_status=결과 확인 상태
hash_status=무결성 상태
thesis=투자 가설
strongest_counter_case=가장 강한 반대 가설
invalidation=가설 무효화 조건
expected_outcome=기대 결과
review_date=검토일
actual_outcome=실제 결과
outcome_classification=결과 분류
forecast_error_class=예측 오차 유형
process_adherence=절차 준수
new_learning=새로 확인한 교훈
created_at=작성 시각
updated_at=수정 시각'''.splitlines())

_PATTERN = re.compile(r'(?<![A-Za-z0-9_])(' + '|'.join(re.escape(k) for k in sorted(TERMS, key=len, reverse=True)) + r')(?![A-Za-z0-9_])')

def ko_text(value):
    if not isinstance(value, str):
        return value
    # Preserve identifiers and URLs; translate known display vocabulary only.
    return _PATTERN.sub(lambda m: TERMS[m.group()], value)

def ko_reason(value):
    if not isinstance(value, str):
        return value
    rules = [
        (r'Bear capital-at-risk (.+) exceeds per-position loss budget (.+)\.', r'하락 시나리오 손실위험 \1가 종목별 허용손실 \2를 초과합니다.'),
        (r'Current weight (.+) exceeds single-name cap (.+)\.', r'현재 비중 \1가 개별 종목 상한 \2를 초과합니다.'),
        (r'Factor weight (.+) exceeds factor cap (.+)\.', r'투자 요인 비중 \1가 요인별 상한 \2를 초과합니다.'),
        (r'Current weight (.+) > risk cap (.+)', r'현재 비중 \1 > 위험 비중 상한 \2'),
        (r'State = ', '투자 상태 = '),
        (r'Price (.+) <= core (.+); evidence (.+)', r'가격 \1 ≤ 핵심 투자 기준 \2; 투자 근거 \3'),
        (r'price stale \((\d+)d\)', r'가격 자료 \1일 경과'),
    ]
    for pattern, replacement in rules:
        value = re.sub(pattern, replacement, value)
    return ko_text(value)

_CODE_COLUMNS = {'severity','category','status','lifecycle_state','evidence_status','thesis_status',
                 'clock_status','priority','bucket','monitor_priority','decision_type','review_status',
                 'outcome_status','hash_status','action','asset_type','currency','market'}
_REASON_COLUMNS = {'message','issues','issue','state_reason'}

def ko_frame(frame):
    """Read-only display copy; keep numeric values, user narratives and IDs intact."""
    if not isinstance(frame, pd.DataFrame):
        return frame
    result = frame.copy(deep=True)
    for col in result.columns:
        if col in _CODE_COLUMNS:
            result[col] = result[col].map(ko_text)
        elif col in _REASON_COLUMNS:
            result[col] = result[col].map(ko_reason)
    # Unknown extension columns remain visible rather than silently discarded.
    return result.rename(columns={c:COLUMNS.get(c,c) for c in result.columns})

def ko_columns(frame, existing=None):
    """Editor headers only: underlying field names and values must remain canonical."""
    config={c:COLUMNS[c] for c in frame.columns if c in COLUMNS}
    config.update(existing or {})
    return config

def ko_format(formatter=str):
    """Translate select labels without changing option/return values."""
    return lambda value: ko_text(formatter(value))
