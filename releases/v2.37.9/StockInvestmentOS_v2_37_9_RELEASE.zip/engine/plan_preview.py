"""Pure editor projections. No broker access, persistence or execution permission."""
from connectors.kis_broker import BrokerError, number
from engine.paper_plans import editor_values


def _numeric(value):
    try:
        numeric = number(value)
        if numeric == 0:
            return '0'
        text = format(numeric, 'f')
        return text.rstrip('0').rstrip('.') if '.' in text else text
    except (BrokerError, TypeError, ValueError):
        return '입력 확인: ' + str(value)[:80]


def _rule_rows(rules):
    rows = []
    for index, rule in enumerate(rules):
        order, limits = rule['order'], rule['limits']
        rows.append({'조건': index+1, '시장': order['market'], '거래소': order['exchange'],
            '종목': order['symbol'], '방향': '매수' if order['side']=='BUY' else '매도',
            '통화': order['currency'], '수량': _numeric(order['quantity']),
            '가격 조건': '이하' if rule['comparison']=='LE' else '이상',
            '조건 가격': _numeric(rule['trigger']), '주문 지정가': _numeric(order['limit_price']),
            '선행 매수 조건': str(rule['after_buy']+1) if 'after_buy' in rule else '연결 없음',
            '건별 금액 상한': _numeric(limits['max_notional']),
            '비용 여유율 (%)': _numeric(limits['fee_buffer_pct']),
            '시세·지정가 차이 한도 (%)': _numeric(limits['max_quote_gap_pct']),
            '하락 가정 (%)': _numeric(limits['downside_pct']),
            '건별 가정 손실 예산': _numeric(limits['max_scenario_loss'])})
    return rows


def _fields(rows, budgets, minutes):
    result = {}
    for row in rows:
        for label, value in row.items():
            if label != '조건':
                result[f"조건 {row['조건']} · {label}"] = str(value)
    for currency, cap in sorted(budgets.items()):
        for key, label in (('cost','하루 금액 한도'),('loss','하루 가정 손실 한도'),('count','하루 시도 수')):
            result[currency+' · '+label] = _numeric(cap[key])
    result['실행 시간 (분)'] = _numeric(minutes)
    return result


def preview(payload, current_rules, current_budgets, current_minutes, *, mode='PAPER'):
    """Compare registered rules and submitted form values, not unsubmitted browser edits."""
    rules, budgets, minutes = editor_values(payload, mode=mode)
    saved_rows, current_rows = _rule_rows(rules), _rule_rows(current_rules)
    saved = _fields(saved_rows, budgets, minutes)
    current = _fields(current_rows, current_budgets, current_minutes)
    changes = []
    for field in dict.fromkeys([*current, *saved]):
        if current.get(field) != saved.get(field):
            changes.append({'항목': field, '변경': '추가' if field not in current else '제거' if field not in saved else '변경',
                '현재 반영값': current.get(field, '없음'), '불러올 값': saved.get(field, '없음')})
    caps = [{'통화': c, '하루 금액 한도': _numeric(b['cost']),
             '하루 가정 손실 한도': _numeric(b['loss']), '하루 시도 수': b['count']}
            for c,b in sorted(budgets.items())]
    return dict(rules=saved_rows, budgets=caps, minutes=minutes, changes=changes)
