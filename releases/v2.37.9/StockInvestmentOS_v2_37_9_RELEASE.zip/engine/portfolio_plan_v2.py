"""Joint manual portfolio scenarios. Pure arithmetic, no data access or execution."""
from datetime import datetime, timezone
import math

from engine.decision_contract_v2 import review_contract

MAX_ROWS = 100
EPSILON = 1e-12


def _number(value, label, errors, maximum=1, positive=False):
    try:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError
        number = float(value)
        if not math.isfinite(number) or number < 0 or number > maximum or (positive and number == 0):
            raise ValueError
        return number
    except (ValueError, OverflowError):
        errors.append(label + ': 허용 범위 안의 유한 숫자를 입력하세요.')
        return 0.0


def review_plan(plan, *, now=None):
    errors = []
    result = dict(status='BLOCKED', blockers=errors, execution_authorization='NONE', orders_enabled=False)
    if not isinstance(plan, dict) or type(plan.get('schema_version')) is not int or plan.get('schema_version') != 1:
        errors.append('포트폴리오 계획 입력 버전은 1이어야 합니다.')
        return result
    assets = _number(plan.get('assets'), '총자산', errors, maximum=1e15, positive=True)
    rows = plan.get('positions')
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_ROWS:
        errors.append(f'현재·목표 보유 내역을 1~{MAX_ROWS}행 입력하세요.')
        return result
    normalized, seen = [], set()
    for index, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            errors.append(f'{index}행: 종목 입력을 확인하세요.')
            continue
        symbol, factor = row.get('symbol'), row.get('factor')
        if not isinstance(symbol, str) or not symbol.strip() or len(symbol.strip()) > 80:
            errors.append(f'{index}행: 1~80자의 종목 식별자가 필요합니다.')
            continue
        symbol = symbol.strip().upper()
        if symbol in seen:
            errors.append(f'{index}행: 종목 식별자가 중복됩니다.')
        seen.add(symbol)
        if not isinstance(factor, str) or not factor.strip() or len(factor.strip()) > 80:
            errors.append(f'{index}행: 1~80자의 투자 요인이 필요합니다.')
            factor = ''
        else:
            factor = factor.strip().upper()
        normalized.append(dict(symbol=symbol, factor=factor,
            current_weight=_number(row.get('current_weight'), f'{index}행 현재 비중', errors),
            target_weight=_number(row.get('target_weight'), f'{index}행 목표 비중', errors),
            downside=_number(row.get('downside'), f'{index}행 하방 가정', errors, positive=True)))
    if errors:
        return result
    current_weight = math.fsum(r['current_weight'] for r in normalized)
    target_weight = math.fsum(r['target_weight'] for r in normalized)
    if current_weight > 1 + EPSILON:
        errors.append('현재 비중 합계가 100%를 초과합니다.')
    if target_weight > 1 + EPSILON:
        errors.append('목표 비중 합계가 100%를 초과합니다. 현금 또는 비중을 재검토하세요.')
    if errors:
        return result
    current = now if now is not None else datetime.now(timezone.utc)
    holdings = [dict(symbol=r['symbol'], factor=r['factor'], weight=r['target_weight'], downside=r['downside']) for r in normalized]
    reviews = []
    for row in normalized:
        reviewed = review_contract(dict(schema_version=2,
            candidate=dict(symbol=row['symbol'], factor=row['factor'], downside=row['downside'], proposed_weight=row['target_weight']),
            positions=holdings, budget=plan.get('budget'), evidence=plan.get('evidence')), now=current)
        if reviewed['blockers']:
            errors.extend(reviewed['blockers'])
            return result
        reviews.append(reviewed)
    budget = plan['budget']
    before_loss = math.fsum(r['current_weight'] * r['downside'] for r in normalized)
    after_loss = math.fsum(r['target_weight'] * r['downside'] for r in normalized)
    factors = []
    for factor in sorted({r['factor'] for r in normalized}):
        before = math.fsum(r['current_weight'] for r in normalized if r['factor'] == factor)
        after = math.fsum(r['target_weight'] for r in normalized if r['factor'] == factor)
        factors.append(dict(factor=factor, current_weight=before, target_weight=after,
            cap=budget['factor_cap'], exceeded=after > budget['factor_cap'] + EPSILON))
    details = []
    for row, reviewed in zip(normalized, reviews):
        delta = row['target_weight'] - row['current_weight']
        details.append(dict(**row, change_weight=delta, change_amount=assets * delta,
            current_loss=assets * row['current_weight'] * row['downside'],
            target_loss=assets * row['target_weight'] * row['downside'],
            loss_share=(row['target_weight'] * row['downside'] / after_loss if after_loss else 0.0),
            max_weight=reviewed['max_weight'], limiting_factors=reviewed['limiting_factors'],
            breaches=reviewed['breaches'], status=reviewed['status']))
    scenarios = []
    for multiplier in (1.0, 1.5, 2.0):
        before = math.fsum(r['current_weight'] * min(1.0, r['downside'] * multiplier) for r in normalized)
        after = math.fsum(r['target_weight'] * min(1.0, r['downside'] * multiplier) for r in normalized)
        scenarios.append(dict(multiplier=multiplier, current_loss=before, target_loss=after,
            current_amount=assets * before, target_amount=assets * after,
            exceeds_budget=after > budget['portfolio_loss'] + EPSILON))
    blocked = any(r['status'] == 'BLOCKED' for r in reviews)
    result.update(status='BLOCKED' if blocked else 'REVIEW', assets=assets,
        current_weight=current_weight, target_weight=target_weight,
        current_cash=max(0.0, 1-current_weight), target_cash=max(0.0, 1-target_weight),
        current_loss=before_loss, target_loss=after_loss,
        current_loss_amount=assets*before_loss, target_loss_amount=assets*after_loss,
        loss_budget=budget['portfolio_loss'], current_headroom=budget['portfolio_loss']-before_loss,
        target_headroom=budget['portfolio_loss']-after_loss,
        positions=details, factors=factors, scenarios=scenarios,
        observed_at=plan['evidence']['observed_at'], reviewed_at=current.isoformat(),
        model='모든 종목이 동시에 입력 하방에 도달하는 단순 합산; 현금 하방 0')
    return result
