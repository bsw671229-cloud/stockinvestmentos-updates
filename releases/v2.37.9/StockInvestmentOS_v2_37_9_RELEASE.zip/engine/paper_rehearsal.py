"""Read-only, aggregate PAPER plan checks. A report never grants order authority."""
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import sqlite3
import time

from connectors.kis_broker import BrokerError, number, whole
from engine.broker_execution import ACTIVE, TERMINAL, canonical, validate_limits
from engine import paper_automation as pa
from engine.paper_calendar import session_status

REPORT_SECONDS = 60


def check_mode(client, account=None, *, mode='PAPER'):
    if mode == 'PAPER':
        pa.paper_only(client, account)
    elif mode == 'LIVE':
        from engine.live_automation import live_only
        live_only(client, account)
    else:
        raise BrokerError('연결 환경을 확인하세요.')


def normalize(rules, budgets, minutes):
    if not 1 <= whole(minutes) <= 60 or not 1 <= len(rules) <= 10:
        raise BrokerError('조건 1~10개와 실행 시간 1~60분을 확인하세요.')
    rules = pa.validate_rules(rules)
    caps = {}
    for c in sorted({r['order']['currency'] for r in rules}):
        b = budgets[c]
        caps[c] = dict(cost=str(number(b['cost'], positive=True)), loss=str(number(b['loss'])), count=whole(b['count']))
        if not 1 <= caps[c]['count'] <= 10:
            raise BrokerError('하루 시도 수는 통화별 1~10회입니다.')
    return rules, caps, whole(minutes)


def signature(client, rules, budgets, minutes, *, mode='PAPER'):
    """Session-local binding only; never included in the downloadable report."""
    rules, caps, minutes = normalize(rules, budgets, minutes)
    check_mode(client, mode=mode)
    value = [mode, client.credentials.identity, id(client), rules, caps, minutes]
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def _state(journal, account, day):
    # mode=ro prevents even accidental writes or creation; no Journal transaction.
    db = sqlite3.connect(journal.path.resolve().as_uri()+'?mode=ro', uri=True, timeout=10)
    db.row_factory = sqlite3.Row
    try:
        db.execute('BEGIN')
        tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        records = {t: [dict(r) for r in db.execute('SELECT * FROM '+t+' WHERE account=? ORDER BY rowid', (account,))]
                   if t in tables else [] for t in ('orders', 'controls', 'paper_runs', 'paper_attempts')}
    finally:
        db.close()
    blockers, totals = [], {}
    if any(r['halted'] for r in records['controls']):
        blockers.append('신규 주문 차단을 해제하기 전에 이전 주문을 확인하세요.')
    now = time.time()
    orders = {r['id']: r for r in records['orders']}
    if any(r['status'] in ACTIVE or (r['status']=='PREPARED' and r['expires']>now) for r in orders.values()):
        blockers.append('미완료 주문 또는 유효한 주문 미리보기가 있습니다.')
    if any(r['state']=='ARMED' and r['process']==pa.PROCESS and r['heartbeat']>now-pa.MAX_GAP and r['expires']>now for r in records['paper_runs']):
        blockers.append('다른 화면에서 자동매매가 실행 중입니다.')
    for r in records['paper_attempts']:
        order = orders.get(r['order_id'])
        if r['state'] in ('CLAIMED','PENDING','UNKNOWN') and not (order and order['status'] in TERMINAL):
            blockers.append('이전 자동 주문 시도의 결과 확인이 필요합니다.')
        if r['day']==day:
            total = totals.setdefault(r['currency'], dict(cost=Decimal(0), loss=Decimal(0), count=0))
            total['cost'] += number(r['cost']); total['loss'] += number(r['loss']); total['count'] += 1
    return dict(blockers=list(dict.fromkeys(blockers)), totals=totals,
                fingerprint=hashlib.sha256(canonical(records).encode()).hexdigest())


def rehearse(client, journal, rules, budgets, minutes, *, mode='PAPER'):
    started = time.time()
    report = dict(schema_version=1, mode=mode, status='BLOCKED', checked_at=datetime.fromtimestamp(started, timezone.utc).isoformat(),
        expires_at=datetime.fromtimestamp(started+REPORT_SECONDS, timezone.utc).isoformat(),
        blockers=[], rules=[], currencies=[], holdings=[], order_transmission='NOT_PERFORMED',
        coverage='조회 당시 입력·연결 계좌 기준. 예약·주문·취소 없음. 두 연결 매도도 모두 예산 합산, 실행 시 하나만 선택합니다. 연결 매도 수량은 선행 매수 전량 체결 후 재검사합니다. 매도대금의 매수 재사용·환전 없음.')
    try:
        check_mode(client, mode=mode)
        account, day = client.credentials.identity, pa._day()
        rules, caps, minutes = normalize(rules, budgets, minutes)
        before = _state(journal, account, day)
        report['blockers'].extend(before['blockers'])
        planned, buys, sells, quotes = {}, {}, {}, []
        for r in rules:
            o = r['order']; c = o['currency']; estimate = validate_limits(o, r['limits'])
            total = planned.setdefault(c, dict(cost=Decimal(0), loss=Decimal(0), count=0, buy_cash=Decimal(0), cash=None))
            total['cost'] += number(estimate['estimated_cost']); total['loss'] += number(estimate['scenario_loss']); total['count'] += 1
            if o['side']=='BUY': total['buy_cash'] += number(estimate['estimated_cost'])
        for c, p in planned.items():
            used = before['totals'].get(c, dict(cost=Decimal(0), loss=Decimal(0), count=0))
            for key, label in (('cost','비용 포함 금액'),('loss','가정 손실'),('count','시도 수')):
                if used[key]+p[key] > number(caps[c][key]):
                    report['blockers'].append(c+' 하루 '+label+' 한도를 전체 조건이 초과합니다.')
            report['currencies'].append(dict(currency=c, planned_cost=str(p['cost']), planned_loss=str(p['loss']), planned_count=p['count'],
                used_cost=str(used['cost']), used_loss=str(used['loss']), used_count=used['count'], budget=caps[c],
                buy_cash_required=str(p['buy_cash']), available_cash=None))
        # Known local blockers require no brokerage reads.
        if report['blockers']: return report
        for idx, r in enumerate(rules, 1):
            o = r['order']; c = o['currency']; instrument = (o['market'], o['exchange'], o['symbol'])
            check_mode(client, account, mode=mode)
            quote = pa.checked_quote(client, r)
            check_mode(client, account, mode=mode)
            quotes.append(quote)
            if o['side']=='BUY':
                check_mode(client, account, mode=mode)
                power = client.buying_power(o)
                check_mode(client, account, mode=mode)
                if power.get('currency') != c: raise BrokerError('주문 가능 금액 통화를 확인하세요.')
                cash, qty = number(power['cash']), whole(power['quantity'])
                planned[c]['cash'] = cash if planned[c]['cash'] is None else min(planned[c]['cash'], cash)
                group = buys.setdefault(instrument, dict(required=0, available=qty))
            elif 'after_buy' not in r:
                check_mode(client, account, mode=mode)
                qty = whole(client.sellable(o))
                check_mode(client, account, mode=mode)
                group = sells.setdefault(instrument, dict(required=0, available=qty))
            if 'after_buy' not in r:
                group['required'] += o['quantity']; group['available'] = min(group['available'], qty)
            hours = session_status(o['market'], time.time())
            matched = pa.matches(r, number(quote['price']))
            gap = abs(number(o['limit_price'])-number(quote['price']))/number(quote['price'])*100
            reasons = []
            if 'after_buy' in r:
                reasons.append(str(r['after_buy']+1)+'번 매수 전량 체결 후 매도 가능 수량 재검사')
                if sum(other.get('after_buy')==r['after_buy'] for other in rules)==2:
                    reasons.append('같은 매수의 두 매도 중 하나만 시도 · 실패해도 자동 전환 없음')
            if not matched: reasons.append('가격 조건 대기')
            if not hours['open']: reasons.append(hours['reason'])
            if hours['coverage']=='OUT_OF_COVERAGE': report['blockers'].append('미국 거래일 달력 범위 밖입니다.')
            if gap > number(r['limits']['max_quote_gap_pct']):
                reasons.append('현재 조회 가격과 지정가 차이 한도 초과')
                if matched: report['blockers'].append(str(idx)+'번 조건의 현재 가격 차이가 한도를 초과합니다.')
            report['rules'].append(dict(index=idx, **o, comparison=r['comparison'], trigger=r['trigger'],
                quote=quote, status='WAIT' if reasons else 'CHECKED', reasons=reasons))
        for row in report['currencies']:
            p = planned[row['currency']]
            row['available_cash'] = str(p['cash']) if p['cash'] is not None else None
            if p['cash'] is not None and p['buy_cash']>p['cash']:
                report['blockers'].append(row['currency']+' 전체 매수 금액과 비용 여유에 필요한 현금이 부족합니다.')
        for side, groups in (('BUY', buys), ('SELL', sells)):
            for (market, exchange, symbol), g in groups.items():
                report['holdings'].append(dict(market=market, exchange=exchange, symbol=symbol, side=side, **g))
                if g['required']>g['available']:
                    report['blockers'].append(symbol+' 전체 '+('매수 가능' if side=='BUY' else '매도 가능')+' 수량이 부족합니다.')
        check_mode(client, account, mode=mode)
        if pa._day()!=day: report['blockers'].append('한국시간 날짜가 바뀌었습니다. 다시 점검하세요.')
        after = _state(journal, account, day)
        if before['fingerprint']!=after['fingerprint']:
            report['blockers'].append('조회 중 주문·예산 기록이 바뀌었습니다. 다시 점검하세요.')
        if any(not -2 <= time.time()-datetime.fromisoformat(q['fetched_at']).timestamp() <= 15 for q in quotes):
            report['blockers'].append('일괄 조회 중 시세 확인 시간이 지났습니다. 다시 점검하세요.')
        if time.time()>=started+REPORT_SECONDS:
            report['blockers'].append('일괄 점검 시간이 초과되었습니다. 다시 점검하세요.')
        report['blockers'] = list(dict.fromkeys(report['blockers']))
        if not report['blockers']:
            report['status'] = 'WAITING' if any(r['status']=='WAIT' for r in report['rules']) else 'CHECKED'
    except Exception:
        # Provider errors can contain account or authentication information.
        report['blockers'].append('입력·연결 환경·조회 응답·저장 기록을 확인하지 못했습니다. 수정 후 다시 점검하세요.')
    return report
