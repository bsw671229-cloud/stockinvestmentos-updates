"""Read-only explanations from saved facts and current local observations."""
import json

CHECK_ORDERS = '주문·체결 관리에서 접수·체결 상태를 확인하세요. 자동 재개하지 않습니다.'
CHECK_START = '기존 주문 결과와 조건·한도를 확인한 뒤 새 실행은 직접 시작하세요.'
NOTES = {
    '사용자가 중지했습니다.': ('USER_STOP', '사용자가 중지했습니다.', CHECK_START),
    '이전 실행 만료': ('PREVIOUS_RUN_ENDED', '새 실행을 준비하면서 이전 실행을 만료 처리했습니다.', CHECK_ORDERS),
    '이전 실행 결과 확인을 위해 신규 주문을 중지했습니다.': ('REVIEW_STOP', '이전 결과 확인을 위해 신규 주문을 중지했습니다.', CHECK_ORDERS),
    '주문 결과를 확인해야 합니다. 주문·체결 관리에서 확인하세요.': ('ORDER_REVIEW', '주문 결과 확인이 필요해 중지했습니다.', CHECK_ORDERS),
    '등록 조건 처리 완료': ('COMPLETE', '등록 조건 처리가 완료되었습니다.', CHECK_ORDERS),
    '가격 조건 대기': ('WAITING', '가격 조건 대기로 기록되어 있습니다.', '현재 확인 사항과 주문 상태를 함께 확인하세요.'),
}
for phase,code,action in (
    ('실행 시간·연결·신규 주문 차단 확인','SESSION_REVIEW','실행 시간·연결 상태·신규 주문 차단 상태와 기존 주문 결과를 확인하세요.'),
    ('접수·체결 결과 확인','FILL_REVIEW',CHECK_ORDERS),
    ('하루 예산·이전 주문 상태 확인','BUDGET_REVIEW','통화별 하루 예산·시도 수와 기존 미완료 주문을 확인하세요.'),
    ('가격 조건·잔고 점검 및 주문 결과 확인','PRE_SEND_REVIEW','가격 조건·주문 가능 금액·보유 수량과 주문 결과를 확인하세요.'),
):
    NOTES['자동매매 중지 · '+phase+'이 필요합니다.']=(code,phase+' 단계에서 중지된 기록입니다.',action)


def diagnose(run, *, now, process, day, halted, max_gap):
    """Never infer the historical stop time/cause from current clock conditions."""
    note=run.get('note')
    code,message,action=NOTES.get(note,('UNCLASSIFIED','분류 가능한 중단 안내가 기록되어 있지 않습니다.',CHECK_ORDERS)) if isinstance(note,str) else ('UNCLASSIFIED','분류 가능한 중단 안내가 기록되어 있지 않습니다.',CHECK_ORDERS)
    result=[dict(basis='RECORDED',code=code,message=message,next_action=action)]
    if run['state']!='ARMED':
        return result
    observations=(
        (run['process']!=process,'PROCESS_CHANGED','현재 프로그램과 실행을 시작한 프로그램이 다릅니다.',CHECK_START),
        (now>=run['expires'],'EXPIRED','현재 실행 종료 시각을 지났습니다.',CHECK_START),
        (not 0<=now-run['heartbeat']<=max_gap,'HEARTBEAT_INVALID','최근 점검 시각이 허용 간격 밖이거나 현재보다 미래입니다.','화면 연결·프로그램 상태와 PC 시간을 확인하세요. '+CHECK_ORDERS),
        (halted,'NEW_ORDERS_HALTED','현재 계좌의 신규 주문 차단이 켜져 있습니다.',CHECK_ORDERS),
        (json.loads(run['config'])['day']!=day,'DAY_CHANGED','실행 기준일과 현재 한국시간 날짜가 다릅니다.',CHECK_START),
    )
    for matched,code,message,action in observations:
        if matched:result.append(dict(basis='CURRENT',code=code,message=message,next_action=action))
    return result
