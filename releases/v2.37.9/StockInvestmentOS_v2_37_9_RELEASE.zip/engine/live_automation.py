"""Explicitly started LIVE sessions. Capabilities exist only in the user's session."""
from dataclasses import dataclass, field
import hashlib
import json
import secrets
import time

from connectors.kis_broker import BrokerError
from engine.broker_execution import canonical
from engine.broker_market_session import check_kr_order_session
from engine.paper_automation import Automation, Permit, session_open

LIVE_URL = 'https://openapi.koreainvestment.com:9443'
LIVE_CONFIRMATION = '실전 자동매매 시작'


def live_only(client, account=None):
    if client.credentials.mode != 'LIVE' or client.base_url != LIVE_URL:
        raise BrokerError('실전투자 연결을 확인하세요.')
    if account is not None and client.credentials.identity != account:
        raise BrokerError('연결 계좌가 바뀌었습니다. 자동매매를 다시 설정하세요.')


@dataclass(frozen=True)
class LivePermit(Permit):
    connection: int = field(repr=False)
    intent: str = field(repr=False)


class LiveAutomation(Automation):
    mode = 'LIVE'

    def _check_client(self, client, account=None):
        live_only(client, account)

    @staticmethod
    def _intent(db, row):
        rules = [(r['idx'], json.loads(r['payload'])) for r in db.execute(
            'SELECT idx,payload FROM paper_rules WHERE run_id=? ORDER BY idx', (row['id'],))]
        value = [row['id'], row['account'], row['expires'], json.loads(row['config']), rules]
        return hashlib.sha256(canonical(value).encode()).hexdigest()

    def _run(self, db, permit):
        if type(permit) is not LivePermit:
            raise BrokerError('현재 세션의 실전 시작 확인이 없습니다.')
        row = super()._run(db, permit)
        if not secrets.compare_digest(permit.intent, self._intent(db, row)):
            raise BrokerError('시작할 때 확인한 조건·한도·종료 시간이 바뀌었습니다.')
        return row

    def arm(self, client, rules, budgets, minutes, *, confirmed=False, live_confirmation='', plan_reference=None):
        self._check_client(client)
        if confirmed is not True or live_confirmation != LIVE_CONFIRMATION:
            raise BrokerError('실전 주문 시작 확인란과 확인 문구를 직접 입력하세요.')
        # All aggregate checks are repeated by the engine, even without the UI.
        from engine.paper_rehearsal import rehearse
        report = rehearse(client, self.journal, rules, budgets, minutes, mode='LIVE')
        if report['blockers'] or report['status'] not in ('CHECKED', 'WAITING'):
            raise BrokerError('전체 조건 조회 점검을 통과하지 못했습니다.')
        permit = super().arm(client, rules, budgets, minutes, confirmed=confirmed, plan_reference=plan_reference)
        with self.journal.transaction() as db:
            row = db.execute('SELECT * FROM paper_runs WHERE id=?', (permit.run_id,)).fetchone()
            intent = self._intent(db, row)
        return LivePermit(permit.run_id, permit.account, permit.token, id(client), intent)

    def guard(self, client, permit):
        if type(permit) is not LivePermit or permit.connection != id(client):
            raise BrokerError('연결이 바뀌었습니다. 실전 자동매매를 다시 설정하세요.')
        super().guard(client, permit)

    def check_order_session(self, client, order):
        check_kr_order_session(client, order)
        if not session_open(order['market'], time.time()):
            raise BrokerError('확인된 정규 거래시간 밖입니다.')
