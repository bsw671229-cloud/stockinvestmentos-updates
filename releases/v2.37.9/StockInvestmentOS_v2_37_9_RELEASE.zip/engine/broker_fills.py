"""Cumulative gross fill evidence, separate from order state and realized profit."""
from datetime import datetime, timezone
from decimal import Decimal

from connectors.kis_broker import number, whole

REASONS={'AMOUNT_UNAVAILABLE','ZERO_QUANTITY_NONZERO_AMOUNT','NO_FILLED_QUANTITY',
    'CURRENCY_UNCONFIRMED','LIMIT_AMOUNT_CONFLICT','CUMULATIVE_AMOUNT_CONFLICT',
    'INCREMENT_AMOUNT_CONFLICT','MATCHED_ORDER_GROSS_AMOUNT','INVALID_AMOUNT'}


def execution_details(order, row, filled, previous=None):
    result = dict(schema_version=1, status='CHECK_REQUIRED', quantity=filled,
        currency=order['currency'], gross_amount=None, average_price=None,
        checked_at=datetime.now(timezone.utc).isoformat(), reason='AMOUNT_UNAVAILABLE')
    prior = previous or {}
    trusted = prior if prior.get('status')=='VERIFIED' else prior.get('last_verified', {})
    if trusted:
        result['last_verified'] = {k:trusted.get(k) for k in ('quantity','gross_amount')}
    try:
        kr = order['market']=='KR'
        raw = row.get('tot_ccld_amt' if kr else 'ft_ccld_amt3')
        if filled == 0:
            if raw not in (None, '') and number(raw) != 0:
                result['reason']='ZERO_QUANTITY_NONZERO_AMOUNT'; return result
            result.update(status='ZERO_FILL', gross_amount='0', reason='NO_FILLED_QUANTITY')
            return result
        if raw in (None, ''):
            return result
        if not kr and row.get('tr_crcy_cd')!='USD':
            result['reason']='CURRENCY_UNCONFIRMED'; return result
        amount = number(raw, positive=True)
        # At most one currency minor unit for cumulative amount rounding.
        tolerance = Decimal('1') if kr else Decimal('0.01')
        maximum = number(order['limit_price'])*filled
        if ((order['side']=='BUY' and amount>maximum+tolerance)
                or (order['side']=='SELL' and amount<maximum-tolerance)):
            result['reason']='LIMIT_AMOUNT_CONFLICT'; return result
        if trusted:
            old_qty, old_amount = whole(trusted['quantity']), number(trusted['gross_amount'], positive=True)
            if filled<old_qty or amount<old_amount or (filled==old_qty and amount!=old_amount):
                result['reason']='CUMULATIVE_AMOUNT_CONFLICT'; return result
            if filled>old_qty:
                increment = amount-old_amount
                limit = number(order['limit_price'])*(filled-old_qty)
                if increment<=0 or (order['side']=='BUY' and increment>limit+tolerance) or (order['side']=='SELL' and increment<limit-tolerance):
                    result['reason']='INCREMENT_AMOUNT_CONFLICT'; return result
        result.update(status='VERIFIED', gross_amount=str(amount), average_price=str(amount/filled),
            reason='MATCHED_ORDER_GROSS_AMOUNT')
        result.pop('last_verified',None)
    except Exception:
        result['reason']='INVALID_AMOUNT'
    return result


def fill_view(order, receipt):
    """Allowlisted presentation; older records do not imply zero fills or amounts."""
    view = dict(status='NOT_QUERIED', quantity=None, currency=order['currency'],
        gross_amount=None, average_price=None, checked_at=None, reason='NO_SAVED_FILL_CHECK')
    try:
        if 'filled_quantity' not in receipt: return view
        quantity = whole(receipt['filled_quantity'])
        if quantity>order['quantity']: return view
        view.update(status='CHECK_REQUIRED', quantity=quantity, reason='LEGACY_AMOUNT_UNAVAILABLE')
        detail = receipt.get('fill_details',{})
        if (detail.get('schema_version')!=1 or detail.get('quantity')!=quantity
                or detail.get('currency')!=order['currency']): return view
        stamp=datetime.fromisoformat(str(detail.get('checked_at','')))
        if stamp.tzinfo is None: return view
        view.update(checked_at=stamp.isoformat(),reason=detail.get('reason') if detail.get('reason') in REASONS else 'AMOUNT_UNAVAILABLE')
        if detail.get('status')=='ZERO_FILL' and quantity==0 and number(detail['gross_amount'])==0:
            view.update(status='ZERO_FILL',gross_amount='0')
        elif detail.get('status')=='VERIFIED' and quantity>0:
            amount=number(detail['gross_amount'],positive=True)
            view.update(status='VERIFIED',gross_amount=str(amount),average_price=str(amount/quantity))
    except Exception:
        view.update(status='CHECK_REQUIRED',gross_amount=None,average_price=None,reason='INVALID_SAVED_FILL')
    return view


def fill_totals(rules):
    totals={}
    seen=set()
    for rule in rules:
        reference=rule.get('order_reference')
        if not reference or reference in seen: continue
        seen.add(reference)
        c=rule['currency']; detail=rule['fill_details']
        group=totals.setdefault(c,dict(currency=c,buy_gross=Decimal(0),sell_gross=Decimal(0),
            known_orders=0,amount_check_required=0,not_queried=0))
        if detail['gross_amount'] is None:
            group['not_queried' if detail['status']=='NOT_QUERIED' else 'amount_check_required']+=1
        else:
            group['buy_gross' if rule['side']=='BUY' else 'sell_gross']+=number(detail['gross_amount'])
            group['known_orders']+=1
    return [{k:str(v) if isinstance(v,Decimal) else v for k,v in t.items()} for t in totals.values()]
