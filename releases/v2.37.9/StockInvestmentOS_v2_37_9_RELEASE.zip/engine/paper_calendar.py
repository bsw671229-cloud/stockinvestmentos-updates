"""Regular-session filter, with bounded published US calendar coverage."""
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo

AS_OF = '2026-10-21'
SOURCES = ('https://www.nyse.com/trade/hours-calendars',
           'https://nasdaqtrader.com/Trader.aspx?id=Calendar')
US_CLOSED_2026 = frozenset(('2026-01-01','2026-01-19','2026-02-16','2026-04-03',
    '2026-05-25','2026-06-19','2026-07-03','2026-09-07','2026-11-26','2026-12-25'))
US_EARLY_2026 = frozenset(('2026-11-27','2026-12-24'))


def session_status(market, stamp):
    if market not in ('KR','US'):
        return dict(open=False, local='', close='', reason='지원하지 않는 시장', coverage='NONE')
    zone = timezone(timedelta(hours=9)) if market == 'KR' else ZoneInfo('America/New_York')
    local = datetime.fromtimestamp(stamp, zone)
    day = local.strftime('%Y-%m-%d')
    minute = local.hour*60+local.minute
    low, high = (540,930) if market == 'KR' else (570,960)
    coverage = 'BASIC_HOURS_ONLY' if market == 'KR' else 'US_PUBLISHED_2026'
    reason = '정규시간 내' if market == 'US' else '기본시간 내 · 국내 휴장 미확인'
    if market == 'US' and local.year != 2026:
        reason = '미국 달력 갱신 필요 · 자동 주문 차단'
        coverage = 'OUT_OF_COVERAGE'
        allowed = False
    elif local.weekday() >= 5 or (market == 'US' and day in US_CLOSED_2026):
        reason = '주말·예정 휴장 · 대기'; allowed = False
    else:
        if market == 'US' and day in US_EARLY_2026:
            high = 780
            reason = '조기 종료일 · 13:00까지'
        allowed = low <= minute < high
        if not allowed:
            reason = '정규시간 외 · 대기'
    return dict(open=allowed, local=local.isoformat(timespec='seconds'),
        close=f'{high//60:02}:{high%60:02}', reason=reason, coverage=coverage)
