"""Local provenance for a run; never grants execution permission."""
import sqlite3
from connectors.kis_broker import BrokerError
from engine.broker_execution import digest
from engine.paper_plans import PlanStore, plan_payload, editor_values
from engine.plan_preview import preview

LABELS = {'DIRECT': '직접 작성', 'SAVED': '저장값 그대로',
          'MODIFIED': '불러온 뒤 수정', 'UNAVAILABLE': '원본 계획 확인 불가',
          'LEGACY': '계획 정보 없음 · 이전 기록'}


def resolve(journal, client, rules, budgets, minutes, reference=None, *, mode='PAPER'):
    current = plan_payload(rules, budgets, minutes, mode=mode)
    result = dict(status='DIRECT', execution_digest=digest(current))
    if reference is None:
        return result
    # Re-read the account/mode-bound source; a stale name alone proves nothing.
    result['status'] = 'UNAVAILABLE'
    try:
        if type(reference) is not dict or set(reference) != {'id', 'revision', 'digest'}:
            return result
        store = PlanStore(journal, mode=mode)
        row = next(r for r in store.list(client)
                   if r['id'] == reference['id'] and r['revision'] == reference['revision'])
        saved = store.load(client, row['id'], row['revision'])
        if digest(saved) != reference['digest']:
            return result
        normalized_rules, normalized_caps, normalized_minutes = editor_values(current, mode=mode)
        status = 'MODIFIED' if preview(saved, normalized_rules, normalized_caps, normalized_minutes, mode=mode)['changes'] else 'SAVED'
        result.update(status=status, plan_id=row['id'], name=row['name'],
                      revision=row['revision'], saved_digest=digest(saved))
    except (StopIteration, KeyError, TypeError, ValueError, OSError, sqlite3.Error, BrokerError):
        pass
    return result


def describe(origin):
    if not isinstance(origin, dict):
        return LABELS['LEGACY']
    label = LABELS.get(origin.get('status'), LABELS['LEGACY'])
    name = origin.get('name')
    return name + ' · ' + label if isinstance(name, str) and origin.get('status') in ('SAVED', 'MODIFIED') else label
