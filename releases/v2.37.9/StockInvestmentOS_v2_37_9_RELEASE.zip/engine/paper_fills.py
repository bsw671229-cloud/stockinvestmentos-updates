"""Explicit evidence-only refresh for terminal orders in the bound account/mode."""
from connectors.kis_broker import BrokerError
from engine.broker_execution import reconcile_order
from engine.broker_fills import fill_view
from engine.paper_recovery import _HistoryClient, history


def refresh_fills(automation,client,*,confirmed=False):
    if confirmed is not True: raise BrokerError('완료 주문 체결 금액 조회를 선택하세요.')
    automation._check_client(client)
    account=client.credentials.identity
    before=history(automation,client)
    references=list(dict.fromkeys(r['order_reference'] for run in before['runs'] for r in run['rules']
        if r['order_reference'] and r['state'] in ('FILLED','CANCELLED','REJECTED')))[:20]
    checked=failed=skipped=verified=uncertain=0
    reader=_HistoryClient(client,account,automation.mode)
    for reference in references:
        automation._check_client(client,account)
        try:
            record=automation.journal.get(reference,account)
            if record['payload']['mode']!=automation.mode: raise BrokerError('현재 연결 환경의 주문 기록이 아닙니다.')
            if record['status'] not in ('FILLED','CANCELLED','REJECTED'):
                skipped+=1; continue
            if not record['result'].get('order_no') or 'filled_quantity' not in record['result']:
                skipped+=1; continue
            updated=reconcile_order(reader,automation.journal,reference,refresh_terminal=True)
            checked+=1
            detail=fill_view(updated['payload']['order'],updated['result'])
            if detail['status'] in ('VERIFIED','ZERO_FILL'): verified+=1
            else: uncertain+=1
        except Exception:
            failed+=1  # Keep prior evidence and never export raw provider messages.
    automation._check_client(client,account)
    result=history(automation,client)
    result['fill_refresh']=dict(checked=checked,failed=failed,skipped=skipped,limit=20,
        amount_verified=verified,amount_check_required=uncertain,
        order_transmission='NOT_PERFORMED',scope='최근 10회 실행의 완료 주문 중 최대 20건')
    return result
