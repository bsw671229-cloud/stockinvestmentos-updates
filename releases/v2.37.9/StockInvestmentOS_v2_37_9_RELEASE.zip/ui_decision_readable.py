"""Display full literal values without changing decision data."""
def readable_metric(container, label, value):
    container.caption(label)
    container.text(value, width="stretch", wrap=True)

def flow_details(st, frame):
    with st.expander("흐름표 전체 설명 보기"):
        for _, row in frame.iterrows():
            st.text(" · ".join(str(v) for v in row.iloc[:2]) + "\n" + str(row.iloc[2]), width="stretch", wrap=True)
