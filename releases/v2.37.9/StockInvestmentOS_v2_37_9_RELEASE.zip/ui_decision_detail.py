"""Stage-specific display adapter; canonical values remain unchanged."""
import re

NUM = r"-?\d[\d,]*(?:\.\d+)?"

def flow_detail(stage, value, status_label, proof_label):
    """Translate only complete, stage-specific engine templates."""
    if not isinstance(value, str):
        return value
    if stage == '공통가정':
        m = re.fullmatch(rf'가격 ({NUM})원 / Downside ({NUM})% / No-Chase ({NUM})원', value)
        if m:
            return f'가격 {m[1]}원 / 하락 위험 {m[2]}% / 추격 매수 제한 {m[3]}원'
    elif stage == 'Price Gate':
        if value == 'No-Chase Ceiling이 필요합니다.':
            return '추격 매수 제한 가격이 필요합니다.'
        m = re.fullmatch(rf'현재가 ({NUM})원 (>|<=) No-Chase Ceiling ({NUM})원', value)
        if m:
            return f'현재가 {m[1]}원 {m[2]} 추격 매수 제한 가격 {m[3]}원'
    elif stage == 'Lifecycle':
        m = re.fullmatch(r'Evidence (PASS|REVIEW|BLOCKED)', value)
        if m:
            return f'근거 {status_label(m[1])}'
    elif stage == 'Thesis / Proof':
        m = re.fullmatch(r'Add Freeze (ON|OFF|REVIEW) / Proof (OPEN|CLOSED|OVERDUE|DUE SOON|NO DATE|NO PROOF)', value)
        if m:
            return f'추가 투자 보류 {status_label(m[1])} / 근거: {proof_label(m[2])}'
    elif stage == 'Portfolio Fit':
        m = re.fullmatch(rf'Portfolio 최대 추가 ({NUM})주', value)
        if m:
            return f'포트폴리오 최대 추가 {m[1]}주'
    elif stage == 'Factor Risk Repair':
        # Greedy prefix preserves the full user factor name, including English words.
        m = re.fullmatch(rf'(.+) ({NUM})% / Cap ({NUM})% / Excess ({NUM})%', value)
        if m:
            return f'{m[1]} {m[2]}% / 상한 {m[3]}% / 초과 {m[4]}%'
    elif stage == 'Capital Migration' and value == 'Recipient 자격만 표시 · Donor/Forward ER 비교는 Capital Migration에서':
        return '자본 유입 대상 자격만 표시 · 자본 제공 대상·향후 기대수익률 비교는 자본 이동 계획에서'
    return value


ACTION_DETAILS = {
    ('SYSTEM REVIEW', '공통값 또는 연결 중 REVIEW 항목을 먼저 확인합니다.'): '공통값 또는 연결 중 검토 필요 항목을 먼저 확인합니다.',
    ('ASSUMPTION REVIEW', '현재가격·Downside·No-Chase·Factor·Sector를 확인하고 승인합니다.'): '현재가격·하락 위험·추격 매수 제한·투자 요인·업종을 확인하고 승인합니다.',
    ('RISK REPAIR', '신규 Add보다 현재 비중을 위험한도 안으로 복구하는 것이 우선입니다.'): '신규 추가 투자보다 현재 비중을 위험한도 안으로 복구하는 것이 우선입니다.',
    ('ADD FREEZE', 'Add Freeze가 해제될 때까지 추가 위험을 늘리지 않습니다.'): '추가 투자 보류가 해제될 때까지 추가 위험을 늘리지 않습니다.',
    ('PORTFOLIO BLOCKED', '종목 자체보다 계좌 집중도/Headroom 제약이 우선입니다.'): '종목 자체보다 계좌 집중도·추가 투자 여력 제약이 우선입니다.',
    ('PORTFOLIO REVIEW', 'Factor/Sector/Headroom을 먼저 확인합니다.'): '투자 요인·업종·추가 투자 여력을 먼저 확인합니다.',
    ('EXECUTION BLOCKED', '현재 Lifecycle 또는 Price Gate가 실행을 허용하지 않습니다.'): '현재 투자 단계 또는 가격 조건이 실행을 허용하지 않습니다.',
    ('EXECUTION REVIEW', '현재 시스템 Gate가 실행 검토를 허용합니다. 자동매수 신호가 아니며 주문 전 최종 검토가 필요합니다.'): '현재 시스템 조건이 실행 검토를 허용합니다. 자동매수 신호가 아니며 주문 전 최종 검토가 필요합니다.',
    ('REVIEW', '결정에 필요한 일부 정보가 REVIEW 상태입니다.'): '결정에 필요한 일부 정보가 검토 필요 상태입니다.',
}

def action_detail(code, value):
    if not isinstance(code, str) or not isinstance(value, str):
        return value
    return ACTION_DETAILS.get((code, value), value)

def detail_frame(frame, status_label, proof_label):
    result = frame.copy(deep=True)
    if {'단계', '핵심'} <= set(result.columns):
        result['핵심'] = [flow_detail(s, v, status_label, proof_label)
                          for s, v in zip(result['단계'], result['핵심'])]
    return result
