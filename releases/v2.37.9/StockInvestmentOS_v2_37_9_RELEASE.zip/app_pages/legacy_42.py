from __future__ import annotations
from ui_korean import ko_text, ko_frame, ko_columns, ko_format
if True:
    st.title(ko_text('Rebalance Planner'))
    st.caption(ko_text('Trade Planner 위에 Portfolio-level cash reserve와 Reconciliation Gate를 추가합니다. 주문은 전송하지 않습니다.'))
    recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    pilot = st.number_input(ko_text('Initial Pilot Fraction of Risk Max'), 0.05, 1.0, float(settings.get('trade_plan_pilot_fraction', 0.5)), format='%.2f', key='rebalance_pilot')
    min_cash = st.number_input(ko_text('Minimum Cash Weight'), 0.0, 1.0, float(settings.get('minimum_cash_weight', 0.2)), format='%.2f')
    raw_plan = generate_trade_plan(state_df, portfolio, total_assets, loss_budget, single_cap, pilot)
    evidence_df = audit_evidence.copy()
    audit = data_quality_report(watchlist, evidence_df, int(settings.get('audit_price_freshness_days', 3)))
    if bool(settings.get('planner_requires_audit_ready', True)):
        raw_plan = apply_audit_gate(raw_plan, audit)
    funded_plan, summary = build_rebalance_summary(raw_plan, portfolio, total_assets, min_cash, recon['status'])
    c1, c2, c3, c4 = st.columns(4)
    c1.metric(ko_text('Reconciliation'), ko_text(recon['status']))
    c2.metric(ko_text('Current Cash'), ko_text(krw(summary.get('cash_value', 0))))
    c3.metric(ko_text('Minimum Cash'), ko_text(krw(summary.get('minimum_cash_value', 0))))
    c4.metric(ko_text('Funding Status'), ko_text(summary.get('status', '-')))
    c5, c6, c7 = st.columns(3)
    c5.metric(ko_text('Estimated Sells'), ko_text(krw(summary.get('estimated_sells', 0))))
    c6.metric(ko_text('Final Estimated Buys'), ko_text(krw(summary.get('final_estimated_buys', 0))))
    c7.metric(ko_text('Post-plan Cash Proxy'), ko_text(krw(summary.get('post_plan_cash_proxy', 0))))
    if recon['status'] != 'PASS':
        st.error(ko_text('Reconciliation mismatch 때문에 신규 BUY가 차단되어 있습니다.'))
    elif summary.get('status') == 'CASH_RESERVE_BLOCK':
        st.warning(ko_text('제안된 BUY가 Minimum Cash Weight를 침해하므로 신규 BUY가 차단되었습니다.'))
    else:
        st.info(ko_text('Funding layer를 통과해도 실제 주문 전 가격·Evidence·유동성을 다시 확인해야 합니다.'))
    st.dataframe(ko_frame(funded_plan), width='stretch', hide_index=True)
    st.download_button(ko_text('Rebalance Review CSV 받기'), funded_plan.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'rebalance_review.csv', 'text/csv')
