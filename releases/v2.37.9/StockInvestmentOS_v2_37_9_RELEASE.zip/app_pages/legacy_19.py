from __future__ import annotations
from ui_korean import ko_text, ko_frame, ko_columns, ko_format
if True:
    st.title(ko_text('Reconciliation'))
    st.caption(ko_text('총자산과 보유자산 합계가 맞는지 먼저 확인합니다. 불일치 상태에서는 Rebalance Planner의 신규 BUY를 차단합니다.'))
    tol = st.number_input(ko_text('허용 오차 (KRW)'), min_value=0, value=int(settings.get('reconciliation_tolerance_krw', 1000)), step=1000)
    recon = reconcile_portfolio(portfolio, total_assets, tol)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric(ko_text('Declared Total'), ko_text(krw(recon['declared_total_assets'])))
    c2.metric(ko_text('Known Portfolio'), ko_text(krw(recon['known_portfolio_value'])))
    c3.metric(ko_text('Gap'), ko_text(krw(recon['gap_krw'])))
    c4.metric(ko_text('Status'), ko_text(recon['status']))
    if recon['status'] == 'PASS':
        st.success(ko_text('총자산과 보유자산 합계가 허용오차 안에서 일치합니다.'))
    else:
        st.error(ko_text('총자산과 보유자산 합계가 맞지 않습니다. Portfolio 또는 Settings의 총자산을 먼저 수정하세요.'))
    rows = portfolio_rows_with_reconciliation(portfolio, total_assets)
    st.dataframe(ko_frame(rows), width='stretch', hide_index=True)
    st.subheader(ko_text('Cash'))
    st.write(ko_text(f"현금 평가액: **{krw(recon['cash_value_krw'])}** / 현금비중: **{pct(recon['cash_weight'])}**"))
    st.caption(ko_text("현금은 asset_type='cash' 또는 이름이 현금/Cash인 행을 기준으로 계산합니다."))
