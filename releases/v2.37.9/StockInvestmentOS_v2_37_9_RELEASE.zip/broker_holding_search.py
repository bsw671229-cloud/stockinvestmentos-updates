"""Shared, local-only search for displayed holding names and identifiers."""


def matches_holding(symbol, name, exchange, search):
    term = search.strip().casefold() if isinstance(search, str) else ''
    return not term or any(term in str(value or '').casefold()
                           for value in (symbol, name, exchange))
