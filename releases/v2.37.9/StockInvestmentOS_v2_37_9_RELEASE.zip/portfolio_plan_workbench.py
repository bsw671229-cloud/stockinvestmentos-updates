"""Manual joint portfolio review; no account access or stored portfolio changes."""
from datetime import datetime, timedelta, timezone
import json

import pandas as pd
import streamlit as st

from engine.portfolio_plan_v2 import review_plan

NAMES = dict(position_loss='종목 손실 예산', portfolio_loss='전체 손실 예산',
    single_name='종목 비중', factor='투자 요인 비중', liquidity='유동성',
    strategy='전략', capital='자본', existing_portfolio_loss='다른 종목의 손실 예산 초과',
    existing_factor_cap='같은 요인 내 다른 종목의 비중 초과')


def _percent(value):
    # Preserve malformed input for engine validation instead of dropping rows.
    return value / 100 if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def make_plan(rows, assets, budget, evidence):
    return dict(schema_version=1, assets=assets, budget=budget, evidence=evidence,
        positions=[dict(symbol=r.get('종목'), factor=r.get('투자 요인'),
            current_weight=_percent(r.get('현재 비중 (%)')),
            target_weight=_percent(r.get('목표 비중 (%)')),
            downside=_percent(r.get('하방 가정 (%)'))) for r in rows])


def render():
    st.title('포트폴리오 변경안 함께 검토')
    st.caption('현재 보유와 여러 종목의 목표 비중을 같은 손실 예산으로 비교합니다. 실제 보유 자료는 자동으로 읽지 않습니다.')
    st.info('기본값은 가상 예시입니다. 국내·해외 자산을 모두 원화로 평가한 총자산과 비중을 입력하세요. 자동 환전·시세 검증은 하지 않습니다.')
    kst = timezone(timedelta(hours=9))
    clock = st.session_state.setdefault('_pp_initial_clock', datetime.now(kst))
    with st.form('portfolio_plan', enter_to_submit=False):
        real = st.checkbox('예시가 아닌 실제 검토 입력입니다', key='pp_real')
        assets = st.number_input('포트폴리오 총자산 (원)', min_value=0.0, max_value=1e15,
            value=100000000.0, key='pp_assets')
        st.subheader('현재 보유와 목표 비중')
        st.caption('현금 이외의 보유를 모두 입력하세요. 목표는 추가 비중이 아닌 변경 후 전체 비중입니다. 신규 종목은 현재 0, 전량 정리는 목표 0으로 입력하세요. 미입력 비중은 현금으로 가정합니다.')
        initial = pd.DataFrame([
            {'종목': 'EXAMPLE_A', '투자 요인': '예시 성장', '현재 비중 (%)': 4.0, '목표 비중 (%)': 3.0, '하방 가정 (%)': 30.0},
            {'종목': 'EXAMPLE_B', '투자 요인': '예시 성장', '현재 비중 (%)': 2.0, '목표 비중 (%)': 3.0, '하방 가정 (%)': 25.0},
            {'종목': 'EXAMPLE_C', '투자 요인': '예시 배당', '현재 비중 (%)': 1.0, '목표 비중 (%)': 2.0, '하방 가정 (%)': 40.0}])
        rows = st.data_editor(initial, num_rows='dynamic', hide_index=True, key='pp_positions',
            alt='종목별 현재 비중, 목표 비중과 하방 가정 입력')
        st.caption('최대 100종목, 종목당 한 행·한 투자 요인입니다. 동일 종목은 같은 식별자를 사용하세요. ETF 내부 중복, 복수 요인, 공매도·차입·레버리지 파생상품은 이 계산에 반영하지 않습니다.')
        st.subheader('손실 예산과 비중 상한')
        budget = {}
        for key, label, default in (
            ('position_loss', '종목 허용손실 / 총자산 (%)', 1.0),
            ('portfolio_loss', '전체 허용손실 / 총자산 (%)', 3.0),
            ('single_name_cap', '종목별 비중 상한 (%)', 5.0),
            ('factor_cap', '같은 투자 요인 비중 상한 (%)', 25.0),
            ('liquidity_cap', '종목별 유동성 비중 상한 (%)', 10.0),
            ('strategy_cap', '종목별 전략 비중 상한 (%)', 10.0)):
            budget[key] = st.number_input(label, min_value=0.0, max_value=100.0,
                value=default, key='pp_'+key) / 100
        st.caption('종목 손실·종목 비중·유동성·전략 상한은 모든 종목에 공통 적용합니다. 투자 요인 상한은 같은 요인의 목표 비중 합계에 적용합니다.')
        source = st.text_input('보유·하방 가정의 출처 또는 원문 주소', value='가상 예시', key='pp_source')
        day = st.date_input('근거 확인 날짜 (한국시간)', value=clock.date(), key='pp_date')
        time = st.time_input('근거 확인 시각 (한국시간)', value=clock.time().replace(tzinfo=None, microsecond=0), key='pp_time')
        ttl = st.number_input('근거 유효 기간 (일)', min_value=1, max_value=365, value=3, key='pp_ttl')
        attested = st.checkbox('전체 보유·목표 비중·하방·출처·확인 시각을 검토했습니다', key='pp_attested')
        submitted = st.form_submit_button('포트폴리오 변경안 비교', key='pp_review')
    if not submitted:
        return
    records = rows.to_dict('records')
    if real and (source.strip() == '가상 예시' or any(
            str(r.get('종목', '')).strip().upper().startswith('EXAMPLE') or
            str(r.get('투자 요인', '')).strip().startswith('예시') for r in records)):
        st.error('실제 검토에서는 예시 종목·투자 요인·출처를 실제 입력으로 바꾸세요.')
        return
    evidence = dict(source=source, observed_at=datetime.combine(day, time, tzinfo=kst).isoformat(),
        max_age_days=int(ttl), user_attested=attested)
    plan = make_plan(records, assets, budget, evidence)
    result = review_plan(plan)
    if not real:
        st.warning('가상 예시 계산입니다. 실제 투자 판단이나 실행 근거로 사용할 수 없습니다.')
    if result['blockers']:
        for error in result['blockers']:
            st.error(error)
        return
    if result['status'] == 'BLOCKED':
        st.error('목표 포트폴리오가 입력한 위험 상한을 초과합니다. 아래 초과 항목을 검토하세요.')
    else:
        st.success('목표 포트폴리오가 입력한 기본 하방 가정의 위험 상한 이내입니다. 매수·매도 승인이 아닙니다.')
    st.caption('비교 버튼을 눌렀을 때의 입력 결과입니다. 입력을 편집하면 다시 비교하세요. 수익률 예측·주문·보유 자료 저장은 수행하지 않습니다.')
    st.table([
        {'항목': '투자 비중', '현재': f"{result['current_weight']:.2%}", '목표': f"{result['target_weight']:.2%}"},
        {'항목': '현금 비중', '현재': f"{result['current_cash']:.2%}", '목표': f"{result['target_cash']:.2%}"},
        {'항목': '가정 손실 / 총자산', '현재': f"{result['current_loss']:.2%}", '목표': f"{result['target_loss']:.2%}"},
        {'항목': '가정 손실 금액', '현재': f"{result['current_loss_amount']:,.0f}원", '목표': f"{result['target_loss_amount']:,.0f}원"},
        {'항목': '손실 예산 잔여 (음수는 초과)', '현재': f"{assets*result['current_headroom']:,.0f}원", '목표': f"{assets*result['target_headroom']:,.0f}원"}],
        alt='현재와 목표 포트폴리오의 현금과 가정 손실 비교')
    st.subheader('종목별 변경과 손실 기여')
    st.dataframe(pd.DataFrame([{'종목': r['symbol'], '현재 비중': f"{r['current_weight']:.2%}",
        '목표 비중': f"{r['target_weight']:.2%}", '비중 변화': f"{r['change_weight']*100:+.2f}%p",
        '변경 금액 (원)': round(r['change_amount']), '목표 가정 손실 (원)': round(r['target_loss']),
        '전체 가정 손실 중 비중': f"{r['loss_share']:.2%}", '다른 목표 고정 시 비중 상한': f"{r['max_weight']:.2%}",
        '제한 기준': ', '.join(NAMES[k] for k in r['limiting_factors']),
        '초과 항목': ', '.join(NAMES[k] for k in r['breaches']) or '없음'} for r in result['positions']]),
        hide_index=True, alt='종목별 목표 비중과 변경 금액, 가정 손실 및 위험 상한')
    st.caption('변경 금액은 현재 총자산 × 비중 차이이며 매매 수량이나 주문 금액이 아닙니다. 상한은 다른 종목의 목표 비중을 고정한 값이므로 각 상한을 동시에 채울 수 없습니다. 세금·비용·호가·유동성·환율 변동은 별도 검토하세요.')
    chart = pd.DataFrame([{'종목': r['symbol'], '현재 가정 손실': r['current_loss'],
        '목표 가정 손실': r['target_loss']} for r in result['positions']]).set_index('종목')
    st.bar_chart(chart, stack=False, alt='종목별 현재와 목표 가정 손실 금액 비교')
    st.subheader('투자 요인별 집중도')
    st.table([{'투자 요인': r['factor'], '현재 비중': f"{r['current_weight']:.2%}",
        '목표 비중': f"{r['target_weight']:.2%}", '상한': f"{r['cap']:.2%}",
        '목표 점검': '초과' if r['exceeded'] else '이내'} for r in result['factors']],
        alt='같은 투자 요인에 속한 종목의 합산 비중과 상한')
    st.subheader('하방 가정이 더 커질 때')
    st.table([{'입력 하방 배수': f"{r['multiplier']:g}배", '현재 가정 손실': f"{r['current_amount']:,.0f}원",
        '목표 가정 손실': f"{r['target_amount']:,.0f}원", '목표 손실 비율': f"{r['target_loss']:.2%}",
        '전체 손실 예산': '초과' if r['exceeds_budget'] else '이내'} for r in result['scenarios']],
        alt='입력 하방의 1배, 1.5배, 2배 시나리오별 손실 비교')
    st.caption('각 종목 하방은 100%에서 제한합니다. 배수는 확률·예측이 아니며 실제 최대손실을 보장하지 않습니다. '
        '모든 종목이 동시에 하락하는 단순 합산이고, 현금 하방은 0으로 가정합니다. 상관관계나 기업가치 분석은 포함하지 않습니다.')
    st.download_button('검토 입력·결과 내려받기', json.dumps(dict(example=not real, input=plan, result=result),
        ensure_ascii=False, indent=2), file_name='portfolio_review.json', mime='application/json',
        on_click='ignore', key='pp_download')
