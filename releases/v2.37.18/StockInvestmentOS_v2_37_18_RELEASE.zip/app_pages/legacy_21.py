from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('프로그램 업데이트 설치')
    from updater.operations_panel import render as render_local_operations
    render_local_operations(ROOT, key='local_ops_release', expanded=True)
    st.info('새 프로그램 버전을 확인·다운로드하고 검증 후 설치하는 화면입니다. 자동 동기화는 발견·다운로드까지이며, 승인과 설치는 직접 실행합니다.')
    st.caption('운영 준비 환경 자체 업데이트 / 백업 / 검증 / 자동 이전 버전 복원 관리 · 최종 배포만 자동 적용하며 data/와 .env는 보호합니다. 이전 완료 배치에서는 releases/backups/logs를 work/control에 저장합니다.')
    _rm_dirs = ensure_runtime_dirs(ROOT)
    _rm_status = release_manager_status_report(ROOT, include_candidates=False)
    rm1, rm2, rm3, rm4 = st.columns(4)
    rm1.metric('현재 버전', _locale.code(_rm_status['current_version']))
    rm2.metric('관리 대상 코드', _locale.code('정상' if _rm_status['managed_code_clean'] else '기준 이탈'))
    rm3.metric('승인됨 적격성', '미확인')
    rm4.metric('재시작 필요', _locale.code('금지' if restart_status(ROOT, APP_RUNTIME)['eligible'] else 'YES'))
    if _rm_status['managed_code_clean']:
        st.success('현재 파일 명세 기준 관리 대상 코드 무결성 = 정상.')
    else:
        st.error('현재 관리 대상 코드 기준 이탈이 있습니다. 자동 업데이트는 로컬 변경 보호를 위해 차단됩니다.')
        st.json(_rm_status['drift'])
    st.info('작업 자동화 경로: releases/inbox → SHA-256 + 검증 정상 승인 → releases/approved → 거래 단위 백업/적용 → 사후-적용 검증 → 실패 시 자동 이전 버전 복원. 실행 중인 Streamlit 프로세스는 업데이트 도구가 직접 재시작하지 않습니다.')
    with st.expander('배포 관리 로컬 경로', expanded=False):
        st.json(_rm_status['paths'])
    st.subheader('0) 신뢰 배포본 업데이트 목록 / 자동 수신함 동기화')
    _feed_status = trusted_release_feed_status(ROOT)
    _feed_config = _feed_status.get('config', {})
    _feed_last = _feed_status.get('last_state', {})
    tf1, tf2, tf3, tf4 = st.columns(4)
    tf1.metric('신뢰 업데이트 목록', _locale.code(_feed_status.get('status', 'DISABLED')))
    tf2.metric('자동 동기화', _locale.code('켜짐' if _feed_config.get('auto_sync') and _feed_config.get('enabled') else '꺼짐'))
    tf3.metric('업데이트 목록 배포 경로', _locale.code(_feed_config.get('channel', 'stable')))
    tf4.metric('마지막 업데이트 목록 상태', _locale.code(_feed_last.get('status', '-')))
    st.caption('신뢰 배포본 업데이트 목록을 한 번 설정하면 새 최종 배포를 자동 발견·다운로드·검증하여 work/control/releases/inbox로 동기화합니다. v1.54-updater2-dev1은 승인/적용은 자동 수행하지 않습니다.')
    _feed_url = st.text_input('신뢰 release_feed.json 주소', value=str(_feed_config.get('feed_url', '')), key='trusted_release_feed_url', placeholder='https://updates.example.com/release_feed.json')
    _feed_hosts_text = st.text_input('허용할 보안 웹 호스트(쉼표로 구분)', value=', '.join(_feed_config.get('allowed_hosts', [])), key='trusted_release_feed_hosts', placeholder='updates.example.com')
    _feed_channel = st.text_input('배포 배포 경로', value=str(_feed_config.get('channel', 'stable')), key='trusted_release_feed_channel')
    tfc1, tfc2, tfc3 = st.columns(3)
    with tfc1:
        _feed_enabled = st.checkbox('신뢰 업데이트 목록 사용', value=bool(_feed_config.get('enabled', False)), key='trusted_release_feed_enabled')
    with tfc2:
        _feed_auto_sync = st.checkbox('앱 실행 시 주기적으로 검증됨 배포를 수신함에 자동 동기화', value=bool(_feed_config.get('auto_sync', False)), key='trusted_release_feed_auto_sync')
    with tfc3:
        _feed_interval = st.number_input('확인 구간 (분)', min_value=5, max_value=1440, value=int(_feed_config.get('check_interval_minutes', 60)), step=5, key='trusted_release_feed_interval')
    if st.button('신뢰 업데이트 목록 설정 저장', key='trusted_release_feed_save'):
        _feed_hosts = [x.strip() for x in _feed_hosts_text.split(',') if x.strip()]
        _feed_save = save_trusted_feed_config(ROOT, feed_url=_feed_url, allowed_hosts=_feed_hosts, channel=_feed_channel, enabled=_feed_enabled, auto_sync=_feed_auto_sync, check_interval_minutes=int(_feed_interval))
        if _feed_save.get('status') == 'SAVED':
            st.success('신뢰 배포본 업데이트 목록 설정을 work/control에 저장했습니다.')
        else:
            st.error(_locale.message('신뢰 업데이트 목록 설정 차단됨 · ' + ' | '.join(_feed_save.get('blockers', []))))
        st.json(_feed_save)
    fbc1, fbc2 = st.columns(2)
    with fbc1:
        if st.button('신뢰 업데이트 목록 확인 (읽기 전용)', key='trusted_release_feed_check'):
            _feed_check = check_trusted_release_feed(ROOT)
            if _feed_check.get('status') == 'UPDATE_AVAILABLE':
                st.success(f"새 배포 발견 · {_feed_check.get('current_version')} → {_feed_check.get('target_version')}")
            elif _feed_check.get('status') == 'UP_TO_DATE':
                st.info('신뢰 업데이트 목록 기준 현재 버전이 최신입니다.')
            elif _feed_check.get('status') == 'DISABLED':
                st.info('신뢰 업데이트 목록이 비활성화되어 있습니다.')
            else:
                st.error('신뢰 업데이트 목록 확인 차단됨')
            st.json(_feed_check)
    with fbc2:
        if st.button('검증됨 배포 자동 다운로드 → 수신함', key='trusted_release_feed_sync'):
            _feed_sync = sync_trusted_release_to_inbox(ROOT)
            if _feed_sync.get('status') == 'SYNCED_TO_INBOX':
                st.success(f"검증됨 배포 자동 동기화 완료 · 대상 {_feed_sync.get('target_version')} · 이제 미리보기/승인을 진행할 수 있습니다.")
            elif _feed_sync.get('status') in {'UP_TO_DATE', 'NOT_DUE'}:
                st.info('동기화할 새 배포가 없습니다.')
            else:
                st.warning(f"신뢰 업데이트 목록 동기화 상태: {_locale.code(_feed_sync.get('status', 'BLOCKED'))}")
            st.json(_feed_sync)
    if _feed_last:
        with st.expander('신뢰 업데이트 목록 마지막 상태', expanded=False):
            st.json(_feed_last)
    st.info('업데이트 도구 2 경로: 신뢰 업데이트 목록 → 호스트 고정 → 배포 패키지 SHA-256 → 검증 정상 → 내부 파일 명세 → 미리보기 적격성 → 일괄 처리 수신함 동기화. 이 단계에서는 자동 승인/적용을 수행하지 않습니다.')
    st.subheader('0A) 안전 업데이트 · 단계별 진행')
    st.caption('자동 전체 검사는 하지 않습니다. 아래 버튼으로 상태를 읽으세요. 결과는 조회 시점의 정보이며 실제 작업 직전에는 다시 검증합니다.')
    if st.button('0A 상태 확인 / 새로 읽기', key='suo_status_load'):
        with st.spinner('상태·코드 무결성·복구 백업 확인 중 — 완료까지 기다려 주세요'):
            st.session_state['_suo_status_snapshot'] = safe_update_orchestrator_status(ROOT)
    _suo_status = st.session_state.get('_suo_status_snapshot')
    if st.session_state.get('_suo_status_refresh_notice'):
        st.warning(_locale.message(st.session_state.pop('_suo_status_refresh_notice')))
    if not _suo_status:
        st.info('화면 준비 완료. ‘0A 상태 확인 / 새로 읽기’를 누르면 검사를 시작합니다.')
        st.stop()
    with st.container(horizontal=True):
        st.metric('통합 관리', _locale.code(_suo_status.get('status', 'REVIEW')), width='content')
        st.metric('현재', _locale.code(_suo_status.get('current_version', '-')), width='content')
        st.metric('관리 대상 코드', _locale.code('정상' if _suo_status.get('managed_code_clean') else '기준 이탈'), width='content')
        st.metric('게시됨', _locale.code(_suo_status.get('latest_published_version', '-')), width='content')
        st.metric('전체 작동 점검', _locale.code(_suo_status.get('e2e_health', 'REVIEW')), width='content')
        st.metric('복구', _locale.code(_suo_status.get('recovery_status', 'REVIEW')), width='content')
    st.caption('0A는 아래 0B~0E의 검증된 절차를 묶어 반복 클릭을 줄입니다. 자동 승인 / 자동 설치는 켜지지 않으며, 원격 게시와 실제 설치는 각각 명시적 확인 1회가 필요합니다.')
    _suo_dashboard = _suo_status.get('dashboard') or {}
    st.markdown('**업데이트 상태와 다음 행동**')
    st.caption('상태 읽은 시각: ' + str(_suo_dashboard.get('observed_at', 'UNKNOWN')) + ' · 마지막 단계: ' + str(_suo_dashboard.get('last_stage', 'UNKNOWN')) + ' / ' + str(_suo_dashboard.get('last_status', 'NOT_RUN')) + ' · 대상: ' + str(_suo_dashboard.get('last_target_version', 'UNKNOWN')) + ' · 결과 시각: ' + str(_suo_dashboard.get('last_evidence_at', 'UNKNOWN')))
    st.info(_locale.message(_suo_dashboard.get('next_action', '0D/0E 상세 근거를 확인하세요.')))
    for _suo_conflict in _suo_dashboard.get('conflicts', []):
        st.warning(_locale.message(_suo_conflict))
    with st.expander('상태 근거 / 확인 시점', expanded=False):
        st.caption('evaluated_at은 로컬 평가 시각입니다. saved_evidence_at은 저장된 검사 근거의 시각이며 알 수 없음은 미확인입니다. 공개 검증은 새 네트워크 검사 결과가 아닙니다.')
        _locale.dataframe(st, _suo_dashboard.get('evidence', []), use_container_width=True)
    with st.expander('업데이트 이력 / 최근 500건', expanded=False):
        _suo_history = _suo_status.get('history') or {}
        for _suo_warning in _suo_history.get('warnings', []):
            st.warning(_locale.message(_suo_warning))
        if (_suo_status.get('last_orchestrator_state') or {}).get('audit_history', {}).get('recorded') is False:
            st.warning('마지막 동작의 이력 저장에 실패했습니다. 동작 결과와 기존 기록부를 확인하세요. 이력 문제만으로 설치/게시를 재실행하지 마세요.')
        st.caption('LOCAL_PUBLISH는 설치 완료가 아닙니다. 복구 모의 점검은 실제 이전 버전 복원이 아닙니다. 기존 기록부와 단계별 시도 기록을 함께 표시합니다.')
        _locale.dataframe(st, _suo_history.get('rows', []), use_container_width=True)
    if st.button('상태 다시 읽기', key='safe_update_observability_refresh'):
        st.session_state.pop('_suo_status_snapshot', None)
        st.rerun()
    st.caption('파일 목록은 이름 기준이며 SHA·검증·승인 검증 결과가 아닙니다. 선택한 배포의 사전 검사와 실제 실행 직전 검증은 새로 수행합니다.')
    _suo_candidates = release_manager_scan_candidates(ROOT)
    _suo_inbox = [row for row in _suo_candidates if row.get('scope') == 'inbox' and row.get('path') and row.get('target_version')]
    _suo_inbox_options = {f"{row.get('package', '')} · {row.get('target_version', '')}": row.get('path') for row in _suo_inbox}
    st.markdown('**A. 새 배포 승인 + 게시 + GitHub 배포 + 공개 검증**')
    _suo_inbox_label = st.selectbox('수신함 배포', [''] + list(_suo_inbox_options.keys()), key='safe_update_orchestrator_inbox')
    _suo_expected_sha = st.text_input('게시됨 배포 SHA-256', value='', key='safe_update_orchestrator_expected_sha', placeholder='64자리 SHA-256').strip()
    _suo_preflight_key = (_suo_inbox_label, _suo_expected_sha)
    if st.button('선택 업데이트 사전 검사', key='suo_preflight_run', disabled=not (_suo_inbox_label and len(_suo_expected_sha) == 64)):
        with st.spinner('선택한 RELEASE의 SHA·Validation·manifest 검사 중'):
            st.session_state['_suo_preflight_snapshot'] = (_suo_preflight_key, safe_update_preflight_inbox_release(ROOT, Path(_suo_inbox_options[_suo_inbox_label]), _suo_expected_sha))
    _suo_saved_preflight = st.session_state.get('_suo_preflight_snapshot')
    _suo_preflight = _suo_saved_preflight[1] if _suo_saved_preflight and _suo_saved_preflight[0] == _suo_preflight_key else None
    if _suo_preflight:
        st.caption('사전 검사 버튼 실행 시점의 결과입니다. 게시 실행 시 새로 검증합니다.')
        sp1, sp2, sp3, sp4 = st.columns(4)
        sp1.metric('대상', _locale.code(_suo_preflight.get('target_version', '-')))
        sp2.metric('사전 검사', _locale.code('정상' if _suo_preflight.get('eligible') else '차단됨'))
        sp3.metric('SHA', _locale.code('일치' if _suo_preflight.get('sha256_match') else '불일치'))
        sp4.metric('검증', _locale.code('정상' if _suo_preflight.get('validation_report_pass') else '실패'))
        if _suo_preflight.get('blockers'):
            st.error(_locale.message('안전 업데이트 사전 검사 차단됨 · ' + ' | '.join(_suo_preflight.get('blockers', []))))
        if _suo_preflight.get('warnings'):
            st.warning(_locale.message(' | '.join(_suo_preflight.get('warnings', []))))
    elif _suo_inbox_label:
        st.info('공개된 배포 SHA-256 64자리를 입력하면 승인/게시/배포 전 사전 검사가 자동 실행됩니다.')
    _suo_publish_confirm = st.checkbox('SHA-256/검증/미리보기가 정상인 배포만 승인하고, 로컬 게시 → 원격 저장소 전송 → 공개 업데이트 목록 검증까지 실행합니다.', key='safe_update_orchestrator_publish_confirm')
    _suo_release_result_key = '_safe_update_orchestrator_release_result'
    _suo_last_release_result = st.session_state.pop(_suo_release_result_key, None)
    if st.button('업데이트 승인·게시·배포·검증', type='primary', key='safe_update_orchestrator_release', disabled=not (_suo_publish_confirm and _suo_preflight and _suo_preflight.get('eligible'))):
        _suo_release_result = safe_update_approve_publish_deploy(ROOT, Path(_suo_inbox_options[_suo_inbox_label]), _suo_expected_sha)
        st.session_state[_suo_release_result_key] = _suo_release_result
        st.rerun()
    if _suo_last_release_result:
        if _suo_last_release_result.get('status') == 'RELEASE_READY_TO_INSTALL':
            st.success('배포 승인 + 로컬 게시 + GitHub 배포 + 공개 업데이트 목록 검증 완료. 이제 설치 확인 1회만 남았습니다.')
        elif _suo_last_release_result.get('status') == 'DEPLOYED_VERIFY_PENDING':
            st.warning('게시 처리는 완료됐지만 공개 피드 검증은 아직 완료되지 않았습니다. 아래 ‘공개 피드 반영 확인’ 버튼으로 검증하세요. 반영되지 않으면 GitHub 배포 작업의 최신 Pages 배포 결과를 확인하세요.')
        else:
            st.error('안전 업데이트 배포 통합 처리 차단됨/검토')
        with st.expander('배포 통합 처리 투자 근거', expanded=False):
            st.json(_suo_last_release_result)
    if st.button('공개 피드 반영 확인', key='suo_public_verify_only'):
        with st.spinner('공개 피드와 배포 파일을 검증하고 있습니다'):
            st.session_state['_suo_public_verify_result'] = verify_public_deployment(ROOT)
        _suo_discarded_ready = st.session_state.pop('_suo_readiness_snapshot', None)
    _suo_public_result = st.session_state.get('_suo_public_verify_result')
    if _suo_public_result:
        if _suo_public_result.get('status') == 'PUBLIC_FEED_VERIFIED':
            st.success('공개 피드 검증 통과 · 대상 업데이트를 선택하고 ‘선택 배포 설치 전 검사’를 누르세요.')
        else:
            st.warning('공개 피드 검증 미완료 · 아래 결과와 GitHub 배포 작업의 Pages 배포 결과를 확인하세요.')
        with st.expander('공개 피드 검증 결과', expanded=False):
            st.json(_suo_public_result)
    st.markdown('**B. 공개 검증이 끝난 승인됨 배포 설치**')
    _suo_candidates_after = _suo_candidates
    _suo_approved = [row for row in _suo_candidates_after if row.get('scope') == 'approved' and row.get('newer_than_current') and row.get('path')]
    _suo_approved_options = {f"{row.get('package', '')} · {row.get('target_version', '')}": row.get('path') for row in _suo_approved}
    _suo_approved_label = st.selectbox('승인됨 배포 — 선택 후 검증', [''] + list(_suo_approved_options.keys()), key='safe_update_orchestrator_approved')
    if st.button('선택 배포 설치 전 검사', key='suo_readiness_run', disabled=not _suo_approved_label):
        with st.spinner('설치 전 승인·SHA·Validation·무결성 확인 중'):
            st.session_state['_suo_readiness_snapshot'] = (_suo_approved_label, safe_update_install_readiness(ROOT, Path(_suo_approved_options[_suo_approved_label]), live_verify=False))
    _suo_saved_ready = st.session_state.get('_suo_readiness_snapshot')
    _suo_install_ready = _suo_saved_ready[1] if _suo_saved_ready and _suo_saved_ready[0] == _suo_approved_label else None
    if _suo_install_ready:
        st.caption('검사 버튼 실행 시점의 결과입니다. 실제 설치 시 새로 검증합니다.')
        with st.container(horizontal=True):
            st.metric('대상', _locale.code(_suo_install_ready.get('target_version', '-')), width='content')
            st.metric('설치 점검', _locale.code('준비 완료' if _suo_install_ready.get('eligible') else '차단됨'), width='content')
            with st.container(width='content'):
                st.caption('공개 검증')
                st.text((_suo_install_ready.get('public_verify') or {}).get('status', 'NONE'), width='stretch', wrap=True)
        if _suo_install_ready.get('blockers'):
            st.warning(_locale.message('설치 차단됨 · ' + ' | '.join(_suo_install_ready.get('blockers', []))))
    _suo_install_confirm = st.checkbox('공개 업데이트 목록의 버전/SHA를 확인하고 설치를 승인합니다. 실패 시 이번 설치 트랜잭션을 자동 복원합니다. 별도 버전 이전 버전 복원 승인은 포함하지 않습니다.', key='safe_update_orchestrator_install_confirm')
    _suo_install_result_key = '_safe_update_orchestrator_install_result'
    _suo_last_install_result = st.session_state.pop(_suo_install_result_key, None)
    if st.button('검증된 업데이트 설치', type='primary', key='safe_update_orchestrator_install', disabled=not (_suo_install_confirm and _suo_install_ready and _suo_install_ready.get('eligible'))):
        with st.status('설치 진행 중 — 종료하지 마세요', expanded=True) as _suo_progress:
            st.session_state[_suo_install_result_key] = safe_update_install_verified_release(ROOT, Path(_suo_approved_options[_suo_approved_label]), progress=st.write)
            _suo_progress.update(label='설치 작업 종료 — 결과를 확인하세요', state='complete' if st.session_state[_suo_install_result_key].get('status') == 'INSTALL_APPLIED_RESTART_REQUIRED' else 'error')
        for _suo_key in ('_suo_status_snapshot', '_suo_readiness_snapshot', '_suo_preflight_snapshot'):
            _suo_discarded_snapshot = st.session_state.pop(_suo_key, None)
        if st.session_state[_suo_install_result_key].get('status') == 'INSTALL_APPLIED_RESTART_REQUIRED':
            st.success('설치 완료 · 프로그램을 종료하고 다시 실행한 뒤 ‘설치 후 작동·복구 최종 점검’을 실행하세요.')
        else:
            st.error('설치가 완료되지 않았습니다. 아래 결과를 확인하세요.')
        st.json(st.session_state[_suo_install_result_key])
        st.stop()
    if _suo_last_install_result:
        if _suo_last_install_result.get('status') == 'INSTALL_APPLIED_RESTART_REQUIRED':
            st.success('설치 완료 · 앱을 종료 후 다시 실행하고 ‘설치 후 작동·복구 최종 점검’을 실행하세요.')
        else:
            st.error('안전 업데이트 설치 차단됨/실패 · 상세 근거를 확인하세요.')
        st.json(_suo_last_install_result)
    st.markdown('**C. 재시작 후 전체 작동 점검 + 복구 최종검사**')
    _suo_runtime_gate = restart_status(ROOT, APP_RUNTIME)
    render_restart_status(_suo_runtime_gate)
    _suo_finalize_result_key = '_safe_update_orchestrator_finalize_result'
    _suo_last_finalize = st.session_state.pop(_suo_finalize_result_key, None)
    if st.button('설치 후 작동·복구 최종 점검', key='safe_update_orchestrator_finalize', disabled=not _suo_runtime_gate['eligible']):
        _suo_finalize_result = guarded_finalize(ROOT, APP_RUNTIME, safe_update_finalize_after_restart)
        store_finalize_result(st.session_state, ROOT, _suo_finalize_result, safe_update_orchestrator_status)
        st.rerun()
    if _suo_last_finalize:
        render_finalize_result(_suo_last_finalize, _suo_runtime_gate)
    st.info('앞으로 일반 업데이트는 0A만 사용하면 됩니다: ① SHA 입력 후 업데이트 승인·게시·배포·검증 → ② 검증된 업데이트 설치 → 재시작 → ③ 설치 후 작동·복구 최종 점검. 0B~0E는 상세 점검/복구용 고급 설정으로 유지됩니다.')
    if not st.checkbox('고급 설정 / 0B~0E 상세 검사 열기', key='suo_advanced_open', value=False):
        st.caption('상세 검사는 열었을 때만 실행합니다.')
        st.stop()
    st.subheader('0B) 배포 게시 관리 / 업데이트 목록 생성 / 신뢰 저장소 관리')
    _publisher_repo_default = default_repository_root(ROOT)
    _publisher_status = publisher_status(ROOT, repository_root=_publisher_repo_default)
    pub1, pub2, pub3, pub4 = st.columns(4)
    pub1.metric('게시 도구', _locale.code(_publisher_status.get('status', 'NOT_INITIALIZED')))
    pub2.metric('최신 게시됨', _locale.code(_publisher_status.get('latest_published_version', '-')))
    pub3.metric('저장소', 'work/control')
    pub4.metric('투자 실행 권한', '없음')
    st.caption('최종 배포를 정적 신뢰 저장소 구조로 게시하고 release_feed.json을 자동 생성합니다. 저장소는 work/control 안에 유지되며 원격 보안 웹 연결 업로드 자체는 이 단계에서 수행하지 않습니다.')
    _publisher_candidates = [row for row in release_manager_scan_candidates(ROOT) if row.get('target_version') and row.get('path')]
    _publisher_options = {f"{row.get('scope', '')} · {row.get('package', '')} · {row.get('target_version', '')}": row.get('path') for row in _publisher_candidates}
    _publisher_label = st.selectbox('최종 배포 후보 대상 게시', [''] + list(_publisher_options.keys()), key='trusted_release_publisher_candidate')
    _publisher_repository = st.text_input('로컬 신뢰 저장소 기준 경로', value=str(_publisher_repo_default), key='trusted_release_publisher_repository')
    _publisher_base_url = st.text_input('공개 보안 웹 연결 기준 주소', value='', key='trusted_release_publisher_base_url', placeholder='https://updates.example.com/stock-investment-os')
    _publisher_feed_id = st.text_input('업데이트 목록 식별번호', value='stock-investment-os-stable', key='trusted_release_publisher_feed_id')
    _publisher_channel = st.text_input('게시 도구 배포 경로', value='stable', key='trusted_release_publisher_channel')
    pbc1, pbc2 = st.columns(2)
    with pbc1:
        if st.button('게시 도구 미리보기', key='trusted_release_publisher_preview', disabled=not _publisher_label or not _publisher_base_url.strip()):
            _publisher_preview = preview_release_publish(ROOT, Path(_publisher_options[_publisher_label]), repository_root=_publisher_repository, public_base_url=_publisher_base_url, channel=_publisher_channel, feed_id=_publisher_feed_id)
            if _publisher_preview.get('status') == 'READY_TO_PUBLISH':
                st.success(f"게시 도구 준비 완료 · 대상 {_publisher_preview.get('target_version')} · 업데이트 목록 {_publisher_preview.get('feed_url')}")
            else:
                st.error('게시 도구 미리보기 차단됨')
            st.json(_publisher_preview)
    with pbc2:
        _publisher_confirm = st.checkbox('검증된 최종 배포를 로컬 신뢰 저장소에 게시하고 release_feed.json을 갱신합니다.', key='trusted_release_publisher_confirm')
        if st.button('게시 배포 + 생성 업데이트 목록', key='trusted_release_publisher_publish', disabled=not _publisher_label or not _publisher_base_url.strip() or (not _publisher_confirm)):
            _publisher_result = publish_release_repository(ROOT, Path(_publisher_options[_publisher_label]), repository_root=_publisher_repository, public_base_url=_publisher_base_url, channel=_publisher_channel, feed_id=_publisher_feed_id)
            if _publisher_result.get('status') == 'PUBLISHED_LOCAL_REPOSITORY':
                st.success(f"배포 게시 관리 완료 · {_publisher_result.get('target_version')} · release_feed.json 생성 완료.")
            else:
                st.error('배포 게시 관리 차단됨')
            st.json(_publisher_result)
    st.info('게시 도구는 업데이트 목록/저장소를 생성하지만 인터넷 호스트로 업로드하지는 않습니다. 한 번 정적 보안 웹 연결 호스팅과 이 저장소를 연결하면 클라이언트의 신뢰 업데이트 목록 주소는 고정되고 이후 배포 ZIP/TXT 수동 다운로드·수신함 복사가 사라집니다.')
    st.subheader('0C) 보안 정적 사이트 배포 연결 / 원격 저장소 전송 / 업데이트 목록 초기 연결')
    _deploy_status = deployment_status(ROOT)
    _deploy_config = load_deployment_config(ROOT)
    dep1, dep2, dep3, dep4 = st.columns(4)
    dep1.metric('배포', _locale.code(_deploy_status.get('status', 'DISABLED')))
    dep2.metric('Git', _locale.code('준비 완료' if _deploy_status.get('git_available') else '누락'))
    dep3.metric('공개 업데이트 목록', _locale.code('검증됨' if _deploy_status.get('last_state', {}).get('status') == 'PUBLIC_FEED_VERIFIED' else '-'))
    dep4.metric('투자 실행 권한', '없음')
    st.caption('로컬 신뢰 저장소를 Git 원격에 원격 전송하고 고정 보안 웹 연결 release_feed.json을 검증합니다. Git 인증정보/토큰은 주식 투자 운영 시스템에 저장하지 않습니다.')
    _deploy_repo = st.text_input('배포 저장소 기준 경로', value=str(_deploy_config.get('repository_root', default_repository_root(ROOT))), key='trusted_repository_deployment_repo')
    _deploy_remote_url = st.text_input('Git 원격 주소', value=str(_deploy_config.get('remote_url', '')), key='trusted_repository_deployment_remote', placeholder='https://github.com/<USER>/<REPO>.git')
    dc1, dc2 = st.columns(2)
    with dc1:
        _deploy_branch = st.text_input('배포 브랜치', value=str(_deploy_config.get('branch', 'main')), key='trusted_repository_deployment_branch')
    with dc2:
        _deploy_remote_name = st.text_input('Git 원격 이름', value=str(_deploy_config.get('remote_name', 'origin')), key='trusted_repository_deployment_remote_name')
    _deploy_public_base = st.text_input('공개 보안 웹 연결 기준 주소', value=str(_deploy_config.get('public_base_url', '')), key='trusted_repository_deployment_public_base', placeholder='https://<USER>.github.io/<REPO>')
    _deploy_interval = st.number_input('클라이언트 자동 동기화 구간 (분)', min_value=5, max_value=1440, value=int(_deploy_config.get('client_check_interval_minutes', 60)), step=5, key='trusted_repository_deployment_interval')
    if st.button('배포 설정 저장', key='trusted_repository_deployment_save'):
        _deploy_save = save_deployment_config(ROOT, repository_root=_deploy_repo, remote_url=_deploy_remote_url, public_base_url=_deploy_public_base, remote_name=_deploy_remote_name, branch=_deploy_branch, enabled=True, auto_bootstrap_client_feed=True, client_check_interval_minutes=int(_deploy_interval))
        if _deploy_save.get('status') == 'SAVED':
            st.success('정적 보안 웹 연결 배포 설정을 work/control에 저장했습니다.')
        else:
            st.error(_locale.message('배포 설정 차단됨 · ' + ' | '.join(_deploy_save.get('blockers', []))))
        st.json(_deploy_save)
    dca, dcb, dcc = st.columns(3)
    with dca:
        if st.button('Git 저장소 초기화 / 연결', key='trusted_repository_deployment_connect'):
            _deploy_connect = connect_git_repository(ROOT)
            if _deploy_connect.get('status') == 'CONNECTED':
                st.success('Git 저장소/원격 연결 완료. 인증정보는 앱에 저장하지 않습니다.')
            else:
                st.error('Git 저장소 연결 차단됨')
            st.json(_deploy_connect)
    with dcb:
        if st.button('배포 미리보기', key='trusted_repository_deployment_preview'):
            _deploy_preview = preview_deployment(ROOT)
            if _deploy_preview.get('status') == 'READY_TO_DEPLOY':
                st.success(f"배포 준비 완료 · 대상 {_deploy_preview.get('target_version')} · {_deploy_preview.get('public_feed_url')}")
            else:
                st.error('배포 미리보기 차단됨')
            st.json(_deploy_preview)
    with dcc:
        _deploy_push_confirm = st.checkbox('검증된 신뢰 저장소를 설정된 Git 원격/브랜치로 변경 기록 + 원격 전송합니다.', key='trusted_repository_deployment_push_confirm')
        if st.button('Git 변경 기록 + 원격 전송', key='trusted_repository_deployment_push', disabled=not _deploy_push_confirm):
            _deploy_push = deploy_repository(ROOT)
            if _deploy_push.get('status') == 'DEPLOYED_TO_GIT_REMOTE':
                st.success(f"Git 배포 완료 · 변경 기록 {_deploy_push.get('commit_hash', '')[:12]}")
            else:
                st.error('Git 배포 차단됨 · Git 인증 정보 관리/SSH 인증을 외부에서 확인하세요.')
            st.json(_deploy_push)
    dva, dvb = st.columns(2)
    with dva:
        if st.button('공개 업데이트 목록 검증', key='trusted_repository_deployment_verify'):
            _deploy_verify = verify_public_deployment(ROOT)
            if _deploy_verify.get('status') == 'PUBLIC_FEED_VERIFIED':
                st.success(f"공개 release_feed.json 검증 완료 · {_deploy_verify.get('target_version')}")
            else:
                st.error('공개 업데이트 목록 검증 차단됨')
            st.json(_deploy_verify)
    with dvb:
        _deploy_bootstrap_confirm = st.checkbox('검증된 공개 release_feed.json을 이 클라이언트의 신뢰 업데이트 목록으로 고정하고 자동 동기화를 켭니다.', key='trusted_repository_deployment_bootstrap_confirm')
        if st.button('검증됨 공개 업데이트 목록 → 클라이언트 초기 연결', key='trusted_repository_deployment_bootstrap', disabled=not _deploy_bootstrap_confirm):
            _deploy_bootstrap = bootstrap_client_feed(ROOT)
            if _deploy_bootstrap.get('status') == 'CLIENT_FEED_BOOTSTRAPPED':
                st.success('신뢰 업데이트 목록 고정 완료 · 앞으로 새 배포는 자동 발견/다운로드/수신함 동기화됩니다.')
            else:
                st.error('클라이언트 업데이트 목록 초기 연결 차단됨')
            st.json(_deploy_bootstrap)
    st.info('한 번 공개 업데이트 목록 초기 연결까지 완료하면 신뢰 업데이트 목록 주소가 고정됩니다. 이 단계에서 자동 승인/적용은 아직 수행하지 않습니다. GitHub/GitLab 인증 토큰은 앱에 입력하거나 저장하지 않습니다.')
    st.subheader('0D) 신뢰 배포본 운영 / 전체 작동 상태 점검')
    _ops_health = trusted_release_operations_status(ROOT)
    op1, op2, op3, op4, op5 = st.columns(5)
    op1.metric('전체 작동 상태', _locale.code(_ops_health.get('status', 'REVIEW')))
    op2.metric('기술 점검', _locale.code(_ops_health.get('technical_gate', 'BLOCKED')))
    op3.metric('운영', _locale.code(_ops_health.get('operating_status', 'REVIEW')))
    op4.metric('업데이트 목록 상태', _locale.code(_ops_health.get('feed_state_status', '-')))
    op5.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, pd.DataFrame(_ops_health.get('checks', [])), width='stretch', hide_index=True)
    _ops_live_result_key = '_trusted_release_operations_live_result'
    _ops_last_live = st.session_state.pop(_ops_live_result_key, None)
    oh1, oh2 = st.columns(2)
    with oh1:
        if _ops_health.get('technical_gate') == 'PASS':
            st.success('신뢰 배포본 운영 기술 점검 정상 · 관리 대상 코드, 보안 웹 연결 호스트 고정, 로컬 저장소, Git 배포, 업데이트 목록 주소/무결성 해시 연결 이력, 자동 적용 금지 경계가 정상입니다.')
        else:
            st.error('신뢰 배포본 운영 기술 점검 차단됨 · 실패 항목의 행동을 먼저 확인하세요.')
    with oh2:
        if st.button('실전 공개 업데이트 목록 + 클라이언트 재처리-확인', key='trusted_release_operations_live_check'):
            _ops_live = trusted_release_operations_live_check(ROOT)
            st.session_state[_ops_live_result_key] = _ops_live
            st.rerun()
        if _ops_last_live:
            if _ops_last_live.get('status') == 'LIVE_CHECK_PASS':
                st.success('실전 신뢰 배포본 전체 작동 점검 확인 정상 · 공개 업데이트 목록과 클라이언트 업데이트 목록을 다시 검증했고 0D 상태를 최신 스냅샷으로 다시 계산했습니다.')
            else:
                st.warning('실전 신뢰 배포본 전체 작동 점검 확인 검토 · 공개/업데이트 목록 결과의 차단 사유를 확인하세요.')
            with st.expander('마지막 실전 재처리-확인 투자 근거', expanded=False):
                st.json(_ops_last_live)
    st.caption('0D는 운영 중 신뢰 배포본 경로의 일관성을 감사합니다. 실전 재처리-확인은 공개 업데이트 목록을 읽고 검증 상태만 갱신하며, 배포 승인/적용 또는 투자 투자 실행 권한을 수행하지 않습니다.')
    st.subheader('0E) 신뢰 배포본 복구 / 이전 버전 복원 준비 상태')
    _recovery = trusted_release_recovery_status(ROOT)
    rc1, rc2, rc3, rc4, rc5 = st.columns(5)
    rc1.metric('복구', _locale.code(_recovery.get('status', 'REVIEW')))
    rc2.metric('기술 점검', _locale.code(_recovery.get('technical_gate', 'BLOCKED')))
    rc3.metric('복구 시점', _locale.code(_recovery.get('recovery_point_version', '-')))
    rc4.metric('마지막 모의 점검', _locale.code(_recovery.get('last_drill_status', 'NOT_RUN')))
    rc5.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, pd.DataFrame(_recovery.get('checks', [])), width='stretch', hide_index=True)
    _recovery_result_key = '_trusted_release_recovery_drill_result'
    _recovery_last_result = st.session_state.pop(_recovery_result_key, None)
    rr1, rr2 = st.columns(2)
    with rr1:
        if _recovery.get('technical_gate') == 'PASS':
            st.success('복구 기술 점검 정상 · 최신 거래 단위 백업의 구조/CRC/파일 명세 복원 가능성을 확인할 수 있습니다.')
        else:
            st.error('복구 기술 점검 차단됨 · 실제 이전 버전 복원 전에 백업 무결성을 먼저 복구하세요.')
    with rr2:
        if st.button('운영 코드를 변경하지 않는 복구 모의 점검', key='trusted_release_recovery_drill'):
            _recovery_drill = trusted_release_recovery_drill(ROOT)
            st.session_state[_recovery_result_key] = _recovery_drill
            st.rerun()
        if _recovery_last_result:
            if _recovery_last_result.get('status') == 'RECOVERY_DRILL_PASS':
                st.success('복구 모의 점검 정상 · 이전 버전 관리 대상-코드를 임시 격리 환경에서 SHA/구문 검사 검증했습니다.')
            else:
                st.warning('복구 모의 점검 검토/차단됨 · 투자 근거의 errors를 확인하세요.')
            with st.expander('마지막 복구 모의 점검 투자 근거', expanded=False):
                st.json(_recovery_last_result)
    st.caption('0E 모의 점검은 실전 앱 tree를 수정하거나 이전 버전 복원을 실행하지 않습니다. 실제 이전 버전 복원은 아래 수동 이전 버전 복원의 별도 확인 절차를 통해서만 수행됩니다.')
    _rm_candidates = release_manager_scan_candidates(ROOT)
    if _rm_candidates:
        _rm_table = pd.DataFrame(_rm_candidates)
        _rm_view_cols = [c for c in ['scope', 'package', 'current_version', 'target_version', 'verification', 'version_source', 'eligible', 'approval_ok', 'package_sha256'] if c in _rm_table.columns]
        st.subheader('1) 수신함 / 승인됨 파일 목록 — 미확인')
        _locale.dataframe(st, _rm_table[_rm_view_cols], width='stretch', hide_index=True)
    else:
        st.subheader('1) 수신함 / 승인됨 파일 목록 — 미확인')
        st.info('아직 배포 후보가 없습니다. 최종 배포 ZIP과 검증 TXT를 releases/inbox에 넣으세요.')
    st.subheader('2) 미리보기')
    _rm_paths = [row['path'] for row in _rm_candidates]
    _rm_selected = st.selectbox('배포 배포 패키지', [''] + _rm_paths, key='release_manager_selected_package')
    if _rm_selected:
        _rm_preview = release_manager_preview_release(ROOT, Path(_rm_selected), for_auto_apply=Path(_rm_selected).parent.name.lower() == 'approved')
        pv1, pv2, pv3, pv4, pv5 = st.columns(5)
        pv1.metric('대상', _locale.code(_rm_preview.get('target_version', '-')))
        pv2.metric('적격', _locale.code('YES' if _rm_preview.get('eligible') else '금지'))
        pv3.metric('추가됨', _locale.code(_rm_preview.get('counts', {}).get('added', 0)))
        pv4.metric('변경됨', _locale.code(_rm_preview.get('counts', {}).get('changed', 0)))
        pv5.metric('제거됨', _locale.code(_rm_preview.get('counts', {}).get('removed', 0)))
        if _rm_preview.get('blockers'):
            st.error(_locale.message('업데이트 차단됨 · ' + ' | '.join(_rm_preview['blockers'])))
        if _rm_preview.get('warnings'):
            st.warning(_locale.message(' | '.join(_rm_preview['warnings'])))
        with st.expander('미리보기 상세', expanded=False):
            st.json({'package_sha256': _rm_preview.get('package_sha256'), 'validation_report': _rm_preview.get('validation_report'), 'validation_report_pass': _rm_preview.get('validation_report_pass'), 'current_drift': _rm_preview.get('current_drift'), 'actions': _rm_preview.get('actions')})
    st.subheader('3) 승인 최종 배포')
    st.caption('승인은 수신함 배포 패키지의 실제 SHA-256을 공개된 배포 SHA-256과 대조하고 검증 보고서의 결과: 정상까지 확인합니다.')
    _rm_inbox_packages = [row['path'] for row in _rm_candidates if row['scope'] == 'inbox']
    _rm_approve_package = st.selectbox('수신함 최종 배포 ZIP', [''] + _rm_inbox_packages, key='release_manager_approve_package')
    _rm_validation_files = sorted((str(p) for p in _rm_dirs['inbox'].glob('*VALIDATION*.txt') if p.is_file()))
    _rm_validation = st.selectbox('검증 보고서', [''] + _rm_validation_files, key='release_manager_validation_report')
    _rm_expected_sha = st.text_input('게시됨 배포 ZIP SHA-256', value='', key='release_manager_expected_sha', placeholder='64자리 SHA-256')
    if st.button('최종 배포 승인 → 승인됨으로 이동', key='release_manager_approve_button'):
        if not _rm_approve_package or not _rm_validation:
            st.warning('수신함 배포 ZIP과 검증 보고서를 선택하세요.')
        else:
            _rm_approval = release_manager_approve_release(ROOT, Path(_rm_approve_package), Path(_rm_validation), _rm_expected_sha)
            if _rm_approval.get('status') == 'APPROVED':
                st.success(f"승인 완료 · 대상 {_rm_approval.get('target_version')} · 승인됨 폴더에 변경 불가 승인 기록을 저장했습니다.")
                st.json(_rm_approval)
            else:
                st.error(_locale.message('승인 차단됨 · ' + ' | '.join(_rm_approval.get('blockers', []))))
    st.subheader('4) 거래 단위 적용')
    _rm_approved = [row for row in release_manager_scan_candidates(ROOT) if row['scope'] == 'approved' and row.get('newer_than_current')]
    _rm_approved_paths = [row['path'] for row in _rm_approved]
    _rm_apply_package = st.selectbox('승인됨 최종 배포', [''] + _rm_approved_paths, key='release_manager_apply_package')
    _rm_apply_confirm = st.checkbox('현재 앱 코드 백업 → 적용 → 사후-적용 검증 → 실패 시 자동 이전 버전 복원 절차를 확인했습니다.', key='release_manager_apply_confirm')
    if st.button('승인됨 배포 적용', type='primary', key='release_manager_apply_button', disabled=not _rm_apply_package or not _rm_apply_confirm):
        _rm_result = release_manager_apply_release(ROOT, Path(_rm_apply_package), require_approved_folder=True)
        if _rm_result.get('status') == 'APPLIED':
            st.success(f"업데이트 적용 완료 · 버전 {_rm_result.get('current_version')} · 사후-적용 검증 정상. 앱을 수동 재시작하세요.")
            st.json(_rm_result)
        elif _rm_result.get('status') == 'ROLLED_BACK':
            st.error('업데이트 검증 실패로 자동 이전 버전 복원을 수행했습니다.')
            st.json(_rm_result)
        else:
            st.error(f"업데이트 {_locale.code(_rm_result.get('status', 'BLOCKED'))}")
            st.json(_rm_result)
    st.subheader('5) 사용 중지 승인됨 배포')
    st.caption('모의 실행/검사 배포처럼 더 이상 자동 적용하면 안 되는 승인됨 배포 패키지는 삭제하지 않고 보관/사용 중지됨으로 이동합니다.')
    _rm_retire_candidates = [row['path'] for row in release_manager_scan_candidates(ROOT) if row['scope'] == 'approved']
    _rm_retire_package = st.selectbox('승인됨 배포 대상 사용 중지', [''] + _rm_retire_candidates, key='release_manager_retire_package')
    _rm_retire_reason = st.text_input('사용 중지 사유', value='', key='release_manager_retire_reason', placeholder='예: v1.50.1 모의 실행 완료')
    _rm_retire_confirm = st.checkbox('이 승인됨 배포를 자동-업데이트 적격성에서 제거하고 변경 불가 사용 중지 기록을 남깁니다.', key='release_manager_retire_confirm')
    if st.button('승인됨 배포 사용 중지', key='release_manager_retire_button', disabled=not _rm_retire_package or not _rm_retire_confirm):
        _rm_retire_result = release_manager_retire_approved_release(ROOT, Path(_rm_retire_package), reason=_rm_retire_reason)
        if _rm_retire_result.get('status') == 'RETIRED':
            st.success(f"승인됨 배포 사용 중지됨 · 대상 {_rm_retire_result.get('target_version', '-')} · 자동-업데이트 적격성 제거 완료.")
        else:
            st.error('승인됨 배포 사용 중지 차단됨/실패')
        st.json(_rm_retire_result)
    st.subheader('6) 수동 이전 버전 복원')
    _rm_rollback_confirm = st.checkbox('가장 최근 배포 관리 백업으로 관리 대상 코드를 복원합니다. data/와 .env는 건드리지 않습니다.', key='release_manager_rollback_confirm')
    if st.button('최근 배포 관리 백업으로 이전 버전 복원', key='release_manager_rollback_button', disabled=not _rm_rollback_confirm):
        _rm_rollback = release_manager_rollback_latest(ROOT)
        if _rm_rollback.get('status') == 'ROLLED_BACK':
            st.success(f"이전 버전 복원 완료 · 버전 {_rm_rollback.get('current_version')} · 앱을 수동 재시작하세요.")
        else:
            st.error('이전 버전 복원 실패 또는 백업 없음')
        st.json(_rm_rollback)
    st.divider()
    st.subheader('작업 자동화 명령')
    st.code('python updater\\update_manager.py status\npython updater\\update_manager.py feed-status\npython updater\\update_manager.py feed-check\npython updater\\update_manager.py feed-sync\npython updater\\update_manager.py deploy-status\npython updater\\update_manager.py deploy-connect\npython updater\\update_manager.py deploy-preview\npython updater\\update_manager.py deploy-push\npython updater\\update_manager.py deploy-verify\npython updater\\update_manager.py deploy-bootstrap\npython updater\\update_manager.py operations-status\npython updater\\update_manager.py operations-live-check\npython updater\\update_manager.py recovery-status\npython updater\\update_manager.py recovery-drill\npython updater\\update_manager.py orchestrator-status\npython updater\\update_manager.py orchestrator-preflight --package <INBOX_RELEASE.zip> --expected-sha256 <SHA256>\npython updater\\update_manager.py orchestrator-release --package <INBOX_RELEASE.zip> --expected-sha256 <SHA256>\npython updater\\update_manager.py orchestrator-install-preview --package <APPROVED_RELEASE.zip> --live-verify\npython updater\\update_manager.py orchestrator-install --package <APPROVED_RELEASE.zip>\npython updater\\update_manager.py orchestrator-finalize\npython updater\\update_manager.py publisher-status\npython updater\\update_manager.py publisher-preview --package <RELEASE.zip> --base-url <HTTPS_BASE_URL>\npython updater\\update_manager.py publisher-publish --package <RELEASE.zip> --base-url <HTTPS_BASE_URL>\npython updater\\update_manager.py scan\npython updater\\update_manager.py preview --package <RELEASE.zip> --auto\npython updater\\update_manager.py approve --package <RELEASE.zip> --validation-report <VALIDATION.txt> --expected-sha256 <SHA256>\npython updater\\update_manager.py retire --package <APPROVED_RELEASE.zip> --reason <REASON>\npython updater\\update_manager.py auto-update\npython updater\\update_manager.py rollback', language='text')
    st.caption('중요: 배포 관리의 프로그램 업데이트 승인은 투자/주문 투자 실행 권한과 완전히 분리됩니다. 업데이트 도구는 투자 주문을 생성하거나 투자 실행 권한을 변경하지 않습니다.')
