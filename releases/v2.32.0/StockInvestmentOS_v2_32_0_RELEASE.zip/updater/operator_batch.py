"""Explicit local check/install batch. No brokerage access, feed, or rollback command.

The same file is shipped as a standalone companion so v2.31 can run the batch.
Only --install authorizes applying the exact v2.32 package specified by the caller.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

SOURCE_VERSION = 'v2.31.0'
TARGET_VERSION = 'v2.32.0'
PACKAGE_NAME = 'StockInvestmentOS_v2_32_0_RELEASE.zip'


def runtime_check(root):
    expected = root / '.venv'
    if Path(sys.prefix).resolve() != expected.resolve() or sys.prefix == sys.base_prefix:
        return False, 'APP_VENV_REQUIRED'
    try:
        result = subprocess.run([sys.executable, '-c', 'import streamlit'],
            cwd=root, capture_output=True, timeout=30, check=False)
        return (True, 'APP_VENV_STREAMLIT_IMPORT_PASS') if result.returncode == 0 else (False, 'STREAMLIT_IMPORT_FAILED')
    except (OSError, subprocess.TimeoutExpired):
        return False, 'STREAMLIT_IMPORT_FAILED_OR_TIMEOUT'


def validate_root(root):
    root = Path(root).resolve()
    if root.name.lower() != 'app' or root.parent.name.lower() != 'work':
        raise ValueError('WORK_READY_APP_PATH_REQUIRED')
    layout = json.loads((root / 'WORK_READY_LAYOUT.json').read_text(encoding='utf-8-sig'))
    control = (root / layout.get('control_rel', '')).resolve()
    if (layout.get('schema_version') != 1 or layout.get('mode') != 'WORK_READY_SEPARATED'
            or control != (root.parent / 'control').resolve()):
        raise ValueError('SEPARATED_CONTROL_LAYOUT_REQUIRED')
    if not (root / 'app.py').is_file() or not (root / 'updater/release_manager.py').is_file():
        raise ValueError('APP_FILES_MISSING')
    return root


def run_batch(root, *, install=False, package=None, validation=None, expected_sha=None,
              drill=False, expected_version=None):
    root = validate_root(root)
    # The trusted installed updater is intentionally reused; no alternate install engine.
    sys.path.insert(0, str(root))
    from updater import release_manager as rm
    from updater import release_recovery as recovery
    report = dict(schema_version=1, created_at=datetime.now(timezone.utc).isoformat(),
        mode='INSTALL' if install else 'CHECK', status='BLOCKED', current_version=None,
        target_version=TARGET_VERSION if install else expected_version,
        checks=[], apply_status='NOT_REQUESTED', live_code_applied=False,
        broker_access='NOT_PERFORMED', public_feed='NOT_VERIFIED',
        browser_ui='NOT_VERIFIED', execution_authorization='NONE')

    def record(name, ok, detail):
        report['checks'].append(dict(name=name, status='PASS' if ok else 'FAIL', detail=detail))
        return ok

    def finish():
        passed = bool(report['checks']) and all(row['status'] == 'PASS' for row in report['checks'])
        report['status'] = ('LOCAL_INSTALL_CHECK_PASS' if install else 'LOCAL_CHECK_PASS') if passed else 'BLOCKED'
        logs = rm.ensure_runtime_dirs(root)['logs']
        name = 'OPS-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '.json'
        path = logs / name
        report['report_file'] = name
        content = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        path.write_text(content, encoding='utf-8')
        # Timestamped reports are the evidence; a latest copy is a convenience only.
        (logs / 'operations_latest.json').write_text(content, encoding='utf-8')
        return report

    try:
        runtime_ok, runtime_detail = runtime_check(root)
        record('python_streamlit', runtime_ok, runtime_detail)
        state = rm.status_report(root, include_candidates=False)
        current = report['current_version'] = state.get('current_version')
        clean = state.get('managed_code_clean') is True and state.get('managed_manifest_entries', 0) > 0
        record('managed_code', clean, 'MANAGED_HASHES_PASS' if clean else 'MANAGED_CODE_DRIFT_OR_EMPTY_MANIFEST')
        allowed = {SOURCE_VERSION, TARGET_VERSION} if install else ({expected_version} if expected_version else {SOURCE_VERSION, TARGET_VERSION})
        version_ok = current in allowed
        record('version', version_ok, current if version_ok else 'UNEXPECTED_VERSION')
        # Cheap inventory only: no old-package scan, recursive traversal, or deletion.
        inbox = rm.ensure_runtime_dirs(root)['inbox']
        report['inbox_inventory'] = dict(files=sum(p.is_file() for p in inbox.iterdir()),
            directories=sum(p.is_dir() for p in inbox.iterdir()), package_verification='NOT_SCANNED')
        if not (runtime_ok and clean and version_ok):
            return finish()
        if install:
            package, validation = Path(package or ''), Path(validation or '')
            supplied = bool(expected_sha and len(expected_sha) == 64 and
                all(c in '0123456789abcdefABCDEF' for c in expected_sha))
            files_ok = package.name == PACKAGE_NAME and package.is_file() and validation.is_file()
            digest_ok = files_ok and supplied and rm.sha256_file(package) == expected_sha.lower()
            binding_ok = digest_ok and rm.validation_report_passes(validation, package)
            if not record('package_binding', bool(binding_ok), 'EXACT_PACKAGE_REPORT_SHA_PASS' if binding_ok else 'PACKAGE_REPORT_OR_SHA_MISMATCH'):
                return finish()
            if current == TARGET_VERSION:
                report['apply_status'] = 'ALREADY_INSTALLED'
                # Same VERSION is insufficient: require byte-exact target manifest identity.
                import zipfile
                with zipfile.ZipFile(package) as archive:
                    exact = hashlib.sha256(archive.read('manifest_sha256.json')).digest() == hashlib.sha256((root / 'manifest_sha256.json').read_bytes()).digest()
                if not record('installed_target_identity', exact, 'EXACT_TARGET_MANIFEST' if exact else 'TARGET_MANIFEST_MISMATCH'):
                    return finish()
            else:
                preview = rm.preview_release(root, package, for_auto_apply=True)
                eligible = preview.get('eligible') is True and preview.get('target_version') == TARGET_VERSION
                if not record('install_preview', eligible, 'ELIGIBLE' if eligible else 'PREVIEW_BLOCKED'):
                    return finish()
                approved = rm.approve_release(root, package, validation, expected_sha.lower())
                if not record('install_approval', approved.get('status') == 'APPROVED', approved.get('status', 'UNKNOWN')):
                    return finish()
                applied = rm.apply_release(root, Path(approved['approved_package']))
                report['apply_status'] = applied.get('status', 'UNKNOWN')
                report['live_code_applied'] = applied.get('status') == 'APPLIED'
                # ROLLED_BACK may have a successful CLI exit code: inspect the actual status.
                if not record('install_apply', report['live_code_applied'], report['apply_status']):
                    return finish()
                state = rm.status_report(root, include_candidates=False)
                report['current_version'] = state.get('current_version')
                installed_ok = state.get('managed_code_clean') is True and state.get('current_version') == TARGET_VERSION
                if not record('installed_integrity', installed_ok, 'TARGET_VERSION_AND_HASHES_PASS' if installed_ok else 'POST_INSTALL_CHECK_FAILED'):
                    return finish()
        if drill or install:
            result = recovery.trusted_release_recovery_drill(root)
            drill_ok = (result.get('status') == 'RECOVERY_DRILL_PASS' and
                result.get('live_root_modified') is False and result.get('rollback_executed') is False)
            record('recovery_drill', drill_ok, result.get('status', 'UNKNOWN'))
        readiness = recovery.trusted_release_recovery_status(root)
        record('recovery_readiness', readiness.get('status') == 'PASS', readiness.get('status', 'UNKNOWN'))
        report['recovery_point_version'] = readiness.get('recovery_point_version')
        report['backup_name'] = readiness.get('backup_name')
    except Exception as exc:
        # Do not export exception messages, arbitrary log fields, account identifiers or paths.
        record('batch_exception', False, type(exc).__name__)
    return finish()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--install', action='store_true')
    parser.add_argument('--package', type=Path)
    parser.add_argument('--validation-report', type=Path)
    parser.add_argument('--expected-sha256')
    parser.add_argument('--expected-version', choices=(SOURCE_VERSION, TARGET_VERSION))
    parser.add_argument('--drill', action='store_true')
    args = parser.parse_args(argv)
    try:
        result = run_batch(args.root, install=args.install, package=args.package,
            validation=args.validation_report, expected_sha=args.expected_sha256,
            drill=args.drill, expected_version=args.expected_version)
    except Exception as exc:
        result = dict(status='BLOCKED', error_type=type(exc).__name__,
            next_action='CHECK_WORK_READY_APP_PATH_LAYOUT_AND_LOG_WRITABILITY', execution_authorization='NONE')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] in ('LOCAL_CHECK_PASS', 'LOCAL_INSTALL_CHECK_PASS') else 2


if __name__ == '__main__':
    raise SystemExit(main())
