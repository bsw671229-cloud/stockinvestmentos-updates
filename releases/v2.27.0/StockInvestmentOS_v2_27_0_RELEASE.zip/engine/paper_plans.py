"""Account-bound PAPER editor plans. No broker reads, execution state or permits."""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import secrets
import sqlite3
import unicodedata

from connectors.kis_broker import BrokerError, number
from engine.broker_execution import canonical
from engine.paper_automation import paper_only
from engine.paper_rehearsal import normalize

MAX_PLANS = 20
MAX_BYTES = 65536
LIMIT_FIELDS = ('max_notional', 'fee_buffer_pct', 'max_quote_gap_pct',
                'downside_pct', 'max_scenario_loss')


def plan_payload(rules, budgets, minutes):
    """Validate numeric inputs and strip all runtime state and confirmations."""
    try:
        rules, caps, minutes = normalize(rules, budgets, minutes)
        clean = []
        for rule in rules:
            clean.append(dict(order=rule['order'], comparison=rule['comparison'], trigger=rule['trigger'],
                limits={key: str(number(rule['limits'][key])) for key in LIMIT_FIELDS}))
        payload = dict(schema_version=1, mode='PAPER', rules=clean, budgets=caps, minutes=minutes)
        if len(canonical(payload).encode()) > MAX_BYTES:
            raise ValueError('size')
        return payload
    except (KeyError, TypeError, ValueError, OverflowError, BrokerError) as exc:
        raise BrokerError('조건·건별 예산·하루 한도·실행 시간을 확인하세요.') from None


def editor_values(payload):
    try:
        if type(payload) is not dict or set(payload) != {'schema_version','mode','rules','budgets','minutes'}:
            raise ValueError('fields')
        if type(payload['schema_version']) is not int or payload['schema_version'] != 1 or payload['mode'] != 'PAPER':
            raise ValueError('schema')
        rules = [{**rule, 'limits': {**rule['limits'], 'risk_attested': True}} for rule in payload['rules']]
        normalized = plan_payload(rules, payload['budgets'], payload['minutes'])
        if canonical(normalized) != canonical(payload):
            raise ValueError('noncanonical')
        # risk_attested is a rule-validation input, never a saved start permission.
        return normalize(rules, payload['budgets'], payload['minutes'])
    except (KeyError, TypeError, ValueError, OverflowError, BrokerError):
        raise BrokerError('저장 계획의 형식이나 내용이 달라 불러올 수 없습니다.') from None


def _name(value):
    if not isinstance(value, str):
        raise BrokerError('계획 이름은 1~60자로 입력하세요.')
    value = unicodedata.normalize('NFC', value.strip())
    if not 1 <= len(value) <= 60 or any(unicodedata.category(c).startswith('C') for c in value):
        raise BrokerError('계획 이름은 제어문자 없이 1~60자로 입력하세요.')
    return value


class PlanStore:
    def __init__(self, journal):
        self.path = journal.path.with_name('paper_plans.sqlite3')

    @contextmanager
    def _db(self, write=False):
        if write:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(str(self.path) if write else self.path.resolve().as_uri()+'?mode=ro',
                             uri=not write, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            if write:
                db.execute('PRAGMA synchronous=FULL')
                db.execute('BEGIN IMMEDIATE')
                db.execute('CREATE TABLE IF NOT EXISTS plans (id TEXT PRIMARY KEY, account TEXT NOT NULL, name TEXT NOT NULL, payload TEXT NOT NULL, digest TEXT NOT NULL, created TEXT NOT NULL, revision INTEGER NOT NULL, archived INTEGER NOT NULL)')
                db.execute('CREATE UNIQUE INDEX IF NOT EXISTS active_plan_name ON plans(account,name) WHERE archived=0')
            else:
                db.execute('BEGIN')
            yield db
            if write:
                db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def list(self, client):
        paper_only(client)
        account = client.credentials.identity
        if not self.path.exists():
            return []
        with self._db() as db:
            rows = db.execute('SELECT id,name,created,revision FROM plans WHERE account=? AND archived=0 ORDER BY rowid DESC LIMIT ?', (account, MAX_PLANS)).fetchall()
        paper_only(client, account)
        return [dict(r) for r in rows]

    def save(self, client, name, rules, budgets, minutes):
        paper_only(client)
        account, name = client.credentials.identity, _name(name)
        payload = canonical(plan_payload(rules, budgets, minutes))
        stamp = datetime.now(timezone.utc).isoformat()
        key = secrets.token_hex(16)
        try:
            with self._db(write=True) as db:
                paper_only(client, account)
                if db.execute('SELECT COUNT(*) FROM plans WHERE account=? AND archived=0', (account,)).fetchone()[0] >= MAX_PLANS:
                    raise BrokerError('계획은 계좌별 최대 20개입니다. 사용하지 않는 계획을 보관하세요.')
                db.execute('INSERT INTO plans VALUES(?,?,?,?,?,?,1,0)',
                    (key, account, name, payload, hashlib.sha256(payload.encode()).hexdigest(), stamp))
                paper_only(client, account)
        except sqlite3.IntegrityError:
            raise BrokerError('같은 이름의 계획이 있습니다. 다른 이름으로 저장하세요.') from None
        return key

    def load(self, client, key, revision):
        paper_only(client)
        account = client.credentials.identity
        if not self.path.exists():
            raise BrokerError('저장 계획을 찾을 수 없습니다.')
        with self._db() as db:
            row = db.execute('SELECT payload,digest FROM plans WHERE id=? AND account=? AND revision=? AND archived=0', (key, account, revision)).fetchone()
        paper_only(client, account)
        if row is None:
            raise BrokerError('계획이 바뀌었거나 보관되었습니다. 목록을 다시 확인하세요.')
        raw = row['payload']
        if not isinstance(raw, str) or len(raw.encode()) > MAX_BYTES or hashlib.sha256(raw.encode()).hexdigest() != row['digest']:
            raise BrokerError('저장 계획의 무결성을 확인할 수 없습니다.')
        try:
            payload = json.loads(raw)
            editor_values(payload)
        except (ValueError, TypeError, BrokerError):
            raise BrokerError('저장 계획을 검증하지 못했습니다. 새 조건을 작성하세요.') from None
        return payload

    def archive(self, client, key, revision):
        paper_only(client)
        account = client.credentials.identity
        if not self.path.exists():
            raise BrokerError('저장 계획을 찾을 수 없습니다.')
        with self._db(write=True) as db:
            paper_only(client, account)
            if db.execute('UPDATE plans SET archived=1,revision=revision+1 WHERE id=? AND account=? AND revision=? AND archived=0', (key, account, revision)).rowcount != 1:
                raise BrokerError('계획이 바뀌었거나 보관되었습니다. 목록을 다시 확인하세요.')
            paper_only(client, account)
