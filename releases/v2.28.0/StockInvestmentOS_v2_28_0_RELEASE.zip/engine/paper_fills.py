"""Explicit monetary-evidence refresh for already terminal PAPER automation orders."""
from connectors.kis_broker import BrokerError
from engine import paper_automation as pa
from engine.broker_execution import reconcile_order
from engine.paper_recovery import _HistoryClient, history


def refresh_fills(automation,client,*,confirmed=False):
    if confirmed is not True: raise BrokerError('완료 주문 체결 금액 조회를 선택하세요.')
    pa.paper_only(client)
    account=client.credentials.identity
    before=history(automation,client)
    references=list(dict.fromkeys(r['order_reference'] for run in before['runs'] for r in run['rules']
        if r['order_reference'] and r['state'] in ('FILLED','CANCELLED','REJECTED')))[:20]
    checked=failed=skipped=0
    reader=_HistoryClient(client,account)
    for reference in references:
        pa.paper_only(client,account)
        try:
            record=automation.journal.get(reference,account)
            if record['payload']['mode']!='PAPER': raise BrokerError('모의 주문 기록을 확인하세요.')
            if not record['result'].get('order_no') or 'filled_quantity' not in record['result']:
                skipped+=1; continue
            reconcile_order(reader,automation.journal,reference,refresh_terminal=True)
            checked+=1
        except Exception:
            failed+=1  # Keep prior evidence and never export raw provider messages.
    pa.paper_only(client,account)
    result=history(automation,client)
    result['fill_refresh']=dict(checked=checked,failed=failed,skipped=skipped,limit=20,
        order_transmission='NOT_PERFORMED',scope='최근 10회 실행의 완료 주문 중 최대 20건')
    return result
