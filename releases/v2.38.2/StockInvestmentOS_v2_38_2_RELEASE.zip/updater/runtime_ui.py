"""Native controls for restart evidence and direct portfolio navigation."""
import ui_locale as _locale
import streamlit as st


def render_shortcuts():
    if st.sidebar.button('국내·미국 자동매매', key='paper_auto_shortcut', width='stretch'):
        st.session_state['main_menu'] = 'KIS Execution'
        st.session_state['kis_view'] = 'AUTO'
    if st.sidebar.button('포트폴리오 변경안 비교', key='portfolio_plan_shortcut', width='stretch'):
        st.session_state['main_menu'] = 'Decision Workbench v2'
        st.session_state['v2_review_mode'] = '포트폴리오 변경안 비교'
    if st.sidebar.button('업데이트·복구 점검', key='release_checks_shortcut', width='stretch'):
        st.session_state['main_menu'] = 'Release Manager'


def render_restart_status(gate):
    if gate.get('eligible'):
        st.success('프로그램 재시작 확인 완료 · 설치된 버전으로 새로 실행됐습니다.')
    else:
        for message in gate.get('blockers', ['프로그램 재시작을 확인해 주세요.']):
            st.warning(_locale.message(message))
        st.caption('프로그램 실행 창을 종료하고 평소 실행 아이콘으로 다시 켠 뒤 이 화면에서 최종 점검하세요.')


def render_finalize_result(result, gate):
    current_pass = (result.get('status') == 'FINAL_PASS' and gate.get('eligible')
                    and result.get('runtime_restart') == gate)
    if current_pass:
        st.success('안전 업데이트 최종 통과 · 실제 재시작, 전체 작동 상태와 운영 코드를 변경하지 않는 복구 모의 점검이 모두 정상입니다.')
    else:
        st.warning('안전 업데이트 최종 검토 · 현재 실행 상태의 최종 점검이 필요합니다. 재시작 안내와 점검 근거를 확인하세요.')
    with st.expander('설치 후 최종 점검 근거', expanded=False):
        st.json(result)
