"""Portfolio proposal editor; explicit transfer only, no broker or journal access."""
from datetime import datetime,timezone,timedelta
from decimal import Decimal
import pandas as pd
import streamlit as st
from connectors.kis_broker import BrokerError
from portfolio_automation import proposal,transfer
from broker_plan_library import clear_editor_confirmation,clear_plan_context


def render(client):
    context=(client.credentials.identity,client.credentials.mode,id(client))
    if st.session_state.get('_portfolio_connection')!=context:
        for key in list(st.session_state):
            if key.startswith('portfolio_') or key=='_portfolio_review': st.session_state.pop(key,None)
        st.session_state['_portfolio_connection']=context
    with st.expander('포트폴리오 비중 → 종목별 자동매매 조건 만들기'):
        st.info('전체 보유·현금·가격·환율을 직접 확인해 입력하세요. 자동 조회·환전은 하지 않으며 입력 자료는 5분 동안만 유효합니다.')
        st.caption('목표 비중에서 정수 수량을 계산하고 각 종목의 가격 조건을 붙입니다. 비교·반영은 주문하지 않습니다. 반영 후 전체 조건 점검과 시작 확인이 별도로 필요합니다.')
        st.caption('목표 비중은 수수료 전 현재 평가 총자산 기준입니다. 정수 절삭·가격 변동·부분 체결로 실제 비중은 달라질 수 있습니다. 정기·무인 리밸런싱이나 자동 수량 재계산은 하지 않습니다.')
        clock=datetime.now(timezone(timedelta(hours=9)))
        with st.form('portfolio_proposal_form',enter_to_submit=False):
            krw=st.text_input('사용 가능한 원화 현금',value='0',key='portfolio_krw')
            usd=st.text_input('사용 가능한 달러 현금',value='0',key='portfolio_usd')
            fx=st.text_input('확인한 원/달러 환율 (1달러당 원)',value='0',key='portfolio_fx')
            day=st.date_input('자료 확인 날짜 (한국시간)',value=clock.date(),key='portfolio_day')
            stamp=st.time_input('자료 확인 시각 (한국시간)',value=clock.time().replace(tzinfo=None,microsecond=0),key='portfolio_time')
            st.markdown('**1. 전체 보유와 신규 종목**')
            st.caption('현금을 제외한 보유를 빠짐없이 입력하세요. 신규 종목은 보유·매도 가능 수량을 0으로 입력합니다. 국내 시장 KR / 거래소 KRX, 미국 시장 US / 거래소 NASD·NYSE·AMEX를 사용합니다.')
            holdings=st.data_editor(pd.DataFrame(columns=['시장','거래소','종목','보유 수량','매도 가능 수량','확인 가격']),num_rows='dynamic',hide_index=True,key='portfolio_holdings',alt='전체 보유와 확인 가격 입력')
            st.markdown('**2. 비중을 바꿀 종목과 가격 조건**')
            st.caption('최대 10종목. 목표 0%는 정리 계획입니다. 아래에 없는 보유는 그대로 유지합니다. 조건은 이하 또는 이상으로 입력하세요.')
            targets=st.data_editor(pd.DataFrame(columns=['시장','종목','목표 비중 (%)','조건','조건 가격','지정가']),num_rows='dynamic',hide_index=True,key='portfolio_targets',alt='목표 비중과 종목별 가격 조건 입력')
            st.markdown('**3. 사용자가 정한 위험 한도**')
            fee=st.text_input('비용 여유율 (%)',value='0',key='portfolio_fee')
            gap=st.text_input('조회 가격·지정가 차이 한도 (%)',value='0',key='portfolio_gap')
            downside=st.text_input('매수 하락 가정 (%)',value='0',key='portfolio_downside')
            limits={}
            for c in ('KRW','USD'):
                cap=st.text_input('건별 비용 포함 금액 상한 ('+c+')',value='0',key='portfolio_cap_'+c)
                loss=st.text_input('건별 매수 가정 손실 예산 ('+c+')',value='0',key='portfolio_loss_'+c)
                limits[c]=dict(max_notional=cap,max_scenario_loss=loss,fee_buffer_pct=fee,max_quote_gap_pct=gap,downside_pct=downside,risk_attested=True)
            attested=st.checkbox('현재 연결의 전체 보유·현금·자료 시각·가격 조건·위험 한도를 확인했습니다',key='portfolio_attested')
            replace=st.checkbox('검토 결과로 현재 작성 중인 자동매매 조건 목록을 교체합니다',key='portfolio_replace')
            compare=st.form_submit_button('비중·수량·조건 비교')
            apply=st.form_submit_button('비교한 조건을 목록에 반영 · 주문 없음')
        if not (compare or apply):return
        try:
            positions=[dict(market=r['시장'],exchange=r['거래소'],symbol=r['종목'],quantity=r['보유 수량'],sellable=r['매도 가능 수량'],price=r['확인 가격']) for r in holdings.to_dict('records')]
            ts=[dict(market=r['시장'],symbol=r['종목'],target_weight=str(Decimal(str(r['목표 비중 (%)']))/100),comparison={'이하':'LE','이상':'GE'}[r['조건']],trigger=r['조건 가격'],limit_price=r['지정가'],limits=limits['KRW' if r['시장']=='KR' else 'USD']) for r in targets.to_dict('records')]
            snapshot=dict(attested=attested,mode=context[1],account_context=str(context),observed_at=datetime.combine(day,stamp,tzinfo=clock.tzinfo).isoformat(),cash={'KRW':krw,'USD':usd},usd_krw=fx,positions=positions)
            result=proposal(snapshot,ts)
            if apply:
                prior=st.session_state.get('_portfolio_review')
                if not replace or not prior or st.session_state.get('_paper_auto'):
                    raise BrokerError('먼저 비교하고 목록 교체를 확인하세요. 실행 중에는 반영할 수 없습니다.')
                rules=transfer(snapshot,ts,prior,account_context=str(context),mode=context[1])
                if not rules:raise BrokerError('변경 수량이 없어 반영할 조건이 없습니다.')
                clear_editor_confirmation();clear_plan_context()
                st.session_state['_paper_auto_draft']=rules
                st.session_state.pop('_portfolio_review',None)
                st.success('조건 목록에 반영했습니다. 하루 한도를 설정하고 전체 조건을 다시 점검한 뒤 직접 시작하세요.')
            else:
                st.session_state['_portfolio_review']=result['binding']
            st.caption('매도 예상 대금은 매수 자금에서 제외합니다. 통화별 현금으로 부족하면 계획을 반영할 수 없습니다.')
            st.dataframe(pd.DataFrame(result['rows']).rename(columns={'market':'시장','symbol':'종목','current_quantity':'현재 수량','target_quantity':'목표 수량','change_quantity':'변경 수량','target_weight':'목표 비중 (0~1)','estimated_weight':'정수 수량 적용 비중 (0~1)'}),hide_index=True,alt='현재 수량과 목표 수량의 비교')
            if not result['rules']:st.info('정수 수량 기준으로 변경할 수량이 없습니다.')
        except (BrokerError,ValueError,TypeError,KeyError,ArithmeticError):
            st.session_state.pop('_portfolio_review',None)
            st.error('입력·자료 시각·매도 가능 수량·통화별 현금·위험 한도를 확인하세요. 입력을 바꾸었으면 다시 비교해야 합니다. 기존 조건 목록은 유지합니다.')
