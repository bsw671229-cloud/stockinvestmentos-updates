"""Read-only unresolved attempt navigation, independent of the last ten runs."""
import streamlit as st
from engine.unresolved_attempt_view import unresolved_page
from connectors.kis_broker import BrokerError

LABELS={'CLAIMED':'시도 기록됨','PENDING':'접수·체결 확인 중','UNKNOWN':'접수 여부 확인 필요','FILLED':'전량 체결','CANCELLED':'취소 확인','REJECTED':'거절','FAILED_PRECHECK':'사전 점검 중단','EXPIRED':'만료','OPEN':'미체결','PARTIAL':'부분 체결','SENDING':'전송 결과 확인 필요','CANCEL_UNKNOWN':'취소 결과 확인 필요','CANCEL_REQUESTED':'취소 확인 중','ACKNOWLEDGED':'접수 확인'}

def render_unresolved(automation,client,*,on_read):
 context=(id(client),client.credentials.identity,automation.mode,str(automation.journal.path.resolve()))
 key='_unresolved_local_page';saved=st.session_state.get(key)
 if saved and saved['context']!=context:st.session_state.pop(key,None);saved=None
 with st.expander('전체 미확인 실행 상세 · 오래된 기록 포함'):
  first=st.button('미확인 상세 처음부터 읽기',key='unresolved_first',on_click=on_read)
  cursor=None if first or not saved else saved['cursor']
  try:page=unresolved_page(automation,client,cursor=cursor)
  except BrokerError:
   st.session_state.pop(key,None);st.warning('미확인 상세를 읽지 못했습니다. 연결과 운영 점검을 확인한 뒤 처음부터 다시 읽으세요.');return
  st.session_state[key]=dict(context=context,cursor=cursor)
  if st.button('미확인 상세 다음 20건',key='unresolved_next',disabled=not page['next_cursor'],on_click=on_read):
   st.session_state[key]=dict(context=context,cursor=page['next_cursor']);st.rerun()
  st.caption(page['scope'])
  st.caption(f"전체 미확인 시도 {page['total_unresolved']}건 · 이번 표시 {len(page['rows'])}건")
  st.caption('새로 생긴 기록은 처음부터 다시 읽기로 확인하세요. 이 목록 읽기는 증권사 조회·주문·중지·재개·차단 해제를 하지 않습니다.')
  if not page['rows']:st.info('현재 범위에 표시할 미확인 시도가 없습니다. 전체 범위를 다시 보려면 처음부터 읽으세요.')
  rows=[{'실행 기록':r['run_reference'],'조건 번호':r['condition_number'],'시도 상태':LABELS.get(r['attempt_state'],r['attempt_state']),'주문 기록':r['order_reference'] or '연결 근거 없음','주문 상태':LABELS.get(r['order_status'],r['order_status']) if r['order_status'] else '확인 불가','다음 확인':r['next_action']} for r in page['rows']]
  if rows:st.dataframe(rows,hide_index=True)
