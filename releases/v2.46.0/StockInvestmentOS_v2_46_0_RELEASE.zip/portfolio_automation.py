"""Pure portfolio-to-conditional-rule proposal. Never reads accounts or sends orders."""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR
from connectors.kis_broker import BrokerError, number, whole, validate_order
from engine.paper_automation import validate_rules
from engine.broker_execution import digest, validate_limits


def proposal(snapshot, targets, *, now=None):
    """All positions + KRW/USD cash must belong to one user-attested snapshot.

    targets: selected symbols, target_weight (0..1), comparison, trigger,
    limit_price, limits. Quantity is fixed at review, never auto-refreshed.
    """
    s, targets = deepcopy(snapshot), deepcopy(targets)
    if s.get('attested') is not True or s.get('mode') not in ('PAPER', 'LIVE') or not s.get('account_context'):
        raise BrokerError('전체 보유·현금과 연결 환경을 확인하세요.')
    current = now or datetime.now(timezone.utc)
    observed = datetime.fromisoformat(s['observed_at'])
    if observed.tzinfo is None or current.tzinfo is None or not 0 <= (current-observed).total_seconds() <= 300:
        raise BrokerError('보유·가격·환율 자료가 오래되었거나 확인 시각이 잘못되었습니다. 다시 확인하세요.')
    if set(s['cash']) != {'KRW', 'USD'}:
        raise BrokerError('원화와 달러 현금을 각각 입력하세요.')
    fx = number(s['usd_krw'], positive=True)
    cash = {c:number(v) for c,v in s['cash'].items()}
    positions = s['positions']
    if not isinstance(positions, list) or len(positions)>100 or not isinstance(targets,list) or not 1<=len(targets)<=10:
        raise BrokerError('보유는 최대 100개, 변경 조건은 1~10개입니다.')
    indexed = {}
    total = cash['KRW'] + cash['USD']*fx
    for p in positions:
        order = validate_order(dict(p, side='BUY', quantity=1, limit_price=p['price']))
        key = (order['market'], order['symbol'])
        if key in indexed:
            raise BrokerError('같은 시장·종목의 보유가 중복되었습니다.')
        qty, sellable = whole(p['quantity']), whole(p['sellable'])
        if sellable > qty:
            raise BrokerError('매도 가능 수량이 보유 수량을 초과합니다.')
        price=number(p['price'],positive=True)
        rate = Decimal(1) if order['currency']=='KRW' else fx
        indexed[key] = (order,qty,sellable,price,rate)
        total += price*qty*rate
    if total<=0:
        raise BrokerError('총 평가 자산이 0입니다.')
    seen=set(); desired={}; rows=[]; rules=[]; costs={'KRW':Decimal(0),'USD':Decimal(0)}
    for t in targets:
        key=(t['market'],str(t['symbol']).strip().upper())
        if key in seen or key not in indexed:
            raise BrokerError('변경 종목은 중복 없이 보유 표에 등록하세요. 신규 종목은 보유 0으로 등록하세요.')
        seen.add(key)
        order,qty,sellable,price,rate=indexed[key]
        weight=number(t['target_weight'])
        if weight>1: raise BrokerError('목표 비중은 0~100%입니다.')
        desired[key]=total*weight
        target_qty=int((total*weight/(price*rate)).to_integral_value(rounding=ROUND_FLOOR))
        delta=target_qty-qty
        rows.append(dict(market=key[0],symbol=key[1],current_quantity=qty,target_quantity=target_qty,
            change_quantity=delta,target_weight=str(weight),estimated_weight=str(price*target_qty*rate/total)))
        if not delta: continue
        if delta<0 and -delta>sellable:
            raise BrokerError('계산한 매도 수량이 매도 가능한 수량을 초과합니다.')
        rule=dict(order=dict(order,side='BUY' if delta>0 else 'SELL',quantity=abs(delta),limit_price=t['limit_price']),
            comparison=t['comparison'],trigger=t['trigger'],limits=t['limits'])
        clean=validate_rules([rule])[0]
        if delta>0:
            costs[order['currency']]+=number(validate_limits(clean['order'],clean['limits'])['estimated_cost'])
        rules.append(clean)
    unchanged=sum(price*qty*rate for key,(_,qty,_,price,rate) in indexed.items() if key not in seen)
    if sum(desired.values())+unchanged>total:
        raise BrokerError('변경하지 않는 보유를 포함한 목표 비중이 총자산을 초과합니다.')
    if any(costs[c]>cash[c] for c in costs):
        raise BrokerError('통화별 현금이 부족합니다. 미체결 매도대금이나 자동 환전은 자금에 포함하지 않습니다.')
    if rules: rules=validate_rules(rules)
    return dict(status='REVIEW' if rules else 'NO_CHANGE',rules=rules,rows=rows,
        total_krw=str(total),buy_costs={c:str(v) for c,v in costs.items()},
        binding=digest(dict(snapshot=s,targets=targets)),account_context=s['account_context'],mode=s['mode'],
        observed_at=s['observed_at'],orders_enabled=False)


def transfer(snapshot, targets, expected_binding, *, account_context, mode, now=None):
    """Rebuild immediately before editor transfer; connection/input changes invalidate review."""
    result=proposal(snapshot,targets,now=now)
    if result['binding']!=expected_binding or result['account_context']!=account_context or result['mode']!=mode:
        raise BrokerError('검토 후 입력 또는 연결이 변경되었습니다. 다시 비교하세요.')
    return deepcopy(result['rules'])
