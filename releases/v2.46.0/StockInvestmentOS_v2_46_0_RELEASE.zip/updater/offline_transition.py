"""Standalone maintenance handoff; no broker requests, investment or rollback.

before/after callbacks run inside the same broker writer lease as managed apply.
An unsuccessful installation never starts the previous executable automatically.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
import os
import time

from engine.update_execution_guard import InstallBlocked

_CURRENT = ContextVar('stock_os_offline_transition', default=None)


def current(root):
    value = _CURRENT.get()
    if value is None:
        return None
    owner_root, controller = value
    if Path(root).resolve() != owner_root:
        raise InstallBlocked('다른 설치 폴더의 종료·재시작 확인입니다.')
    return controller


@contextmanager
def scope(root, controller):
    if _CURRENT.get() is not None:
        raise InstallBlocked('이미 설치 전환을 처리 중입니다.')
    token = _CURRENT.set((Path(root).resolve(), controller))
    try:
        yield
    finally:
        _CURRENT.reset(token)


def install(root, package, *, controller, start_after=True, progress=None):
    from updater.safe_update_orchestrator import install_verified_release
    with scope(root, controller):
        result = install_verified_release(root, package, progress=progress)
    result = {**result, 'offline_transition': list(controller.evidence)}
    complete = {e.get('phase') for e in controller.evidence if e.get('quiet')}
    safe = (complete == {'BEFORE_MANAGED_CHANGE', 'BEFORE_WRITER_RELEASE'}
            and not result.get('apply', {}).get('broker_installation_guard'))
    if result.get('status') != 'INSTALL_APPLIED_RESTART_REQUIRED' or not start_after or not safe:
        return {**result, 'automatic_start_performed': False}
    try:
        started = controller.start(Path(root).resolve())
    except (OSError, RuntimeError):
        return {**result, 'automatic_start_performed': False,
                'restart_status': 'START_REVIEW_REQUIRED'}
    return {**result, 'automatic_start_performed': True,
            'restart_status': 'STARTED_FINAL_CHECK_REQUIRED', 'started': started}


class Transition:
    """Backend injection keeps all actual process control out of unit tests."""
    def __init__(self, backend, *, on_hold=None):
        self.backend = backend
        self.evidence = []
        self.on_hold = on_hold

    def _quiet(self, root, phase):
        selected = self.backend.inventory(root)
        if any(p['pid'] == os.getpid() for p in selected):
            raise InstallBlocked('현재 앱 안에서는 최초 전환을 진행할 수 없습니다. 독립 설치 도구를 사용하세요.')
        # Validate the entire set before terminating any member.
        for process in selected:
            self.backend.validate(root, process, selected)
        for process in sorted(selected, key=lambda p: p.get('parent', 0), reverse=True):
            self.backend.stop(process)
        if self.backend.inventory(root):
            raise InstallBlocked('종료하지 못했거나 다시 시작한 앱이 있습니다. 설치를 보류합니다.')
        self.evidence.append(dict(phase=phase, stopped_pids=[p['pid'] for p in selected], quiet=True))

    def before_change(self, root):
        self._quiet(root, 'BEFORE_MANAGED_CHANGE')

    def after_change(self, root):
        # File changes may already be committed. Do not release the broker writer
        # lease while an old-code process cannot be identified/stopped. A caller
        # must keep this maintenance worker alive until the condition is resolved.
        reported = False
        while True:
            try:
                self._quiet(root, 'BEFORE_WRITER_RELEASE')
                return
            except Exception:
                if not reported:
                    self.evidence.append(dict(phase='MAINTENANCE_HELD', quiet=False))
                    if self.on_hold:
                        try:self.on_hold('설치 후 앱 종료 확인이 필요하여 주문 기록 잠금을 유지합니다. 설치 도구를 종료하지 마세요.')
                        except Exception:pass
                    reported = True
                time.sleep(.25)

    def start(self, root):
        if self.backend.inventory(root):
            raise InstallBlocked('다른 앱 실행이 확인되어 중복 시작하지 않습니다.')
        return self.backend.start(root)
