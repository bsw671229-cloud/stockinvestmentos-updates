"""Independent first protected upgrade using the official verified install route."""
import argparse
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path

def main(argv=None):
    parser=argparse.ArgumentParser(description='공식 업데이트 오프라인 전환')
    parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--package',required=True,type=Path)
    parser.add_argument('--sha256',required=True)
    parser.add_argument('--port',type=int,default=8501)
    parser.add_argument('--start',action='store_true')
    parser.add_argument('--legacy-proof',type=Path)
    args=parser.parse_args(argv)
    if (len(args.sha256)!=64 or any(c not in '0123456789abcdef' for c in args.sha256)
            or hashlib.sha256(args.package.read_bytes()).hexdigest()!=args.sha256):
        raise SystemExit('업데이트 SHA-256이 일치하지 않습니다.')
    from migration.work_ready_paths import resolve_control_root
    from updater.release_manager import current_drift_report
    from updater.offline_transition import install,Transition
    from updater.windows_app_processes import WindowsAppProcesses
    root=args.root.resolve();control=resolve_control_root(root).resolve()
    if control!=root.parent/'control' or not current_drift_report(root)['clean']:
        raise SystemExit('운영 app/control 구조 또는 관리파일 무결성을 확인하세요.')
    record=control/'update_logs/offline_transition_latest.json'
    def save(status,**extra):
        record.parent.mkdir(parents=True,exist_ok=True)
        value=dict(checked_at=datetime.now(timezone.utc).isoformat(),status=status,
                   worker_pid=os.getpid(),root=str(root),**extra)
        temporary=record.with_suffix('.tmp')
        temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temporary,record)
    def held(message):
        save('MAINTENANCE_HELD',requires_action=message)
        print(message,flush=True)
    proof=json.loads(args.legacy_proof.read_text(encoding='utf-8')) if args.legacy_proof else None
    controller=Transition(WindowsAppProcesses(port=args.port,legacy_proof=proof),on_hold=held)
    save('PREFLIGHT_STARTED')
    result=install(root,args.package,controller=controller,start_after=args.start,
                   progress=lambda message:print(message,flush=True))
    save('INSTALL_RETURNED',result=result)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    return 0 if (result.get('status')=='INSTALL_APPLIED_RESTART_REQUIRED'
                 and (not args.start or result.get('automatic_start_performed'))) else 2

if __name__=='__main__':
    raise SystemExit(main())
