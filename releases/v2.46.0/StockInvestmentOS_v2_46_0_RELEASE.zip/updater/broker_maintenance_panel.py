"""Explicit maintenance recovery without restarting trading or rolling back."""
import sqlite3
from pathlib import Path
from migration.work_ready_paths import resolve_control_root
from engine.update_execution_guard import inspect,acknowledge_restored_source,InstallBlocked

def render(root, *, st=None):
    if st is None:
        import streamlit as st
    gate=inspect(resolve_control_root(Path(root))/'broker_operations/orders.sqlite3')
    if gate['eligible']:
        return gate
    st.warning('업데이트 안전 확인이 필요합니다.')
    for reason in gate['blockers']:st.write(reason)
    counts=gate.get('counts')
    if counts and any(counts.values()):
        st.info('자동매매를 중지하고 주문·체결 관리에서 미완료 주문을 확인하세요. 이 화면은 주문을 취소하지 않습니다.')
        return gate
    st.info('설치가 중단됐다면 기존 프로그램을 완전히 종료하고 다시 실행하세요. 아래 확인은 설치 전 파일로 이미 복원됐는지 검사합니다. 파일 복원이나 주문 실행은 하지 않습니다.')
    confirmed=st.checkbox('기존 프로그램을 종료하고 다시 실행했으며 복구 점검 내용을 확인했습니다.',key='broker_install_recovery_confirm')
    if st.button('설치 전 원본 복구 확인',key='broker_install_recovery_check',disabled=not confirmed):
        try:
            result=acknowledge_restored_source(root,confirmed=confirmed)
        except (InstallBlocked,sqlite3.Error,OSError,ValueError):
            st.error('안전 조건을 확인하지 못했습니다. 차단을 유지합니다. 기존 프로세스 종료·관리파일 무결성·설치 기록을 점검하세요.')
        else:
            st.success('설치 전 원본과 새 실행을 확인했습니다. 자동매매는 재개하지 않았습니다. 시작하려면 조건과 주문 기록을 다시 확인하세요.')
            return result
    return gate
