"""Bounded account-scoped local unresolved attempt evidence. No broker operations."""
import hashlib
from connectors.kis_broker import BrokerError
STATES=('CLAIMED','PENDING','UNKNOWN')

def unresolved_page(automation,client,*,cursor=None):
 automation._check_client(client);account=client.credentials.identity;j=automation.journal
 context={'account':account,'mode':automation.mode,'journal':hashlib.sha256(str(j.path.resolve()).encode()).hexdigest()}
 after=0;upper=None
 if cursor is not None:
  if (not isinstance(cursor,dict) or set(cursor)!=set(context)|{'after','upper'} or any(cursor.get(k)!=v for k,v in context.items()) or type(cursor['after']) is not int or type(cursor['upper']) is not int or not 0<=cursor['after']<=cursor['upper']):raise BrokerError('확인 범위가 현재 연결과 다릅니다. 처음부터 다시 읽으세요.')
  after,upper=cursor['after'],cursor['upper']
 with j.transaction() as db:
  if upper is None:upper=db.execute('SELECT COALESCE(MAX(rowid),0) FROM paper_attempts WHERE account=?',(account,)).fetchone()[0]
  base="account=? AND state IN ('CLAIMED','PENDING','UNKNOWN')"
  total=db.execute('SELECT COUNT(*) FROM paper_attempts WHERE '+base,(account,)).fetchone()[0]
  raw=db.execute('SELECT rowid AS sequence,run_id,idx,state,order_id FROM paper_attempts WHERE '+base+' AND rowid>? AND rowid<=? ORDER BY rowid LIMIT 21',(account,after,upper)).fetchall()
  rows=[]
  for item in raw[:20]:
   record=db.execute('SELECT status FROM orders WHERE id=? AND account=?',(item['order_id'],account)).fetchone() if item['order_id'] else None
   linked=record is not None
   rows.append(dict(run_reference=item['run_id'],condition_number=item['idx']+1,attempt_state=item['state'],order_reference=item['order_id'],order_status=record['status'] if linked else None,
    reason=('RESULT_SYNC_PENDING' if record['status'] in ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK') else 'LINKED_ORDER') if linked else 'ORDER_LINK_UNCONFIRMED',
    next_action=('종료 결과가 주문 기록에 있습니다. 신규 주문을 막고 이전 결과 확인 버튼으로 실행 기록에 반영하세요. 자동매매를 재개하지 않습니다.' if record['status'] in ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK') else '주문·체결 관리에서 해당 주문 기록을 확인하세요.') if linked else '주문 연결 근거가 없습니다. 증권사 주문·체결 내역과 실행 기록을 대조하고 운영 점검을 확인하세요. 자동 재전송하거나 미확인 상태를 해제하지 마세요.'))
 automation._check_client(client,account)
 return dict(rows=rows,total_unresolved=total,next_cursor=dict(context,after=raw[19]['sequence'],upper=upper) if len(raw)>20 else None,scope='현재 연결의 전체 미확인 시도 · 한 번에 최대20건 · 로컬 기록만 조회')
