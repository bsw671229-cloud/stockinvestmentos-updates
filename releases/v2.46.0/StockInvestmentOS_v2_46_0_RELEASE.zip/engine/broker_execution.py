"""User-confirmed order workflow with durable idempotency and explicit uncertainty."""
from __future__ import annotations
from contextlib import contextmanager
from datetime import datetime,timedelta,timezone
from decimal import Decimal
from pathlib import Path
import hashlib,json,secrets,sqlite3,time
from connectors.kis_broker import BrokerError,BrokerRejected,number,whole,validate_order,input_number
from engine.broker_market_session import check_kr_order_session
from engine.broker_fills import execution_details

ACTIVE=('SENDING','UNKNOWN','ACKNOWLEDGED','PARTIAL','OPEN','CANCEL_REQUESTED','CANCEL_UNKNOWN')
TERMINAL=('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK')


def canonical(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(value): return hashlib.sha256(canonical(value).encode()).hexdigest()


class Journal:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.transaction() as db:
            db.execute('CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, account TEXT NOT NULL, fingerprint TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL, expires REAL NOT NULL, result TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT, at REAL NOT NULL, kind TEXT NOT NULL, detail TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS controls (account TEXT PRIMARY KEY, halted INTEGER NOT NULL)')

    @contextmanager
    def transaction(self):
        db=sqlite3.connect(self.path,timeout=10,isolation_level=None)
        db.row_factory=sqlite3.Row
        try:
            db.execute('PRAGMA synchronous=FULL');db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except BaseException:
            db.rollback();raise
        finally: db.close()

    def _event(self,db,order_id,kind,detail=''):
        db.execute('INSERT INTO events(order_id,at,kind,detail) VALUES(?,?,?,?)',(order_id,time.time(),kind,detail))

    def halted(self,account):
        with self.transaction() as db:
            row=db.execute('SELECT halted FROM controls WHERE account=?',(account,)).fetchone()
            return bool(row['halted']) if row else False

    def set_halted(self,account,value):
        with self.transaction() as db:
            db.execute('INSERT INTO controls VALUES(?,?) ON CONFLICT(account) DO UPDATE SET halted=excluded.halted',(account,int(bool(value))))
            self._event(db,None,'HALTED' if value else 'RESUMED',account)

    def prepare(self,account,payload,*,on_prepared=None):
        order_id=secrets.token_hex(16);now=time.time()
        fingerprint=digest({'account':account,'order':payload['order']})
        with self.transaction() as db:
            from engine.update_execution_guard import require_execution
            require_execution(db)
            if db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1',(account,)).fetchone(): raise BrokerError('신규 주문이 중지되어 있습니다')
            # Block any unresolved order in this account, including one from a different symbol/tab.
            if db.execute("SELECT 1 FROM orders WHERE account=? AND status IN ('SENDING','UNKNOWN','CANCEL_UNKNOWN')",(account,)).fetchone():
                raise BrokerError('결과 미확인 주문이 있습니다. 먼저 증권사에서 확인하세요')
            if db.execute('SELECT 1 FROM orders WHERE account=? AND fingerprint=? AND status IN ('+','.join('?' for _ in ACTIVE)+')',(account,fingerprint,*ACTIVE)).fetchone():
                raise BrokerError('동일한 미완료 주문이 있습니다. 기존 주문을 확인하세요')
            # A new preview supersedes old previews for the same account across browser tabs.
            db.execute("UPDATE orders SET status='EXPIRED' WHERE account=? AND status='PREPARED'",(account,))
            db.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?)',(order_id,account,fingerprint,canonical(payload),'PREPARED',now,now+60,'{}'))
            self._event(db,order_id,'PREPARED')
            if on_prepared is not None:
                on_prepared(db, order_id, payload)
        return self.get(order_id,account)

    def get(self,order_id,account):
        with self.transaction() as db:
            row=db.execute('SELECT * FROM orders WHERE id=? AND account=?',(order_id,account)).fetchone()
            if row is None: raise BrokerError('이 계좌의 주문 기록을 찾을 수 없습니다')
            result=dict(row)
        result['payload']=json.loads(result['payload']);result['result']=json.loads(result['result'])
        return result

    def recent(self,account):
        with self.transaction() as db:
            ids=[row[0] for row in db.execute('SELECT id FROM orders WHERE account=? ORDER BY created DESC LIMIT 100',(account,))]
        return [self.get(order_id,account) for order_id in ids]

    def claim_send(self,order_id,account,payload_hash):
        with self.transaction() as db:
            from engine.update_execution_guard import require_execution
            require_execution(db)
            row=db.execute('SELECT * FROM orders WHERE id=? AND account=?',(order_id,account)).fetchone()
            if row is None or row['status']!='PREPARED': raise BrokerError('이미 처리했거나 만료된 주문입니다. 재전송하지 않습니다')
            if time.time()>row['expires']: raise BrokerError('확인 시간이 지났습니다. 주문을 다시 준비하세요')
            if digest(json.loads(row['payload']))!=payload_hash: raise BrokerError('검토 후 주문 내용이 바뀌었습니다')
            if db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1',(account,)).fetchone(): raise BrokerError('신규 주문이 중지되어 있습니다')
            if db.execute('SELECT 1 FROM orders WHERE account=? AND id<>? AND status IN ('+','.join('?' for _ in ACTIVE)+')',(account,order_id,*ACTIVE)).fetchone():
                raise BrokerError('먼저 기존 주문의 완료 여부를 확인하세요')
            db.execute("UPDATE orders SET status='SENDING' WHERE id=?",(order_id,))
            self._event(db,order_id,'SENDING')

    def update(self,order_id,account,status,result,*,expected=None):
        if status not in ACTIVE+TERMINAL: raise BrokerError('지원하지 않는 주문 상태입니다')
        with self.transaction() as db:
            current=db.execute('SELECT status,result FROM orders WHERE id=? AND account=?',(order_id,account)).fetchone()
            if current is None: raise BrokerError('주문 기록 저장에 실패했습니다')
            if expected is not None and (current['status']!=expected['status'] or current['result']!=canonical(expected['result'])):
                return False
            if current['status'] in TERMINAL: return False
            changed=db.execute('UPDATE orders SET status=?,result=? WHERE id=? AND account=?',(status,canonical(result),order_id,account)).rowcount
            if changed!=1: raise BrokerError('주문 기록 저장에 실패했습니다')
            self._event(db,order_id,status)
            return True

    def claim_cancel(self,order_id,account,expected):
        with self.transaction() as db:
            row=db.execute('SELECT status,result FROM orders WHERE id=? AND account=?',(order_id,account)).fetchone()
            if row is None or row[0] not in ('ACKNOWLEDGED','OPEN','PARTIAL'): raise BrokerError('중복 취소 또는 취소할 수 없는 상태입니다')
            if row['status']!=expected['status'] or row['result']!=canonical(expected['result']): raise BrokerError('주문 상태가 바뀌었습니다. 다시 조회하세요')
            db.execute("UPDATE orders SET status='CANCEL_REQUESTED' WHERE id=?",(order_id,))
            self._event(db,order_id,'CANCEL_REQUESTED')


def validate_limits(order,limits):
    if limits.get('risk_attested') is not True: raise BrokerError('가격·손실 가정·주문 조건을 확인해 주세요')
    qty=order['quantity'];price=input_number(order['limit_price'],'지정가',positive=True)
    cap=input_number(limits.get('max_notional'),'금액 상한',positive=True)
    fee=input_number(limits.get('fee_buffer_pct'),'비용 여유율')
    gap=input_number(limits.get('max_quote_gap_pct'),'가격 차이 한도',positive=True)
    if fee>5: raise BrokerError('비용 여유율: 0~5% 범위의 숫자를 입력하세요')
    if gap>20: raise BrokerError('가격 차이 한도: 0 초과 20% 이하를 입력하세요')
    cost=price*qty*(1+fee/100)
    if cost>cap: raise BrokerError('설정한 주문금액 상한을 초과합니다')
    loss=Decimal(0)
    if order['side']=='BUY':
        downside=input_number(limits.get('downside_pct'),'매수 하락 가정',positive=True)
        loss_cap=input_number(limits.get('max_scenario_loss'),'매수 가정 손실 예산',positive=True)
        if downside>100: raise BrokerError('하방 가정은 100% 이하여야 합니다')
        loss=price*qty*downside/100+price*qty*fee/100
        if loss>loss_cap: raise BrokerError('설정한 가정 손실 예산을 초과합니다')
    return {'estimated_cost':str(cost),'scenario_loss':str(loss),'max_notional':str(cap),'max_quote_gap_pct':str(gap)}


def check_snapshot(client,order,limits):
    totals=validate_limits(order,limits)
    quote=client.quote(order);price=number(quote['price'],positive=True);limit=number(order['limit_price'],positive=True)
    if abs(limit-price)/price*100>number(totals['max_quote_gap_pct']): raise BrokerError('증권사 조회 가격과 지정가 차이가 한도를 초과합니다')
    if order['side']=='BUY':
        power=client.buying_power(order)
        if power['currency']!=order['currency']: raise BrokerError('통화가 일치하지 않습니다')
        if order['quantity']>whole(power['quantity']) or number(totals['estimated_cost'])>number(power['cash']):
            raise BrokerError('현금 또는 매수 가능 수량이 부족합니다')
        availability={'cash':power['cash'],'quantity':power['quantity']}
    else:
        quantity=client.sellable(order)
        if order['quantity']>quantity: raise BrokerError('매도 가능한 보유 수량이 부족합니다')
        availability={'quantity':quantity}
    return {'quote':quote,'availability':availability,**totals}


def _require_connection(client, account, mode):
    credentials=client.credentials
    if credentials.identity!=account or credentials.mode!=mode:
        raise BrokerError('연결 계좌 또는 투자 환경이 변경되었습니다. 원래 연결을 확인하세요.')


def prepare_order(client,journal,order,limits,*,on_prepared=None):
    credentials=client.credentials;account=credentials.identity;mode=credentials.mode
    order=validate_order(order)
    if journal.halted(client.credentials.identity): raise BrokerError('신규 주문이 중지되어 있습니다')
    validate_limits(order,limits)
    check_kr_order_session(client,order)
    snapshot=check_snapshot(client,order,limits)
    _require_connection(client,account,mode)
    session=check_kr_order_session(client,order)
    _require_connection(client,account,mode)
    payload={'order':order,'limits':limits,'snapshot':snapshot,'mode':client.credentials.mode,
             'account_label':client.credentials.masked_account,'market_session':session}
    if on_prepared is not None:
        return journal.prepare(client.credentials.identity,payload,on_prepared=on_prepared)
    return journal.prepare(client.credentials.identity,payload)


def confirmation_text(record):
    order=record['payload']['order'];mode=record['payload']['mode']
    return f"{mode} {record['payload']['account_label']} {order['side']} {order['symbol']} {order['quantity']} {order['limit_price']} {order['currency']} {record['id'][-6:]}"


def submit_order(client,journal,order_id,confirmation,*,allow_live=False):
    account=client.credentials.identity;record=journal.get(order_id,account)
    if confirmation!=confirmation_text(record): raise BrokerError('표시된 주문 확인 문구를 정확히 입력하세요')
    if record['payload']['mode']!=client.credentials.mode: raise BrokerError('검토 당시 연결 환경과 다릅니다')
    if client.credentials.mode=='LIVE' and allow_live is not True: raise BrokerError('이 세션의 실전 주문 허용 확인이 필요합니다')
    if record['status']!='PREPARED' or time.time()>record['expires']: raise BrokerError('확인 가능한 준비 주문이 아닙니다')
    order=record['payload']['order'];limits=record['payload']['limits']
    check_kr_order_session(client,order)
    check_snapshot(client,order,limits)
    _require_connection(client,account,record['payload']['mode'])
    check_kr_order_session(client,order)
    _require_connection(client,account,record['payload']['mode'])
    journal.claim_send(order_id,account,digest(record['payload']))
    try:
        _require_connection(client,account,record['payload']['mode'])
    except BrokerError:
        journal.update(order_id,account,'FAILED_PRECHECK',{'message':'연결 변경으로 전송 전에 중지했습니다.'})
        raise
    # SENDING is durable before network I/O. A crash remains blocked after restart.
    try:
        receipt=client.send_limit(order)
    except BrokerRejected as exc:
        journal.update(order_id,account,'REJECTED',{'message':str(exc)})
    except Exception:
        journal.update(order_id,account,'UNKNOWN',{'message':'전송 결과 미확인. 증권사에서 확인하기 전 재주문 금지.'})
    else:
        journal.update(order_id,account,'ACKNOWLEDGED',receipt)
    return journal.get(order_id,account)


def _same_number(left,right):
    return str(left).strip().lstrip('0')==str(right).strip().lstrip('0')


def reconcile_order(client,journal,order_id,*,refresh_terminal=False):
    from engine.order_query_diagnostics import EvidenceCheckError
    account=client.credentials.identity;record=journal.get(order_id,account)
    terminal_refresh=refresh_terminal is True and record['status'] in ('FILLED','CANCELLED','REJECTED')
    if refresh_terminal is True and not terminal_refresh: return record
    if record['status'] not in ACTIVE and not terminal_refresh: return record
    if terminal_refresh:
        from engine.paper_rehearsal import check_mode
        check_mode(client, account, mode=record['payload']['mode'])
    def check_connection():
        credentials=client.credentials
        if credentials.identity!=account or credentials.mode!=record['payload']['mode']:
            raise EvidenceCheckError('CONNECTION_CHANGED')
    check_connection()
    receipt=record['result'];order=record['payload']['order']
    if not receipt.get('order_no'):
        raise EvidenceCheckError('ORDER_NUMBER_MISSING')
    start=(datetime.fromtimestamp(record['created'],timezone.utc)-timedelta(days=1)).strftime('%Y%m%d')
    end=(datetime.now(timezone.utc)+timedelta(days=1)).strftime('%Y%m%d')
    rows=client.order_history(order,start,end)
    check_connection()
    if terminal_refresh:
        check_mode(client, account, mode=record['payload']['mode'])
    side='02' if order['side']=='BUY' else '01'
    found=[r for r in rows if _same_number(r.get('odno',''),receipt['order_no']) and r.get('pdno')==order['symbol'] and r.get('sll_buy_dvsn_cd')==side]
    if len(found)!=1: raise EvidenceCheckError('ORDER_MATCH_AMBIGUOUS')
    row=found[0];kr=order['market']=='KR'
    if number(row.get('ord_unpr' if kr else 'ft_ord_unpr3'))!=number(order['limit_price']):
        raise EvidenceCheckError('ORDER_PRICE_MISMATCH')
    order_day=str(row.get('ord_dt',''))
    created=datetime.fromtimestamp(record['created'],timezone(timedelta(hours=9)))
    valid_days={(created-timedelta(days=n)).strftime('%Y%m%d') for n in (0,1)}
    if order_day not in valid_days: raise EvidenceCheckError('ORDER_DATE_MISMATCH')
    if receipt.get('order_time') and row.get('ord_tmd')!=receipt['order_time']: raise EvidenceCheckError('ORDER_TIME_MISMATCH')
    if not kr and row.get('ovrs_excg_cd')!=order['exchange']: raise EvidenceCheckError('ORDER_EXCHANGE_MISMATCH')
    quantity=whole(row.get('ord_qty' if kr else 'ft_ord_qty'));filled=whole(row.get('tot_ccld_qty' if kr else 'ft_ccld_qty'))
    if quantity!=order['quantity'] or filled>quantity: raise EvidenceCheckError('ORDER_QUANTITY_MISMATCH')
    if filled<receipt.get('filled_quantity',0): raise EvidenceCheckError('OLDER_FILL_RECORD')
    remaining=whole(row.get('rmn_qty' if kr else 'nccs_qty'))
    if remaining+filled>quantity: raise EvidenceCheckError('REMAINING_QUANTITY_CONFLICT')
    cancelled=(row.get('cncl_yn')=='Y' if kr else row.get('rvse_cncl_dvsn')=='02')
    rejected=(whole(row.get('rjct_qty','0'))>0 if kr else bool(str(row.get('rjct_rson','')).strip().strip('0')))
    if filled==quantity: status='FILLED'
    elif remaining==0 and cancelled: status='CANCELLED'
    elif filled==0 and remaining==0 and rejected: status='REJECTED'
    elif remaining>0: status='PARTIAL' if filled else 'OPEN'
    else: raise EvidenceCheckError('TERMINAL_STATE_UNCLEAR')
    result={**receipt,'filled_quantity':filled,'remaining_quantity':remaining,'last_checked_at':datetime.now(timezone.utc).isoformat()}
    result['fill_details']=execution_details(order,row,filled,receipt.get('fill_details'))
    if terminal_refresh:
        if status!=record['status'] or filled!=receipt.get('filled_quantity') or remaining!=receipt.get('remaining_quantity'):
            raise EvidenceCheckError('TERMINAL_RECORD_MISMATCH')
        # Only evidence changes on a terminal record. Never reopen the order.
        with journal.transaction() as db:
            check_mode(client, account, mode=record['payload']['mode'])
            changed=db.execute('UPDATE orders SET result=? WHERE id=? AND account=? AND status=? AND result=?',
                (canonical(result),order_id,account,record['status'],canonical(receipt))).rowcount
            if changed: journal._event(db,order_id,'FILL_DETAILS_REFRESHED')
            check_mode(client, account, mode=record['payload']['mode'])
        return journal.get(order_id,account)
    if record['status'] in ('CANCEL_REQUESTED','CANCEL_UNKNOWN') and status in ('OPEN','PARTIAL'):
        status=record['status']
    check_connection()
    journal.update(order_id,account,status,result,expected=record)
    return journal.get(order_id,account)


def cancel_order(client,journal,order_id,confirmation,*,allow_live=False):
    account=client.credentials.identity;record=journal.get(order_id,account)
    if confirmation!='CANCEL '+record['result'].get('order_no',''): raise BrokerError('취소 확인 문구가 일치하지 않습니다')
    if client.credentials.mode=='LIVE' and allow_live is not True: raise BrokerError('실전 취소 요청 확인이 필요합니다')
    record=reconcile_order(client,journal,order_id)
    remaining=record['result'].get('remaining_quantity',0)
    if not remaining: raise BrokerError('취소할 미체결 수량이 없습니다')
    previous=record['status'];journal.claim_cancel(order_id,account,record)
    claimed=journal.get(order_id,account)
    try:
        _require_connection(client,account,record['payload']['mode'])
    except BrokerError:
        journal.update(order_id,account,previous,record['result'],expected=claimed)
        raise
    try:
        client.cancel(record['payload']['order'],record['result'],remaining)
    except BrokerRejected:
        journal.update(order_id,account,previous,{**record['result'],'cancel_message':'증권사에서 취소를 거절했습니다'},expected=claimed)
    except Exception:
        journal.update(order_id,account,'CANCEL_UNKNOWN',{**record['result'],'cancel_message':'취소 결과 미확인. 재요청 전 증권사 확인 필요.'},expected=claimed)
    # Accepted cancellation is a request, not proof that the original order is cancelled.
    return journal.get(order_id,account)
