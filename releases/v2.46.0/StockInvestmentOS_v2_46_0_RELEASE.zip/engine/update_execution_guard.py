"""Prototype: durable installation fence and broker writer serialization.

Only aggregate status is inspected; no account, payload or credential is returned.
An abandoned fence requires an independently verified recovery, never auto-clear.
"""
from contextlib import contextmanager
import math
import hashlib
import os
from pathlib import Path
import secrets
import sqlite3
import time

from connectors.kis_broker import BrokerError


class InstallBlocked(RuntimeError):
    pass


def _tables(db):
    return {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def activity(db):
    tables = _tables(db)
    counts = dict(orders=0, runs=0, attempts=0)
    if 'orders' in tables:
        counts['orders'] = db.execute("SELECT COUNT(*) FROM orders WHERE status IS NULL OR status NOT IN ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK','PREPARED') OR (status='PREPARED' AND (expires IS NULL OR expires>?))", (time.time(),)).fetchone()[0]
    elif tables - {'install_fence','install_process_identity'}:
        raise InstallBlocked('주문 기록 구조를 확인하지 못했습니다. 설치를 보류합니다.')
    if 'paper_runs' in tables:
        # Even expired ownership must be explicitly stopped before maintenance.
        counts['runs'] = db.execute("SELECT COUNT(*) FROM paper_runs WHERE state IS NULL OR state NOT IN ('STOPPED','EXPIRED','COMPLETE')").fetchone()[0]
    if 'paper_attempts' in tables:
        counts['attempts'] = db.execute("SELECT COUNT(*) FROM paper_attempts a LEFT JOIN orders o ON a.order_id=o.id AND a.account=o.account WHERE (a.state IS NULL OR a.state NOT IN ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK')) AND (o.id IS NULL OR o.status NOT IN ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK'))").fetchone()[0]
    return counts


def require_execution(db, *, born=None):
    if 'install_fence' not in _tables(db):
        return
    row = db.execute('SELECT state,finished FROM install_fence WHERE id=1').fetchone()
    if row is None:
        raise BrokerError('설치 보호 기록이 비어 있습니다. 설치 상태를 점검하세요.')
    state, finished = row
    if state != 'FINISHED':
        raise BrokerError('설치 또는 복구 점검 중입니다. 신규 주문과 자동매매 시작을 보류합니다.')
    if born is None:
        from updater.runtime_identity import _process_start
        born = _process_start(os.getpid())
    if (type(born) not in (int, float) or not math.isfinite(born)
            or type(finished) not in (int, float) or not math.isfinite(finished)
            or born <= finished + .000001):
        raise BrokerError('설치 전에 시작한 프로그램이거나 시작 시각을 확인하지 못했습니다. 프로그램을 완전히 종료하고 다시 실행하세요.')


def inspect(path):
    """Read-only advisory. The authoritative check is in installation()."""
    path = Path(path)
    if not path.exists():
        return dict(eligible=True, counts=dict(orders=0, runs=0, attempts=0), blockers=[])
    try:
        with sqlite3.connect(path.resolve().as_uri()+'?mode=ro', uri=True, timeout=.2) as db:
            db.execute('BEGIN')
            counts = activity(db)
            if 'install_fence' in _tables(db):
                row = db.execute('SELECT state FROM install_fence WHERE id=1').fetchone()
                if not row or row[0] != 'FINISHED':
                    raise InstallBlocked('완료되지 않은 설치 보호 기록이 있습니다. 복구 점검이 필요합니다.')
            if any(counts.values()):
                return dict(eligible=False, counts=counts, blockers=['미완료 주문 또는 실행이 있습니다. 중지·주문 확인 후 다시 검사하세요.'])
            return dict(eligible=True, counts=counts, blockers=[])
    except (sqlite3.Error, OSError, InstallBlocked):
        return dict(eligible=False, counts=None, blockers=['주문·설치 기록을 확인할 수 없어 설치를 보류합니다.'])


@contextmanager
def installation(path, *, timeout=.2, root=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    owner = secrets.token_hex(16)
    db = sqlite3.connect(path, timeout=timeout, isolation_level=None)
    marked = False
    try:
        db.execute('PRAGMA synchronous=FULL')
        db.execute('BEGIN IMMEDIATE')
        counts = activity(db)
        if any(counts.values()):
            raise InstallBlocked('미완료 주문 또는 실행이 있어 설치를 보류합니다.')
        if 'install_fence' in _tables(db):
            row = db.execute('SELECT state FROM install_fence WHERE id=1').fetchone()
            if not row or row[0] != 'FINISHED':
                raise InstallBlocked('이전 설치·복구 점검이 완료되지 않았습니다.')
        db.execute('CREATE TABLE IF NOT EXISTS install_fence (id INTEGER PRIMARY KEY CHECK(id=1),owner TEXT NOT NULL,state TEXT NOT NULL,finished REAL NOT NULL,started REAL NOT NULL,installer_pid INTEGER NOT NULL,root TEXT NOT NULL,source_version TEXT NOT NULL,source_manifest TEXT NOT NULL)')
        root = Path(root).resolve() if root is not None else None
        source_version = (root/'VERSION').read_text(encoding='utf-8-sig').strip() if root else ''
        source_manifest = hashlib.sha256((root/'manifest_sha256.json').read_bytes()).hexdigest() if root else ''
        db.execute("INSERT INTO install_fence VALUES(1,?,'INSTALLING',0,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET owner=excluded.owner,state=excluded.state,finished=0,started=excluded.started,installer_pid=excluded.installer_pid,root=excluded.root,source_version=excluded.source_version,source_manifest=excluded.source_manifest", (owner,time.time(),os.getpid(),str(root or ''),source_version,source_manifest))
        # Bind optional native process evidence to this exact fence ownership.
        # A separate table preserves the original fence schema for predecessors.
        # No extra schema in a never-initialized broker DB: predecessors must
        # still read the maintenance-only fence. Missing identity stays conservative.
        if 'orders' in _tables(db):
            db.execute('CREATE TABLE IF NOT EXISTS install_process_identity (id INTEGER PRIMARY KEY CHECK(id=1),owner TEXT NOT NULL,pid INTEGER NOT NULL,created TEXT NOT NULL)')
            created = _native_creation_ticks(os.getpid())
            db.execute('INSERT OR REPLACE INTO install_process_identity VALUES(1,?,?,?)', (owner,os.getpid(),created or ''))
        db.commit()  # Persist BEFORE any managed file changes, survives process loss.
        marked = True
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT owner,state FROM install_fence WHERE id=1').fetchone()
        if row != (owner, 'INSTALLING'):
            raise InstallBlocked('설치 보호 소유권이 변경되었습니다.')
        if any(activity(db).values()):
            raise InstallBlocked('설치 시작 사이에 실행 상태가 변경되었습니다.')
        yield
        db.execute("UPDATE install_fence SET state='FINISHED',finished=? WHERE id=1 AND owner=?", (time.time(), owner))
        db.commit()
    except BaseException:
        db.rollback()
        if marked:
            try:
                db.execute('BEGIN IMMEDIATE')
                db.execute("UPDATE install_fence SET state='FAILED',finished=? WHERE id=1 AND owner=?", (time.time(), owner))
                db.commit()
            except sqlite3.Error:
                db.rollback()  # The durable INSTALLING marker remains fail-closed.
        raise
    finally:
        db.close()


def _native_creation_ticks(pid):
    """Exact Windows kernel creation evidence. Unknown is never inferred."""
    if os.name != 'nt' or type(pid) is not int or pid <= 0:
        return None
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
    kernel.GetProcessTimes.restype=wintypes.BOOL
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:return None
    try:
        times=[wintypes.FILETIME() for _ in range(4)]
        if not kernel.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]):return None
        ticks=(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime
        return str(ticks) if ticks>0 else None
    finally:
        kernel.CloseHandle(handle)


def _installer_absent(pid, *, expected_created=None):
    """Prove exit or a different kernel process; never signal any process."""
    if type(pid) is not int or pid <= 0:
        return False
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        handle = kernel.OpenProcess(0x1000,False,pid)
        if not handle:
            return ctypes.get_last_error() == 87  # Invalid PID; access denied is not absence.
        try:
            code=wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle,ctypes.byref(code)):return False
            if code.value!=259:return True
            # Compare on the SAME open handle to avoid PID lookup races.
            if (type(expected_created) is not str or not expected_created.isascii()
                    or not expected_created.isdigit() or len(expected_created)>20
                    or not 0<int(expected_created)<2**64):return False
            times=[wintypes.FILETIME() for _ in range(4)]
            if not kernel.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]):return False
            ticks=(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime
            return ticks>0 and ticks!=int(expected_created)
        finally:
            kernel.CloseHandle(handle)
    if os.name == 'posix' and Path('/proc').is_dir():
        return not Path('/proc',str(pid)).exists()
    return False


def acknowledge_restored_source(root, *, confirmed=False):
    """Explicit local maintenance acknowledgement; no rollback/order/auto-resume.

    Only exact original managed bytes after the installer exits are recoverable.
    Partial install or unknown ownership stays blocked for official repair.
    """
    if confirmed is not True:
        raise InstallBlocked('복구 점검 내용을 직접 확인해 주세요.')
    from migration.work_ready_paths import resolve_control_root
    from updater.release_manager import current_drift_report
    from updater.runtime_identity import _process_start
    root=Path(root).resolve()
    path=resolve_control_root(root)/'broker_operations/orders.sqlite3'
    db=sqlite3.connect(path.resolve().as_uri()+'?mode=rw',uri=True,timeout=.2,isolation_level=None)
    try:
        db.execute('PRAGMA synchronous=FULL');db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT owner,state,finished,started,installer_pid,root,source_version,source_manifest FROM install_fence WHERE id=1').fetchone()
        if not row or row[1] not in ('INSTALLING','FAILED') or row[5]!=str(root):
            raise InstallBlocked('이 설치 폴더의 미완료 보호 기록을 확인하지 못했습니다.')
        owner,state,finished,started,pid,_,version,manifest=row
        identity=None
        if 'install_process_identity' in _tables(db):
            evidence=db.execute('SELECT owner,pid,created FROM install_process_identity WHERE id=1').fetchone()
            if evidence and evidence[0]==owner and evidence[1]==pid:identity=evidence[2]
        if not _installer_absent(pid,expected_created=identity):
            raise InstallBlocked('설치 프로세스가 종료됐는지 확인하지 못했습니다. 기존 프로그램 종료 후 다시 실행하세요.')
        born=_process_start(os.getpid());boundary=finished if state=='FAILED' else started
        if (type(boundary) not in (int,float) or not math.isfinite(boundary) or boundary<=0
                or type(born) not in (int,float) or not math.isfinite(born) or born<=boundary+.000001):
            raise InstallBlocked('새로 시작한 프로그램의 근거를 확인하지 못했습니다.')
        if (not manifest or hashlib.sha256((root/'manifest_sha256.json').read_bytes()).hexdigest()!=manifest
                or (root/'VERSION').read_text(encoding='utf-8-sig').strip()!=version
                or not current_drift_report(root)['clean']):
            raise InstallBlocked('설치 전 관리파일과 완전히 일치하지 않습니다. 공식 복구 절차를 확인하세요.')
        if any(activity(db).values()):
            raise InstallBlocked('미완료 주문 또는 실행을 먼저 확인하세요.')
        db.execute("UPDATE install_fence SET state='FINISHED',finished=? WHERE id=1 AND owner=?",(boundary,owner))
        db.commit()
        return dict(status='RESTORED_SOURCE_CONFIRMED',automatic_execution_resumed=False,rollback_performed=False)
    except BaseException:
        db.rollback();raise
    finally:
        db.close()
