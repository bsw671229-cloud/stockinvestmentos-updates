"""Stopped PAPER run review. No send, cancel, unhalt, or resume operations."""
import json
import time
from datetime import datetime, timezone

from connectors.kis_broker import BrokerError
from engine.broker_execution import ACTIVE, TERMINAL, reconcile_order
from engine.broker_fills import fill_view, fill_totals
from engine import paper_automation as pa

UNRESOLVED = ('CLAIMED','PENDING','UNKNOWN')


def history(automation, client):
    automation._check_client(client)
    account = client.credentials.identity
    now = time.time()
    with automation.journal.transaction() as db:
        runs = db.execute('SELECT * FROM paper_runs WHERE account=? ORDER BY rowid DESC LIMIT 10', (account,)).fetchall()
        unresolved = db.execute("SELECT COUNT(*) FROM paper_attempts WHERE account=? AND state IN ('CLAIMED','PENDING','UNKNOWN')", (account,)).fetchone()[0]
        halted = bool(db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (account,)).fetchone())
        output = []
        for run in runs:
            effective = run['state']
            if effective == 'ARMED' and (run['process'] != pa.PROCESS or now >= run['expires']
                    or not 0 <= now-run['heartbeat'] <= pa.MAX_GAP or halted
                    or json.loads(run['config'])['day'] != pa._day()):
                effective = 'REVIEW_REQUIRED'
            rows = []
            for row in db.execute('SELECT * FROM paper_rules WHERE run_id=? ORDER BY idx', (run['id'],)):
                rule = json.loads(row['payload'])
                order = rule['order']
                record = db.execute('SELECT status,result FROM orders WHERE id=? AND account=?', (row['order_id'],account)).fetchone()
                parent = rule.get('after_buy')
                choice = db.execute('SELECT selected_idx FROM paper_exit_choices WHERE run_id=? AND parent_idx=?', (run['id'],parent)).fetchone() if parent is not None else None
                rows.append(dict(index=row['idx']+1, market=order['market'], symbol=order['symbol'],
                    after_buy_index=parent+1 if parent is not None else None,
                    selected_exit_index=choice['selected_idx']+1 if choice else None,
                    side=order['side'], quantity=order['quantity'], limit_price=order['limit_price'],
                    currency=order['currency'], state=record['status'] if record else row['state'],
                    order_reference=row['order_id'],
                    fill_details=fill_view(order,json.loads(record['result']) if record else {})))
            output.append(dict(run_reference=run['id'], state=effective,
                expires=datetime.fromtimestamp(run['expires'],timezone.utc).isoformat(), rules=rows))
    automation._check_client(client, account)
    return dict(schema_version=2, generated_at=datetime.fromtimestamp(now,timezone.utc).isoformat(),
        mode=automation.mode, account_label=client.credentials.masked_account, halted=halted,
        unresolved_attempts=unresolved, coverage='최근 10회 실행 · 미확인 수는 전체 기록 기준', runs=output,
        fill_totals=fill_totals([r for run in output for r in run['rules']]),
        fill_coverage='최근 10회에 연결된 주문의 누적 체결 금액 · 비용·세금·환전 제외 · 실현손익 아님')


class _HistoryClient:
    def __init__(self, client, account, mode='PAPER'):
        self.client, self.account, self.mode = client, account, mode

    @property
    def credentials(self):
        from engine.paper_rehearsal import check_mode
        check_mode(self.client, self.account, mode=self.mode)
        return self.client.credentials

    @property
    def base_url(self):
        self.credentials  # Validate the bound connection before exposing its host.
        return self.client.base_url

    def order_history(self, order, *dates):
        from engine.paper_rehearsal import check_mode
        check_mode(self.client, self.account, mode=self.mode)
        result = self.client.order_history(order, *dates)
        from engine.paper_rehearsal import check_mode
        check_mode(self.client, self.account, mode=self.mode)
        return result


def review_stopped(automation, client, *, confirmed=False):
    if confirmed is not True:
        raise BrokerError('신규 주문 중지와 이전 결과 확인을 선택하세요.')
    automation._check_client(client)
    account = client.credentials.identity
    journal = automation.journal
    automation.stop(account, '이전 실행 결과 확인을 위해 신규 주문을 중지했습니다.')
    checked = closed = failed = 0
    # Run invalidation precedes all local closures and broker reads. Existing in-flight
    # requests can still complete; SENDING/UNKNOWN without a receipt are never guessed.
    with journal.transaction() as db:
        attempts = [dict(r) for r in db.execute("SELECT * FROM paper_attempts WHERE account=? AND state IN ('CLAIMED','PENDING','UNKNOWN') ORDER BY rowid LIMIT 20", (account,))]
    reader = _HistoryClient(client, account, automation.mode)
    for attempt in attempts:
        automation._check_client(client, account)
        run_id, idx, order_id = attempt['run_id'], attempt['idx'], attempt['order_id']
        if not order_id:
            with journal.transaction() as db:
                protocol = db.execute("SELECT 1 FROM paper_prepare_protocol WHERE run_id=? AND idx=? AND protocol='ATOMIC_V1'", (run_id,idx)).fetchone()
                # Older orphan reservations have no proof of atomic linkage. Preserve
                # their unresolved state even when no matching order can be found.
                if protocol:
                    changed = db.execute("UPDATE paper_attempts SET state='FAILED_PRECHECK' WHERE run_id=? AND idx=? AND account=? AND state='CLAIMED' AND order_id=''", (run_id,idx,account)).rowcount
                    if changed:
                        db.execute("UPDATE paper_rules SET state='FAILED_PRECHECK' WHERE run_id=? AND idx=? AND order_id=''", (run_id,idx))
                        journal._event(db,None,automation.mode+'_PRE_SEND_CLOSED',run_id+':'+str(idx))
                        closed += 1
            continue
        try:
            record = journal.get(order_id,account)
            if record['payload']['mode'] != automation.mode:
                raise BrokerError('현재 연결 환경의 주문 기록이 아닙니다.')
            if record['status'] == 'PREPARED':
                journal.update(order_id,account,'FAILED_PRECHECK',{},expected=record)
                record = journal.get(order_id,account)
                if record['status'] == 'FAILED_PRECHECK': closed += 1
            if record['status'] in ACTIVE:
                record = reconcile_order(reader,journal,order_id)
                checked += 1
            with journal.transaction() as db:
                # Re-read under the write lock so a concurrent fill is never lost.
                current = db.execute('SELECT status FROM orders WHERE id=? AND account=?', (order_id,account)).fetchone()
                state = current['status'] if current['status'] in TERMINAL else ('UNKNOWN' if current['status'] in ('SENDING','UNKNOWN','CANCEL_UNKNOWN') else 'PENDING')
                for table in ('paper_attempts','paper_rules'):
                    db.execute(f'UPDATE {table} SET state=? WHERE run_id=? AND idx=? AND order_id=?', (state,run_id,idx,order_id))
        except Exception:
            failed += 1  # Never expose raw provider exceptions or infer non-receipt.
    automation._check_client(client,account)
    result = history(automation,client)
    result['review'] = dict(history_checked=checked, pre_send_closed=closed, check_required=failed)
    return result
