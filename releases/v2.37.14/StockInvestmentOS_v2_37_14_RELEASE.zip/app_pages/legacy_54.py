from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('투자 근거 등록 / 출처 이력 원장')
    st.caption('확인된 사실 · 투자적 해석 · 반대 투자 근거 · 다음 확인 근거를 분리해서 공식 원문 출처 중심의 추가 기록 전용 투자 근거 자료로 남깁니다.')
    st.info('승인됨은 사용자가 출처와 내용을 검토했다는 뜻입니다. 관심종목 근거 상태, 투자 단계, 추가 투자 보류, 시나리오를 자동 변경하지 않습니다. 승인된 자료 묶음을 수정하는 대신 새 개정을 생성하는 방식으로 사용하세요.')
    evidence_packets = normalize_evidence_packets(load_csv('evidence_packets.csv'))
    if watchlist.empty:
        st.warning('관심종목이 비어 있습니다.')
    else:
        ei_names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        handed_company = str(st.session_state.get('evidence_intake_company', '') or '').strip()
        ei_default = ei_names.index(handed_company) if handed_company in ei_names else 0
        ei_company = st.selectbox('투자 근거 종목', ei_names, index=ei_default, key='evidence_intake_company_select')
        st.session_state['evidence_intake_company'] = ei_company
        handoff_state = st.session_state.get('_evidence_handoff', {})
        if isinstance(handoff_state, dict) and str(handoff_state.get('company', '') or '').strip() == ei_company:
            _src_title = str(handoff_state.get('source_title', '') or '').strip()
            _src_url = str(handoff_state.get('source_url', '') or '').strip()
            _src_type = str(handoff_state.get('source_type', 'DART / KRX / GOVERNMENT') or 'DART / KRX / GOVERNMENT').strip()
            _event_date = pd.to_datetime(handoff_state.get('event_date', ''), errors='coerce')
            if _src_title:
                st.session_state[f'evidence_source_title::{ei_company}'] = _src_title
            if _src_url:
                st.session_state[f'evidence_source_url::{ei_company}'] = _src_url
            if _src_type:
                st.session_state[f'evidence_source_type::{ei_company}'] = _src_type
            if not pd.isna(_event_date):
                st.session_state[f'evidence_event_date::{ei_company}'] = _event_date.date()
        ei_watch = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(ei_company)]
        ei_ticker = str(ei_watch.iloc[0].get('ticker', '') or '').strip() if not ei_watch.empty else ''
        active_candidate_id = str(st.session_state.get('evidence_candidate_id', '') or '').strip()
        active_candidate_receipt = str(st.session_state.get('evidence_candidate_receipt_no', '') or '').strip()
        active_candidate_company = ''
        if active_candidate_id:
            candidate_source_df = normalize_source_candidates(load_csv('source_candidates.csv'))
            candidate_hit = candidate_source_df.loc[candidate_source_df['candidate_id'].fillna('').astype(str).eq(active_candidate_id)]
            if not candidate_hit.empty:
                active_candidate_company = str(candidate_hit.iloc[0].get('company', '') or '').strip()
                if active_candidate_company == ei_company:
                    st.info(f"공식 원문 점검 인계 · 전자공시 접수번호 {active_candidate_receipt or '-'} · 공시 제목은 사실이 아닙니다. 원문을 열고 확인된 사실을 직접 작성하세요.")
                else:
                    st.warning('현재 선택 종목과 출처 후보 종목이 다릅니다. 이 투자 근거 저장에는 후보 연결을 적용하지 않습니다.')
        if isinstance(handoff_state, dict) and str(handoff_state.get('company', '') or '').strip() == ei_company:
            st.success(f"공식 원문 점검 인계 연결됨 · 후보 {handoff_state.get('candidate_id', '-')} · 전자공시 접수번호 {handoff_state.get('receipt_no', '-')}")
            st.caption('공시 제목은 사실이 아닙니다. 출처 제목 / 주소 / 기록 날짜가 자동 전달되었는지만 먼저 확인한 뒤 원문을 읽고 사실을 작성하세요.')
        st.subheader('1. 최신 승인된 출처 이력')
        latest_packet = latest_approved_packet(evidence_packets, ei_company)
        latest_summary = approved_packet_summary(evidence_packets, ei_company)
        if not latest_packet:
            st.info('아직 승인됨 투자 근거 자료가 없습니다. 첫 자료 묶음을 초안 또는 승인됨으로 저장할 수 있습니다.')
        else:
            l1, l2, l3, l4, l5 = st.columns(5)
            l1.metric('기록', _locale.code(latest_summary.get('event_date', '') or '-'))
            l2.metric('신호', _locale.code(latest_summary.get('evidence_signal', '') or '-'))
            l3.metric('출처 등급', _locale.code(latest_summary.get('source_tier', '') or '-'))
            l4.metric('최신성', _locale.code(latest_summary.get('freshness_status', '') or '-'))
            l5.metric('무결성 해시', _locale.code(latest_summary.get('hash_status', '') or '-'))
            if latest_summary.get('hash_status') == 'TAMPERED':
                st.error('승인됨 자료 묶음의 내용이 저장 당시 무결성 해시와 다릅니다. 원본 표 데이터를 직접 수정하지 말고 새 개정을 생성하세요.')
            elif latest_summary.get('freshness_status') == 'OVERDUE':
                st.warning('최신 승인된 투자 근거의 검토 기한이 지났습니다. 공식 원문 출처를 다시 확인하고 새 자료 묶음을 생성하세요.')
            else:
                st.success(f"최신 투자 근거 출처 이력 = {_locale.code(latest_summary.get('status', '-'))}")
            current_impact_reviews = normalize_impact_reviews(load_csv('evidence_impact_reviews.csv'))
            current_impact_status = evidence_impact_status(evidence_packets, current_impact_reviews, ei_company)
            ib1, ib2 = st.columns([2, 1])
            ib1.metric('최신 투자 근거 영향', _locale.code(current_impact_status.get('status', '-') or '-'))
            if current_impact_status.get('status') == 'REVIEW REQUIRED':
                ib1.warning('최신 승인됨 투자 근거가 아직 투자 가설 / 가치 평가 / 위험 영향검토와 연결되지 않았습니다.')
                ib2.button('투자 근거 영향 검토로 이동', type='primary', on_click=_navigate, args=('Evidence Impact Review', {'evidence_impact_company': ei_company}), key=f'intake_to_impact::{ei_company}')
            elif current_impact_status.get('status') == 'REVIEWED':
                ib1.success('최신 승인됨 투자 근거의 영향 검토가 완료되어 있습니다.')
        impact_bridge_state = st.session_state.get('_evidence_impact_bridge', {})
        if isinstance(impact_bridge_state, dict) and str(impact_bridge_state.get('company', '') or '').strip() == ei_company:
            st.success('새 승인됨 투자 근거 저장 완료 · 다음 단계는 투자 근거 영향 검토입니다.')
            b1, b2 = st.columns([1, 3])
            b1.button('새 투자 근거 영향검토 시작', type='primary', on_click=_navigate, args=('Evidence Impact Review', {'evidence_impact_company': ei_company}), key=f'new_approved_to_impact::{ei_company}')
            b2.caption('자동으로 투자 가설/투자 단계/포트폴리오를 변경하지 않습니다. 영향 검토에서 사람이 영향과 다음 행동을 분류합니다.')
        st.subheader('2. 새 투자 근거 자료')
        source_types = list(SOURCE_TIER_MAP.keys())
        handoff_candidate_id = str(handoff_state.get('candidate_id', '') or '').strip()
        handoff_key_suffix = handoff_candidate_id if handoff_candidate_id else 'manual'
        draft_context = st.session_state.get('_evidence_draft_context', {})
        if not (isinstance(draft_context, dict) and str(draft_context.get('company', '') or '').strip() == ei_company and (str(draft_context.get('candidate_id', '') or '').strip() == handoff_candidate_id)):
            draft_context = {}
        fact_key = f'evidence_fact::{ei_company}::{handoff_key_suffix}'
        interpretation_key = f'evidence_interpretation::{ei_company}::{handoff_key_suffix}'
        contrary_key = f'evidence_contrary::{ei_company}::{handoff_key_suffix}'
        linked_kpi_key = f'evidence_linked_kpi::{ei_company}::{handoff_key_suffix}'
        next_proof_key = f'evidence_next_proof::{ei_company}::{handoff_key_suffix}'
        review_due_key = f'evidence_review_due::{ei_company}::{handoff_key_suffix}'
        reviewed_key = f'evidence_reviewed::{ei_company}::{handoff_key_suffix}'
        handoff_source_type = str(handoff_state.get('source_type', 'DART / KRX / GOVERNMENT') or 'DART / KRX / GOVERNMENT').strip()
        source_type_index = source_types.index(handoff_source_type) if handoff_source_type in source_types else 0
        source_type = st.selectbox('출처 유형', source_types, index=source_type_index, key=f'evidence_source_type::{ei_company}::{handoff_key_suffix}')
        source_tier = source_tier_for_type(source_type)
        st.metric('출처 등급', _locale.code(source_tier))
        handoff_event_raw = handoff_state.get('event_date', '')
        handoff_event_ts = pd.to_datetime(handoff_event_raw, errors='coerce')
        handoff_event_date = handoff_event_ts.date() if not pd.isna(handoff_event_ts) else date.today()
        e1, e2 = st.columns(2)
        event_date = e1.date_input('투자 근거 기록 날짜', value=handoff_event_date, key=f'evidence_event_date::{ei_company}::{handoff_key_suffix}')
        evidence_signal = e2.selectbox('투자 근거 신호', ['NEUTRAL', 'STRENGTHENED', 'WEAKENED', 'INVALIDATION CHECK'], key=f'evidence_signal::{ei_company}', format_func=_locale.option())
        s1, s2 = st.columns(2)
        source_title = s1.text_input('출처 제목', value=str(handoff_state.get('source_title', '') or ''), key=f'evidence_source_title::{ei_company}::{handoff_key_suffix}', placeholder='예: 전자공시 반기보고서 (2026.06)')
        confidence = s2.selectbox('확신도', ['MEDIUM', 'HIGH', 'LOW'], key=f'evidence_confidence::{ei_company}', help='출처 품질과 별개로 이번 사실 해석에 대한 검토 확신도입니다.', format_func=_locale.option())
        source_url = st.text_input('출처 주소', value=str(handoff_state.get('source_url', '') or ''), key=f'evidence_source_url::{ei_company}::{handoff_key_suffix}', placeholder='https://...')
        handoff_complete = bool(str(source_title or '').strip() and str(source_url or '').strip() and (event_date is not None))
        if handoff_candidate_id:
            st.caption(f"인계 진단 · 후보 {handoff_candidate_id[:8]} · 제목 {('OK' if str(source_title or '').strip() else 'MISSING')} · 주소 {('OK' if str(source_url or '').strip() else 'MISSING')} · 기록 날짜 {event_date}")
        if handoff_state:
            if handoff_complete:
                st.success('출처 인계 = 정상 · 제목 / 주소 / 기록 날짜 전달 완료')
            else:
                st.error('출처 인계 = 검토 · 제목 / 주소 / 기록 날짜 중 누락이 있습니다. 투자 근거 자료 저장 전 출처 점검에서 다시 전달하세요.')
        if draft_context:
            st.subheader('2-1. 투자 근거 초안 입력 보조')
            st.warning(_locale.message(str(draft_context.get('warning', '원문 확인용 검토 템플릿입니다.'))))
            st.caption(f"양식 유형: {draft_context.get('guide_type', '-')} · 범위: {draft_context.get('scope', 'REVIEW_PROMPTS_ONLY')}")
            with st.expander('이 원문에서 확인할 항목', expanded=True):
                for _q in draft_context.get('review_questions', []):
                    st.write(f'- {_q}')
            _suggested_kpi = str(draft_context.get('linked_kpi_suggestion', '') or '').strip()
            _suggested_next = str(draft_context.get('next_proof_suggestion', '') or '').strip()
            da1, da2, da3 = st.columns(3)
            if da1.button('연결됨 핵심 성과 지표 제안 적용', key=f'apply_kpi_guide::{ei_company}::{handoff_key_suffix}', disabled=not bool(_suggested_kpi)):
                st.session_state[linked_kpi_key] = _suggested_kpi
                st.rerun()
            if da2.button('다음 확인 근거 제안 적용', key=f'apply_next_guide::{ei_company}::{handoff_key_suffix}', disabled=not bool(_suggested_next)):
                st.session_state[next_proof_key] = _suggested_next
                st.rerun()
            if da3.button('이 후보 초안 입력 비우기', key=f'clear_evidence_draft::{ei_company}::{handoff_key_suffix}'):
                for _key in [fact_key, interpretation_key, contrary_key, linked_kpi_key, next_proof_key, reviewed_key]:
                    st.session_state.pop(_key, None)
                st.rerun()
            st.info('사실 / 해석 / 반대 근거는 자동 작성하지 않습니다. 공시 원문을 읽은 뒤 직접 입력해야 승인 점검을 통과할 수 있습니다.')
        fact_summary = st.text_area('확인된 사실 / 사실', value='', key=fact_key, placeholder='공시·IR에 직접 적힌 사실과 수치를 요약합니다.')
        interpretation = st.text_area('투자적 해석 / 해석', value='', key=interpretation_key, placeholder='사실과 분리해서 투자 가설에 어떤 의미인지 적습니다.')
        contrary = st.text_area('반대 투자 근거 / 대안 설명', value='', key=contrary_key, placeholder='현재 해석이 틀릴 수 있는 가장 강한 반대 근거')
        p1, p2 = st.columns(2)
        linked_kpi = p1.text_input('연결됨 핵심 성과 지표', value='', key=linked_kpi_key, placeholder='예: 영업현금흐름/잉여현금흐름, 주요 고객 수주, NRR')
        next_proof = p2.text_input('다음 확인 근거', value='', key=next_proof_key, placeholder='다음에 어떤 데이터로 다시 검증할지')
        review_due_date = st.date_input('검토 기한', value=date.today() + timedelta(days=90), key=review_due_key, help='자동 가정변경일이 아니라 공식 원문 출처 재검토 기한입니다.')
        preview_packet = {'company': ei_company, 'ticker': ei_ticker, 'event_date': event_date.isoformat(), 'source_type': source_type, 'source_tier': source_tier, 'source_title': source_title, 'source_url': source_url, 'fact_summary': fact_summary, 'investment_interpretation': interpretation, 'contrary_evidence': contrary, 'evidence_signal': evidence_signal, 'confidence': confidence, 'linked_kpi': linked_kpi, 'next_proof': next_proof, 'review_due_date': review_due_date.isoformat()}
        st.subheader('2-2. 투자 근거 변경 비교')
        previous_approved_packet = latest_approved_packet(evidence_packets, ei_company)
        if not previous_approved_packet:
            st.info('이 종목은 비교할 이전 승인됨 투자 근거가 없습니다. 이번 자료 묶음이 첫 기준 상태가 됩니다.')
        else:
            evidence_diff = build_evidence_diff(previous_approved_packet, preview_packet)
            d1, d2, d3 = st.columns(3)
            d1.metric('이전 승인됨', _locale.code(str(previous_approved_packet.get('event_date', '') or '-')))
            d2.metric('초안 항목 시작됨', _locale.code(evidence_diff['started_fields']))
            d3.metric('문장 항목 변경됨', _locale.code(evidence_diff['changed_fields']))
            st.warning(_locale.message(evidence_diff['warning']))
            st.markdown('**출처 / 신호 변화**')
            _locale.dataframe(st, evidence_diff['metadata'], width='stretch', hide_index=True)
            st.markdown('**투자 근거 내용 변화**')
            _locale.dataframe(st, evidence_diff['summary'], width='stretch', hide_index=True)
            changed_detail_labels = [_label for _label, _detail in evidence_diff['details'].items() if _detail['status'] in {'NEW', 'CHANGED'}]
            if not changed_detail_labels:
                if evidence_diff['started_fields'] == 0:
                    st.caption('현재 초안 입력 전입니다. 사실을 입력하면 이전 승인됨과의 차이를 표시합니다.')
                else:
                    st.success('현재 입력된 투자 근거 내용은 이전 승인됨과 문자 기준으로 동일합니다.')
            else:
                with st.expander('추가/삭제된 문구 상세', expanded=False):
                    for _label in changed_detail_labels:
                        _detail = evidence_diff['details'][_label]
                        st.markdown(f"**{_label} · {_locale.code(_detail['status'])}**")
                        _sim = _detail.get('similarity_pct')
                        if _sim is not None:
                            st.caption(f'문자 유사도: {_sim:.1f}%')
                        if _detail.get('added'):
                            st.write('추가된 문구')
                            st.code(_detail['added'])
                        if _detail.get('removed'):
                            st.write('이전 자료 묶음에서 빠진 문구')
                            st.code(_detail['removed'])
            st.caption("주의: '변경됨'은 문자 차이를 뜻합니다. 강화됨/약화됨/가설 무효화 여부는 원문과 반대 투자 근거를 확인한 뒤 사람이 투자 근거 신호로 판단합니다.")
        st.subheader('3. 출처 이력 / 승인 점검')
        draft_validation = validate_evidence_packet(preview_packet, for_approval=False)
        approval_validation = validate_evidence_packet(preview_packet, for_approval=True)
        g1, g2, g3 = st.columns(3)
        g1.metric('초안 점검', _locale.code('정상' if draft_validation['valid'] else '검토'))
        g2.metric('승인 점검', _locale.code('정상' if approval_validation['valid'] else '검토'))
        g3.metric('출처 이력', _locale.code(approval_validation['provenance_status']))
        if not approval_validation['valid']:
            st.warning(_locale.message('승인됨 전 확인: ' + ' / '.join(approval_validation['issues'])))
        if approval_validation['provenance_status'] == 'REVIEW':
            st.caption('보조/보조 출처도 기록할 수 있지만, 공식 원문/발행사 출처보다 출처 이력이 약합니다. 중요한 위험확대 판단은 공식 원문 출처 재확인을 우선하세요.')
        reviewed = st.checkbox('출처와 사실 / 해석 / 반대 근거 / 다음 확인 근거를 직접 검토했습니다.', value=False, key=reviewed_key)
        target_status = 'APPROVED' if reviewed else 'DRAFT'
        st.write(f'저장 상태: **{_locale.code(target_status)}** · 승인됨이 관심종목 근거 상태를 자동 변경하지는 않습니다.')
        if st.button('새 투자 근거 자료 저장', type='primary', key=f'save_evidence_packet::{ei_company}'):
            try:
                if handoff_state and (not handoff_complete):
                    raise ValueError('Primary Source Monitor handoff가 불완전합니다. Source Title / URL / Event Date를 다시 전달하세요.')
                packet = build_evidence_packet(company=ei_company, ticker=ei_ticker, event_date=event_date, source_type=source_type, source_title=source_title, source_url=source_url, fact_summary=fact_summary, investment_interpretation=interpretation, contrary_evidence=contrary, evidence_signal=evidence_signal, confidence=confidence, linked_kpi=linked_kpi, next_proof=next_proof, review_due_date=review_due_date, review_status=target_status)
                updated = pd.concat([evidence_packets[EVIDENCE_PACKET_COLS], pd.DataFrame([packet])], ignore_index=True)
                if active_candidate_id and active_candidate_company == ei_company:
                    save_csv(updated, 'evidence_packets.csv')
                    candidate_source_df = normalize_source_candidates(load_csv('source_candidates.csv'))
                    linked_candidates = mark_candidate_status(candidate_source_df, active_candidate_id, 'PROMOTED', linked_evidence_id=packet['evidence_id'])
                    save_csv(linked_candidates, 'source_candidates.csv')
                    st.session_state.pop('evidence_candidate_id', None)
                    st.session_state.pop('evidence_candidate_receipt_no', None)
                    _saved_draft_context = st.session_state.get('_evidence_draft_context', {})
                    if isinstance(_saved_draft_context, dict) and str(_saved_draft_context.get('candidate_id', '') or '').strip() == active_candidate_id:
                        st.session_state.pop('_evidence_draft_context', None)
                    if target_status == 'APPROVED':
                        st.session_state['_evidence_impact_bridge'] = {'company': ei_company, 'evidence_id': packet.get('evidence_id', ''), 'event_date': packet.get('event_date', ''), 'source_title': packet.get('source_title', '')}
                    st.session_state['_save_flash'] = ('success', f'Evidence Packet을 {target_status} 상태로 저장했습니다. · Primary Source Candidate Link PASS')
                    st.rerun()
                else:
                    _saved_ok = verified_save_feedback(updated, 'evidence_packets.csv', f'Evidence Packet을 {target_status} 상태로 저장했습니다.', rerun=False)
                    if _saved_ok:
                        if target_status == 'APPROVED':
                            st.session_state['_evidence_impact_bridge'] = {'company': ei_company, 'evidence_id': packet.get('evidence_id', ''), 'event_date': packet.get('event_date', ''), 'source_title': packet.get('source_title', '')}
                        st.rerun()
            except Exception as e:
                st.error(f'투자 근거 자료 저장 실패: {e}')
        st.subheader('4. 투자 근거 자료 이력')
        enriched_packets = enrich_evidence_packets(evidence_packets)
        company_packets = enriched_packets.loc[enriched_packets['company'].fillna('').astype(str).eq(ei_company)].copy() if not enriched_packets.empty else pd.DataFrame()
        if company_packets.empty:
            st.info('이 종목의 투자 근거 자료 기록이 없습니다.')
        else:
            history_cols = ['created_at', 'review_status', 'event_date', 'source_tier', 'source_title', 'evidence_signal', 'confidence', 'freshness_status', 'review_due_date', 'hash_status', 'linked_kpi', 'next_proof']
            _locale.dataframe(st, company_packets[[c for c in history_cols if c in company_packets.columns]].tail(50), width='stretch', hide_index=True)
        st.subheader('5. 기존 투자 근거 등록부와의 관계')
        st.info('`Evidence Register`와 `Watchlist evidence_status`는 기존 호환성을 위해 그대로 유지합니다. 투자 근거 등록은 출처 이력 원장이며 기존 상태값을 자동 덮어쓰지 않습니다.')
        st.button('기존 투자 근거 등록부 보기', on_click=_navigate, args=('Evidence',), key=f'evidence_to_legacy::{ei_company}')
    st.caption('투자 근거 자료는 추가 기록 전용 감사기록입니다. 승인됨 기록을 수정해야 한다면 표 데이터를 직접 고치지 말고 새 자료 묶음 / 개정을 생성하세요.')
