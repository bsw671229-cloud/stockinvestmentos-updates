"""Session-bound integrated detail and identifiers-only holding navigation."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import streamlit as st
from connectors.kis_broker import BrokerError, number
from connectors.kis_position_labels import position_name
from broker_inquiry_service import build_check_report, _timestamp
from broker_inquiry_transfer import _context, ERROR_KEY, clear_navigation_authority, enter_precheck
from broker_position_transfer import holding_choices
from broker_market_retry import sanitize_report

STATE_KEY = '_kis_market_details'
PREFIX = 'kis_ro_detail_'
HINT = '상세 결과를 다시 확인하려면 국내·미국 한 번에 점검을 누르세요.'


def clear_details():
    state = st.session_state
    state.pop(STATE_KEY, None)
    for key in list(state):
        if key.startswith(PREFIX): state.pop(key, None)


def queries(domestic, exchange, symbol):
    return {'KR': ('KR', 'KRX', domestic), 'US': ('US', exchange, symbol)}


def capture(client, inputs, market, check, version):
    """Called only by explicit inquiry orchestration, never by rendering."""
    state = st.session_state
    saved = state.get(STATE_KEY)
    if not isinstance(saved, dict) or saved.get('connection') != _context(client) or saved.get('inputs') != inputs or saved.get('version') != version:
        clear_details()
        saved = dict(connection=_context(client), inputs=dict(inputs), version=version, markets={})
        state[STATE_KEY] = saved
    saved['markets'][market] = {**check, 'results': dict(check['results'])}
    for suffix in ('choice_', 'search_', 'source_'):
        state.pop(PREFIX + suffix + market, None)


def valid_check(saved, client, inputs, market, report, version, now=None):
    """Tie detailed records to current context, report metadata and a 5-minute window."""
    try:
        now = now or datetime.now(timezone.utc)
        if (not isinstance(saved, dict) or saved.get('connection') != _context(client)
                or saved.get('inputs') != inputs or saved.get('version') != version
                or market not in ('KR', 'US') or client.credentials.mode not in ('LIVE', 'PAPER')):
            return None
        clean = sanitize_report(report, version=version, mode=client.credentials.mode,
            us_exchange=inputs['US'][1], now=now)
        check = saved['markets'][market]
        if not isinstance(check, dict) or set(check['results']) != {'quote', 'power', 'positions'}: return None
        metadata = build_check_report(check, version=version, mode=client.credentials.mode,
            market=market, exchange=inputs[market][1])
        if metadata != clean['markets'][market]: return None
        for value in [check['started_at'], check['finished_at'], *(r['checked_at'] for r in check['results'].values())]:
            stamp = _timestamp(value)
            if stamp is None or not 0 <= (now - datetime.fromisoformat(stamp)).total_seconds() <= 300: return None
        for record in check['results'].values():
            if record['status'] == 'PASS' and not isinstance(record.get('data'), dict): return None
        return check
    except (ValueError, TypeError, KeyError, AttributeError, OverflowError):
        return None


def _current_inputs():
    state = st.session_state
    values = [state.get('kis_ro_both_KR'), state.get('kis_ro_both_exchange'), state.get('kis_ro_both_US')]
    if not all(isinstance(v, str) for v in values): return None
    return queries(values[0].strip().upper(), values[1], values[2].strip().upper())


def open_holding(client, connection, inputs, market, record, version):
    state = st.session_state
    clear_navigation_authority()
    check = valid_check(state.get(STATE_KEY), client, inputs, market, state.get('_kis_market_report'), version)
    current_version = Path(__file__).with_name('VERSION').read_text(encoding='utf-8-sig').strip()
    if (state.get('_kis_client') is not client or _context(client) != connection
            or state.get('kis_mode') != client.credentials.mode or state.get('kis_view') != 'INQUIRY'
            or state.get('kis_ro_range') != 'BOTH' or _current_inputs() != inputs or current_version != version
            or state.get('_kis_inquiry_context') != (*connection, 'BOTH', inputs['KR'][2], inputs['US'][1], inputs['US'][2])
            or check is None or check['results']['positions'] is not record):
        clear_details()
        state['kis_view'] = 'INQUIRY'
        state[ERROR_KEY] = HINT
        return
    selected = state.get(PREFIX + 'choice_' + market)
    choices = holding_choices(market, record)
    choice = choices.get(selected) if isinstance(selected, str) else None
    if choice is None or choice['instrument'] is None:
        state.pop(PREFIX + 'choice_' + market, None)
        state[ERROR_KEY] = '현재 잔고에서 점검 가능한 종목을 선택하세요. OTCB는 조회 전용입니다.'
        return
    enter_precheck(client, choice['instrument'])


def _time(record):
    value = _timestamp(record.get('checked_at'))
    return datetime.fromisoformat(value).astimezone(timezone(timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S KST') if value else '미확인'


def _money(record, field, currency, positive=False):
    if record.get('status') != 'PASS': return None
    try:
        data = record['data']
        if data.get('currency') != currency: return None
        return f"{number(data[field], positive=positive):,f} {currency}"
    except (BrokerError, KeyError, TypeError, ValueError): return None


def _rows(record):
    data = record.get('data', {})
    if record.get('status') != 'PASS' or not isinstance(data, dict) or data.get('complete') is not True or not isinstance(data.get('positions'), list):
        return None
    return [{'종목': row.get('symbol'), '종목명': position_name(row.get('name')) or '미제공',
        '거래소': row.get('exchange'), '보유 수량': row.get('quantity'),
        '매도 가능 수량': row.get('sellable_quantity'), '통화': row.get('currency'),
        '점검 이동': '조회 전용' if row.get('exchange') == 'OTCB' else '별도 점검 필요'}
        for row in data['positions'] if isinstance(row, dict)]


def filter_rows(rows, search):
    term = search.strip().casefold() if isinstance(search, str) else ''
    return [row for row in rows if not term or any(term in str(row.get(key, '')).casefold() for key in ('종목', '종목명', '거래소'))]


def render(client, inputs, report, version):
    st.markdown('**통합 조회 상세**')
    st.caption('방금 받은 결과를 표시합니다. 상세 확인·검색·종목 선택은 추가 조회를 하지 않습니다. 원화와 달러는 합산하지 않습니다.')
    for market, label in (('KR', '국내'), ('US', '미국')):
        check = valid_check(st.session_state.get(STATE_KEY), client, inputs, market, report, version)
        if check is None:
            for suffix in ('choice_', 'search_', 'source_'): st.session_state.pop(PREFIX + suffix + market, None)
            saved = st.session_state.get(STATE_KEY)
            if isinstance(saved, dict) and isinstance(saved.get('markets'), dict): saved['markets'].pop(market, None)
            st.caption(label + ' · ' + HINT)
            continue
        with st.expander(label + ' 가격·가능금액·보유 종목', expanded=True):
            records = check['results']; currency = 'KRW' if market == 'KR' else 'USD'
            st.caption('가격·가능금액 조회 기준: ' + inputs[market][2] + ' · ' + inputs[market][1])
            for item, title, field, positive in (('quote', '조회 가격', 'price', True), ('power', '주문 가능금액', 'cash', False)):
                record = records[item]
                value = _money(record, field, currency, positive)
                st.metric(label + ' ' + title, value if value is not None else '확인 필요')
                st.caption(title + ' 확인: ' + _time(record))
            st.caption('조회 가격은 API 응답 기준입니다. 가능금액은 위 조회 종목·계산가격 기준이며 실제 주문은 별도 점검합니다.')
            record = records['positions']; rows = _rows(record)
            st.caption('잔고 확인: ' + _time(record) + (' · 이전 결과 유지' if market in report.get('retained_markets', []) else ' · 이번에 조회'))
            if rows is None:
                st.info('완료된 잔고 결과가 없습니다. 조회 진단을 확인하세요.')
                continue
            st.caption('조회 범위: ' + str(record['data'].get('scope', '미확인')) + ' · 연속조회 완료')
            if not rows:
                st.info('조회된 보유 주식이 없습니다.')
                continue
            choices = holding_choices(market, record)
            source_key = PREFIX + 'source_' + market
            if st.session_state.get(source_key) is not record:
                for suffix in ('choice_', 'search_'): st.session_state.pop(PREFIX + suffix + market, None)
                st.session_state[source_key] = record
            search = st.text_input(label + ' 보유 종목 검색', key=PREFIX + 'search_' + market,
                placeholder='종목명·코드·거래소', max_chars=80)
            visible = filter_rows(rows, search)
            st.caption(f'검색 결과 {len(visible)} / 전체 {len(rows)}행')
            st.dataframe(visible, hide_index=True, alt=label + ' 보유 종목 검색 결과와 매도 가능 수량')
            if any(row['거래소'] == 'OTCB' for row in rows): st.info('OTCB는 조회 전용입니다. 주문 전 점검으로 이동할 수 없습니다.')
            key = PREFIX + 'choice_' + market
            if st.session_state.get(key) is not None and (not isinstance(st.session_state.get(key), str) or st.session_state.get(key) not in choices):
                st.session_state.pop(key, None)
            selected = st.selectbox(label + ' 점검할 보유 종목', list(choices), index=None,
                format_func=lambda value, options=choices: options[value]['label'], key=key,
                placeholder='종목명·코드·거래소를 확인하여 선택하세요')
            choice = choices.get(selected) if isinstance(selected, str) else None
            st.button(label + ' 보유 종목으로 주문 전 점검', key=PREFIX + 'precheck_' + market,
                disabled=choice is None or choice['instrument'] is None, on_click=open_holding,
                args=(client, _context(client), inputs, market, record, version))
            st.caption('선택란은 전체 보유 종목 기준입니다. 시장·거래소·종목만 옮기며 수량·방향·가격·확인 결과는 새로 입력·점검합니다.')
