"""A session-only, explicit domestic/US operational inquiry overview."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import streamlit as st
from broker_inquiry_service import run_market_checks
from broker_market_retry import sanitize_report, retry_state, retry_failed_markets, FULL_CHECK_HINT
from connectors.kis_broker import BrokerError
from broker_inquiry_transfer import render_precheck_entry
from broker_inquiry_feedback import next_action
import broker_market_details as details


def render(client, clear_results):
    st.caption('국내와 미국을 순서대로 조회합니다. 각 시장의 새 시세로 가능금액을 계산하고 잔고를 확인합니다.')
    domestic = st.text_input('국내 조회 종목코드', value='005930', key='kis_ro_both_KR').strip().upper()
    exchange = st.selectbox('미국 조회 거래소', ['NASD', 'NYSE', 'AMEX'], key='kis_ro_both_exchange')
    us_symbol = st.text_input('미국 조회 종목코드', value='AAPL', key='kis_ro_both_US').strip().upper()
    context = (client.credentials.identity, client.credentials.mode, id(client), 'BOTH', domestic, exchange, us_symbol)
    if st.session_state.get('_kis_inquiry_context') != context:
        clear_results()
        st.session_state['_kis_inquiry_context'] = context
    st.caption('입력한 종목은 조회 기준입니다. 투자 추천이나 매매 지시가 아닙니다.')
    render_precheck_entry(client, 'BOTH')
    version = Path(__file__).with_name('VERSION').read_text(encoding='utf-8-sig').strip()
    inputs = details.queries(domestic, exchange, us_symbol)
    def collect(market, check):
        details.capture(client, inputs, market, check, version)
    if st.button('국내·미국 한 번에 점검', key='kis_ro_both_check', type='primary'):
        st.session_state.pop('_kis_market_report', None)
        details.clear_details()
        progress = st.empty()
        def update(completed, total, label):
            progress.progress(completed / total, text=label)
        try:
            report = run_market_checks(client, domestic, exchange, us_symbol,
                version=version, collect=collect, phase_progress=update)
        finally:
            progress.empty()
        st.session_state['_kis_market_report'] = report
    report = st.session_state.get('_kis_market_report')
    if report is not None:
        try:
            report = sanitize_report(report, version=version, mode=client.credentials.mode, us_exchange=exchange)
            st.session_state['_kis_market_report'] = report
        except (ValueError, TypeError, KeyError, OverflowError):
            st.session_state.pop('_kis_market_report', None)
            details.clear_details()
            report = None
            st.warning(FULL_CHECK_HINT)
    if report:
        targets, reason = retry_state(report, version=version, mode=client.credentials.mode, us_exchange=exchange)
        if st.button('확인 필요한 시장만 다시 점검', key='kis_ro_both_retry', disabled=not targets):
            st.session_state.pop('_kis_market_report', None)
            progress = st.empty()
            try:
                report = retry_failed_markets(client, report, domestic, exchange, us_symbol, version=version,
                    collect=collect, phase_progress=lambda completed, total, label: progress.progress(completed / total, text=label))
                st.session_state['_kis_market_report'] = report
                st.rerun()
            except BrokerError:
                report = None
                details.clear_details()
                st.warning(FULL_CHECK_HINT)
            finally:
                progress.empty()
        if reason:
            st.caption(reason)
        else:
            st.caption('최근 5분 이내 기록에서 확인 필요한 시장을 시세부터 새로 조회합니다. 성공한 시장은 이전 기록을 유지합니다.')
    if report:
        if report['status'] == 'PASS':
            if report.get('retained_markets'):
                st.success('국내·미국 조회 기록은 모두 성공입니다. 이전 결과의 확인 시각도 확인하세요.')
            else:
                st.success('국내·미국의 시세·주문 가능금액·잔고 조회가 모두 성공했습니다.')
        else:
            st.warning('일부 항목을 확인하지 못했습니다. 시장별 결과와 진단을 확인하세요.')
        rows = []
        labels = {'quote': '시세', 'power': '주문 가능금액', 'positions': '잔고'}
        statuses = {'PASS': '조회 성공', 'CHECK_REQUIRED': '확인 필요', 'SKIPPED': '건너뜀', 'UNKNOWN': '미확인'}
        kst = timezone(timedelta(hours=9))
        for market, label in (('KR', '국내'), ('US', '미국')):
            check = report['markets'][market]
            for name, item in labels.items():
                row = check['checks'][name]
                timestamp = datetime.fromisoformat(row['checked_at']).astimezone(kst).strftime('%Y-%m-%d %H:%M:%S')
                rows.append({'시장': label, '항목': item, '결과': statuses[row['status']],
                    '확인 시각(KST)': timestamp,
                    '이번 점검': '이전 결과 유지' if market in report.get('retained_markets', []) else '새 조회',
                    '소요 시간(ms)': row['elapsed_ms'], '다음 행동': next_action(row, name)})
        st.table(rows, alt='국내와 미국의 항목별 조회 결과, 확인 시각, 이전 결과 유지 여부와 소요 시간')
        for market, label in (('KR', '국내'), ('US', '미국')):
            check = report['markets'][market]
            timestamp = datetime.fromisoformat(check['finished_at']).astimezone(kst).strftime('%Y-%m-%d %H:%M:%S KST')
            st.caption(f"{label} 완료: {timestamp} · {check['elapsed_ms']}ms")
            if check['status'] != 'PASS':
                with st.expander(label + ' 조회 진단'):
                    st.json(check['checks'])
        if report.get('run_kind') == 'FAILED_MARKETS_RECHECK':
            st.caption(f"이번 재점검 소요 시간: {report['elapsed_ms']}ms · 이전 결과 유지 항목은 이번에 조회하지 않았습니다.")
        else:
            st.caption(f"전체 소요 시간: {report['elapsed_ms']}ms · 두 시장을 순서대로 확인한 시점별 기록입니다.")
        details.render(client, inputs, report, version)
        st.download_button('통합 점검 결과 저장', data=json.dumps(report, ensure_ascii=False, indent=2),
            file_name='StockInvestmentOS_market_checks.json', mime='application/json',
            key='kis_ro_both_report', on_click='ignore')
        st.caption('저장 파일에는 환경·상태·시각·오류 코드만 포함합니다. 키·계좌·종목·보유 내역·가격·금액은 제외합니다.')
    st.caption('자동으로 반복 조회하지 않습니다. 결과는 이 연결과 현재 입력에 대한 세션 기록이며 주문 허용·체결 확인이 아닙니다.')
