"""Korean display boundary. Never modify the original data or selected values."""
import re
import json
from pathlib import Path
from functools import lru_cache
import pandas as pd
from ui_korean import COLUMNS, TERMS
from ui_locale_glossary import WORDS, PHRASES
_LABELS={**TERMS,**WORDS,**PHRASES}
_FOLD={k.casefold():v for k,v in _LABELS.items()}
_CODE=re.compile(r'[A-Z][A-Z0-9]*(?:[ _/-][A-Z0-9]+)*')
_CODE_FIELDS={'status','state','gate','category','bucket','severity','priority','action','decision_type','review_status','lifecycle','lifecycle_state','evidence_status','thesis_status','clock_status','outcome_status','hash_status','scope','blocks_new_risk','source_type','source_tier','market','mode','side','direction'}

def label(value):
    if not isinstance(value,str):return value
    if value in COLUMNS:return COLUMNS[value]
    if value in _LABELS:return _LABELS[value]
    if re.search('[가-힣]',value):return value
    parts=re.split(r'[_\s]+',value)
    if parts and all(p.casefold() in _FOLD or p.isdigit() for p in parts):
        return ' '.join(_FOLD.get(p.casefold(),p) for p in parts)
    return value

def code(value):
    if not isinstance(value,str) or not _CODE.fullmatch(value):return value
    if value in _LABELS:return _LABELS[value]
    parts=re.split(r'[ _/-]+',value)
    if parts and all(p.casefold() in _FOLD or p.isdigit() for p in parts):
        return ' · '.join(_FOLD.get(p.casefold(),p) for p in parts)
    return value

def option(formatter=None):
    def format_value(value):
        if formatter:return formatter(value)
        return label(str(value))
    return format_value

def frame(value):
    if not isinstance(value,pd.DataFrame) or not value.columns.is_unique:return value
    from ui_review_queue_display import review_queue_display
    result=review_queue_display(value).copy(deep=True)
    for col in result.columns:
        if isinstance(col,str) and (col in _CODE_FIELDS or col.endswith(('_status','_state','_gate'))):
            result[col]=result[col].map(code)
    return result

def columns(value,existing=None):
    configured={}
    if isinstance(value,pd.DataFrame):
        configured={c:label(c) for c in value.columns if isinstance(c,str) and label(c)!=c}
    for key,value in (existing or {}).items():
        if isinstance(value,dict):
            value=value.copy()
            if isinstance(value.get('label'),str):value['label']=label(value['label'])
        elif isinstance(value,str):value=label(value)
        configured[key]=value
    return configured

def dataframe(st,value,*args,**kwargs):
    kwargs['column_config']=columns(value,kwargs.get('column_config'))
    return st.dataframe(frame(value),*args,**kwargs)

def editor(st,value,*args,**kwargs):
    # Only headers change. Returned edits retain canonical keys and codes.
    kwargs['column_config']=columns(value,kwargs.get('column_config'))
    return st.data_editor(value,*args,**kwargs)


@lru_cache(maxsize=1)
def _messages():
    data=json.loads(Path(__file__).with_name('ui_engine_messages.json').read_text(encoding='utf-8'))
    return data['exact'],[(re.compile(r['pattern']),r['parts'],r['needles']) for r in data['templates']]

@lru_cache(maxsize=2048)
def _message_text(value):
    exact,templates=_messages()
    if value in exact:return exact[value]
    if len(value)>2000:return value
    for regex,parts,needles in templates:
        if not all(part in value for part in needles):continue
        match=regex.fullmatch(value)
        if not match:continue
        result=[]
        for part in parts:
            if 'text' in part:result.append(part['text'])
            else:
                captured=match.group(part['capture']+1)
                result.append(code(captured) if part['code'] else captured)
        return ''.join(result)
    return value

def message(value):
    return _message_text(value) if isinstance(value,str) else value


def route(value):
    from ui_review_queue_display import NAVIGATION
    return NAVIGATION.get(value,value) if isinstance(value,str) else value
