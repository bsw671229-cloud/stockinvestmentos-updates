"""Explicit holding-to-precheck navigation; identifiers only, no broker calls."""
import streamlit as st
from connectors.kis_broker import BrokerError, us_position_identity
from connectors.kis_position_labels import position_name
from broker_inquiry_transfer import (ERROR_KEY, _context, instrument_values,
    clear_navigation_authority, enter_precheck)

CHOICE_KEY = 'kis_ro_holding_choice'
SOURCE_KEY = '_kis_holding_source'
CONTEXT_HINT = '연결·조회 조건 또는 잔고 결과가 바뀌었습니다. 현재 잔고에서 종목을 다시 선택하세요.'
SELECTION_HINT = '현재 잔고에서 점검할 보유 종목을 선택하세요.'
READ_ONLY_HINT = '이 거래소의 보유 내역은 조회 전용이며 주문 전 점검으로 옮길 수 없습니다.'


def clear_selection():
    for key in (CHOICE_KEY, SOURCE_KEY):
        st.session_state.pop(key, None)


def holding_choices(market, record):
    if not isinstance(record, dict) or record.get('status') != 'PASS':
        return {}
    data = record.get('data')
    if not isinstance(data, dict) or data.get('complete') is not True or not isinstance(data.get('positions'), list):
        return {}
    choices = {}
    for row in data['positions']:
        if not isinstance(row, dict):
            continue
        try:
            if market == 'KR':
                instrument = instrument_values(market, row.get('exchange'), row.get('symbol'))
                symbol, exchange = instrument['symbol'], instrument['exchange']
            elif market == 'US':
                symbol, exchange = us_position_identity({'ovrs_pdno': row.get('symbol'), 'ovrs_excg_cd': row.get('exchange')}, 1)
                # NAS is a balance response code; precheck/order inputs use NASD.
                instrument = (None if exchange == 'OTCB' else
                    instrument_values(market, 'NASD' if exchange == 'NAS' else exchange, symbol))
            else:
                continue
        except BrokerError:
            continue
        key = '|'.join((market, exchange, symbol))
        name = position_name(row.get('name')) or '미제공'
        choices.setdefault(key, dict(instrument=instrument, exchange=exchange,
            label=f'{name} · {symbol} · {exchange}' + (' · 조회 전용' if instrument is None else '')))
    return choices


def _query_context():
    state = st.session_state
    market = state.get('kis_ro_market')
    exchange = state.get('kis_ro_exchange_' + str(market))
    symbol = state.get('kis_ro_symbol_' + str(market))
    if not all(isinstance(value, str) for value in (market, exchange, symbol)):
        return None
    return market, exchange, symbol.strip().upper()


def open_holding(client, connection, query, record):
    state = st.session_state
    clear_navigation_authority()
    results = state.get('_kis_inquiry_results')
    if (state.get('_kis_client') is not client or _context(client) != connection
            or client.credentials.mode not in ('LIVE', 'PAPER')
            or state.get('kis_mode') != client.credentials.mode
            or state.get('kis_view') != 'INQUIRY' or state.get('kis_ro_range') != 'SINGLE'
            or _query_context() != query
            or state.get('_kis_inquiry_context') != (client.credentials.identity, *query)
            or not isinstance(results, dict) or results.get('positions') is not record):
        clear_selection()
        state['kis_view'] = 'INQUIRY'
        state[ERROR_KEY] = CONTEXT_HINT
        return
    choices = holding_choices(query[0], record)
    selected = state.get(CHOICE_KEY)
    choice = choices.get(selected) if isinstance(selected, str) else None
    if choice is None or choice['instrument'] is None:
        clear_selection()
        state[ERROR_KEY] = READ_ONLY_HINT if choice is not None else SELECTION_HINT
        return
    enter_precheck(client, choice['instrument'])


def render(client, query, record):
    choices = holding_choices(query[0], record)
    if not choices:
        clear_selection()
        return
    state = st.session_state
    connection = _context(client)
    previous = state.get(SOURCE_KEY) or {}
    if previous.get('record') is not record or previous.get('connection') != connection or previous.get('query') != query:
        clear_selection()
        state[SOURCE_KEY] = dict(record=record, connection=connection, query=query)
    selected = state.get(CHOICE_KEY)
    if selected is not None and (not isinstance(selected, str) or selected not in choices):
        state.pop(CHOICE_KEY, None)
    selected = st.selectbox('점검할 보유 종목', list(choices), index=None,
        format_func=lambda key: choices[key]['label'], key=CHOICE_KEY,
        placeholder='이름·종목코드·거래소를 확인하여 선택하세요')
    choice = choices.get(selected) if isinstance(selected, str) else None
    if choice is not None:
        if choice['instrument'] is None:
            st.info(READ_ONLY_HINT)
        else:
            instrument = choice['instrument']
            st.caption(f"이동할 종목: {'국내' if query[0] == 'KR' else '미국'} · {instrument['exchange']} · {instrument['symbol']}")
            if choice['exchange'] == 'NAS':
                st.caption('나스닥 잔고 코드 NAS는 점검 화면에서 NASD로 표시합니다.')
    st.button('선택한 보유 종목으로 주문 전 점검', key='kis_ro_holding_precheck',
        disabled=choice is None or choice['instrument'] is None,
        on_click=open_holding, args=(client, connection, query, record))
    st.caption('시장·거래소·종목만 옮깁니다. 보유 수량·가격·점검 결과는 옮기지 않으며, 추가 조회나 주문은 하지 않습니다.')
