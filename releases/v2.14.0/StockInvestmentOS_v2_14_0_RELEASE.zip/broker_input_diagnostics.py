"""Explain rejected precheck inputs; never approve, mutate or query an order."""
from connectors.kis_broker import BrokerError, input_number, validate_order


def input_issues(order, limits):
    """Return field hints only. Existing execution validators remain authoritative."""
    if not isinstance(order, dict) or not isinstance(limits, dict):
        return [dict(field='form', label='주문 조건', message='입력 화면에서 조건을 다시 입력하세요.')]
    market = order.get('market')
    currency = ' (KRW)' if market == 'KR' else ' (USD)' if market == 'US' else ''
    labels = dict(market='점검 시장', exchange='점검 거래소', symbol='점검 종목코드',
        side='점검 방향', quantity='점검 수량 (주)', limit_price='점검 지정가'+currency,
        max_notional='금액 상한'+currency, fee_buffer_pct='비용 여유율 (%)',
        max_quote_gap_pct='조회 가격과 지정가 차이 한도 (%)', downside_pct='하락 가정 (%)',
        max_scenario_loss='가정 손실 예산'+currency, risk_attested='조건 확인 체크')
    issues = {}

    def add(field, message):
        issues.setdefault(field, dict(field=field, label=labels[field], message=message))

    valid_market = market in ('KR', 'US')
    if not valid_market:
        add('market', '국내 또는 미국을 선택하세요.')
    else:
        exchanges = ('KRX',) if market == 'KR' else ('NASD', 'NYSE', 'AMEX')
        if order.get('exchange') not in exchanges:
            add('exchange', '해당 시장에서 지원하는 거래소를 선택하세요.')
    if order.get('side') not in ('BUY', 'SELL'):
        add('side', '매수 또는 매도를 직접 선택하세요.')

    # Known-valid context isolates each field through the unchanged validator.
    # These temporary probes are never returned, persisted or sent to a client.
    probe_market = market if valid_market else 'KR'
    probe = dict(market=probe_market, exchange='KRX' if probe_market == 'KR' else 'NASD',
                 symbol='005930' if probe_market == 'KR' else 'AAPL',
                 side='BUY', quantity=1, limit_price='1')
    fields = ['quantity']
    if valid_market:
        fields = ['symbol', 'quantity', 'limit_price']
    hints = dict(symbol='국내는 종목코드 6자리, 미국은 지원되는 티커를 입력하세요.',
                 quantity='1~1,000,000주 범위의 정수를 입력하세요.',
                 limit_price=('0보다 크고 1,000,000,000 이하인 가격을 '
                              + ('원' if market == 'KR' else '센트')
                              + ' 단위로 입력하세요. 쉼표·통화 기호는 빼세요.'))
    for field in fields:
        try:
            validate_order({**probe, field: order.get(field)})
        except BrokerError:
            add(field, hints[field])
    if not valid_market:
        try:
            input_number(order.get('limit_price'), '지정가', positive=True)
        except BrokerError:
            add('limit_price', '0보다 큰 유효한 숫자를 입력하고 시장을 선택하세요.')

    specs = [('max_notional', True, None), ('fee_buffer_pct', False, 5),
             ('max_quote_gap_pct', True, 20)]
    if order.get('side') == 'BUY':
        specs += [('downside_pct', True, 100), ('max_scenario_loss', True, None)]
    values = {}
    for field, positive, maximum in specs:
        try:
            value = input_number(limits.get(field), '입력값', positive=positive)
        except BrokerError as exc:
            add(field, str(exc).removeprefix('입력값: '))
            continue
        if maximum is not None and value > maximum:
            add(field, ('0 초과 ' if positive else '0 이상 ') + str(maximum) + '% 이하로 입력하세요.')
        else:
            values[field] = value

    try:
        checked = validate_order(order)
    except (BrokerError, TypeError, ValueError):
        checked = None
    if checked is not None and 'fee_buffer_pct' in values:
        gross = input_number(checked['limit_price'], '지정가', positive=True) * checked['quantity']
        fee = values['fee_buffer_pct']
        if 'max_notional' in values and gross * (1 + fee / 100) > values['max_notional']:
            add('max_notional', '비용 여유 포함 금액이 상한을 초과합니다. 수량·지정가·상한을 검토하세요.')
        if checked['side'] == 'BUY' and all(k in values for k in ('downside_pct', 'max_scenario_loss')):
            loss = gross * values['downside_pct'] / 100 + gross * fee / 100
            if loss > values['max_scenario_loss']:
                add('max_scenario_loss', '계산한 가정 손실이 예산을 초과합니다. 수량·가격·손실 가정과 예산을 검토하세요.')
    if limits.get('risk_attested') is not True:
        add('risk_attested', '위 입력값과 가정을 검토한 뒤 조건 확인을 직접 체크하세요.')
    return [issues[field] for field in labels if field in issues]
