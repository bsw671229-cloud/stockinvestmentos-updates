"""Explicit, session-only instrument navigation. No broker request or order preparation."""
import streamlit as st
from connectors.kis_broker import BrokerError, validate_order

INPUT_HINT = '시장·거래소·종목코드를 확인한 뒤 다시 이동하세요.'
CONTEXT_HINT = '연결 또는 조회 화면이 바뀌었습니다. 현재 화면에서 다시 이동하세요.'
ERROR_KEY = '_kis_inquiry_transfer_error'


def instrument_values(market, exchange, symbol):
    if not all(isinstance(value, str) for value in (market, exchange, symbol)):
        raise BrokerError(INPUT_HINT)
    # Reuse adapter syntax validation; the local placeholders are never retained.
    order = validate_order(dict(market=market, exchange=exchange, symbol=symbol,
                                side='BUY', quantity=1, limit_price='1'))
    return {key: order[key] for key in ('market', 'exchange', 'symbol')}


def _context(client):
    return (client.credentials.identity, client.credentials.mode, id(client))


def clear_navigation_authority():
    """Invalidate old prechecks and order confirmations before either navigation path."""
    from broker_precheck import clear_precheck
    state = st.session_state
    clear_precheck()
    for key in list(state):
        if key.startswith('kis_confirm_') or key in (
                '_kis_order_draft', '_kis_pending', 'kis_allow_live', 'kis_risk_attested',
                '_kis_order_selection', '_kis_notice', 'kis_side', ERROR_KEY):
            state.pop(key, None)


def enter_precheck(client, instrument):
    """Apply only already-validated identifiers after a caller has checked context."""
    from broker_inquiries import clear_results
    clear_results()
    state = st.session_state
    market = instrument['market']
    state['_kis_precheck_account'] = _context(client)
    state['kis_pc_market'] = market
    state['kis_pc_exchange_' + market] = instrument['exchange']
    state['kis_pc_symbol_' + market] = instrument['symbol']
    state['kis_view'] = 'PRECHECK'


def open_precheck(client, rendered_context, scope, selected_market=None):
    clear_navigation_authority()
    state = st.session_state
    if (state.get('_kis_client') is not client or _context(client) != rendered_context
            or client.credentials.mode not in ('LIVE', 'PAPER')
            or state.get('kis_mode') != client.credentials.mode
            or state.get('kis_view') != 'INQUIRY'
            or scope not in ('SINGLE', 'BOTH') or state.get('kis_ro_range') != scope):
        state['kis_view'] = 'INQUIRY'
        state[ERROR_KEY] = CONTEXT_HINT
        return
    if scope == 'SINGLE':
        market = state.get('kis_ro_market')
        exchange = state.get('kis_ro_exchange_' + str(market))
        symbol = state.get('kis_ro_symbol_' + str(market))
    else:
        market = selected_market
        exchange = 'KRX' if market == 'KR' else state.get('kis_ro_both_exchange')
        symbol = state.get('kis_ro_both_' + str(market))
    try:
        instrument = instrument_values(market, exchange, symbol)
    except BrokerError:
        state[ERROR_KEY] = INPUT_HINT
        return
    enter_precheck(client, instrument)


def render_precheck_entry(client, scope):
    context = _context(client)
    if scope == 'SINGLE':
        st.button('입력한 종목으로 주문 전 점검', key='kis_ro_precheck',
                  on_click=open_precheck, args=(client, context, scope))
    elif scope == 'BOTH':
        with st.container(horizontal=True):
            for market, label in (('KR', '국내'), ('US', '미국')):
                st.button(label + ' 종목으로 주문 전 점검', key='kis_ro_both_precheck_' + market,
                          on_click=open_precheck, args=(client, context, scope, market))
    st.caption('시장·거래소·종목만 옮깁니다. 점검 화면에서 매수·매도 방향, 수량, 지정가와 상한을 확인하세요.')
