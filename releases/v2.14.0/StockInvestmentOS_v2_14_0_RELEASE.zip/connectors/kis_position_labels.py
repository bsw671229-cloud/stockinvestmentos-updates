"""Optional balance labels. Never used as instrument identity or order input."""
import unicodedata


def position_name(value, sensitive=()):
    """Return bounded display text or an empty label; malformed names are optional."""
    if not isinstance(value, str) or len(value) > 240:
        return ''
    if any(unicodedata.category(char).startswith('C') and char not in '\t\r\n' for char in value):
        return ''
    label = ' '.join(value.split())
    if not label or len(label) > 120:
        return ''
    compact = ''.join(char for char in label if char.isalnum())
    for secret in sensitive:
        if not isinstance(secret, str) or not secret:
            continue
        if secret in value or ' '.join(secret.split()) in label:
            return ''
        normalized = ''.join(char for char in secret if char.isalnum())
        if len(normalized) >= 8 and normalized in compact:
            return ''
    return label
