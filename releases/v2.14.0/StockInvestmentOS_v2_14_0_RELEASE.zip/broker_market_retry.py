"""Explicit failed-market rechecks; retain only timestamped, sanitized metadata."""
from datetime import datetime, timezone
import time
from broker_inquiry_service import build_check_report, run_inquiry_check, _integer, _timestamp
from connectors.kis_broker import BrokerError

MAX_REPORT_AGE_SECONDS = 300
FULL_CHECK_HINT = '이전 기록을 재사용할 수 없습니다. 국내·미국 한 번에 점검을 다시 실행하세요.'


def sanitize_report(report, *, version, mode, us_exchange, now=None, max_age=None):
    """Validate history without copying arbitrary data from session state."""
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None or not isinstance(report, dict):
        raise ValueError(FULL_CHECK_HINT)

    def require(condition):
        if not condition:
            raise ValueError(FULL_CHECK_HINT)

    def timestamp(value):
        clean = _timestamp(value)
        require(clean is not None)
        dt = datetime.fromisoformat(clean)
        age = (now - dt).total_seconds()
        require(age >= 0 and (max_age is None or age <= max_age))
        return dt

    def envelope(record, scope):
        require(isinstance(record, dict))
        require(type(record.get('schema_version')) is int and record['schema_version'] == 1)
        require(record.get('scope') == scope and record.get('app_version') == version)
        require(record.get('mode') == mode and mode in ('LIVE', 'PAPER'))
        require(record.get('order_permission') == 'NOT_GRANTED_BY_INQUIRY')
        require(record.get('broker_order_test') == 'NOT_PERFORMED')
        require(_integer(record.get('elapsed_ms'), 86400000) is not None)
        start, finish = timestamp(record.get('started_at')), timestamp(record.get('finished_at'))
        require(start <= finish)
        return start, finish

    run_start, run_finish = envelope(report, 'MULTI_MARKET_READ_ONLY_INQUIRIES')
    markets = report.get('markets')
    require(isinstance(markets, dict) and set(markets) == {'KR', 'US'})
    require(us_exchange in ('NASD', 'NYSE', 'AMEX'))
    reports, windows = {}, {}
    for market, exchange in (('KR', 'KRX'), ('US', us_exchange)):
        record = markets[market]
        start, finish = envelope(record, 'READ_ONLY_INQUIRIES')
        require(finish <= run_finish)
        windows[market] = (start, finish)
        require(record.get('market') == market and record.get('exchange') == exchange)
        checks = record.get('checks')
        require(isinstance(checks, dict) and set(checks) == {'quote', 'power', 'positions'})
        previous = start
        for name in ('quote', 'power', 'positions'):
            item = checks[name]
            require(isinstance(item, dict) and item.get('status') in ('PASS', 'CHECK_REQUIRED', 'SKIPPED', 'UNKNOWN'))
            checked = timestamp(item.get('checked_at'))
            require(previous <= checked <= finish)
            previous = checked
            require(_integer(item.get('elapsed_ms'), 86400000) is not None)
        clean = build_check_report({'results': checks, 'started_at': record['started_at'],
            'finished_at': record['finished_at'], 'elapsed_ms': record['elapsed_ms']},
            version=version, mode=mode, market=market, exchange=exchange)
        require(clean['app_version'] != 'UNKNOWN' and record.get('status') == clean['status'])
        reports[market] = clean
    status = 'PASS' if all(r['status'] == 'PASS' for r in reports.values()) else 'CHECK_REQUIRED'
    require(report.get('status') == status)
    result = dict(schema_version=1, scope='MULTI_MARKET_READ_ONLY_INQUIRIES', app_version=version,
        mode=mode, status=status, started_at=_timestamp(report['started_at']),
        finished_at=_timestamp(report['finished_at']), elapsed_ms=report['elapsed_ms'], markets=reports,
        order_permission='NOT_GRANTED_BY_INQUIRY', broker_order_test='NOT_PERFORMED')
    if 'run_kind' in report:
        refreshed = report.get('refreshed_markets')
        require(report['run_kind'] == 'FAILED_MARKETS_RECHECK' and isinstance(refreshed, list))
        require(bool(refreshed) and all(isinstance(m, str) and m in ('KR', 'US') for m in refreshed))
        require(refreshed == [m for m in ('KR', 'US') if m in refreshed])
        retained = [m for m in ('KR', 'US') if m not in refreshed]
        require(report.get('retained_markets') == retained)
        require(all(reports[m]['status'] == 'PASS' for m in retained))
        require(all(windows[m][0] >= run_start for m in refreshed))
        require(all(windows[m][1] <= run_start for m in retained))
        result.update(run_kind='FAILED_MARKETS_RECHECK', refreshed_markets=refreshed[:], retained_markets=retained)
    else:
        require(all(start >= run_start for start, finish in windows.values()))
    return result


def retry_state(report, *, version, mode, us_exchange, now=None):
    try:
        clean = sanitize_report(report, version=version, mode=mode, us_exchange=us_exchange,
            now=now, max_age=MAX_REPORT_AGE_SECONDS)
    except (ValueError, TypeError, KeyError, OverflowError):
        return [], FULL_CHECK_HINT
    markets = [m for m in ('KR', 'US') if clean['markets'][m]['status'] != 'PASS']
    return markets, '' if markets else '모두 조회 성공입니다. 새 결과가 필요하면 국내·미국 한 번에 점검을 누르세요.'


def retry_failed_markets(client, previous, domestic_symbol, us_exchange, us_symbol, *, version, progress=None):
    """Revalidate at invocation, then freshly query each failed market in order."""
    try:
        clean = sanitize_report(previous, version=version, mode=client.credentials.mode,
            us_exchange=us_exchange, max_age=MAX_REPORT_AGE_SECONDS)
    except (ValueError, TypeError, KeyError, OverflowError):
        raise BrokerError(FULL_CHECK_HINT) from None
    targets = [m for m in ('KR', 'US') if clean['markets'][m]['status'] != 'PASS']
    if not targets:
        raise BrokerError('모두 조회 성공입니다. 새 결과가 필요하면 전체 점검을 실행하세요.')
    start = time.monotonic()
    started_at = datetime.now(timezone.utc).isoformat()
    reports = clean['markets']

    def notify(completed, label):
        if progress is not None:
            try:
                progress(completed, len(targets), label)
            except Exception:
                pass

    for index, market in enumerate(targets):
        notify(index, ('국내' if market == 'KR' else '미국') + ' 다시 조회 중')
        exchange, symbol = ('KRX', domestic_symbol) if market == 'KR' else (us_exchange, us_symbol)
        check = run_inquiry_check(client, market, exchange, symbol)
        reports[market] = build_check_report(check, version=version,
            mode=client.credentials.mode, market=market, exchange=exchange)
    notify(len(targets), '재점검 완료')
    return dict(schema_version=1, scope='MULTI_MARKET_READ_ONLY_INQUIRIES', app_version=version,
        mode=client.credentials.mode,
        status='PASS' if all(r['status'] == 'PASS' for r in reports.values()) else 'CHECK_REQUIRED',
        started_at=started_at, finished_at=datetime.now(timezone.utc).isoformat(),
        elapsed_ms=round((time.monotonic() - start) * 1000), markets=reports,
        run_kind='FAILED_MARKETS_RECHECK', refreshed_markets=targets,
        retained_markets=[m for m in ('KR', 'US') if m not in targets],
        order_permission='NOT_GRANTED_BY_INQUIRY', broker_order_test='NOT_PERFORMED')
