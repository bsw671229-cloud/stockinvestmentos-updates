"""Translate exact engine descriptions only when corroborated by source summary."""
SPECS = {
 'Canonical Assumption': ('assumption_approval','REVIEW','Assumption Approval','가정 승인',{'APPROVED':'승인됨','REVIEW':'검토 필요'}),
 'Thesis Invalidation': ('invalidation_status','NOT TRIGGERED','Invalidation','투자 가설 무효화',{'NOT TRIGGERED':'미발생','TRIGGERED':'발생','CHECK':'확인 필요'}),
 'Lifecycle': ('lifecycle','OBSERVE','Lifecycle','투자 단계',{'OBSERVE':'관찰','INITIAL':'초기','CORE':'핵심','MAX':'최대','EXIT':'청산'}),
 'Add Freeze': ('add_freeze','REVIEW','Add Freeze','추가 투자 보류',{'OFF':'해제','ON':'설정','REVIEW':'검토 필요'}),
 'Portfolio Fit': ('portfolio_fit','REVIEW','Portfolio Fit','포트폴리오 적합성',{'PASS':'정상','REVIEW':'검토 필요','BLOCKED':'진행 차단'}),
}

def detail_text(gate, detail, summary):
    if not isinstance(gate,str) or not isinstance(detail,str) or not isinstance(summary,dict): return detail
    spec=SPECS.get(gate)
    if spec is None: return detail
    key,default,prefix,label,values=spec
    raw=summary.get(key)
    value='' if raw is None else str(raw).strip()
    if value.lower() in {'nan','none','nat'}: value=''
    value=value.upper() or default
    if value not in values or detail != f'{prefix} = {value}': return detail
    return f'{label} = {values[value]}'
