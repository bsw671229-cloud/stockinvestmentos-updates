"""Fixed, bounded read-only guidance. Never reflect raw messages or payloads."""
from datetime import datetime, timedelta, timezone
from broker_inquiry_service import _diagnostic, _timestamp, _integer

LABELS = {'quote': '시세', 'power': '주문 가능금액', 'positions': '잔고'}
STATUSES = {'PASS': '조회 성공', 'CHECK_REQUIRED': '확인 필요', 'SKIPPED': '건너뜀', 'UNKNOWN': '미확인'}


def next_action(record, item=None):
    if not isinstance(record, dict): return '한 번에 조회를 실행하세요.'
    if record.get('status') == 'PASS': return '확인 시각을 확인하세요. 새 결과가 필요하면 다시 조회하세요.'
    if record.get('status') == 'SKIPPED': return '시세부터 다시 조회한 뒤 주문 가능금액을 확인하세요.'
    diagnostic = _diagnostic(record.get('diagnostic'))
    if diagnostic.get('balance_validation'):
        return '잔고 응답 형식을 확인해야 합니다. 조회 진단의 항목·사유를 확인하세요.'
    http = diagnostic.get('http_status')
    if http in (401, 403): return '연결 설정과 이용 권한을 확인하고 다시 연결한 뒤 조회하세요.'
    if http == 429: return '잠시 기다린 뒤 다시 조회하세요. 반복해서 누르지 마세요.'
    if isinstance(http, int) and http >= 500:
        return '잠시 후 해당 항목을 다시 조회하세요. 반복되면 조회 진단을 확인하세요.'
    return '입력·연결 조건을 확인하고 다시 조회하세요. 반복되면 조회 진단을 확인하세요.'


def summary_rows(report):
    rows = []
    for name, label in LABELS.items():
        record = report.get('checks', {}).get(name, {})
        stamp = _timestamp(record.get('checked_at'))
        timestamp = datetime.fromisoformat(stamp).astimezone(timezone(timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S') if stamp else '미확인'
        elapsed = _integer(record.get('elapsed_ms'), 86400000)
        rows.append({'항목': label, '결과': STATUSES.get(record.get('status'), '미확인'), '확인 시각(KST)': timestamp,
            '이번 점검': '이전 결과 유지' if name in report.get('retained_items', []) else '새 조회',
            '소요 시간(ms)': elapsed, '다음 행동': next_action(record, name)})
    return rows
