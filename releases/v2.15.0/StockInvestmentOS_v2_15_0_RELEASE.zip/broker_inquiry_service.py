"""Explicit, serial read-only checks and allowlisted diagnostic reports."""
from datetime import datetime, timezone
import re
import time
from connectors.kis_broker import BrokerError, number


def resolve_reference(record, method, manual_price, currency, now=None):
    if method == 'MANUAL':
        return str(number(manual_price, positive=True)), {'kind': 'MANUAL', 'label': '사용자 입력 계산가격 · 최신 시세 아님'}
    if not record or record.get('status') != 'PASS':
        raise BrokerError('먼저 시세를 조회하거나 계산가격 입력을 선택하세요')
    quote = record['data']
    if quote.get('currency') != currency:
        raise BrokerError('시세와 조회 통화가 일치하지 않습니다')
    try:
        fetched = datetime.fromisoformat(quote['fetched_at'])
        if fetched.tzinfo is None: raise ValueError()
        age = ((now or datetime.now(timezone.utc)) - fetched).total_seconds()
    except (ValueError, TypeError, KeyError):
        raise BrokerError('시세 조회시각을 확인할 수 없습니다') from None
    if not 0 <= age <= 60:
        raise BrokerError('조회 가격이 60초를 지났습니다. 시세를 다시 조회하거나 계산가격을 직접 입력하세요')
    return str(number(quote['price'], positive=True)), {
        'kind': 'QUOTE', 'label': '최근 API 조회 가격', 'quote_fetched_at': quote['fetched_at']}


def _run(client, action):
    client.last_diagnostic = {}
    start = time.monotonic()
    try:
        data = action()
        result = {'status': 'PASS', 'data': data}
    except BrokerError as exc:
        result = {'status': 'CHECK_REQUIRED', 'message': str(exc)}
    except Exception:
        result = {'status': 'CHECK_REQUIRED', 'message': '조회 결과를 확인하지 못했습니다. 해당 항목을 다시 점검하세요.'}
    result.update(checked_at=datetime.now(timezone.utc).isoformat(),
        elapsed_ms=round((time.monotonic() - start) * 1000), diagnostic=dict(client.last_diagnostic))
    return result


def run_inquiry_check(client, market, exchange, symbol, *, progress=None):
    """Fresh quote first, then dependent power, then independent balance."""
    start = time.monotonic()
    started_at = datetime.now(timezone.utc).isoformat()
    def notify(completed, label):
        if progress is not None:
            try: progress(completed, 3, label)
            except Exception: pass
    notify(0, '시세 조회 중')
    quote = _run(client, lambda: client.inquire_quote(market, exchange, symbol))
    notify(1, '주문 가능금액 조회 중' if quote['status'] == 'PASS' else '새 시세 확인 실패 · 금액 조회 건너뜀')
    if quote['status'] == 'PASS':
        def power_query():
            price, reference = resolve_reference(quote, 'QUOTE', '0', 'KRW' if market == 'KR' else 'USD')
            return {**client.inquire_buying_power(market, exchange, symbol, price), 'basis': reference}
        power = _run(client, power_query)
    else:
        power = {'status': 'SKIPPED', 'message': '새 시세를 확인하지 못해 금액 조회를 건너뛰었습니다. 시세부터 다시 확인하세요.',
                 'checked_at': datetime.now(timezone.utc).isoformat(), 'elapsed_ms': 0, 'diagnostic': {}}
    notify(2, '잔고 조회 중')
    positions = _run(client, lambda: client.positions(market, exchange))
    notify(3, '선택 시장 조회 완료')
    return {'results': {'quote': quote, 'power': power, 'positions': positions},
            'started_at': started_at, 'finished_at': datetime.now(timezone.utc).isoformat(),
            'elapsed_ms': round((time.monotonic() - start) * 1000)}


def _enum(value, allowed):
    return value if isinstance(value, str) and value in allowed else 'UNKNOWN'


def _integer(value, maximum):
    return value if type(value) is int and 0 <= value <= maximum else None


def _timestamp(value):
    if not isinstance(value, str) or len(value) > 40:
        return None
    try:
        value = datetime.fromisoformat(value)
        return value.astimezone(timezone.utc).isoformat() if value.tzinfo is not None else None
    except (ValueError, OverflowError):
        return None


def _code(value):
    return value if isinstance(value, str) and re.fullmatch(r'[A-Z]{3,4}[0-9]{3,5}', value) else 'UNKNOWN'


def _diagnostic(value):
    if not isinstance(value, dict):
        return {}
    result = {'http_status': _integer(value.get('http_status'), 599),
              'attempts': _integer(value.get('attempts'), 2),
              'broker_code': _code(value.get('broker_code'))}
    first = value.get('first_error')
    if isinstance(first, dict):
        result['first_error'] = {'http_status': _integer(first.get('http_status'), 599),
                                 'broker_code': _code(first.get('broker_code'))}
    validation = value.get('balance_validation')
    if isinstance(validation, dict):
        result['balance_validation'] = {
            'stage': _enum(validation.get('stage'), {'BALANCE_RESPONSE'}),
            'field': _enum(validation.get('field'), {'ovrs_excg_cd', 'ovrs_pdno'}),
            'reason': _enum(validation.get('reason'), {'MISSING', 'TYPE', 'FORMAT', 'UNSUPPORTED'}),
            'row': _integer(validation.get('row'), 1000000)}
    return result


def build_check_report(check, *, version, mode, market, exchange):
    """Never serialize response data, exceptions, credentials or account identity."""
    records = check.get('results', {})
    items = {}
    for name in ('quote', 'power', 'positions'):
        record = records.get(name, {})
        items[name] = {'status': _enum(record.get('status'), {'PASS', 'CHECK_REQUIRED', 'SKIPPED'}),
                       'checked_at': _timestamp(record.get('checked_at')),
                       'elapsed_ms': _integer(record.get('elapsed_ms'), 86400000),
                       'diagnostic': _diagnostic(record.get('diagnostic'))}
    return {'schema_version': 1,
            'app_version': version if isinstance(version, str) and re.fullmatch(r'v\d{1,3}\.\d{1,3}\.\d{1,3}', version) else 'UNKNOWN',
            'scope': 'READ_ONLY_INQUIRIES', 'mode': _enum(mode, {'LIVE', 'PAPER'}),
            'market': _enum(market, {'KR', 'US'}),
            'exchange': _enum(exchange, {'KRX'} if market == 'KR' else {'NASD', 'NYSE', 'AMEX'} if market == 'US' else set()),
            'status': 'PASS' if all(item['status'] == 'PASS' for item in items.values()) else 'CHECK_REQUIRED',
            'started_at': _timestamp(check.get('started_at')), 'finished_at': _timestamp(check.get('finished_at')),
            'elapsed_ms': _integer(check.get('elapsed_ms'), 86400000), 'checks': items,
            'order_permission': 'NOT_GRANTED_BY_INQUIRY', 'broker_order_test': 'NOT_PERFORMED'}


def run_market_checks(client, domestic_symbol, us_exchange, us_symbol, *, version, progress=None):
    """Fixed, sequential KR/US checks; return sanitized metadata only."""
    start = time.monotonic()
    started_at = datetime.now(timezone.utc).isoformat()
    reports = {}

    def notify(completed, label):
        if progress is not None:
            try:
                progress(completed, 2, label)
            except Exception:
                pass  # A presentation failure must not interrupt independent checks.

    for index, (market, exchange, symbol, label) in enumerate((
            ('KR', 'KRX', domestic_symbol, '국내 조회 중'),
            ('US', us_exchange, us_symbol, '미국 조회 중'))):
        notify(index, label)
        check = run_inquiry_check(client, market, exchange, symbol)
        reports[market] = build_check_report(check, version=version,
            mode=client.credentials.mode, market=market, exchange=exchange)
    notify(2, '국내·미국 점검 완료')
    return {'schema_version': 1, 'scope': 'MULTI_MARKET_READ_ONLY_INQUIRIES',
            'app_version': reports['KR']['app_version'], 'mode': reports['KR']['mode'],
            'status': 'PASS' if all(r['status'] == 'PASS' for r in reports.values()) else 'CHECK_REQUIRED',
            'started_at': started_at, 'finished_at': datetime.now(timezone.utc).isoformat(),
            'elapsed_ms': round((time.monotonic() - start) * 1000), 'markets': reports,
            'order_permission': 'NOT_GRANTED_BY_INQUIRY', 'broker_order_test': 'NOT_PERFORMED'}
