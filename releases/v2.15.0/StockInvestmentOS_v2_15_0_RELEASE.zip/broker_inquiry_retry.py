"""Explicit session-bound failed-item recovery. No orders, persistence or cache."""
from datetime import datetime, timezone
import time
from connectors.kis_broker import BrokerError
from broker_inquiry_service import _run, _integer, _timestamp, resolve_reference, build_check_report

STATE_KEY = '_kis_inquiry_retry'
ITEMS = ('quote', 'power', 'positions')
LABELS = {'quote': '시세', 'power': '주문 가능금액', 'positions': '잔고'}
FULL_HINT = '기록이 바뀌었거나 5분을 지났습니다. 선택 시장 한 번에 조회를 다시 실행하세요.'
DONE_HINT = '모두 조회 성공입니다. 새 결과가 필요하면 선택 시장 한 번에 조회를 누르세요.'


def snapshot(client, query, check, version):
    return {'connection': (client.credentials.identity, client.credentials.mode, id(client)),
            'query': query, 'version': version, 'check': {**check, 'results': dict(check['results'])}}


def _plan(saved, client, query, results, version, now):
    def require(condition):
        if not condition:
            raise ValueError(FULL_HINT)
    require(isinstance(saved, dict) and isinstance(results, dict))
    require(saved.get('connection') == (client.credentials.identity, client.credentials.mode, id(client)))
    require(client.credentials.mode in ('LIVE', 'PAPER') and saved.get('query') == query and saved.get('version') == version)
    require(isinstance(query, tuple) and len(query) == 3 and query[0] in ('KR', 'US'))
    check = saved.get('check')
    require(isinstance(check, dict) and isinstance(check.get('results'), dict) and set(check['results']) == set(ITEMS))
    require(_integer(check.get('elapsed_ms'), 86400000) is not None)
    def timestamp(value):
        clean = _timestamp(value)
        require(clean is not None)
        point = datetime.fromisoformat(clean)
        require(0 <= (now - point).total_seconds() <= 300)
        return point
    start, finish = timestamp(check.get('started_at')), timestamp(check.get('finished_at'))
    require(start <= finish)
    for name in ITEMS:
        record = check['results'][name]
        require(isinstance(record, dict) and results.get(name) is record)
        require(record.get('status') in ('PASS', 'CHECK_REQUIRED', 'SKIPPED'))
        require(timestamp(record.get('checked_at')) <= finish)
        require(_integer(record.get('elapsed_ms'), 86400000) is not None)
        if record['status'] == 'PASS':
            require(isinstance(record.get('data'), dict))
            if name == 'positions': require(record['data'].get('complete') is True)
            if name == 'power': require(record['data'].get('basis', {}).get('kind') == 'QUOTE')
    targets = {name for name in ITEMS if results[name]['status'] != 'PASS'}
    if 'quote' in targets:
        targets.add('power')
    elif 'power' in targets:
        try:
            resolve_reference(results['quote'], 'QUOTE', '0', 'KRW' if query[0] == 'KR' else 'USD', now=now)
        except (BrokerError, ValueError, KeyError, TypeError, OverflowError):
            targets.add('quote')
    return [name for name in ITEMS if name in targets]


def retry_state(saved, client, query, results, version, now=None):
    try:
        targets = _plan(saved, client, query, results, version, now or datetime.now(timezone.utc))
        return targets, '' if targets else DONE_HINT
    except (ValueError, TypeError, KeyError, OverflowError, AttributeError):
        return [], FULL_HINT


def retry_failed_items(saved, client, query, results, version, progress=None):
    targets, reason = retry_state(saved, client, query, results, version)
    if not targets:
        raise BrokerError(reason)
    market, exchange, symbol = query
    records = dict(results)
    started_at = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    def notify(completed, label):
        if progress is not None:
            try: progress(completed, len(targets), label)
            except Exception: pass
    for index, name in enumerate(targets):
        notify(index, LABELS[name] + ' 다시 조회 중')
        if name == 'quote':
            records[name] = _run(client, lambda: client.inquire_quote(market, exchange, symbol))
        elif name == 'power':
            if records['quote']['status'] == 'PASS':
                def lookup():
                    price, reference = resolve_reference(records['quote'], 'QUOTE', '0', 'KRW' if market == 'KR' else 'USD')
                    return {**client.inquire_buying_power(market, exchange, symbol, price), 'basis': reference}
                records[name] = _run(client, lookup)
            else:
                records[name] = dict(status='SKIPPED', message='새 시세를 확인하지 못해 금액 조회를 건너뛰었습니다.',
                    checked_at=datetime.now(timezone.utc).isoformat(), elapsed_ms=0, diagnostic={})
        else:
            records[name] = _run(client, lambda: client.positions(market, exchange))
    notify(len(targets), '재조회 완료')
    return dict(results={name: records[name] for name in ITEMS}, started_at=started_at,
        finished_at=datetime.now(timezone.utc).isoformat(), elapsed_ms=round((time.monotonic() - start) * 1000),
        refreshed_items=targets, retained_items=[name for name in ITEMS if name not in targets])


def recheck_report(check, *, version, mode, market, exchange):
    report = build_check_report(check, version=version, mode=mode, market=market, exchange=exchange)
    refreshed = check['refreshed_items']
    if not isinstance(refreshed, list) or not refreshed or any(name not in ITEMS for name in refreshed):
        raise ValueError(FULL_HINT)
    report.update(run_kind='FAILED_ITEMS_RECHECK', refreshed_items=[name for name in ITEMS if name in refreshed],
        retained_items=[name for name in ITEMS if name not in refreshed])
    return report
