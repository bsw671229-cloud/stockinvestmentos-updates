from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import urlparse
import hashlib

from updater.release_feed import (
    trusted_release_feed_status,
    check_trusted_release_feed,
)
from updater.release_publisher import publisher_status
from updater.repository_deployer import (
    deployment_status,
    verify_public_deployment,
)
from updater.release_manager import (
    status_report,
    read_current_version,
    is_version_newer,
)


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b"",
        ):
            h.update(chunk)
    return h.hexdigest()


def _check(
    layer: str,
    name: str,
    status: str,
    detail: str,
    action: str = "",
) -> dict[str, str]:
    status = _text(status).upper()
    return {
        "layer": _text(layer).upper(),
        "check": _text(name),
        "status": status,
        "detail": _text(detail),
        "action": "" if status == "PASS" else _text(action),
    }


def _expected_public_feed_url(public_base_url: str) -> str:
    base = _text(public_base_url).rstrip("/")
    return f"{base}/release_feed.json" if base else ""


def _valid_sha(value: Any) -> bool:
    text = _text(value).lower()
    return (
        len(text) == 64
        and all(ch in "0123456789abcdef" for ch in text)
    )


def trusted_release_operations_status(
    root: str | Path,
) -> dict[str, Any]:
    """Build a non-mutating, local E2E operations health snapshot.

    This function intentionally does not perform a network request.  The most
    recent public verification evidence is read from deployment state.  Use
    ``trusted_release_operations_live_check`` when a fresh public verification
    is required.
    """

    root = Path(root).resolve()

    feed = trusted_release_feed_status(root)
    publisher = publisher_status(root)
    deployment = deployment_status(root)
    manager = status_report(root)

    feed_cfg = feed.get("config") or {}
    feed_state = feed.get("last_state") or {}
    deploy_state = deployment.get("last_state") or {}

    current_version = read_current_version(root)
    publisher_version = _text(
        publisher.get("latest_published_version")
    )
    if publisher_version == "-":
        publisher_version = ""

    publisher_sha = _text(
        publisher.get("latest_package_sha256")
    ).lower()
    if publisher_sha == "-":
        publisher_sha = ""

    client_feed_url = _text(
        feed_cfg.get("feed_url")
    )
    public_base_url = _text(
        deployment.get("public_base_url")
    )
    expected_feed_url = _expected_public_feed_url(
        public_base_url
    )

    local_feed_path = Path(
        publisher.get("feed_path") or ""
    )
    local_feed_sha = (
        _sha256_path(local_feed_path)
        if local_feed_path.is_file()
        else ""
    )

    verified_public_sha = _text(
        deploy_state.get("public_feed_sha256")
        or deploy_state.get("local_feed_sha256")
    ).lower()

    deployment_target = _text(
        deploy_state.get("target_version")
        or deploy_state.get("feed_target_version")
    )
    client_target = _text(
        feed_state.get("target_version")
        or deploy_state.get("feed_target_version")
    )

    checks: list[dict[str, str]] = []

    managed_clean = bool(
        manager.get("managed_code_clean")
    )
    checks.append(
        _check(
            "TECHNICAL",
            "Managed Code Clean",
            "PASS" if managed_clean else "FAIL",
            (
                f"managed_code_clean={managed_clean} · "
                f"manifest_entries={manager.get('managed_manifest_entries', 0)}"
            ),
            "Release operations require Managed Code = CLEAN.",
        )
    )

    parsed_feed = urlparse(
        client_feed_url
    )
    allowed_hosts = [
        _text(x).lower()
        for x in (
            feed_cfg.get("allowed_hosts")
            or []
        )
        if _text(x)
    ]
    feed_transport_ok = (
        _text(feed.get("status")).upper()
        == "ENABLED"
        and feed_cfg.get("auto_sync")
        is True
        and parsed_feed.scheme.lower()
        == "https"
        and bool(parsed_feed.hostname)
        and parsed_feed.hostname.lower()
        in allowed_hosts
        and feed_cfg.get("allow_file_source")
        is False
    )
    checks.append(
        _check(
            "TECHNICAL",
            "Trusted Feed Transport / Host Pin",
            "PASS" if feed_transport_ok else "FAIL",
            (
                f"status={feed.get('status')} · auto_sync={feed_cfg.get('auto_sync')} · "
                f"scheme={parsed_feed.scheme or 'NONE'} · "
                f"host={parsed_feed.hostname or 'NONE'} · pinned={len(allowed_hosts)}"
            ),
            "Bootstrap a verified HTTPS feed and keep Auto Sync enabled.",
        )
    )

    publisher_ready = (
        _text(publisher.get("status")).upper()
        == "READY"
        and bool(publisher_version)
        and _valid_sha(publisher_sha)
        and local_feed_path.is_file()
        and _valid_sha(local_feed_sha)
    )
    checks.append(
        _check(
            "TECHNICAL",
            "Local Trusted Repository",
            "PASS" if publisher_ready else "FAIL",
            (
                f"status={publisher.get('status')} · latest={publisher_version or 'NONE'} · "
                f"package_sha={'OK' if _valid_sha(publisher_sha) else 'MISSING/BAD'} · "
                f"feed_sha={'OK' if _valid_sha(local_feed_sha) else 'MISSING/BAD'}"
            ),
            "Publish a validated final RELEASE into the local Trusted Repository.",
        )
    )

    deploy_connected = (
        _text(deployment.get("status")).upper()
        == "CONNECTED"
        and deployment.get("git_available")
        is True
        and deployment.get("git_initialized")
        is True
        and deployment.get("credentials_stored_by_app")
        is False
        and bool(_text(deployment.get("remote_url")))
        and bool(_text(deployment.get("branch")))
    )
    checks.append(
        _check(
            "TECHNICAL",
            "Static HTTPS Deployment Connector",
            "PASS" if deploy_connected else "FAIL",
            (
                f"status={deployment.get('status')} · git={deployment.get('git_available')} · "
                f"initialized={deployment.get('git_initialized')} · "
                f"branch={deployment.get('branch') or 'NONE'} · "
                f"credentials_stored={deployment.get('credentials_stored_by_app')}"
            ),
            "Connect the Trusted Repository to the configured Git remote/branch.",
        )
    )

    url_coherent = (
        bool(client_feed_url)
        and bool(expected_feed_url)
        and client_feed_url.rstrip("/")
        == expected_feed_url.rstrip("/")
    )
    checks.append(
        _check(
            "TECHNICAL",
            "Client / Deployment Feed URL Coherence",
            "PASS" if url_coherent else "FAIL",
            (
                f"client={client_feed_url or 'NONE'} · "
                f"deployment={expected_feed_url or 'NONE'}"
            ),
            "Re-bootstrap the client from the verified public deployment.",
        )
    )

    if verified_public_sha:
        feed_hash_status = (
            "PASS"
            if (
                _valid_sha(local_feed_sha)
                and _valid_sha(verified_public_sha)
                and local_feed_sha
                == verified_public_sha
            )
            else "FAIL"
        )
        feed_hash_action = (
            "Run Public Feed Verify. If hashes still differ, do not bootstrap or sync."
        )
    else:
        feed_hash_status = "REVIEW"
        feed_hash_action = (
            "Run a live Public Feed Verify to establish fresh remote SHA evidence."
        )

    checks.append(
        _check(
            "TECHNICAL",
            "Local / Last-Verified Public Feed SHA",
            feed_hash_status,
            (
                f"local={local_feed_sha or 'NONE'} · "
                f"verified_public={verified_public_sha or 'NONE'}"
            ),
            feed_hash_action,
        )
    )

    versions = [
        x
        for x in [
            publisher_version,
            deployment_target,
            client_target,
        ]
        if x
    ]
    version_coherent = (
        bool(versions)
        and len(set(versions)) == 1
    )
    checks.append(
        _check(
            "TECHNICAL",
            "Published Version Lineage",
            "PASS" if version_coherent else "REVIEW",
            (
                f"publisher={publisher_version or 'NONE'} · "
                f"deployment={deployment_target or 'NONE'} · "
                f"client_state={client_target or 'NONE'}"
            ),
            "Re-publish/deploy/verify so Publisher, Deployment and Client state reference one version.",
        )
    )

    safety_ok = (
        deployment.get("credentials_stored_by_app")
        is False
        and _text(feed.get("execution_authorization", "NONE")).upper()
        == "NONE"
        and _text(publisher.get("execution_authorization", "NONE")).upper()
        == "NONE"
        and _text(deployment.get("execution_authorization", "NONE")).upper()
        == "NONE"
        and feed_state.get("auto_approval_performed", False)
        is False
        and feed_state.get("auto_apply_performed", False)
        is False
    )
    checks.append(
        _check(
            "TECHNICAL",
            "No Auto Approval / Apply / Investment Authorization",
            "PASS" if safety_ok else "FAIL",
            (
                f"auto_approval={feed_state.get('auto_approval_performed', False)} · "
                f"auto_apply={feed_state.get('auto_apply_performed', False)} · "
                f"execution_authorization={feed.get('execution_authorization', 'NONE')} · "
                f"credentials_stored={deployment.get('credentials_stored_by_app')}"
            ),
            "Automatic approval/apply and investment execution authorization must remain disabled.",
        )
    )

    dirty = deployment.get("dirty")
    checks.append(
        _check(
            "OPERATING",
            "Git Working Tree",
            (
                "PASS"
                if dirty is False
                else (
                    "REVIEW"
                    if dirty is True
                    else "REVIEW"
                )
            ),
            f"dirty={dirty}",
            "If a new release was published locally, run Deployment Preview and Git Commit + Push.",
        )
    )

    feed_state_status = _text(
        feed_state.get("status")
    ).upper()

    if feed_state_status in {
        "UP_TO_DATE",
        "NOT_DUE",
    }:
        feed_operating = "PASS"
    elif feed_state_status in {
        "UPDATE_AVAILABLE",
        "SYNCED_TO_INBOX",
    }:
        feed_operating = "REVIEW"
    elif feed_state_status in {
        "",
        "DISABLED",
        "AUTO_SYNC_DISABLED",
    }:
        feed_operating = "REVIEW"
    else:
        feed_operating = "FAIL"

    checks.append(
        _check(
            "OPERATING",
            "Trusted Feed Runtime State",
            feed_operating,
            (
                f"status={feed_state_status or 'NONE'} · "
                f"current={current_version} · target={client_target or 'NONE'}"
            ),
            (
                "Review the Trusted Feed state. UPDATE_AVAILABLE/SYNCED_TO_INBOX "
                "requires human Preview/Approve/Apply; BLOCKED requires repair."
            ),
        )
    )

    if publisher_version:
        if current_version == publisher_version:
            version_position = "UP_TO_DATE"
            version_operating = "PASS"
        else:
            try:
                if is_version_newer(
                    publisher_version,
                    current_version,
                ):
                    version_position = "UPDATE_AVAILABLE"
                    version_operating = "REVIEW"
                elif is_version_newer(
                    current_version,
                    publisher_version,
                ):
                    version_position = "CLIENT_AHEAD_OF_PUBLISHED_FEED"
                    version_operating = "REVIEW"
                else:
                    version_position = "REVIEW"
                    version_operating = "REVIEW"
            except Exception:
                version_position = "VERSION_COMPARE_FAILED"
                version_operating = "FAIL"
    else:
        version_position = "NO_PUBLISHED_VERSION"
        version_operating = "REVIEW"

    checks.append(
        _check(
            "OPERATING",
            "Installed vs Published Version",
            version_operating,
            (
                f"position={version_position} · "
                f"installed={current_version} · published={publisher_version or 'NONE'}"
            ),
            (
                "A newer published release should remain human-reviewed before approval/apply. "
                "If the client is ahead, publish/deploy the current final release."
            ),
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL"
        and row["status"] == "FAIL"
    )
    technical_review = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL"
        and row["status"] == "REVIEW"
    )
    technical_pass = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL"
        and row["status"] == "PASS"
    )
    operating_review = sum(
        1
        for row in checks
        if row["layer"] == "OPERATING"
        and row["status"] == "REVIEW"
    )
    operating_fail = sum(
        1
        for row in checks
        if row["layer"] == "OPERATING"
        and row["status"] == "FAIL"
    )
    operating_pass = sum(
        1
        for row in checks
        if row["layer"] == "OPERATING"
        and row["status"] == "PASS"
    )

    technical_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    operating_status = (
        "PASS"
        if (
            operating_fail == 0
            and operating_review == 0
            and technical_review == 0
        )
        else (
            "REVIEW"
            if operating_fail == 0
            else "BLOCKED"
        )
    )

    return {
        "status": (
            "PASS"
            if (
                technical_gate == "PASS"
                and operating_status == "PASS"
            )
            else (
                "REVIEW"
                if technical_gate == "PASS"
                else "BLOCKED"
            )
        ),
        "technical_gate": technical_gate,
        "operating_status": operating_status,
        "technical_pass": technical_pass,
        "technical_review": technical_review,
        "technical_fail": technical_fail,
        "operating_pass": operating_pass,
        "operating_review": operating_review,
        "operating_fail": operating_fail,
        "current_version": current_version,
        "published_version": publisher_version or "-",
        "client_feed_url": client_feed_url,
        "public_feed_url": expected_feed_url,
        "local_feed_sha256": local_feed_sha,
        "last_verified_public_feed_sha256": verified_public_sha,
        "feed_state_status": feed_state_status or "-",
        "git_dirty": dirty,
        "checks": checks,
        "execution_authorization": "NONE",
    }


def trusted_release_operations_live_check(
    root: str | Path,
) -> dict[str, Any]:
    """Refresh public deployment/feed evidence and return the E2E status."""

    root = Path(root).resolve()

    public_verify = verify_public_deployment(
        root
    )

    feed_check = check_trusted_release_feed(
        root
    )

    health = trusted_release_operations_status(
        root
    )

    live_ok = (
        public_verify.get("status")
        == "PUBLIC_FEED_VERIFIED"
        and feed_check.get("status")
        in {
            "UP_TO_DATE",
            "UPDATE_AVAILABLE",
        }
        and health.get("technical_gate")
        == "PASS"
    )

    return {
        "status": (
            "LIVE_CHECK_PASS"
            if live_ok
            else "LIVE_CHECK_REVIEW"
        ),
        "public_verify": public_verify,
        "feed_check": feed_check,
        "health": health,
        "execution_authorization": "NONE",
    }
