from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import json
import os
import re
import time

from updater.release_manager import (
    approve_release,
    apply_release,
    ensure_runtime_dirs,
    find_validation_report,
    preview_release,
    read_current_version,
    scan_candidates,
    sha256_file,
    status_report,
    validation_report_passes,
)
from updater.release_publisher import (
    default_repository_root,
    preview_release_publish,
    publish_release_repository,
    publisher_status,
)
from updater.repository_deployer import (
    deployment_status,
    deploy_repository,
    load_deployment_config,
    preview_deployment,
    verify_public_deployment,
)
from updater.release_feed import (
    check_trusted_release_feed,
    trusted_release_feed_status,
)
from updater.trusted_release_operations import (
    trusted_release_operations_live_check,
    trusted_release_operations_status,
)
from updater.release_recovery import (
    trusted_release_recovery_drill,
    trusted_release_recovery_status,
)


from functools import wraps
from migration.work_ready_paths import resolve_control_root
from updater.release_observability import build_dashboard, record_event, release_history


ORCHESTRATOR_STATE_NAME = "safe_update_orchestrator_state.json"


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        ) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, path)


def _state_path(root: Path) -> Path:
    dirs = ensure_runtime_dirs(root)
    return dirs["logs"] / ORCHESTRATOR_STATE_NAME


def _write_state(root: Path, data: dict[str, Any]) -> None:
    data["audit_history"] = record_event(resolve_control_root(root), data)
    _write_json(_state_path(root), {**data, "execution_authorization": "NONE"})


def _record_attempt(stage: str):
    def decorate(function):
        @wraps(function)
        def run(root, *args, **kwargs):
            try:
                result = function(root, *args, **kwargs)
            except Exception as exc:
                _write_state(Path(root).resolve(), {
                    "created_at": _now(), "stage": stage, "status": "FAILED",
                    "error_type": type(exc).__name__, "execution_authorization": "NONE",
                })
                raise
            result.setdefault("created_at", _now())
            result.setdefault("stage", stage)
            _write_state(Path(root).resolve(), result)
            return result
        return run
    return decorate


def _load_state(root: Path) -> dict[str, Any]:
    path = _state_path(root)
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _approved_candidate(
    root: Path,
    package: Path,
) -> dict[str, Any] | None:
    package = package.resolve()
    for row in scan_candidates(root):
        if (
            row.get("scope") == "approved"
            and Path(row.get("path") or "").resolve() == package
        ):
            return row
    return None


def _inbox_candidate(
    root: Path,
    package: Path,
) -> dict[str, Any] | None:
    package = package.resolve()
    for row in scan_candidates(root):
        if (
            row.get("scope") == "inbox"
            and Path(row.get("path") or "").resolve() == package
        ):
            return row
    return None


def _expected_sha_ok(value: str) -> bool:
    return bool(
        re.fullmatch(
            r"[0-9a-fA-F]{64}",
            str(value or "").strip(),
        )
    )


def safe_update_orchestrator_status(
    root: str | Path,
) -> dict[str, Any]:
    root = Path(root).resolve()

    manager = status_report(root)
    publisher = publisher_status(root)
    deployment = deployment_status(root)
    feed = trusted_release_feed_status(root)
    operations = trusted_release_operations_status(root)
    recovery = trusted_release_recovery_status(root)

    candidates = scan_candidates(root)
    inbox = [
        row for row in candidates
        if row.get("scope") == "inbox"
    ]
    approved = [
        row for row in candidates
        if row.get("scope") == "approved"
        and row.get("eligible")
        and row.get("approval_ok") is True
    ]

    deploy_state = deployment.get("last_state") or {}
    verified_version = str(
        deploy_state.get("target_version")
        or deploy_state.get("feed_target_version")
        or ""
    ).strip()

    last = _load_state(root)

    ready = (
        bool(manager.get("managed_code_clean"))
        and deployment.get("status") == "CONNECTED"
        and bool(
            str(
                deployment.get("public_base_url") or ""
            ).strip()
        )
    )

    return {
        "status": "READY" if ready else "REVIEW",
        "current_version": manager.get("current_version"),
        "managed_code_clean": bool(
            manager.get("managed_code_clean")
        ),
        "inbox_count": len(inbox),
        "approved_eligible_count": len(approved),
        "latest_published_version": publisher.get(
            "latest_published_version",
            "-",
        ),
        "last_verified_public_version": (
            verified_version or "-"
        ),
        "trusted_feed_status": feed.get("status"),
        "e2e_health": operations.get("status"),
        "recovery_status": recovery.get("status"),
        "deployment_status": deployment.get("status"),
        "credentials_stored_by_app": False,
        "auto_approval": False,
        "auto_apply": False,
        "last_orchestrator_state": last,
        "dashboard": build_dashboard(manager, publisher, deployment, feed, operations, recovery, last),
        "history": release_history(resolve_control_root(root)),
        "execution_authorization": "NONE",
    }


def preflight_inbox_release(
    root: str | Path,
    package: str | Path,
    expected_sha256: str,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(package).resolve()
    blockers: list[str] = []
    warnings: list[str] = []

    manager = status_report(root)
    if not manager.get("managed_code_clean"):
        blockers.append(
            "Managed Code is not CLEAN; orchestration is blocked."
        )

    candidate = _inbox_candidate(root, package)
    if candidate is None:
        blockers.append(
            "Selected package is not a Release Manager inbox candidate."
        )

    expected = str(expected_sha256 or "").strip().lower()
    if not _expected_sha_ok(expected):
        blockers.append(
            "Expected SHA-256 must be exactly 64 hex characters."
        )

    actual = sha256_file(package) if package.is_file() else ""
    if expected and actual and expected != actual:
        blockers.append(
            f"Package SHA-256 mismatch. expected={expected}, actual={actual}"
        )

    validation = find_validation_report(package)
    validation_ok = validation_report_passes(validation)
    if not validation_ok:
        blockers.append(
            "A sidecar Validation report containing RESULT: PASS is required."
        )

    preview = preview_release(
        root,
        package,
        for_auto_apply=False,
    )
    blockers.extend(
        x for x in preview.get("blockers", [])
        if x not in blockers
    )
    warnings.extend(
        x for x in preview.get("warnings", [])
        if x not in warnings
    )

    deploy = deployment_status(root)
    if deploy.get("status") != "CONNECTED":
        blockers.append(
            "Static HTTPS deployment connector is not CONNECTED."
        )

    public_base = str(
        deploy.get("public_base_url") or ""
    ).strip()
    if not public_base:
        blockers.append(
            "Deployment Public HTTPS Base URL is not configured."
        )

    publisher_preview: dict[str, Any] = {}
    if package.is_file() and public_base:
        publisher_preview = preview_release_publish(
            root,
            package,
            repository_root=default_repository_root(root),
            public_base_url=public_base,
            channel="stable",
            feed_id="stock-investment-os-stable",
            allow_file_public_url=public_base.lower().startswith(
                "file://"
            ),
        )
        blockers.extend(
            x for x in publisher_preview.get("blockers", [])
            if x not in blockers
        )
        warnings.extend(
            x for x in publisher_preview.get("warnings", [])
            if x not in warnings
        )

    return {
        "status": (
            "READY_TO_APPROVE_PUBLISH_DEPLOY"
            if not blockers
            else "BLOCKED"
        ),
        "eligible": not blockers,
        "blockers": blockers,
        "warnings": warnings,
        "current_version": read_current_version(root),
        "target_version": preview.get("target_version", ""),
        "package": str(package),
        "package_sha256": actual,
        "expected_sha256": expected,
        "sha256_match": bool(
            expected and actual and expected == actual
        ),
        "validation_report": (
            str(validation) if validation else ""
        ),
        "validation_report_pass": validation_ok,
        "preview": preview,
        "publisher_preview": publisher_preview,
        "deployment": deploy,
        "auto_approval": False,
        "auto_apply": False,
        "execution_authorization": "NONE",
    }


@_record_attempt("PUBLISH_DEPLOY_VERIFY")
def publish_deploy_verify(
    root: str | Path,
    approved_package: str | Path,
    *,
    verify_attempts: int = 4,
    retry_seconds: float = 2.0,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(approved_package).resolve()

    candidate = _approved_candidate(root, package)
    blockers: list[str] = []

    if candidate is None:
        blockers.append(
            "Package is not present in Release Manager approved."
        )
    else:
        if candidate.get("approval_ok") is not True:
            blockers.append(
                candidate.get("approval_error")
                or "Approved package approval record is invalid."
            )
        if not candidate.get("eligible"):
            blockers.extend(
                candidate.get("blockers") or [
                    "Approved package is not eligible."
                ]
            )

    deploy = deployment_status(root)
    if deploy.get("status") != "CONNECTED":
        blockers.append(
            "Static HTTPS deployment connector is not CONNECTED."
        )

    public_base = str(
        deploy.get("public_base_url") or ""
    ).strip()
    if not public_base:
        blockers.append(
            "Deployment Public HTTPS Base URL is missing."
        )

    if blockers:
        return {
            "status": "BLOCKED",
            "blockers": blockers,
            "package": str(package),
            "execution_authorization": "NONE",
        }

    publish_preview = preview_release_publish(
        root,
        package,
        repository_root=default_repository_root(root),
        public_base_url=public_base,
        channel="stable",
        feed_id="stock-investment-os-stable",
        allow_file_public_url=public_base.lower().startswith(
            "file://"
        ),
    )

    if not publish_preview.get("eligible"):
        return {
            "status": "BLOCKED",
            "stage": "PUBLISH_PREVIEW",
            "blockers": publish_preview.get("blockers", []),
            "publish_preview": publish_preview,
            "execution_authorization": "NONE",
        }

    published = publish_release_repository(
        root,
        package,
        repository_root=default_repository_root(root),
        public_base_url=public_base,
        channel="stable",
        feed_id="stock-investment-os-stable",
        allow_file_public_url=public_base.lower().startswith(
            "file://"
        ),
    )

    if published.get("status") != "PUBLISHED_LOCAL_REPOSITORY":
        return {
            "status": "BLOCKED",
            "stage": "LOCAL_PUBLISH",
            "blockers": published.get(
                "blockers",
                ["Local publish did not complete."],
            ),
            "published": published,
            "execution_authorization": "NONE",
        }

    deploy_preview = preview_deployment(root)
    if (
        not deploy_preview.get("eligible")
        or deploy_preview.get("target_version")
        != publish_preview.get("target_version")
    ):
        return {
            "status": "BLOCKED",
            "stage": "DEPLOY_PREVIEW",
            "blockers": (
                deploy_preview.get("blockers", [])
                or [
                    "Deployment target version does not match publisher target."
                ]
            ),
            "published": published,
            "deploy_preview": deploy_preview,
            "execution_authorization": "NONE",
        }

    deployed = deploy_repository(root)
    if deployed.get("status") != "DEPLOYED_TO_GIT_REMOTE":
        return {
            "status": "BLOCKED",
            "stage": "GIT_DEPLOY",
            "blockers": deployed.get(
                "blockers",
                ["Git deployment did not complete."],
            ),
            "published": published,
            "deployed": deployed,
            "execution_authorization": "NONE",
        }

    verification: dict[str, Any] = {}
    attempts = max(1, int(verify_attempts))

    for attempt in range(1, attempts + 1):
        verification = verify_public_deployment(root)
        if (
            verification.get("status")
            == "PUBLIC_FEED_VERIFIED"
            and verification.get("target_version")
            == publish_preview.get("target_version")
            and str(
                verification.get("package_sha256") or ""
            ).lower()
            == str(
                publish_preview.get("package_sha256") or ""
            ).lower()
        ):
            break

        if attempt < attempts and retry_seconds > 0:
            time.sleep(float(retry_seconds))

    if verification.get("status") != "PUBLIC_FEED_VERIFIED":
        result = {
            "created_at": _now(),
            "status": "DEPLOYED_VERIFY_PENDING",
            "stage": "PUBLIC_VERIFY",
            "target_version": publish_preview.get("target_version"),
            "package": str(package),
            "package_sha256": publish_preview.get("package_sha256"),
            "published": published,
            "deployed": deployed,
            "public_verify": verification,
            "blockers": verification.get(
                "blockers",
                [
                    "Git deployment completed but public feed verification is pending."
                ],
            ),
            "auto_approval": False,
            "auto_apply": False,
            "execution_authorization": "NONE",
        }
        return result

    feed_check = check_trusted_release_feed(root)

    result = {
        "created_at": _now(),
        "status": "PUBLISHED_DEPLOYED_VERIFIED",
        "target_version": publish_preview.get("target_version"),
        "package": str(package),
        "package_sha256": publish_preview.get("package_sha256"),
        "published": published,
        "deployed": deployed,
        "public_verify": verification,
        "feed_check": feed_check,
        "auto_approval": False,
        "auto_apply": False,
        "execution_authorization": "NONE",
    }
    return result


@_record_attempt("APPROVE_PUBLISH_DEPLOY")
def approve_publish_deploy(
    root: str | Path,
    inbox_package: str | Path,
    expected_sha256: str,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(inbox_package).resolve()

    preflight = preflight_inbox_release(
        root,
        package,
        expected_sha256,
    )

    if not preflight.get("eligible"):
        return {
            "status": "BLOCKED",
            "stage": "PREFLIGHT",
            "blockers": preflight.get("blockers", []),
            "preflight": preflight,
            "execution_authorization": "NONE",
        }

    validation = Path(
        preflight["validation_report"]
    ).resolve()

    approval = approve_release(
        root,
        package,
        validation,
        preflight["expected_sha256"],
    )

    if approval.get("status") != "APPROVED":
        return {
            "status": "BLOCKED",
            "stage": "APPROVAL",
            "blockers": approval.get(
                "blockers",
                ["Release approval did not complete."],
            ),
            "preflight": preflight,
            "approval": approval,
            "execution_authorization": "NONE",
        }

    publish_result = publish_deploy_verify(
        root,
        Path(approval["approved_package"]),
    )

    result = {
        "created_at": _now(),
        "status": (
            "RELEASE_READY_TO_INSTALL"
            if publish_result.get("status")
            == "PUBLISHED_DEPLOYED_VERIFIED"
            else publish_result.get(
                "status",
                "BLOCKED",
            )
        ),
        "target_version": preflight.get("target_version"),
        "approved_package": approval.get("approved_package"),
        "package_sha256": approval.get("package_sha256"),
        "preflight": preflight,
        "approval": approval,
        "publish_deploy": publish_result,
        "auto_approval": False,
        "auto_apply": False,
        "execution_authorization": "NONE",
    }
    return result


def install_readiness(
    root: str | Path,
    approved_package: str | Path,
    *,
    live_verify: bool = False,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(approved_package).resolve()
    blockers: list[str] = []

    candidate = _approved_candidate(root, package)
    if candidate is None:
        blockers.append(
            "Selected package is not in Release Manager approved."
        )
    else:
        if candidate.get("approval_ok") is not True:
            blockers.append(
                candidate.get("approval_error")
                or "Approval record is invalid."
            )
        if not candidate.get("eligible"):
            blockers.extend(
                candidate.get("blockers")
                or ["Approved package is not eligible."]
            )

    preview = preview_release(
        root,
        package,
        for_auto_apply=True,
    )

    blockers.extend(
        x for x in preview.get("blockers", [])
        if x not in blockers
    )

    if live_verify:
        public_verify = verify_public_deployment(root)
    else:
        deploy = deployment_status(root)
        public_verify = deploy.get("last_state") or {}

    expected_target = str(
        preview.get("target_version") or ""
    ).strip()
    expected_sha = str(
        preview.get("package_sha256") or ""
    ).strip().lower()

    verify_status = str(
        public_verify.get("status") or ""
    ).strip()

    if verify_status != "PUBLIC_FEED_VERIFIED":
        blockers.append(
            "Public Feed is not verified for the selected release."
        )

    if (
        str(public_verify.get("target_version") or "").strip()
        != expected_target
    ):
        blockers.append(
            "Verified public target version does not match selected approved release."
        )

    if (
        str(public_verify.get("package_sha256") or "").strip().lower()
        != expected_sha
    ):
        blockers.append(
            "Verified public package SHA-256 does not match selected approved release."
        )

    return {
        "status": (
            "READY_TO_INSTALL"
            if not blockers
            else "BLOCKED"
        ),
        "eligible": not blockers,
        "blockers": blockers,
        "current_version": read_current_version(root),
        "target_version": expected_target,
        "package": str(package),
        "package_sha256": expected_sha,
        "preview": preview,
        "public_verify": public_verify,
        "live_verify": bool(live_verify),
        "auto_apply": False,
        "execution_authorization": "NONE",
    }


@_record_attempt("INSTALL")
def install_verified_release(
    root: str | Path,
    approved_package: str | Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(approved_package).resolve()

    readiness = install_readiness(
        root,
        package,
        live_verify=True,
    )

    if not readiness.get("eligible"):
        return {
            "status": "BLOCKED",
            "stage": "INSTALL_READINESS",
            "blockers": readiness.get("blockers", []),
            "readiness": readiness,
            "execution_authorization": "NONE",
        }

    applied = apply_release(
        root,
        package,
        require_approved_folder=True,
    )

    result = {
        "created_at": _now(),
        "status": (
            "INSTALL_APPLIED_RESTART_REQUIRED"
            if applied.get("status") == "APPLIED"
            else applied.get("status", "BLOCKED")
        ),
        "target_version": readiness.get("target_version"),
        "package": str(package),
        "package_sha256": readiness.get("package_sha256"),
        "readiness": readiness,
        "apply": applied,
        "restart_required": bool(
            applied.get("restart_required")
        ),
        "auto_apply": False,
        "execution_authorization": "NONE",
    }
    return result


@_record_attempt("FINALIZE")
def finalize_after_restart(
    root: str | Path,
) -> dict[str, Any]:
    root = Path(root).resolve()

    operations_live = trusted_release_operations_live_check(root)
    operations = trusted_release_operations_status(root)

    recovery_drill = trusted_release_recovery_drill(root)
    recovery = trusted_release_recovery_status(root)

    operations_ok = (
        operations_live.get("status") == "LIVE_CHECK_PASS"
        and operations.get("status") == "PASS"
        and operations.get("technical_gate") == "PASS"
        and operations.get("operating_status") == "PASS"
        and operations.get("feed_state_status") == "UP_TO_DATE"
    )

    recovery_ok = (
        recovery_drill.get("status") == "RECOVERY_DRILL_PASS"
        and recovery.get("status") == "PASS"
        and recovery.get("technical_gate") == "PASS"
    )

    result = {
        "created_at": _now(),
        "status": (
            "FINAL_PASS"
            if operations_ok and recovery_ok
            else "FINAL_REVIEW"
        ),
        "current_version": read_current_version(root),
        "operations_live": operations_live,
        "operations": operations,
        "recovery_drill": recovery_drill,
        "recovery": recovery,
        "operations_pass": operations_ok,
        "recovery_pass": recovery_ok,
        "auto_approval": False,
        "auto_apply": False,
        "execution_authorization": "NONE",
    }

    return result
