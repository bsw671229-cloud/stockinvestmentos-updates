"""Native UI for explicit, bounded PAPER automation in an existing connection."""
from datetime import datetime
from pathlib import Path
import time
import streamlit as st

from connectors.kis_broker import BrokerError
from engine.broker_execution import Journal
from engine.paper_automation import Automation, paper_only, validate_rule, session_open

LABELS = {'WAITING': '조건 대기', 'CLAIMED': '시도 기록됨', 'PENDING': '접수·체결 확인 중',
    'FILLED': '전량 체결', 'CANCELLED': '취소 확인', 'UNKNOWN': '접수 여부 확인 필요',
    'REJECTED': '거절', 'FAILED_PRECHECK': '사전 점검 중단', 'EXPIRED': '만료'}


def stop_session():
    active = st.session_state.pop('_paper_auto', None)
    if active:
        # Fail closed in the persistent journal before dropping the session capability.
        Automation(Journal(Path(active['path']))).stop(active['permit'].account)
    st.session_state.pop('_paper_auto_draft', None)
    st.session_state.pop('_paper_auto_context', None)


def _rule_rows(rules):
    return [{'시장': r['order']['market'], '거래소': r['order']['exchange'], '종목': r['order']['symbol'],
             '방향': '매수' if r['order']['side'] == 'BUY' else '매도',
             '조건': f"{r['trigger']} {'이하' if r['comparison']=='LE' else '이상'}",
             '수량': r['order']['quantity'], '지정가': r['order']['limit_price'], '통화': r['order']['currency']}
            for r in rules]


@st.fragment(run_every='10s')
def _monitor(client, journal):
    active = st.session_state.get('_paper_auto')
    if not active:
        return
    automation, permit = Automation(journal), active['permit']
    if st.button('자동매매 중지 · 신규 주문 차단', key='paper_auto_stop', type='primary'):
        automation.stop(permit.account)
    try:
        before = automation.snapshot(permit)
        if before['state'] == 'ARMED':
            automation.tick(client, permit)
        state = automation.snapshot(permit)
        if state['state'] == 'ARMED':
            st.success('모의 자동매매 실행 중 · 10초마다 조건과 주문 상태 확인')
        elif state['state'] == 'COMPLETE':
            st.success('등록한 조건의 처리 완료')
        else:
            st.warning(state['note'])
        st.caption('종료 예정: ' + datetime.fromtimestamp(state['expires']).strftime('%H:%M:%S') + ' (이 PC 시간)')
        for col, market, label in zip(st.columns(2), ('KR', 'US'), ('국내', '미국')):
            col.metric(label+' 기본 거래시간', '시간 내' if session_open(market,time.time()) else '시간 외 · 대기')
        rows = _rule_rows([r['rule'] for r in state['rules']])
        for row, item in zip(rows, state['rules']):
            row['상태'] = LABELS.get(item['state'], item['state'])
            row['최근 조회 가격'] = item['price'] or '—'
        st.dataframe(rows, hide_index=True, width='stretch')
        if state['totals']:
            st.write('오늘의 자동 주문 시도 누계 · 한국시간 기준')
            st.dataframe([{'통화': c, '비용 포함 금액': v['cost'], '가정 손실': v['loss'], '시도 수': v['count']} for c, v in state['totals'].items()], hide_index=True, width='stretch')
        st.caption('접수된 주문은 중지·화면 종료로 취소되지 않습니다. 취소와 결과 확인은 주문·체결 관리에서 진행하세요. 이미 전송 중인 요청은 완료될 수 있습니다.')
        if state['state'] != 'ARMED' and st.button('실행 기록 확인 후 새 조건 작성', key='paper_auto_new'):
            st.session_state.pop('_paper_auto', None)
            st.session_state.pop('_paper_auto_draft', None)
            st.rerun()
    except Exception:
        st.error('실행 상태를 확인하지 못했습니다. 새 주문을 시작하지 말고 주문·체결 관리에서 기록을 확인하세요.')


def render(client, journal):
    st.subheader('국내·미국 모의 자동매매')
    st.caption('가격 조건 → 모의 지정가 주문 → 체결 확인 | 조건별 1회 실행')
    if client.credentials.mode != 'PAPER':
        st.warning('모의투자(PAPER)에 연결한 뒤 이용하세요. 실전 자동 주문은 사용할 수 없습니다.')
        return
    try:
        paper_only(client)
    except BrokerError as exc:
        st.error(str(exc)); return
    context = (client.credentials.identity, id(client))
    if st.session_state.get('_paper_auto_context') != context:
        stop_session()
        st.session_state['_paper_auto_context'] = context
    st.info('직접 등록한 조건으로 모의 주문을 전송합니다. 실제 증권사 모의계좌 연동 검증은 아직 필요합니다.')
    st.caption('이 화면이 연결된 동안만 확인합니다. 재실행·재연결 시 자동 재개하지 않습니다. 60초 이상 점검이 끊기면 중단하며, 장시간 무인 운영은 지원하지 않습니다.')
    if st.session_state.get('_paper_auto'):
        _monitor(client, journal)
        return
    if journal.halted(client.credentials.identity):
        st.warning('신규 주문이 차단되어 있습니다. 이전 주문 기록을 확인한 뒤 해제하세요.')
        if st.button('이전 주문 확인 후 신규 주문 차단 해제', key='paper_auto_unhalt'):
            journal.set_halted(client.credentials.identity, False)
            st.rerun()
    draft = st.session_state.setdefault('_paper_auto_draft', [])
    st.markdown('**1. 자동으로 실행할 조건 등록**')
    market = st.selectbox('자동매매 시장', ['KR', 'US'], format_func=lambda v: '국내 주식·ETF' if v == 'KR' else '미국 주식·ETF', key='paper_market')
    currency = 'KRW' if market == 'KR' else 'USD'
    with st.form('paper_rule_form', enter_to_submit=False):
        left, right = st.columns(2)
        exchange = left.selectbox('거래소', ['KRX'] if market == 'KR' else ['NASD', 'NYSE', 'AMEX'], key='paper_exchange_'+market)
        symbol = right.text_input('종목코드 / 티커', key='paper_symbol_'+market)
        side = left.selectbox('매매 방향', ['BUY', 'SELL'], format_func=lambda v: '매수' if v == 'BUY' else '매도', index=None, key='paper_side')
        comparison = right.selectbox('가격 조건', ['LE', 'GE'], format_func=lambda v: '조건 가격 이하' if v == 'LE' else '조건 가격 이상', key='paper_comparison')
        trigger = left.text_input('조건 가격 ('+currency+')', value='0', key='paper_trigger_'+market)
        price = right.text_input('주문 지정가 ('+currency+')', value='0', key='paper_price_'+market)
        quantity = left.number_input('주문 수량 (주)', min_value=1, max_value=1000000, step=1, key='paper_quantity')
        cap = right.text_input('건별 비용 포함 금액 상한 ('+currency+')', value='0', key='paper_cap_'+market)
        fee = left.text_input('비용 여유율 (%)', value='0.5', key='paper_fee')
        gap = right.text_input('조회 가격·지정가 차이 한도 (%)', value='3', key='paper_gap')
        downside = left.text_input('매수 하락 가정 (%)', value='0', key='paper_downside')
        loss = right.text_input('건별 매수 가정 손실 예산 ('+currency+')', value='0', key='paper_loss_'+market)
        st.caption('매도도 보유 수량 안에서 지정가로 전송합니다. 가격 조건은 체결이나 손절을 보장하지 않습니다. 매도 조건은 하락 가정·가정 손실 예산을 사용하지 않습니다.')
        if st.form_submit_button('조건 목록에 추가', disabled=len(draft) >= 10):
            try:
                rule = validate_rule(dict(order=dict(market=market, exchange=exchange, symbol=symbol.strip().upper(), side=side, quantity=quantity, limit_price=price),
                    comparison=comparison, trigger=trigger, limits=dict(max_notional=cap, fee_buffer_pct=fee, max_quote_gap_pct=gap, downside_pct=downside, max_scenario_loss=loss, risk_attested=True)))
                if rule in draft:
                    raise BrokerError('같은 조건이 이미 등록되어 있습니다.')
                draft.append(rule)
            except (BrokerError, ValueError, KeyError):
                st.error('방향·종목·가격·수량과 건별 예산을 확인하세요. 금액은 쉼표 없이 입력하세요.')
    if draft:
        st.dataframe(_rule_rows(draft), hide_index=True, width='stretch')
        if st.button('등록 조건 모두 지우기', key='paper_clear'):
            st.session_state['_paper_auto_draft'] = []; st.rerun()
    st.markdown('**2. 하루 한도와 실행 시간 확인**')
    st.caption('한국시간 하루 누계이며 이전 실행의 시도도 합산합니다. 실패·거절·불명확한 시도도 차감합니다. 원화와 달러는 따로 계산하며 자동 환전하지 않습니다.')
    with st.form('paper_start_form', enter_to_submit=False):
        budgets = {}
        for c in sorted({r['order']['currency'] for r in draft}):
            st.write(c + ' 하루 자동 주문 시도 한도')
            a, b, d = st.columns(3)
            budgets[c] = dict(cost=a.text_input('비용 포함 금액 ('+c+')', value='0', key='paper_daily_cost_'+c),
                loss=b.text_input('매수 가정 손실 ('+c+')', value='0', key='paper_daily_loss_'+c),
                count=d.number_input('최대 시도 수 ('+c+')', min_value=1, max_value=10, value=1, key='paper_daily_count_'+c))
        minutes = st.number_input('이번 실행 시간 (분)', min_value=1, max_value=60, value=10, key='paper_minutes')
        st.caption('가정 손실 = 매수 금액 × 하락 가정 + 비용 여유. 실제 손익이나 최대손실 보장이 아닙니다. 한국시간 날짜가 바뀌면 중단합니다.')
        attested = st.checkbox('등록 조건과 예산을 확인했고 모의 주문의 자동 전송을 시작합니다', key='paper_attested')
        if st.form_submit_button('확인한 조건으로 모의 자동매매 시작', type='primary', disabled=not draft or journal.halted(client.credentials.identity)):
            try:
                permit = Automation(journal).arm(client, draft, budgets, minutes, confirmed=attested)
                st.session_state['_paper_auto'] = dict(permit=permit, path=str(journal.path))
                st.session_state.pop('paper_attested', None)
                st.rerun()
            except (BrokerError, ValueError, KeyError) as exc:
                st.error(str(exc) if isinstance(exc, BrokerError) else '하루 한도를 확인하세요.')
    with st.expander('작동 범위와 확인할 점'):
        st.write('국내 KRX, 미국 NASDAQ·NYSE·AMEX의 정수 수량·현금 지정가 주문입니다. 기본 평일 정규 시간과 미국 서머타임을 적용합니다. 휴장·조기 종료·임시 시간 변경·거래정지는 자동 검증하지 않습니다.')
        st.write('시세 응답을 새로 받아 조회 시점을 확인합니다. 거래소 원천 시세의 지연 여부는 보장하지 않습니다. 조건이 전송 점검 중 바뀌거나 잔고·예산이 부족하면 중단합니다.')
        st.write('조건별 시도는 한 번입니다. 재전송·재시작 후 자동 재개·시장가·자동 환전은 없습니다. 미완료 주문은 한 건씩 확인하며 불명확한 결과는 주문·체결 관리에서 확인하세요.')
