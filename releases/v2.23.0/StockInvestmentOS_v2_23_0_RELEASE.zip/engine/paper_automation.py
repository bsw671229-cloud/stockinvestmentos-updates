"""Bounded, session-owned PAPER automation. No credentials, workers or auto-resume."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo
import hashlib
import json
import secrets
import time

from connectors.kis_broker import BrokerError, number, whole, validate_order
from engine.broker_execution import (ACTIVE, canonical, validate_limits, prepare_order,
                                     submit_order, confirmation_text, reconcile_order)

PROCESS = secrets.token_hex(32)
PAPER_URL = 'https://openapivts.koreainvestment.com:29443'
MAX_GAP = 60


@dataclass(frozen=True)
class Permit:
    run_id: str
    account: str
    token: str = field(repr=False)


def _owner(token):
    return hashlib.sha256(token.encode()).hexdigest()


def _day():
    return datetime.fromtimestamp(time.time(), timezone(timedelta(hours=9))).strftime('%Y-%m-%d')


def paper_only(client, account=None):
    if client.credentials.mode != 'PAPER' or client.base_url != PAPER_URL:
        raise BrokerError('자동매매는 모의투자 연결에서만 가능합니다.')
    if account is not None and client.credentials.identity != account:
        raise BrokerError('연결 계좌가 바뀌었습니다. 자동매매를 다시 설정하세요.')


def session_open(market, stamp):
    # Basic regular hours only: no claim of holiday/halts/early-close verification.
    zone = timezone(timedelta(hours=9)) if market == 'KR' else ZoneInfo('America/New_York')
    local = datetime.fromtimestamp(stamp, zone)
    minute = local.hour * 60 + local.minute
    low, high = (540, 930) if market == 'KR' else (570, 960)
    return local.weekday() < 5 and low <= minute < high


def validate_rule(value):
    order = validate_order(value['order'])
    if value.get('comparison') not in ('LE', 'GE'):
        raise BrokerError('가격 조건을 확인하세요.')
    trigger = number(value['trigger'], positive=True)
    if trigger > Decimal('1000000000'):
        raise BrokerError('조건 가격을 확인하세요.')
    limits = value['limits']
    validate_limits(order, limits)
    # Keep only engine-used, nonsecret fields; do not persist caller extras.
    clean_limits = {key: limits[key] for key in ('max_notional', 'fee_buffer_pct',
        'max_quote_gap_pct', 'downside_pct', 'max_scenario_loss', 'risk_attested')}
    return dict(order=order, comparison=value['comparison'], trigger=str(trigger), limits=clean_limits)


def matches(rule, price):
    return price <= number(rule['trigger']) if rule['comparison'] == 'LE' else price >= number(rule['trigger'])


def checked_quote(client, rule):
    value = client.quote(rule['order'])
    fetched = datetime.fromisoformat(str(value.get('fetched_at', '')).replace('Z', '+00:00'))
    if fetched.tzinfo is None or not -2 <= time.time() - fetched.timestamp() <= 15:
        raise BrokerError('시세 조회 시점을 확인할 수 없습니다.')
    if value.get('currency') != rule['order']['currency']:
        raise BrokerError('시세 통화가 주문 통화와 다릅니다.')
    price = number(value['price'], positive=True)
    return dict(price=str(price), currency=value['currency'], fetched_at=fetched.isoformat())


class Automation:
    def __init__(self, journal):
        self.journal = journal
        with journal.transaction() as db:
            db.execute('CREATE TABLE IF NOT EXISTS paper_runs (id TEXT PRIMARY KEY, account TEXT NOT NULL, owner TEXT NOT NULL, process TEXT NOT NULL, expires REAL NOT NULL, heartbeat REAL NOT NULL, busy INTEGER NOT NULL, state TEXT NOT NULL, config TEXT NOT NULL, note TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS paper_rules (run_id TEXT NOT NULL, idx INTEGER NOT NULL, payload TEXT NOT NULL, state TEXT NOT NULL, order_id TEXT NOT NULL, price TEXT NOT NULL, PRIMARY KEY(run_id,idx))')
            db.execute('CREATE TABLE IF NOT EXISTS paper_attempts (run_id TEXT NOT NULL, idx INTEGER NOT NULL, account TEXT NOT NULL, day TEXT NOT NULL, currency TEXT NOT NULL, cost TEXT NOT NULL, loss TEXT NOT NULL, state TEXT NOT NULL, order_id TEXT NOT NULL, PRIMARY KEY(run_id,idx))')

    @staticmethod
    def _valid(row, permit):
        return (row is not None and row['account'] == permit.account
                and secrets.compare_digest(row['owner'], _owner(permit.token))
                and row['process'] == PROCESS)

    def _run(self, db, permit):
        row = db.execute('SELECT * FROM paper_runs WHERE id=?', (permit.run_id,)).fetchone()
        if not self._valid(row, permit):
            raise BrokerError('현재 세션의 시작 확인이 없습니다. 자동 재개하지 않습니다.')
        return row

    def arm(self, client, rules, budgets, minutes, *, confirmed=False):
        paper_only(client)
        if confirmed is not True or not 1 <= whole(minutes) <= 60:
            raise BrokerError('조건을 확인하고 1~60분의 실행 시간을 선택하세요.')
        if not 1 <= len(rules) <= 10:
            raise BrokerError('조건을 1~10개 등록하세요.')
        rules = [validate_rule(rule) for rule in rules]
        if len({canonical(r) for r in rules}) != len(rules):
            raise BrokerError('같은 조건이 중복 등록되어 있습니다.')
        config = {'budgets': {}, 'day': _day()}
        for currency in {r['order']['currency'] for r in rules}:
            budget = budgets[currency]
            config['budgets'][currency] = dict(cost=str(number(budget['cost'], positive=True)),
                loss=str(number(budget['loss'])), count=whole(budget['count']))
            if not 1 <= config['budgets'][currency]['count'] <= 10:
                raise BrokerError('하루 주문 시도 수는 통화별 1~10회입니다.')
        account = client.credentials.identity
        permit = Permit(secrets.token_hex(16), account, secrets.token_hex(32))
        now = time.time()
        with self.journal.transaction() as db:
            self._no_active(db, account)
            # Manual reconciliation may have resolved a stopped run's known order.
            for old in db.execute("SELECT run_id,idx,order_id FROM paper_attempts WHERE account=? AND state IN ('CLAIMED','PENDING','UNKNOWN')", (account,)).fetchall():
                resolved = db.execute("SELECT status FROM orders WHERE id=? AND account=? AND status IN ('FILLED','CANCELLED','REJECTED','EXPIRED','FAILED_PRECHECK')", (old['order_id'], account)).fetchone()
                if resolved:
                    for table in ('paper_rules', 'paper_attempts'):
                        db.execute(f'UPDATE {table} SET state=? WHERE run_id=? AND idx=?', (resolved['status'], old['run_id'], old['idx']))
            # Unfinished reservations survive process loss and never become eligible again.
            if db.execute("SELECT 1 FROM paper_attempts WHERE account=? AND state IN ('CLAIMED','PENDING','UNKNOWN')", (account,)).fetchone():
                raise BrokerError('이전 자동 주문의 확인이 필요합니다. 주문·체결 관리에서 확인하세요.')
            if db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (account,)).fetchone():
                raise BrokerError('신규 주문이 중지되어 있습니다.')
            if db.execute("SELECT 1 FROM paper_runs WHERE account=? AND state='ARMED' AND process=? AND heartbeat>? AND expires>?", (account, PROCESS, now-MAX_GAP, now)).fetchone():
                raise BrokerError('다른 화면에서 자동매매가 실행 중입니다. 먼저 중지하세요.')
            db.execute("UPDATE paper_runs SET state='STOPPED',note='이전 실행 만료' WHERE account=? AND state='ARMED'", (account,))
            db.execute('INSERT INTO paper_runs VALUES(?,?,?,?,?,?,0,?,?,?)',
                (permit.run_id, account, _owner(permit.token), PROCESS, now+60*minutes, now, 'ARMED', canonical(config), '가격 조건 대기'))
            db.executemany("INSERT INTO paper_rules VALUES(?,?,?,'WAITING','','')",
                [(permit.run_id, i, canonical(r)) for i, r in enumerate(rules)])
            self.journal._event(db, None, 'PAPER_AUTO_ARMED', permit.run_id)
        return permit

    def _no_active(self, db, account):
        expired = db.execute("SELECT id FROM orders WHERE account=? AND status='PREPARED' AND expires<=?", (account, time.time())).fetchall()
        for row in expired:
            db.execute("UPDATE orders SET status='EXPIRED' WHERE id=?", (row['id'],))
            self.journal._event(db, row['id'], 'EXPIRED')
        states = (*ACTIVE, 'PREPARED')
        if db.execute('SELECT 1 FROM orders WHERE account=? AND status IN ('+','.join('?' for _ in states)+')', (account, *states)).fetchone():
            raise BrokerError('미완료 주문이 있습니다. 주문·체결 관리에서 먼저 확인하세요.')

    def stop(self, account, note='사용자가 중지했습니다.', *, halt=True):
        with self.journal.transaction() as db:
            db.execute("UPDATE paper_runs SET state='STOPPED',note=? WHERE account=? AND state='ARMED'", (note, account))
            if halt:
                db.execute('INSERT INTO controls VALUES(?,1) ON CONFLICT(account) DO UPDATE SET halted=1', (account,))
            self.journal._event(db, None, 'PAPER_AUTO_STOPPED', account)

    def guard(self, client, permit):
        paper_only(client, permit.account)
        with self.journal.transaction() as db:
            row = self._run(db, permit)
            now = time.time()
            if (row['state'] != 'ARMED' or now >= row['expires']
                    or not 0 <= now-row['heartbeat'] <= MAX_GAP
                    or json.loads(row['config'])['day'] != _day()
                    or db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (permit.account,)).fetchone()):
                raise BrokerError('실행 시간이 끝났거나 자동매매가 중지되었습니다.')

    def snapshot(self, permit):
        with self.journal.transaction() as db:
            run = dict(self._run(db, permit))
            rules = [dict(r) for r in db.execute('SELECT * FROM paper_rules WHERE run_id=? ORDER BY idx', (permit.run_id,))]
            day = datetime.fromtimestamp(time.time(), timezone(timedelta(hours=9))).strftime('%Y-%m-%d')
            totals = {}
            for r in db.execute('SELECT * FROM paper_attempts WHERE account=? AND day=?', (permit.account, day)):
                total = totals.setdefault(r['currency'], {'cost': Decimal(0), 'loss': Decimal(0), 'count': 0})
                total['cost'] += number(r['cost']); total['loss'] += number(r['loss']); total['count'] += 1
        return dict(state=run['state'], note=run['note'], expires=run['expires'], busy=bool(run['busy']),
            rules=[dict(idx=r['idx'], rule=json.loads(r['payload']), state=r['state'], order_id=r['order_id'], price=r['price']) for r in rules],
            totals={c: {k: str(v) if isinstance(v, Decimal) else v for k, v in t.items()} for c, t in totals.items()})

    def _reserve(self, permit, idx, rule):
        cost = validate_limits(rule['order'], rule['limits'])
        currency = rule['order']['currency']
        day = datetime.fromtimestamp(time.time(), timezone(timedelta(hours=9))).strftime('%Y-%m-%d')
        with self.journal.transaction() as db:
            run = self._run(db, permit)
            if run['state'] != 'ARMED':
                raise BrokerError('자동매매가 중지되었습니다.')
            self._no_active(db, permit.account)
            cap = json.loads(run['config'])['budgets'][currency]
            past = list(db.execute('SELECT cost,loss FROM paper_attempts WHERE account=? AND day=? AND currency=?', (permit.account, day, currency)))
            if (len(past) >= cap['count']
                    or sum((number(p['cost']) for p in past), Decimal(0))+number(cost['estimated_cost']) > number(cap['cost'])
                    or sum((number(p['loss']) for p in past), Decimal(0))+number(cost['scenario_loss']) > number(cap['loss'])):
                raise BrokerError('오늘의 통화별 주문 시도 예산을 초과했습니다.')
            updated = db.execute("UPDATE paper_rules SET state='CLAIMED' WHERE run_id=? AND idx=? AND state='WAITING'", (permit.run_id, idx))
            if updated.rowcount != 1:
                raise BrokerError('이미 처리된 조건입니다.')
            db.execute("INSERT INTO paper_attempts VALUES(?,?,?,?,?,?,?,'CLAIMED','')", (permit.run_id, idx, permit.account, day, currency, cost['estimated_cost'], cost['scenario_loss']))

    def _record(self, permit, idx, state, order_id=''):
        with self.journal.transaction() as db:
            db.execute('UPDATE paper_rules SET state=?,order_id=? WHERE run_id=? AND idx=?', (state, order_id, permit.run_id, idx))
            db.execute('UPDATE paper_attempts SET state=?,order_id=? WHERE run_id=? AND idx=?', (state, order_id, permit.run_id, idx))

    def _reconcile_record(self, permit, idx, record):
        status = record['status']
        if status in ('SENDING', 'UNKNOWN', 'CANCEL_UNKNOWN', 'REJECTED', 'FAILED_PRECHECK', 'EXPIRED'):
            self._record(permit, idx, 'UNKNOWN' if status in ('SENDING', 'UNKNOWN', 'CANCEL_UNKNOWN') else status, record['id'])
            self.stop(permit.account, '주문 결과를 확인해야 합니다. 주문·체결 관리에서 확인하세요.')
        else:
            self._record(permit, idx, status if status in ('FILLED', 'CANCELLED') else 'PENDING', record['id'])

    def tick(self, client, permit):
        """One serialized cycle. Never retry a send or take over a crashed cycle."""
        acquired = False
        phase = '실행 시간·연결·신규 주문 차단 확인'
        try:
            self.guard(client, permit)
            with self.journal.transaction() as db:
                row = self._run(db, permit)
                if row['busy']:
                    return None  # another cycle owns the durable lease; never take it over
                db.execute('UPDATE paper_runs SET busy=1,heartbeat=? WHERE id=?', (time.time(), permit.run_id))
                acquired = True
            state = self.snapshot(permit)
            guarded = _PaperClient(client, self, permit)
            for item in state['rules']:
                if item['state'] == 'PENDING':
                    phase = '접수·체결 결과 확인'
                    record = reconcile_order(guarded, self.journal, item['order_id'])
                    self._reconcile_record(permit, item['idx'], record)
                    return self.snapshot(permit)
                if item['state'] in ('CLAIMED', 'UNKNOWN'):
                    raise BrokerError('이전 시도의 결과를 확인해야 합니다.')
            for item in state['rules']:
                if item['state'] != 'WAITING':
                    continue
                rule = item['rule']
                self.guard(client, permit)
                if not session_open(rule['order']['market'], time.time()):
                    continue
                quote = checked_quote(guarded, rule)
                with self.journal.transaction() as db:
                    db.execute('UPDATE paper_rules SET price=? WHERE run_id=? AND idx=?', (quote['price'], permit.run_id, item['idx']))
                if not matches(rule, number(quote['price'])):
                    continue
                phase = '하루 예산·이전 주문 상태 확인'
                self._reserve(permit, item['idx'], rule)
                record = None
                try:
                    phase = '가격 조건·잔고 점검 및 주문 결과 확인'
                    guarded.rule = rule
                    record = prepare_order(guarded, self.journal, rule['order'], rule['limits'])
                    self._record(permit, item['idx'], 'CLAIMED', record['id'])
                    record = submit_order(guarded, self.journal, record['id'], confirmation_text(record), allow_live=False)
                    self._reconcile_record(permit, item['idx'], record)
                except Exception:
                    if record is not None:
                        record = self.journal.get(record['id'], permit.account)
                        if record['status'] == 'PREPARED':
                            self.journal.update(record['id'], permit.account, 'FAILED_PRECHECK', {})
                        state_name = 'UNKNOWN' if record['status'] in ACTIVE else 'FAILED_PRECHECK'
                    else:
                        state_name = 'FAILED_PRECHECK'
                    self._record(permit, item['idx'], state_name, record['id'] if record else '')
                    raise
                break  # at most one new order in a cycle
            state = self.snapshot(permit)
            if all(r['state'] in ('FILLED', 'CANCELLED') for r in state['rules']):
                with self.journal.transaction() as db:
                    db.execute("UPDATE paper_runs SET state='COMPLETE',note='등록 조건 처리 완료' WHERE id=? AND state='ARMED'", (permit.run_id,))
            return self.snapshot(permit)
        except Exception:
            # Do not log arbitrary exception strings, API bodies or credentials.
            # An invalid capability must not stop another session/account.
            with self.journal.transaction() as db:
                row = db.execute('SELECT * FROM paper_runs WHERE id=?', (permit.run_id,)).fetchone()
                owned = self._valid(row, permit)
            if owned:
                self.stop(permit.account, '자동매매 중지 · '+phase+'이 필요합니다.')
                return self.snapshot(permit)
            raise
        finally:
            if acquired:
                with self.journal.transaction() as db:
                    db.execute('UPDATE paper_runs SET busy=0 WHERE id=?', (permit.run_id,))


class _PaperClient:
    """Recheck mode/account/session before every operation, including the final POST."""
    def __init__(self, client, automation, permit):
        self.client, self.automation, self.permit = client, automation, permit
        self.rule = None
        self.last_quote = None

    @property
    def credentials(self):
        self.automation.guard(self.client, self.permit)
        return self.client.credentials

    def quote(self, order):
        self.automation.guard(self.client, self.permit)
        if not session_open(order['market'], time.time()):
            raise BrokerError('기본 정규 거래시간 밖입니다.')
        rule = self.rule or dict(order=order)
        value = checked_quote(self.client, rule)
        self.automation.guard(self.client, self.permit)
        if self.rule and not matches(self.rule, number(value['price'])):
            raise BrokerError('가격 조건이 달라졌습니다.')
        self.last_quote = value
        return value

    def buying_power(self, order):
        self.automation.guard(self.client, self.permit)
        return self.client.buying_power(order)

    def sellable(self, order):
        self.automation.guard(self.client, self.permit)
        return self.client.sellable(order)

    def send_limit(self, order):
        self.automation.guard(self.client, self.permit)
        if self.last_quote is None or not -2 <= time.time() - datetime.fromisoformat(self.last_quote['fetched_at']).timestamp() <= 15:
            raise BrokerError('전송 전에 시세 조회 시점이 만료되었습니다.')
        if not session_open(order['market'], time.time()):
            raise BrokerError('기본 정규 거래시간 밖입니다.')
        return self.client.send_limit(order)

    def order_history(self, *args):
        self.automation.guard(self.client, self.permit)
        return self.client.order_history(*args)
