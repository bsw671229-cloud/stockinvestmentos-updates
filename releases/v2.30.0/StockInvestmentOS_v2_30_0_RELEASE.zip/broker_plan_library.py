"""Plan editor UI. Loading never starts an automation or changes its journal."""
import streamlit as st
from engine.paper_plans import PlanStore, editor_values


def clear_editor_confirmation():
    st.session_state.pop('_paper_rehearsal', None)
    st.session_state.pop('paper_attested', None)
    st.session_state.pop('live_confirmation', None)


def clear_plan_context():
    for key in list(st.session_state):
        if key.startswith(('paper_daily_', 'paper_plan_', 'paper_remove_rule_')) or key in ('paper_minutes','_paper_loaded_plan','_paper_plan_notice'):
            st.session_state.pop(key, None)


def library(client, journal):
    notice = st.session_state.pop('_paper_plan_notice', None)
    if notice:
        st.success(notice)
    with st.expander('저장한 자동매매 계획'):
        st.caption('현재 모의계좌의 조건·하루 한도·실행 시간을 이 PC에 저장합니다. 저장·불러오기는 주문을 시작하지 않습니다.')
        store = PlanStore(journal)
        try:
            plans = store.list(client)
        except Exception:
            st.error('저장 계획 목록을 읽지 못했습니다. 기존 계획을 덮어쓰지 않습니다.')
            return
        if not plans:
            st.caption('아직 저장한 계획이 없습니다. 아래 조건과 하루 한도를 입력한 뒤 계획을 저장하세요.')
            return
        by_id = {r['id']:r for r in plans}
        selected = st.selectbox('불러올 계획', list(by_id), index=None,
            format_func=lambda key: by_id[key]['name'], key='paper_plan_select')
        if selected not in by_id:
            return
        row = by_id[selected]
        st.caption('저장 시각(UTC): '+row['created'])
        st.caption('불러오면 작성 중인 조건을 교체합니다. 저장한 시세·잔고는 없으며 시작 전 다시 조회합니다.')
        a, b = st.columns(2)
        if a.button('불러오기 · 작성 중 조건 교체', key='paper_plan_load'):
            try:
                payload = store.load(client, selected, row['revision'])
                rules, budgets, minutes = editor_values(payload)
                clear_editor_confirmation()
                for key in list(st.session_state):
                    if key.startswith('paper_daily_'):
                        st.session_state.pop(key, None)
                st.session_state['_paper_auto_draft'] = rules
                for currency, cap in budgets.items():
                    for field, value in cap.items():
                        st.session_state['paper_daily_'+field+'_'+currency] = value
                st.session_state['paper_minutes'] = minutes
                st.session_state['_paper_loaded_plan'] = row['name']
                st.session_state['_paper_plan_notice'] = '계획을 불러왔습니다. 조건·예산을 확인하고 전체 조건 점검을 다시 실행하세요.'
                st.rerun()
            except Exception:
                st.error('계획을 불러오지 못했습니다. 목록과 저장 상태를 확인하세요.')
        if b.button('목록에서 보관', key='paper_plan_archive'):
            try:
                store.archive(client, selected, row['revision'])
                st.session_state['_paper_plan_notice'] = '계획을 목록에서 보관했습니다. 작성 중 조건과 실행 기록은 유지됩니다.'
                st.rerun()
            except Exception:
                st.error('계획을 보관하지 못했습니다. 목록을 다시 확인하세요.')
        st.caption('보관하면 목록에서 숨기며 원본 기록은 이 PC에 유지합니다.')
    if st.session_state.get('_paper_loaded_plan'):
        st.text('불러온 계획: '+st.session_state['_paper_loaded_plan'])
