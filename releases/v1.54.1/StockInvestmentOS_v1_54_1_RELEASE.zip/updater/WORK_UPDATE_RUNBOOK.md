# Stock Investment OS — Work-ready Self Update Runbook

This updater is deliberately transactional. It does not trust a ZIP merely
because it exists in Downloads.

## Trust boundary

Automatic apply requires all of the following:

1. final package name: `StockInvestmentOS_vX_Y_Z_RELEASE.zip`
2. internal `manifest_sha256.json` passes
3. Python sources compile
4. package contains no `.env`, `data/`, bytecode, symlinks, or unsafe paths
5. target VERSION is newer than installed VERSION
6. current managed code has no local drift
7. a validation report contains `RESULT: PASS`
8. the operator/Work supplies the expected release ZIP SHA-256 during approval
9. the approved ZIP + validation report + approval record remain hash-consistent

## Work workflow

From the project root:

```bat
python updater\update_manager.py status
python updater\update_manager.py scan
```

Put a downloaded final RELEASE ZIP and its validation TXT in `releases\inbox`.

Preview:

```bat
python updater\update_manager.py preview --package releases\inbox\StockInvestmentOS_v1_51_0_RELEASE.zip --auto
```

Approve using the SHA-256 published with the release:

```bat
python updater\update_manager.py approve ^
  --package releases\inbox\StockInvestmentOS_v1_51_0_RELEASE.zip ^
  --validation-report releases\inbox\V151_RELEASE_VALIDATION_YYYYMMDD.txt ^
  --expected-sha256 <64-char-release-sha256>
```

Apply the newest approved release:

```bat
python updater\update_manager.py auto-update
```

The command returns `restart_required: true` after a successful update. Stop and
restart Streamlit outside the updater. The updater never tries to restart the
process that is currently executing its own code.

If apply/post-apply verification fails, the updater automatically restores the
backup it created immediately before the transaction.

Manual rollback to the newest updater backup:

```bat
python updater\update_manager.py rollback
```

## Work automation contract

A Work task may perform the approval/apply commands, but should stop if:

- SHA-256 differs from the release message/report
- `RESULT: PASS` is absent
- preview reports any blocker
- current managed code drift is present
- target is a dev/patch package instead of a final RELEASE
- any protected path would be touched

Work should report the transaction journal from `update_logs/` and should not
modify `data/` or `.env`.

## Investment/execution separation

Software update approval is not an investment approval.

The release manager never changes:
- investment Execution Authorization
- portfolio orders
- Recalibration Authorization
- Capacity Authorization

Those remain governed by Stock Investment OS itself.

## Work-ready migrated layout

When `WORK_READY_LAYOUT.json` exists in the code root, Release Manager routes
`releases/`, `backups/`, `update_logs/`, and staging to `work/control/`.

The final RELEASE ZIP still targets the code root (`work/app`) and must never
contain `WORK_READY_LAYOUT.json`, `managed_code_manifest.json`, `.env`, or
`data/`.

Recommended Work authorization is the migration `work/` folder only.


## Prerelease -> final precedence

Release Manager uses explicit prerelease/final precedence.

Examples:

```text
v1.50.0-dev2-hotfix1 < v1.50.0
v1.50.0-rc1          < v1.50.0
v1.50.0              < v1.50.1
```

This allows a final `v1.50.0 RELEASE` to promote a validated
`v1.50.0-dev...` installation without artificially changing the final version
number.

## Retiring an approved test/dry-run release

An approved release that should no longer be automatically applied must be
retired rather than silently deleted.

```bat
python -m updater.update_manager retire ^
  --package ..\control\releases\approved\<RELEASE.zip> ^
  --reason "dry-run completed"
```

Retirement moves the package, validation report, and approval record to:

```text
work/control/releases/archive/retired/<RETIRE-ID>/
```

and writes an immutable retirement record plus update log.

A retired package is no longer considered by `auto-update`.


## Development managed-code baseline semantics

During a dev/hotfix chain, `managed_code_manifest.json` is the authoritative
baseline for current code/tooling.

It intentionally excludes predecessor final-release metadata:

- `manifest_sha256.json`
- `RELEASE_NOTES_v*.txt`

Historical release identity is verified separately through
`release_baselines/vX_Y_Z.json`.

A real current-code change outside the managed baseline remains DRIFT and
continues to block software update.


## Updater2 — Trusted Release Feed / Auto Inbox Sync

v1.54-updater2 removes the repeated manual file-transfer step.

Before:
download ZIP + validation TXT
→ manually copy both to work/control/releases/inbox

After one-time Trusted Feed configuration:
release feed check
→ verified remote download
→ SHA-256 / Validation / internal manifest / Preview checks
→ atomic inbox sync

When `auto_sync=true`, app startup/rerun checks the feed only when the configured
interval is due.

Updater2-dev1 does not auto-approve or auto-apply. Those remain separate policy
gates.

CLI:

```bat
python -m updater.update_manager feed-status
python -m updater.update_manager feed-check
python -m updater.update_manager feed-sync
```


## Updater2-dev2 — Release Publisher / Feed Generator

Publisher commands:

```bat
python -m updater.update_manager publisher-status

python -m updater.update_manager publisher-preview ^
  --package <FINAL_RELEASE.zip> ^
  --base-url <HTTPS_PUBLIC_BASE_URL>

python -m updater.update_manager publisher-publish ^
  --package <FINAL_RELEASE.zip> ^
  --base-url <HTTPS_PUBLIC_BASE_URL>
```

Default repository root:
`work/control/trusted_repository`

The publisher generates:
- release_feed.json
- release_history.json
- releases/<version>/RELEASE.zip
- releases/<version>/VALIDATION.txt

The next infrastructure step is a one-time static HTTPS hosting connection for
this repository root.


## Updater2-dev3 — Static HTTPS Deployment Connector

The connector binds `work/control/trusted_repository` to an external Git remote
without storing credentials inside Stock Investment OS.

Production flow:

```text
Release Publisher
→ deploy-config
→ deploy-connect
→ deploy-preview
→ deploy-push
→ deploy-verify
→ deploy-bootstrap
```

After public-feed bootstrap, the Trusted Feed URL is fixed and client Auto Sync
is enabled.

Authentication is configured outside Stock Investment OS using Git Credential
Manager or SSH.
