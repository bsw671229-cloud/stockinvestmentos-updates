"""Basic LIVE KRX regular-session guard; no scheduling or order transmission."""
from datetime import datetime, time, timedelta, timezone
from connectors.kis_broker import BrokerError

KST = timezone(timedelta(hours=9))


def _utcnow():
    return datetime.now(timezone.utc)


def _window():
    now = _utcnow()
    if now.tzinfo is None or now.utcoffset() is None:
        raise BrokerError('거래시간을 확인할 수 없습니다. 주문을 준비하거나 전송하지 않습니다')
    local = now.astimezone(KST)
    if local.weekday() >= 5:
        raise BrokerError('국내 실전 주문: 주말에는 주문을 준비하거나 전송하지 않습니다. 조회 전용 점검은 가능합니다')
    if not time(9) <= local.time() < time(15, 30):
        raise BrokerError('국내 실전 주문: 기본 정규장 시간(한국시간 09:00~15:30) 밖입니다. 예약주문으로 접수하지 않습니다')
    return local


def check_kr_order_session(client, order):
    """Calendar availability is mandatory; never infer opening from a quote."""
    if order['market'] != 'KR' or client.credentials.mode != 'LIVE':
        return {'status': 'NOT_APPLICABLE'}
    before = _window()
    day = before.strftime('%Y%m%d')
    try:
        result = client.kr_open_day(day)
    except BrokerError:
        raise
    except Exception:
        raise BrokerError('국내 개장일을 확인하지 못했습니다. 주문을 준비하거나 전송하지 않습니다') from None
    if not isinstance(result, dict) or result.get('date') != day or type(result.get('open')) is not bool:
        raise BrokerError('국내 개장일 응답을 확인하지 못했습니다. 주문을 준비하거나 전송하지 않습니다')
    if not result['open']:
        raise BrokerError('국내 실전 주문: 증권사 조회 결과 오늘은 개장일이 아닙니다. 조회 전용 점검은 가능합니다')
    after = _window()
    if after.date() != before.date():
        raise BrokerError('거래일이 바뀌었습니다. 주문을 다시 점검하세요')
    return {'status': 'PASS', 'date': day, 'checked_at': after.isoformat(), 'scope': 'LIVE_KR_BASIC_REGULAR'}
