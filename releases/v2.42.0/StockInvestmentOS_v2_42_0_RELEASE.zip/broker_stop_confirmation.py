"""Session stop intent: revoke execution immediately, confirm local stop separately."""
from datetime import datetime,timezone
from pathlib import Path
import streamlit as st
from engine.broker_execution import Journal

KEY='_broker_stop_pending'


def _now():return datetime.now(timezone.utc).isoformat()


def _queue():
    value=st.session_state.get(KEY,[])
    if not isinstance(value,list):value=[dict(valid=False,requested_at=_now())]
    st.session_state[KEY]=value
    return value


def pending():
    value=st.session_state.get(KEY,[])
    return not isinstance(value,list) or bool(value)


def _target(item):
    if (not isinstance(item,dict) or item.get('valid') is not True
        or item.get('mode') not in ('PAPER','LIVE')
        or not isinstance(item.get('account'),str) or not 0<len(item['account'])<=128
        or not isinstance(item.get('path'),str) or not Path(item['path']).is_absolute()):return None
    return item['path'],item['account'],item['mode']


def capture_target(journal,account,mode):
    queue=_queue()
    try:
        item=dict(valid=True,path=str(journal.path.resolve()),account=account,mode=mode,requested_at=_now(),attempts=0)
        target=_target(item)
        if target is None:raise ValueError('Invalid stop target')
        if not any(_target(old)==target for old in queue):queue.append(item)
    except Exception:
        if not any(_target(old) is None for old in queue):queue.append(dict(valid=False,requested_at=_now(),attempts=0))
    st.session_state[KEY]=queue


def capture_active():
    # Never retain a runnable permit while local storage is unavailable.
    active=st.session_state.pop('_paper_auto',None)
    st.session_state.pop('_paper_auto_skip_tick',None)
    if active is not None:
        try:
            class Target:
                path=Path(active['path'])
            capture_target(Target(),active['permit'].account,active.get('mode','PAPER'))
        except Exception:
            queue=_queue()
            if not any(_target(old) is None for old in queue):queue.append(dict(valid=False,requested_at=_now(),attempts=0))
            st.session_state[KEY]=queue


def capture_navigation_stop():
    if st.session_state.get('main_menu')!='KIS Execution':capture_active()


def capture_view_stop():
    if st.session_state.get('kis_view')!='AUTO':capture_active()


def retry_pending(engine_factory=None):
    if not pending():return True
    capture_active() # A stale/new capability cannot bypass an earlier unconfirmed stop.
    if engine_factory is None:
        from broker_automation import _engine
        engine_factory=_engine
    failed=[]
    for item in list(_queue()):
        target=_target(item)
        if target is None:
            failed.append(item);continue
        path,account,mode=target
        count=item.get('attempts',0)
        attempt=dict(item,attempts=(count if type(count) is int and count>=0 else 0)+1,last_attempt_at=_now())
        try:
            journal=Journal(Path(path))
            engine_factory(journal,mode).stop(account)
            if not journal.halted(account):raise ValueError('Stop not confirmed')
        except Exception:
            # No arbitrary exception text, account, or path is rendered or exported.
            attempt['status']='STOP_UNCONFIRMED';failed.append(attempt)
    if failed:st.session_state[KEY]=failed
    else:st.session_state.pop(KEY,None)
    return not failed


def render_pending():
    st.error('중지 기록 확인 대기 · 현재 세션의 자동 실행 권한을 제거했습니다. 저장된 중지·신규 주문 차단을 확인할 때까지 이 화면의 새 주문·자동매매 시작·차단 해제를 사용할 수 없습니다.')
    st.caption('기록 저장소가 잠겼거나 사용할 수 없을 수 있습니다. 저장소 접근을 확인한 뒤 아래 버튼으로 다시 확인하세요. 원인을 확정하지 않은 오류 원문은 표시하지 않습니다. 이미 전송 중인 요청은 완료될 수 있으며 접수된 주문은 자동 취소되지 않습니다.')
    st.caption('재확인 대상은 현재 브라우저 세션에 보관합니다. 앱·브라우저를 다시 시작했다면 이전 실행·주문 결과를 직접 확인하세요. 저장 실패가 영구 기록으로 보장된다는 뜻은 아닙니다.')
    st.button('중지 기록 다시 확인',key='broker_stop_retry') # Its normal rerun retries the gate before controls render.


def gate(engine_factory=None):
    if retry_pending(engine_factory):return True
    render_pending();return False
