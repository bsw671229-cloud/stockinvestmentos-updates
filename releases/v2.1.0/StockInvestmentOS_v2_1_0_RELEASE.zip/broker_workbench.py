"""Explicit user-operated KIS order and reconciliation screen."""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import time
import streamlit as st
from connectors.kis_broker import BrokerError,Credentials,KisClient
from engine.broker_execution import Journal,prepare_order,confirmation_text,submit_order,reconcile_order,cancel_order
from migration.work_ready_paths import resolve_control_root

STATUS={'PREPARED':'확인 대기','SENDING':'전송 중 · 결과 확인 필요','UNKNOWN':'접수 여부 미확인',
        'ACKNOWLEDGED':'접수됨 · 체결 확인 필요','OPEN':'미체결','PARTIAL':'부분 체결',
        'FILLED':'전량 체결','CANCEL_REQUESTED':'취소 요청됨 · 확인 필요','CANCEL_UNKNOWN':'취소 결과 미확인',
        'CANCELLED':'취소 확인','REJECTED':'증권사 거절','EXPIRED':'확인 만료','FAILED_PRECHECK':'사전 점검 실패'}


def _attempt(action):
    try: return action()
    except BrokerError as exc: st.error(str(exc))
    except Exception: st.error('처리를 완료하지 못했습니다. 전송 기록과 증권사 주문 내역을 확인하세요. 자동 재전송하지 않습니다.')
    return None


def _summary(record):
    order=record['payload']['order']
    return {'환경':record['payload']['mode'],'계좌':record['payload']['account_label'],
            '시장':order['market'],'거래소':order['exchange'],'종목':order['symbol'],
            '방향':'매수' if order['side']=='BUY' else '매도','수량':order['quantity'],
            '지정가':order['limit_price'],'통화':order['currency'],'상태':STATUS.get(record['status'],record['status'])}


def render(root:Path):
    st.title('한국투자증권 주문·운영')
    st.caption('국내 KRX · 미국 NASDAQ / NYSE / AMEX | 정수 수량 · 현금 지정가 주문')
    st.info('각 주문은 사전 점검 → 내용 확인 → 사용자가 전송합니다. 접수와 체결은 구분하여 표시합니다.')
    st.warning('이 버전의 실제 증권사 연결·주문·체결 검증은 아직 완료되지 않았습니다. 먼저 모의 환경에서 확인하세요.')
    mode=st.radio('연결 환경',['PAPER','LIVE'],format_func=lambda x:'모의투자' if x=='PAPER' else '실전투자',horizontal=True,key='kis_mode')
    if st.session_state.get('_kis_mode')!=mode:
        for key in ('_kis_client','_kis_pending','kis_allow_live'): st.session_state.pop(key,None)
        st.session_state['_kis_mode']=mode
    with st.expander('API 연결 설정 방법'):
        st.write('한국투자증권에서 해당 환경의 API 이용 신청과 계좌 준비를 마친 뒤, 이 프로그램을 실행하는 PC에 아래 환경변수를 설정하고 프로그램을 다시 시작하세요. 키와 계좌번호는 채팅에 보내지 마세요.')
        st.code('\n'.join('KIS_'+mode+'_'+name for name in ('APP_KEY','APP_SECRET','ACCOUNT','PRODUCT')))
        st.caption('ACCOUNT: 계좌 앞 8자리 / PRODUCT: 01. 모의·실전 키와 계좌는 각각 설정합니다. 토큰은 현재 연결의 메모리에만 보관합니다.')
        st.link_button('한국투자증권 공식 API 안내','https://apiportal.koreainvestment.com/apiservice-summary')
    client=st.session_state.get('_kis_client')
    if client is None:
        if st.button('설정한 계좌로 연결 확인',key='kis_connect'):
            def connect():
                value=KisClient(Credentials.from_env(mode));value.connect();return value
            client=_attempt(connect)
            if client is not None: st.session_state['_kis_client']=client;st.rerun()
        st.caption('연결 확인은 인증만 수행합니다. 주문은 전송하지 않습니다.')
        return
    st.success(f"{mode} 연결 · 계좌 {client.credentials.masked_account}")
    if st.button('연결 해제',key='kis_disconnect'):
        st.session_state.pop('_kis_client',None);st.session_state.pop('_kis_pending',None);st.rerun()
    allow_live=False
    if mode=='LIVE':
        allow_live=st.checkbox('이 세션에서 직접 확인한 실전 주문·취소 전송을 허용합니다',key='kis_allow_live')
    journal=_attempt(lambda:Journal(resolve_control_root(Path(root))/'broker_operations/orders.sqlite3'))
    if journal is None: return
    account=client.credentials.identity
    halted=journal.halted(account)
    col1,col2=st.columns(2)
    col1.metric('신규 주문', '중지됨' if halted else '사용자 확인 후 가능')
    if col2.button('신규 주문 다시 허용' if halted else '신규 주문 중지',key='kis_halt'):
        if _attempt(lambda:(journal.set_halted(account,not halted),True)[1]): st.rerun()
    st.caption('중지는 이 프로그램의 신규 주문을 막습니다. 이미 접수된 주문의 취소와 상태 조회는 별도로 진행합니다.')

    st.subheader('1. 주문 준비')
    market=st.selectbox('시장',['KR','US'],format_func=lambda x:'국내 주식·ETF' if x=='KR' else '미국 주식·ETF',key='kis_market')
    exchange=st.selectbox('거래소',['KRX'] if market=='KR' else ['NASD','NYSE','AMEX'],key='kis_exchange_'+market)
    side=st.radio('주문 방향',['BUY','SELL'],format_func=lambda x:'매수' if x=='BUY' else '매도',horizontal=True,key='kis_side')
    currency='KRW' if market=='KR' else 'USD'
    with st.form('kis_prepare'):
        symbol=st.text_input('종목코드',key='kis_symbol_'+market,placeholder='6자리 코드' if market=='KR' else '티커')
        quantity=st.number_input('수량 (주)',min_value=1,max_value=1000000,value=1,step=1,key='kis_quantity')
        price=st.text_input('지정가 ('+currency+')',value='0',key='kis_price_'+market)
        cap=st.text_input('이번 주문의 금액 상한 ('+currency+')',value='0',key='kis_cap_'+market)
        fee=st.text_input('비용 여유율 (%)',value='0.5',key='kis_fee')
        gap=st.text_input('조회 가격과 지정가 차이 한도 (%)',value='3',key='kis_gap')
        downside=st.text_input('틀렸을 때의 하락 가정 (%)',value='0',key='kis_downside',disabled=side=='SELL')
        loss=st.text_input('이번 매수의 가정 손실 예산 ('+currency+')',value='0',key='kis_loss_'+market,disabled=side=='SELL')
        st.caption('가정 손실은 지정가 × 수량 × 하락 가정 + 비용 여유입니다. 실제 손실의 상한이나 손절 주문이 아닙니다. 미국 주문은 USD 현금 기준이며 자동 환전하지 않습니다.')
        attested=st.checkbox('종목·가격·수량·금액 상한과 손실 가정을 직접 확인했습니다',key='kis_risk_attested')
        prepared=st.form_submit_button('시세·주문 가능금액 점검',disabled=halted)
    if prepared:
        st.session_state.pop('_kis_pending',None)
        order=dict(market=market,exchange=exchange,symbol=symbol,side=side,quantity=quantity,limit_price=price)
        limits=dict(max_notional=cap,fee_buffer_pct=fee,max_quote_gap_pct=gap,downside_pct=downside,max_scenario_loss=loss,risk_attested=attested)
        record=_attempt(lambda:prepare_order(client,journal,order,limits))
        if record: st.session_state['_kis_pending']=record['id']
    pending=st.session_state.get('_kis_pending')
    if pending:
        record=_attempt(lambda:journal.get(pending,account))
        if record and record['status']=='PREPARED':
            st.subheader('2. 아래 고정된 주문을 확인하고 전송')
            st.table([_summary(record)])
            snap=record['payload']['snapshot']
            st.write(f"증권사 조회 가격: {snap['quote']['price']} {record['payload']['order']['currency']} · 조회시각(UTC): {snap['quote']['fetched_at']}")
            st.write(f"비용 포함 금액: {snap['estimated_cost']} · 가정 손실: {snap['scenario_loss']} {record['payload']['order']['currency']}")
            st.caption('새 주문을 준비하면 이전 확인은 만료됩니다. 다른 화면 입력을 바꿔도 위 고정된 주문은 바뀌지 않습니다. 전송 직전에 가격·현금·수량을 다시 확인합니다.')
            expired=time.time()>record['expires']
            st.write('확인 만료시각(UTC): '+datetime.fromtimestamp(record['expires'],timezone.utc).strftime('%H:%M:%S'))
            phrase=confirmation_text(record)
            st.code(phrase)
            confirmation=st.text_input('위 주문 확인 문구를 그대로 입력',key='kis_confirm_'+pending)
            if st.button('실제 주문 전송' if mode=='LIVE' else '모의 주문 전송',key='kis_send',type='primary',disabled=expired or halted or (mode=='LIVE' and not allow_live)):
                sent=_attempt(lambda:submit_order(client,journal,pending,confirmation,allow_live=allow_live))
                if sent:
                    st.session_state.pop('_kis_pending',None)
                    st.session_state['_kis_notice']=STATUS[sent['status']]
                    st.rerun()
            if expired: st.warning('확인 시간이 지났습니다. 주문을 다시 준비하세요.')
    if st.session_state.get('_kis_notice'): st.info(st.session_state.pop('_kis_notice'))
    st.subheader('3. 주문 기록·체결 확인·취소')
    records=journal.recent(account)
    if not records: st.caption('이 프로그램에서 준비한 주문 기록이 없습니다.');return
    st.dataframe([{**_summary(r),'주문번호':r['result'].get('order_no',''),
        '체결':r['result'].get('filled_quantity','미확인'),'잔여':r['result'].get('remaining_quantity','미확인'),
        '기록 ID':r['id']} for r in records],hide_index=True)
    chosen=st.selectbox('확인할 주문',[r['id'] for r in records],format_func=lambda i:next(r['payload']['order']['symbol']+' · '+STATUS[r['status']]+' · '+i[-6:] for r in records if r['id']==i),key='kis_history')
    selected=next(r for r in records if r['id']==chosen)
    if selected['status'] in ('UNKNOWN','SENDING','CANCEL_UNKNOWN'):
        st.error('전송 결과가 확정되지 않았습니다. 한국투자증권 앱의 주문·체결 내역을 직접 확인하세요. 접수번호 없는 미확인 기록은 이 버전에서 자동 해제하지 않습니다.')
    if st.button('증권사에서 체결 상태 조회',key='kis_reconcile'):
        if _attempt(lambda:reconcile_order(client,journal,chosen)): st.rerun()
    if selected['status'] in ('ACKNOWLEDGED','OPEN','PARTIAL'):
        st.caption('취소할 주문을 확인하세요. 이미 체결된 수량은 취소할 수 없습니다.')
        phrase='CANCEL '+selected['result'].get('order_no','')
        st.code(phrase)
        confirmation=st.text_input('취소 확인 문구',key='kis_cancel_confirm_'+chosen)
        if st.button('미체결 수량 취소 요청',key='kis_cancel',disabled=mode=='LIVE' and not allow_live):
            if _attempt(lambda:cancel_order(client,journal,chosen,confirmation,allow_live=allow_live)): st.rerun()
