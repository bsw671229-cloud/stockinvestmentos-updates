"""KIS REST adapter. Network requests happen only on explicit method calls.

Official protocol references checked 2026-10-09; see release development evidence.
Secrets stay in process memory; responses exposed to callers are allowlisted.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from threading import RLock
import hashlib, os, re, time
import requests


class BrokerError(RuntimeError):
    pass


class BrokerRejected(BrokerError):
    pass


def number(value, *, positive=False) -> Decimal:
    if isinstance(value,bool): raise BrokerError('숫자 입력을 확인하세요')
    if len(str(value))>64: raise BrokerError('숫자 입력 범위를 초과했습니다')
    try: result=Decimal(str(value))
    except (InvalidOperation,ValueError,TypeError): raise BrokerError('숫자 입력을 확인하세요') from None
    if not result.is_finite() or result<0 or result>Decimal('1e18') or (positive and result==0):
        raise BrokerError('유효한 양수 또는 0이 필요합니다')
    if result and result.adjusted() < -12: raise BrokerError('숫자 입력 정밀도를 초과했습니다')
    return result


def whole(value) -> int:
    result=number(value)
    if result!=result.to_integral_value(): raise BrokerError('정수 수량이 필요합니다')
    return int(result)


@dataclass(frozen=True)
class Credentials:
    mode: str
    app_key: str=field(repr=False)
    app_secret: str=field(repr=False)
    account: str=field(repr=False)
    product: str=field(default='01',repr=False)

    def __post_init__(self):
        if self.mode not in {'PAPER','LIVE'}: raise BrokerError('모의/실전 환경을 선택하세요')
        if not self.app_key or not self.app_secret: raise BrokerError('해당 환경의 API 키 설정이 필요합니다')
        if not re.fullmatch(r'\d{8}',self.account) or self.product!='01':
            raise BrokerError('주식 위탁계좌 8자리와 상품코드 01을 확인하세요')

    @classmethod
    def from_env(cls,mode):
        if mode not in {'PAPER','LIVE'}: raise BrokerError('잘못된 연결 환경입니다')
        prefix='KIS_'+mode+'_'
        return cls(mode,os.getenv(prefix+'APP_KEY',''),os.getenv(prefix+'APP_SECRET',''),
                   os.getenv(prefix+'ACCOUNT',''),os.getenv(prefix+'PRODUCT','01'))

    @property
    def identity(self):
        return hashlib.sha256(f'{self.mode}:{self.account}:{self.product}'.encode()).hexdigest()

    @property
    def masked_account(self): return '****'+self.account[-4:]+'-'+self.product


def validate_order(order):
    if not isinstance(order,dict): raise BrokerError('주문 입력을 확인하세요')
    market=order.get('market');exchange=order.get('exchange');symbol=str(order.get('symbol','')).strip().upper()
    if market=='KR':
        if exchange!='KRX' or not re.fullmatch(r'\d{6}',symbol): raise BrokerError('국내 KRX 종목코드 6자리가 필요합니다')
    elif market=='US':
        if exchange not in {'NASD','NYSE','AMEX'} or not re.fullmatch(r'[A-Z][A-Z0-9.\-]{0,14}',symbol):
            raise BrokerError('미국 거래소와 종목코드를 확인하세요')
    else: raise BrokerError('국내 또는 미국 시장을 선택하세요')
    if order.get('side') not in {'BUY','SELL'}: raise BrokerError('매수/매도를 선택하세요')
    quantity=whole(order.get('quantity'));price=number(order.get('limit_price'),positive=True)
    if not 1<=quantity<=1000000: raise BrokerError('수량은 1~1,000,000주 정수만 가능합니다')
    quantum=Decimal('1') if market=='KR' else Decimal('0.01')
    if price>Decimal('1000000000') or price!=price.quantize(quantum):
        raise BrokerError('국내 가격은 원 단위, 미국 가격은 센트 단위로 입력하세요')
    return dict(market=market,exchange=exchange,symbol=symbol,side=order['side'],quantity=quantity,
                limit_price=format(price,'f'),currency='KRW' if market=='KR' else 'USD')


class KisClient:
    def __init__(self,credentials:Credentials,session=None):
        self.credentials=credentials
        self._http=session or requests.Session()
        if session is None: self._http.trust_env=False
        self._lock=RLock();self._token='';self._expiry=0.0;self._last_call=0.0

    @property
    def base_url(self):
        return 'https://openapi.koreainvestment.com:9443' if self.credentials.mode=='LIVE' else 'https://openapivts.koreainvestment.com:29443'

    def _http_json(self,method,path,headers,payload):
        # No redirect and no automatic retry, especially for a send with an unknown outcome.
        delay=(0.55 if self.credentials.mode=='PAPER' else 0.12)-(time.monotonic()-self._last_call)
        if delay>0: time.sleep(delay)
        self._last_call=time.monotonic()
        try:
            response=self._http.request(method,self.base_url+path,headers=headers,
                **({'json':payload} if method=='POST' else {'params':payload}),timeout=(5,12),allow_redirects=False)
            if response.status_code!=200: raise BrokerError('증권사 HTTP 응답 오류: '+str(response.status_code))
            body=response.json()
            if not isinstance(body,dict): raise BrokerError('증권사 응답 형식을 확인할 수 없습니다')
            return body,{str(k).lower():v for k,v in response.headers.items()}
        except BrokerError: raise
        except Exception: raise BrokerError('증권사 통신 결과를 확인할 수 없습니다. 자동 재전송하지 않습니다.') from None

    def connect(self):
        with self._lock:
            if self._token and time.monotonic()<self._expiry: return
            body,_=self._http_json('POST','/oauth2/tokenP',{'content-type':'application/json'},
                {'grant_type':'client_credentials','appkey':self.credentials.app_key,'appsecret':self.credentials.app_secret})
            token=body.get('access_token')
            if not isinstance(token,str) or not token: raise BrokerError('인증에 실패했습니다. 환경과 API 설정을 확인하세요')
            try: lifetime=min(float(body.get('expires_in',3600)),86400)
            except (TypeError,ValueError): raise BrokerError('인증 유효기간을 확인할 수 없습니다') from None
            if not 60<lifetime<=86400: raise BrokerError('인증 유효기간이 올바르지 않습니다')
            self._token=token;self._expiry=time.monotonic()+lifetime-60

    def _request(self,method,path,trid,payload,continuation=''):
        with self._lock:
            self.connect()
            headers={'content-type':'application/json; charset=utf-8','authorization':'Bearer '+self._token,
                'appkey':self.credentials.app_key,'appsecret':self.credentials.app_secret,'tr_id':trid,'custtype':'P','tr_cont':continuation}
            body,headers=self._http_json(method,path,headers,payload)
            if body.get('rt_cd') not in {'0','1'}:
                raise BrokerError('증권사 처리 결과가 불명확합니다. 재전송하지 마세요')
            if body['rt_cd']=='1':
                code=re.sub(r'[^A-Za-z0-9_-]','',str(body.get('msg_cd','UNKNOWN')))[:32]
                raise BrokerRejected('증권사 요청 거절: '+code)
            return body,headers

    def _tr(self,live,paper): return live if self.credentials.mode=='LIVE' else paper
    def _account(self): return {'CANO':self.credentials.account,'ACNT_PRDT_CD':self.credentials.product}

    def quote(self,order):
        order=validate_order(order)
        if order['market']=='KR':
            body,_=self._request('GET','/uapi/domestic-stock/v1/quotations/inquire-price','FHKST01010100',
                {'FID_COND_MRKT_DIV_CODE':'J','FID_INPUT_ISCD':order['symbol']})
            output=body.get('output',{});value=number(output.get('stck_prpr'),positive=True)
            name=str(output.get('hts_kor_isnm') or order['symbol'])
        else:
            body,_=self._request('GET','/uapi/overseas-price/v1/quotations/price','HHDFS00000300',
                {'AUTH':'','EXCD':{'NASD':'NAS','NYSE':'NYS','AMEX':'AMS'}[order['exchange']],'SYMB':order['symbol']})
            output=body.get('output',{});value=number(output.get('last'),positive=True);name=order['symbol']
        return {'price':str(value),'name':name,'fetched_at':datetime.now(timezone.utc).isoformat(),
                'currency':order['currency'],'source':'KIS 조회값 (실시간 체결 보장 아님)'}

    def buying_power(self,order):
        order=validate_order(order);params=self._account()
        if order['market']=='KR':
            # Official guide requires 01 for no-receivable buying-quantity estimation.
            params.update(PDNO=order['symbol'],ORD_UNPR=order['limit_price'],ORD_DVSN='01',CMA_EVLU_AMT_ICLD_YN='N',OVRS_ICLD_YN='N')
            body,_=self._request('GET','/uapi/domestic-stock/v1/trading/inquire-psbl-order',self._tr('TTTC8908R','VTTC8908R'),params)
            output=body.get('output',{});cash=number(output.get('nrcvb_buy_amt'));quantity=whole(output.get('nrcvb_buy_qty'))
        else:
            params.update(OVRS_EXCG_CD=order['exchange'],OVRS_ORD_UNPR=order['limit_price'],ITEM_CD=order['symbol'])
            body,_=self._request('GET','/uapi/overseas-stock/v1/trading/inquire-psamount',self._tr('TTTS3007R','VTTS3007R'),params)
            output=body.get('output',{})
            if output.get('tr_crcy_cd')!='USD': raise BrokerError('미국 주문 가능금액의 USD 통화를 확인할 수 없습니다')
            cash=number(output.get('ord_psbl_frcr_amt'));quantity=whole(output.get('ord_psbl_qty'))
        return {'cash':str(cash),'quantity':quantity,'currency':order['currency']}

    def _pages(self,path,trid,params,key,area):
        rows=[];continuation='';seen=set()
        for _ in range(30):
            body,headers=self._request('GET',path,trid,params,continuation)
            output=body.get(key)
            if not isinstance(output,list): raise BrokerError('증권사 목록 응답 형식이 올바르지 않습니다')
            rows.extend(output)
            if headers.get('tr_cont') not in {'M','F'}: return rows
            cursor=(body.get('ctx_area_fk'+area),body.get('ctx_area_nk'+area))
            if cursor in seen or not all(isinstance(v,str) for v in cursor): raise BrokerError('증권사 연속조회가 완결되지 않았습니다')
            seen.add(cursor);params.update({'CTX_AREA_FK'+area:cursor[0],'CTX_AREA_NK'+area:cursor[1]});continuation='N'
        raise BrokerError('조회 한도를 넘었습니다. 불완전한 잔고로 주문하지 않습니다')

    def sellable(self,order):
        order=validate_order(order);params=self._account()
        if order['market']=='KR':
            params.update(AFHR_FLPR_YN='N',OFL_YN='',INQR_DVSN='02',UNPR_DVSN='01',FUND_STTL_ICLD_YN='N',
                FNCG_AMT_AUTO_RDPT_YN='N',PRCS_DVSN='01',CTX_AREA_FK100='',CTX_AREA_NK100='')
            rows=self._pages('/uapi/domestic-stock/v1/trading/inquire-balance',self._tr('TTTC8434R','VTTC8434R'),params,'output1','100')
            selected=[r for r in rows if r.get('pdno')==order['symbol']]
        else:
            params.update(OVRS_EXCG_CD=order['exchange'],TR_CRCY_CD='USD',CTX_AREA_FK200='',CTX_AREA_NK200='')
            rows=self._pages('/uapi/overseas-stock/v1/trading/inquire-balance',self._tr('TTTS3012R','VTTS3012R'),params,'output1','200')
            selected=[r for r in rows if r.get('ovrs_pdno')==order['symbol'] and r.get('ovrs_excg_cd')==order['exchange']]
        return sum(whole(r.get('ord_psbl_qty')) for r in selected)

    def send_limit(self,order):
        order=validate_order(order);params=self._account()
        if order['market']=='KR':
            params.update(PDNO=order['symbol'],ORD_DVSN='00',ORD_QTY=str(order['quantity']),ORD_UNPR=order['limit_price'],
                EXCG_ID_DVSN_CD='KRX',SLL_TYPE='01' if order['side']=='SELL' else '',CNDT_PRIC='')
            tr=self._tr('TTTC0012U','VTTC0012U') if order['side']=='BUY' else self._tr('TTTC0011U','VTTC0011U')
            path='/uapi/domestic-stock/v1/trading/order-cash'
        else:
            params.update(OVRS_EXCG_CD=order['exchange'],PDNO=order['symbol'],ORD_QTY=str(order['quantity']),
                OVRS_ORD_UNPR=order['limit_price'],CTAC_TLNO='',MGCO_APTM_ODNO='',SLL_TYPE='00' if order['side']=='SELL' else '',
                ORD_SVR_DVSN_CD='0',ORD_DVSN='00')
            tr=self._tr('TTTT1002U','VTTT1002U') if order['side']=='BUY' else self._tr('TTTT1006U','VTTT1001U')
            path='/uapi/overseas-stock/v1/trading/order'
        body,_=self._request('POST',path,tr,params)
        output=body.get('output',{});lower={k.lower():v for k,v in output.items()}
        odno=str(lower.get('odno','')).strip()
        if not re.fullmatch(r'\d{1,20}',odno): raise BrokerError('주문번호를 확인할 수 없습니다. 재전송하지 마세요')
        return {'order_no':odno,'branch':str(lower.get('krx_fwdg_ord_orgno') or lower.get('ord_gno_brno') or ''),
                'order_time':str(lower.get('ord_tmd','')),'accepted_at':datetime.now(timezone.utc).isoformat(),'status':'ACKNOWLEDGED'}

    def order_history(self,order,start_date,end_date):
        order=validate_order(order);params=self._account()
        if not all(re.fullmatch(r'\d{8}',d) for d in [start_date,end_date]): raise BrokerError('조회 날짜를 확인하세요')
        if order['market']=='KR':
            params.update(INQR_STRT_DT=start_date,INQR_END_DT=end_date,SLL_BUY_DVSN_CD='00',PDNO=order['symbol'],
                CCLD_DVSN='00',INQR_DVSN='00',INQR_DVSN_3='00',ORD_GNO_BRNO='',ODNO='',INQR_DVSN_1='',
                CTX_AREA_FK100='',CTX_AREA_NK100='',EXCG_ID_DVSN_CD='KRX')
            rows=self._pages('/uapi/domestic-stock/v1/trading/inquire-daily-ccld',self._tr('TTTC0081R','VTTC0081R'),params,'output1','100')
        else:
            params.update(PDNO=order['symbol'],ORD_STRT_DT=start_date,ORD_END_DT=end_date,SLL_BUY_DVSN='00',CCLD_NCCS_DVSN='00',
                OVRS_EXCG_CD='' if self.credentials.mode=='PAPER' else order['exchange'],SORT_SQN='DS',ORD_DT='',ORD_GNO_BRNO='',ODNO='',CTX_AREA_FK200='',CTX_AREA_NK200='')
            rows=self._pages('/uapi/overseas-stock/v1/trading/inquire-ccnl',self._tr('TTTS3035R','VTTS3035R'),params,'output','200')
        keep={'ord_dt','odno','orgn_odno','pdno','sll_buy_dvsn_cd','ord_qty','ft_ord_qty','tot_ccld_qty','ft_ccld_qty',
            'ord_unpr','ft_ord_unpr3','avg_prvs','ft_ccld_unpr3','cncl_yn','cnc_cfrm_qty','rmn_qty','nccs_qty','rjct_qty','rjct_rson','rvse_cncl_dvsn','ord_tmd','ovrs_excg_cd'}
        return [{k:v for k,v in row.items() if k in keep} for row in rows]

    def cancel(self,order,receipt,remaining):
        order=validate_order(order);remaining=whole(remaining)
        if remaining<=0: raise BrokerError('취소할 잔여 수량이 없습니다')
        odno=str(receipt.get('order_no',''))
        if not re.fullmatch(r'\d{1,20}',odno): raise BrokerError('증권사 원주문번호가 필요합니다')
        params=self._account()
        if order['market']=='KR':
            if not receipt.get('branch'): raise BrokerError('국내 원주문 조직번호가 필요합니다')
            params.update(KRX_FWDG_ORD_ORGNO=receipt['branch'],ORGN_ODNO=odno,ORD_DVSN='00',RVSE_CNCL_DVSN_CD='02',
                ORD_QTY=str(remaining),ORD_UNPR='0',QTY_ALL_ORD_YN='Y',EXCG_ID_DVSN_CD='KRX')
            path='/uapi/domestic-stock/v1/trading/order-rvsecncl';tr=self._tr('TTTC0013U','VTTC0013U')
        else:
            params.update(OVRS_EXCG_CD=order['exchange'],PDNO=order['symbol'],ORGN_ODNO=odno,RVSE_CNCL_DVSN_CD='02',
                ORD_QTY=str(remaining),OVRS_ORD_UNPR='0',MGCO_APTM_ODNO='',ORD_SVR_DVSN_CD='0')
            path='/uapi/overseas-stock/v1/trading/order-rvsecncl';tr=self._tr('TTTT1004U','VTTT1004U')
        self._request('POST',path,tr,params)
        return {'status':'CANCEL_REQUESTED','order_no':odno}
