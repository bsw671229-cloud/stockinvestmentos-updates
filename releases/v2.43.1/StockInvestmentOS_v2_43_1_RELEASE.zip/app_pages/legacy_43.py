from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('시나리오 비교')
    st.caption('기존 과대집중 포지션을 엄격한하게 정리하는 경우와 1주 예외를 남기는 경우를 비교합니다. 이 화면은 검토용이며 주문을 전송하거나 포트폴리오를 변경하지 않습니다.')
    names = portfolio['name'].dropna().astype(str).tolist()
    if not names:
        names = ['']
    donor_default = names.index('삼성전자') if '삼성전자' in names else 0
    donor_name = st.selectbox('자금 제공 자산 / 위험 보완 보유 종목', names, index=donor_default if names else 0)
    ready_names = watchlist['name'].dropna().astype(str).tolist()
    if not ready_names:
        ready_names = ['']
    rec_default = ready_names.index('NICE평가정보') if 'NICE평가정보' in ready_names else 0
    recipient_name = st.selectbox('자금 수령 자산 후보', ready_names, index=rec_default if ready_names else 0)
    a, b = st.columns(2)
    strict_qty = a.number_input('엄격한 대상 주식 수', min_value=0, step=1, value=int(settings.get('default_strict_target_qty', 0)))
    override_qty = b.number_input('1-주문 단위 예외 승인 대상 주식 수', min_value=0, step=1, value=int(settings.get('default_override_target_qty', 1)))
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    audit_df = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    try:
        scenarios = compare_two_repair_scenarios(portfolio, watchlist, state_df, audit_df, total_assets, donor_name, recipient_name, int(strict_qty), int(override_qty), loss_budget, single_cap)
    except Exception as e:
        scenarios = pd.DataFrame()
        st.error(_locale.message(str(e)))
    if not scenarios.empty:
        cards = scenario_summary_cards(scenarios)
        strict = cards.get('STRICT', {})
        one = cards.get('ONE_LOT_OVERRIDE', {})
        st.subheader('엄격한')
        s1, s2, s3, s4 = st.columns(4)
        s1.metric('매도 주식 수', _locale.code(strict.get('sell_qty', 0)))
        s2.metric('매도 대금 추정치', _locale.code(krw(strict.get('sale_proceeds_proxy_krw', 0))))
        s3.metric('자금 제공 자산 사후 비중', _locale.code(pct(strict.get('donor_post_weight', 0))))
        s4.metric('자금 제공 자산 하락 시나리오 손실위험자본', _locale.code(pct(strict.get('donor_post_bear_car', 0))))
        st.write(f"자금 수령 자산 점검: **{_locale.code(strict.get('recipient_gate', '-'))}** / 처리 용량 조건 점검 해제: **{strict.get('recipient_capacity_qty_if_gate_clear', 0)}주** / 현재-정책 실행 가능 수량: **{strict.get('recipient_executable_qty_under_current_policy', 0)}주**")
        st.subheader('1-주문 단위 예외 승인')
        o1, o2, o3, o4 = st.columns(4)
        o1.metric('매도 주식 수', _locale.code(one.get('sell_qty', 0)))
        o2.metric('매도 대금 추정치', _locale.code(krw(one.get('sale_proceeds_proxy_krw', 0))))
        o3.metric('자금 제공 자산 사후 비중', _locale.code(pct(one.get('donor_post_weight', 0))))
        o4.metric('자금 제공 자산 하락 시나리오 손실위험자본', _locale.code(pct(one.get('donor_post_bear_car', 0))))
        st.write(f"자금 수령 자산 점검: **{_locale.code(one.get('recipient_gate', '-'))}** / 처리 용량 조건 점검 해제: **{one.get('recipient_capacity_qty_if_gate_clear', 0)}주** / 현재-정책 실행 가능 수량: **{one.get('recipient_executable_qty_under_current_policy', 0)}주**")
        st.subheader('매매 구분-기준-매매 구분')
        cols = ['scenario', 'donor_target_qty', 'donor_sell_qty', 'sale_proceeds_proxy_krw', 'donor_post_weight', 'donor_post_bear_car', 'donor_risk_max', 'donor_repair_complete', 'override_required', 'recipient_state', 'recipient_audit', 'recipient_risk_max', 'recipient_stage_target_weight', 'recipient_capacity_qty_if_gate_clear', 'recipient_policy_gate', 'recipient_executable_qty_under_current_policy', 'residual_sale_proceeds_proxy_krw']
        _locale.dataframe(st, scenarios[[c for c in cols if c in scenarios.columns]], width='stretch', hide_index=True)
        st.info("1-주문 단위 시나리오의 '처리 용량 조건 점검 해제'는 비교용 잠재용량입니다. 현재 엄격한 위험 점검을 통과하지 못하면 실제 계획 수량은 0주/대기로 유지됩니다.")
        if st.button('1-주문 단위 예외 승인 초안 만들기'):
            overrides = ensure_cols(load_csv('overrides.csv'), OVERRIDE_COLS)
            stamp = pd.Timestamp.now().strftime('%Y%m%d%H%M%S')
            draft = pd.DataFrame([{'override_id': f'OVR-{stamp}', 'company': donor_name, 'override_type': 'ONE_LOT_RISK_EXCEPTION', 'requested_change': f'Keep {int(override_qty)} share(s) despite strict risk cap', 'reason': 'DRAFT — document why a one-lot exception is necessary before approval.', 'evidence_level': '', 'approved_by': '', 'start_date': str(date.today()), 'expiry_date': '', 'status': 'DRAFT', 'notes': f'Scenario Compare v{VERSION}; recipient remains gated until policy explicitly resolves the exception.'}])
            save_csv(pd.concat([overrides, draft], ignore_index=True), 'overrides.csv')
            st.success('예외 승인 등록부에 초안을 만들었습니다. 승인/투자 근거/만료일이 없으므로 아직 유효하지 않습니다.')
        st.download_button('시나리오 비교 표 데이터 받기', scenarios.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'scenario_compare.csv', 'text/csv')
