from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('상장지수펀드 실질 구성자산 분석')
    st.caption('상장지수펀드의 기초자산을 직접 입력하거나 지원되는 상장지수펀드는 yfinance에서 상위 보유 내역을 가져옵니다. 부분 보유목록은 Unmapped로 남겨 과도한 정밀도를 피합니다.')
    holdings = ensure_cols(load_csv('etf_holdings.csv'), ETF_HOLDING_COLS)
    tab1, tab2, tab3 = st.tabs(['보유 내역 관리', '실질 구성자산 분석 노출', '상장지수펀드 중복'])
    with tab1:
        edited = _locale.editor(st, holdings, num_rows='dynamic', width='stretch', key='etf_holdings_editor')
        c1, c2, c3 = st.columns(3)
        if c1.button('상장지수펀드 보유 내역 저장', type='primary'):
            save_csv(normalize_holdings(edited), 'etf_holdings.csv')
            st.success('저장했습니다.')
            st.rerun()
        etf_ticker = c2.text_input('yfinance 상장지수펀드 종목코드', value='', placeholder='예: SPY, QQQ')
        etf_name = c3.text_input('상장지수펀드 이름', value='')
        if st.button('상위 보유 내역 자동 가져오기'):
            try:
                fetched = yfinance_top_holdings(etf_ticker)
                fetched['etf_name'] = etf_name or etf_ticker
                fetched['etf_ticker'] = etf_ticker
                fetched['sector'] = ''
                fetched['country'] = ''
                fetched['currency'] = ''
                fetched['factor'] = ''
                fetched['source'] = 'yfinance funds_data'
                fetched['as_of'] = str(date.today())
                fetched = ensure_cols(fetched, ETF_HOLDING_COLS)
                merged = pd.concat([holdings, fetched], ignore_index=True)
                save_csv(normalize_holdings(merged), 'etf_holdings.csv')
                st.success(f'{len(fetched)}개 상위 보유 내역을 추가했습니다.')
                st.rerun()
            except Exception as e:
                st.error(_locale.message(str(e)))
        uploaded = st.file_uploader('상장지수펀드 보유 내역 표 데이터 가져오기', type=['csv'], key='etf_csv')
        if uploaded is not None:
            imp = pd.read_csv(uploaded)
            _locale.dataframe(st, imp, width='stretch')
            if st.button('업로드 보유 내역 추가'):
                merged = pd.concat([holdings, ensure_cols(imp, ETF_HOLDING_COLS)], ignore_index=True)
                save_csv(normalize_holdings(merged), 'etf_holdings.csv')
                st.success('추가했습니다.')
                st.rerun()
    with tab2:
        lt = portfolio_lookthrough(portfolio, holdings)
        if lt.empty:
            st.info('포트폴리오 또는 상장지수펀드 보유 내역이 비어 있습니다.')
        else:
            st.subheader('상위 기초자산 집중도')
            uc = underlying_concentration(lt, total_assets if total_assets > 0 else None)
            _locale.dataframe(st, uc.head(30), width='stretch', hide_index=True)
            dims = st.tabs(['업종', '국가', '통화', '투자 요인'])
            for tab, dim in zip(dims, ['sector', 'country', 'currency', 'factor']):
                with tab:
                    ex = exposure_summary(lt, dim, total_assets if total_assets > 0 else None)
                    _locale.dataframe(st, ex, width='stretch', hide_index=True)
                    if not ex.empty:
                        st.bar_chart(ex.set_index(dim)['portfolio_weight'])
            with st.expander('전체 실질 구성자산 분석 행'):
                _locale.dataframe(st, lt, width='stretch', hide_index=True)
    with tab3:
        ov = pairwise_etf_overlap(holdings)
        if ov.empty:
            st.info('비교할 상장지수펀드 보유 내역이 2개 이상 필요합니다.')
        else:
            _locale.dataframe(st, ov, width='stretch', hide_index=True)
            st.caption('중복 = 동일 기초자산의 최소(A 비중, B 비중) 합계입니다.')
