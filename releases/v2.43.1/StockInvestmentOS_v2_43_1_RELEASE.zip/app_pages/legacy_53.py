from __future__ import annotations
import ui_locale as _locale
if True:
    st.title(f'투자 근거 일괄 검토 / {VERSION}')
    st.caption('관심종목 · 데이터 품질 · 승인됨 투자 근거 · 전자공시 후보를 한 화면에서 연결해 반복 이동을 줄이는 사용자 검토 작업 화면입니다.')
    st.info('이 화면은 검토 순서와 근거를 한곳에 모읍니다. 투자 근거 승인, 관심종목 근거 상태, 차환 조건, 투자 가설, 투자 단계, 추가 투자 보류, 시나리오, 포트폴리오는 자동 변경하지 않습니다.')
    batch_packets = normalize_evidence_packets(load_csv('evidence_packets.csv'))
    batch_enriched_packets = enrich_evidence_packets(batch_packets)
    batch_candidates = normalize_source_candidates(load_csv('source_candidates.csv'))
    batch_data_quality = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    batch_queue = build_evidence_batch_queue(watchlist=watchlist, evidence_packets=batch_enriched_packets, source_candidates=batch_candidates, data_quality=batch_data_quality)
    batch_summary = evidence_batch_summary(batch_queue)
    st.subheader('1. 투자 근거 검토 대기 목록')
    b1, b2, b3, b4, b5, b6 = st.columns(6)
    b1.metric('관심종목', _locale.code(batch_summary['total']))
    b2.metric('행동 필요한', _locale.code(batch_summary['action_needed']))
    b3.metric('승인됨 없음', _locale.code(batch_summary['approved_missing']))
    b4.metric('차환 검토', _locale.code(batch_summary['refinancing_review']))
    b5.metric('투자 근거 상태 검토', _locale.code(batch_summary['evidence_status_review']))
    b6.metric('높은 우선순위 검토 대기', _locale.code(batch_summary['high_open_candidates']))
    st.caption(f"진행 중 후보 {batch_summary['open_candidates']}개 · 높음 후보가 있는 종목 {batch_summary['high_open_companies']}개 · 데이터 품질 검토/차단됨 {batch_summary['data_quality_review']}개 · 오래됨/기한 초과 {batch_summary['overdue_or_stale']}개")
    st.caption('우선순위는 투자 매력도 점수가 아닙니다. P0→P4는 데이터 무결성·투자 근거 검토의 운영 순서일 뿐이며 매수/매도 판단을 의미하지 않습니다.')
    if batch_queue.empty:
        st.warning('관심종목이 비어 있거나 일괄 검토 대기 목록을 만들 수 없습니다.')
    else:
        queue_view_cols = ['priority', 'company', 'primary_workstream', 'pending_gates', 'data_quality', 'refinancing_gate', 'evidence_status', 'approved_packet', 'latest_event_date', 'freshness_status', 'hash_status', 'open_candidates', 'high_open_candidates', 'next_action', 'issues']
        _locale.dataframe(st, batch_queue[[c for c in queue_view_cols if c in batch_queue.columns]], width='stretch', hide_index=True)
        st.subheader('2. 업무 영역별 검토')
        lane_labels = {f"Evidence Packet 없음 · {batch_summary['approved_missing']}": 'MISSING_PACKET', f"Refinancing 검토 · {batch_summary['refinancing_review']}": 'REFINANCING', f"Evidence Status 검토 · {batch_summary['evidence_status_review']}": 'EVIDENCE_STATUS', f"HIGH 신규공시 · {batch_summary['high_open_companies']}종목 / {batch_summary['high_open_candidates']}건": 'HIGH_DISCLOSURE', f"Data Quality REVIEW/BLOCKED · {batch_summary['data_quality_review']}": 'DATA_QUALITY', f"전체 Action Needed · {batch_summary['action_needed']}": 'ACTION_NEEDED', f"전체 Watchlist · {batch_summary['total']}": 'ALL'}
        lane_label = st.radio('검토할 작업 묶음', list(lane_labels.keys()), horizontal=True, key='evidence_batch_lane')
        lane = lane_labels[lane_label]
        lane_queue = filter_evidence_batch_queue(batch_queue, lane)
        st.caption('검토 종목 목록은 현재 선택한 업무 영역에 포함된 종목만 보여줍니다. 삼성전자처럼 승인됨 투자 근거가 있는 종목을 테스트하려면 `전체 Watchlist`를 선택하세요.')
        if lane_queue.empty:
            st.success('이 업무 영역에는 현재 처리할 종목이 없습니다.')
        else:
            batch_names = lane_queue['company'].fillna('').astype(str).tolist()
            current_widget_company = str(st.session_state.get('evidence_batch_company_select', '') or '').strip()
            if current_widget_company not in batch_names:
                st.session_state['evidence_batch_company_select'] = batch_names[0]
            batch_company = st.selectbox('검토 종목', batch_names, key='evidence_batch_company_select')
            st.session_state['evidence_batch_company'] = batch_company
            batch_hit = batch_queue.loc[batch_queue['company'].fillna('').astype(str).eq(batch_company)]
            batch_row = batch_hit.iloc[0].to_dict() if not batch_hit.empty else {}
            q1, q2, q3, q4, q5, q6 = st.columns(6)
            q1.metric('우선순위', _locale.code(batch_row.get('priority', '-') or '-'))
            q2.metric('데이터 품질', _locale.code(batch_row.get('data_quality', '-') or '-'))
            q3.metric('승인됨', _locale.code(batch_row.get('approved_packet', '-') or '-'))
            q4.metric('차환', _locale.code(batch_row.get('refinancing_gate', '-') or '-'))
            q5.metric('투자 근거', _locale.code(batch_row.get('evidence_status', '-') or '-'))
            q6.metric('높은 우선순위 검토 대기', _locale.code(int(batch_row.get('high_open_candidates', 0) or 0)))
            pending_gates = int(batch_row.get('pending_gates', 0) or 0)
            if pending_gates:
                st.warning(f"현재 사용자 검토 점검 {pending_gates}개 · {batch_row.get('workstreams', '-') or '-'}")
            else:
                st.success('현재 일괄 검토 점검이 모두 정리되어 정기 모니터링 상태입니다.')
            st.write(f"**다음 작업:** {batch_row.get('next_action', '-') or '-'}")
            if str(batch_row.get('issues', '') or '').strip():
                st.caption('확인 항목 · ' + str(batch_row.get('issues', '') or ''))
            latest_source_title = str(batch_row.get('latest_source_title', '') or '').strip()
            latest_source_url = str(batch_row.get('latest_source_url', '') or '').strip()
            if str(batch_row.get('approved_packet', '') or '').upper() == 'YES':
                st.markdown('**최신 승인된 투자 근거**')
                src_line = f"{batch_row.get('latest_event_date', '') or '-'} · {latest_source_title or '-'}"
                st.write(src_line)
                if latest_source_url:
                    st.markdown(f'[승인됨 투자 근거 원문 열기]({latest_source_url})')
                with st.expander('승인됨 투자 근거 내용 확인', expanded=False):
                    st.markdown('**사실**')
                    st.write(batch_row.get('latest_fact', '') or '-')
                    st.markdown('**해석**')
                    st.write(batch_row.get('latest_interpretation', '') or '-')
                    st.markdown('**반대 근거**')
                    st.write(batch_row.get('latest_contrary_evidence', '') or '-')
                    st.markdown('**다음 확인 근거**')
                    st.write(batch_row.get('latest_next_proof', '') or '-')
            n1, n2, n3, n4 = st.columns(4)
            n1.button('투자 근거 등록 열기', on_click=_navigate, args=('Evidence Intake', {'evidence_intake_company': batch_company}), key=f'batch_to_evidence::{batch_company}')
            n2.button('투자 상태 열기', on_click=_navigate, args=('Investment State', {'state_machine_company': batch_company, 'state_edit_company': batch_company}), key=f'batch_to_state::{batch_company}')
            n3.button('데이터 품질 열기', on_click=_navigate, args=('Data Quality',), key=f'batch_to_dq::{batch_company}')
            n4.button('공식 원문 점검 열기', on_click=_navigate, args=('Primary Source Monitor', {'source_monitor_filter': 'OPEN'}), key=f'batch_to_source::{batch_company}')
            st.subheader('3. 후보 집중 검토')
            all_batch_open = company_open_candidates(batch_candidates, batch_company, high_only=False)
            high_batch_open = company_open_candidates(batch_candidates, batch_company, high_only=True)
            scope_options = ['HIGH 먼저', '모든 Open']
            scope_default = 0 if not high_batch_open.empty else 1
            batch_candidate_scope = st.radio('후보 범위', scope_options, index=scope_default, horizontal=True, key=f'batch_candidate_scope::{batch_company}')
            batch_open = high_batch_open if batch_candidate_scope == 'HIGH 먼저' else all_batch_open
            if batch_candidate_scope == 'HIGH 먼저' and high_batch_open.empty:
                st.info('현재 높음 후보가 없어 모든 진행 중 후보를 표시합니다.')
                batch_open = all_batch_open
            if batch_open.empty:
                st.success('현재 이 종목의 신규 / 검토 중 후보가 없습니다. 필요하면 공식 원문 점검에서 관심종목 전자공시 조회를 실행하세요.')
            else:
                batch_candidate_cols = ['receipt_date', 'company', 'report_name', 'category', 'monitor_priority', 'candidate_status', 'attention_status', 'source_hash_status', 'days_open']
                _locale.dataframe(st, batch_open[[c for c in batch_candidate_cols if c in batch_open.columns]], width='stretch', hide_index=True)
                st.caption('표의 첫 행이 현재 범위에서 먼저 확인할 공시입니다. 이는 투자판단 우선순위가 아니라 출처 검토 운영 순서입니다.')
                batch_candidate_labels = []
                batch_candidate_lookup = {}
                for _, _r in batch_open.iterrows():
                    _cid = str(_r.get('candidate_id', '') or '')
                    _label = f"[{_r.get('candidate_status', '')}] [{_r.get('monitor_priority', '')}] {_r.get('receipt_date', '')} · {_r.get('report_name', '')} · {(_cid[-8:] if _cid else '-')}"
                    batch_candidate_labels.append(_label)
                    batch_candidate_lookup[_label] = _r.to_dict()
                batch_selected_label = st.selectbox('검토 후보', batch_candidate_labels, key=f'batch_candidate::{batch_company}')
                batch_selected_candidate = batch_candidate_lookup[batch_selected_label]
                _batch_source_url = str(batch_selected_candidate.get('source_url', '') or '').strip()
                _batch_hash = str(batch_selected_candidate.get('source_hash_status', '') or '').strip().upper()
                _batch_candidate_id = str(batch_selected_candidate.get('candidate_id', '') or '').strip()
                _batch_status = str(batch_selected_candidate.get('candidate_status', '') or '').strip().upper()
                c1, c2, c3, c4 = st.columns(4)
                c1.metric('상태', _locale.code(_batch_status or '-'))
                c2.metric('우선순위', _locale.code(str(batch_selected_candidate.get('monitor_priority', '') or '-')))
                c3.metric('분류', _locale.code(str(batch_selected_candidate.get('category', '') or '-')))
                c4.metric('무결성 해시', _locale.code(_batch_hash or '-'))
                st.write(f"**검토 이유:** {batch_selected_candidate.get('relevance_reason', '') or '-'}")
                _batch_guide = candidate_review_guide(batch_selected_candidate)
                with st.expander('투자 근거 초안 입력 보조 · 원문 확인 체크리스트', expanded=True):
                    st.warning(_locale.message(_batch_guide['warning']))
                    st.caption(f"양식 유형: {_batch_guide['guide_type']} · 범위: {_batch_guide['scope']}")
                    for _q in _batch_guide['review_questions']:
                        st.write(f'- {_q}')
                    if _batch_guide.get('linked_kpi_suggestion'):
                        st.caption('연결됨 핵심 성과 지표 제안 · ' + _batch_guide['linked_kpi_suggestion'])
                    st.caption('다음 확인 근거 제안 · ' + _batch_guide['next_proof_suggestion'])
                if _batch_hash and _batch_hash not in {'OK', 'PASS'}:
                    st.error(f'출처 후보 무결성 해시 = {_batch_hash}. 투자 근거 등록 전달 전에 공식 원문 점검에서 무결성을 확인하세요.')
                if not _batch_source_url:
                    st.warning('선택 후보의 출처 주소가 없습니다. 공식 원문 점검에서 실제 전자공시를 다시 조회해 주소를 복구하세요.')
                    st.button('출처 점검에서 주소 복구', on_click=_navigate, args=('Primary Source Monitor', {'source_monitor_filter': 'OPEN'}), key=f'batch_repair_source::{batch_company}')
                else:
                    st.markdown(f'[선택 후보 전자공시 원문 열기]({_batch_source_url})')
                    h1, h2 = st.columns(2)
                    h1.button('선택 후보 → 투자 근거 등록 전달', type='primary', on_click=_source_candidate_handoff_callback, args=(batch_selected_candidate, batch_candidates), key=f'batch_handoff::{batch_company}::{_batch_candidate_id}', disabled=bool(_batch_hash and _batch_hash not in {'OK', 'PASS'}))
                    with h2:
                        st.caption('투자 근거가 불필요한 공시는 아래에서 이유를 남기고 종료할 수 있습니다.')
                    with st.expander('이 후보를 투자 근거 불필요로 종료', expanded=False):
                        dismiss_reason = st.text_input('검토 제외 사유', value='', key=f'batch_dismiss_reason::{_batch_candidate_id}', placeholder='예: 정기 지분공시로 기존 투자 가설/가치 평가/생존 가정에 신규 정보 없음')
                        dismiss_confirm = st.checkbox('전자공시 원문을 직접 확인했고 투자 근거 자료로 만들 필요가 없는 이유를 기록했습니다.', key=f'batch_dismiss_confirm::{_batch_candidate_id}')
                        dismiss_ready = bool(_batch_candidate_id and _batch_source_url and (_batch_hash in {'OK', 'PASS'}) and (len(str(dismiss_reason).strip()) >= 10) and dismiss_confirm)
                        if st.button('검토 완료 · 검토 제외 저장', key=f'batch_dismiss::{_batch_candidate_id}', disabled=not dismiss_ready):
                            try:
                                updated_candidates = mark_candidate_status(batch_candidates, _batch_candidate_id, 'DISMISSED', dismissed_reason=str(dismiss_reason).strip())
                                save_csv(updated_candidates, 'source_candidates.csv')
                                st.session_state['_save_flash'] = ('success', 'Source Candidate를 DISMISSED로 저장했습니다. 다음 Candidate를 계속 검토하세요.')
                                st.rerun()
                            except Exception as e:
                                st.error(f'후보 종료 실패: {e}')
            st.subheader('4. 다음 종목')
            current_pos = batch_names.index(batch_company)
            next_company = batch_names[(current_pos + 1) % len(batch_names)] if len(batch_names) > 1 else batch_company
            next_col1, next_col2 = st.columns([1, 3])
            if next_col1.button(f'다음 종목 → {next_company}', key=f'batch_next_company::{lane}::{batch_company}', disabled=len(batch_names) <= 1):
                st.session_state['evidence_batch_company_select'] = next_company
                st.session_state['evidence_batch_company'] = next_company
                st.rerun()
            next_col2.caption('업무 영역 안에서 다음 종목으로 이동합니다. 상태값은 자동 변경하지 않습니다.')
        st.subheader('5. 일괄 검토 원칙')
        st.write('- 공시 제목은 사실이 아닙니다. 원문을 확인한 뒤 사실을 작성합니다.\n- 후보 검토 제외는 원문 확인 + 구체적 이유 기록이 있어야 저장됩니다.\n- 승인됨 투자 근거가 있어도 관심종목 근거 상태를 자동 정상으로 바꾸지 않습니다.\n- 간접 자료 기준 통과는 확정 정상이 아니므로 차환 근거를 별도 검토합니다.\n- 신규 투자 근거가 기존 투자 가설과 충돌하면 새 개정과 영향 검토를 남깁니다.')
