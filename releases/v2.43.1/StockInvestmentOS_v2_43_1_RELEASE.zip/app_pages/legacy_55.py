from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('근거 영향 검토 / 판단 연결')
    st.caption('최신 승인된 투자 근거를 투자 가설 · 가치 평가 · 추가 투자 보류 · 투자 단계 · 시나리오 · 포트폴리오 위험과 명시적으로 연결해서 검토합니다.')
    st.info('이 화면은 행동 후보를 구조화하는 감사기록입니다. 승인됨을 눌러도 관심종목, 투자 단계, 추가 투자 보류, 시나리오, 기준 원장 투자 가정, 포트폴리오를 자동 변경하지 않습니다. 실제 변경은 각 원본 화면에서 별도 검토합니다.')
    impact_evidence_packets = normalize_evidence_packets(load_csv('evidence_packets.csv'))
    impact_reviews = normalize_impact_reviews(load_csv('evidence_impact_reviews.csv'))
    if watchlist.empty:
        st.warning('관심종목이 비어 있습니다.')
    else:
        impact_names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        handed_company = str(st.session_state.get('evidence_impact_company', '') or '').strip()
        impact_default = impact_names.index(handed_company) if handed_company in impact_names else 0
        impact_company = st.selectbox('영향 검토 종목', impact_names, index=impact_default, key='evidence_impact_company_select')
        st.session_state['evidence_impact_company'] = impact_company
        source_packet = latest_approved_packet(impact_evidence_packets, impact_company)
        current_impact_status = evidence_impact_status(impact_evidence_packets, impact_reviews, impact_company)
        st.subheader('1. 최신 승인된 투자 근거 상태 기록')
        if not source_packet:
            st.info('승인됨 투자 근거 자료가 없습니다. 먼저 투자 근거 등록에서 공식 원문 출처를 검토하세요.')
            st.button('투자 근거 등록으로 이동', on_click=_navigate, args=('Evidence Intake', {'evidence_intake_company': impact_company}), key=f'impact_to_intake_empty::{impact_company}')
        else:
            s1, s2, s3, s4, s5 = st.columns(5)
            s1.metric('기록', _locale.code(str(source_packet.get('event_date', '') or '-')))
            s2.metric('신호', _locale.code(str(source_packet.get('evidence_signal', '') or '-')))
            s3.metric('출처 등급', _locale.code(str(source_packet.get('source_tier', '') or '-')))
            s4.metric('최신성', _locale.code(str(source_packet.get('freshness_status', '') or '-')))
            s5.metric('무결성 해시', _locale.code(str(source_packet.get('hash_status', '') or '-')))
            st.write(f"**출처:** {source_packet.get('source_title', '')}")
            fact_text = str(source_packet.get('fact_summary', '') or '').strip()
            if fact_text:
                st.write(f'**사실:** {fact_text}')
            interpretation_text = str(source_packet.get('investment_interpretation', '') or '').strip()
            if interpretation_text:
                st.write(f'**투자 근거 해석:** {interpretation_text}')
            contrary_text = str(source_packet.get('contrary_evidence', '') or '').strip()
            if contrary_text:
                st.write(f'**기존 반대 근거:** {contrary_text}')
            if str(source_packet.get('hash_status', '')).upper() != 'OK':
                st.error('원 투자 근거 자료의 무결성 해시 무결성이 정상이 아닙니다. 영향 검토 저장보다 투자 근거 등록 무결성 확인을 먼저 하세요.')
            st.subheader('1-1. 이전 승인됨 대비 변화')
            previous_packet = previous_approved_packet(impact_evidence_packets, impact_company, str(source_packet.get('evidence_id', '') or ''))
            if not previous_packet:
                st.info('이전 승인됨 투자 근거가 없습니다. 현재 자료 묶음이 영향 검토의 첫 기준 상태입니다.')
            else:
                impact_diff = build_evidence_diff(previous_packet, source_packet)
                pd1, pd2, pd3 = st.columns(3)
                pd1.metric('이전 승인됨', _locale.code(str(previous_packet.get('event_date', '') or '-')))
                pd2.metric('변경됨 문장 항목', _locale.code(impact_diff['changed_fields']))
                pd3.metric('현재 신호', _locale.code(str(source_packet.get('evidence_signal', '') or '-')))
                _locale.dataframe(st, impact_diff['metadata'], width='stretch', hide_index=True)
                _locale.dataframe(st, impact_diff['summary'], width='stretch', hide_index=True)
                st.caption('이 변경 비교는 문자 변화의 감사 보조도구입니다. 투자 가설 강화/약화, 가치 평가 수정, 추가 투자 보류, 투자 단계, 포트폴리오 행동은 아래에서 사람이 별도로 판단합니다.')
            st.subheader('2. 현재 영향 검토 상태')
            impact_state = current_impact_status.get('status', '-')
            c1, c2, c3, c4 = st.columns(4)
            c1.metric('영향 상태', _locale.code(impact_state))
            c2.metric('투자 가설', _locale.code(current_impact_status.get('thesis_impact', '') or '-'))
            c3.metric('가치 평가', _locale.code(current_impact_status.get('valuation_action', '') or '-'))
            c4.metric('시나리오', _locale.code(current_impact_status.get('scenario_action', '') or '-'))
            if impact_state == 'REVIEWED':
                st.success('최신 승인된 투자 근거에 대한 영향 검토가 완료되어 있습니다.')
            elif impact_state == 'REVIEW REQUIRED':
                st.warning('최신 승인된 투자 근거의 투자영향 검토가 아직 완료되지 않았습니다.')
            else:
                st.error(f'영향 상태 = {_locale.code(impact_state)}. 무결성 해시/출처 연결을 먼저 확인하세요.')
            st.subheader('3. 새 근거 영향 검토')
            r1, r2 = st.columns(2)
            thesis_impact = r1.selectbox('투자 가설 영향', THESIS_IMPACTS, index=THESIS_IMPACTS.index('UNCHANGED'), key=f'impact_thesis::{impact_company}', help='투자 근거 신호와 동일할 필요는 없습니다. 사실이 장기 투자 가설에 미치는 영향을 별도로 판단합니다.')
            valuation_action = r2.selectbox('가치 평가 행동', VALUATION_ACTIONS, index=VALUATION_ACTIONS.index('NO CHANGE'), key=f'impact_valuation::{impact_company}')
            r3, r4 = st.columns(2)
            add_freeze_action = r3.selectbox('추가 투자 보류 검토', ADD_FREEZE_ACTIONS, index=ADD_FREEZE_ACTIONS.index('KEEP CURRENT'), key=f'impact_add_freeze::{impact_company}')
            lifecycle_action = r4.selectbox('투자 단계 검토', LIFECYCLE_ACTIONS, index=LIFECYCLE_ACTIONS.index('KEEP CURRENT'), key=f'impact_lifecycle::{impact_company}')
            r5, r6 = st.columns(2)
            scenario_action = r5.selectbox('시나리오 행동', SCENARIO_ACTIONS, index=SCENARIO_ACTIONS.index('NO REFRESH'), key=f'impact_scenario::{impact_company}')
            portfolio_action = r6.selectbox('포트폴리오 위험 행동', PORTFOLIO_ACTIONS, index=PORTFOLIO_ACTIONS.index('NO CHANGE'), key=f'impact_portfolio::{impact_company}')
            strongest_counter_case = st.text_area('가장 강한 반대 가설', value='', key=f'impact_counter::{impact_company}', placeholder='이번 투자 근거가 긍정적/부정적으로 보이더라도 현재 해석이 틀릴 수 있는 가장 강한 반대 가설을 독립적으로 적습니다.')
            rationale = st.text_area('근거', value='', key=f'impact_rationale::{impact_company}', placeholder='왜 투자 가설 / 가치 평가 / 위험 행동을 이렇게 분류했는지 사실과 해석을 구분해서 적습니다.')
            next_action = st.text_area('다음 검토 행동', value='', key=f'impact_next_action::{impact_company}', placeholder='예: 추가 투자 보류 유지. 3분기 영업현금흐름/잉여현금흐름 확인 후 시나리오 새로 읽기 재검토.')
            preview_review = {'evidence_id': source_packet.get('evidence_id', ''), 'evidence_content_hash_snapshot': source_packet.get('content_hash', ''), 'company': impact_company, 'ticker': source_packet.get('ticker', ''), 'evidence_event_date': source_packet.get('event_date', ''), 'evidence_signal': source_packet.get('evidence_signal', ''), 'thesis_impact': thesis_impact, 'valuation_action': valuation_action, 'add_freeze_action': add_freeze_action, 'lifecycle_action': lifecycle_action, 'scenario_action': scenario_action, 'portfolio_action': portfolio_action, 'strongest_counter_case': strongest_counter_case, 'rationale': rationale, 'next_action': next_action}
            draft_validation = validate_impact_review(preview_review, for_approval=False)
            approval_validation = validate_impact_review(preview_review, for_approval=True)
            st.subheader('4. 승인 점검')
            g1, g2, g3 = st.columns(3)
            g1.metric('초안 점검', _locale.code('정상' if draft_validation['valid'] else '검토'))
            g2.metric('승인 점검', _locale.code('정상' if approval_validation['valid'] else '검토'))
            g3.metric('출처 연결', _locale.code('정상' if str(source_packet.get('hash_status', '')).upper() == 'OK' else '검토'))
            if not approval_validation['valid']:
                st.warning(_locale.message('승인됨 전 확인: ' + ' / '.join(approval_validation['issues'])))
            reviewed = st.checkbox('투자 근거 상태 기록과 투자 가설 / 가치 평가 / 위험 영향, 가장 강한 반대 가설, 다음 검토 행동을 직접 검토했습니다.', value=False, key=f'impact_reviewed::{impact_company}')
            target_status = 'APPROVED' if reviewed else 'DRAFT'
            st.write(f'저장 상태: **{_locale.code(target_status)}** · 이 저장은 원본 투자 상태를 자동 변경하지 않습니다.')
            if st.button('새 근거 영향 검토 저장', type='primary', key=f'save_evidence_impact::{impact_company}'):
                if str(source_packet.get('hash_status', '')).upper() != 'OK':
                    st.error('원 투자 근거 자료의 무결성 해시 무결성이 정상이 아니므로 영향 검토 저장을 중단했습니다.')
                else:
                    try:
                        review_row = build_evidence_impact_review(evidence_packet=source_packet, thesis_impact=thesis_impact, valuation_action=valuation_action, add_freeze_action=add_freeze_action, lifecycle_action=lifecycle_action, scenario_action=scenario_action, portfolio_action=portfolio_action, strongest_counter_case=strongest_counter_case, rationale=rationale, next_action=next_action, review_status=target_status)
                        updated_reviews = pd.concat([impact_reviews[IMPACT_REVIEW_COLS], pd.DataFrame([review_row])], ignore_index=True)
                        _impact_saved = verified_save_feedback(updated_reviews, 'evidence_impact_reviews.csv', f'Evidence Impact Review를 {target_status} 상태로 저장했습니다.', rerun=False)
                        if _impact_saved:
                            if target_status == 'APPROVED':
                                _bridge = st.session_state.get('_evidence_impact_bridge', {})
                                if isinstance(_bridge, dict) and str(_bridge.get('company', '') or '').strip() == impact_company and (str(_bridge.get('evidence_id', '') or '').strip() == str(source_packet.get('evidence_id', '') or '').strip()):
                                    st.session_state.pop('_evidence_impact_bridge', None)
                            st.rerun()
                    except Exception as e:
                        st.error(f'근거 영향 검토 저장 실패: {e}')
            st.subheader('5. 영향 검토 이력')
            impact_history = enrich_impact_reviews(impact_reviews, impact_evidence_packets)
            if impact_history.empty:
                st.info('아직 영향 검토 기록이 없습니다.')
            else:
                company_history = impact_history.loc[impact_history['company'].fillna('').astype(str).eq(impact_company)].copy()
                if company_history.empty:
                    st.info('이 종목의 영향 검토 기록이 없습니다.')
                else:
                    history_cols = ['created_at', 'review_status', 'evidence_event_date', 'evidence_signal', 'thesis_impact', 'valuation_action', 'add_freeze_action', 'lifecycle_action', 'scenario_action', 'portfolio_action', 'hash_status', 'link_status', 'next_action']
                    _locale.dataframe(st, company_history[[c for c in history_cols if c in company_history.columns]].tail(50), width='stretch', hide_index=True)
            st.subheader('6. 원본 실행 화면')
            b1, b2, b3 = st.columns(3)
            b1.button('투자 가설 점검', on_click=_navigate, args=('Thesis Monitor',), key=f'impact_to_thesis::{impact_company}')
            b2.button('시나리오 새로 읽기', on_click=_navigate, args=('Scenario Refresh',), key=f'impact_to_scenario::{impact_company}')
            b3.button('판단 요약', on_click=_navigate, args=('Decision Summary',), key=f'impact_to_decision::{impact_company}')
    st.caption('근거 영향 검토는 투자 근거와 행동 사이의 사용자 검토 검토 단계입니다. 좋은 투자 근거 ≠ 자동 매수, 나쁜 투자 근거 ≠ 자동 매도입니다.')
