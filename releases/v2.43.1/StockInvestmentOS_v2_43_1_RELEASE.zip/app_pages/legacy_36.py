from __future__ import annotations
import ui_locale as _locale
if True:
    st.title(f'손실위험자본 집중도 보완 / {VERSION}')
    st.caption('포트폴리오 직접 하락 시나리오 손실 위험 자본 집중을 수학적으로 복구하는 가정별 분석 작업 화면입니다.')
    st.info('이 화면은 매도 우선순위나 자동 주문을 만들지 않습니다. 비교 기준은 상위 손실위험자본 비중 상한을 복구하기 위한 수학적 비교선이며 실제 축소는 투자 가설 / 가치 평가 / 세금 / 유동성 / 기회 비용을 별도로 검토해야 합니다.')
    car_policy_cap = float(settings.get('top_car_share_review_cap', 0.5))
    car_contrib = direct_car_contributions(portfolio, total_assets)
    car_state = car_concentration_state(car_contrib, top_share_cap=car_policy_cap)
    st.subheader('1. 현재 손실위험자본 집중도')
    cc1, cc2, cc3, cc4, cc5 = st.columns(5)
    cc1.metric('직접 하락 시나리오 손실', _locale.code(pct(car_state['direct_bear_loss'])))
    cc2.metric('상위 손실위험자본 비중', _locale.code(pct(car_state['top_car_share'])))
    cc3.metric('상위 기여 자산', _locale.code(car_state['top_name'] or '-'))
    cc4.metric('위험 집중도 지수', f"{car_state['risk_hhi']:.4f}")
    cc5.metric('집중도 점검', _locale.code(car_state['status']))
    st.caption(f'정책 상위 손실위험자본 비중 상한 = {car_policy_cap:.1%}. 이 상한은 투자 매력도가 아니라 포트폴리오 하락 시나리오-위험 집중도 운영 기준입니다.')
    if car_contrib.empty:
        st.info('직접 손실위험자본 기여 자산이 없습니다.')
    else:
        car_view = car_contrib.copy()
        for _c in ['weight', 'bear_downside', 'car_weight', 'direct_car_share']:
            car_view[_c] = pd.to_numeric(car_view[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
        car_view['current_value_krw'] = pd.to_numeric(car_view['current_value_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
        _locale.dataframe(st, car_view, width='stretch', hide_index=True)
    car_benchmark = minimum_car_concentration_repair(car_contrib, total_assets, top_share_cap=car_policy_cap)
    st.subheader('2. 최소 손실위험자본 집중도 보완 비교 기준')
    st.caption('모든 축소대금이 현금으로 이동한다고 가정하고, 모든 직접 손실위험자본 비중을 상한 이내로 만들면서 남는 총 손실위험자본을 최대화하는 수학적 하한-연결됨입니다.')
    cb1, cb2, cb3, cb4, cb5 = st.columns(5)
    cb1.metric('비교 기준 비중 축소', _locale.code(krw(car_benchmark['total_trim_krw'])))
    cb2.metric('비중 축소 / 자산', _locale.code(pct(car_benchmark['total_trim_weight'])))
    cb3.metric('자금 제공 자산 건수', _locale.code(car_benchmark['donor_count']))
    cb4.metric('사후 상위 손실위험자본 비중', _locale.code(pct(car_benchmark['post_state']['top_car_share'])))
    cb5.metric('비교 기준 상태', _locale.code(car_benchmark['status']))
    if car_benchmark['status'] == 'CAP_RESTORED':
        st.success(_locale.message(car_benchmark['detail']))
    elif car_benchmark['status'] == 'NO_REPAIR_REQUIRED':
        st.info(_locale.message(car_benchmark['detail']))
    else:
        st.warning(_locale.message(car_benchmark['detail']))
    benchmark_plan = car_benchmark.get('plan', pd.DataFrame()).copy()
    if not benchmark_plan.empty:
        positive_benchmark = benchmark_plan.loc[pd.to_numeric(benchmark_plan['trim_amount_krw'], errors='coerce').fillna(0.0).gt(1e-09)].copy()
        if not positive_benchmark.empty:
            benchmark_show = positive_benchmark.copy()
            for _c in ['weight', 'bear_downside', 'direct_car_share', 'target_car_weight', 'trim_car_weight', 'post_car_weight', 'post_car_share', 'trim_pct_of_position']:
                if _c in benchmark_show.columns:
                    benchmark_show[_c] = pd.to_numeric(benchmark_show[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            for _c in ['current_value_krw', 'trim_amount_krw', 'post_value_krw']:
                if _c in benchmark_show.columns:
                    benchmark_show[_c] = pd.to_numeric(benchmark_show[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            _locale.dataframe(st, benchmark_show, width='stretch', hide_index=True)
    st.subheader('3. 보완 시나리오')
    car_template = st.radio('시작 템플릿', ['Minimum CAR Concentration Repair Benchmark', '직접 입력'], horizontal=True, key='car_concentration_repair_template', format_func=_locale.option())
    editor_cols = ['name', 'ticker', 'current_value_krw', 'weight', 'bear_downside', 'car_weight', 'direct_car_share', 'trim_amount_krw']
    if car_template == 'Minimum CAR Concentration Repair Benchmark':
        if benchmark_plan.empty:
            car_edited = pd.DataFrame(columns=editor_cols)
        else:
            car_edited = benchmark_plan[editor_cols].copy()
            car_display = car_edited.copy()
            for _c in ['weight', 'bear_downside', 'car_weight', 'direct_car_share']:
                car_display[_c] = pd.to_numeric(car_display[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            for _c in ['current_value_krw', 'trim_amount_krw']:
                car_display[_c] = pd.to_numeric(car_display[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            _locale.dataframe(st, car_display, width='stretch', hide_index=True)
            st.caption('비교 기준 모드는 계산값을 그대로 사용합니다. 금액을 바꾸려면 `직접 입력`을 선택하세요.')
    else:
        manual_seed = car_contrib.copy()
        manual_seed['trim_amount_krw'] = 0.0
        car_edited = _locale.editor(st, manual_seed[editor_cols], width='stretch', hide_index=True, disabled=[c for c in editor_cols if c != 'trim_amount_krw'], column_config={'trim_amount_krw': st.column_config.NumberColumn('가상 축소금액(원화)', min_value=0.0, step=10000.0, format='%.0f'), 'current_value_krw': st.column_config.NumberColumn('현재 가치(원화)', format='%.0f')}, key='car_concentration_manual_editor')
    car_sim = simulate_car_concentration_repair(portfolio, total_assets, car_edited, top_share_cap=car_policy_cap)
    st.subheader('4. 모의검증 결과')
    cs1, cs2, cs3, cs4, cs5 = st.columns(5)
    cs1.metric('합계 비중 축소', _locale.code(krw(car_sim['total_trim_krw'])))
    cs2.metric('사후 직접 하락 시나리오 손실', _locale.code(pct(car_sim['post_state']['direct_bear_loss'])))
    cs3.metric('손실위험자본 완화', _locale.code('-' + pct(car_sim['car_reduction'])))
    cs4.metric('사후 상위 손실위험자본 비중', _locale.code(pct(car_sim['post_state']['top_car_share'])))
    cs5.metric('보완 상태', _locale.code(car_sim['repair_status']))
    if car_sim['repair_status'] == 'CAP_RESTORED':
        st.success('상위 손실위험자본 비중 상한이 수학적으로 복구됩니다. 실행 전 자금 제공 자산별 향후 판단을 별도로 검토하세요.')
    elif car_sim['repair_status'] == 'PARTIAL_REPAIR':
        st.warning('집중위험은 감소하지만 상위 손실위험자본 비중 상한은 아직 복구되지 않습니다.')
    elif car_sim['repair_status'] == 'NO_REPAIR_REQUIRED':
        st.info('현재 상한 기준으로 추가 보완이 필요하지 않습니다.')
    else:
        st.info('현재 입력안은 집중도 상태를 변경하지 않습니다.')
    sim_plan = car_sim.get('effective_plan', pd.DataFrame()).copy()
    positive_plan = pd.DataFrame()
    if not sim_plan.empty:
        positive_plan = sim_plan.loc[pd.to_numeric(sim_plan['effective_trim_krw'], errors='coerce').fillna(0.0).gt(1e-09)].copy()
        if not positive_plan.empty:
            sim_show = positive_plan.copy()
            for _c in ['weight', 'bear_downside', 'direct_car_share', 'post_weight', 'post_car_weight', 'post_car_share', 'trim_pct_of_position']:
                if _c in sim_show.columns:
                    sim_show[_c] = pd.to_numeric(sim_show[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            for _c in ['current_value_krw', 'effective_trim_krw', 'post_value_krw']:
                if _c in sim_show.columns:
                    sim_show[_c] = pd.to_numeric(sim_show[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            _locale.dataframe(st, sim_show, width='stretch', hide_index=True)
    st.subheader('5. 일부 체결 보완 단계별 분석')
    st.caption('비교 기준 비중 축소의 0% → 25% → 50% → 75% → 100%를 같은 비율로 적용해 직접 하락 시나리오 손실과 상위 손실위험자본 비중 변화를 보여주는 진단표입니다. 어느 행도 실행 추천값이 아닙니다.')
    car_fraction_ladder = benchmark_fraction_ladder(portfolio, total_assets, benchmark_plan, top_share_cap=car_policy_cap)
    if car_fraction_ladder.empty:
        st.info('일부 체결 보완 단계별 분석을 만들 비교 기준이 없습니다.')
    else:
        ladder_show = car_fraction_ladder.copy()
        ladder_show['benchmark_fraction'] = pd.to_numeric(ladder_show['benchmark_fraction'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.0%}')
        for _c in ['total_trim_weight', 'post_direct_bear_loss', 'car_reduction', 'post_top_car_share']:
            ladder_show[_c] = pd.to_numeric(ladder_show[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
        ladder_show['total_trim_krw'] = pd.to_numeric(ladder_show['total_trim_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
        _locale.dataframe(st, ladder_show, width='stretch', hide_index=True)
    st.subheader('6. 주문 단위 실행 실행 가능성')
    st.caption('연속적인 원화 비교 기준은 실제 보유수량 단위와 정확히 일치하지 않을 수 있습니다. 현재 기록 수량이 정수인 경우 전체-주문 단위 결과를 보여줍니다. 브로커의 소수 단위 매매/주문 단위 조건은 자동 추정하지 않습니다.')
    quantity_target_options = car_contrib['name'].fillna('').astype(str).tolist() if not car_contrib.empty else []
    if not quantity_target_options:
        st.info('주문 단위 진단 대상이 없습니다.')
    else:
        quantity_target = st.selectbox('주문 단위 대상', quantity_target_options, index=0, key='car_repair_quantity_target')
        quantity_ladder = whole_quantity_trim_ladder(portfolio, total_assets, quantity_target, top_share_cap=car_policy_cap)
        if quantity_ladder.empty:
            st.info('현재 기록된 수량이 없거나 소수 단위 수량이므로 전체-수량 단계별 분석을 만들지 않습니다.')
        else:
            qshow = quantity_ladder.copy()
            for _c in ['post_direct_bear_loss', 'post_top_car_share']:
                qshow[_c] = pd.to_numeric(qshow[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            for _c in ['unit_value_proxy_krw', 'trim_amount_krw']:
                qshow[_c] = pd.to_numeric(qshow[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            qshow['policy_state'] = qshow['within_policy_cap'].map(lambda x: 'WITHIN_CAP' if bool(x) else 'ABOVE_CAP')
            _locale.dataframe(st, qshow[[c for c in ['name', 'current_quantity', 'unit_value_proxy_krw', 'trim_quantity', 'trim_amount_krw', 'remaining_quantity', 'post_direct_bear_loss', 'post_top_car_share', 'policy_state', 'repair_status'] if c in qshow.columns]], width='stretch', hide_index=True)
            st.caption('주문 단위 표는 현재 값 ÷ 수량을 단위 값 추정치로 사용합니다. 실제 체결가격·세금·슬리피지는 포함하지 않습니다.')
    st.subheader('7. 실행 준비 상태')
    recon_car = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    liq_overlays_car = normalize_liquidity_overlays(load_csv('liquidity_operational_overlays.csv'))
    liq_editor_car = liquidity_overlay_editor_rows(portfolio, liq_overlays_car, legacy_overlays=normalize_risk_overlays(load_csv('asset_risk_overlays.csv')))
    liq_status_car = liquidity_status_table(portfolio, liq_editor_car, total_assets, liquidity_days_limit=float(settings.get('liquidity_days_limit', 5.0)))
    positive_names = positive_plan['name'].fillna('').astype(str).tolist() if not positive_plan.empty else []
    donor_liq = liq_status_car.loc[liq_status_car['name'].fillna('').astype(str).isin(positive_names)].copy() if not liq_status_car.empty else pd.DataFrame()
    if not positive_names:
        liquidity_gate_car = 'N/A'
    elif donor_liq.empty:
        liquidity_gate_car = 'REVIEW'
    elif donor_liq['status'].fillna('').astype(str).str.upper().eq('PASS').all():
        liquidity_gate_car = 'TIGHT' if donor_liq['liquidity_status'].fillna('').astype(str).str.upper().eq('TIGHT').any() else 'PASS'
    else:
        liquidity_gate_car = 'REVIEW'
    er1, er2, er3 = st.columns(3)
    er1.metric('대조', _locale.code(recon_car['status']))
    er2.metric('자금 제공 자산 유동성', _locale.code(liquidity_gate_car))
    er3.metric('현금 증가 추정치', _locale.code(krw(car_sim['cash_increase_krw'])))
    if not donor_liq.empty:
        _locale.dataframe(st, donor_liq[[c for c in ['name', 'weight', 'liquidity_days_to_exit', 'liquidity_status', 'reviewed', 'source', 'status', 'issues'] if c in donor_liq.columns]], width='stretch', hide_index=True)
    if recon_car['status'] != 'PASS':
        st.error('포트폴리오 대조가 정상이 아니므로 실행 검토를 진행하지 마세요.')
    elif liquidity_gate_car == 'REVIEW':
        st.warning('비중 축소 자금 제공 자산의 유동성 출처/사용자 검토가 완료되지 않았습니다.')
    elif liquidity_gate_car == 'TIGHT':
        st.warning('비중 축소 자금 제공 자산 중 여유 부족 유동성이 있습니다. 한 번에 같은 금액을 실행할 수 있다고 가정하지 마세요.')
    elif positive_names:
        st.success('비중 축소 자금 제공 자산의 유동성 데이터는 현재 검토 완료 상태입니다. 그래도 세금/가치 평가/투자 가설은 자본 이동에서 별도로 검토해야 합니다.')
    st.subheader('8. 자본 이동 인계')
    if positive_plan.empty:
        st.info('비중 축소 금액이 0원보다 큰 자금 제공 자산이 생기면 자본 이동으로 연결할 수 있습니다.')
    else:
        handoff_names = positive_plan['name'].fillna('').astype(str).tolist()
        handoff_donor = st.selectbox('자본 이동으로 넘길 자금 제공 자산', handoff_names, key='car_repair_handoff_donor')
        handoff_hit = positive_plan.loc[positive_plan['name'].fillna('').astype(str).eq(handoff_donor)]
        handoff_amount = float(handoff_hit.iloc[0].get('effective_trim_krw', 0.0) or 0.0) if not handoff_hit.empty else 0.0
        st.write(f'선택 자금 제공 자산: **{handoff_donor}** · 가상 축소금액: **{handoff_amount:,.0f}원**')
        st.button('선택 자금 제공 자산을 자본 이동으로 이어서 검토', on_click=_navigate, args=('Capital Migration', {'migration_donor': handoff_donor, 'migration_recipient': '현금 (CASH)', 'migration_amount_krw': handoff_amount, 'migration_handoff_source': 'CAR Concentration Repair', 'migration_handoff_donor_original': handoff_donor, 'migration_handoff_amount_original': handoff_amount, 'migration_handoff_created_at': datetime.now().isoformat()}), key='car_repair_to_migration')
    st.subheader('9. 검토 기록')
    car_note = st.text_input('검토 메모', value='', key='car_repair_note', placeholder='예: 상위 손실위험자본 집중도 수학적 보완 비교 기준 검토')
    if st.button('현재 손실위험자본 집중도 보완 검토 저장', key='save_car_concentration_repair'):
        car_row = car_repair_review_row(car_sim, policy_cap=car_policy_cap, liquidity_gate=liquidity_gate_car, reconciliation_gate=recon_car['status'], template=car_template, note=car_note)
        car_hist = load_csv('car_concentration_repair_reviews.csv')
        for _col in CAR_REPAIR_REVIEW_COLS:
            if _col not in car_hist.columns:
                car_hist[_col] = ''
        car_hist = pd.concat([car_hist[CAR_REPAIR_REVIEW_COLS], pd.DataFrame([car_row])], ignore_index=True)
        verified_save_feedback(car_hist, 'car_concentration_repair_reviews.csv', 'CAR Concentration Repair 검토를 저장했습니다.', rerun=False)
    car_history = load_csv('car_concentration_repair_reviews.csv')
    if not car_history.empty:
        _locale.dataframe(st, car_history.tail(20), width='stretch', hide_index=True)
    st.caption('손실위험자본 집중도 보완은 포트폴리오 하락 시나리오-위험 집중도의 수학적 가정별 분석입니다. 상위 손실위험자본 비중 상한을 맞추는 것 자체가 투자목표가 아니며, 자금 제공 자산 축소는 향후 투자 가설/가치 평가/세금/유동성/기회 비용 검토를 통과해야 합니다.')
