from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('포트폴리오 전체 투자 요인 위험 보완')
    st.caption('하나의 자금 제공 자산이 아니라 여러 보유자산의 가상 축소금액을 동시에 넣어 투자 요인 노출이 어떻게 바뀌는지 계산합니다.')
    st.info('모든 축소금액은 우선 현금으로 이동한다고 가정합니다. 이 화면의 비교 기준과 최소 총축소량은 수학적 비교값이며 매도 우선순위가 아닙니다. 실제 축소는 각 자금 제공 자산의 투자 가설 / 가치 평가 / 세금 / 유동성을 별도로 확인해야 합니다.')
    pw_factor_cap = float(settings.get('factor_cap', 0.1))
    pw_exposure = all_factor_exposures(portfolio, total_assets, factor_loadings, factor_cap=pw_factor_cap)
    pw_breached = pw_exposure.loc[pw_exposure['breach_status'].astype(str).eq('PRE-EXISTING BREACH')].copy() if not pw_exposure.empty else pd.DataFrame()
    if pw_breached.empty:
        st.success('현재 사전-기존 상한 초과 투자 요인이 없습니다. 포트폴리오 전체 위험 보완을 실행할 필요가 없습니다.')
    else:
        pw_factor_options = pw_breached['factor'].fillna('').astype(str).tolist()
        handed_factor = str(st.session_state.get('portfolio_repair_factor', '') or '').strip()
        pw_default_index = pw_factor_options.index(handed_factor) if handed_factor in pw_factor_options else 0
        pw_factor = st.selectbox('복구 검토 투자 요인', pw_factor_options, index=pw_default_index, key='portfolio_repair_factor_select')
        st.session_state['portfolio_repair_factor'] = pw_factor
        pw_overview = factor_repair_overview(portfolio=portfolio, total_assets=total_assets, factor=pw_factor, factor_cap=pw_factor_cap, factor_loadings=factor_loadings)
        pw_universe = repair_universe(portfolio=portfolio, total_assets=total_assets, factor=pw_factor, factor_cap=pw_factor_cap, factor_loadings=factor_loadings)
        st.subheader('1. 현재 상한 초과')
        p1, p2, p3, p4 = st.columns(4)
        p1.metric('현재 노출', _locale.code(pct(pw_overview.get('current_exposure', 0.0))))
        p2.metric('정책 상한', _locale.code(pct(pw_overview.get('factor_cap', 0.0))))
        p3.metric('초과', _locale.code(pct(pw_overview.get('excess_exposure', 0.0))))
        p4.metric('기여 보유자산 수', _locale.code(len(pw_universe)))
        if pw_universe.empty:
            st.warning('선택 투자 요인의 기여 보유자산을 계산할 수 없습니다.')
        else:
            pw_min = minimum_gross_trim_benchmark(portfolio=portfolio, total_assets=total_assets, factor=pw_factor, factor_cap=pw_factor_cap, factor_loadings=factor_loadings)
            pw_pro = pro_rata_repair_benchmark(portfolio=portfolio, total_assets=total_assets, factor=pw_factor, factor_cap=pw_factor_cap, factor_loadings=factor_loadings)
            pw_min_sim = pw_min['simulation']
            pw_pro_sim = pw_pro['simulation']
            st.subheader('2. 두 개의 수학적 비교 기준')
            st.caption('둘 다 실행 권고가 아닙니다. 실제 선택안이 어느 정도의 축소를 요구하는지 비교하기 위한 기준선입니다.')
            b1, b2 = st.columns(2)
            with b1:
                st.markdown('**최소 총액 비중 축소 하한 연결됨**')
                st.metric('총 가상 축소금액', _locale.code(krw(pw_min_sim.get('total_trim_krw', 0.0))))
                st.metric('총자산 대비', _locale.code(pct(pw_min_sim.get('total_trim_weight', 0.0))))
                st.write(f"자금 제공 자산 수: **{pw_min_sim.get('donor_count', 0)}개** · 축소 후 노출: **{pct(pw_min_sim.get('post_exposure', 0.0))}**")
                st.caption('투자 요인 감소 1원당 효율이 높은 노출 계수부터 사용한 수학적 최소 총축소 하한입니다. 투자 가설·세금·유동성·가치 평가를 무시하므로 실행안으로 사용하면 안 됩니다.')
            with b2:
                st.markdown('**비례 배분 기여 자산 비교 기준**')
                st.metric('총 가상 축소금액', _locale.code(krw(pw_pro_sim.get('total_trim_krw', 0.0))))
                st.metric('각 기여자 공통 축소비율', _locale.code(pct(pw_pro.get('pro_rata_pct', 0.0))))
                st.write(f"자금 제공 자산 수: **{pw_pro_sim.get('donor_count', 0)}개** · 축소 후 노출: **{pct(pw_pro_sim.get('post_exposure', 0.0))}**")
                st.caption('현재 투자 요인 기여 보유자산을 같은 비율로 줄이는 비교 비교 기준입니다.')
            st.subheader('3. 여러 자금 제공 자산 시나리오 편집')
            template_label = st.radio('시작 템플릿', ['직접 입력', 'Factor 기여자 비례 복구 Benchmark', '최소 총축소 Lower Bound Benchmark'], horizontal=True, key='portfolio_repair_template', format_func=_locale.option())
            editor_cols = ['name', 'ticker', 'current_value_krw', 'portfolio_weight', 'factor_loading', 'factor_exposure', 'trim_amount_krw']
            if template_label == 'Factor 기여자 비례 복구 Benchmark':
                pw_edited = pw_pro['plan'][editor_cols].copy()
                benchmark_view = pw_edited.copy()
                benchmark_view['current_value_krw'] = pd.to_numeric(benchmark_view['current_value_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
                benchmark_view['trim_amount_krw'] = pd.to_numeric(benchmark_view['trim_amount_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
                for c in ['portfolio_weight', 'factor_loading', 'factor_exposure']:
                    benchmark_view[c] = pd.to_numeric(benchmark_view[c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
                _locale.dataframe(st, benchmark_view, width='stretch', hide_index=True)
                st.caption('비교 기준 모드에서는 계산된 축소안을 그대로 사용합니다. 금액을 직접 바꾸려면 `직접 입력`을 선택하세요.')
            elif template_label == '최소 총축소 Lower Bound Benchmark':
                pw_edited = pw_min['plan'][editor_cols].copy()
                benchmark_view = pw_edited.copy()
                benchmark_view['current_value_krw'] = pd.to_numeric(benchmark_view['current_value_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
                benchmark_view['trim_amount_krw'] = pd.to_numeric(benchmark_view['trim_amount_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
                for c in ['portfolio_weight', 'factor_loading', 'factor_exposure']:
                    benchmark_view[c] = pd.to_numeric(benchmark_view[c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
                _locale.dataframe(st, benchmark_view, width='stretch', hide_index=True)
                st.caption('비교 기준 모드에서는 계산된 축소안을 그대로 사용합니다. 금액을 직접 바꾸려면 `직접 입력`을 선택하세요.')
            else:
                pw_seed = pw_universe[editor_cols].copy()
                pw_seed['trim_amount_krw'] = 0.0
                pw_editor_key = 'portfolio_repair_manual_editor_' + str(abs(hash(pw_factor)))
                pw_edited = _locale.editor(st, pw_seed, num_rows='fixed', width='stretch', hide_index=True, disabled=[c for c in editor_cols if c != 'trim_amount_krw'], column_config={'trim_amount_krw': st.column_config.NumberColumn('가상 축소금액(원화)', min_value=0.0, step=10000.0, format='%.0f'), 'current_value_krw': st.column_config.NumberColumn('현재 가치(원화)', format='%.0f')}, key=pw_editor_key)
            pw_sim = simulate_portfolio_repair(portfolio=portfolio, total_assets=total_assets, factor=pw_factor, factor_cap=pw_factor_cap, trim_plan=pw_edited, factor_loadings=factor_loadings)
            st.subheader('4. 포트폴리오 전체 시뮬레이션 결과')
            r1, r2, r3, r4, r5 = st.columns(5)
            r1.metric('총 가상 축소', _locale.code(krw(pw_sim.get('total_trim_krw', 0.0))))
            r2.metric('투자 요인 감소', _locale.code(pct(pw_sim.get('factor_reduction', 0.0))))
            r3.metric('축소 후 노출', _locale.code(pct(pw_sim.get('post_exposure', 0.0))))
            r4.metric('축소 후 초과', _locale.code(pct(pw_sim.get('post_excess_exposure', 0.0))))
            r5.metric('상태', _locale.code(pw_sim.get('repair_status', '-')))
            pw_status = pw_sim.get('repair_status', 'REVIEW')
            if pw_status == 'CAP RESTORED':
                st.success(f"{_locale.code(pw_status)} · {pw_sim.get('repair_detail', '')}")
            elif pw_status == 'BLOCKED':
                st.error(f"{_locale.code(pw_status)} · {pw_sim.get('repair_detail', '')}")
                for issue in pw_sim.get('issues', []):
                    st.write(f'- {issue}')
            else:
                st.warning(f"{_locale.code(pw_status)} · {pw_sim.get('repair_detail', '')}")
            plan_view = pw_sim.get('effective_plan', pd.DataFrame()).copy()
            if not plan_view.empty:
                positive = plan_view.loc[pd.to_numeric(plan_view['effective_trim_krw'], errors='coerce').fillna(0.0).gt(0)].copy()
                if not positive.empty:
                    show_plan = positive.copy()
                    for c in ['portfolio_weight', 'factor_loading', 'factor_exposure', 'trim_pct_of_position', 'factor_reduction']:
                        show_plan[c] = pd.to_numeric(show_plan[c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
                    for c in ['current_value_krw', 'effective_trim_krw', 'post_value_krw']:
                        show_plan[c] = pd.to_numeric(show_plan[c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
                    _locale.dataframe(st, show_plan[['name', 'current_value_krw', 'factor_loading', 'effective_trim_krw', 'trim_pct_of_position', 'factor_reduction', 'post_value_krw']], width='stretch', hide_index=True)
            st.subheader('5. 다른 투자 요인에 미치는 영향')
            cross = pw_sim.get('cross_factor_impact', pd.DataFrame()).copy()
            if cross.empty:
                st.info('투자 요인 간 영향표를 계산할 수 없습니다.')
            else:
                cross_show = cross.copy()
                for c in ['before_exposure', 'factor_reduction', 'after_exposure', 'policy_cap', 'before_excess', 'after_excess']:
                    cross_show[c] = pd.to_numeric(cross_show[c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
                _locale.dataframe(st, cross_show, width='stretch', hide_index=True)
                st.caption('모든 가상 축소대금이 현금으로 이동한다고 가정하므로 표의 투자 요인 노출은 감소 방향만 계산합니다. 다른 자금 수령 자산으로 재투자하면 자본 이동에서 투자 요인 재유입을 다시 계산해야 합니다.')
            st.subheader('6. 자금 제공 자산별 자본 이동 연결')
            positive_plan = pw_sim.get('effective_plan', pd.DataFrame())
            if isinstance(positive_plan, pd.DataFrame) and (not positive_plan.empty):
                positive_plan = positive_plan.loc[pd.to_numeric(positive_plan['effective_trim_krw'], errors='coerce').fillna(0.0).gt(0)].copy()
            if not isinstance(positive_plan, pd.DataFrame) or positive_plan.empty:
                st.info('가상 축소금액이 0원보다 큰 자금 제공 자산이 생기면 한 자금 제공 자산씩 자본 이동으로 연결할 수 있습니다.')
            else:
                handoff_name = st.selectbox('자본 이동으로 넘길 자금 제공 자산', positive_plan['name'].fillna('').astype(str).tolist(), key='portfolio_repair_handoff_donor')
                handoff_row = positive_plan.loc[positive_plan['name'].fillna('').astype(str).eq(handoff_name)].iloc[0].to_dict()
                handoff_amount = float(handoff_row.get('effective_trim_krw', 0.0) or 0.0)
                st.write(f'선택 자금 제공 자산: **{handoff_name}** · 가상 축소금액: **{handoff_amount:,.0f}원**')
                st.button('선택 자금 제공 자산을 자본 이동으로 이어서 검토', on_click=_navigate, args=('Capital Migration', {'migration_donor': handoff_name, 'migration_recipient': '현금 (CASH)', 'migration_amount_krw': handoff_amount, 'migration_factor_repair_mode': True, 'migration_repair_factor': pw_factor, 'migration_handoff_source': 'Portfolio Risk Repair'}), key='portfolio_repair_to_migration')
            st.subheader('7. 검토 기록 저장')
            pw_note = st.text_input('검토 메모', value='', key='portfolio_repair_note', placeholder='예: 투자 요인 집중위험 복구 시나리오 비교')
            st.caption('저장은 실제 주문이 아니라 당시 사용한 다중 자금 제공 자산 시나리오와 투자 요인 전/후 노출을 감사 기록으로 남깁니다.')
            if st.button('현재 포트폴리오 전체 위험 보완 검토 저장', key='save_portfolio_repair_review'):
                row = portfolio_repair_review_row(pw_sim, template=template_label, note=pw_note)
                hist = load_csv('portfolio_risk_repair_reviews.csv')
                for col in PORTFOLIO_REPAIR_REVIEW_COLS:
                    if col not in hist.columns:
                        hist[col] = ''
                hist = pd.concat([hist[PORTFOLIO_REPAIR_REVIEW_COLS], pd.DataFrame([row])], ignore_index=True)
                verified_save_feedback(hist, 'portfolio_risk_repair_reviews.csv', 'Portfolio-wide Risk Repair 검토를 저장했습니다.', rerun=False)
            pw_history = load_csv('portfolio_risk_repair_reviews.csv')
            if not pw_history.empty:
                _locale.dataframe(st, pw_history.tail(20), width='stretch', hide_index=True)
    st.caption('포트폴리오 전체 위험 보완은 기존 집중위험의 수학적 복구효과를 비교하는 가정별 분석 도구입니다. 평균매입가는 향후 판단의 기준으로 사용하지 않으며 증권사 주문을 전송하지 않습니다.')
