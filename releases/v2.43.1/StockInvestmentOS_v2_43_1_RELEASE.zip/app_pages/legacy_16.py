from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('핵심 성과 지표 점검')
    st.caption('각 투자 가설의 핵심 핵심 성과 지표를 공식 원문 출처 날짜와 함께 관리합니다. 핵심 성과 지표 상태는 투자결정을 대신하지 않습니다.')
    kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    c1, c2 = st.columns(2)
    company_options = [''] + sorted(set(watchlist['name'].dropna().astype(str).tolist()))
    selected_company = c1.selectbox('회사', company_options, key='kpi_company')
    stale_days = c2.number_input('핵심 성과 지표 오래됨 일수', min_value=1, max_value=365, value=int(settings.get('kpi_stale_days', 120)), step=10)
    b1, b2 = st.columns(2)
    if b1.button('선택 회사 기본 핵심 성과 지표 템플릿 추가'):
        if not selected_company:
            st.error('회사를 먼저 선택하세요.')
        else:
            seed = seed_generic_kpis(selected_company)
            existing_metrics = set(zip(kpis['company'].fillna('').astype(str).str.strip(), kpis['metric'].fillna('').astype(str).str.strip()))
            add_rows = seed.loc[~seed.apply(lambda r: (str(r['company']).strip(), str(r['metric']).strip()) in existing_metrics, axis=1)]
            save_csv(pd.concat([kpis, add_rows], ignore_index=True), 'thesis_kpis.csv')
            st.success(f'{len(add_rows)}개 핵심 성과 지표 템플릿을 추가했습니다.')
            st.rerun()
    if b2.button('최근 전자공시 상태 기록에서 재무 핵심 성과 지표 반영'):
        if not selected_company:
            st.error('회사를 먼저 선택하세요.')
        else:
            w = watchlist.loc[watchlist['name'].fillna('').astype(str).str.strip() == selected_company]
            stock_code = '' if w.empty else str(w.iloc[0].get('code', '') or '')
            snapshots = load_csv('dart_snapshots.csv')
            updated = update_from_latest_dart(kpis, selected_company, stock_code, snapshots)
            save_csv(updated, 'thesis_kpis.csv')
            st.success('저장된 전자공시 상태 기록에서 가능한 재무 핵심 성과 지표를 반영했습니다.')
            st.rerun()
    st.subheader('핵심 성과 지표 목록')
    _locale.dataframe(st, kpis, width='stretch', hide_index=True)
    if kpis.empty:
        st.info('핵심 성과 지표가 없습니다. 기본 템플릿을 추가하세요.')
    else:
        labels = [f"{i + 1}. {str(row.get('company', ''))} / {str(row.get('metric', ''))}" for i, row in kpis.iterrows()]
        selected_label = st.selectbox('수정할 핵심 성과 지표 선택', labels, key='kpi_row_select')
        selected_idx = labels.index(selected_label)
        current = kpis.iloc[selected_idx].to_dict()

        def _txt(v):
            if v is None:
                return ''
            s = str(v)
            return '' if s.lower() in {'nan', 'none'} else s
        with st.form('kpi_edit_form'):
            st.markdown('### 선택한 핵심 성과 지표 수정')
            a, b = st.columns(2)
            company = a.text_input('기업', value=_txt(current.get('company')))
            metric = b.text_input('지표', value=_txt(current.get('metric')))
            a, b, c = st.columns(3)
            direction_options = ['HIGHER_BETTER', 'LOWER_BETTER', 'RANGE', 'MANUAL']
            current_direction = _txt(current.get('direction')).upper() or 'MANUAL'
            d_idx = direction_options.index(current_direction) if current_direction in direction_options else 3
            direction = a.selectbox('방향', direction_options, index=d_idx)
            actual_text = b.text_input('실제', value=_txt(current.get('actual')))
            unit = c.text_input('단위', value=_txt(current.get('unit')))
            a, b = st.columns(2)
            good_text = a.text_input('양호 기준값', value=_txt(current.get('good_threshold')))
            bad_text = b.text_input('주의 기준값', value=_txt(current.get('bad_threshold')))
            a, b = st.columns(2)
            as_of = a.text_input('기준 시점', value=_txt(current.get('as_of')), placeholder='YYYY-MM-DD')
            next_check_date = b.text_input('다음 확인일', value=_txt(current.get('next_check_date')), placeholder='YYYY-MM-DD')
            source_url = st.text_input('출처 주소', value=_txt(current.get('source_url')))
            status_options = ['', 'PASS', 'REVIEW', 'FAIL', 'NO DATA']
            current_status = _txt(current.get('status')).upper()
            s_idx = status_options.index(current_status) if current_status in status_options else 0
            status = st.selectbox('상태 (수동 핵심 성과 지표용)', status_options, index=s_idx)
            note = st.text_area('메모', value=_txt(current.get('note')), height=100)
            save_row = st.form_submit_button('선택한 KPI 저장', type='primary')
        if save_row:

            def _optional_number(text):
                text = str(text).strip()
                if text == '':
                    return float('nan')
                try:
                    return float(text.replace(',', ''))
                except Exception:
                    raise ValueError(f'숫자 입력이 필요합니다: {text}')
            try:
                updated = normalize_kpis(kpis.copy())
                values = {'company': company, 'metric': metric, 'direction': direction, 'actual': _optional_number(actual_text), 'good_threshold': _optional_number(good_text), 'bad_threshold': _optional_number(bad_text), 'unit': unit, 'as_of': as_of, 'source_url': source_url, 'next_check_date': next_check_date, 'status': status, 'note': note}
                for col, val in values.items():
                    updated.at[selected_idx, col] = val
                save_csv(normalize_kpis(updated), 'thesis_kpis.csv')
                st.success('선택한 핵심 성과 지표를 저장했습니다.')
                st.rerun()
            except Exception as e:
                st.error(_locale.message(str(e)))
    st.subheader('새 핵심 성과 지표 추가')
    with st.form('kpi_add_form'):
        a, b, c = st.columns(3)
        new_company = a.text_input('새 기업', value=selected_company)
        new_metric = b.text_input('새 지표')
        new_direction = c.selectbox('새 방향', ['HIGHER_BETTER', 'LOWER_BETTER', 'RANGE', 'MANUAL'], index=3, format_func=_locale.option())
        add_new = st.form_submit_button('빈 KPI 행 추가')
    if add_new:
        if not new_company or not new_metric:
            st.error('기업과 지표를 입력하세요.')
        else:
            row = {c: '' for c in KPI_COLS}
            row.update({'company': new_company, 'metric': new_metric, 'direction': new_direction, 'status': 'REVIEW' if new_direction == 'MANUAL' else ''})
            save_csv(pd.concat([kpis, pd.DataFrame([row])], ignore_index=True), 'thesis_kpis.csv')
            st.success('새 핵심 성과 지표 행을 추가했습니다.')
            st.rerun()
    evaluated = evaluate_kpis(kpis, int(stale_days))
    st.subheader('핵심 성과 지표 평가')
    if evaluated.empty:
        st.info('핵심 성과 지표가 없습니다.')
    else:
        summary = evaluated['monitor_status'].value_counts().to_dict()
        c1, c2, c3, c4 = st.columns(4)
        c1.metric('실패', _locale.code(int(summary.get('FAIL', 0))))
        c2.metric('기한 초과', _locale.code(int(summary.get('OVERDUE', 0))))
        c3.metric('오래됨 / 기한', _locale.code(int(summary.get('STALE', 0) + summary.get('DUE SOON', 0))))
        c4.metric('정상', _locale.code(int(summary.get('PASS', 0))))
        _locale.dataframe(st, evaluated, width='stretch', hide_index=True)
