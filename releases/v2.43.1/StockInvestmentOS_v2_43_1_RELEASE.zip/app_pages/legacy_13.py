from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('모니터링 센터 2.0 / 일일 검토 계획')
    st.caption('모든 검토 기한을 종합 대기 목록 하나로 통합하고, 오늘 먼저 확인할 작업과 종목별 모니터링 확인 범위를 자동 계산합니다.')
    st.info('이 화면은 검토 작업을 자동 정렬할 뿐 투자판단을 자동 변경하지 않습니다. 대기 목록 항목은 원본 투자 근거/기한을 갱신하면 자동으로 사라지거나 이동합니다.')
    mc_today = date.today()
    mc_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    mc_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    mc_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    mc_thesis = build_thesis_monitor(watchlist, mc_states, mc_plans, mc_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=mc_today)
    mc_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    mc_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    mc_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=mc_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=mc_kpis, state_df=mc_states, thesis_monitor=mc_thesis, audit_df=mc_audit, reconciliation=mc_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=mc_today)
    mc_coverage = monitoring_coverage(watchlist=watchlist, thesis_plans=mc_plans, proof=proof, evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), factor_loadings=factor_loadings, source_candidates=load_csv('source_candidates.csv'), today=mc_today)
    mc_summary = monitoring_summary(mc_queue, mc_coverage)
    st.subheader('1. 모니터링 현황')
    p1, p2, p3, p4, p5, p6, p7 = st.columns(7)
    p1.metric('기한 초과', _locale.code(mc_summary['overdue']))
    p2.metric('오늘 + 지금 확인', _locale.code(mc_summary['today'] + mc_summary['now']))
    p3.metric('다음 7 일수', _locale.code(mc_summary['next_7_days']))
    p4.metric('확인 범위 정상', _locale.code(mc_summary['coverage_pass']))
    p5.metric('확인 범위 검토', _locale.code(mc_summary['coverage_review']))
    p6.metric('확인 범위 차이', _locale.code(mc_summary['coverage_gap']))
    p7.metric('진행 중 출처', _locale.code(mc_summary['open_source_candidates']))
    if mc_summary['overdue'] > 0:
        st.error('기한 초과 검토가 있습니다. 가격보다 먼저 공식 원문 출처와 검토 기한을 확인하세요.')
    elif mc_summary['today'] + mc_summary['now'] > 0:
        st.warning('오늘/즉시 확인할 검토가 있습니다. 이는 자동 매수/매도 신호가 아닙니다.')
    else:
        st.success('현재 기한 초과 / 오늘 / 지금 확인 검토가 없습니다.')
    st.subheader('2. 일일 검토 계획')
    max_plan_items = st.slider('오늘 표시할 최대 검토 수', min_value=5, max_value=30, value=12, step=1, key='monitoring_plan_max_items')
    mc_plan = daily_review_plan(mc_queue, max_items=max_plan_items)
    plan_cols = ['bucket', 'due_date', 'category', 'subject', 'status', 'issue', 'next_action', 'go_to']
    if mc_plan.empty:
        st.success('현재 일일 검토 계획이 비어 있습니다.')
    else:
        _locale.dataframe(st, mc_plan[[c for c in plan_cols if c in mc_plan.columns]], width='stretch', hide_index=True)
        selector = mc_plan.copy()
        selector['_label'] = selector['bucket'].astype(str) + ' · ' + selector['category'].astype(str) + ' · ' + selector['subject'].astype(str)
        chosen = st.selectbox('바로 검토할 항목', selector['_label'].tolist(), key='monitoring_center_selected_review')
        selected = selector.loc[selector['_label'].eq(chosen)].iloc[0].to_dict()
        target = str(selected.get('go_to', '') or '').strip()
        if target:
            st.button(f'{target}로 이동', type='primary', on_click=_navigate, args=(target,), key='monitoring_center_go_to')
    st.subheader('3. 모니터링 확인 범위')
    st.caption('확인 범위는 종목의 투자매력 점수가 아니라 투자 가설 / 확인 근거 / 투자 근거 / 영향 / 판단 / 투자 요인 노출 계수가 운영 가능한 상태인지 확인하는 완전성 점검입니다.')
    if mc_coverage.empty:
        st.info('확인 범위를 계산할 관심종목 종목이 없습니다.')
    else:
        _locale.dataframe(st, mc_coverage, width='stretch', hide_index=True)
        gaps = mc_coverage.loc[~mc_coverage['coverage_status'].fillna('').astype(str).str.upper().eq('PASS')]
        if gaps.empty:
            st.success('관심종목 전체 모니터링 확인 범위가 정상입니다.')
        else:
            st.warning(f'확인 범위 검토/차이 종목 {len(gaps)}개가 있습니다.')
    st.subheader('4. 모니터링 상태 기록')
    monitoring_runs = ensure_cols(load_csv('monitoring_runs.csv'), MONITORING_RUN_COLS)
    if st.button('현재 모니터링 상태 기록 저장', key='save_monitoring_snapshot'):
        try:
            run_row = build_monitoring_run_row(queue=mc_queue, coverage=mc_coverage, technical_attention=0, today=mc_today)
            updated = pd.concat([monitoring_runs[MONITORING_RUN_COLS], pd.DataFrame([run_row])], ignore_index=True)
            verified_save_feedback(updated, 'monitoring_runs.csv', 'Monitoring Snapshot을 저장했습니다.', rerun=True)
        except Exception as e:
            st.error(f'모니터링 상태 기록 저장 실패: {e}')
    if monitoring_runs.empty:
        st.info('저장된 모니터링 상태 기록이 없습니다.')
    else:
        _locale.dataframe(st, monitoring_runs.tail(30), width='stretch', hide_index=True)
    st.subheader('5. 원본 종합 검토 대기 목록')
    if mc_queue.empty:
        st.success('현재 종합 검토 대기 목록이 비어 있습니다.')
    else:
        mc_cols = ['bucket', 'due_date', 'days_to_due', 'category', 'subject', 'status', 'issue', 'next_action', 'go_to']
        _locale.dataframe(st, mc_queue[[c for c in mc_cols if c in mc_queue.columns]], width='stretch', hide_index=True)
    nav1, nav2, nav3 = st.columns(3)
    nav1.button('검토 대기 목록', on_click=_navigate, args=('Review Queue',), key='monitoring_to_review_queue')
    nav2.button('공식 원문 점검', on_click=_navigate, args=('Primary Source Monitor',), key='monitoring_to_source_monitor')
    nav3.button('안정성 검증', on_click=_navigate, args=('Stability Audit',), key='monitoring_to_stability')
    st.caption('모니터링 센터는 앱을 열거나 데이터가 변경될 때 계산됩니다. 백그라운드에서 자동 주문하거나 투자 상태를 임의 변경하지 않습니다.')
