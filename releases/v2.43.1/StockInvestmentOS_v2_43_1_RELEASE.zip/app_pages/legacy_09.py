from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('투자 요인 위험 보완 계획')
    st.caption('사전-기존 상한 초과를 어떤 보유자산이 얼마나 만들고 있는지 보고, 가상의 축소금액이 투자 요인 노출을 얼마나 줄이는지 계산합니다.')
    st.info('이 화면은 매도 지시가 아닙니다. 기존 포지션을 실제로 줄일지는 투자 가설, 가치 평가, 세금/매매 비용, 자본 이동을 별도로 확인해야 합니다.')
    factor_cap_policy = float(settings.get('factor_cap', 0.1))
    exposure_table = all_factor_exposures(portfolio, total_assets, factor_loadings, factor_cap=factor_cap_policy)
    breached = exposure_table.loc[exposure_table['breach_status'].astype(str).eq('PRE-EXISTING BREACH')].copy() if not exposure_table.empty else pd.DataFrame()
    if breached.empty:
        st.success('현재 사전-기존 상한 초과 투자 요인이 없습니다. 위험 보완 계획을 사용할 필요가 없습니다.')
    else:
        factor_options = breached['factor'].fillna('').astype(str).tolist()
        selected_factor = st.selectbox('복구 검토 투자 요인', factor_options, key='factor_repair_factor')
        overview = factor_repair_overview(portfolio=portfolio, total_assets=total_assets, factor=selected_factor, factor_cap=factor_cap_policy, factor_loadings=factor_loadings)
        st.subheader('1. 현재 상한 초과')
        b1, b2, b3, b4 = st.columns(4)
        b1.metric('현재 실질 구성자산 분석 노출', _locale.code(pct(overview['current_exposure'])))
        b2.metric('정책 상한', _locale.code(pct(overview['factor_cap'])))
        b3.metric('초과 노출', _locale.code(pct(overview['excess_exposure'])))
        b4.metric('신규 위험 추가 허용 여력', _locale.code(pct(overview['new_risk_headroom'])))
        st.warning(f"{selected_factor} = **{_locale.code(overview['breach_status'])}** · 기존 초과위험은 별도 위험 보완 대상으로 관리하고, 같은 투자 요인 신규 위험은 0% 추가 허용 여력으로 차단합니다.")
        st.button('여러 자금 제공 자산을 함께 검토', on_click=_navigate, args=('Portfolio Risk Repair', {'portfolio_repair_factor': selected_factor}), key='factor_repair_to_portfolio_repair')
        st.subheader('2. 누가 투자 요인 위험에 기여하는가')
        contributors = overview['contributors'].copy()
        if contributors.empty:
            st.info('기여 자산을 계산할 수 없습니다.')
        else:
            show = contributors.copy()
            for col in ['portfolio_weight', 'factor_loading', 'factor_exposure', 'factor_share_of_total_exposure', 'max_repair_if_full_exit', 'required_trim_weight_if_alone']:
                if col in show.columns:
                    show[col] = pd.to_numeric(show[col], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            for col in ['current_value_krw', 'required_trim_krw_if_alone']:
                if col in show.columns:
                    show[col] = pd.to_numeric(show[col], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            _locale.dataframe(st, show[['name', 'portfolio_weight', 'factor_loading', 'factor_exposure', 'factor_share_of_total_exposure', 'loading_status', 'required_trim_weight_if_alone', 'required_trim_krw_if_alone', 'can_restore_cap_alone']], width='stretch', hide_index=True)
            st.caption('`required_trim_if_alone`은 선택 자산 하나만으로 상한을 복구한다고 가정한 수학적 손익계산이며 매도 권고가 아닙니다.')
            st.subheader('3. 자금 제공 자산 하나를 선택해 축소 효과 시뮬레이션')
            donor_names = contributors['name'].fillna('').astype(str).tolist()
            donor_name = st.selectbox('검토할 자금 제공 자산', donor_names, key='factor_repair_donor')
            donor_hit = contributors.loc[contributors['name'].fillna('').astype(str).eq(str(donor_name))]
            donor_row = donor_hit.iloc[0].to_dict() if not donor_hit.empty else {}
            donor_ticker = str(donor_row.get('ticker', '') or '').strip()
            d1, d2, d3, d4 = st.columns(4)
            d1.metric('자금 제공 자산 현재 비중', _locale.code(pct(donor_row.get('portfolio_weight', 0.0))))
            d2.metric('투자 요인 노출 계수', _locale.code(pct(donor_row.get('factor_loading', 0.0))))
            d3.metric('현재 투자 요인 기여', _locale.code(pct(donor_row.get('factor_exposure', 0.0))))
            d4.metric('자금 제공 자산 현재 가치', _locale.code(krw(donor_row.get('current_value_krw', 0.0))))
            required_krw = float(donor_row.get('required_trim_krw_if_alone', 0.0) or 0.0)
            required_weight = float(donor_row.get('required_trim_weight_if_alone', 0.0) or 0.0)
            feasible_alone = bool(donor_row.get('can_restore_cap_alone', False))
            if feasible_alone:
                st.info(f'이 자금 제공 자산 하나만 사용한다고 가정한 상한 복구 필요량: 총자산의 **{required_weight:.2%}** / 약 **{required_krw:,.0f}원**. 이는 계산값이지 목표 매도량이 아닙니다.')
            else:
                st.warning('이 자금 제공 자산을 전부 줄여도 해당 투자 요인을 정책 상한까지 복구할 수 없습니다. 여러 자금 제공 자산 또는 정책 자체를 별도 검토해야 합니다.')
            trim_amount = st.number_input('가상 축소금액(원화)', min_value=0.0, value=0.0, step=10000.0, key='factor_repair_trim_amount', help='실제 주문이 아니라 투자 요인 위험 감소효과 시뮬레이션입니다.')
            sim = simulate_factor_repair(portfolio=portfolio, total_assets=total_assets, factor=selected_factor, factor_cap=factor_cap_policy, donor_name=donor_name, donor_ticker=donor_ticker, trim_amount_krw=trim_amount, factor_loadings=factor_loadings)
            st.subheader('4. 시뮬레이션 결과')
            s1, s2, s3, s4 = st.columns(4)
            s1.metric('투자 요인 노출 감소', _locale.code(pct(sim.get('factor_reduction', 0.0))))
            s2.metric('축소 후 노출', _locale.code(pct(sim.get('post_exposure', 0.0))))
            s3.metric('축소 후 초과', _locale.code(pct(sim.get('post_excess_exposure', 0.0))))
            s4.metric('축소 후 상태', _locale.code(sim.get('post_breach_status', '-')))
            status = sim.get('simulation_status', 'REVIEW')
            detail = sim.get('simulation_detail', '')
            if status == 'CAP RESTORED':
                st.success(f'{_locale.code(status)} · {detail}')
            elif status in {'BLOCKED', 'NO FACTOR EFFECT'}:
                st.error(f'{_locale.code(status)} · {detail}')
            else:
                st.warning(f'{_locale.code(status)} · {detail}')
            st.subheader('5. 자본 이동 연결')
            st.write('- 실제 축소 여부는 **비중 축소 / 투자 가설 / 가치 평가**에서 별도로 판단합니다.\n- 축소자금을 다른 종목으로 옮길지는 **자본 이동**에서 비교합니다.\n- 적격 자금 수령 자산이 없으면 **현금**에 남기는 경로도 허용합니다.\n- 평균매입가는 이 향후 판단의 기준으로 사용하지 않습니다.')
            if trim_amount > 0 and status not in {'BLOCKED', 'NO FACTOR EFFECT'}:
                st.info('아래 버튼은 실제 주문을 내지 않습니다. 현재 자금 제공 자산·가상 축소금액·투자 요인을 자본 이동으로 넘기고, **자금 수령 자산은 우선 현금**로 설정합니다. 현금 경로를 확인한 뒤 같은 화면에서 다른 자금 수령 자산으로 바꿔 비교할 수 있습니다.')
                st.button('이 위험 보완을 자본 이동으로 이어서 검토', key='factor_repair_to_migration', on_click=_navigate, args=('Capital Migration', {'migration_donor': donor_name, 'migration_recipient': '현금 (CASH)', 'migration_amount_krw': float(trim_amount), 'migration_factor_repair_mode': True, 'migration_repair_factor': selected_factor, 'migration_handoff_source': 'Factor Risk Repair'}))
            else:
                st.caption('가상 축소금액을 0원보다 크게 입력하고 유효한 시뮬레이션이 나오면 자본 이동 연결 버튼이 활성화됩니다.')
    st.caption('투자 요인 위험 보완 계획은 기존 집중위험의 크기와 수학적 복구효과를 보여주는 시뮬레이션 도구이며 증권사 주문을 전송하지 않습니다.')
