from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('주가·평가액 갱신')
    st.info('관심 종목과 보유 자산의 가격을 조회하고 저장하는 화면입니다. 프로그램 버전 설치는 왼쪽 ‘프로그램 업데이트 설치’ 메뉴에서 진행하세요.')
    st.caption('먼저 미리보기 → 결과 확인 → 적용 순서입니다. 오류 종목은 기존 값을 유지합니다.')
    c1, c2 = st.columns(2)
    if c1.button('관심 종목 가격 미리보기', type='primary'):
        with st.spinner('가격을 조회하는 중...'):
            upd, log = refresh_watchlist_prices(watchlist)
            st.session_state['watch_preview'] = upd
            st.session_state['watch_log'] = log
    if c2.button('보유 자산 가격·평가액 미리보기'):
        with st.spinner('가격과 FX를 조회하는 중...'):
            portfolio_for_refresh = portfolio.copy()
            if 'current_value_krw' in portfolio_for_refresh.columns:
                portfolio_for_refresh['current_value_krw'] = pd.to_numeric(portfolio_for_refresh['current_value_krw'], errors='coerce').astype('float64')
            upd, log = refresh_portfolio_values(portfolio_for_refresh)
            if 'current_value_krw' in upd.columns:
                upd['current_value_krw'] = pd.to_numeric(upd['current_value_krw'], errors='coerce').round().astype('Int64')
            if 'new_value_krw' in log.columns:
                log['new_value_krw'] = pd.to_numeric(log['new_value_krw'], errors='coerce').round().astype('Int64')
            st.session_state['port_preview'] = upd
            st.session_state['port_log'] = log
    if 'watch_log' in st.session_state:
        st.subheader('관심종목 업데이트 로그')
        _locale.dataframe(st, st.session_state['watch_log'], width='stretch', hide_index=True)
        if st.button('관심종목 가격 적용'):
            save_csv(st.session_state['watch_preview'], 'watchlist.csv')
            st.success('적용했습니다. 이전 표 데이터는 백업에 보관됩니다.')
            st.session_state.pop('watch_preview', None)
            st.session_state.pop('watch_log', None)
            st.rerun()
    if 'port_log' in st.session_state:
        st.subheader('포트폴리오 업데이트 로그')
        _locale.dataframe(st, st.session_state['port_log'], width='stretch', hide_index=True)
        if st.button('포트폴리오 평가액 적용'):
            save_csv(st.session_state['port_preview'], 'portfolio.csv')
            st.success('적용했습니다. 이전 표 데이터는 백업에 보관됩니다.')
            st.session_state.pop('port_preview', None)
            st.session_state.pop('port_log', None)
            st.rerun()
    st.info('종목코드가 비어 있는 상장지수펀드/자산은 자동갱신하지 않고 수동 평가액을 유지합니다. 포트폴리오에서 종목코드를 입력하면 자동화 범위가 늘어납니다.')
