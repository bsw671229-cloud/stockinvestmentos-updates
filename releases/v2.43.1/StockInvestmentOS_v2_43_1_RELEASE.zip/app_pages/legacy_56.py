from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('투자 근거 등록부')
    ev = load_csv('evidence.csv')
    edited = _locale.editor(st, ev, num_rows='dynamic', width='stretch')
    if st.button('투자 근거 저장', type='primary'):
        verified_save_feedback(edited, 'evidence.csv', 'Evidence를 저장했습니다.')
