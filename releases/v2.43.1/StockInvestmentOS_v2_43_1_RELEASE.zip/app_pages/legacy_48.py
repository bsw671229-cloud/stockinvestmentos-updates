from __future__ import annotations
import ui_locale as _locale
from ui_korean import ko_text, ko_frame, ko_columns, ko_format
if True:
    st.title(ko_text('Decision Journal 2.0 / Forecast Calibration'))
    st.caption(ko_text('결정 당시의 정보·반대가설·Invalidation·Expected Outcome을 먼저 고정하고, Proof Date 이후 실제 결과와 Forecast Error를 별도로 검토합니다.'))
    st.info(_locale.message(ko_text('Good Outcome ≠ Good Decision. APPROVED 기록은 append-only + Hash 감사기록이며 Lifecycle, Add Freeze, Canonical, Portfolio, 주문을 자동 변경하지 않습니다.')))
    decision_records = normalize_decision_records(load_csv('decision_records.csv'))
    outcome_reviews = normalize_outcome_reviews(load_csv('decision_outcome_reviews.csv'))
    js2 = decision_journal_v2_summary(decision_records, outcome_reviews)
    j1, j2, j3, j4, j5 = st.columns(5)
    j1.metric(ko_text('APPROVED Decisions'), _locale.code(ko_text(js2['approved_decisions'])))
    j2.metric(ko_text('Open Outcomes'), _locale.code(ko_text(js2['open_outcomes'])))
    j3.metric(ko_text('Overdue Outcomes'), _locale.code(ko_text(js2['overdue_outcomes'])))
    j4.metric(ko_text('Reviewed'), _locale.code(ko_text(js2['reviewed_outcomes'])))
    j5.metric(ko_text('Integrity Issues'), _locale.code(ko_text(js2['integrity_issues'])))
    if watchlist.empty:
        st.warning(_locale.message(ko_text('Watchlist가 비어 있습니다.')))
    else:
        names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        handed = str(st.session_state.get('decision_journal_company', '') or '').strip()
        default_index = names.index(handed) if handed in names else 0
        company = st.selectbox(ko_text('Decision 종목'), names, index=default_index, key='decision_journal_company_select', format_func=ko_format())
        st.session_state['decision_journal_company'] = company
        wh = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(company)]
        wr = wh.iloc[0].to_dict() if not wh.empty else {}
        ticker = str(wr.get('ticker', '') or '').strip()
        plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
        kpis2 = normalize_kpis(load_csv('thesis_kpis.csv'))
        try:
            live = build_one_page_decision_summary(company=company, watchlist=watchlist, portfolio=portfolio, proof=proof, thesis_plans=plans, kpis=kpis2, total_assets=total_assets, loss_budget=loss_budget, single_name_cap=single_cap, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), pilot_fraction=float(settings.get('pilot_fraction', 0.5)), reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), stale_days=int(settings.get('kpi_stale_days', 120)), factor_loadings=factor_loadings)
        except Exception:
            live = {}
        ev_df = load_csv('evidence_packets.csv')
        impact_df = load_csv('evidence_impact_reviews.csv')
        latest_ev = latest_approved_packet(ev_df, company)
        latest_impact = latest_approved_impact_review(impact_df, ev_df, company)
        current_price = float(live.get('price', wr.get('price', 0)) or 0)
        bear_downside = float(live.get('downside', wr.get('bear_downside', 0)) or 0)
        risk_ceiling = int(float(live.get('risk_ceiling_shares', 0) or 0))
        executable = int(float(live.get('executable_shares', 0) or 0))
        lifecycle = str(live.get('lifecycle', 'OBSERVE') or 'OBSERVE').upper()
        add_freeze = str(live.get('add_freeze', '') or '')
        factor = str(live.get('factor', wr.get('factor', '')) or '')
        portfolio_fit = str(live.get('portfolio_fit', '') or '')
        st.subheader(ko_text('1. Current Snapshot'))
        s1, s2, s3, s4, s5, s6 = st.columns(6)
        s1.metric(ko_text('Price'), _locale.code(ko_text(krw(current_price))))
        s2.metric(ko_text('Lifecycle'), _locale.code(ko_text(lifecycle)))
        s3.metric(ko_text('Risk Ceiling'), _locale.code(ko_text(f'{risk_ceiling}주')))
        s4.metric(ko_text('Executable'), _locale.code(ko_text(f'{executable}주')))
        s5.metric(ko_text('Add Freeze'), _locale.code(ko_text(add_freeze or '-')))
        s6.metric(ko_text('Portfolio Fit'), _locale.code(ko_text(portfolio_fit or '-')))
        ev_ok = bool(latest_ev and latest_ev.get('hash_status') == 'OK')
        impact_ok = bool(latest_impact and latest_impact.get('hash_status') == 'OK' and (latest_impact.get('link_status') == 'MATCH'))
        st.caption(ko_text(f"Evidence Link: **{('PASS' if ev_ok else 'REVIEW')}** · Impact Link: **{('PASS' if impact_ok else 'REVIEW')}**"))
        pre_tab, outcome_tab, history_tab, learning_tab, feedback_tab, forecast_tab = st.tabs([ko_text(_label) for _label in ['Pre-decision Record', 'Outcome Review', 'History', 'Execution / Learning Lineage', 'Learning Feedback', 'Forecast Calibration']])
        with pre_tab:
            st.subheader(ko_text('2. Pre-decision Record'))
            c1, c2, c3 = st.columns(3)
            decision_date_value = c1.date_input(ko_text('Decision Date'), value=date.today(), key=f'dj2_date::{company}')
            type_index = DECISION_TYPES.index(lifecycle) if lifecycle in DECISION_TYPES else 0
            decision_type = c2.selectbox(ko_text('Decision Type'), DECISION_TYPES, index=type_index, key=f'dj2_type::{company}', format_func=ko_format())
            proof_default = date.today() + timedelta(days=90)
            if proof is not None and (not proof.empty):
                ph = proof.loc[proof['company'].fillna('').astype(str).eq(company)]
                if not ph.empty:
                    pdue = pd.to_datetime(ph['due_date'], errors='coerce').dropna()
                    if not pdue.empty:
                        proof_default = min((x.date() for x in pdue))
            proof_date_value = c3.date_input(ko_text('Expected Proof Date'), value=proof_default, key=f'dj2_proof::{company}')
            action = st.text_input(ko_text('현재 행동 / Decision Action'), value=str(live.get('current_action', '관찰 유지') or '관찰 유지'), key=f'dj2_action::{company}')
            thesis_default = ''
            invalidation_default = ''
            if not plans.empty:
                tph = plans.loc[plans['company'].fillna('').astype(str).eq(company)]
                if not tph.empty:
                    thesis_default = str(tph.iloc[-1].get('thesis_summary', '') or '')
                    invalidation_default = str(tph.iloc[-1].get('invalidation', '') or '')
            thesis = st.text_area(ko_text('Thesis'), value=thesis_default, key=f'dj2_thesis::{company}')
            counter = st.text_area(ko_text('Strongest Counter Case'), value=str(latest_impact.get('strongest_counter_case', '') or ''), key=f'dj2_counter::{company}')
            invalidation = st.text_area(ko_text('Invalidation / 틀렸다고 인정할 조건'), value=invalidation_default, key=f'dj2_invalidation::{company}')
            expected = st.text_area(ko_text('Expected Outcome / Proof Date까지 무엇이 확인되어야 하는가'), value='', key=f'dj2_expected::{company}')
            preview = {'company': company, 'ticker': ticker, 'decision_date': decision_date_value.isoformat(), 'decision_type': decision_type, 'lifecycle_state': lifecycle, 'action': action, 'current_price': current_price, 'bear_downside': bear_downside, 'risk_ceiling_shares': risk_ceiling, 'executable_shares': executable, 'add_freeze': add_freeze, 'factor': factor, 'portfolio_fit': portfolio_fit, 'evidence_id': str(latest_ev.get('evidence_id', '') or ''), 'evidence_hash_snapshot': str(latest_ev.get('content_hash', '') or ''), 'impact_review_id': str(latest_impact.get('review_id', '') or ''), 'impact_hash_snapshot': str(latest_impact.get('content_hash', '') or ''), 'thesis': thesis, 'strongest_counter_case': counter, 'invalidation': invalidation, 'expected_outcome': expected, 'proof_date': proof_date_value.isoformat()}
            dg = validate_decision_record(preview, for_approval=False)
            ag = validate_decision_record(preview, for_approval=True)
            g1, g2, g3 = st.columns(3)
            g1.metric(ko_text('Draft Gate'), _locale.code(ko_text('PASS' if dg['valid'] else 'REVIEW')))
            g2.metric(ko_text('Approval Gate'), _locale.code(ko_text('PASS' if ag['valid'] else 'REVIEW')))
            g3.metric(ko_text('Snapshot Link'), _locale.code(ko_text('PASS' if ev_ok and impact_ok else 'REVIEW')))
            if not ag['valid']:
                st.warning(_locale.message(ko_text('APPROVED 전 확인: ' + ' / '.join(ag['issues']))))
            reviewed = st.checkbox(ko_text('당시 정보·반대가설·Invalidation·Expected Outcome을 직접 검토했습니다.'), value=False, key=f'dj2_reviewed::{company}')
            save_status = 'APPROVED' if reviewed else 'DRAFT'
            st.write(ko_text(f'저장 상태: **{save_status}**'))
            if st.button(ko_text('새 Decision Record 저장'), type='primary', key=f'dj2_save::{company}'):
                try:
                    row = build_decision_record(company=company, ticker=ticker, decision_date=decision_date_value, decision_type=decision_type, lifecycle_state=lifecycle, action=action, current_price=current_price, bear_downside=bear_downside, risk_ceiling_shares=risk_ceiling, executable_shares=executable, add_freeze=add_freeze, factor=factor, portfolio_fit=portfolio_fit, evidence_id=str(latest_ev.get('evidence_id', '') or ''), evidence_hash_snapshot=str(latest_ev.get('content_hash', '') or ''), impact_review_id=str(latest_impact.get('review_id', '') or ''), impact_hash_snapshot=str(latest_impact.get('content_hash', '') or ''), thesis=thesis, strongest_counter_case=counter, invalidation=invalidation, expected_outcome=expected, proof_date=proof_date_value, review_status=save_status)
                    updated = pd.concat([decision_records[DECISION_RECORD_COLS], pd.DataFrame([row])], ignore_index=True)
                    verified_save_feedback(updated, 'decision_records.csv', ko_text(f'Decision Record를 {save_status} 상태로 저장했습니다.'), rerun=True)
                except Exception as e:
                    st.error(_locale.message(ko_text(f'Decision Record 저장 실패: {e}')))
        enriched_decisions = enrich_decision_records(decision_records, outcome_reviews)
        company_decisions = enriched_decisions.loc[enriched_decisions['company'].fillna('').astype(str).eq(company)].copy() if not enriched_decisions.empty else pd.DataFrame()
        with outcome_tab:
            st.subheader(ko_text('3. Outcome Review / Forecast Error'))
            approved = company_decisions.loc[company_decisions['review_status'].fillna('').astype(str).str.upper().eq('APPROVED')].copy() if not company_decisions.empty else pd.DataFrame()
            if approved.empty:
                st.info(_locale.message(ko_text('APPROVED Decision Record가 생기면 Outcome Review를 작성할 수 있습니다.')))
            else:
                lookup = {}
                labels = []
                for _, r in approved.iterrows():
                    label = f"{r.get('decision_date', '')} · {r.get('decision_type', '')} · {r.get('action', '')} · {r.get('outcome_status', '')}"
                    labels.append(label)
                    lookup[label] = r.to_dict()
                selected_label = st.selectbox(ko_text('검토할 Decision'), labels[::-1], key=f'dj2_out_target::{company}', format_func=ko_format())
                target = lookup[selected_label]
                if str(target.get('hash_status', '') or '').upper() != 'OK':
                    st.error(_locale.message(ko_text('선택한 Decision Record의 Hash가 정상이 아닙니다. Outcome Review보다 무결성을 먼저 확인하세요.')))
                else:
                    st.caption(ko_text(f"Expected Outcome: {target.get('expected_outcome', '-')} · Proof Date: {target.get('proof_date', '-')} · Proof Status: {target.get('proof_status', '-')}"))
                    o1, o2, o3 = st.columns(3)
                    out_date = o1.date_input(ko_text('Outcome Review Date'), value=date.today(), key='dj2_out_date::' + str(target.get('decision_id', '')))
                    out_class = o2.selectbox(ko_text('Outcome Classification'), OUTCOME_CLASSIFICATIONS, key='dj2_out_class::' + str(target.get('decision_id', '')), format_func=ko_format())
                    err_class = o3.selectbox(ko_text('Forecast Error Class'), FORECAST_ERROR_CLASSES, key='dj2_err::' + str(target.get('decision_id', '')), format_func=ko_format())
                    adherence = st.selectbox(ko_text('Process Adherence'), PROCESS_ADHERENCE, key='dj2_process::' + str(target.get('decision_id', '')), format_func=ko_format())
                    actual = st.text_area(ko_text('Actual Outcome / 실제로 무엇이 발생했는가'), value='', key='dj2_actual::' + str(target.get('decision_id', '')))
                    learning = st.text_area(ko_text('New Learning / 무엇을 모델에 반영할 것인가'), value='', key='dj2_learning::' + str(target.get('decision_id', '')))
                    next_action = st.text_area(ko_text('Next Action / 다음 검토 행동'), value='', key='dj2_next::' + str(target.get('decision_id', '')))
                    out_preview = {'decision_id': target.get('decision_id', ''), 'decision_hash_snapshot': target.get('content_hash', ''), 'company': company, 'review_date': out_date.isoformat(), 'actual_outcome': actual, 'outcome_classification': out_class, 'forecast_error_class': err_class, 'process_adherence': adherence, 'new_learning': learning, 'next_action': next_action}
                    odg = validate_outcome_review(out_preview, for_approval=False)
                    oag = validate_outcome_review(out_preview, for_approval=True)
                    og1, og2, og3 = st.columns(3)
                    og1.metric(ko_text('Draft Gate'), _locale.code(ko_text('PASS' if odg['valid'] else 'REVIEW')))
                    og2.metric(ko_text('Approval Gate'), _locale.code(ko_text('PASS' if oag['valid'] else 'REVIEW')))
                    og3.metric(ko_text('Decision Link'), _locale.code(ko_text('PASS')))
                    if not oag['valid']:
                        st.warning(_locale.message(ko_text('APPROVED 전 확인: ' + ' / '.join(oag['issues']))))
                    out_reviewed = st.checkbox(ko_text('Expected Outcome과 Actual Outcome을 비교하고 Forecast Error를 직접 검토했습니다.'), value=False, key='dj2_out_reviewed::' + str(target.get('decision_id', '')))
                    out_status = 'APPROVED' if out_reviewed else 'DRAFT'
                    st.write(ko_text(f'Outcome 저장 상태: **{out_status}**'))
                    if st.button(ko_text('새 Outcome Review 저장'), type='primary', key='dj2_out_save::' + str(target.get('decision_id', ''))):
                        try:
                            row = build_outcome_review(decision_id=str(target.get('decision_id', '') or ''), decision_hash_snapshot=str(target.get('content_hash', '') or ''), company=company, review_date=out_date, actual_outcome=actual, outcome_classification=out_class, forecast_error_class=err_class, process_adherence=adherence, new_learning=learning, next_action=next_action, review_status=out_status)
                            updated = pd.concat([outcome_reviews[OUTCOME_REVIEW_COLS], pd.DataFrame([row])], ignore_index=True)
                            verified_save_feedback(updated, 'decision_outcome_reviews.csv', ko_text(f'Outcome Review를 {out_status} 상태로 저장했습니다.'), rerun=True)
                        except Exception as e:
                            st.error(_locale.message(ko_text(f'Outcome Review 저장 실패: {e}')))
        with history_tab:
            st.subheader(ko_text('4. Decision Records'))
            if company_decisions.empty:
                st.info(_locale.message(ko_text('이 종목의 Decision Record가 없습니다.')))
            else:
                decision_cols = ['created_at', 'review_status', 'decision_date', 'decision_type', 'action', 'lifecycle_state', 'proof_date', 'proof_status', 'outcome_status', 'hash_status', 'current_price', 'risk_ceiling_shares', 'executable_shares']
                _locale.dataframe(st, ko_frame(company_decisions[[c for c in decision_cols if c in company_decisions.columns]].tail(50)), width='stretch', hide_index=True)
            st.subheader(ko_text('5. Outcome Review History'))
            enriched_outcomes = enrich_outcome_reviews(outcome_reviews, decision_records)
            company_outcomes = enriched_outcomes.loc[enriched_outcomes['company'].fillna('').astype(str).eq(company)].copy() if not enriched_outcomes.empty else pd.DataFrame()
            if company_outcomes.empty:
                st.info(_locale.message(ko_text('Outcome Review 기록이 없습니다.')))
            else:
                outcome_cols = ['created_at', 'review_status', 'review_date', 'outcome_classification', 'forecast_error_class', 'process_adherence', 'hash_status', 'link_status', 'new_learning', 'next_action']
                _locale.dataframe(st, ko_frame(company_outcomes[[c for c in outcome_cols if c in company_outcomes.columns]].tail(50)), width='stretch', hide_index=True)
        with learning_tab:
            st.subheader(ko_text('6. Packet → Fill → Post-Trade → Decision / Outcome Lineage'))
            st.caption(ko_text('실행 전 Packet, 실제 Fill, Post-Trade Audit, 당시 APPROVED Decision, 그리고 이후 Outcome Review / Forecast Error를 하나의 감사 Lineage로 연결합니다. 이 연결은 Portfolio·Lifecycle·주문권한을 변경하지 않습니다.'))
            _learning_post_hist = load_csv('pretrade_posttrade_lineage.csv')
            _learning_fill_hist = load_csv('pretrade_fill_lineage.csv')
            _learning_saved = load_csv('decision_learning_lineage.csv')
            _learning_candidates = []
            if not _learning_post_hist.empty and (not _learning_fill_hist.empty) and ('fill_lineage_id' in _learning_post_hist.columns) and ('lineage_id' in _learning_fill_hist.columns):
                for _pidx, _prow in _learning_post_hist.iterrows():
                    _flid = str(_prow.get('fill_lineage_id', '') or '').strip()
                    if not _flid:
                        continue
                    _fhit = _learning_fill_hist.loc[_learning_fill_hist['lineage_id'].fillna('').astype(str).str.strip().eq(_flid)]
                    if _fhit.empty:
                        continue
                    _frow = _fhit.iloc[-1].to_dict()
                    if str(_frow.get('fill_name', '') or '').strip() != company:
                        continue
                    _learning_candidates.append((_pidx, _prow.to_dict(), _frow))
            if not _learning_candidates:
                st.info(_locale.message(ko_text('이 종목에는 아직 Packet → Fill → Post-Trade Lineage가 없습니다. 실제 체결이 생긴 뒤 Fill Reconciliation과 Post-Trade Audit을 완료하면 여기서 연결할 수 있습니다.')))
            else:
                _learning_options = list(range(len(_learning_candidates)))

                def _learning_lineage_label(_opt):
                    _, _post, _fill = _learning_candidates[_opt]
                    return f"{_post.get('packet_id', '')} | Fill {_post.get('fill_id', '')} | Post-Trade {_post.get('post_trade_audit_status', '')} | Fill Lineage {_fill.get('lineage_status', '')}"
                _learning_choice = st.selectbox(ko_text('연결할 Execution Lineage'), options=_learning_options, index=0, format_func=ko_format(_learning_lineage_label), key=f'dj_learning_exec::{company}')
                _, _learning_post, _learning_fill = _learning_candidates[_learning_choice]
                _learning_fill_integrity = pretrade_fill_lineage_integrity(_learning_fill)
                _learning_post_integrity = pretrade_posttrade_lineage_integrity(_learning_post)
                el1, el2, el3, el4 = st.columns(4)
                el1.metric(ko_text('Fill Lineage Integrity'), _locale.code(ko_text(_learning_fill_integrity['status'])))
                el2.metric(ko_text('Post-Trade Lineage Integrity'), _locale.code(ko_text(_learning_post_integrity['status'])))
                el3.metric(ko_text('Locked Decision'), _locale.code(ko_text(str(_learning_fill.get('locked_decision_state', '') or '-'))))
                el4.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                _learning_approved = company_decisions.loc[company_decisions['review_status'].fillna('').astype(str).str.upper().eq('APPROVED')].copy() if not company_decisions.empty else pd.DataFrame()
                if _learning_approved.empty:
                    st.warning(_locale.message(ko_text('이 종목의 APPROVED Decision Record가 없습니다. 사후 결과에 맞춰 과거 결정을 새로 쓰지 말고, 실제 당시 존재했던 Decision Record만 연결하세요.')))
                else:
                    _decision_options = list(_learning_approved.index)

                    def _learning_decision_label(_idx):
                        _r = _learning_approved.loc[_idx]
                        return f"{_r.get('decision_date', '')} | {_r.get('decision_type', '')} | {_r.get('action', '')} | Hash {_r.get('hash_status', '')}"
                    _decision_idx = st.selectbox(ko_text('연결할 당시 APPROVED Decision Record'), options=_decision_options, format_func=ko_format(_learning_decision_label), key=f'dj_learning_decision::{company}')
                    _learning_decision = _learning_approved.loc[_decision_idx].to_dict()
                    _learning_outcomes = enrich_outcome_reviews(outcome_reviews, decision_records)
                    _learning_outcome_candidates = pd.DataFrame()
                    if not _learning_outcomes.empty and 'decision_id' in _learning_outcomes.columns:
                        _learning_outcome_candidates = _learning_outcomes.loc[_learning_outcomes['decision_id'].fillna('').astype(str).str.strip().eq(str(_learning_decision.get('decision_id', '') or '').strip())].copy()
                    _outcome_option_list = [-1]
                    if not _learning_outcome_candidates.empty:
                        _outcome_option_list += list(_learning_outcome_candidates.index[::-1])

                    def _learning_outcome_label(_idx):
                        if _idx == -1:
                            return 'Outcome 아직 연결 안 함 / Proof 대기'
                        _r = _learning_outcome_candidates.loc[_idx]
                        return f"{_r.get('review_date', '')} | {_r.get('outcome_classification', '')} | {_r.get('forecast_error_class', '')} | {_r.get('process_adherence', '')} | {_r.get('review_status', '')}"
                    _outcome_idx = st.selectbox(ko_text('연결할 Outcome Review'), options=_outcome_option_list, index=0, format_func=ko_format(_learning_outcome_label), key=f'dj_learning_outcome::{company}')
                    _learning_outcome = {} if _outcome_idx == -1 else _learning_outcome_candidates.loc[_outcome_idx].to_dict()
                    _learning_preview = evaluate_decision_learning_lineage(_learning_post, _learning_fill, _learning_decision, _learning_outcome)
                    lr1, lr2, lr3, lr4 = st.columns(4)
                    lr1.metric(ko_text('Learning Lineage'), _locale.code(ko_text(_learning_preview['learning_status'])))
                    lr2.metric(ko_text('Decision Hash'), _locale.code(ko_text(_learning_preview['decision_hash_status'] or '-')))
                    lr3.metric(ko_text('Outcome Link'), _locale.code(ko_text(_learning_preview['outcome_link_status'] or ('PENDING' if not _learning_preview['has_outcome'] else '-'))))
                    lr4.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                    if _learning_preview['has_outcome']:
                        lo1, lo2, lo3 = st.columns(3)
                        lo1.metric(ko_text('Outcome'), _locale.code(ko_text(_learning_preview['outcome_classification'] or '-')))
                        lo2.metric(ko_text('Forecast Error'), _locale.code(ko_text(_learning_preview['forecast_error_class'] or '-')))
                        lo3.metric(ko_text('Process Adherence'), _locale.code(ko_text(_learning_preview['process_adherence'] or '-')))
                    else:
                        st.info(_locale.message(ko_text('Outcome이 아직 없으면 OUTCOME_PENDING으로 저장할 수 있습니다. Proof Date 이후 APPROVED Outcome Review가 생기면 새 LEARNING_COMPLETE 기록을 append 하세요.')))
                    if _learning_preview['learning_status'] == 'LEARNING_COMPLETE':
                        st.success(_locale.message(ko_text('LEARNING_COMPLETE · Decision 당시 예상과 실제 결과, Forecast Error, Process Adherence까지 연결됐습니다.')))
                    elif _learning_preview['learning_status'] == 'OUTCOME_PENDING':
                        st.info(_locale.message(ko_text('OUTCOME_PENDING · Execution Lineage와 당시 Decision은 연결됐고 Outcome/Proof는 아직 열려 있습니다.')))
                    elif _learning_preview['learning_status'] == 'INVALIDATED':
                        st.error(_locale.message(ko_text('INVALIDATED · upstream execution lineage 무결성 문제가 있어 학습기록 연결에 사용할 수 없습니다.')))
                    else:
                        st.warning(_locale.message(ko_text('REVIEW · Decision/Outcome/Execution lineage 연결 조건을 확인하세요.')))
                    if _learning_preview['issues']:
                        st.warning(_locale.message(ko_text('Learning Lineage 사유 · ' + ' | '.join(_learning_preview['issues']))))
                    _learning_human = st.checkbox(ko_text('Execution Lineage와 당시 Decision, 선택한 Outcome/Forecast Error를 직접 대조했습니다.'), value=False, key=f'dj_learning_human::{company}')
                    _learning_note = st.text_input(ko_text('Learning Lineage 메모'), value='', key=f'dj_learning_note::{company}', placeholder='예: 실제 과거 연결 이력 / 과거 기록의 사후 변경 금지')
                    _learning_review = validate_learning_lineage_review(_learning_preview, human_review_confirmed=_learning_human)
                    lg1, lg2, lg3 = st.columns(3)
                    lg1.metric(ko_text('Learning Review Gate'), _locale.code(ko_text(_learning_review['review_gate'])))
                    lg2.metric(ko_text('Save Status'), _locale.code(ko_text(_learning_review['save_status'])))
                    lg3.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                    if _learning_review['issues']:
                        st.warning(_locale.message(ko_text('저장 전 확인 · ' + ' | '.join(_learning_review['issues']))))
                    if st.button(ko_text('Decision Learning Lineage 기록 저장'), disabled=_learning_review['review_gate'] != 'PASS', key=f'dj_learning_save::{company}'):
                        _learning_row = build_decision_learning_lineage_record(_learning_preview, _learning_review, human_review_confirmed=_learning_human, note=_learning_note)
                        _learning_hist = load_csv('decision_learning_lineage.csv')
                        for _col in DECISION_LEARNING_LINEAGE_COLS:
                            if _col not in _learning_hist.columns:
                                _learning_hist[_col] = ''
                        _learning_hist = pd.concat([_learning_hist[DECISION_LEARNING_LINEAGE_COLS], pd.DataFrame([_learning_row])], ignore_index=True)
                        verified_save_feedback(_learning_hist, 'decision_learning_lineage.csv', ko_text(f"Decision Learning Lineage 저장 · {_learning_row['learning_status']} · Execution Authorization = NONE."), rerun=False)
            if not _learning_saved.empty:
                st.subheader(ko_text('7. Saved Decision Learning Lineage'))
                _learning_view = _learning_saved.copy()
                if 'company' in _learning_view.columns:
                    _learning_view = _learning_view.loc[_learning_view['company'].fillna('').astype(str).eq(company)]
                if _learning_view.empty:
                    st.caption(ko_text('이 종목의 저장된 Learning Lineage는 아직 없습니다.'))
                else:
                    _locale.dataframe(st, ko_frame(_learning_view.tail(30)), width='stretch', hide_index=True)
                    _learning_latest = _learning_view.iloc[-1].to_dict()
                    _learning_integrity = decision_learning_lineage_integrity(_learning_latest)
                    st.caption(ko_text(f"Latest Learning Lineage Integrity · {_learning_integrity['status']}"))
            st.caption(ko_text('Forecast Error는 Model / Parameter / Execution / Exogenous 등 기존 Decision Journal 분류를 그대로 보존합니다. 좋은 결과가 좋은 결정임을 뜻하지 않으며, 사후 결과로 당시 Decision Record를 재작성하지 않습니다.'))
        with feedback_tab:
            st.subheader(ko_text('8. Learning Feedback / Assumption Change Proposal'))
            st.caption(ko_text('LEARNING_COMPLETE 기록의 Forecast Error / Process Adherence를 근거로 다음 검토 대상을 제안합니다. 이 화면은 Forward ER·Risk Penalty·Hurdle·Thesis·Position Size를 자동 변경하지 않으며 실제 변경은 각 원본 Revalidation/Review 화면에서 다시 승인해야 합니다.'))
            _feedback_lineage = load_csv('decision_learning_lineage.csv')
            _feedback_saved = load_csv('learning_feedback_proposals.csv')
            if _feedback_lineage.empty:
                st.info(_locale.message(ko_text('Learning Feedback의 원본이 없습니다. 실제 Fill → Post-Trade → Decision / Outcome Lineage가 LEARNING_COMPLETE가 된 뒤 사용하세요.')))
            else:
                if 'company' not in _feedback_lineage.columns:
                    _feedback_lineage['company'] = ''
                if 'learning_status' not in _feedback_lineage.columns:
                    _feedback_lineage['learning_status'] = ''
                _feedback_candidates = _feedback_lineage.loc[_feedback_lineage['company'].fillna('').astype(str).eq(company) & _feedback_lineage['learning_status'].fillna('').astype(str).str.upper().eq('LEARNING_COMPLETE')].copy()
                if _feedback_candidates.empty:
                    st.info(_locale.message(ko_text('이 종목에는 아직 LEARNING_COMPLETE 기록이 없습니다. Outcome Review가 완료되기 전에는 Assumption Change Proposal을 만들지 않습니다.')))
                else:
                    _feedback_indices = list(_feedback_candidates.index[::-1])

                    def _feedback_label(_idx):
                        _r = _feedback_candidates.loc[_idx]
                        return f"{_r.get('learning_lineage_id', '')} | Error {_r.get('forecast_error_class', '')} | Process {_r.get('process_adherence', '')} | Outcome {_r.get('outcome_classification', '')}"
                    _feedback_idx = st.selectbox(ko_text('Feedback 원본 LEARNING_COMPLETE Lineage'), options=_feedback_indices, index=0, format_func=ko_format(_feedback_label), key=f'learning_feedback_source::{company}')
                    _feedback_source_row = _feedback_candidates.loc[_feedback_idx].to_dict()
                    _feedback_source = learning_feedback_source_context(_feedback_source_row)
                    fb1, fb2, fb3, fb4 = st.columns(4)
                    fb1.metric(ko_text('Source Integrity'), _locale.code(ko_text(_feedback_source['source_integrity_status'])))
                    fb2.metric(ko_text('Forecast Error'), _locale.code(ko_text(_feedback_source['forecast_error_class'] or '-')))
                    fb3.metric(ko_text('Review Lane'), _locale.code(ko_text(_feedback_source['review_lane'])))
                    fb4.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                    fb5, fb6, fb7 = st.columns(3)
                    fb5.metric(ko_text('Outcome'), _locale.code(ko_text(_feedback_source['outcome_classification'] or '-')))
                    fb6.metric(ko_text('Process Adherence'), _locale.code(ko_text(_feedback_source['process_adherence'] or '-')))
                    fb7.metric(ko_text('Source Gate'), _locale.code(ko_text(_feedback_source['source_gate'])))
                    if _feedback_source['issues']:
                        st.warning(_locale.message(ko_text('Feedback Source 사유 · ' + ' | '.join(_feedback_source['issues']))))
                    st.markdown(ko_text('**원본 Learning 요약**'))
                    _learning_summary_df = pd.DataFrame([{'Actual Outcome': _feedback_source['actual_outcome'], 'New Learning': _feedback_source['new_learning'], 'Recorded Next Action': _feedback_source['next_action']}])
                    _locale.dataframe(st, ko_frame(_learning_summary_df), width='stretch', hide_index=True)
                    t1, t2, t3 = st.columns(3)
                    _feedback_target = t1.selectbox(ko_text('Feedback Target'), LEARNING_FEEDBACK_TARGETS, index=0, key=f'learning_feedback_target::{company}', format_func=ko_format())
                    _feedback_direction = t2.selectbox(ko_text('Change Direction'), LEARNING_FEEDBACK_DIRECTIONS, index=0, key=f'learning_feedback_direction::{company}', format_func=ko_format())
                    _feedback_delta = t3.number_input(ko_text('Proposed Delta (decimal)'), min_value=0.0, max_value=1.0, value=0.0, step=0.005, format='%.3f', key=f'learning_feedback_delta::{company}', help='예: 0.010 = 1.0%p. 실제 값 변경이 아니라 재검증 제안용입니다.')
                    _feedback_due = st.date_input(ko_text('Revalidation / Review Due Date'), value=date.today() + timedelta(days=30), key=f'learning_feedback_due::{company}')
                    _feedback_rationale = st.text_area(ko_text('Feedback Rationale'), value='', key=f'learning_feedback_rationale::{company}', height=100, placeholder='기대 결과 대비 실제 결과, 예측 오차, 절차 준수를 근거로 왜 이 대상을 재검토해야 하는지 기록.')
                    fc1, fc2 = st.columns(2)
                    _feedback_confirm_expected = fc1.checkbox(ko_text('Expected Outcome과 Actual Outcome / Forecast Error를 직접 대조했습니다.'), value=False, key=f'learning_feedback_confirm_expected::{company}')
                    _feedback_confirm_no_auto = fc2.checkbox(ko_text('이 Proposal은 원본 Assumption / Thesis / Risk Budget을 자동 변경하지 않음을 확인했습니다.'), value=False, key=f'learning_feedback_confirm_no_auto::{company}')
                    fc3, fc4 = st.columns(2)
                    _feedback_confirm_no_exec = fc3.checkbox(ko_text('이 Proposal은 Execution Authorization을 생성하지 않음을 확인했습니다.'), value=False, key=f'learning_feedback_confirm_no_exec::{company}')
                    _feedback_confirm_human = fc4.checkbox(ko_text('현재 Learning Feedback Proposal을 최종 Human Review했습니다.'), value=False, key=f'learning_feedback_confirm_human::{company}')
                    _feedback_note = st.text_input(ko_text('Learning Feedback 메모'), value='', key=f'learning_feedback_note::{company}', placeholder='예: 출처 학습 검토됨 / 재검증 전용 / 금지 자동-적용')
                    _feedback_review = validate_learning_feedback_proposal(_feedback_source, feedback_target=_feedback_target, change_direction=_feedback_direction, proposed_delta=_feedback_delta, review_due_date=_feedback_due.isoformat(), rationale=_feedback_rationale, expected_vs_actual_confirmed=_feedback_confirm_expected, no_auto_apply_confirmed=_feedback_confirm_no_auto, no_execution_authorization_confirmed=_feedback_confirm_no_exec, human_review_confirmed=_feedback_confirm_human)
                    fg1, fg2, fg3, fg4 = st.columns(4)
                    fg1.metric(ko_text('Proposal Gate'), _locale.code(ko_text(_feedback_review['proposal_gate'])))
                    fg2.metric(ko_text('Proposal Status'), _locale.code(ko_text(_feedback_review['proposal_status'])))
                    fg3.metric(ko_text('Next Gate'), _locale.code(ko_text(_feedback_review['next_gate'])))
                    fg4.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                    st.caption(ko_text('Review Lane은 Forecast Error의 감사 분류이고, Next Gate는 사용자가 선택한 Target의 실제 재검토 위치입니다. 둘이 같지 않아도 자동 변경하지 않으며 Human Review 기록으로만 남깁니다.'))
                    if _feedback_review['issues']:
                        st.warning(_locale.message(ko_text('Proposal 저장 전 확인 · ' + ' | '.join(_feedback_review['issues']))))
                    else:
                        st.success(_locale.message(ko_text('Proposal Gate PASS · 원본 값은 변경되지 않았고 다음 Revalidation/Review Gate로 넘길 기록만 준비되었습니다.')))
                    if st.button(ko_text('Learning Feedback Proposal 저장'), disabled=_feedback_review['proposal_gate'] != 'PASS', key=f'learning_feedback_save::{company}'):
                        _feedback_row = build_learning_feedback_record(_feedback_source, _feedback_review, feedback_target=_feedback_target, change_direction=_feedback_direction, proposed_delta=_feedback_delta, review_due_date=_feedback_due.isoformat(), rationale=_feedback_rationale, expected_vs_actual_confirmed=_feedback_confirm_expected, no_auto_apply_confirmed=_feedback_confirm_no_auto, no_execution_authorization_confirmed=_feedback_confirm_no_exec, human_review_confirmed=_feedback_confirm_human, note=_feedback_note)
                        _feedback_hist = load_csv('learning_feedback_proposals.csv')
                        for _col in LEARNING_FEEDBACK_COLS:
                            if _col not in _feedback_hist.columns:
                                _feedback_hist[_col] = ''
                        _feedback_hist = pd.concat([_feedback_hist[LEARNING_FEEDBACK_COLS], pd.DataFrame([_feedback_row])], ignore_index=True)
                        verified_save_feedback(_feedback_hist, 'learning_feedback_proposals.csv', ko_text(f"Learning Feedback Proposal 저장 · {_feedback_row['proposal_status']} · Next Gate {_feedback_row['next_gate']} · Execution Authorization = NONE."), rerun=False)
            if not _feedback_saved.empty:
                st.subheader(ko_text('9. Saved Learning Feedback Proposals'))
                _feedback_view = _feedback_saved.copy()
                if 'company' in _feedback_view.columns:
                    _feedback_view = _feedback_view.loc[_feedback_view['company'].fillna('').astype(str).eq(company)]
                if _feedback_view.empty:
                    st.caption(ko_text('이 종목의 저장된 Learning Feedback Proposal은 없습니다.'))
                else:
                    _locale.dataframe(st, ko_frame(_feedback_view.tail(30)), width='stretch', hide_index=True)
                    _latest_feedback = _feedback_view.iloc[-1].to_dict()
                    _latest_feedback_integrity = learning_feedback_record_integrity(_latest_feedback)
                    st.caption(ko_text(f"Latest Learning Feedback Integrity · {_latest_feedback_integrity['status']}"))
            st.info(_locale.message(ko_text('v1.22.0-dev1은 Learning → Change Proposal까지만 연결합니다. Forward ER / Risk Penalty / Hurdle / Thesis / Position Size의 실제 변경은 자동 적용하지 않습니다.')))
        with forecast_tab:
            st.subheader(ko_text('10. Forecast Calibration / Error Recurrence Monitor'))
            st.caption(ko_text('LEARNING_COMPLETE 기록의 Forecast Error를 일정 기간 Cohort로 묶어 반복 패턴을 확인합니다. 반복은 Model/Parameter/Execution/Exogenous 재검토 신호일 뿐 자동 Assumption 변경이나 투자 행동 지시가 아닙니다.'))
            _fc_result = build_forecast_error_recurrence(load_csv('decision_learning_lineage.csv'), lookback_days=365, min_repeat_count=3, today=date.today())
            fc1, fc2, fc3, fc4, fc5 = st.columns(5)
            fc1.metric(ko_text('Forecast Audit'), _locale.code(ko_text(_fc_result['audit_status'])))
            fc2.metric(ko_text('Valid Learning'), _locale.code(ko_text(_fc_result['valid_learning_records'])))
            fc3.metric(ko_text('Integrity Issues'), _locale.code(ko_text(_fc_result['integrity_issues'])))
            fc4.metric(ko_text('Recurring Patterns'), _locale.code(ko_text(_fc_result['recurring_patterns'])))
            fc5.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
            st.caption(ko_text(f"Lookback {_fc_result['lookback_days']} days · Recurrence threshold {_fc_result['min_repeat_count']} records · Process FOLLOWED 상태에서도 발생한 Error records {_fc_result['process_followed_error_records']}"))
            if _fc_result['audit_status'] == 'NO_DATA':
                st.info(_locale.message(ko_text('아직 유효한 LEARNING_COMPLETE 기록이 없습니다. 실제 Outcome/Forecast Error가 축적되기 전에는 Recurrence를 판단하지 않습니다.')))
            elif _fc_result['audit_status'] == 'INTEGRITY_REVIEW':
                st.error(_locale.message(ko_text('Forecast Calibration 원본 Learning Lineage Hash 무결성 확인이 필요합니다.')))
            elif _fc_result['audit_status'] == 'REVIEW':
                st.warning(_locale.message(ko_text('동일 Forecast Error가 반복된 Cohort가 있습니다. 아래 Review Lane에서 공통 원인과 Source/Evidence를 독립적으로 재검토하세요.')))
            else:
                st.success(_locale.message(ko_text('현재 설정한 최소 반복횟수 기준으로 Recurring Forecast Error pattern이 없습니다.')))
            _fc_cohort = _fc_result['cohort']
            if not _fc_cohort.empty:
                _fc_company_view = _fc_cohort.loc[_fc_cohort['scope'].eq('GLOBAL') | _fc_cohort['scope'].eq('COMPANY') & _fc_cohort['company'].eq(company)].copy()
                if not _fc_company_view.empty:
                    _fc_display = _fc_company_view.copy()
                    _fc_display['error_share'] = pd.to_numeric(_fc_display['error_share'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.1%}')
                    _locale.dataframe(st, ko_frame(_fc_display), width='stretch', hide_index=True)
            _fc_note = st.text_input(ko_text('Forecast Calibration Snapshot 메모'), value='', key=f'forecast_calibration_note::{company}', placeholder='예: 예정됨 반복 검토 / 금지 자동 매개변수 변경')
            if st.button(ko_text('Forecast Calibration Snapshot 저장'), key=f'forecast_calibration_snapshot_save::{company}'):
                _fc_row = build_forecast_recurrence_snapshot(_fc_result, note=_fc_note)
                _fc_hist = load_csv('forecast_error_recurrence_snapshots.csv')
                for _col in FORECAST_RECURRENCE_SNAPSHOT_COLS:
                    if _col not in _fc_hist.columns:
                        _fc_hist[_col] = ''
                _fc_hist = pd.concat([_fc_hist[FORECAST_RECURRENCE_SNAPSHOT_COLS], pd.DataFrame([_fc_row])], ignore_index=True)
                verified_save_feedback(_fc_hist, 'forecast_error_recurrence_snapshots.csv', ko_text(f"Forecast Calibration Snapshot 저장 · {_fc_row['audit_status']} · Recurring {_fc_row['recurring_patterns']} · Execution Authorization = NONE."), rerun=False)
            _fc_saved = load_csv('forecast_error_recurrence_snapshots.csv')
            if not _fc_saved.empty:
                with st.expander(ko_text('Forecast Calibration 최근 Snapshot'), expanded=False):
                    _locale.dataframe(st, ko_frame(_fc_saved.tail(20)), width='stretch', hide_index=True)
            st.subheader(ko_text('11. Forecast Change Registry / Implementation Review'))
            st.caption(ko_text("반복 Forecast Error를 근거로 '변경 계획'만 append-only로 등록합니다. 이 Registry는 Model logic, Assumption parameter, Execution process, Evidence monitoring을 자동 변경하지 않습니다."))
            _fcr_recurring = pd.DataFrame()
            if isinstance(_fc_cohort, pd.DataFrame) and (not _fc_cohort.empty):
                _fcr_recurring = _fc_cohort.loc[_fc_cohort['recurrence_status'].fillna('').astype(str).eq('REVIEW') & (_fc_cohort['scope'].eq('GLOBAL') | _fc_cohort['scope'].eq('COMPANY') & _fc_cohort['company'].eq(company))].copy()
            if _fcr_recurring.empty:
                st.info(_locale.message(ko_text('현재 이 종목/전역에서 Change Registry로 넘길 반복 Forecast Error pattern이 없습니다.')))
            else:
                _fcr_indices = list(_fcr_recurring.index)

                def _fcr_label(_idx):
                    _r = _fcr_recurring.loc[_idx]
                    return f"{_r.get('scope', '')} | {_r.get('company', '')} | {_r.get('forecast_error_class', '')} | {int(_r.get('error_count', 0) or 0)}/{int(_r.get('sample_size', 0) or 0)}"
                _fcr_idx = st.selectbox(ko_text('변경 계획의 원본 Recurring Cohort'), options=_fcr_indices, format_func=ko_format(_fcr_label), key=f'forecast_change_cohort::{company}')
                _fcr_source = _fcr_recurring.loc[_fcr_idx].to_dict()
                _fcr_expected_area = expected_change_area(_fcr_source.get('forecast_error_class', ''))
                cr1, cr2, cr3, cr4 = st.columns(4)
                cr1.metric(ko_text('Error Class'), _locale.code(ko_text(str(_fcr_source.get('forecast_error_class', '')))))
                cr2.metric(ko_text('Repeat Count'), _locale.code(ko_text(int(_fcr_source.get('error_count', 0) or 0))))
                cr3.metric(ko_text('Expected Change Area'), _locale.code(ko_text(_fcr_expected_area)))
                cr4.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                _fcr_change_area = st.selectbox(ko_text('Change Area'), FORECAST_CHANGE_AREAS, index=FORECAST_CHANGE_AREAS.index(_fcr_expected_area) if _fcr_expected_area in FORECAST_CHANGE_AREAS else 0, key=f'forecast_change_area::{company}', format_func=ko_format())
                _fcr_change_target = st.text_input(ko_text('Change Target'), value='', key=f'forecast_change_target::{company}', placeholder='예: 예상 수익률 보정 방법 / 이익률 점진적 감소 로직 / 실행 점검표 / 투자 근거 발동 조건')
                _fcr_baseline = st.text_area(ko_text('Baseline Description'), value='', key=f'forecast_change_baseline::{company}', height=90, placeholder='변경 전 모형/매개변수/절차/투자 근거 조건을 구체적으로 기록')
                _fcr_change = st.text_area(ko_text('Proposed Change'), value='', key=f'forecast_change_proposal::{company}', height=90, placeholder='반복 오류가 다시 발생하지 않게 하기 위해 검토할 변경 계획. 실제 적용값이 아님.')
                _fcr_expected = st.text_area(ko_text('Expected Improvement / Proof'), value='', key=f'forecast_change_expected::{company}', height=90, placeholder='어떤 새로운 결과/보정 데이터가 나오면 변경이 개선됐다고 볼지 사전에 기록')
                _fcr_proof_date = st.date_input(ko_text('Change Proof Date'), value=date.today() + timedelta(days=90), key=f'forecast_change_proof::{company}')
                crc1, crc2 = st.columns(2)
                _fcr_source_confirm = crc1.checkbox(ko_text('선택한 Recurring Cohort의 Error Class / Count / Process Adherence를 직접 확인했습니다.'), value=False, key=f'forecast_change_source_confirm::{company}')
                _fcr_no_auto = crc2.checkbox(ko_text('이 Registry는 Model / Assumption / Process / Evidence rule을 자동 변경하지 않음을 확인했습니다.'), value=False, key=f'forecast_change_no_auto::{company}')
                crc3, crc4 = st.columns(2)
                _fcr_no_exec = crc3.checkbox(ko_text('이 Change Plan은 Execution Authorization을 생성하지 않음을 확인했습니다.'), value=False, key=f'forecast_change_no_exec::{company}')
                _fcr_human = crc4.checkbox(ko_text('현재 Forecast Change Plan을 최종 Human Review했습니다.'), value=False, key=f'forecast_change_human::{company}')
                _fcr_note = st.text_input(ko_text('Forecast Change Plan 메모'), value='', key=f'forecast_change_note::{company}', placeholder='예: 계획 전용 / 이행에는 별도의 출처 검토 필요')
                _fcr_validation = validate_forecast_change_plan(_fcr_source, change_area=_fcr_change_area, change_target=_fcr_change_target, baseline_description=_fcr_baseline, proposed_change=_fcr_change, expected_improvement=_fcr_expected, proof_date=_fcr_proof_date.isoformat(), source_pattern_confirmed=_fcr_source_confirm, no_auto_apply_confirmed=_fcr_no_auto, no_execution_authorization_confirmed=_fcr_no_exec, human_review_confirmed=_fcr_human, today=date.today())
                cg1, cg2, cg3, cg4 = st.columns(4)
                cg1.metric(ko_text('Change Plan Gate'), _locale.code(ko_text(_fcr_validation['plan_gate'])))
                cg2.metric(ko_text('Plan Status'), _locale.code(ko_text(_fcr_validation['plan_status'])))
                cg3.metric(ko_text('Next Gate'), _locale.code(ko_text(_fcr_validation['next_gate'])))
                cg4.metric(ko_text('Implementation'), _locale.code(ko_text(_fcr_validation['implementation_status'])))
                if _fcr_validation['issues']:
                    st.warning(_locale.message(ko_text('Change Plan 저장 전 확인 · ' + ' | '.join(_fcr_validation['issues']))))
                else:
                    st.success(_locale.message(ko_text('Change Plan Gate PASS · 변경 계획만 Registry에 등록되며 실제 구현/적용은 별도 Review입니다.')))
                if st.button(ko_text('Forecast Change Plan Registry 저장'), disabled=_fcr_validation['plan_gate'] != 'PASS', key=f'forecast_change_registry_save::{company}'):
                    _fcr_row = build_forecast_change_plan_record(_fcr_source, _fcr_validation, change_area=_fcr_change_area, change_target=_fcr_change_target, baseline_description=_fcr_baseline, proposed_change=_fcr_change, expected_improvement=_fcr_expected, proof_date=_fcr_proof_date.isoformat(), source_pattern_confirmed=_fcr_source_confirm, no_auto_apply_confirmed=_fcr_no_auto, no_execution_authorization_confirmed=_fcr_no_exec, human_review_confirmed=_fcr_human, note=_fcr_note)
                    _fcr_hist = load_csv('forecast_change_registry.csv')
                    for _col in FORECAST_CHANGE_PLAN_COLS:
                        if _col not in _fcr_hist.columns:
                            _fcr_hist[_col] = ''
                    _fcr_hist = pd.concat([_fcr_hist[FORECAST_CHANGE_PLAN_COLS], pd.DataFrame([_fcr_row])], ignore_index=True)
                    verified_save_feedback(_fcr_hist, 'forecast_change_registry.csv', ko_text(f"Forecast Change Plan 저장 · {_fcr_row['plan_status']} · Area {_fcr_row['change_area']} · Execution Authorization = NONE."), rerun=False)
            _fcr_saved = load_csv('forecast_change_registry.csv')
            if not _fcr_saved.empty:
                _fcr_company_saved = _fcr_saved.loc[_fcr_saved['company'].fillna('').astype(str).isin([company, 'ALL'])].copy() if 'company' in _fcr_saved.columns else _fcr_saved.copy()
                if not _fcr_company_saved.empty:
                    with st.expander(ko_text('Forecast Change Registry 최근 기록'), expanded=False):
                        _locale.dataframe(st, ko_frame(_fcr_company_saved.tail(20)), width='stretch', hide_index=True)
                        _fcr_latest = _fcr_company_saved.iloc[-1].to_dict()
                        _fcr_integrity = forecast_change_plan_integrity(_fcr_latest)
                        st.caption(ko_text(f"Latest Change Plan Integrity · {_fcr_integrity['status']}"))
            st.subheader(ko_text('12. Change Implementation Event / Before-After Cohort Lock'))
            st.caption(ko_text('Forecast Change Plan 이후 실제 원본 Review에서 변경이 구현됐는지 또는 변경하지 않기로 결정했는지를 append-only Event로 기록합니다. 구현 이벤트가 있어도 Model/Assumption/Process/Evidence를 이 화면에서 변경하지 않습니다.'))
            _fci_plans = load_csv('forecast_change_registry.csv')
            _fci_events = load_csv('forecast_change_implementation_events.csv')
            if _fci_plans.empty:
                st.info(_locale.message(ko_text('Implementation Event 대상으로 사용할 Forecast Change Plan이 없습니다.')))
            else:
                for _col in FORECAST_CHANGE_PLAN_COLS:
                    if _col not in _fci_plans.columns:
                        _fci_plans[_col] = ''
                _fci_candidates = _fci_plans.loc[_fci_plans['plan_status'].fillna('').astype(str).str.upper().eq('REGISTERED_FOR_IMPLEMENTATION_REVIEW') & _fci_plans['company'].fillna('').astype(str).isin([company, 'ALL'])].copy()
                if _fci_candidates.empty:
                    st.info(_locale.message(ko_text('이 종목/전역에 REGISTERED_FOR_IMPLEMENTATION_REVIEW Change Plan이 없습니다.')))
                else:
                    _fci_indices = list(_fci_candidates.index[::-1])

                    def _fci_label(_idx):
                        _r = _fci_candidates.loc[_idx]
                        return f"{_r.get('change_plan_id', '')} | {_r.get('forecast_error_class', '')} | {_r.get('change_area', '')} | Proof {_r.get('proof_date', '')}"
                    _fci_idx = st.selectbox(ko_text('Implementation Event 대상 Change Plan'), options=_fci_indices, index=0, format_func=ko_format(_fci_label), key=f'forecast_implementation_plan::{company}')
                    _fci_plan = _fci_candidates.loc[_fci_idx].to_dict()
                    _fci_plan_integrity = forecast_change_plan_integrity(_fci_plan)
                    _fci_latest = latest_forecast_implementation(_fci_events, str(_fci_plan.get('change_plan_id', '') or ''))
                    ic1, ic2, ic3, ic4 = st.columns(4)
                    ic1.metric(ko_text('Plan Integrity'), _locale.code(ko_text(_fci_plan_integrity['status'])))
                    ic2.metric(ko_text('Baseline Samples'), _locale.code(ko_text(int(pd.to_numeric(pd.Series([_fci_plan.get('source_sample_size', 0)]), errors='coerce').fillna(0).iloc[0]))))
                    ic3.metric(ko_text('Baseline Error Share'), _locale.code(ko_text(f"{float(pd.to_numeric(pd.Series([_fci_plan.get('source_error_share', 0)]), errors='coerce').fillna(0).iloc[0]):.1%}")))
                    ic4.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                    if _fci_latest:
                        _fci_latest_integrity = forecast_implementation_integrity(_fci_latest)
                        st.caption(ko_text(f"Latest Event · {_fci_latest.get('implementation_id', '')} · Status {_fci_latest.get('implementation_status', '')} · Integrity {_fci_latest_integrity['status']}"))
                    _fci_action = st.selectbox(ko_text('Implementation Action'), FORECAST_IMPLEMENTATION_ACTIONS, index=0, key=f'forecast_implementation_action::{company}', format_func=ko_format())
                    _fci_date = st.date_input(ko_text('Actual Implementation / Review Date'), value=date.today(), key=f'forecast_implementation_date::{company}')
                    _fci_reference = st.text_input(ko_text('Implementation / Source Review Reference'), value='', key=f'forecast_implementation_reference::{company}', placeholder='예: 승인됨 보정 식별번호 / 모형 검토 문서 / 절차 검토 기록 / 투자 근거 검토 식별번호')
                    _fci_summary = st.text_area(ko_text('Implementation / Review Summary'), value='', key=f'forecast_implementation_summary::{company}', height=90, placeholder='실제 원본 검토에서 무엇이 바뀌었는지, 또는 왜 변경하지 않기로 했는지 기록')
                    ii1, ii2 = st.columns(2)
                    _fci_baseline_confirm = ii1.checkbox(ko_text('Change Plan의 source sample / error count / error share를 Before Baseline으로 잠그는 것을 확인했습니다.'), value=False, key=f'forecast_implementation_baseline_confirm::{company}')
                    _fci_source_confirm = ii2.checkbox(ko_text('실제 원본 Model / Assumption / Process / Evidence Review 결과를 직접 확인했습니다.'), value=False, key=f'forecast_implementation_source_confirm::{company}')
                    ii3, ii4 = st.columns(2)
                    _fci_no_auto = ii3.checkbox(ko_text('이 Event는 원본 설정을 자동 적용하거나 수정하지 않음을 확인했습니다.'), value=False, key=f'forecast_implementation_no_auto::{company}')
                    _fci_no_exec = ii4.checkbox(ko_text('이 Event는 Execution Authorization을 생성하지 않음을 확인했습니다.'), value=False, key=f'forecast_implementation_no_exec::{company}')
                    _fci_human = st.checkbox(ko_text('현재 Forecast Change Implementation Event를 최종 Human Review했습니다.'), value=False, key=f'forecast_implementation_human::{company}')
                    _fci_note = st.text_input(ko_text('Implementation Event 메모'), value='', key=f'forecast_implementation_note::{company}', placeholder='예: 외부 이행 확인됨 / 기준 상태 고정됨 / 금지 자동-적용')
                    _fci_validation = validate_forecast_implementation_event(_fci_plan, implementation_action=_fci_action, implementation_date=_fci_date.isoformat(), implementation_reference=_fci_reference, implementation_summary=_fci_summary, baseline_locked_confirmed=_fci_baseline_confirm, source_review_confirmed=_fci_source_confirm, no_auto_apply_confirmed=_fci_no_auto, no_execution_authorization_confirmed=_fci_no_exec, human_review_confirmed=_fci_human, today=date.today())
                    ig1, ig2, ig3 = st.columns(3)
                    ig1.metric(ko_text('Implementation Gate'), _locale.code(ko_text(_fci_validation['event_gate'])))
                    ig2.metric(ko_text('Implementation Status'), _locale.code(ko_text(_fci_validation['implementation_status'])))
                    ig3.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                    if _fci_validation['issues']:
                        st.warning(_locale.message(ko_text('Implementation Event 저장 전 확인 · ' + ' | '.join(_fci_validation['issues']))))
                    else:
                        st.success(_locale.message(ko_text('Implementation Gate PASS · 실제 원본 변경은 이미 외부/원본 Review에서 결정된 것이며 이 화면은 Event와 Before Baseline만 감사기록으로 잠급니다.')))
                    if st.button(ko_text('Forecast Implementation Event 저장'), disabled=_fci_validation['event_gate'] != 'PASS', key=f'forecast_implementation_save::{company}'):
                        _fci_row = build_forecast_implementation_record(_fci_plan, _fci_validation, implementation_action=_fci_action, implementation_date=_fci_date.isoformat(), implementation_reference=_fci_reference, implementation_summary=_fci_summary, baseline_locked_confirmed=_fci_baseline_confirm, source_review_confirmed=_fci_source_confirm, no_auto_apply_confirmed=_fci_no_auto, no_execution_authorization_confirmed=_fci_no_exec, human_review_confirmed=_fci_human, note=_fci_note)
                        _fci_hist = load_csv('forecast_change_implementation_events.csv')
                        for _col in FORECAST_IMPLEMENTATION_COLS:
                            if _col not in _fci_hist.columns:
                                _fci_hist[_col] = ''
                        _fci_hist = pd.concat([_fci_hist[FORECAST_IMPLEMENTATION_COLS], pd.DataFrame([_fci_row])], ignore_index=True)
                        verified_save_feedback(_fci_hist, 'forecast_change_implementation_events.csv', ko_text(f"Forecast Implementation Event 저장 · {_fci_row['implementation_status']} · Baseline {_fci_row['baseline_error_share']:.1%} · Execution Authorization = NONE."), rerun=False)
                    _fci_latest_live = latest_forecast_implementation(load_csv('forecast_change_implementation_events.csv'), str(_fci_plan.get('change_plan_id', '') or ''))
                    if _fci_latest_live:
                        _fci_ba = build_before_after_cohort(_fci_plan, _fci_latest_live, load_csv('decision_learning_lineage.csv'), min_post_samples=3, today=date.today())
                        st.markdown(ko_text('**Before / After Cohort Monitor**'))
                        ba1, ba2, ba3, ba4, ba5 = st.columns(5)
                        ba1.metric(ko_text('Before/After Status'), _locale.code(ko_text(_fci_ba['before_after_status'])))
                        ba2.metric(ko_text('Before Error Share'), _locale.code(ko_text(f"{_fci_ba['baseline_error_share']:.1%}")))
                        ba3.metric(ko_text('Post Samples'), _locale.code(ko_text(_fci_ba['post_sample_size'])))
                        ba4.metric(ko_text('Post Error Share'), _locale.code(ko_text('-' if _fci_ba['post_error_share'] is None else f"{_fci_ba['post_error_share']:.1%}")))
                        ba5.metric(ko_text('Comparison'), _locale.code(ko_text(_fci_ba['comparison'])))
                        st.caption(ko_text(f"""Error Share Δ · {('-' if _fci_ba['error_share_delta'] is None else f"{_fci_ba['error_share_delta']:+.1%}")} · Proof Date Reached {_fci_ba['proof_date_reached']} · Minimum Post Samples {_fci_ba['min_post_samples']}"""))
                        if _fci_ba['issues']:
                            st.warning(_locale.message(ko_text('Before/After 검토 사유 · ' + ' | '.join(_fci_ba['issues']))))
                        st.caption(ko_text('LOWER/HIGHER_ERROR_SHARE는 관측 Cohort 비교값일 뿐 Change 성공/실패 판정이 아닙니다. Proof Ready 이후에도 Human Review가 필요합니다.'))
            st.subheader(ko_text('13. Proof Review / Change Effect Classification / Second-order Learning'))
            st.caption(ko_text('PROOF_READY Before/After Cohort를 Human Review해 관측된 Error Share 변화와 Second-order Learning을 기록합니다. 관측값만으로 변경의 인과효과를 확정하지 않습니다.'))
            _fer_plans = load_csv('forecast_change_registry.csv')
            _fer_events = load_csv('forecast_change_implementation_events.csv')
            _fer_reviews = load_csv('forecast_change_effect_reviews.csv')
            _fer_candidates = []
            if not _fer_plans.empty:
                for _col in FORECAST_CHANGE_PLAN_COLS:
                    if _col not in _fer_plans.columns:
                        _fer_plans[_col] = ''
                _fer_pool = _fer_plans.loc[_fer_plans['plan_status'].fillna('').astype(str).str.upper().eq('REGISTERED_FOR_IMPLEMENTATION_REVIEW') & _fer_plans['company'].fillna('').astype(str).isin([company, 'ALL'])].copy()
                for _idx, _pr in _fer_pool.iterrows():
                    _plan = _pr.to_dict()
                    _event = latest_forecast_implementation(_fer_events, str(_plan.get('change_plan_id', '') or ''))
                    if not _event:
                        continue
                    if str(_event.get('implementation_status', '') or '').upper() != 'IMPLEMENTED_BASELINE_LOCKED':
                        continue
                    _ba = build_before_after_cohort(_plan, _event, load_csv('decision_learning_lineage.csv'), min_post_samples=3, today=date.today())
                    if str(_ba.get('before_after_status', '') or '').upper() == 'PROOF_READY':
                        _fer_candidates.append((_plan, _event, _ba))
            if not _fer_candidates:
                st.info(_locale.message(ko_text('현재 Proof Review 대상으로 사용할 PROOF_READY Change Cohort가 없습니다.')))
            else:
                _fer_opts = list(range(len(_fer_candidates)))

                def _fer_label(_opt):
                    _p, _e, _b = _fer_candidates[_opt]
                    return f"{_p.get('change_plan_id', '')} | {_p.get('forecast_error_class', '')} | {_b.get('comparison', '')} | Post N={_b.get('post_sample_size', 0)}"
                _fer_opt = st.selectbox(ko_text('Proof Review 대상 Change Cohort'), options=_fer_opts, format_func=ko_format(_fer_label), key=f'forecast_effect_candidate::{company}')
                _fer_plan, _fer_event, _fer_ba = _fer_candidates[_fer_opt]
                _fer_latest = latest_forecast_effect_review(_fer_reviews, str(_fer_plan.get('change_plan_id', '') or ''))
                e1, e2, e3, e4, e5 = st.columns(5)
                e1.metric(ko_text('Proof Status'), _locale.code(ko_text(_fer_ba['before_after_status'])))
                e2.metric(ko_text('Before Error Share'), _locale.code(ko_text(f"{_fer_ba['baseline_error_share']:.1%}")))
                e3.metric(ko_text('Post Error Share'), _locale.code(ko_text('-' if _fer_ba['post_error_share'] is None else f"{_fer_ba['post_error_share']:.1%}")))
                e4.metric(ko_text('Comparison'), _locale.code(ko_text(_fer_ba['comparison'])))
                e5.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                if _fer_latest:
                    _fer_latest_integrity = forecast_effect_review_integrity(_fer_latest)
                    st.caption(ko_text(f"Latest Effect Review · {_fer_latest.get('effect_review_id', '')} · Status {_fer_latest.get('review_status', '')} · Integrity {_fer_latest_integrity['status']}"))
                _expected_cls = expected_effect_classification(_fer_ba['comparison'])
                _cls_idx = EFFECT_CLASSIFICATIONS.index(_expected_cls) if _expected_cls in EFFECT_CLASSIFICATIONS else 3
                _fer_cls = st.selectbox(ko_text('Observed Effect Classification'), EFFECT_CLASSIFICATIONS, index=_cls_idx, key=f'forecast_effect_class::{company}', format_func=ko_format())
                _fer_action = st.selectbox(ko_text('Proof Review Action'), EFFECT_REVIEW_ACTIONS, key=f'forecast_effect_action::{company}', format_func=ko_format())
                _fer_interpret = st.text_area(ko_text('Effect Interpretation'), key=f'forecast_effect_interpret::{company}', placeholder='관측값 중심으로 기술. 인과 확정 표현은 피합니다.')
                _fer_alt = st.text_area(ko_text('Alternative Explanations / Confounders'), key=f'forecast_effect_alt::{company}', placeholder='시장 국면, 표본 구성, 투자 근거 품질, 다른 모형/절차 변화 등')
                _fer_learning = st.text_area(ko_text('Second-order Learning'), key=f'forecast_effect_learning::{company}', placeholder='다음 예측/검토 설계에서 무엇을 다르게 볼지 기록')
                _fer_next = st.text_area(ko_text('Next Review Action'), key=f'forecast_effect_next::{company}', placeholder='다음 투자 근거/확인 근거/모형/매개변수/절차 검토 행동')
                c1, c2 = st.columns(2)
                _fer_proof = c1.checkbox(ko_text('Before/Post sample, Error Share, Proof Date와 Comparison을 직접 확인했습니다.'), key=f'forecast_effect_proof::{company}')
                _fer_no_causal = c2.checkbox(ko_text('관측 Error Share 변화만으로 인과효과를 확정하지 않음을 확인했습니다.'), key=f'forecast_effect_causal::{company}')
                c3, c4 = st.columns(2)
                _fer_no_carry = c3.checkbox(ko_text('이 Effect Review를 다음 Model/Assumption에 자동 Carry-forward하지 않음을 확인했습니다.'), key=f'forecast_effect_carry::{company}')
                _fer_no_exec = c4.checkbox(ko_text('이 Effect Review는 Execution Authorization을 생성하지 않음을 확인했습니다.'), key=f'forecast_effect_exec::{company}')
                _fer_human = st.checkbox(ko_text('현재 Proof Review / Second-order Learning을 최종 Human Review했습니다.'), key=f'forecast_effect_human::{company}')
                _fer_note = st.text_input(ko_text('Effect Review 메모'), key=f'forecast_effect_note::{company}')
                _fer_validation = validate_forecast_effect_review(_fer_plan, _fer_event, _fer_ba, effect_classification=_fer_cls, effect_interpretation=_fer_interpret, alternative_explanations=_fer_alt, second_order_learning=_fer_learning, next_review_action=_fer_next, review_action=_fer_action, proof_snapshot_confirmed=_fer_proof, no_causal_overclaim_confirmed=_fer_no_causal, no_auto_carry_forward_confirmed=_fer_no_carry, no_execution_authorization_confirmed=_fer_no_exec, human_review_confirmed=_fer_human)
                g1, g2, g3 = st.columns(3)
                g1.metric(ko_text('Effect Review Gate'), _locale.code(ko_text(_fer_validation['review_gate'])))
                g2.metric(ko_text('Review Status'), _locale.code(ko_text(_fer_validation['review_status'])))
                g3.metric(ko_text('Execution Authorization'), _locale.code(ko_text('NONE')))
                if _fer_validation['issues']:
                    st.warning(_locale.message(ko_text('Effect Review 저장 전 확인 · ' + ' | '.join(_fer_validation['issues']))))
                if st.button(ko_text('Forecast Change Effect Review 저장'), disabled=_fer_validation['review_gate'] != 'PASS', key=f'forecast_effect_save::{company}'):
                    _row = build_forecast_effect_review_record(_fer_plan, _fer_event, _fer_ba, _fer_validation, effect_classification=_fer_cls, effect_interpretation=_fer_interpret, alternative_explanations=_fer_alt, second_order_learning=_fer_learning, next_review_action=_fer_next, review_action=_fer_action, proof_snapshot_confirmed=_fer_proof, no_causal_overclaim_confirmed=_fer_no_causal, no_auto_carry_forward_confirmed=_fer_no_carry, no_execution_authorization_confirmed=_fer_no_exec, human_review_confirmed=_fer_human, note=_fer_note)
                    _hist = load_csv('forecast_change_effect_reviews.csv')
                    for _col in FORECAST_EFFECT_REVIEW_COLS:
                        if _col not in _hist.columns:
                            _hist[_col] = ''
                    _hist = pd.concat([_hist[FORECAST_EFFECT_REVIEW_COLS], pd.DataFrame([_row])], ignore_index=True)
                    verified_save_feedback(_hist, 'forecast_change_effect_reviews.csv', ko_text(f"Forecast Change Effect Review 저장 · {_row['review_status']} · {_row['effect_classification']} · Execution Authorization = NONE."), rerun=False)
            st.caption(ko_text('반복 Error가 있다고 해서 특정 Assumption을 자동으로 낮추거나 높이지 않습니다. MODEL / PARAMETER / EXECUTION / EXOGENOUS를 분리해 원본 Evidence와 Decision Process를 다시 검토합니다.'))
    with st.expander(ko_text('Legacy Decision Journal 보기')):
        legacy = ensure_cols(load_csv('decision_journal.csv'), JOURNAL_COLS)
        st.caption(ko_text('기존 Journal은 호환성을 위해 보존합니다. 새 기록은 Decision Journal 2.0을 사용하세요.'))
        _locale.dataframe(st, ko_frame(legacy.tail(100)), width='stretch', hide_index=True)
    st.caption(ko_text('사후 결과로 당시 판단을 재작성하지 않습니다.'))
