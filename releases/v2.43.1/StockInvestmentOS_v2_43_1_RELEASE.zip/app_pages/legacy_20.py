from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('이전 관리')
    st.caption('운영 준비 환경 프로젝트 이전 / 데이터-비밀정보 분리 / 무결성 이관 관리 · 기존 설치본은 삭제하거나 이동하지 않는 원본을 보존하는 이전입니다.')
    _mg_layout = load_work_ready_layout(ROOT)
    if _mg_layout.get('active'):
        st.success('현재 실행 중인 코드가 운영 코드와 데이터 분리 구조 배치를 사용하고 있습니다.')
        mg0, mg1, mg2, mg3 = st.columns(4)
        mg0.metric('배치', '작업 · 준비 완료')
        mg1.metric('코드 기준 경로', _locale.code(Path(_mg_layout['code_root']).name))
        mg2.metric('실행 환경 데이터', '외부')
        mg3.metric('비밀정보', '외부')
        with st.expander('활성 운영 준비 환경 경로', expanded=False):
            st.json({'work_root': _mg_layout.get('work_root'), 'code_root': _mg_layout.get('code_root'), 'runtime_data_root': _mg_layout.get('runtime_data_root'), 'secrets_root': _mg_layout.get('secrets_root'), 'control_root': _mg_layout.get('control_root'), 'secret_env_path': _mg_layout.get('secret_env_path')})
        _mg_home = Path(_mg_layout['home_root'])
        if st.button('현재 운영 준비 환경 이전 무결성 재검증', key='work_ready_verify_active'):
            _mg_verify = work_ready_verify_migration(_mg_home)
            if _mg_verify.get('status') == 'READY_FOR_WORK_CUTOVER':
                st.success('이전 무결성 = 운영 전환 준비 완료')
            else:
                st.error('이전 무결성 차단됨')
            st.json(_mg_verify)
        if st.button('운영 준비 환경 실행 도구 보완', key='work_ready_launcher_repair'):
            _mg_launcher_repair = repair_work_ready_launcher(_mg_home)
            if _mg_launcher_repair.get('status') == 'REPAIRED':
                st.success('run_work_ready.bat 복구 완료 · 검증된 work/app/run.bat를 호출하도록 수정했습니다.')
            else:
                st.error('실행 도구 보완 차단됨/실패')
            st.json(_mg_launcher_repair)
        st.info('작업에는 work/ 폴더만 연결하는 것을 권장합니다. 실행 환경-data/와 비밀정보/는 작업 권한 루트 밖에 유지됩니다.')
        st.caption('최초 이전 코드 파일 명세는 이관 시점의 역사적 접수입니다. 긴급 수정/배포 이후 현재 코드 무결성은 현재 관리 대상 코드 기준 상태로 검증합니다.')
    else:
        st.info('현재는 기존 배치입니다. 이전은 새 대상으로 복사하며 기존 설치본을 그대로 보존합니다.')
        _mg_default = str(default_target_home(ROOT))
        _mg_target = st.text_input('운영 준비 환경 이전 대상 기준 폴더', value=_mg_default, key='work_ready_migration_target')
        _mg_plan = work_ready_plan_migration(ROOT, Path(_mg_target))
        mgp1, mgp2, mgp3, mgp4, mgp5 = st.columns(5)
        mgp1.metric('계획', _locale.code(_mg_plan['status']))
        mgp2.metric('관리 대상 코드', _locale.code('정상' if _mg_plan['managed_code']['clean'] else '기준 이탈'))
        mgp3.metric('코드 파일', _locale.code(_mg_plan['code_summary']['files']))
        mgp4.metric('실행 환경 데이터 파일', _locale.code(_mg_plan['data_summary']['files']))
        mgp5.metric('비밀정보 파일', _locale.code(_mg_plan['secret_summary']['files']))
        if _mg_plan['blockers']:
            st.error(_locale.message('이전 차단됨 · ' + ' | '.join(_mg_plan['blockers'])))
        if _mg_plan['warnings']:
            st.warning(_locale.message(' | '.join(_mg_plan['warnings'])))
        st.code(f"Target layout\n{_mg_plan['target_home']}\n├─ work/                  ← Work 권한 권장 루트\n│  ├─ app/                ← 코드\n│  └─ control/            ← releases/backups/update_logs\n├─ runtime-data/          ← Work root 밖\n├─ secrets/               ← Work root 밖\n└─ run_work_ready.bat", language='text')
        with st.expander('이전 계획 상세', expanded=False):
            st.json({'source_root': _mg_plan['source_root'], 'source_version': _mg_plan['source_version'], 'target_home': _mg_plan['target_home'], 'estimated_copy_bytes': _mg_plan['estimated_copy_bytes'], 'managed_code': _mg_plan['managed_code'], 'data_summary': _mg_plan['data_summary'], 'secret_summary': _mg_plan['secret_summary']})
        st.warning('실제 이전은 실행 중인 Streamlit에서 시작하지 않습니다. 실행 환경 표 데이터 일관성을 위해 앱을 종료한 뒤 아래 명령줄 도구 또는 작업에서 실행하십시오.')
        st.code(f'python migration\\migrate_work_ready.py migrate --target "{_mg_target}"', language='text')
        st.caption('이전은 출처를 수정/삭제하지 않습니다. 실패하거나 검증이 차단됨이면 운영 전환하지 말고 기존 설치본을 계속 사용하십시오.')
    st.divider()
    st.subheader('운영 준비 환경 이전 명령줄 도구')
    st.code('python -m migration.migrate_work_ready plan\npython -m migration.migrate_work_ready migrate --target <TARGET_HOME>\npython -m migration.migrate_work_ready verify --target <TARGET_HOME>\npython -m migration.migrate_work_ready repair-launcher --target <TARGET_HOME>', language='text')
    st.caption('이전/프로그램 업데이트 상태는 투자 투자 실행 권한과 분리됩니다. 이전 관리는 주문·포지션·투자 실행 권한을 변경하지 않습니다.')
