from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('투자 가설 점검')
    st.caption('가격보다 먼저 투자 가설이 아직 살아 있는지 확인합니다. 투자 가설 핵심 성과 지표 · 투자 근거 · 투자 근거 유효기간 · 추가 투자 보류 · 가설 무효화를 한 화면에 모읍니다.')
    plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    monitor = build_thesis_monitor(watchlist, state_df, plans, kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
    st.markdown('**초보자용 순서:** `Thesis → KPI → Evidence → Proof Clock → Add Freeze → 다음 확인`')
    st.caption('추가 투자 보류가 켜짐이면 가격이 싸져도 추가 위험을 늘리지 않습니다. 예상했던 투자 근거가 기한 내 나오지 않는 것도 새로운 투자 근거로 취급합니다.')
    if monitor.empty:
        st.info('아직 투자 가설 점검에서 확인할 종목이 없습니다. 관심종목에 종목을 먼저 추가하세요.')
    else:
        company_options = monitor['company'].fillna('').astype(str).tolist()
        selected = st.selectbox('확인할 종목', company_options, key='thesis_monitor_company')
        hit = monitor.loc[monitor['company'].astype(str).eq(str(selected))]
        if not hit.empty:
            r = hit.iloc[0].to_dict()
            c1, c2, c3, c4 = st.columns(4)
            c1.metric('현재 투자 단계', _locale.code(str(r.get('lifecycle', '-'))))
            c2.metric('투자 근거', _locale.code(str(r.get('evidence_status', '-'))))
            c3.metric('추가 투자 보류', _locale.code(str(r.get('add_freeze', '-'))))
            c4.metric('투자 근거 유효기간', _locale.code(str(r.get('proof_status', '-'))))
            if str(r.get('add_freeze', '')) == 'ON':
                st.error('추가 투자 보류 = 켜짐 · 현재는 추가 위험을 늘리지 않는 상태입니다. 가격하락만으로 해제하지 마세요.')
            elif str(r.get('add_freeze', '')) == 'REVIEW':
                st.warning('추가 투자 보류 = 검토 · 투자 근거/핵심 성과 지표/투자 근거 유효기간 중 추가 확인이 필요합니다.')
            else:
                st.success('추가 투자 보류 = 꺼짐 · 모니터링상 엄격한 보류는 없습니다. 이 상태 자체가 매수 신호는 아닙니다.')
            st.subheader('1. 투자 가설')
            thesis_summary = str(r.get('thesis_summary', '') or '').strip()
            if thesis_summary:
                st.write(thesis_summary)
            else:
                st.info('아직 투자 가설 요약이 없습니다. 아래 편집 영역에서 한 문장으로 적어 두세요.')
            st.subheader('2. 투자 가설 핵심 성과 지표')
            selected_kpis, selected_proof = selected_company_details(selected, kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
            if selected_kpis.empty:
                st.info('등록된 투자 가설 핵심 성과 지표가 없습니다. 핵심 성과 지표 점검에서 기본 핵심 성과 지표 템플릿 또는 핵심 핵심 성과 지표를 추가하세요.')
            else:
                kcols = ['metric', 'monitor_status', 'actual', 'unit', 'good_threshold', 'bad_threshold', 'as_of', 'next_check_date', 'source_url', 'note']
                _locale.dataframe(st, selected_kpis[[c for c in kcols if c in selected_kpis.columns]], width='stretch', hide_index=True)
                k1, k2, k3 = st.columns(3)
                k1.metric('주의 핵심 성과 지표', _locale.code(int(r.get('kpi_attention_count', 0) or 0)))
                k2.metric('실패', _locale.code(int(r.get('kpi_fail_count', 0) or 0)))
                k3.metric('정상', _locale.code(int(r.get('kpi_pass_count', 0) or 0)))
            st.subheader('3. 투자 근거 / 투자 근거 유효기간')
            e1, e2, e3 = st.columns(3)
            e1.metric('투자 근거 상태', _locale.code(str(r.get('evidence_status', '-'))))
            e2.metric('가설 무효화', _locale.code(str(r.get('invalidation_status', '-'))))
            e3.metric('다음 확인일', _locale.code(str(r.get('next_check_date', '') or 'NO DATE')))
            if selected_proof.empty:
                st.info('등록된 투자 근거 유효기간이 없습니다. 필요한 투자 근거와 기한을 투자 근거 유효기간에 추가하세요.')
            else:
                pcols = ['proof_item', 'due_date', 'clock_status', 'days_to_due', 'invalidation_signal', 'source_url', 'last_checked', 'note']
                _locale.dataframe(st, selected_proof[[c for c in pcols if c in selected_proof.columns]], width='stretch', hide_index=True)
            st.subheader('4. 행동 규칙')
            rule1, rule2, rule3 = st.columns(3)
            with rule1:
                st.markdown('**추가 조건**')
                st.write(str(r.get('add_rule', '') or '미작성'))
            with rule2:
                st.markdown('**추가 투자 보류 조건**')
                st.write(str(r.get('add_freeze_rule', '') or '미작성'))
            with rule3:
                st.markdown('**가설 무효화 조건**')
                st.write(str(r.get('invalidation_rule', '') or '미작성'))
            st.subheader('5. 다음 확인')
            next_source = str(r.get('next_check_source', '') or 'NO DATE')
            next_detail = str(r.get('next_check_detail', '') or '')
            next_note = str(r.get('next_check_note', '') or '')
            if r.get('next_check_date'):
                st.info(_locale.message(f"{r.get('next_check_date')} · {next_source}" + (f' · {next_detail}' if next_detail else '') + (f'\n\n{next_note}' if next_note else '')))
            else:
                st.warning('다음 확인 날짜가 없습니다. 투자 근거 유효기간 또는 투자 가설 계획에 날짜를 넣어 주세요.')
            st.caption('투자 근거 상태는 투자 상태의 관심종목 값, 핵심 성과 지표는 핵심 성과 지표 점검, 투자 근거 유효기간은 투자 근거 유효기간 화면의 데이터를 읽습니다.')
        st.divider()
        st.subheader('투자 가설 계획 편집')
        st.caption('숫자 핵심 성과 지표는 핵심 성과 지표 점검에서 관리하고, 여기서는 투자 가설과 행동 규칙을 문장으로 고정합니다.')
        edit_company = st.selectbox('편집할 종목', company_options, key='thesis_plan_edit_company')
        plan_hit = plans.loc[plans['company'].fillna('').astype(str).str.strip().eq(str(edit_company).strip())]
        current_plan = plan_hit.iloc[0].to_dict() if not plan_hit.empty else {c: '' for c in THESIS_PLAN_COLS}

        def _plan_txt(v):
            if v is None:
                return ''
            s = str(v)
            return '' if s.lower() in {'nan', 'none'} else s
        with st.form('thesis_plan_form'):
            thesis_summary_in = st.text_area('투자 가설 요약', value=_plan_txt(current_plan.get('thesis_summary')), placeholder='예: 검증 자동화 수요 증가가 매출·현금흐름으로 반복 확인되면 가치가 커진다.', height=90)
            a, b = st.columns(2)
            with a:
                add_rule_in = st.text_area('추가 조건', value=_plan_txt(current_plan.get('add_rule')), placeholder='예: 가격 기준 통과 + 값 유지/상향 + 투자 근거 강화', height=110)
                invalidation_rule_in = st.text_area('가설 무효화 조건', value=_plan_txt(current_plan.get('invalidation_rule')), placeholder='예: 핵심 고객 둔화 + 잉여현금흐름 구조적 악화가 동시에 확인되면 가설 재검토', height=110)
            with b:
                add_freeze_rule_in = st.text_area('추가 투자 보류 조건', value=_plan_txt(current_plan.get('add_freeze_rule')), placeholder='예: 투자 근거 실패/오래됨, 확인 근거 기한 초과, 핵심 성과 지표 실패가면 추가매수 중단', height=110)
                next_check_date_in = st.text_input('다음 확인 날짜', value=_plan_txt(current_plan.get('next_check_date')), placeholder='YYYY-MM-DD')
                next_check_note_in = st.text_area('다음 확인 메모', value=_plan_txt(current_plan.get('next_check_note')), placeholder='예: 다음 분기 실적 또는 중요 공시 중 먼저 발생하는 시점', height=70)
            note_in = st.text_area('메모', value=_plan_txt(current_plan.get('note')), height=70)
            save_plan = st.form_submit_button('Thesis Plan 저장', type='primary')
        if save_plan:
            d = pd.to_datetime(next_check_date_in, errors='coerce')
            if str(next_check_date_in).strip() and pd.isna(d):
                st.error('다음 확인 날짜는 YYYY-MM-DD 형식으로 입력해 주세요.')
            else:
                values = {'thesis_summary': thesis_summary_in, 'add_rule': add_rule_in, 'add_freeze_rule': add_freeze_rule_in, 'invalidation_rule': invalidation_rule_in, 'next_check_date': '' if not str(next_check_date_in).strip() else d.date().isoformat(), 'next_check_note': next_check_note_in, 'note': note_in}
                updated = upsert_thesis_plan(plans, edit_company, values)
                save_csv(updated, 'thesis_plans.csv')
                st.success(f'{edit_company} 투자 가설 계획을 저장했습니다.')
                st.rerun()
    st.divider()
    st.subheader('전체 투자 가설 점검')
    if monitor.empty:
        st.info('표시할 데이터가 없습니다.')
    else:
        summary_cols = ['company', 'lifecycle', 'evidence_status', 'add_freeze', 'invalidation_status', 'kpi_worst_status', 'proof_status', 'proof_due_date', 'next_check_date', 'next_check_source', 'monitor_version']
        _locale.dataframe(st, monitor[[c for c in summary_cols if c in monitor.columns]], width='stretch', hide_index=True)
    st.caption('투자 가설 점검은 모니터링 도구입니다. 준비 완료/정상/꺼짐도 자동매수 신호가 아니며 증권사 주문을 전송하지 않습니다.')
