from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('종합 현황')
    p = normalize_portfolio(portfolio, total_assets if total_assets > 0 else None)
    s = portfolio_summary(p, total_assets if total_assets > 0 else None)
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap) if not watchlist.empty else watchlist
    recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric('포트폴리오 자산', _locale.code(krw(s['assets_krw'])))
    c2.metric('확인된 보유 종목', _locale.code(krw(s['known_value_krw'])))
    c3.metric('상위 보유 종목', _locale.code(s['top_name'] or '-'))
    c4.metric('상위 비중', _locale.code(pct(s['top_weight'])))
    c5.metric('하락 시나리오 손실위험자본', _locale.code(pct(s['bear_car'])))
    if recon['status'] != 'PASS':
        st.error(f"포트폴리오 대조 불일치: 등록된 {krw(recon['declared_total_assets'])} 대비 확인된 {krw(recon['known_portfolio_value'])} (차이 {krw(recon['gap_krw'])}). 매매 자금 확보 대조가 완료될 때까지 차단 상태를 유지해야 합니다.")
    if s['top_weight'] > single_cap:
        st.warning(f'단일종목 비중이 개별 종목 상한 {pct(single_cap)}을 초과합니다. 신규매수보다 집중도 위험을 먼저 확인하세요.')
    if not p.empty:
        st.subheader('포트폴리오')
        cols = [c for c in ['name', 'current_value_krw', 'weight', 'bear_downside', 'capital_at_risk', 'factor'] if c in p.columns]
        _locale.dataframe(st, p[cols], width='stretch', hide_index=True)
        fx = factor_exposure(p)
        st.subheader('투자 요인 노출')
        st.bar_chart(fx.set_index('factor')['weight'])
    st.subheader('투자 단계 상태')
    if state_df.empty:
        st.info('관심종목이 비어 있습니다.')
    else:
        cols = [c for c in ['name', 'price', 'lifecycle_state', 'state_reason', 'evidence_status', 'thesis_status', 'initial_ceiling', 'core_ceiling', 'bear_downside'] if c in state_df.columns]
        _locale.dataframe(st, state_df[cols], width='stretch', hide_index=True)
    clock = enrich_proof_clock(proof)
    if not clock.empty:
        urgent = clock[clock['clock_status'].isin(['OVERDUE', 'DUE SOON'])]
        if not urgent.empty:
            st.subheader('투자 근거 유효기간 알림')
            _locale.dataframe(st, urgent[['company', 'proof_item', 'due_date', 'clock_status', 'days_to_due', 'status']], width='stretch', hide_index=True)
