from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('포트폴리오')
    st.caption('수량과 종목 코드가 있으면 주가·평가액 갱신 메뉴에서 평가액을 갱신합니다. 수량을 모르면 current_value_krw만 사용해도 됩니다.')
    edited = _locale.editor(st, portfolio, num_rows='dynamic', width='stretch', key='portfolio_editor')
    if st.button('포트폴리오 저장', type='primary'):
        verified_save_feedback(edited, 'portfolio.csv', '포트폴리오를 저장했습니다.')
    uploaded = st.file_uploader('표 데이터 불러오기', type=['csv'])
    if uploaded is not None:
        imp = pd.read_csv(uploaded)
        _locale.dataframe(st, imp, width='stretch')
        if st.button('업로드 표 데이터로 교체'):
            save_csv(ensure_cols(imp, PORT_COLS), 'portfolio.csv')
            st.rerun()
