from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('상태 기록 이력')
    st.caption('실제 저장 데이터의 시점별 상태를 보존합니다. 가격 미리보기는 자동 저장하지 않습니다.')
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    alerts = build_alerts(portfolio, state_df, proof, total_assets, loss_budget, single_cap, float(settings.get('factor_cap', 0.1)))
    if st.button('현재 상태 기록 저장', type='primary'):
        path = save_snapshot(ROOT, portfolio, watchlist, proof, total_assets, alerts)
        st.success(f'저장했습니다: {path.name}')
    snaps = list_snapshots(ROOT)
    if snaps.empty:
        st.info('아직 상태 기록이 없습니다.')
    else:
        _locale.dataframe(st, snaps, width='stretch', hide_index=True)
        diff = compare_latest_two(ROOT)
        st.subheader('최근 2개 상태 기록 비교')
        if diff.empty:
            st.info('비교하려면 상태 기록이 2개 이상 필요합니다.')
        else:
            _locale.dataframe(st, diff, width='stretch', hide_index=True)
