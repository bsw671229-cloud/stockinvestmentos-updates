from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('시나리오 승인 → 기준 원장 대조')
    st.caption('최신 승인된 시나리오 새로 읽기와 현재 기준 원장 투자 가정을 나란히 비교하고, 실제 원장에 반영할 항목만 사용자가 선택합니다.')
    st.info('자동 변경은 없습니다. 시나리오가 승인됨여도 기준 원장 하락 위험 / 필요 수익률 / 종료 상태 성장 / 투자 가설 다음 확인은 별도 선택과 저장을 거쳐야 합니다.')
    sr_all = load_csv('scenario_refresh_reviews.csv')
    rec_history = load_csv('scenario_reconciliation_reviews.csv')
    sr_plans_all = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    approved_companies = []
    if not sr_all.empty and 'company' in sr_all.columns and ('review_status' in sr_all.columns):
        approved_companies = list(dict.fromkeys(sr_all.loc[sr_all['review_status'].fillna('').astype(str).str.upper().eq('APPROVED'), 'company'].fillna('').astype(str).tolist()))
        approved_companies = [x for x in approved_companies if str(x).strip()]
    if not approved_companies:
        st.warning('승인됨 시나리오 새로 읽기가 없습니다. 초안은 기준 원장 대조에 사용되지 않습니다.')
        st.button('시나리오 새로 읽기로 이동', on_click=_navigate, args=('Scenario Refresh',), key='scenario_recon_to_refresh_no_approved')
    else:
        handed_company = str(st.session_state.get('scenario_reconciliation_company', '') or '').strip()
        default_idx = approved_companies.index(handed_company) if handed_company in approved_companies else 0
        recon_company = st.selectbox('대조 종목', approved_companies, index=default_idx, key='scenario_reconciliation_company_select')
        st.session_state['scenario_reconciliation_company'] = recon_company
        latest_scenario = latest_approved_refresh(sr_all, recon_company)
        wh = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(recon_company)] if not watchlist.empty else pd.DataFrame()
        if wh.empty:
            st.error('관심종목에서 해당 종목을 찾지 못했습니다. 시스템 통합을 먼저 확인하세요.')
        else:
            wr = wh.iloc[0].to_dict()
            recon_ticker = str(wr.get('ticker', '') or '').strip()
            plan_hit = sr_plans_all.loc[sr_plans_all['company'].fillna('').astype(str).eq(recon_company)] if not sr_plans_all.empty else pd.DataFrame()
            plan_row = plan_hit.iloc[0].to_dict() if not plan_hit.empty else {}
            proof_rows = proof.loc[proof['company'].fillna('').astype(str).eq(recon_company)] if not proof.empty and 'company' in proof.columns else pd.DataFrame()
            recon_view = build_scenario_reconciliation(watch_row=wr, scenario_row=latest_scenario, thesis_plan_row=plan_row, proof_rows=proof_rows)
            prior_status = reconciliation_status_for_scenario(rec_history, company=recon_company, scenario_row=latest_scenario)
            st.subheader('1. 최신 승인된 시나리오')
            a1, a2, a3, a4, a5 = st.columns(5)
            a1.metric('시나리오 기록', _locale.code(str(latest_scenario.get('event_date', '') or '-')))
            a2.metric('투자 근거', _locale.code(str(latest_scenario.get('evidence_signal', '') or '-')))
            a3.metric('시나리오 신호', _locale.code(str(latest_scenario.get('thesis_signal', '') or '-')))
            a4.metric('기준 원장 상태', _locale.code(str(wr.get('assumption_status', '') or 'REVIEW')))
            a5.metric('대조', _locale.code(prior_status.get('status', 'PENDING')))
            if prior_status.get('status', 'PENDING').startswith('RECONCILED'):
                st.success('이 승인됨 시나리오 새로 읽기는 이미 대조 검토기록이 있습니다. 새 투자 근거가 아니면 같은 값을 반복 적용할 필요가 없습니다.')
            else:
                st.warning('이 승인됨 시나리오 새로 읽기는 아직 기준 원장 원장과 명시적으로 대조되지 않았습니다.')
            st.subheader('2. 기준 원장 대비 시나리오')
            matrix = recon_view['matrix'].copy()
            display_matrix = matrix.copy()
            for idx_, row_ in display_matrix.iterrows():
                field_ = str(row_.get('field', ''))
                if field_ in {'Plausible Downside', 'Required Return', 'Terminal Growth'}:
                    for c in ['canonical', 'scenario', 'delta']:
                        try:
                            display_matrix.at[idx_, c] = f'{float(row_.get(c, 0.0)):.2%}'
                        except Exception:
                            pass
                elif field_ == 'Adjusted normalized FCF/share':
                    try:
                        display_matrix.at[idx_, 'canonical'] = f"{float(row_.get('canonical', 0.0)):,.0f}원"
                        display_matrix.at[idx_, 'scenario'] = f"{float(row_.get('scenario', 0.0)):,.0f}원"
                        gap_ = row_.get('delta', 0.0)
                        display_matrix.at[idx_, 'delta'] = '∞' if gap_ == float('inf') else f'{float(gap_):.1%}'
                    except Exception:
                        pass
            _locale.dataframe(st, display_matrix, width='stretch', hide_index=True)
            st.caption('`Adjusted normalized FCF/share`는 현재 기준 원장 구조에 직접 대응되는 원장 필드가 없어 참조 전용입니다. 시나리오에서 값이 달라졌다는 이유만으로 normalized_fcf_yield를 자동 역산해 덮어쓰지 않습니다.')
            st.subheader('3. 투자 가설 / 투자 근거 유효기간 일치')
            m1, m2, m3, m4 = st.columns(4)
            m1.metric('시나리오 다음 확인', _locale.code(recon_view.get('scenario_next_check', '') or '-'))
            m2.metric('투자 가설 다음 확인', _locale.code(recon_view.get('thesis_next_check', '') or '-'))
            m3.metric('투자 근거 유효기간 다음 기한', _locale.code(recon_view.get('proof_next_due', '') or '-'))
            m4.metric('확인 근거 일치', _locale.code(recon_view.get('proof_alignment', '-')))
            st.write(f"**확인 근거 항목:** {recon_view.get('proof_item', '') or '-'} · **확인 상태:** {_locale.code(recon_view.get('proof_status', '-'))}")
            st.write(f"**통합 시나리오 신호:** {recon_view.get('scenario_combined_signal', '') or '-'}")
            st.caption('투자 근거 유효기간은 투자 근거 항목별 시계이므로 시나리오 일치 점검이 자동으로 덮어쓰지 않습니다. 날짜가 다르면 투자 근거 유효기간에서 근거를 확인합니다.')
            st.subheader('4. 선택적 기준 원장 반영')
            st.warning('체크한 항목만 원장에 반영합니다. 가격 / 추격 매수 금지 / 투자 요인 / 업종은 시나리오 일치 점검에서 변경하지 않습니다.')
            c1, c2, c3, c4 = st.columns(4)
            apply_downside = c1.checkbox('모형 추정 하락 위험 반영', value=False, disabled=recon_view.get('downside_status') == 'MATCH', key=f'recon_apply_downside::{recon_company}')
            apply_rr = c2.checkbox('필요 수익률 반영', value=False, disabled=recon_view.get('required_return_status') == 'MATCH', key=f'recon_apply_rr::{recon_company}')
            apply_tg = c3.checkbox('종료 상태 성장 반영', value=False, disabled=recon_view.get('terminal_growth_status') == 'MATCH', key=f'recon_apply_tg::{recon_company}')
            sync_next_check = c4.checkbox('시나리오 다음 확인 → 투자 가설 계획', value=False, disabled=not bool(recon_view.get('scenario_next_check')) or recon_view.get('thesis_date_status') == 'MATCH', key=f'recon_sync_next_check::{recon_company}')
            any_canonical = apply_downside or apply_rr or apply_tg
            approve_canonical = st.checkbox('선택한 기준 원장 변경 후 공통가정을 승인됨으로 승인합니다.', value=False, disabled=not any_canonical, key=f'recon_approve_canonical::{recon_company}')
            reviewed_complete = st.checkbox('남아 있는 차이와 참조 전용 항목까지 검토했고, 이번 시나리오의 대조를 완료로 기록합니다.', value=False, key=f'recon_reviewed_complete::{recon_company}')
            action_confirm = st.checkbox('최신 승인된 시나리오의 투자 근거 근거와 위 선택사항을 직접 확인했습니다.', value=False, key=f'recon_action_confirm::{recon_company}')
            recon_note = st.text_input('대조 메모', value='', key=f'recon_note::{recon_company}', placeholder='예: 하락 위험만 원장에 반영, 잉여현금흐름/비중 차이는 다음 실적에서 재검토')
            if any_canonical and (not approve_canonical):
                st.warning('기준 원장 변경은 저장되지만 투자 가정 상태는 검토가 됩니다. 승인됨은 직접 검토·승인한 경우에만 선택하세요.')
            if st.button('선택사항 적용 + 대조 기록 저장', type='primary', disabled=not action_confirm, key=f'save_scenario_reconciliation::{recon_company}'):
                try:
                    new_watch, new_port, new_plans, meta = apply_scenario_reconciliation(watchlist=watchlist, portfolio=portfolio, thesis_plans=sr_plans_all, company=recon_company, ticker=recon_ticker, scenario_row=latest_scenario, apply_downside=apply_downside, apply_required_return=apply_rr, apply_terminal_growth=apply_tg, sync_thesis_next_check=sync_next_check, approve_canonical=approve_canonical)
                    if meta['applied_fields']:
                        canonical_fields = {'bear_downside', 'required_return', 'terminal_growth'}
                        if canonical_fields.intersection(set(meta['applied_fields'])):
                            save_csv(new_watch, 'watchlist.csv')
                        if meta['portfolio_rows_synced'] > 0:
                            save_csv(new_port, 'portfolio.csv')
                        if meta['thesis_synced']:
                            save_csv(new_plans, 'thesis_plans.csv')
                    new_wh = new_watch.loc[new_watch['name'].fillna('').astype(str).eq(recon_company)]
                    new_wr = new_wh.iloc[0].to_dict()
                    new_plan_hit = new_plans.loc[new_plans['company'].fillna('').astype(str).eq(recon_company)]
                    new_plan_row = new_plan_hit.iloc[0].to_dict() if not new_plan_hit.empty else {}
                    after_view = build_scenario_reconciliation(watch_row=new_wr, scenario_row=latest_scenario, thesis_plan_row=new_plan_row, proof_rows=proof_rows)
                    record = reconciliation_record(company=recon_company, ticker=recon_ticker, scenario_row=latest_scenario, before_reconciliation=recon_view, after_reconciliation=after_view, apply_meta=meta, reviewed_complete=reviewed_complete, note=recon_note)
                    hist = load_csv('scenario_reconciliation_reviews.csv')
                    for col in SCENARIO_RECONCILIATION_COLS:
                        if col not in hist.columns:
                            hist[col] = ''
                    hist = pd.concat([hist[SCENARIO_RECONCILIATION_COLS], pd.DataFrame([record])], ignore_index=True)
                    verified_save_feedback(hist, 'scenario_reconciliation_reviews.csv', f"Scenario → Canonical Reconciliation을 {record['reconciliation_status']} 상태로 저장했습니다.", rerun=True)
                except Exception as e:
                    st.error(f'대조 저장 실패: {e}')
            st.subheader('5. 원본 화면으로 이동')
            n1, n2, n3 = st.columns(3)
            n1.button('시스템 통합', on_click=_navigate, args=('System Integration', {'integration_company': recon_company}), key=f'recon_to_integration::{recon_company}')
            n2.button('투자 가설 점검', on_click=_navigate, args=('Thesis Monitor',), key=f'recon_to_thesis::{recon_company}')
            n3.button('투자 근거 유효기간', on_click=_navigate, args=('Proof Clock',), key=f'recon_to_proof::{recon_company}')
            st.subheader('6. 대조 이력')
            if rec_history.empty:
                st.info('아직 대조 기록이 없습니다.')
            else:
                company_rec = rec_history.loc[rec_history['company'].fillna('').astype(str).eq(recon_company)].copy()
                if company_rec.empty:
                    st.info('이 종목의 대조 기록이 없습니다.')
                else:
                    show_cols = ['timestamp', 'scenario_event_date', 'reconciliation_status', 'canonical_status_after', 'applied_fields', 'remaining_canonical_gap_count', 'remaining_schedule_gap_count', 'remaining_reference_gap_count', 'note']
                    show_cols = [c for c in show_cols if c in company_rec.columns]
                    _locale.dataframe(st, company_rec[show_cols].tail(30), width='stretch', hide_index=True)
    st.caption('대조 완료는 차이를 검토하고 반영/유지 결정을 기록했다는 뜻입니다. 시나리오가 맞다고 보장하거나 자동 매수·매도를 의미하지 않습니다.')
