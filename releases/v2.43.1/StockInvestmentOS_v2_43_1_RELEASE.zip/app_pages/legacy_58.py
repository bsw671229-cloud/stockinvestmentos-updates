from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('시장 데이터')
    ticker = st.text_input('종목코드 / 코드', value='005930')
    market = st.selectbox('시장', ['KOSPI', 'KOSDAQ', 'US/Other'], format_func=_locale.option())
    c1, c2 = st.columns(2)
    if c1.button('가격 조회'):
        try:
            p = latest_price(ticker, market)
            st.success(f"{p.ticker}: {p.price:,.2f} {p.currency or ''} / {p.timestamp}")
            hist = price_history(ticker, market, '6mo')
            idx = 'Date' if 'Date' in hist.columns else 'Datetime' if 'Datetime' in hist.columns else None
            st.line_chart(hist.set_index(idx)['Close'] if idx else hist['Close'])
        except Exception as e:
            st.error(_locale.message(str(e)))
    if c2.button('미국 달러/원화 조회'):
        try:
            fx = latest_fx('USD', 'KRW')
            st.success(f'미국 달러/원화: {fx.price:,.2f} / {fx.timestamp}')
        except Exception as e:
            st.error(_locale.message(str(e)))
