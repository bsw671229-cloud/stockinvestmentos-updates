from __future__ import annotations
import ui_locale as _locale
if True:
    st.title(f'역산 현금흐름 할인 / 현재 가격에 반영된 기대 · {VERSION}')
    st.caption('현재가격이 요구하는 잉여현금흐름 성장·현금창출력·상한·할인율을 역산하고, 독립적으로 검토한 기업의 실제 미래와 비교합니다.')
    st.info('핵심 원칙: 역산 현금흐름 할인의 정상화된 잉여현금흐름/비중은 현재가격과 독립된 근거가 있어야 합니다. 가격 × 잉여현금흐름 수익률 방식의 관심종목 추정치는 참고 진단으로는 볼 수 있지만, 독립적 기준값으로 확인되기 전에는 시장 가격에 반영된 성장을 투자 Edge로 해석하지 않습니다.')
    names = watchlist['name'].dropna().astype(str).tolist()
    selected = st.selectbox('관심종목 종목', ['직접 입력'] + names, key='reverse_dcf_company')
    d = {}
    if selected != '직접 입력':
        d = watchlist.loc[watchlist['name'].astype(str).eq(selected)].iloc[0].to_dict()
    st.subheader('1. 입력 출처 이력 / 기준값 무결성')
    default_price = float(pd.to_numeric(pd.Series([d.get('price', 0)]), errors='coerce').fillna(0).iloc[0])
    default_yield = float(pd.to_numeric(pd.Series([d.get('normalized_fcf_yield', 0.05)]), errors='coerce').fillna(0.05).iloc[0])
    default_conf = float(pd.to_numeric(pd.Series([d.get('fcf_confidence', settings.get('default_fcf_confidence', 0.9))]), errors='coerce').fillna(0.9).iloc[0])
    default_rr = float(pd.to_numeric(pd.Series([d.get('required_return', settings.get('default_required_return', 0.1))]), errors='coerce').fillna(0.1).iloc[0])
    default_tg = float(pd.to_numeric(pd.Series([d.get('terminal_growth', settings.get('default_terminal_growth', 0.02))]), errors='coerce').fillna(0.02).iloc[0])
    watchlist_fcf_proxy = default_price * default_yield * default_conf
    _fund_history = normalize_fundamental_snapshots(load_csv('fundamental_snapshots.csv'))
    latest_fundamental = {}
    latest_fy_fundamental = {}
    if selected != '직접 입력' and (not _fund_history.empty):
        latest_fundamental = latest_fundamental_snapshot(_fund_history, selected)
        _company_fund = _fund_history.loc[_fund_history['company'].fillna('').astype(str).eq(selected)].copy()
        if not _company_fund.empty:
            _fy_mask = _company_fund['source_period'].fillna('').astype(str).str.upper().isin(['FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'])
            _fy_candidates = _company_fund.loc[_fy_mask].copy()
            if not _fy_candidates.empty:
                _fy_candidates['_created_sort'] = pd.to_datetime(_fy_candidates['created_at'], errors='coerce', utc=True)
                _fy_candidates = _fy_candidates.sort_values('_created_sort', ascending=False, na_position='last')
                for _, _row in _fy_candidates.iterrows():
                    _candidate = _row.drop(labels=['_created_sort'], errors='ignore').to_dict()
                    if snapshot_integrity_status(_candidate) == 'OK' and pd.to_numeric(pd.Series([_candidate.get('fcf_per_share')]), errors='coerce').fillna(0).iloc[0] > 0:
                        latest_fy_fundamental = _candidate
                        break
    p1, p2, p3, p4 = st.columns(4)
    p1.metric('관심종목 가격', _locale.code(krw(default_price)))
    p2.metric('정상화된 잉여현금흐름 수익률', _locale.code(pct(default_yield)))
    p3.metric('잉여현금흐름 확신도', _locale.code(pct(default_conf)))
    p4.metric('가격-연결됨 잉여현금흐름/비중 참조', _locale.code(krw(watchlist_fcf_proxy)))
    if latest_fundamental:
        lf1, lf2, lf3, lf4 = st.columns(4)
        lf1.metric('최신 기업 기초 기간', _locale.code(f"{latest_fundamental.get('source_business_year', '')} {latest_fundamental.get('source_period', '')}".strip() or '-'))
        lf2.metric('기간 잉여현금흐름/비중 추정치', _locale.code(krw(latest_fundamental.get('fcf_per_share'))))
        lf3.metric('기간 투하자본이익률 추정치', _locale.code(pct(latest_fundamental.get('roic'))))
        lf4.metric('기업 기초 무결성 해시', _locale.code(snapshot_integrity_status(latest_fundamental)))
        _latest_period = str(latest_fundamental.get('source_period', '') or '').strip().upper()
        if _latest_period not in {'FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'}:
            st.caption('최신 기업 기초 상태 기록은 중간기간입니다. 기간 잉여현금흐름/비중·매출/비중·투하자본이익률을 역산 현금흐름 할인의 연간 정상화된 기준값으로 자동 변환하지 않습니다.')
    if latest_fy_fundamental:
        st.success('무결성 해시 정상 + 검토됨 성격의 전체-연도 기업 기초 잉여현금흐름/비중 기준값을 사용할 수 있습니다.')
    else:
        st.warning('현재 저장된 전체-연도 기업 기초 잉여현금흐름/비중 기준값이 없습니다. 역산 현금흐름 할인의 주 모델에는 독립적인 정상화된 잉여현금흐름/비중을 직접 입력하고 출처를 확인해야 합니다.')
    st.subheader('2. 독립적인 정상화된 기준값')
    if selected != '직접 입력':
        st.markdown('### 2-1. OpenDART 회계연도 기준값 생성 도구')
        st.caption('저장된 회계연도 기업 기초 상태 기록이 없을 때, 최근 연차 OpenDART 원문에서 가격과 독립적인 회계연도 잉여현금흐름/비중 참조를 만들 수 있습니다.')
        _dart_key_reverse = str(st.session_state.get('dart_api_key', os.getenv('DART_API_KEY', '')) or '').strip()
        _selected_code = str(d.get('code', '') or '').strip().zfill(6)
        _reverse_corp_code = ''
        if latest_fundamental:
            _reverse_corp_code = str(latest_fundamental.get('source_corp_code', '') or '').strip()
        if not _reverse_corp_code:
            _corp_cache = ROOT / 'data' / 'dart_corp_codes.csv'
            if _corp_cache.exists() and _selected_code:
                try:
                    _reverse_codes = pd.read_csv(_corp_cache, dtype=str)
                    _reverse_corp_code = find_corp_code(_selected_code, _reverse_codes) or ''
                except Exception:
                    _reverse_corp_code = ''
        _latest_year = None
        _latest_period = ''
        if latest_fundamental:
            try:
                _latest_year = int(float(latest_fundamental.get('source_business_year', '')))
            except Exception:
                _latest_year = None
            _latest_period = str(latest_fundamental.get('source_period', '') or '').strip().upper()
        if _latest_year is not None:
            _default_fy_year = _latest_year if _latest_period in {'FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'} else _latest_year - 1
        else:
            _default_fy_year = 2025
        _fy_year = st.number_input('회계연도 출처 연도', min_value=2015, max_value=2100, value=int(_default_fy_year), step=1, key=f'reverse_fy_year::{selected}')
        _fy_key = f'reverse_fy_anchor::{selected}::{int(_fy_year)}'
        _fy_source = st.session_state.get(_fy_key, {})
        fyc1, fyc2 = st.columns([1, 3])
        if fyc1.button('OpenDART 회계연도 출처 불러오기', type='primary', disabled=not bool(_dart_key_reverse and _reverse_corp_code), key=f'reverse_load_fy::{selected}::{int(_fy_year)}'):
            try:
                _fy_raw = full_financials(_dart_key_reverse, _reverse_corp_code, int(_fy_year), '11011', 'CFS')
                if _fy_raw.empty:
                    raise RuntimeError(f'{int(_fy_year)} FY 연결 재무제표가 비어 있습니다.')
                _fy_summary = summarize_financials(_fy_raw)
                _fy_share_raw = stock_total_status(_dart_key_reverse, _reverse_corp_code, int(_fy_year), '11011')
                _fy_share_summary = summarize_share_count(_fy_share_raw)
                _fy_anchor = build_annual_source_anchor(_fy_summary, _fy_share_summary, business_year=int(_fy_year), period='FY')
                st.session_state[_fy_key] = {'anchor': _fy_anchor, 'summary': _fy_summary, 'share_summary': _fy_share_summary, 'raw': _fy_raw, 'share_raw': _fy_share_raw, 'corp_code': _reverse_corp_code}
                st.rerun()
            except Exception as e:
                st.error(f'회계연도 기준값 출처 조회 실패: {e}')
        if not _dart_key_reverse:
            fyc2.warning('전자공시 연결 키가 필요합니다.')
        elif not _reverse_corp_code:
            fyc2.warning('전자공시 법인 고유번호를 찾지 못했습니다. 전자공시 자동 수집에서 종목을 한 번 수집하거나 기업 고유번호 목록을 확인하세요.')
        elif _fy_source:
            _fy_anchor_view = dict(_fy_source.get('anchor', {}) or {})
            if _fy_anchor_view.get('ready'):
                fyc2.success(f'{int(_fy_year)} 회계연도 출처 준비 완료 · 가격 독립 잉여현금흐름/비중 참조 사용 가능')
            else:
                fyc2.warning(f'{int(_fy_year)} 회계연도 출처 검토 · 추출/비중 출처 상태를 확인하세요.')
        else:
            fyc2.info(f'{int(_fy_year)} 회계연도 연결재무제표 + 주식수 출처를 불러옵니다.')
        if _fy_source:
            _fy_anchor_view = dict(_fy_source.get('anchor', {}) or {})
            fy1, fy2, fy3, fy4 = st.columns(4)
            fy1.metric('회계연도 잉여현금흐름 추정치', _locale.code(krw(_fy_anchor_view.get('fcf_proxy'))))
            fy2.metric('회계연도 주식 수 추정치', _locale.code('-' if _fy_anchor_view.get('share_count_proxy') is None else f"{_fy_anchor_view['share_count_proxy']:,.0f}"))
            fy3.metric('회계연도 잉여현금흐름/비중 참조', _locale.code(krw(_fy_anchor_view.get('fcf_per_share'))))
            fy4.metric('회계연도 투하자본이익률 추정치', _locale.code(pct(_fy_anchor_view.get('roic_proxy'))))
            fya1, fya2, fya3 = st.columns(3)
            fya1.metric('추출', _locale.code(_fy_anchor_view.get('extraction_integrity_status', '-') or '-'))
            fya2.metric('비중 출처', _locale.code(_fy_anchor_view.get('share_status', '-') or '-'))
            fya3.metric('회계연도 매출/비중', _locale.code(krw(_fy_anchor_view.get('revenue_per_share'))))
            st.warning(_locale.message(_fy_anchor_view.get('warning', 'FY Source proxy입니다.')))
            with st.expander('회계연도 기준값 출처 검증', expanded=False):
                _fy_summary_view = dict(_fy_source.get('summary', {}) or {})
                _fy_share_view = dict(_fy_source.get('share_summary', {}) or {})
                _locale.dataframe(st, pd.DataFrame([{'item': 'Revenue', 'value': _fy_anchor_view.get('revenue'), 'source': _fy_summary_view.get('revenue_source_account', '')}, {'item': 'FCF proxy', 'value': _fy_anchor_view.get('fcf_proxy'), 'source': f"{_fy_summary_view.get('cfo_source_account', '')} - {_fy_summary_view.get('capex_source_account', '')}"}, {'item': 'Share Count proxy', 'value': _fy_anchor_view.get('share_count_proxy'), 'source': f"OpenDART stockTotqySttus · {_fy_share_view.get('share_count_basis', '')}"}, {'item': 'Tax proxy', 'value': _fy_anchor_view.get('effective_tax_rate_proxy'), 'source': 'Pretax Income / Income Tax Expense'}, {'item': 'Invested Capital proxy', 'value': _fy_anchor_view.get('invested_capital_proxy'), 'source': 'Equity + Debt proxy - Cash'}]), width='stretch', hide_index=True)
    else:
        _fy_source = {}
        _fy_anchor_view = {}
    anchor_options = ['Manual Independent']
    if _fy_source and _fy_anchor_view.get('ready'):
        anchor_options.append('OpenDART FY Source')
    if latest_fy_fundamental:
        anchor_options.append('Latest FY Fundamental')
    if selected != '직접 입력':
        anchor_options.append('Watchlist Price-linked Diagnostic')
    anchor_choice = st.radio('정상화된 잉여현금흐름/비중 기준값 출처', anchor_options, horizontal=True, key=f'reverse_anchor_source::{selected}')
    price = st.number_input('현재 가격', min_value=0.0, value=default_price, step=100.0, key=f'reverse_price::{selected}')
    anchor_source_code = ''
    anchor_confirmed = False
    anchor_period = ''
    anchor_hash = ''
    anchor_note = ''
    if anchor_choice == 'Manual Independent':
        normalized_fcf_ps = st.number_input('정상화된 연간 잉여현금흐름 / 비중', min_value=0.0, value=0.0, step=100.0, key=f'reverse_fcf_ps_manual::{selected}', help='현재가격에서 역산하지 않은 독립적 연간 정상화된 잉여현금흐름/비중을 입력합니다. 회계연도 재무, 장기 평균, 보수적 정상화 등 사용한 근거를 검토 메모에 남기세요.')
        anchor_note = st.text_input('잉여현금흐름 기준값 출처 / 검토 메모', value='', key=f'reverse_fcf_anchor_note::{selected}', placeholder='예: 2025 회계연도 영업현금흐름/잉여현금흐름 + 주기 정상화, 유지 관리 자본적 지출 별도 검토')
        anchor_confirmed = st.checkbox('정상화된 잉여현금흐름/비중이 현재가격과 독립된 기업 기초 출처/가정에서 나온 값임을 직접 확인했습니다.', key=f'reverse_fcf_anchor_confirm::{selected}')
        anchor_source_code = 'MANUAL_INDEPENDENT'
    elif anchor_choice == 'OpenDART FY Source':
        normalized_fcf_ps = float(_fy_anchor_view.get('fcf_per_share', 0) or 0)
        anchor_period = 'FY'
        anchor_note = f"{_fy_anchor_view.get('business_year', '')} FY OpenDART CFS + stock total-status"
        anchor_confirmed = st.checkbox('회계연도 재무제표의 영업현금흐름/유형자산취득, 주식수 출처, 세금/투자된 자본 추정치를 직접 검토했고 이 값이 현재가격과 독립된 회계연도 잉여현금흐름/비중 참조임을 확인했습니다.', key=f'reverse_fy_anchor_confirm::{selected}')
        st.metric('정상화된 연간 잉여현금흐름/비중', _locale.code(krw(normalized_fcf_ps)))
        st.caption(anchor_note)
        anchor_source_code = 'DART_FY_SOURCE'
    elif anchor_choice == 'Latest FY Fundamental':
        normalized_fcf_ps = float(pd.to_numeric(pd.Series([latest_fy_fundamental.get('fcf_per_share')]), errors='coerce').fillna(0).iloc[0])
        anchor_period = str(latest_fy_fundamental.get('source_period', '') or '')
        anchor_hash = snapshot_integrity_status(latest_fy_fundamental)
        anchor_note = f"{latest_fy_fundamental.get('source_business_year', '')} {anchor_period} Fundamental Snapshot"
        st.metric('정상화된 연간 잉여현금흐름/비중', _locale.code(krw(normalized_fcf_ps)))
        st.caption(anchor_note)
        anchor_confirmed = True
        anchor_source_code = 'FUNDAMENTAL_FY'
    else:
        normalized_fcf_ps = watchlist_fcf_proxy
        st.metric('가격-연결됨 잉여현금흐름/비중 진단', _locale.code(krw(normalized_fcf_ps)))
        anchor_confirmed = st.checkbox('이 값이 현재 가격 × 잉여현금흐름 수익률 × 확신도의 가격-연결됨 추정치가며 독립적 기업 기초 기준값으로 검증되지 않았음을 이해했습니다.', key=f'reverse_legacy_anchor_ack::{selected}')
        anchor_source_code = 'WATCHLIST_PRICE_LINKED'
    anchor_status = anchor_integrity_status(anchor_source_code, normalized_fcf_ps, manual_confirmed=anchor_confirmed, fundamental_hash_status=anchor_hash, fundamental_period=anchor_period, source_integrity_status=_fy_anchor_view.get('extraction_integrity_status', '') if anchor_source_code == 'DART_FY_SOURCE' else '', share_status=_fy_anchor_view.get('share_status', '') if anchor_source_code == 'DART_FY_SOURCE' else '')
    ag1, ag2, ag3 = st.columns(3)
    ag1.metric('기준값 무결성', _locale.code(anchor_status['status']))
    ag2.metric('정상화된 잉여현금흐름/비중', _locale.code(krw(normalized_fcf_ps)))
    ag3.metric('판단 활용 점검', _locale.code('정상' if anchor_status['decision_ready'] else '검토'))
    if anchor_status['status'] == 'DIAGNOSTIC_ONLY':
        st.warning('가격-연결됨 관심종목 추정치는 진단 전용입니다. 이 값으로 계산한 가격에 반영된 성장은 현재가격과 입력 기준값이 연결되어 있어 독립적인 시장-대비-기업 기초 Edge로 사용하지 않습니다.')
    elif not anchor_status['decision_ready']:
        st.warning(f"기준값 점검 검토 · {anchor_status['reason']}. 시장 가격에 반영된 계산은 독립적인 기준값 확인 후 활성화됩니다.")
    else:
        st.success(f"독립적인 기준값 정상 · {anchor_status['reason']}")
    if anchor_source_code == 'DART_FY_SOURCE' and anchor_status['decision_ready']:
        st.markdown('**회계연도 출처 참조 → 투자 가정 입력 보조**')
        _fy_revenue_ps_ref = _fy_anchor_view.get('revenue_per_share')
        _fy_roic_ref = _fy_anchor_view.get('roic_proxy')
        _revenue_key = f'reverse_revenue_ps::{selected}'
        _roic_key = f'reverse_normalized_roic::{selected}'

        def _reference_is_applied(input_key, reference_value):
            if reference_value is None:
                return False
            try:
                current_value = float(st.session_state.get(input_key, 0.0) or 0.0)
                reference_number = float(reference_value)
            except Exception:
                return False
            scale = max(1.0, abs(current_value), abs(reference_number))
            return abs(current_value - reference_number) <= scale * 1e-09
        revenue_reference_applied = _reference_is_applied(_revenue_key, _fy_revenue_ps_ref)
        roic_reference_applied = _reference_is_applied(_roic_key, _fy_roic_ref)
        reference_applied_count = int(revenue_reference_applied) + int(roic_reference_applied)
        st.markdown(f'**회계연도 참조 적용 상태 · {reference_applied_count}/2**')
        ref1, ref2 = st.columns(2)
        if ref1.button('✓ 회계연도 매출/비중 참조 적용됨' if revenue_reference_applied else '회계연도 매출/비중 참조 복사', type='primary' if revenue_reference_applied else 'secondary', disabled=_fy_revenue_ps_ref is None or revenue_reference_applied, key=f'reverse_copy_fy_revenue::{selected}'):
            st.session_state[_revenue_key] = float(_fy_revenue_ps_ref)
            st.rerun()
        if revenue_reference_applied:
            ref1.success('적용됨')
        if ref2.button('✓ 회계연도 투하자본이익률 추정치 참조 적용됨' if roic_reference_applied else '회계연도 투하자본이익률 추정치 참조 복사', type='primary' if roic_reference_applied else 'secondary', disabled=_fy_roic_ref is None or roic_reference_applied, key=f'reverse_copy_fy_roic::{selected}'):
            st.session_state[_roic_key] = float(_fy_roic_ref)
            st.rerun()
        if roic_reference_applied:
            ref2.success('적용됨')
        st.caption('버튼이 ✓ 적용됨으로 바뀌고 초록색 `적용됨` 표시가 나오면 투자 가정 입력칸에 회계연도 참조가 반영된 상태입니다. 매출/비중과 장기 투하자본이익률의 사용자 확인 체크박스는 별도 검토 단계이므로 자동 선택되지 않습니다.')
    st.subheader('3. 시장 모형 / 기업 기초 가정')
    i1, i2, i3 = st.columns(3)
    years = i1.number_input('명시적 예측 기간(년)', min_value=1, max_value=15, value=5, step=1, key=f'reverse_years::{selected}')
    required_return = i1.number_input('필요 수익률 / 가중평균자본비용 추정치', min_value=0.001, max_value=0.8, value=default_rr, step=0.005, format='%.4f', key=f'reverse_wacc::{selected}')
    terminal_growth = i1.number_input('종료 상태 성장', min_value=-0.1, max_value=0.15, value=default_tg, step=0.005, format='%.4f', key=f'reverse_tg::{selected}')
    fundamental_base_growth = i2.number_input('기업 기초 기준 잉여현금흐름 연평균성장률', min_value=-0.8, max_value=2.0, value=0.06, step=0.01, format='%.4f', key=f'reverse_base_growth::{selected}')
    base_growth_confirmed = i2.checkbox('기준 잉여현금흐름 연평균성장률 가정을 직접 검토했습니다.', key=f'reverse_base_growth_confirm::{selected}')
    normalized_roic = i2.number_input('장기 정상화된 투하자본이익률 (선택 사항)', min_value=0.0, max_value=3.0, value=0.0, step=0.01, format='%.4f', key=f'reverse_normalized_roic::{selected}')
    roic_confirmed = i2.checkbox('장기 정상화된 투하자본이익률 가정을 직접 검토했습니다.', key=f'reverse_roic_confirm::{selected}')
    normalized_revenue_ps = i3.number_input('정상화된 연간 매출 / 비중 (선택 사항)', min_value=0.0, value=0.0, step=100.0, key=f'reverse_revenue_ps::{selected}')
    revenue_confirmed = i3.checkbox('매출/비중이 연간 정상화된 출처임을 확인했습니다.', key=f'reverse_revenue_confirm::{selected}')
    fundamental_cap = i3.number_input('기업 기초 재투자 비율 / 상한 (선택 사항)', min_value=0.0, max_value=3.0, value=0.0, step=0.01, format='%.4f', key=f'reverse_fundamental_cap::{selected}', help='장기 정상화 기준의 기업 기초 재투자 비율입니다. H1 자본 Δ / 기간 세후영업이익을 자동 복사하지 않습니다.')
    cap_confirmed = i3.checkbox('기업 기초 상한/재투자 가정을 직접 검토했습니다.', key=f'reverse_cap_confirm::{selected}')
    cap_zero_intentional = i3.checkbox('0% 상한을 의도적으로 사용합니다.', key=f'reverse_cap_zero_intent::{selected}', disabled=not bool(cap_confirmed and fundamental_cap == 0), help='0.0000은 기본 미입력값과 구분하기 어렵기 때문에, 실제로 장기 재투자 0%를 가정할 때만 선택합니다.')
    readiness = assumption_readiness(anchor_ready=anchor_status['decision_ready'], base_growth_confirmed=base_growth_confirmed, revenue_confirmed=revenue_confirmed, roic_confirmed=roic_confirmed, cap_confirmed=cap_confirmed, cap_value=fundamental_cap, cap_zero_intentional=cap_zero_intentional)
    st.markdown('**투자 가정 준비 상태**')
    _locale.dataframe(st, readiness, width='stretch', hide_index=True)
    if cap_confirmed and fundamental_cap == 0 and (not cap_zero_intentional):
        st.warning('기업 기초 상한이 0.0000인데 확인 체크가 선택되어 있습니다. 0% 상한을 실제 가정하는 것이 아니라면 확인 체크를 해제하거나 값을 입력하세요. 이 상태에서는 상한 차이를 계산하지 않습니다.')
    if required_return <= terminal_growth:
        st.error('가중평균자본비용/필요 수익률은 종료 상태 성장보다 커야 합니다.')
        model_ready = False
    else:
        model_ready = bool(price > 0 and normalized_fcf_ps > 0 and anchor_status['decision_ready'])
    if not model_ready:
        st.info('주 시장 가격에 반영된 계산은 독립적인 기준값 정상 + 가격 > 0 + 가중평균자본비용 > 종료 상태 성장일 때 활성화됩니다.')
    else:
        st.subheader('4. 현재 가격에 반영된 기대')
        implied_growth_result = solve_implied_growth(price, normalized_fcf_ps, required_return, terminal_growth, int(years))
        implied_growth = implied_growth_result.get('value')
        if base_growth_confirmed:
            required_fcf_result = required_fcf_per_share(price, fundamental_base_growth, required_return, terminal_growth, int(years))
            implied_margin_result = solve_implied_fcf_margin(price, normalized_revenue_ps, fundamental_base_growth, required_return, terminal_growth, int(years)) if revenue_confirmed else {'value': None, 'status': 'REVENUE_ANCHOR_NOT_CONFIRMED'}
            implied_wacc_result = solve_implied_required_return(price, normalized_fcf_ps, fundamental_base_growth, terminal_growth, int(years))
            implied_tg_result = solve_implied_terminal_growth(price, normalized_fcf_ps, fundamental_base_growth, required_return, int(years))
        else:
            required_fcf_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
            implied_margin_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
            implied_wacc_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
            implied_tg_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
        translated_cap = capital_intensity_translation(implied_growth, normalized_roic) if roic_confirmed else {'value': None, 'status': 'NORMALIZED_ROIC_NOT_CONFIRMED'}
        cap_comparison = cap_gap(implied_growth, normalized_roic if roic_confirmed else None, fundamental_cap if cap_confirmed else None, zero_is_intentional=cap_zero_intentional)
        m1, m2, m3, m4 = st.columns(4)
        m1.metric(f'시장 가격에 반영된 {int(years)}Y 잉여현금흐름 연평균성장률', _locale.code(pct(implied_growth)))
        m2.metric('필요 잉여현금흐름/비중 @ 기준 성장', _locale.code(krw(required_fcf_result.get('value'))))
        m3.metric('가격에 반영된 잉여현금흐름 이익률 @ 기준 성장', _locale.code(pct(implied_margin_result.get('value'))))
        m4.metric('시장 가격에 반영된 상한 @ 정상화된 투하자본이익률', _locale.code(pct(translated_cap.get('value'))))
        m5, m6, m7, m8 = st.columns(4)
        m5.metric('기업 기초 기준 잉여현금흐름 연평균성장률', _locale.code(pct(fundamental_base_growth) if base_growth_confirmed else '-'))
        m6.metric('성장 기대 차이', _locale.code(pct(fundamental_base_growth - implied_growth) if base_growth_confirmed and implied_growth is not None else '-'))
        m7.metric('상한 차이 (기업 기초 - 시장)', _locale.code(pct(cap_comparison.get('gap'))), help="기업 기초 상한이 실제 입력/확인된 경우에만 계산합니다. 0.0000 기본값은 별도 '0% 상한 의도' 확인 없이는 미입력으로 처리합니다.")
        m8.metric('기준값 상태', _locale.code(anchor_status['status']))
        if not base_growth_confirmed:
            st.warning('기준 잉여현금흐름 연평균성장률이 아직 사용자 확인되지 않았습니다. 따라서 필요 잉여현금흐름/비중, 가격에 반영된 잉여현금흐름 이익률, 성장 기대 차이, 가격에 반영된 가중평균자본비용, 가격에 반영된 종료 상태 성장처럼 기준 성장에 의존하는 값은 표시하지 않습니다.')
        st.markdown('**단일 변수 손익분기 진단**')
        b1, b2 = st.columns(2)
        b1.metric('가격에 반영된 가중평균자본비용 @ 기준 성장', _locale.code(pct(implied_wacc_result.get('value'))))
        b2.metric('가격에 반영된 종료 상태 성장 @ 기준 성장', _locale.code(pct(implied_tg_result.get('value'))))
        st.caption('가격에 반영된 가중평균자본비용과 가격에 반영된 종료 상태 성장은 각각 다른 변수를 고정한 단일변수 손익분기입니다. 두 숫자를 동시에 성립하는 하나의 시장 가정으로 해석하면 안 됩니다.')
        expectation_rows = [{'Expectation': 'FCF Growth', 'Market-implied': implied_growth, 'Fundamental / Input': fundamental_base_growth if base_growth_confirmed else None, 'Gap': fundamental_base_growth - implied_growth if base_growth_confirmed and implied_growth is not None else None, 'Status': implied_growth_result.get('status')}, {'Expectation': 'Normalized FCF/share', 'Market-required @ Base Growth': required_fcf_result.get('value'), 'Fundamental / Input': normalized_fcf_ps, 'Gap': normalized_fcf_ps - required_fcf_result.get('value') if required_fcf_result.get('value') is not None else None, 'Status': required_fcf_result.get('status')}, {'Expectation': 'FCF Margin', 'Market-required @ Base Growth': implied_margin_result.get('value'), 'Fundamental / Input': normalized_fcf_ps / normalized_revenue_ps if revenue_confirmed and normalized_revenue_ps > 0 else None, 'Gap': normalized_fcf_ps / normalized_revenue_ps - implied_margin_result.get('value') if revenue_confirmed and normalized_revenue_ps > 0 and (implied_margin_result.get('value') is not None) else None, 'Status': implied_margin_result.get('status')}, {'Expectation': 'Reinvestment / CAP', 'Market-implied translation': translated_cap.get('value'), 'Fundamental / Input': fundamental_cap if cap_confirmed else None, 'Gap': cap_comparison.get('gap'), 'Status': cap_comparison.get('status')}]
        _locale.dataframe(st, pd.DataFrame(expectation_rows), width='stretch', hide_index=True)
        current_fcf_margin = normalized_fcf_ps / normalized_revenue_ps if revenue_confirmed and normalized_revenue_ps > 0 else None
        pressure = expectation_pressure_summary(current_fcf_per_share=normalized_fcf_ps, required_fcf_per_share=required_fcf_result.get('value') if base_growth_confirmed else None, current_fcf_margin=current_fcf_margin, required_fcf_margin=implied_margin_result.get('value') if base_growth_confirmed else None, implied_growth=implied_growth, normalized_roic=normalized_roic if roic_confirmed else None)
        st.markdown('**기대 부담 진단**')
        ep1, ep2, ep3 = st.columns(3)
        ep1.metric('필요 잉여현금흐름 / 기준값 잉여현금흐름', _locale.code('-' if pressure.get('required_fcf_multiple') is None else f"{pressure['required_fcf_multiple']:.2f}x"))
        ep2.metric('필요 이익률 - 기준값 이익률', _locale.code(pct(pressure.get('required_margin_gap'))))
        ep3.metric('가격에 반영된 상한 / 재투자', _locale.code(pct(pressure.get('implied_cap'))))
        if pressure.get('flags'):
            st.warning(_locale.message('기대 부담 검토 · ' + ' | '.join(pressure['flags'])))
        else:
            st.success('기대 부담: 현재 입력 기준으로 추가 경고 표시가 없습니다.')
        if translated_cap.get('value') is not None and translated_cap.get('value') > 1.0:
            st.warning('현재 시장 가격에 반영된 성장을 입력한 정상화된 투하자본이익률로 설명하려면 상한/재투자가 100%를 초과합니다. 성장·투하자본이익률·상한 정의를 다시 확인해야 하는 일관성 신호입니다.')
        st.subheader('5. 손익분기 잉여현금흐름 / 이익률 단계별 분석')
        if not base_growth_confirmed:
            st.caption('손익분기 단계별 분석 자체는 가격·가중평균자본비용·종료 상태 성장에 대한 진단표라 계속 표시합니다. 다만 6% 기준 성장 행은 아직 검토된 기업 기초 기준 가정이 아닙니다.')
        growth_ladder = sorted(set([-0.05, 0.0, 0.05, 0.1, 0.15, round(float(fundamental_base_growth), 6), round(float(implied_growth), 6) if implied_growth is not None else 0.0]))
        break_even_table = break_even_fcf_table(price, growth_ladder, required_return, terminal_growth, int(years), normalized_revenue_ps if revenue_confirmed else None)
        _locale.dataframe(st, break_even_table, width='stretch', hide_index=True)
        st.caption('각 성장 가정에서 현재가격을 정당화하려면 필요한 시작 잉여현금흐름/비중과, 매출 기준값이 있으면 필요한 잉여현금흐름 이익률을 보여줍니다.')
        st.subheader('6. 상승 시나리오 / 기준 / 하락 시나리오 / 극단적 하락')
        _base_driver_ready = bool(roic_confirmed and cap_confirmed and (fundamental_cap > 0 or (fundamental_cap == 0 and cap_zero_intentional)))
        _driver_seed = scenario_driver_seed(base_roic=normalized_roic, base_cap=fundamental_cap, base_ready=_base_driver_ready)
        scenario_seed = pd.DataFrame([{'Scenario': 'Bear', 'FCF CAGR': -0.03, 'Normalized ROIC': None, 'Reinvestment Rate': None, 'Contraction Driver': '', 'WACC': min(0.8, required_return + 0.02), 'Terminal Growth': min(terminal_growth, 0.01), 'Probability': 0.25, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}, {'Scenario': 'Base', 'FCF CAGR': fundamental_base_growth, 'Normalized ROIC': _driver_seed.get('base_roic'), 'Reinvestment Rate': _driver_seed.get('base_cap'), 'Contraction Driver': '', 'WACC': required_return, 'Terminal Growth': terminal_growth, 'Probability': 0.5, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}, {'Scenario': 'Bull', 'FCF CAGR': 0.12, 'Normalized ROIC': None, 'Reinvestment Rate': None, 'Contraction Driver': '', 'WACC': max(terminal_growth + 0.012, required_return - 0.01), 'Terminal Growth': min(terminal_growth + 0.005, max(terminal_growth + 0.001, required_return - 0.021)), 'Probability': 0.2, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}, {'Scenario': 'Tail', 'FCF CAGR': -0.2, 'Normalized ROIC': None, 'Reinvestment Rate': None, 'Contraction Driver': '', 'WACC': min(0.9, required_return + 0.05), 'Terminal Growth': min(terminal_growth, 0.0), 'Probability': 0.05, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}])
        _scenario_drafts = normalize_reverse_scenario_drafts(load_csv('reverse_dcf_scenario_drafts.csv'))
        _saved_scenario_table, _saved_scenario_at = scenario_editor_from_saved_draft(_scenario_drafts, selected)
        _scenario_seed_source = 'DEFAULT'
        if selected != '직접 입력' and (not _saved_scenario_table.empty):
            scenario_seed = _saved_scenario_table.copy()
            _scenario_seed_source = 'SAVED_DRAFT'
        sd1, sd2, sd3 = st.columns(3)
        sd1.metric('시나리오 초안 출처', _locale.code(_scenario_seed_source))
        sd2.metric('저장됨 초안', _locale.code('YES' if _scenario_seed_source == 'SAVED_DRAFT' else '금지'))
        sd3.metric('마지막 저장됨', _locale.code(_saved_scenario_at or '-'))
        if _scenario_seed_source == 'SAVED_DRAFT':
            st.success('저장된 역산 현금흐름 할인 시나리오 초안을 자동으로 불러왔습니다. 앱/버전 재시작 후에도 이 초안이 유지됩니다.')
        else:
            st.caption('아직 저장된 시나리오 초안이 없습니다. 아래 입력 후 `Scenario Draft 저장`을 누르면 다음 재시작부터 자동 복원됩니다.')
        st.markdown('**시나리오 입력 안내**')
        st.caption('투하자본이익률/상한은 자동으로 정답을 채우지 않습니다. 양(+)의 성장 시나리오는 입력한 한쪽 동인을 기준으로 다른 쪽 동인의 일관성 수준을 계산합니다. 하락 시나리오/극단적 하락처럼 잉여현금흐름 연평균성장률이 음수이면 음수 상한을 역산하지 않고 축소 동인을 사람이 직접 기술합니다.')
        template_df = scenario_template_text()
        with st.expander('발동 조건 / 행동 조건 템플릿 보기', expanded=False):
            _locale.dataframe(st, template_df, width='stretch', hide_index=True)
            st.caption('템플릿의 [기준]/[기간]은 사용자가 실제 핵심 성과 지표와 투자 근거에 맞게 채워야 합니다. 버튼 하나로 자동 승인하거나 검토됨을 체크하지 않습니다.')
        scenario_input = _locale.editor(st, scenario_seed, width='stretch', hide_index=True, disabled=['Scenario'], column_config={'FCF CAGR': st.column_config.NumberColumn('잉여현금흐름 연평균성장률', format='%.2f'), 'Normalized ROIC': st.column_config.NumberColumn('정상화된 투하자본이익률', format='%.2f', help='시나리오별 장기 투하자본이익률 가정. 자동 채우지 않습니다.'), 'Reinvestment Rate': st.column_config.NumberColumn('재투자 비율', format='%.2f', help='시나리오별 장기 상한/재투자 가정. 자동 채우지 않습니다.'), 'Contraction Driver': st.column_config.TextColumn('축소 동인', help='잉여현금흐름 연평균성장률이 음수인 시나리오에서는 투하자본이익률×경쟁우위 지속기간 역산 대신 판매량·이익률·자산 합리화·자본 회수 등 실제 축소 요인을 기술합니다.'), 'WACC': st.column_config.NumberColumn('가중평균자본비용', format='%.2f'), 'Terminal Growth': st.column_config.NumberColumn('종료 상태 성장', format='%.2f'), 'Probability': st.column_config.NumberColumn('확률', format='%.2f'), 'Trigger': st.column_config.TextColumn('발동 조건', help='이 시나리오를 활성화/재검토하게 만드는 관찰 가능한 투자 근거 조건'), 'Action Rule': st.column_config.TextColumn('행동 조건', help='시나리오가 현실화될 때 취할 행동 원칙. 자동 주문이 아니라 사용자 검토 규칙'), 'Reviewed': st.column_config.CheckboxColumn('검토됨', help='성장/투하자본이익률/상한/가중평균자본비용/TG/확률/발동 조건/행동을 직접 검토했을 때만 체크')}, key=f'reverse_scenario_editor::{selected}')
        _saved_fingerprint = scenario_draft_fingerprint(_saved_scenario_table) if not _saved_scenario_table.empty else ''
        _current_fingerprint = scenario_draft_fingerprint(scenario_input)
        _draft_dirty = _current_fingerprint != _saved_fingerprint
        sc1, sc2, sc3 = st.columns([1, 1, 2])
        sc1.metric('초안 상태', _locale.code('UNSAVED' if _draft_dirty else '저장됨'))
        if sc2.button('시나리오 초안 저장', type='primary', disabled=selected == '직접 입력' or not _draft_dirty, key=f'reverse_scenario_draft_save::{selected}'):
            _updated_drafts = upsert_reverse_scenario_draft(_scenario_drafts, selected, scenario_input, datetime.now().isoformat())
            verified_save_feedback(_updated_drafts, 'reverse_dcf_scenario_drafts.csv', f'{selected} Reverse DCF Scenario Draft를 저장했습니다.', rerun=True)
        with sc3:
            _has_saved_draft = not _saved_scenario_table.empty
            _draft_reset_confirm = st.checkbox('저장된 초안을 삭제하고 기본값으로 초기화', key=f'reverse_scenario_draft_reset_confirm::{selected}', disabled=not _has_saved_draft)
            if st.button('시나리오 초안 삭제 / 초기화', disabled=not _has_saved_draft or not _draft_reset_confirm, key=f'reverse_scenario_draft_reset::{selected}'):
                _cleaned_drafts, _removed_drafts = delete_reverse_scenario_draft(_scenario_drafts, selected)
                if _removed_drafts > 0:
                    save_csv(_cleaned_drafts, 'reverse_dcf_scenario_drafts.csv')
                    st.session_state.pop(f'reverse_scenario_editor::{selected}', None)
                    st.session_state['_save_flash'] = ('success', f'{selected} Scenario Draft를 삭제하고 기본값으로 초기화했습니다.')
                    st.rerun()
        st.caption('시나리오 초안 저장은 작업 중 입력을 보존하는 기능입니다. 승인됨/시나리오 점검 정상을 의미하지 않으며, 동인 / 발동 조건 / 행동 / 검토됨 사용자 검토 절차는 그대로 유지됩니다.')
        driver_requirement_table = scenario_driver_requirements(scenario_input)
        with st.expander('성장 ↔ 투하자본이익률 ↔ 상한 입력 보조', expanded=True):
            _locale.dataframe(st, driver_requirement_table, width='stretch', hide_index=True)
            st.caption('예: 투하자본이익률을 먼저 입력하면 `CAP required @ entered ROIC`가 계산됩니다. 이 값은 입력 보조용이며 시나리오 표에 자동 반영하지 않습니다.')
        scenario_result, scenario_summary = scenario_values(normalized_fcf_ps, scenario_input, price, int(years))
        st.markdown('**발동 조건 / 행동 입력 보조 · 직접 편집 가능**')
        st.caption('이제 파란색 읽기 전용 카드가 아니라 직접 수정할 수 있는 입력칸입니다. 템플릿을 시작점으로 사용하되 [기준]/[기간]과 `예:` 문구는 실제 핵심 성과 지표/투자 근거에 맞게 고친 뒤 초안에 반영하세요.')
        _template_lookup = {row['Scenario']: row for _, row in template_df.iterrows()}
        _helper_version = _saved_fingerprint[:10] if _saved_fingerprint else 'default'
        template_cols = st.columns(4)
        for _idx, _scenario_name in enumerate(['Bear', 'Base', 'Bull', 'Tail']):
            _t = _template_lookup[_scenario_name]
            _scenario_hit = scenario_input.loc[scenario_input['Scenario'].fillna('').astype(str).eq(_scenario_name)]
            _current_row = _scenario_hit.iloc[0].to_dict() if not _scenario_hit.empty else {}
            _template_contraction = str(_t.get('Contraction Driver Template', '') or '').strip()
            _current_contraction = str(_current_row.get('Contraction Driver', '') or '').strip()
            _current_trigger = str(_current_row.get('Trigger', '') or '').strip()
            _current_action = str(_current_row.get('Action Rule', '') or '').strip()
            _default_contraction = _current_contraction if _current_contraction else _template_contraction
            _default_trigger = _current_trigger if _current_trigger else str(_t['Trigger Template'])
            _default_action = _current_action if _current_action else str(_t['Action Template'])
            with template_cols[_idx]:
                st.markdown(f'**{_scenario_name}**')
                if _template_contraction:
                    _edited_contraction = st.text_area('축소 동인', value=_default_contraction, height=105, key=f'scenario_helper_contraction::{selected}::{_scenario_name}::{_helper_version}')
                else:
                    _edited_contraction = ''
                _edited_trigger = st.text_area('발동 조건', value=_default_trigger, height=105, key=f'scenario_helper_trigger::{selected}::{_scenario_name}::{_helper_version}')
                _edited_action = st.text_area('행동 조건', value=_default_action, height=105, key=f'scenario_helper_action::{selected}::{_scenario_name}::{_helper_version}')
                _text_same_as_draft = str(_edited_contraction or '').strip() == _current_contraction and str(_edited_trigger or '').strip() == _current_trigger and (str(_edited_action or '').strip() == _current_action)
                _has_current_scenario_text = bool(_current_trigger or _current_action or _current_contraction)
                _scenario_text_synced = bool(_text_same_as_draft and _has_current_scenario_text)
                if _scenario_text_synced:
                    st.success('✓ 현재 시나리오 초안과 동일')
                else:
                    st.warning('입력보조 내용에 초안 미반영 변경이 있습니다.')
                if st.button(f'✓ {_scenario_name} 초안 반영됨' if _scenario_text_synced else f'{_scenario_name} 입력보조 → 초안 저장', type='primary' if _scenario_text_synced else 'secondary', disabled=bool(selected == '직접 입력' or _scenario_text_synced), key=f'scenario_helper_apply::{selected}::{_scenario_name}::{_helper_version}'):
                    _updated_scenario = apply_scenario_text_inputs(scenario_input, _scenario_name, contraction_driver=_edited_contraction, trigger=_edited_trigger, action_rule=_edited_action)
                    _updated_drafts = upsert_reverse_scenario_draft(_scenario_drafts, selected, _updated_scenario, datetime.now().isoformat())
                    st.session_state.pop(f'reverse_scenario_editor::{selected}', None)
                    verified_save_feedback(_updated_drafts, 'reverse_dcf_scenario_drafts.csv', f'{selected} · {_scenario_name} 입력보조 내용을 Scenario Draft에 저장했습니다. Reviewed는 다시 직접 확인해야 합니다.', rerun=True)
        st.caption('입력보조에서 편집 후 `Draft 저장`을 누르면 상단 시나리오 표와 영구 초안 표 데이터에 반영됩니다. 검토됨은 자동 체크되지 않고, 텍스트를 바꾸면 해당 시나리오의 검토됨은 아니요로 되돌립니다.')
        s1, s2, s3 = st.columns(3)
        s1.metric('확률 합계', _locale.code(pct(scenario_summary.get('probability_sum'))))
        s2.metric('확률-가중 값 (계산)', _locale.code(krw(scenario_summary.get('probability_weighted_value'))))
        s3.metric('확인 근거 상승 여력 / 하락 위험 (계산)', _locale.code(pct(scenario_summary.get('probability_weighted_upside'))))
        if scenario_summary.get('status') != 'PASS':
            st.warning('확률 합계 100%와 각 가중평균자본비용 > 종료 상태 성장 조건을 확인하세요.')
        _locale.dataframe(st, scenario_result, width='stretch', hide_index=True)
        st.markdown('**시나리오 동인 일관성**')
        driver_table, driver_summary = scenario_driver_diagnostics(scenario_input)
        d1, d2, d3, d4 = st.columns(4)
        d1.metric('동인 완료', _locale.code(driver_summary.get('complete', 0)))
        d2.metric('동인 미완성', _locale.code(driver_summary.get('incomplete', 0)))
        d3.metric('상한 > 100%', _locale.code(driver_summary.get('cap_above_100pct', 0)))
        d4.metric('가중평균자본비용 ≤ TG', _locale.code(driver_summary.get('wacc_tg_issues', 0)))
        _locale.dataframe(st, driver_table, width='stretch', hide_index=True)
        st.caption('양(+)의 성장 시나리오에서는 투하자본이익률 × 상한으로 장기 성장 일관성을 봅니다. `Growth - ROIC×CAP`은 투자판정 점수가 아니라 가정 간 불일치 진단값입니다. 음(-)의 성장 시나리오에서는 음수 상한을 기계적으로 만들지 않고 축소 동인을 사용합니다.')
        st.markdown('**시나리오 관리 기준 점검**')
        scenario_gate = scenario_governance_gate(scenario_input, scenario_summary, driver_table)
        g1, g2, g3, g4, g5 = st.columns(5)
        g1.metric('시나리오 점검', _locale.code(scenario_gate.get('status', 'REVIEW')))
        g2.metric('동인', f"{scenario_gate.get('driver_complete', 0)}/{scenario_gate.get('driver_required', 0)}")
        g3.metric('발동 조건', f"{scenario_gate.get('trigger_complete', 0)}/{scenario_gate.get('required_rows', 0)}")
        g4.metric('행동', f"{scenario_gate.get('action_complete', 0)}/{scenario_gate.get('required_rows', 0)}")
        g5.metric('검토됨', f"{scenario_gate.get('reviewed_complete', 0)}/{scenario_gate.get('required_rows', 0)}")
        if scenario_gate.get('status') != 'PASS':
            st.warning(_locale.message('시나리오 판단 활용 점검 = 검토 · ' + ' | '.join(scenario_gate.get('issues', []))))
            st.caption('확률-가중 값은 가치 평가 계산 진단으로는 볼 수 있지만, 투하자본이익률/상한 동인·발동 조건·행동·사용자 검토가 모두 채워지기 전에는 완성된 시나리오 판단 모형으로 사용하지 않습니다.')
        else:
            st.success('시나리오 판단 활용 점검 정상 · 가치 평가 계산 / 동인 / 발동 조건 / 행동 / 검토가 모두 완성되었습니다.')
        _base_driver_status = ''
        if driver_table is not None and (not driver_table.empty):
            _base_hit = driver_table.loc[driver_table['Scenario'].fillna('').astype(str).eq('Base')]
            if not _base_hit.empty:
                _base_driver_status = str(_base_hit.iloc[0].get('Status', '') or '').upper()
        if not _base_driver_ready:
            if _base_driver_status == 'COMPLETE':
                st.success('기준 시나리오 투하자본이익률/상한 동인은 자동 seed가 아니라 사용자가 직접 입력해 완료 상태입니다.')
            else:
                st.info('기준 시나리오 투하자본이익률/상한 동인은 기업 기초 상한이 아직 준비 완료가 아니므로 자동 입력하지 않았습니다.')
        st.subheader('7. 성장 × 가중평균자본비용 민감도')
        center_growth = implied_growth if implied_growth is not None else fundamental_base_growth
        growth_values = sorted(set((round(x, 8) for x in [max(-0.9, center_growth - 0.06), max(-0.9, center_growth - 0.03), center_growth, min(2.0, center_growth + 0.03), min(2.0, center_growth + 0.06)])))
        wacc_values = sorted(set((round(x, 8) for x in [max(terminal_growth + 0.005, required_return - 0.02), max(terminal_growth + 0.005, required_return - 0.01), required_return, min(0.8, required_return + 0.01), min(0.8, required_return + 0.02)])))
        sensitivity = sensitivity_matrix(normalized_fcf_ps, growth_values, wacc_values, terminal_growth, int(years))
        _locale.dataframe(st, sensitivity, width='stretch', hide_index=True)
        st.subheader('8. 판단 연결')
        st.write('**확인 순서:** 독립적인 잉여현금흐름 기준값 → 시장 가격에 반영된 성장 → 손익분기 잉여현금흐름/이익률 → 투하자본이익률로 번역한 시장 가격에 반영된 상한 → 기업 기초 상한 → 상승 시나리오/기준/하락 시나리오/극단적 하락 → 시나리오 성장·투하자본이익률·상한 일관성 → 발동 조건 → 행동 조건 → 사용자 검토 → 민감도.')
        st.caption('기업의 실제 미래와 시장 가격에 반영된 미래의 차이는 가정 차이입니다. 이 화면은 자동 매수·매도 판정을 하지 않습니다.')
        if selected != '직접 입력':
            b1, b2 = st.columns(2)
            b1.button('시나리오 새로 읽기에서 투자 근거 반영', key='reverse_dcf_to_scenario_refresh', on_click=_navigate, args=('Scenario Refresh', {'scenario_refresh_company': selected}))
            b2.button('기업 기초 분석 엔진 확인', key='reverse_dcf_to_fundamental', on_click=_navigate, args=('Fundamental Engine', {'fundamental_company': selected}))
