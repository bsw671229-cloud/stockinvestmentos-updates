from __future__ import annotations
import ui_locale as _locale
if True:
    st.title(f'자본 효율 / {VERSION}')
    st.caption('다음 1원을 현재 보유 종목 / 현금 / 관심종목 후보 사이에서 같은 향후 기간으로 비교하는 진단 작업 화면입니다.')
    st.info('이 화면은 투자대상을 자동 선택하지 않습니다. 예상 수익률·위험 차감치·최소 요구수익률·처리 용량을 출처 근거 기반 사용자 검토로 입력한 뒤 비용 차감 후 교체 효과와 점검을 비교합니다.')
    st.subheader('1A. 출처 근거 기반 투자 가정 입력 보조')
    st.caption('기존 관심종목 / 투자 근거 / 기업 기초 / 투자 단계 / 처리 용량 정보를 모아 최소 요구수익률·처리 용량·출처 입력을 보조합니다. 예상 수익률과 위험 차감치는 자동 입력하지 않습니다.')
    cp_inputs = normalize_capital_productivity_inputs(load_csv('capital_productivity_inputs.csv'))
    cp_universe = capital_productivity_universe(portfolio, watchlist, cp_inputs, total_assets)
    cp_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap) if not watchlist.empty else pd.DataFrame()
    cp_fundamentals = load_csv('fundamental_snapshots.csv')
    cp_assist = capital_productivity_source_assist(cp_universe, watchlist, cp_states, audit_evidence, cp_fundamentals)
    if cp_assist.empty:
        st.info('출처 입력 보조 대상이 없습니다.')
    else:
        ca1, ca2, ca3 = st.columns(3)
        _assist_ready = int(cp_assist['assist_status'].fillna('').astype(str).str.upper().eq('SOURCE_READY').sum())
        ca1.metric('출처 준비 완료', _locale.code(_assist_ready))
        ca2.metric('출처 검토', _locale.code(int(len(cp_assist) - _assist_ready)))
        ca3.metric('입력 보조 후보', _locale.code(len(cp_assist)))
        assist_cols = ['name', 'kind', 'hurdle_reference', 'hurdle_source', 'fcf_yield_reference', 'fundamental_reference', 'fundamental_review_status', 'evidence_status', 'evidence_source_count', 'lifecycle', 'add_freeze', 'capacity_reference_krw', 'missing_assumptions', 'assist_status', 'assist_issues']
        _locale.dataframe(st, cp_assist[[c for c in assist_cols if c in cp_assist.columns]], width='stretch', hide_index=True)
        cp_assist_names = cp_assist['name'].fillna('').astype(str).tolist()
        _pilot_preferred = ['현금 (CASH)', '삼성전자', 'NICE평가정보']
        _pilot_default = [x for x in _pilot_preferred if x in cp_assist_names]
        cp_assist_targets = st.multiselect('출처 입력 보조 적용 대상', cp_assist_names, default=_pilot_default, key='capital_productivity_assist_targets', help='기본 소규모 시험은 현금 / 삼성전자 / NICE평가정보입니다. 최소 요구수익률 / 처리 용량 / 출처만 보조하며 예상 수익률 / 위험 차감치는 비워둡니다.')
        cp_assist_confirm = st.checkbox('출처 입력 보조의 최소 요구수익률 / 투자 근거 / 기업 기초 / 처리 용량 근거를 직접 검토했습니다.', key='capital_productivity_assist_confirm')
        if st.button('출처 입력 보조 → 최소 요구수익률 / 처리 용량 / 출처 입력 보조', disabled=not cp_assist_confirm, key='capital_productivity_assist_apply'):
            _cp_assisted, _cp_assisted_count = apply_capital_productivity_source_assist(cp_inputs, cp_assist, cp_assist_targets)
            if _cp_assisted_count <= 0:
                st.info('새로 반영할 출처 입력 보조 값이 없습니다.')
            else:
                verified_save_feedback(_cp_assisted, 'capital_productivity_inputs.csv', f'Source Assist {_cp_assisted_count}건을 입력 보조로 반영했습니다. Forward ER / Risk Penalty / Reviewed는 자동 입력하지 않았습니다.', rerun=True)
    st.subheader('1A-2. 예상 수익률 / 위험 차감치 검토 입력 보조')
    st.caption('예상 수익률과 위험 차감치를 자동 산출하지 않습니다. 잉여현금흐름 수익률·하락 시나리오 하락 위험·시나리오·투자 근거·투자 단계를 한곳에 모아 사람이 같은 향후 기간으로 검토합니다.')
    cp_scenarios = load_csv('scenario_refresh_reviews.csv')
    cp_forward_risk = capital_productivity_forward_risk_assist(cp_assist, watchlist, cp_scenarios)
    if cp_forward_risk.empty:
        st.info('예상 수익률 / 위험 차감치 검토 입력 보조 대상이 없습니다.')
    else:
        review_cols = ['name', 'kind', 'hurdle_reference', 'fcf_yield_reference', 'canonical_bear_downside', 'fcf_confidence', 'evidence_status', 'refinancing_gate', 'lifecycle', 'add_freeze', 'fundamental_reference', 'latest_scenario_event', 'scenario_pw_value_delta', 'scenario_bear_downside', 'scenario_thesis_signal', 'scenario_evidence_signal', 'scenario_combined_signal', 'risk_reference_flags']
        _locale.dataframe(st, cp_forward_risk[[c for c in review_cols if c in cp_forward_risk.columns]], width='stretch', hide_index=True)
        _review_names = cp_forward_risk['name'].fillna('').astype(str).tolist()
        _default_review_index = _review_names.index('삼성전자') if '삼성전자' in _review_names else 0
        cp_review_name = st.selectbox('예상 수익률 / 위험 차감치 검토 대상', _review_names, index=_default_review_index, key='capital_productivity_forward_risk_target')
        _review_hit = cp_forward_risk.loc[cp_forward_risk['name'].fillna('').astype(str).eq(cp_review_name)]
        _review_ref = _review_hit.iloc[0].to_dict() if not _review_hit.empty else {}
        fr1, fr2, fr3, fr4 = st.columns(4)
        fr1.metric('최소 요구수익률 참조', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_review_ref.get('hurdle_reference')]), errors='coerce').iloc[0]) else pct(_review_ref.get('hurdle_reference'))))
        fr2.metric('잉여현금흐름 수익률 참조', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_review_ref.get('fcf_yield_reference')]), errors='coerce').iloc[0]) else pct(_review_ref.get('fcf_yield_reference'))))
        fr3.metric('기준 원장 하락 시나리오', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_review_ref.get('canonical_bear_downside')]), errors='coerce').iloc[0]) else pct(_review_ref.get('canonical_bear_downside'))))
        fr4.metric('투자 단계', _locale.code(str(_review_ref.get('lifecycle', '') or '-')))
        st.caption('예상 수익률은 최소 요구수익률/잉여현금흐름 수익률/시나리오를 참고하되 자동 계산하지 않습니다. 위험 차감치도 하락 시나리오 하락 위험/투자 단계/투자 근거를 보고 사람이 별도로 정합니다.')
        rr1, rr2 = st.columns(2)
        cp_forward_er_text = rr1.text_input('향후 기대수익률(소수 입력)', value='', key='capital_productivity_review_forward_er', placeholder='예: 0.10', help='모든 후보에 같은 향후 기간을 사용하세요.')
        cp_risk_penalty_text = rr2.text_input('위험 차감치(소수 입력)', value='', key='capital_productivity_review_risk_penalty', placeholder='예: 0.02', help='하락 시나리오/투자 단계/투자 근거 등 예상 수익률에 충분히 반영되지 않은 위험 차감값.')
        cp_review_basis = st.text_area('예상 수익률 / 위험 차감치 검토 근거', value='', key='capital_productivity_review_basis', height=100, placeholder='예: 12개월 기준. 잉여현금흐름 수익률, 시나리오 새로 읽기, 하락 시나리오 하락 위험, 투자 근거/투자 단계를 함께 검토. 시장 가격에 반영된 성장을 기대수익으로 그대로 사용하지 않음.')
        rc1, rc2, rc3 = st.columns(3)
        cp_horizon_confirmed = rc1.checkbox('자금 제공 자산/자금 수령 자산과 같은 향후 기간을 사용했습니다.', key='capital_productivity_review_horizon_confirmed')
        cp_risk_confirmed = rc2.checkbox('하락 시나리오 하락 위험 / 투자 근거 / 투자 단계 위험을 다시 확인했습니다.', key='capital_productivity_review_risk_confirmed')
        cp_human_confirmed = rc3.checkbox('예상 수익률과 위험 차감치를 직접 검토했습니다.', key='capital_productivity_review_human_confirmed')
        cp_review_due = st.date_input('향후 기준 가정 검토 기한', value=date.today() + timedelta(days=int(settings.get('capital_productivity_review_days', 30))), key='capital_productivity_review_due')
        cp_manual_gate = validate_capital_productivity_manual_review(forward_er_text=cp_forward_er_text, risk_penalty_text=cp_risk_penalty_text, review_basis=cp_review_basis, review_due_date=cp_review_due, horizon_confirmed=cp_horizon_confirmed, risk_reference_confirmed=cp_risk_confirmed, human_confirmed=cp_human_confirmed)
        mg1, mg2 = st.columns(2)
        mg1.metric('수동 검토 점검', _locale.code(cp_manual_gate['status']))
        mg2.metric('검토 문제', _locale.code(len(cp_manual_gate['issues'])))
        if cp_manual_gate['status'] != 'PASS':
            st.warning(_locale.message('향후/위험 검토 미완료 · ' + ' | '.join(cp_manual_gate['issues'])))
        else:
            st.success('예상 수익률 / 위험 차감치 사용자 검토가 완료되었습니다. 아래 버튼은 투자 가정 등록부에 검토값을 저장할 뿐 투자결론을 만들지 않습니다.')
        if st.button('검토된 예상 수익률 / 위험 차감치 → 투자 가정 등록부 반영', disabled=cp_manual_gate['status'] != 'PASS', key='capital_productivity_review_apply'):
            _cp_reviewed = apply_reviewed_capital_productivity_assumption(cp_inputs, _review_ref, forward_er=float(cp_manual_gate['forward_er']), risk_penalty=float(cp_manual_gate['risk_penalty']), review_basis=cp_review_basis, review_due_date=cp_manual_gate['review_due_date'])
            verified_save_feedback(_cp_reviewed, 'capital_productivity_inputs.csv', f'{cp_review_name} Forward ER / Risk Penalty Human Review를 Assumption Register에 반영했습니다.', rerun=True)
    st.subheader('1A-3. 예상 수익률 / 위험 차감치 보정 범위')
    st.caption('선택사항입니다. 시스템이 숫자를 추천하지 않고, 사람이 입력한 낮음 / 기준 / 높음 범위를 동일 최소 요구수익률 기준으로 정렬해 위험 조정 기대수익률과 최소 요구수익률 매수·매도 호가 차이를 계산합니다.')
    if cp_forward_risk.empty:
        st.info('보정 대상이 없습니다.')
    else:
        _cal_names = cp_forward_risk['name'].fillna('').astype(str).tolist()
        _cal_default_index = _cal_names.index('NICE평가정보') if 'NICE평가정보' in _cal_names else 0
        cp_cal_name = st.selectbox('보정 대상', _cal_names, index=_cal_default_index, key='capital_productivity_calibration_target')
        _cal_hit = cp_forward_risk.loc[cp_forward_risk['name'].fillna('').astype(str).eq(cp_cal_name)]
        _cal_ref = _cal_hit.iloc[0].to_dict() if not _cal_hit.empty else {}
        cr1, cr2, cr3, cr4, cr5, cr6 = st.columns(6)
        cr1.metric('최소 요구수익률 참조', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_cal_ref.get('hurdle_reference')]), errors='coerce').iloc[0]) else pct(_cal_ref.get('hurdle_reference'))))
        cr2.metric('잉여현금흐름 수익률 참조', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_cal_ref.get('fcf_yield_reference')]), errors='coerce').iloc[0]) else pct(_cal_ref.get('fcf_yield_reference'))))
        cr3.metric('기준 원장 하락 시나리오', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_cal_ref.get('canonical_bear_downside')]), errors='coerce').iloc[0]) else pct(_cal_ref.get('canonical_bear_downside'))))
        cr4.metric('시나리오 하락 시나리오', _locale.code('-' if pd.isna(pd.to_numeric(pd.Series([_cal_ref.get('scenario_bear_downside')]), errors='coerce').iloc[0]) else pct(_cal_ref.get('scenario_bear_downside'))))
        cr5.metric('투자 근거', _locale.code(str(_cal_ref.get('evidence_status', '') or '-')))
        cr6.metric('투자 단계', _locale.code(str(_cal_ref.get('lifecycle', '') or '-')))
        _cal_flags = str(_cal_ref.get('risk_reference_flags', '') or '').strip()
        if _cal_flags:
            st.warning(_locale.message('참조 표시 · ' + _cal_flags + '. 이 표시는 자동 차감치 숫자로 변환하지 않습니다.'))
        cp_cal_horizon = st.text_input('향후 투자 기간', value='12M', key='capital_productivity_calibration_horizon', help='모든 비교대상에서 같은 향후 기간을 사용하세요.')
        erc1, erc2, erc3 = st.columns(3)
        cp_er_low = erc1.text_input('예상 수익률 낮음', value='', key='capital_productivity_calibration_er_low', placeholder='예: 0.06')
        cp_er_base = erc2.text_input('예상 수익률 기준', value='', key='capital_productivity_calibration_er_base', placeholder='예: 0.09')
        cp_er_high = erc3.text_input('예상 수익률 높음', value='', key='capital_productivity_calibration_er_high', placeholder='예: 0.12')
        rpc1, rpc2, rpc3 = st.columns(3)
        cp_risk_low = rpc1.text_input('위험 차감치 낮음', value='', key='capital_productivity_calibration_risk_low', placeholder='예: 0.01')
        cp_risk_base = rpc2.text_input('위험 차감치 기준', value='', key='capital_productivity_calibration_risk_base', placeholder='예: 0.02')
        cp_risk_high = rpc3.text_input('위험 차감치 높음', value='', key='capital_productivity_calibration_risk_high', placeholder='예: 0.04')
        cp_cal_basis = st.text_area('보정 검토 근거', value='', key='capital_productivity_calibration_basis', height=110, placeholder='예: 12M 기준. 잉여현금흐름 수익률 / 시나리오 / 하락 시나리오 하락 위험 / 투자 근거 / 차환 / 투자 단계를 참고. 예상 수익률과 위험 차감치 범위는 사람이 직접 입력.')
        cc1, cc2, cc3 = st.columns(3)
        cp_cal_horizon_confirmed = cc1.checkbox('모든 비교대상에 같은 향후 투자 기간을 적용했습니다.', key='capital_productivity_calibration_horizon_confirmed')
        cp_cal_reference_confirmed = cc2.checkbox('잉여현금흐름 수익률 / 하락 시나리오 / 시나리오 / 투자 근거 / 투자 단계 참조를 직접 확인했습니다.', key='capital_productivity_calibration_reference_confirmed')
        cp_cal_human_confirmed = cc3.checkbox('낮음 / 기준 / 높음 범위를 직접 검토했습니다.', key='capital_productivity_calibration_human_confirmed')
        cp_cal_due = st.date_input('보정 검토 기한', value=date.today() + timedelta(days=int(settings.get('capital_productivity_review_days', 30))), key='capital_productivity_calibration_due')
        cp_calibration = validate_forward_risk_calibration(er_low_text=cp_er_low, er_base_text=cp_er_base, er_high_text=cp_er_high, risk_low_text=cp_risk_low, risk_base_text=cp_risk_base, risk_high_text=cp_risk_high, hurdle_rate=_cal_ref.get('hurdle_reference'), forward_horizon=cp_cal_horizon, review_basis=cp_cal_basis, review_due_date=cp_cal_due, horizon_confirmed=cp_cal_horizon_confirmed, reference_confirmed=cp_cal_reference_confirmed, human_confirmed=cp_cal_human_confirmed)
        calp1, calp2, calp3, calp4 = st.columns(4)
        calp1.metric('보정 점검', _locale.code(cp_calibration['status']))
        calp2.metric('낮음 위험 조정 기대수익률', _locale.code('-' if cp_calibration['risk_adjusted_low'] is None else pct(cp_calibration['risk_adjusted_low'])))
        calp3.metric('기준 위험 조정 기대수익률', _locale.code('-' if cp_calibration['risk_adjusted_base'] is None else pct(cp_calibration['risk_adjusted_base'])))
        calp4.metric('높음 위험 조정 기대수익률', _locale.code('-' if cp_calibration['risk_adjusted_high'] is None else pct(cp_calibration['risk_adjusted_high'])))
        if cp_calibration['risk_adjusted_low'] is not None:
            cp_cal_table = pd.DataFrame([{'Point': 'LOW_ER_HIGH_RISK', 'Forward ER': cp_calibration['er_low'], 'Risk Penalty': cp_calibration['risk_high'], 'Risk-adjusted ER': cp_calibration['risk_adjusted_low'], 'Hurdle': cp_calibration['hurdle_rate'], 'Hurdle Spread': cp_calibration['hurdle_spread_low']}, {'Point': 'BASE', 'Forward ER': cp_calibration['er_base'], 'Risk Penalty': cp_calibration['risk_base'], 'Risk-adjusted ER': cp_calibration['risk_adjusted_base'], 'Hurdle': cp_calibration['hurdle_rate'], 'Hurdle Spread': cp_calibration['hurdle_spread_base']}, {'Point': 'HIGH_ER_LOW_RISK', 'Forward ER': cp_calibration['er_high'], 'Risk Penalty': cp_calibration['risk_low'], 'Risk-adjusted ER': cp_calibration['risk_adjusted_high'], 'Hurdle': cp_calibration['hurdle_rate'], 'Hurdle Spread': cp_calibration['hurdle_spread_high']}])
            for _c in ['Forward ER', 'Risk Penalty', 'Risk-adjusted ER', 'Hurdle', 'Hurdle Spread']:
                cp_cal_table[_c] = pd.to_numeric(cp_cal_table[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            _locale.dataframe(st, cp_cal_table, width='stretch', hide_index=True)
        if cp_calibration['status'] != 'PASS':
            st.warning(_locale.message('보정 검토 미완료 · ' + ' | '.join(cp_calibration['issues'])))
        else:
            st.success('보정 범위 사용자 검토가 완료됐습니다. 아래에서 적용할 시점을 사람이 직접 선택해야 하며 자동 선택하지 않습니다.')
        cp_cal_selected = st.radio('투자 가정 등록부에 반영할 시점', ['LOW_ER_HIGH_RISK', 'BASE', 'HIGH_ER_LOW_RISK'], index=1, horizontal=True, disabled=cp_calibration['status'] != 'PASS', key='capital_productivity_calibration_selected_point', format_func=_locale.option())
        cp_selected_values = calibration_point_values(cp_calibration, cp_cal_selected)
        if cp_selected_values['status'] == 'PASS':
            sp1, sp2, sp3 = st.columns(3)
            sp1.metric('선택됨 예상 수익률', _locale.code(pct(cp_selected_values['forward_er'])))
            sp2.metric('선택됨 위험 차감치', _locale.code(pct(cp_selected_values['risk_penalty'])))
            sp3.metric('선택됨 최소 요구수익률 매수·매도 호가 차이', _locale.code(pct(cp_selected_values['hurdle_spread'])))
        cp_cal_purpose = st.radio('보정 목적', ['PILOT_TEST', 'OPERATING_ASSUMPTION'], index=0, horizontal=True, key='capital_productivity_calibration_purpose', help='PILOT_TEST는 기능/범위 검증용으로 운영 투자 가정에 승격할 수 없습니다. OPERATING_ASSUMPTION만 별도 승인 관리 기준을 통과한 뒤 승격할 수 있습니다.', format_func=_locale.option())
        cp_cal_note = st.text_input('보정 초안 메모', value='', key='capital_productivity_calibration_note', placeholder='예: 소규모 시험 범위 계산 검사')
        cp_draft_confirm = st.checkbox('현재 보정 범위와 시점을 초안으로만 저장합니다. 투자 가정 등록부에는 아직 반영하지 않습니다.', key='capital_productivity_calibration_draft_confirm', disabled=cp_selected_values['status'] != 'PASS')
        if st.button('보정 초안 저장', disabled=cp_selected_values['status'] != 'PASS' or not cp_draft_confirm, key='capital_productivity_calibration_draft_save'):
            _draft_row = build_calibration_draft(_cal_ref, cp_calibration, cp_selected_values, purpose=cp_cal_purpose, review_basis=cp_cal_basis, note=cp_cal_note)
            _draft_hist = normalize_calibration_drafts(load_csv('capital_productivity_calibration_drafts.csv'))
            _draft_hist = pd.concat([_draft_hist[CAPITAL_PRODUCTIVITY_CALIBRATION_DRAFT_COLS], pd.DataFrame([_draft_row])], ignore_index=True)
            verified_save_feedback(_draft_hist, 'capital_productivity_calibration_drafts.csv', f'{cp_cal_name} Calibration을 {cp_cal_purpose} DRAFT로 저장했습니다. 운영 Assumption은 변경하지 않았습니다.', rerun=True)
    st.subheader('1A-4. 보정 초안 / 승인 관리 기준')
    st.caption('초안은 운영 투자 가정과 분리됩니다. PILOT_TEST는 승격할 수 없고, 운영 · 투자 가정 초안만 무결성 해시 / 참조 일치 / 사용자 승인을 통과한 뒤 투자 가정 등록부에 반영할 수 있습니다.')
    cp_drafts = normalize_calibration_drafts(load_csv('capital_productivity_calibration_drafts.csv'))
    if cp_drafts.empty:
        st.info('아직 저장된 보정 초안이 없습니다. 위 1A-3에서 먼저 초안을 저장하세요.')
    else:
        ds1, ds2, ds3, ds4 = st.columns(4)
        _draft_status = cp_drafts['approval_status'].fillna('').astype(str).str.upper()
        _draft_purpose = cp_drafts['purpose'].fillna('').astype(str).str.upper()
        ds1.metric('초안', _locale.code(int(_draft_status.eq('DRAFT').sum())))
        ds2.metric('승인됨', _locale.code(int(_draft_status.eq('APPROVED').sum())))
        ds3.metric('소규모 시험 검사', _locale.code(int(_draft_purpose.eq('PILOT_TEST').sum())))
        ds4.metric('운영', _locale.code(int(_draft_purpose.eq('OPERATING_ASSUMPTION').sum())))
        draft_view_cols = ['calibration_id', 'created_at', 'approval_status', 'purpose', 'name', 'selected_point', 'selected_forward_er', 'selected_risk_penalty', 'selected_hurdle_spread', 'review_due_date', 'hash_schema', 'execution_authorization']
        _locale.dataframe(st, cp_drafts[draft_view_cols].tail(50), width='stretch', hide_index=True)
        _draft_options = cp_drafts['calibration_id'].fillna('').astype(str).tolist()
        _draft_labels = {}
        for _, _drow in cp_drafts.iterrows():
            _did = str(_drow.get('calibration_id', '') or '')
            _draft_labels[_did] = f"{_did} · {_drow.get('name', '')} · {_drow.get('purpose', '')} · {_drow.get('approval_status', '')}"
        cp_draft_id = st.selectbox('승인 검토 초안', _draft_options, format_func=lambda x: _draft_labels.get(x, x), key='capital_productivity_approval_draft_id')
        _d_hit = cp_drafts.loc[cp_drafts['calibration_id'].eq(cp_draft_id)]
        _d_row = _d_hit.iloc[-1].to_dict() if not _d_hit.empty else {}
        _d_name = str(_d_row.get('name', '') or '')
        _current_ref_hit = cp_forward_risk.loc[cp_forward_risk['name'].fillna('').astype(str).eq(_d_name)] if not cp_forward_risk.empty else pd.DataFrame()
        _current_ref = _current_ref_hit.iloc[0].to_dict() if not _current_ref_hit.empty else {}
        _hash_integrity = calibration_draft_integrity(_d_row)
        _current_ref_hash = calibration_reference_hash(_current_ref)
        _reference_match = 'MATCH' if str(_d_row.get('reference_hash', '') or '') == _current_ref_hash and bool(str(_d_row.get('reference_hash', '') or '')) else 'MISMATCH'
        ag1, ag2, ag3, ag4, ag5 = st.columns(5)
        ag1.metric('초안 상태', _locale.code(str(_d_row.get('approval_status', '') or '-')))
        ag2.metric('목적', _locale.code(str(_d_row.get('purpose', '') or '-')))
        ag3.metric('무결성 해시 무결성', _locale.code(_hash_integrity))
        st.caption(f"보정 무결성 해시 저장 구조: {str(_d_row.get('hash_schema', '') or 'legacy-v1')}")
        ag4.metric('참조', _locale.code(_reference_match))
        ag5.metric('투자 실행 권한', '없음')
        st.caption(f"선택됨 시점: {_d_row.get('selected_point', '-')} · 예상 수익률: {pct(_d_row.get('selected_forward_er'))} · 위험 차감치: {pct(_d_row.get('selected_risk_penalty'))} · 최소 요구수익률 매수·매도 호가 차이: {pct(_d_row.get('selected_hurdle_spread'))}")
        _draft_hash_schema = str(_d_row.get('hash_schema', '') or '').strip().lower()
        if _draft_hash_schema != 'v2':
            st.warning('이 초안은 dev6 기존 무결성 해시 저장 구조입니다. pandas 표 데이터 소수점 수 저장 후 재읽기 때문에 잘못된 불일치가 발생할 수 있어 승인 대상으로 사용하지 않습니다. 1A-3에서 현재 범위를 다시 검토해 새 초안으로 저장하면 안정된 2세대 무결성 해시가 적용됩니다.')
        if str(_d_row.get('purpose', '') or '').upper() == 'PILOT_TEST':
            st.info('이 초안은 PILOT_TEST입니다. 계산/기능 검증용으로 보관되며 투자 가정 등록부로 승격할 수 없습니다.')
        cp_approval_note = st.text_area('승인 메모', value='', key='capital_productivity_approval_note', height=90, placeholder='예: 운영 투자 가정으로 사용할 범위/시점과 현재 참조를 재검토함.')
        ac1, ac2 = st.columns(2)
        cp_draft_reconfirmed = ac1.checkbox('초안의 낮음 / 기준 / 높음 범위와 선택됨 시점을 다시 검토했습니다.', key='capital_productivity_draft_reconfirmed')
        cp_reference_reconfirmed = ac2.checkbox('현재 출처 / 기업 기초 / 시나리오 참조와 무결성 식별값 일치를 확인했습니다.', key='capital_productivity_reference_reconfirmed')
        ac3, ac4 = st.columns(2)
        cp_operating_confirmed = ac3.checkbox('이 초안을 테스트가 아닌 OPERATING_ASSUMPTION으로 사용할 것을 확인했습니다.', key='capital_productivity_operating_use_confirmed')
        cp_approval_human = ac4.checkbox('최종 사용자 승인을 완료했습니다.', key='capital_productivity_approval_human')
        cp_approval_gate = calibration_approval_gate(_d_row, _current_ref, draft_reconfirmed=cp_draft_reconfirmed, reference_reconfirmed=cp_reference_reconfirmed, operating_use_confirmed=cp_operating_confirmed, human_approval_confirmed=cp_approval_human, approval_note=cp_approval_note)
        pg1, pg2, pg3, pg4 = st.columns(4)
        pg1.metric('승인 점검', _locale.code(cp_approval_gate['status']))
        pg2.metric('무결성 해시', _locale.code(cp_approval_gate['integrity']))
        pg3.metric('참조 일치', _locale.code(cp_approval_gate['reference_match']))
        pg4.metric('검토 기한', _locale.code(cp_approval_gate['review_due_gate']))
        if cp_approval_gate['status'] != 'PASS':
            st.warning(_locale.message('보정 승인 미완료 · ' + ' | '.join(cp_approval_gate['issues'])))
        else:
            st.success('승인 점검 정상. 아래 승격 버튼은 승인됨 기록과 투자 가정 등록부를 함께 갱신하지만 투자 실행 권한은 없음입니다.')
        if st.button('승인됨 승격 + 투자 가정 등록부 반영', disabled=cp_approval_gate['status'] != 'PASS', key='capital_productivity_approve_and_apply'):
            _approved_drafts, _approval_result = approve_calibration_draft(cp_drafts, cp_draft_id, approval_note=cp_approval_note)
            if _approval_result['status'] != 'PASS':
                st.error(_locale.message('보정 승인 실패 · ' + ' | '.join(_approval_result['issues'])))
            else:
                _approved_row = _approval_result['approved_row']
                _updated_inputs, _apply_result = apply_approved_calibration_draft(cp_inputs, _approved_row)
                if _apply_result['status'] != 'PASS':
                    st.error(_locale.message('투자 가정 등록부 반영 실패 · ' + ' | '.join(_apply_result['issues'])))
                else:
                    _final_hist = load_csv('capital_productivity_calibrations.csv')
                    for _col in CAPITAL_PRODUCTIVITY_CALIBRATION_COLS:
                        if _col not in _final_hist.columns:
                            _final_hist[_col] = ''
                    _final_row = approved_calibration_audit_record(_approved_row)
                    _final_hist = pd.concat([_final_hist[CAPITAL_PRODUCTIVITY_CALIBRATION_COLS], pd.DataFrame([_final_row])], ignore_index=True)
                    try:
                        save_csv(_approved_drafts, 'capital_productivity_calibration_drafts.csv')
                        save_csv(_updated_inputs, 'capital_productivity_inputs.csv')
                        save_csv(_final_hist, 'capital_productivity_calibrations.csv')
                        st.session_state['_save_flash'] = ('success', f'{_d_name} Calibration DRAFT를 APPROVED로 승격하고 Assumption Register에 반영했습니다. Execution Authorization = NONE.')
                        st.rerun()
                    except Exception as e:
                        st.error(f'보정 승인 저장 실패: {e}')
    st.subheader('1B. 사용자 확인 투자 가정 등록부')
    cp_inputs = normalize_capital_productivity_inputs(load_csv('capital_productivity_inputs.csv'))
    cp_universe = capital_productivity_universe(portfolio, watchlist, cp_inputs, total_assets)
    if cp_universe.empty:
        st.info('자본 효율 비교대상이 없습니다.')
        cp_edited = pd.DataFrame(columns=CAPITAL_PRODUCTIVITY_INPUT_COLS)
    else:
        cp_edit = cp_universe[['name', 'ticker', 'kind', 'forward_er', 'risk_penalty', 'hurdle_rate', 'capacity_headroom_krw', 'reviewed', 'source', 'review_due_date', 'note']].copy()
        cp_edit['review_due_date'] = pd.to_datetime(cp_edit['review_due_date'], errors='coerce')
        _cp_editor_source_csv = cp_edit.copy().fillna('').astype(str).to_csv(index=False, lineterminator='\n')
        _cp_editor_fingerprint = hashlib.sha256(_cp_editor_source_csv.encode('utf-8')).hexdigest()[:16]
        _cp_editor_key = 'capital_productivity_input_editor::' + _cp_editor_fingerprint
        _cp_previous_editor_key = st.session_state.get('_capital_productivity_editor_widget_key', '')
        if _cp_previous_editor_key and _cp_previous_editor_key != _cp_editor_key:
            st.session_state.pop(_cp_previous_editor_key, None)
        st.session_state['_capital_productivity_editor_widget_key'] = _cp_editor_key
        st.caption(f'투자 가정 등록부 편집기 동기화 · 저장됨-출처 무결성 식별값 `{_cp_editor_fingerprint}` · 출처 입력 보조/보정 승인으로 원장이 바뀌면 편집기도 새 원장으로 자동 동기화됩니다.')
        cp_edited = _locale.editor(st, cp_edit, width='stretch', hide_index=True, disabled=['name', 'ticker', 'kind'], column_config={'forward_er': st.column_config.NumberColumn('예상 수익률', min_value=-1.0, max_value=5.0, step=0.01, format='%.3f', help='모든 후보에 같은 향후 기간을 사용하세요.'), 'risk_penalty': st.column_config.NumberColumn('위험 차감치', min_value=0.0, max_value=2.0, step=0.01, format='%.3f', help='예상 수익률에 충분히 반영되지 않은 추가 위험의 보수적 차감값.'), 'hurdle_rate': st.column_config.NumberColumn('최소 요구수익률 비율', min_value=-1.0, max_value=5.0, step=0.01, format='%.3f', help='관심종목 required_return이 있으면 초기값으로 사용합니다. 직접 검토 후 저장하세요.'), 'capacity_headroom_krw': st.column_config.NumberColumn('처리 용량 추가 허용 여력 (원화)', min_value=0.0, step=10000.0, format='%.0f', help='추가 가능한 금액의 현재 검토값. 현금은 비교 시 처리 용량 제한을 적용하지 않습니다.'), 'reviewed': st.column_config.CheckboxColumn('검토됨', help='예상 수익률 / 위험 차감치 / 최소 요구수익률 / 출처를 직접 확인했을 때만 체크'), 'review_due_date': st.column_config.DateColumn('검토 기한', help='이 향후 투자 가정을 다시 검토할 날짜')}, key=_cp_editor_key)
        st.caption('수동 저장은 현재 화면에 보이는 편집기 값을 원장에 반영합니다. 보정 승인 직후에는 위 편집기 동기화 무결성 식별값이 갱신됐는지 먼저 확인하세요.')
        if st.button('자본 효율 투자 가정 저장', type='primary', key='save_capital_productivity_inputs'):
            _cp_saved = capital_productivity_save_rows(cp_edited)
            verified_save_feedback(_cp_saved, 'capital_productivity_inputs.csv', 'Capital Productivity Assumption을 저장했습니다.', rerun=True)
    cp_inputs = normalize_capital_productivity_inputs(load_csv('capital_productivity_inputs.csv'))
    cp_universe = capital_productivity_universe(portfolio, watchlist, cp_inputs, total_assets)
    if not cp_universe.empty:
        cp1, cp2, cp3 = st.columns(3)
        _ready_count = int(cp_universe['input_status'].fillna('').astype(str).str.upper().eq('READY').sum())
        cp1.metric('투자 가정 준비 완료', _locale.code(_ready_count))
        cp2.metric('기준 가정 검토', _locale.code(int(len(cp_universe) - _ready_count)))
        cp3.metric('합계 후보', _locale.code(len(cp_universe)))
        cp_diag_cols = ['name', 'ticker', 'kind', 'current_value_krw', 'portfolio_weight', 'forward_er', 'risk_penalty', 'risk_adjusted_er', 'hurdle_rate', 'hurdle_spread', 'capacity_headroom_krw', 'review_clock', 'input_status', 'issues']
        _locale.dataframe(st, cp_universe[[c for c in cp_diag_cols if c in cp_universe.columns]], width='stretch', hide_index=True)
    st.subheader('1C. 투자 가정 작동 상태 / 기준 자료 변경 점검')
    st.caption('검토됨 투자 가정이 아직 유효한지 확인합니다. 보정-근거를 갖춘 투자 가정은 승인됨 초안 무결성 해시 / 현재 출처·기업 기초·시나리오 참조 / 실제 등록부 값이 모두 일치해야 정상입니다. 참조가 바뀌면 저장값을 자동 수정하지 않고 비교 점검만 검토로 낮춥니다.')
    cp_assumption_health = build_assumption_health(cp_universe, cp_forward_risk, load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'))
    cp_health_summary = assumption_health_summary(cp_assumption_health)
    ah1, ah2, ah3, ah4, ah5, ah6 = st.columns(6)
    ah1.metric('작동 상태 정상', _locale.code(cp_health_summary['pass']))
    ah2.metric('작동 상태 검토', _locale.code(cp_health_summary['review']))
    ah3.metric('기준 자료 변경', _locale.code(cp_health_summary['reference_drift']))
    ah4.metric('만료됨', _locale.code(cp_health_summary['expired']))
    ah5.metric('입력 불일치', _locale.code(cp_health_summary['input_mismatch']))
    ah6.metric('무결성 해시 불일치', _locale.code(cp_health_summary['hash_mismatch']))
    al1, al2, al3, al4 = st.columns(4)
    al1.metric('재검증 일치', _locale.code(cp_health_summary['revalidation_match']))
    al2.metric('사후-갱신 불일치', _locale.code(cp_health_summary['post_revalidation_mismatch']))
    al3.metric('재검증 기록 누락', _locale.code(cp_health_summary['revalidation_record_missing']))
    al4.metric('재검증 무결성 해시 불일치', _locale.code(cp_health_summary['revalidation_hash_mismatch']))
    if not cp_assumption_health.empty:
        health_cols = ['name', 'kind', 'provenance_type', 'input_status_before_health', 'review_due_date', 'review_due_gate', 'approved_calibration_id', 'calibration_hash_status', 'reference_status', 'input_match_status', 'health_status', 'health_issues', 'next_action']
        _locale.dataframe(st, cp_assumption_health[[c for c in health_cols if c in cp_assumption_health.columns]], width='stretch', hide_index=True)
        _health_attention = cp_assumption_health.loc[~cp_assumption_health['health_status'].fillna('').astype(str).str.upper().eq('PASS')].copy()
        if _health_attention.empty:
            st.success('현재 검토됨 자본 효율 투자 가정의 작동 상태 점검이 모두 정상입니다.')
        else:
            st.warning(f'투자 가정 작동 상태 재검토 대상 {_health_attention.shape[0]}건이 있습니다. 기준 자료 변경 / 만료 / 승인됨 입력 불일치를 해소하기 전에는 해당 투자 가정을 다음 투자금 경쟁 비교에서 준비 완료로 사용하지 않습니다.')
            _recal_names = _health_attention['name'].fillna('').astype(str).tolist()
            if _recal_names:
                _health_target = st.selectbox('재검증 대상', _recal_names, key='capital_productivity_health_target')
                _health_hit = _health_attention.loc[_health_attention['name'].fillna('').astype(str).eq(_health_target)]
                if not _health_hit.empty:
                    st.caption('다음 검토 행동 · ' + str(_health_hit.iloc[0].get('next_action', '') or ''))
                st.button('선택 종목을 보정 검토 대상으로 지정', on_click=lambda: st.session_state.update({'capital_productivity_calibration_target': _health_target, 'capital_productivity_forward_risk_target': _health_target}), key='capital_productivity_health_to_review')
    st.subheader('1D. 투자 가정 재검증 / 갱신 관리 기준')
    st.caption('기존 예상 수익률 / 위험 차감치 / 최소 요구수익률 값을 바꾸지 않고 검토 기한만 갱신하는 절차입니다. 참조 · 기준 이탈 / 입력 · 불일치 / 무결성 해시 · 불일치 / 미검토 상태는 단순 연장할 수 없습니다.')
    _reval_names = cp_assumption_health['name'].fillna('').astype(str).tolist() if not cp_assumption_health.empty else []
    if not _reval_names:
        st.info('재검증 대상 투자 가정이 없습니다.')
    else:
        _handoff_reval = str(st.session_state.get('capital_productivity_revalidation_target', st.session_state.get('capital_productivity_health_target', '')) or '')
        if _handoff_reval in _reval_names:
            st.session_state['capital_productivity_revalidation_target'] = _handoff_reval
        cp_reval_name = st.selectbox('재검증 대상', _reval_names, key='capital_productivity_revalidation_target')
        cp_reval_context = build_revalidation_context(cp_universe, cp_assumption_health, load_csv('capital_productivity_calibration_drafts.csv'), cp_reval_name)
        rv1, rv2, rv3, rv4, rv5 = st.columns(5)
        rv1.metric('적격성', _locale.code(cp_reval_context['eligibility_status']))
        rv2.metric('작동 상태', _locale.code(cp_reval_context['health_status']))
        rv3.metric('출처 이력', _locale.code(cp_reval_context['provenance_type']))
        rv4.metric('현재 검토 기한', _locale.code(cp_reval_context['current_review_due_date'] or '-'))
        rv5.metric('투자 실행 권한', '없음')
        ra1, ra2, ra3, ra4 = st.columns(4)
        ra1.metric('예상 수익률', _locale.code('-' if cp_reval_context['forward_er'] is None else pct(cp_reval_context['forward_er'])))
        ra2.metric('위험 차감치', _locale.code('-' if cp_reval_context['risk_penalty'] is None else pct(cp_reval_context['risk_penalty'])))
        ra3.metric('최소 요구수익률', _locale.code('-' if cp_reval_context['hurdle_rate'] is None else pct(cp_reval_context['hurdle_rate'])))
        ra4.metric('최소 요구수익률 매수·매도 호가 차이', _locale.code('-' if cp_reval_context['hurdle_spread'] is None else pct(cp_reval_context['hurdle_spread'])))
        _reval_health_hit = cp_assumption_health.loc[cp_assumption_health['name'].fillna('').astype(str).eq(cp_reval_name)]
        if not _reval_health_hit.empty:
            _rh = _reval_health_hit.iloc[0].to_dict()
            _lineage_status = str(_rh.get('revalidation_lineage_status', '') or 'N/A')
            _latest_reval_id = str(_rh.get('latest_revalidation_id', '') or '')
            if _lineage_status != 'N/A':
                st.caption(f'재검증 연결 이력 · {_lineage_status}' + (f' · 최신 {_latest_reval_id}' if _latest_reval_id else ''))
        if cp_reval_context['provenance_type'] == 'APPROVED_CALIBRATION':
            st.caption(f"승인됨 보정 · {cp_reval_context['approved_calibration_id'] or '-'} · 무결성 해시 {_locale.code(cp_reval_context['calibration_hash_status'])} · 참조 {_locale.code(cp_reval_context['reference_status'])} · 입력 {_locale.code(cp_reval_context['input_match_status'])}")
        if cp_reval_context['eligibility_status'] != 'PASS':
            st.warning(_locale.message('단순 재검증 차단 · ' + cp_reval_context['eligibility_reason']))
            st.caption('기준 자료 변경은 새 보정, 입력 불일치는 대조, 무결성 해시 불일치는 무결성 검토, UNREVIEWED는 최초 기준 가정 검토가 필요합니다.')
        else:
            st.success('현재 투자 가정 값과 참조가 재검증 가능한 상태입니다. 아래 사용자 검토를 완료해도 예상 수익률 / 위험 차감치 / 최소 요구수익률 값은 변경되지 않습니다.')
        _current_due = pd.to_datetime(cp_reval_context['current_review_due_date'], errors='coerce')
        _reval_default_days = int(settings.get('capital_productivity_revalidation_days', 30))
        _reval_max_days = int(settings.get('capital_productivity_revalidation_max_days', 90))
        if not pd.isna(_current_due):
            _candidate_due = _current_due.date() + timedelta(days=_reval_default_days)
        else:
            _candidate_due = date.today() + timedelta(days=_reval_default_days)
        _max_due = date.today() + timedelta(days=_reval_max_days)
        _default_reval_due = min(max(_candidate_due, date.today() + timedelta(days=1)), _max_due)
        cp_reval_due = st.date_input('신규 검토 기한', value=_default_reval_due, key='capital_productivity_revalidation_due', help=f'기존 가정의 값은 그대로 두고 검토 기한만 갱신합니다. 정책 최대 {_reval_max_days}일.')
        cp_reval_basis = st.text_area('재검증 검토 근거', value='', key='capital_productivity_revalidation_basis', height=100, placeholder='예: 기존 향후 투자 기간과 가정값을 유지. 최신 출처/투자 근거/기업 기초/시나리오를 재확인했고 가정을 다시 보정할 정도의 중요 변경이 없음을 검토.')
        rc1, rc2 = st.columns(2)
        cp_reval_horizon = rc1.checkbox('기존 향후 투자 기간과 정의를 그대로 유지합니다.', key='capital_productivity_revalidation_horizon')
        cp_reval_reference = rc2.checkbox('현재 출처 / 투자 근거 / 기업 기초 / 시나리오 참조를 다시 확인했습니다.', key='capital_productivity_revalidation_reference')
        rc3, rc4 = st.columns(2)
        cp_reval_no_change = rc3.checkbox('새로운 중요 변경이 없어 재보정 대신 검토 기한 갱신이 적절함을 확인했습니다.', key='capital_productivity_revalidation_no_change')
        cp_reval_values = rc4.checkbox('예상 수익률 / 위험 차감치 / 최소 요구수익률 값을 변경하지 않음을 확인했습니다.', key='capital_productivity_revalidation_values')
        cp_reval_human = st.checkbox('투자 가정 재검증을 최종 사용자 검토했습니다.', key='capital_productivity_revalidation_human')
        cp_reval_note = st.text_input('재검증 메모', value='', key='capital_productivity_revalidation_note', placeholder='예: 중요한 변경 없음 / 다음 검토 기한 갱신됨')
        cp_reval_gate = validate_revalidation(cp_reval_context, new_review_due_date=cp_reval_due, review_basis=cp_reval_basis, same_horizon_confirmed=cp_reval_horizon, current_reference_confirmed=cp_reval_reference, no_material_change_confirmed=cp_reval_no_change, assumption_values_unchanged_confirmed=cp_reval_values, human_confirmed=cp_reval_human, max_extension_days=_reval_max_days)
        rg1, rg2, rg3 = st.columns(3)
        rg1.metric('재검증 점검', _locale.code(cp_reval_gate['governance_gate']))
        rg2.metric('최종 판단', _locale.code(cp_reval_gate['final_decision']))
        rg3.metric('신규 검토 기한', _locale.code(cp_reval_gate['new_review_due_date'] or '-'))
        if cp_reval_gate['governance_gate'] != 'PASS':
            st.warning(_locale.message('재검증 미완료 · ' + ' | '.join(cp_reval_gate['issues'])))
        else:
            st.success('재검증 관리 기준 정상. 저장 시 검토 기한과 감사기록만 갱신하며 예상 수익률 / 위험 차감치 / 최소 요구수익률은 그대로 유지됩니다.')
        if st.button('투자 가정 재검증 저장', disabled=cp_reval_gate['governance_gate'] != 'PASS', key='capital_productivity_revalidation_save'):
            _existing_reval_hist = normalize_revalidations(load_csv('capital_productivity_revalidations.csv'))
            _reval_record = build_revalidation_record(cp_reval_context, cp_reval_gate, review_basis=cp_reval_basis, same_horizon_confirmed=cp_reval_horizon, current_reference_confirmed=cp_reval_reference, no_material_change_confirmed=cp_reval_no_change, assumption_values_unchanged_confirmed=cp_reval_values, human_confirmed=cp_reval_human, note=cp_reval_note, revalidation_history=_existing_reval_hist)
            _updated_cp_inputs, _reval_apply = apply_revalidation(cp_inputs, cp_reval_context, _reval_record)
            if _reval_apply['status'] != 'PASS':
                st.error(_locale.message('재검증 반영 실패 · ' + ' | '.join(_reval_apply['issues'])))
            else:
                _reval_hist = _existing_reval_hist.copy()
                _reval_hist = pd.concat([_reval_hist[REVALIDATION_COLS], pd.DataFrame([_reval_record])], ignore_index=True)
                try:
                    save_csv(_updated_cp_inputs, 'capital_productivity_inputs.csv')
                    save_csv(_reval_hist, 'capital_productivity_revalidations.csv')
                    st.session_state['_save_flash'] = ('success', f'{cp_reval_name} Assumption Revalidation 저장 완료 · 경제 가정값 변경 없음 · Execution Authorization = NONE')
                    st.rerun()
                except Exception as e:
                    st.error(f'재검증 저장 실패: {e}')
        _reval_history = normalize_revalidations(load_csv('capital_productivity_revalidations.csv'))
        if not _reval_history.empty:
            with st.expander('투자 가정 재검증 최근 기록', expanded=False):
                _locale.dataframe(st, _reval_history.tail(20), width='stretch', hide_index=True)
    st.subheader('1E. 재검증 연결 이력 / 사후-갱신 무결성')
    st.caption('재검증 이후 예상 수익률 / 위험 차감치 / 최소 요구수익률 / 처리 용량 또는 검토 기한이 바뀌었는지, 재검증 감사기록과 실전 등록부가 계속 연결되는지 확인합니다.')
    _lineage_rows = cp_assumption_health.loc[cp_assumption_health['revalidation_lineage_status'].fillna('').astype(str).ne('N/A')].copy() if not cp_assumption_health.empty and 'revalidation_lineage_status' in cp_assumption_health.columns else pd.DataFrame()
    if _lineage_rows.empty:
        st.info('아직 투자 가정 재검증 연결 이력 기록이 없습니다.')
    else:
        li1, li2, li3, li4 = st.columns(4)
        _ls = _lineage_rows['revalidation_lineage_status'].fillna('').astype(str).str.upper()
        li1.metric('재검증 · 일치', _locale.code(int(_ls.eq('REVALIDATION_MATCH').sum())))
        li2.metric('사후 · 재검증 · 입력 · 불일치', _locale.code(int(_ls.eq('POST_REVALIDATION_INPUT_MISMATCH').sum())))
        li3.metric('재검증 · 기록 · 누락', _locale.code(int(_ls.eq('REVALIDATION_RECORD_MISSING').sum())))
        li4.metric('재검증 · 무결성 해시 · 불일치', _locale.code(int(_ls.eq('REVALIDATION_HASH_MISMATCH').sum())))
        _lineage_cols = ['name', 'kind', 'provenance_type', 'latest_revalidation_id', 'revalidation_hash_status', 'revalidation_lineage_status', 'revalidation_lineage_issues', 'review_due_date', 'health_status', 'next_action']
        _locale.dataframe(st, _lineage_rows[[c for c in _lineage_cols if c in _lineage_rows.columns]], width='stretch', hide_index=True)
        if _ls.eq('REVALIDATION_MATCH').all():
            st.success('현재 저장된 재검증 연결 이력과 실전 투자 가정이 모두 일치합니다.')
        else:
            st.warning('사후-갱신 무결성 재검토 대상이 있습니다. 해당 투자 가정은 작동 상태 점검에서 입력 · 불일치 또는 HASH_MISMATCH로 내려가며 다음 투자금에서 준비 완료로 사용하지 않습니다.')
    st.subheader('1F. 학습 결과 반영 → 투자 가정 재검증 초안 연결')
    st.caption('승인됨 · 대상 · 재검증 학습 결과 반영을 현재 자본 효율 투자 가정과 대조해 원본 검토 화면으로 넘길 초안을 만듭니다. 증가/DECREASE는 기존 1D 기한 갱신으로 값을 바꾸지 않고 반드시 보정 검토로 라우팅합니다.')
    _lf_bridge_feedback = load_csv('learning_feedback_proposals.csv')
    _lf_bridge_drafts = load_csv('learning_feedback_revalidation_drafts.csv')
    if _lf_bridge_feedback.empty:
        st.info('학습 결과 반영 제안이 없습니다. 투자 판단 기록 → 학습 결과 반영에서 학습 연결 완료 근거를 먼저 APPROVED_FOR_REVALIDATION으로 검토하세요.')
    else:
        for _col in ['feedback_id', 'company', 'feedback_target', 'change_direction', 'proposal_status', 'record_hash']:
            if _col not in _lf_bridge_feedback.columns:
                _lf_bridge_feedback[_col] = ''
        _lf_cp_feedback = _lf_bridge_feedback.loc[_lf_bridge_feedback['proposal_status'].fillna('').astype(str).str.upper().eq('APPROVED_FOR_REVALIDATION') & _lf_bridge_feedback['feedback_target'].fillna('').astype(str).str.upper().isin(['FORWARD_ER', 'RISK_PENALTY', 'HURDLE'])].copy()
        if _lf_cp_feedback.empty:
            st.info('자본 효율 투자 가정으로 연결할 승인됨 학습 결과 반영이 없습니다.')
        else:
            _lf_feedback_indices = list(_lf_cp_feedback.index[::-1])

            def _lf_feedback_label(_idx):
                _r = _lf_cp_feedback.loc[_idx]
                return f"{_r.get('feedback_id', '')} | {_r.get('company', '')} | {_r.get('feedback_target', '')} {_r.get('change_direction', '')} | Δ {_r.get('proposed_delta', '')}"
            _lf_handoff_feedback_id = str(st.session_state.get('learning_feedback_bridge_feedback_id', '') or '')
            _lf_default_pos = 0
            if _lf_handoff_feedback_id:
                for _pos, _idx in enumerate(_lf_feedback_indices):
                    if str(_lf_cp_feedback.loc[_idx].get('feedback_id', '') or '') == _lf_handoff_feedback_id:
                        _lf_default_pos = _pos
                        break
            _lf_feedback_idx = st.selectbox('연결할 승인됨 학습 결과 반영', options=_lf_feedback_indices, index=_lf_default_pos, format_func=_lf_feedback_label, key='learning_feedback_revalidation_feedback_index')
            _lf_feedback_row = _lf_cp_feedback.loc[_lf_feedback_idx].to_dict()
            _lf_bridge_context = build_feedback_revalidation_context(_lf_feedback_row, cp_inputs, cp_assumption_health)
            lb1, lb2, lb3, lb4, lb5 = st.columns(5)
            lb1.metric('개선 제안 무결성', _locale.code(_lf_bridge_context['feedback_integrity_status']))
            lb2.metric('연결 맥락', _locale.code(_lf_bridge_context['context_gate']))
            lb3.metric('대상', _locale.code(_lf_bridge_context['feedback_target']))
            lb4.metric('연결 이동 경로', _locale.code(_lf_bridge_context['bridge_route']))
            lb5.metric('투자 실행 권한', '없음')
            _lf_values = pd.DataFrame([{'Assumption': 'Forward ER', 'Current': _lf_bridge_context['current_forward_er'], 'Proposed Draft': _lf_bridge_context['proposed_forward_er']}, {'Assumption': 'Risk Penalty', 'Current': _lf_bridge_context['current_risk_penalty'], 'Proposed Draft': _lf_bridge_context['proposed_risk_penalty']}, {'Assumption': 'Hurdle', 'Current': _lf_bridge_context['current_hurdle_rate'], 'Proposed Draft': _lf_bridge_context['proposed_hurdle_rate']}])
            for _c in ['Current', 'Proposed Draft']:
                _lf_values[_c] = pd.to_numeric(_lf_values[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            _locale.dataframe(st, _lf_values, width='stretch', hide_index=True)
            st.caption(f"출처 다음 점검 · {_lf_bridge_context['source_next_gate'] or '-'} · 실제 연결 이동 경로 · {_lf_bridge_context['bridge_route']} · 작동 상태 {_lf_bridge_context['assumption_health_status'] or '-'} · 출처 이력 {_lf_bridge_context['assumption_provenance_type'] or '-'}")
            if _lf_bridge_context['bridge_route'] == 'CAPITAL_PRODUCTIVITY_CALIBRATION':
                st.warning('값 변경 제안입니다. 기존 1D 투자 가정 재검증은 검토 기한만 연장하므로 이 초안을 직접 적용할 수 없습니다. 새 보정 범위 + 참조 사용자 검토가 필요합니다.')
            else:
                st.info('값 변경 없는 검토 · 전용 제안입니다. 1D 투자 가정 재검증에서 중요 변경 없음과 현재 참조를 다시 검토할 수 있습니다.')
            if _lf_bridge_context['issues']:
                st.warning(_locale.message('연결 맥락 사유 · ' + ' | '.join(_lf_bridge_context['issues'])))
            lbc1, lbc2 = st.columns(2)
            _lf_current_confirm = lbc1.checkbox('현재 예상 수익률 / 위험 차감치 / 최소 요구수익률 값을 직접 대조했습니다.', value=False, key='learning_feedback_bridge_current_confirm')
            _lf_route_confirm = lbc2.checkbox('값 변경 제안은 보정, 값 유지 검토는 재검증으로 라우팅됨을 확인했습니다.', value=False, key='learning_feedback_bridge_route_confirm')
            lbc3, lbc4 = st.columns(2)
            _lf_proposal_confirm = lbc3.checkbox('표시된 제안된 초안은 자동 적용값이 아니라 원본 사용자 검토용 제안임을 확인했습니다.', value=False, key='learning_feedback_bridge_proposal_confirm')
            _lf_no_exec_confirm = lbc4.checkbox('이 연결 초안은 투자 실행 권한을 생성하지 않음을 확인했습니다.', value=False, key='learning_feedback_bridge_no_exec_confirm')
            _lf_human_confirm = st.checkbox('학습 결과 반영 → 투자 가정 재검증 초안을 최종 사용자 검토했습니다.', value=False, key='learning_feedback_bridge_human_confirm')
            _lf_bridge_note = st.text_input('재검증 초안 메모', value='', key='learning_feedback_bridge_note', placeholder='예: 학습 결과 반영 인계 전용 / 출처 검토 필요 / 금지 자동-적용')
            _lf_bridge_review = validate_feedback_revalidation_draft(_lf_bridge_context, current_values_confirmed=_lf_current_confirm, route_confirmed=_lf_route_confirm, proposal_only_confirmed=_lf_proposal_confirm, no_execution_authorization_confirmed=_lf_no_exec_confirm, human_review_confirmed=_lf_human_confirm)
            lbg1, lbg2, lbg3 = st.columns(3)
            lbg1.metric('연결 점검', _locale.code(_lf_bridge_review['bridge_gate']))
            lbg2.metric('초안 상태', _locale.code(_lf_bridge_review['draft_status']))
            lbg3.metric('투자 실행 권한', '없음')
            if _lf_bridge_review['issues']:
                st.warning(_locale.message('초안 저장 전 확인 · ' + ' | '.join(_lf_bridge_review['issues'])))
            else:
                st.success('연결 점검 정상 · 원본 투자 가정은 아직 변경되지 않았습니다. 초안 저장 후 반드시 원본 보정/재검증 화면에서 다시 사용자 검토하세요.')
            if st.button('학습 결과 반영 → 재검증 초안 저장', disabled=_lf_bridge_review['bridge_gate'] != 'PASS', key='learning_feedback_revalidation_draft_save'):
                _lf_draft_row = build_feedback_revalidation_draft_record(_lf_bridge_context, _lf_bridge_review, current_values_confirmed=_lf_current_confirm, route_confirmed=_lf_route_confirm, proposal_only_confirmed=_lf_proposal_confirm, no_execution_authorization_confirmed=_lf_no_exec_confirm, human_review_confirmed=_lf_human_confirm, note=_lf_bridge_note)
                _lf_draft_hist = load_csv('learning_feedback_revalidation_drafts.csv')
                for _col in LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS:
                    if _col not in _lf_draft_hist.columns:
                        _lf_draft_hist[_col] = ''
                _lf_draft_hist = pd.concat([_lf_draft_hist[LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS], pd.DataFrame([_lf_draft_row])], ignore_index=True)
                verified_save_feedback(_lf_draft_hist, 'learning_feedback_revalidation_drafts.csv', f"Learning Feedback Revalidation Draft 저장 · {_lf_draft_row['draft_status']} · Route {_lf_draft_row['bridge_route']} · Execution Authorization = NONE.", rerun=False)
            _lf_existing_drafts = load_csv('learning_feedback_revalidation_drafts.csv')
            if not _lf_existing_drafts.empty and 'feedback_id' in _lf_existing_drafts.columns:
                _lf_feedback_id = str(_lf_bridge_context.get('feedback_id', '') or '')
                _lf_saved_hit = _lf_existing_drafts.loc[_lf_existing_drafts['feedback_id'].fillna('').astype(str).str.strip().eq(_lf_feedback_id)].copy()
                if not _lf_saved_hit.empty:
                    _lf_saved_hit['_sort'] = pd.to_datetime(_lf_saved_hit['created_at'], errors='coerce', utc=True)
                    _lf_saved_hit = _lf_saved_hit.sort_values('_sort', ascending=False, na_position='last')
                    _lf_latest_draft = _lf_saved_hit.iloc[0].drop(labels=['_sort'], errors='ignore').to_dict()
                    _lf_latest_integrity = feedback_revalidation_draft_integrity(_lf_latest_draft)
                    st.caption(f"최신 초안 · {_lf_latest_draft.get('bridge_id', '')} · 무결성 {_locale.code(_lf_latest_integrity['status'])} · 상태 {_locale.code(_lf_latest_draft.get('draft_status', ''))}")
                    if _lf_latest_integrity['status'] == 'OK' and str(_lf_latest_draft.get('draft_status', '') or '').upper() == 'READY_FOR_SOURCE_REVIEW':
                        if str(_lf_latest_draft.get('bridge_route', '') or '') == 'CAPITAL_PRODUCTIVITY_CALIBRATION':
                            st.button('보정 검토 대상으로 지정', type='primary', on_click=lambda: st.session_state.update({'capital_productivity_calibration_target': _lf_bridge_context['company'], 'capital_productivity_forward_risk_target': _lf_bridge_context['company']}), key='learning_feedback_bridge_to_calibration')
                        else:
                            st.button('투자 가정 재검증 대상으로 지정', type='primary', on_click=lambda: st.session_state.update({'capital_productivity_revalidation_target': _lf_bridge_context['company']}), key='learning_feedback_bridge_to_revalidation')
            if not _lf_bridge_drafts.empty:
                with st.expander('학습 결과 반영 재검증 초안 최근 기록', expanded=False):
                    _locale.dataframe(st, _lf_bridge_drafts.tail(20), width='stretch', hide_index=True)
    st.subheader('1G. 출처 검토 완료 / 개선 제안 종결 / 변경 연결 이력')
    st.caption('준비 완료 · 대상 · 출처 · 검토 초안 이후 실제 보정/재검증 결과가 생겼는지 확인하고, 제안과 실제 출처-검토됨 결과의 차이를 기록해 학습 결과 반영을 닫거나 추가 투자 근거 대기로 남깁니다. 제안과 다른 결론도 정상적인 사용자 검토 결과일 수 있으며 자동 재적용하지 않습니다.')
    _lfc_drafts = load_csv('learning_feedback_revalidation_drafts.csv')
    _lfc_feedback = load_csv('learning_feedback_proposals.csv')
    _lfc_closures = load_csv('learning_feedback_change_lineage.csv')
    if _lfc_drafts.empty:
        st.info('출처 검토 종결 대상 초안이 없습니다. 1F에서 준비 완료 · 대상 · 출처 · 검토 초안을 먼저 생성하세요.')
    else:
        for _col in LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS:
            if _col not in _lfc_drafts.columns:
                _lfc_drafts[_col] = ''
        _lfc_ready = _lfc_drafts.loc[_lfc_drafts['draft_status'].fillna('').astype(str).str.upper().eq('READY_FOR_SOURCE_REVIEW')].copy()
        if _lfc_ready.empty:
            st.info('준비 완료 · 대상 · 출처 · 검토 초안이 없습니다.')
        else:
            _lfc_indices = list(_lfc_ready.index[::-1])

            def _lfc_label(_idx):
                _r = _lfc_ready.loc[_idx]
                return f"{_r.get('bridge_id', '')} | {_r.get('company', '')} | {_r.get('feedback_target', '')} {_r.get('change_direction', '')} | {_r.get('bridge_route', '')}"
            _lfc_handoff_bridge_id = str(st.session_state.get('learning_feedback_change_bridge_id', '') or '')
            _lfc_default = 0
            if _lfc_handoff_bridge_id:
                for _pos, _idx in enumerate(_lfc_indices):
                    if str(_lfc_ready.loc[_idx].get('bridge_id', '') or '') == _lfc_handoff_bridge_id:
                        _lfc_default = _pos
                        break
            _lfc_idx = st.selectbox('종결 검토할 준비 완료 · 대상 · 출처 · 검토 초안', options=_lfc_indices, index=_lfc_default, format_func=_lfc_label, key='learning_feedback_change_draft_index')
            _lfc_draft = _lfc_ready.loc[_lfc_idx].to_dict()
            _lfc_feedback_id = str(_lfc_draft.get('feedback_id', '') or '')
            _lfc_feedback_row = {}
            if not _lfc_feedback.empty and 'feedback_id' in _lfc_feedback.columns:
                _lfc_fhit = _lfc_feedback.loc[_lfc_feedback['feedback_id'].fillna('').astype(str).str.strip().eq(_lfc_feedback_id)]
                if not _lfc_fhit.empty:
                    _lfc_feedback_row = _lfc_fhit.iloc[-1].to_dict()
            _lfc_context = build_feedback_change_context(_lfc_draft, _lfc_feedback_row, cp_inputs, load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'))
            lc1, lc2, lc3, lc4, lc5 = st.columns(5)
            lc1.metric('출처 검토', _locale.code(_lfc_context['closure_readiness']))
            lc2.metric('출처 유형', _locale.code(_lfc_context['source_review_type'] or '-'))
            lc3.metric('출처 무결성', _locale.code(_lfc_context['source_review_integrity_status']))
            lc4.metric('제안 결과', _locale.code(_lfc_context['proposal_outcome']))
            lc5.metric('투자 실행 권한', '없음')
            _lfc_values = pd.DataFrame([{'Value': 'Baseline before Proposal', 'Rate': _lfc_context['baseline_value']}, {'Value': 'Proposed Draft', 'Rate': _lfc_context['proposed_value']}, {'Value': 'Source-reviewed Result', 'Rate': _lfc_context['source_review_value']}, {'Value': 'Live Assumption Register', 'Rate': _lfc_context['live_register_value']}])
            _lfc_values['Rate'] = pd.to_numeric(_lfc_values['Rate'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            _locale.dataframe(st, _lfc_values, width='stretch', hide_index=True)
            st.caption(f"출처 검토 식별번호 · {_lfc_context['source_review_id'] or '-'} · 기록 시각 {_lfc_context['source_review_timestamp'] or '-'} · 실전 등록부 일치 {_locale.code(_lfc_context['live_register_match_status'])}")
            if _lfc_context['closure_readiness'] == 'SOURCE_REVIEW_PENDING':
                st.info('아직 이 연결 초안 이후의 승인됨 보정 / 정상 재검증 기록을 찾지 못했습니다. 원본 출처 검토가 끝나기 전에는 개선 제안을 닫지 않습니다.')
            elif _lfc_context['source_review_gate'] == 'PASS':
                st.success('출처 검토 완료 정상 · 제안과 실제 결과가 같든 다르든 출처-검토됨 결과를 기준으로 종결 여부를 사용자 검토할 수 있습니다.')
            else:
                st.warning(_locale.message('출처 검토 완료 재검토 · ' + ' | '.join(_lfc_context['issues'])))
            _lfc_latest = latest_feedback_closure_record(_lfc_closures, _lfc_feedback_id)
            if _lfc_latest:
                _lfc_latest_integrity = feedback_change_lineage_integrity(_lfc_latest)
                st.caption(f"최신 종결 · {_lfc_latest.get('change_lineage_id', '')} · 상태 {_locale.code(_lfc_latest.get('closure_status', ''))} · 무결성 {_locale.code(_lfc_latest_integrity['status'])}")
            _lfc_action = st.selectbox('개선 제안 종결 행동', FEEDBACK_CLOSURE_ACTIONS, index=0, key='learning_feedback_closure_action')
            lcc1, lcc2 = st.columns(2)
            _lfc_source_confirm = lcc1.checkbox('출처 검토 식별번호 / 기록 시각 / 무결성 해시와 실전 투자 가정 등록부 값을 직접 확인했습니다.', value=False, key='learning_feedback_closure_source_confirm')
            _lfc_outcome_confirm = lcc2.checkbox('기준 상태 / 제안된 / 실제 출처-검토됨 결과와 제안 결과를 직접 대조했습니다.', value=False, key='learning_feedback_closure_outcome_confirm')
            lcc3, lcc4 = st.columns(2)
            _lfc_no_carry = lcc3.checkbox('이 결과를 다음 투자 가정에 자동 다음 검토로 이월하지 않으며 새 투자 근거마다 다시 검토함을 확인했습니다.', value=False, key='learning_feedback_closure_no_carry')
            _lfc_no_exec = lcc4.checkbox('이 종결은 투자 실행 권한을 생성하지 않음을 확인했습니다.', value=False, key='learning_feedback_closure_no_exec')
            _lfc_human = st.checkbox('학습 결과 반영 출처 검토 완료 / 종결을 최종 사용자 검토했습니다.', value=False, key='learning_feedback_closure_human')
            _lfc_note = st.text_input('개선 제안 종결 메모', value='', key='learning_feedback_closure_note', placeholder='예: 출처 검토 결과 수락됨 / 근거 확인 후 제안 변경 / 금지 자동 다음 검토로 이월')
            _lfc_review = validate_feedback_closure(_lfc_context, closure_action=_lfc_action, source_review_result_confirmed=_lfc_source_confirm, proposal_outcome_confirmed=_lfc_outcome_confirm, no_auto_carry_forward_confirmed=_lfc_no_carry, no_execution_authorization_confirmed=_lfc_no_exec, human_review_confirmed=_lfc_human)
            lg1, lg2, lg3 = st.columns(3)
            lg1.metric('종결 점검', _locale.code(_lfc_review['closure_gate']))
            lg2.metric('종결 상태', _locale.code(_lfc_review['closure_status']))
            lg3.metric('투자 실행 권한', '없음')
            if _lfc_review['issues']:
                st.warning(_locale.message('종결 저장 전 확인 · ' + ' | '.join(_lfc_review['issues'])))
            if st.button('학습 결과 반영 변경 연결 이력 저장', disabled=_lfc_review['closure_gate'] != 'PASS', key='learning_feedback_change_lineage_save'):
                _lfc_row = build_feedback_change_lineage_record(_lfc_context, _lfc_review, source_review_result_confirmed=_lfc_source_confirm, proposal_outcome_confirmed=_lfc_outcome_confirm, no_auto_carry_forward_confirmed=_lfc_no_carry, no_execution_authorization_confirmed=_lfc_no_exec, human_review_confirmed=_lfc_human, note=_lfc_note)
                _lfc_hist = load_csv('learning_feedback_change_lineage.csv')
                for _col in LEARNING_FEEDBACK_CHANGE_LINEAGE_COLS:
                    if _col not in _lfc_hist.columns:
                        _lfc_hist[_col] = ''
                _lfc_hist = pd.concat([_lfc_hist[LEARNING_FEEDBACK_CHANGE_LINEAGE_COLS], pd.DataFrame([_lfc_row])], ignore_index=True)
                verified_save_feedback(_lfc_hist, 'learning_feedback_change_lineage.csv', f"Learning Feedback Change Lineage 저장 · {_lfc_row['closure_status']} · Outcome {_lfc_row['proposal_outcome']} · Execution Authorization = NONE.", rerun=False)
            if not _lfc_closures.empty:
                with st.expander('학습 결과 반영 변경 연결 이력 최근 기록', expanded=False):
                    _locale.dataframe(st, _lfc_closures.tail(20), width='stretch', hide_index=True)
    cp_universe_for_competition = apply_assumption_health_gate(cp_universe, cp_assumption_health)
    st.subheader('2. 다음 투자금 경쟁 비교')
    st.caption('비용 차감 후 교체 효과 = 자금 수령 자산 위험 조정 기대수익률 − 자금 제공 자산 위험 조정 기대수익률 − 세금 − 매매. 적격은 현재 입력 점검이 통과했다는 뜻이며 자동 매수/매도 결론이 아닙니다.')
    if cp_universe.empty:
        st.info('투자 가정 등록부를 먼저 준비하세요.')
    else:
        donor_options = cp_universe['name'].fillna('').astype(str).tolist()
        cp_donor = st.selectbox('자금 제공 자산', donor_options, key='capital_productivity_donor')
        cpa, cpb, cpc, cpd = st.columns(4)
        cp_amount = cpa.number_input('비교 결과 금액 (원화)', min_value=0.0, value=100000.0, step=10000.0, key='capital_productivity_amount', help='실제 주문금액이 아니라 동일한 다음 자본 단위를 비교하는 금액입니다.')
        cp_tax = cpb.number_input('세금 비용 비율', min_value=0.0, max_value=1.0, value=0.0, step=0.001, format='%.3f', key='capital_productivity_tax')
        cp_trading = cpc.number_input('매매 비용 비율', min_value=0.0, max_value=1.0, value=0.002, step=0.001, format='%.3f', key='capital_productivity_trading')
        cp_min_gap = cpd.number_input('최소 교체 차이', min_value=-1.0, max_value=2.0, value=float(settings.get('capital_productivity_min_switching_gap', 0.02)), step=0.01, format='%.3f', key='capital_productivity_min_gap')
        cp_comp = capital_competition_table(cp_universe_for_competition, cp_donor, cp_amount, tax_cost_rate=cp_tax, trading_cost_rate=cp_trading, minimum_switching_gap=cp_min_gap)
        cp_summary = capital_competition_summary(cp_universe_for_competition, cp_comp)
        cpr1, cpr2, cpr3, cpr4 = st.columns(4)
        cpr1.metric('준비 완료 입력값', f"{cp_summary['ready_inputs']}/{cp_summary['total_inputs']}")
        cpr2.metric('적격 자금 수령 자산', _locale.code(cp_summary['qualified_recipients']))
        cpr3.metric('검토 자금 수령 자산', _locale.code(cp_summary['review_recipients']))
        cpr4.metric('차단됨 자금 수령 자산', _locale.code(cp_summary['blocked_recipients']))
        if cp_comp.empty:
            st.info('자금 제공 자산과 비교할 자금 수령 자산이 없습니다.')
        else:
            cp_show = cp_comp.copy()
            for _c in ['donor_risk_adjusted_er', 'recipient_forward_er', 'recipient_risk_penalty', 'recipient_risk_adjusted_er', 'recipient_hurdle_rate', 'recipient_hurdle_spread', 'tax_cost_rate', 'trading_cost_rate', 'net_switching_gap']:
                cp_show[_c] = pd.to_numeric(cp_show[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
            cp_show['comparison_amount_krw'] = pd.to_numeric(cp_show['comparison_amount_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            cp_show['recipient_capacity_headroom_krw'] = pd.to_numeric(cp_show['recipient_capacity_headroom_krw'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
            _locale.dataframe(st, cp_show, width='stretch', hide_index=True)
            qualified = cp_comp.loc[cp_comp['comparison_status'].fillna('').astype(str).str.upper().eq('QUALIFIED')].copy()
            if qualified.empty:
                st.warning('현재 입력 기준 모형-적격 자금 수령 자산이 없습니다. 향후 가정을 억지로 바꾸지 말고, 새 자본의 이동을 보류하는 상태를 관리 기준으로 기록할 수 있습니다.')
                st.subheader('3. 금지 적격 자금 수령 자산 / 자본 유지 관리 기준')
                st.caption("이 섹션은 '아무 것도 하지 않기'를 자동 권고하지 않습니다. 현재 적격 자금 수령 자산이 0인 상태에서 새 자본의 재배분을 보류하고 언제/무엇을 다시 확인할지 기록합니다. 기존 자금 제공 자산의 비중 축소/종료/위험 보완 의무는 취소하지 않습니다.")
                _cp_donor_ref_hit = cp_forward_risk.loc[cp_forward_risk['name'].fillna('').astype(str).eq(cp_donor)] if not cp_forward_risk.empty else pd.DataFrame()
                _cp_donor_ref = _cp_donor_ref_hit.iloc[0].to_dict() if not _cp_donor_ref_hit.empty else {}
                _cp_donor_lifecycle = str(_cp_donor_ref.get('lifecycle', '') or '').upper()
                _cp_donor_add_freeze = str(_cp_donor_ref.get('add_freeze', '') or '').upper()
                cp_hold_context = capital_hold_context(cp_universe_for_competition, cp_comp, cp_donor, cp_amount, donor_lifecycle=_cp_donor_lifecycle, donor_add_freeze=_cp_donor_add_freeze)
                hg1, hg2, hg3, hg4, hg5 = st.columns(5)
                hg1.metric('유지 적격성', _locale.code(cp_hold_context['hold_eligibility']))
                hg2.metric('유지 상태', _locale.code(cp_hold_context['hold_state']))
                hg3.metric('진행 중 자금 수령 자산 검토 항목', _locale.code(cp_hold_context['review_recipients']))
                hg4.metric('기존 자금 제공 자산 행동', _locale.code(cp_hold_context['existing_donor_action']))
                hg5.metric('투자 실행 권한', '없음')
                if cp_hold_context['existing_donor_action'] != 'NONE':
                    st.warning(f"자금 제공 자산 {cp_donor}의 기존 상태는 **{cp_hold_context['existing_donor_action']}** 입니다. 자본 유지는 새 자본 재배분을 보류하는 기록일 뿐, 기존 비중 축소/종료/추가 투자 보류/위험 보완 판단을 취소하지 않습니다.")
                ch1, ch2, ch3 = st.columns(3)
                ch1.metric('적격', _locale.code(cp_hold_context['qualified_recipients']))
                ch2.metric('검토', _locale.code(cp_hold_context['review_recipients']))
                ch3.metric('차단됨', _locale.code(cp_hold_context['blocked_recipients']))
                _earliest_hold_due = pd.to_datetime(cp_hold_context.get('earliest_assumption_review_due', ''), errors='coerce')
                _default_hold_due = _earliest_hold_due.date() if not pd.isna(_earliest_hold_due) and _earliest_hold_due.date() > date.today() else date.today() + timedelta(days=int(settings.get('capital_hold_default_review_days', 14)))
                if cp_hold_context['earliest_assumption_review_due']:
                    st.caption('가장 이른 준비 완료 기준 가정 검토 기한 · ' + cp_hold_context['earliest_assumption_review_due'] + ' · 유지 검토는 이 날짜보다 늦게 잡지 않는 것이 원칙입니다.')
                cp_hold_reason = st.text_area('자본 유지 사유', value='', key='capital_hold_reason', height=90, placeholder='예: 적격 자금 수령 자산 0. NICE는 비용 차감 후 교체 효과가 양수지만 최소 요구수익률 매수·매도 호가 차이가 음수이고, 나머지 후보는 기준 가정 검토 상태라 새 자본 재배분을 보류함.')
                cp_hold_next_evidence = st.text_area('다음 해제 조건 / 필요한 투자 근거', value='', key='capital_hold_next_evidence', height=90, placeholder='예: NICE 차환 근거 보강, 다음 시나리오/기업 기초 업데이트, 검토 후보의 예상 수익률/위험 차감치 투자 가정 완료 후 재비교.')
                hc1, hc2 = st.columns(2)
                cp_hold_assumption_confirm = hc1.checkbox('적격을 만들기 위해 예상 수익률 / 위험 차감치 / 최소 요구수익률 가정을 억지로 변경하지 않았습니다.', key='capital_hold_assumption_discipline')
                cp_hold_open_reviews_confirm = hc2.checkbox('현재 검토 자금 수령 자산이 남아 있으며, 이들은 기각이 아니라 추가 투자 가정/투자 근거 검토 대상임을 확인했습니다.', key='capital_hold_open_reviews_confirm', disabled=cp_hold_context['review_recipients'] <= 0, value=cp_hold_context['review_recipients'] <= 0)
                hc3, hc4 = st.columns(2)
                cp_hold_existing_action_confirm = hc3.checkbox('자본 유지가 자금 제공 자산의 기존 비중 축소 / 종료 / 추가 투자 보류 / 위험 보완 상태를 취소하지 않음을 확인했습니다.', key='capital_hold_existing_action_confirm', disabled=cp_hold_context['existing_donor_action'] == 'NONE', value=cp_hold_context['existing_donor_action'] == 'NONE')
                cp_hold_human_confirm = hc4.checkbox('현재 새 자본의 재배분을 보류하고 다음 검토까지 재평가하기로 직접 검토했습니다.', key='capital_hold_human_confirm')
                cp_hold_due = st.date_input('자본 유지 다음 검토 날짜', value=_default_hold_due, key='capital_hold_review_due', help='준비 완료 투자 가정의 가장 이른 검토 기한보다 늦으면 관리 기준 정상이 되지 않습니다.')
                cp_hold_note = st.text_input('자본 유지 메모', value='', key='capital_hold_note', placeholder='예: 금지 적격 자금 수령 자산 / 검토 진행 중')
                cp_hold_governance = capital_hold_governance_gate(cp_hold_context, hold_reason=cp_hold_reason, next_evidence_needed=cp_hold_next_evidence, hold_review_due_date=cp_hold_due, assumption_discipline_confirmed=cp_hold_assumption_confirm, open_reviews_confirmed=cp_hold_open_reviews_confirm, existing_action_confirmed=cp_hold_existing_action_confirm, human_confirmed=cp_hold_human_confirm)
                cg1, cg2, cg3 = st.columns(3)
                cg1.metric('유지 관리 기준 점검', _locale.code(cp_hold_governance['governance_gate']))
                cg2.metric('최종 판단', _locale.code(cp_hold_governance['final_decision']))
                cg3.metric('검토 기한 점검', _locale.code(cp_hold_governance['review_due_gate']))
                if cp_hold_governance['governance_gate'] == 'PASS':
                    st.success('자본 유지 관리 기준 검토가 완료되었습니다. 이는 새 자본의 이동을 승인하는 것이 아니라 다음 검토까지 재배분을 보류하는 기록이며 투자 실행 권한은 없음입니다.')
                else:
                    st.warning(_locale.message('자본 유지 관리 기준 미완료 · ' + ' | '.join(cp_hold_governance['issues'])))
                if st.button('자본 유지 관리 기준 검토 기록 저장', disabled=cp_hold_governance['governance_gate'] != 'PASS', key='save_capital_hold_governance'):
                    _hold_row = capital_hold_review_row(cp_hold_context, cp_hold_governance, hold_reason=cp_hold_reason, next_evidence_needed=cp_hold_next_evidence, assumption_discipline_confirmed=cp_hold_assumption_confirm, open_reviews_confirmed=cp_hold_open_reviews_confirm, existing_action_confirmed=cp_hold_existing_action_confirm, human_confirmed=cp_hold_human_confirm, note=cp_hold_note)
                    _hold_hist = load_csv('capital_hold_reviews.csv')
                    for _col in CAPITAL_HOLD_REVIEW_COLS:
                        if _col not in _hold_hist.columns:
                            _hold_hist[_col] = ''
                    _hold_hist = pd.concat([_hold_hist[CAPITAL_HOLD_REVIEW_COLS], pd.DataFrame([_hold_row])], ignore_index=True)
                    verified_save_feedback(_hold_hist, 'capital_hold_reviews.csv', 'Capital Hold Governance 검토 기록을 저장했습니다. Execution Authorization = NONE.', rerun=False)
                _hold_history = load_csv('capital_hold_reviews.csv')
                if not _hold_history.empty:
                    with st.expander('자본 유지 관리 기준 최근 기록', expanded=False):
                        _locale.dataframe(st, _hold_history.tail(20), width='stretch', hide_index=True)
            else:
                st.success('현재 입력 점검을 통과한 비교대상이 있습니다. 실제 자본이동은 자본 이동에서 투자 단계 / 포트폴리오 적합성 / 실행 점검을 다시 확인하세요.')
                handoff_recipient = st.selectbox('자본 이동에서 다시 검토할 자금 수령 자산', qualified['recipient'].fillna('').astype(str).tolist(), key='capital_productivity_handoff_recipient')
                st.button('선택 비교를 자본 이동으로 이어서 검토', on_click=_navigate, args=('Capital Migration', {'migration_donor': cp_donor, 'migration_recipient': handoff_recipient, 'migration_amount_krw': float(cp_amount), 'migration_handoff_source': 'Capital Productivity', 'migration_handoff_donor_original': cp_donor, 'migration_handoff_amount_original': float(cp_amount), 'migration_handoff_created_at': datetime.now().isoformat()}), key='capital_productivity_to_migration')
    st.caption('자본 효율은 입력가정의 비교도구입니다. 양호한 점수가 자동 투자결론을 의미하지 않으며, 적격 자금 수령 자산이 없으면 현금 유지도 유효한 상태입니다.')
