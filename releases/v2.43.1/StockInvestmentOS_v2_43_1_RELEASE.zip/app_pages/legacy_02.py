from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('운영 제어 종합 관리')
    st.caption('많은 메뉴를 돌지 않고 오늘 무엇을 먼저 확인할지 압축합니다. 기술/데이터 무결성 → 기한/검토 → 의사결정 상태 순으로 정리합니다.')
    st.info('이 화면의 준비 완료/정상은 투자 승인이나 매수/매도 신호가 아닙니다. 운영 우선순위와 안전한 다음 원본 화면만 안내합니다. 투자 실행 권한 = 없음.')
    _ct_save_health = verify_user_data_health()
    _ct_csv_fail = int(_ct_save_health['status'].fillna('').astype(str).str.upper().eq('FAIL').sum()) if not _ct_save_health.empty else 0
    _ct_integration, _ct_integration_summary = build_global_integration_audit(watchlist, portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _ct_reconciliation = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _ct_data_quality = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    _ct_dq_summary = audit_summary(_ct_data_quality)
    _ct_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    _ct_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    _ct_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    _ct_thesis = build_thesis_monitor(watchlist, _ct_states, _ct_plans, _ct_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=date.today())
    _ct_master_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=_ct_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=_ct_kpis, state_df=_ct_states, thesis_monitor=_ct_thesis, audit_df=_ct_data_quality, reconciliation=_ct_reconciliation, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=date.today())
    _ct_queue_summary = review_queue_summary(_ct_master_queue)
    _ct_review_compression = compress_review_queue(_ct_master_queue)
    _ct_session_worklist = build_session_worklist(_ct_review_compression, max_groups=5)
    _ct_learning = build_learning_cycle_release_gate(load_csv('decision_learning_lineage.csv'), load_csv('learning_feedback_proposals.csv'), load_csv('learning_feedback_revalidation_drafts.csv'), load_csv('learning_feedback_change_lineage.csv'), load_csv('capital_productivity_inputs.csv'), load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'), today=date.today())
    _ct_forecast = build_forecast_calibration_release_gate(load_csv('forecast_change_registry.csv'), load_csv('forecast_change_implementation_events.csv'), load_csv('forecast_change_effect_reviews.csv'), load_csv('decision_learning_lineage.csv'), today=date.today())
    _ct_recovery = build_recovery_integration_context(project_root=Path.cwd(), latest_backup=latest_user_backup(), save_health=_ct_save_health, save_events=get_save_events(50), recovery_point_locks=load_csv('recovery_point_locks.csv'), runbook_locks=load_csv('disaster_recovery_runbook_locks.csv'), now=datetime.now().astimezone(), keep_latest=3)
    _ct_schema_context = build_schema_governance_context(data_dir=ROOT / 'data', baselines=load_csv('schema_baseline_locks.csv'), contracts=load_csv('schema_contract_locks.csv'), proposals=load_csv('schema_migration_proposals.csv'), proofs=load_csv('schema_migration_proof_reviews.csv'), approvals=load_csv('schema_refresh_approvals.csv'))
    _ct_schema_release = build_schema_governance_release_gate(_ct_schema_context)
    _ct_tower = build_operations_control_tower(reconciliation_status=_ct_reconciliation['status'], integration_status=_ct_integration_summary['status'], csv_fail_count=_ct_csv_fail, data_quality_blocked=_ct_dq_summary['blocked'], data_quality_review=_ct_dq_summary['review'], review_overdue=_ct_queue_summary['overdue'], review_attention_now=_ct_queue_summary['attention_now'], learning_release_gate=_ct_learning['release_gate'], forecast_release_gate=_ct_forecast['release_gate'], recovery_release_gate=_ct_recovery['recovery_release']['release_gate'], recovery_integration_status=_ct_recovery['recovery_integration_status'], schema_release_gate=_ct_schema_release['release_gate'], schema_contract_drift_status=_ct_schema_release['contract_drift_status'], watchlist_count=len(watchlist))
    ct1, ct2, ct3, ct4, ct5 = st.columns(5)
    ct1.metric('운영 상태', _locale.code(_ct_tower['system_state']))
    ct2.metric('차단 사유', _locale.code(_ct_tower['blocking_count']))
    ct3.metric('검토', _locale.code(_ct_tower['review_count']))
    ct4.metric('상위 우선순위', _locale.code(_ct_tower['top_priority'] or '-'))
    ct5.metric('투자 실행 권한', '없음')
    if _ct_tower['system_state'] == 'BLOCKED':
        st.error(f"운영 차단됨 · 먼저 {_ct_tower['top_domain']}에서 {_ct_tower['top_issue']}를 확인하세요.")
    elif _ct_tower['system_state'] == 'REVIEW':
        st.warning(f"운영 검토 · 첫 확인은 {_ct_tower['top_domain']} · {_ct_tower['top_issue']}입니다.")
    else:
        st.success('운영 준비 완료 · 현재 기술/데이터 차단과 즉시 검토 항목이 없습니다.')
    st.subheader('1. 오늘의 우선순위 압축')
    _ct_top = top_actions(_ct_tower, limit=5)
    _locale.dataframe(st, _ct_top, width='stretch', hide_index=True)
    if not _ct_top.empty:
        _ct_route_options = list(_ct_top.index)

        def _ct_route_label(_idx):
            _r = _ct_top.loc[_idx]
            return f"[{_r.get('priority', '')}] {_r.get('domain', '')} · {_r.get('issue', '')}"
        _ct_route_idx = st.selectbox('원본 화면으로 이동할 항목', options=_ct_route_options, format_func=_ct_route_label, key='operations_control_tower_route')
        _ct_selected = _ct_top.loc[_ct_route_idx].to_dict()
        _ct_go_to = str(_ct_selected.get('go_to', '') or '')
        if _ct_go_to:
            st.button(f'{_ct_go_to}로 이동', type='primary', on_click=_navigate, args=(_ct_go_to,), key='operations_control_tower_go_to')
    st.subheader('1A. 검토 대기 목록 행동 그룹')
    cta1, cta2, cta3, cta4 = st.columns(4)
    cta1.metric('원본 검토 항목', _locale.code(_ct_review_compression['raw_items']))
    cta2.metric('행동 그룹', _locale.code(_ct_review_compression['action_groups']))
    cta3.metric('확인 필요 그룹', _locale.code(_ct_review_compression['attention_groups']))
    cta4.metric('압축', _locale.code(f"{_ct_review_compression['compression_ratio']:.1f}x" if _ct_review_compression['action_groups'] > 0 else '-'))
    if _ct_session_worklist.empty:
        st.success('현재 작업 세션 작업 목록으로 압축할 검토 항목이 없습니다.')
    else:
        _locale.dataframe(st, _ct_session_worklist[['session_rank', 'priority', 'phase', 'category', 'item_count', 'subject_count', 'sample_subjects', 'sample_issues', 'go_to']], width='stretch', hide_index=True)
        st.caption('원본 항목 수가 많아도 같은 분류 / 이동 경로 / 상태의 반복 항목을 행동 그룹으로 묶습니다. 원본 개별 항목은 검토 대기 목록에서 그대로 확인할 수 있습니다.')
    _ct_core_gates = {'learning': _ct_learning['release_gate'], 'forecast': _ct_forecast['release_gate'], 'recovery': _ct_recovery['recovery_release']['release_gate'], 'recovery_audit': _ct_recovery['recovery_integration_status'], 'schema': _ct_schema_release['release_gate'], 'schema_drift': _ct_schema_release['contract_drift_status'], 'integration': _ct_integration_summary['status'], 'csv_fail': str(_ct_csv_fail)}
    _ct_session_history = load_csv('operations_sessions.csv')
    _ct_open_session = current_open_session(_ct_session_history)
    _ct_last_closed = latest_closed_session(_ct_session_history)
    st.subheader('1B. 일일 운영 작업 세션 / 인계 / 운영 종료')
    os1, os2, os3, os4 = st.columns(4)
    os1.metric('작업 세션', _locale.code('진행 중' if _ct_open_session else '금지 · 진행 중 · 작업 세션'))
    os2.metric('현재 상태', _locale.code(_ct_tower['system_state']))
    os3.metric('확인 필요 그룹', _locale.code(_ct_review_compression['attention_groups']))
    os4.metric('투자 실행 권한', '없음')
    if _ct_last_closed:
        _ct_last_integrity = operations_session_integrity(_ct_last_closed)
        st.caption(f"마지막 종료 · {_ct_last_closed.get('session_id', '')} · {_locale.code(_ct_last_closed.get('event_status', ''))} · 다음 검토로 이월 {_ct_last_closed.get('carry_forward_groups', 0)} 그룹 · 무결성 {_locale.code(_ct_last_integrity['status'])}")
    if not _ct_open_session:
        _ct_open_note = st.text_input('작업 세션 진행 중 메모', value='', key='operations_session_open_note', placeholder='예: 하루 시작 / 요약된 검토 대기 목록 불러옴')
        if st.button('일일 운영 작업 세션 시작', key='operations_session_open'):
            _ct_open_row = build_open_session_record(_ct_tower, _ct_review_compression, _ct_session_worklist, _ct_core_gates, note=_ct_open_note)
            _ct_session_hist = load_csv('operations_sessions.csv')
            for _col in OPERATIONS_SESSION_COLS:
                if _col not in _ct_session_hist.columns:
                    _ct_session_hist[_col] = ''
            _ct_session_hist = pd.concat([_ct_session_hist[OPERATIONS_SESSION_COLS], pd.DataFrame([_ct_open_row])], ignore_index=True)
            verified_save_feedback(_ct_session_hist, 'operations_sessions.csv', f"Daily Operations Session 시작 · {_ct_open_row['session_id']} · State {_ct_open_row['system_state']} · Execution Authorization = NONE.", rerun=False)
    else:
        _ct_open_integrity = operations_session_integrity(_ct_open_session)
        st.info(f"진행 중 작업 세션 · {_ct_open_session.get('session_id', '')} · 개설됨 {_ct_open_session.get('created_at', '')} · 무결성 {_locale.code(_ct_open_integrity['status'])}")
        _ct_close_evidence_readiness = build_flow_evidence_capture_readiness(load_csv('operations_flow_trend_snapshots.csv'), load_csv('operations_sessions.csv'))
        ecr1, ecr2, ecr3 = st.columns(3)
        ecr1.metric('처리 흐름 투자 근거 기록', _locale.code(_ct_close_evidence_readiness['capture_state']))
        ecr2.metric('내-작업 세션 추세', _locale.code(_ct_close_evidence_readiness['eligible_trend_snapshots']))
        ecr3.metric('투자 실행 권한', '없음')
        _ecr_state = _ct_close_evidence_readiness['capture_state']
        if _ecr_state == 'READY_FOR_EVIDENCE_CLOSE':
            st.success('현재 진행 중 작업 세션 기간 안에 유효한 처리 흐름 추세 상태 기록이 있습니다. 작업 세션을 종료하면 종료 이전 최신 상태 기록 1개가 투자 근거 연결 주소 후보가 됩니다.')
        elif _ecr_state == 'TREND_SNAPSHOT_REQUIRED_BEFORE_CLOSE':
            st.warning('현재 진행 중 작업 세션 안에 처리 흐름 추세 상태 기록이 없습니다. 작업 세션 종료 자체는 가능하지만 이번 작업 세션은 보정 투자 근거로 인정되지 않습니다. 실제 대기 목록 상태를 검토한 뒤 1G에서 추세 상태 기록을 저장하고 종료하는 순서를 권장합니다.')
        elif _ecr_state == 'OPEN_SESSION_INTEGRITY_REVIEW':
            st.error('현재 진행 중 작업 세션 무결성을 확인할 수 없어 처리 흐름 투자 근거 기록을 보류합니다.')
        oc1, oc2 = st.columns(2)
        _oc_tower = oc1.checkbox('현재 제어 종합 관리 상태와 핵심 점검 상태 기록을 직접 확인했습니다.', key='operations_close_tower_confirm')
        _oc_worklist = oc2.checkbox('이번 작업 세션 작업 목록을 검토했고 미해결 항목은 다음 검토로 이월됨을 확인했습니다.', key='operations_close_worklist_confirm')
        oc3, oc4 = st.columns(2)
        _oc_no_auto = oc3.checkbox('작업 세션 종료가 원본 검토 항목을 자동 완료/해결 처리하지 않음을 확인했습니다.', key='operations_close_no_auto_confirm')
        _oc_no_exec = oc4.checkbox('작업 세션 종료는 투자 실행 권한을 생성하지 않음을 확인했습니다.', key='operations_close_no_exec_confirm')
        _oc_human = st.checkbox('현재 일일 운영 작업 세션을 최종 사용자 검토했습니다.', key='operations_close_human_confirm')
        _oc_note = st.text_input('운영 종료 / 인계 메모', value='', key='operations_session_close_note', placeholder='예: 미해결 그룹 이월 / 금지 투자 실행 권한')
        _oc_validation = validate_close_session(_ct_open_session, _ct_tower, control_tower_review_confirmed=_oc_tower, worklist_review_confirmed=_oc_worklist, no_source_auto_resolution_confirmed=_oc_no_auto, no_execution_authorization_confirmed=_oc_no_exec, human_review_confirmed=_oc_human)
        ocg1, ocg2, ocg3 = st.columns(3)
        ocg1.metric('종료 점검', _locale.code(_oc_validation['close_gate']))
        ocg2.metric('종료 상태', _locale.code(_oc_validation['close_status']))
        ocg3.metric('투자 실행 권한', '없음')
        if _oc_validation['issues']:
            st.caption('작업 세션 종료 전 확인 · ' + ' | '.join(_oc_validation['issues']))
        if st.button('일일 운영 작업 세션 종료 / 인계 저장', disabled=_oc_validation['close_gate'] != 'PASS', key='operations_session_close'):
            _ct_close_row = build_close_session_record(_ct_open_session, _ct_tower, _ct_review_compression, _ct_session_worklist, _ct_core_gates, _oc_validation, control_tower_review_confirmed=_oc_tower, worklist_review_confirmed=_oc_worklist, no_source_auto_resolution_confirmed=_oc_no_auto, no_execution_authorization_confirmed=_oc_no_exec, human_review_confirmed=_oc_human, note=_oc_note)
            _ct_session_hist = load_csv('operations_sessions.csv')
            for _col in OPERATIONS_SESSION_COLS:
                if _col not in _ct_session_hist.columns:
                    _ct_session_hist[_col] = ''
            _ct_session_hist = pd.concat([_ct_session_hist[OPERATIONS_SESSION_COLS], pd.DataFrame([_ct_close_row])], ignore_index=True)
            verified_save_feedback(_ct_session_hist, 'operations_sessions.csv', f"Daily Operations Session Close · {_ct_close_row['event_status']} · Carry-forward {_ct_close_row['carry_forward_groups']} groups · Execution Authorization = NONE.", rerun=False)
    st.caption('작업 세션 진행 중/종료는 운영 스냅샷과 다음 검토로 이월을 기록할 뿐, 원본 검토를 자동 완료하거나 투자행동을 승인하지 않습니다.')
    _ct_carry_forward = build_carry_forward_aging(_ct_review_compression['groups'], load_csv('operations_sessions.csv'), today=date.today())
    _ct_capacity = build_review_capacity_plan(_ct_review_compression, _ct_carry_forward, session_capacity=5)
    _ct_carry_queue = build_carry_forward_queue(_ct_carry_forward, _ct_capacity)
    st.subheader('1C. 다음 검토로 이월 경과 기간 / 검토 처리 용량 / 운영 처리 기한')
    cf1, cf2, cf3, cf4, cf5 = st.columns(5)
    cf1.metric('처리 용량 상태', _locale.code(_ct_capacity['capacity_status']))
    cf2.metric('작업 세션 처리 용량', _locale.code(_ct_capacity['session_capacity']))
    cf3.metric('초과분 그룹', _locale.code(_ct_capacity['overflow_groups']))
    cf4.metric('경과 기간 / 오래됨', f"{_ct_carry_forward['aging_groups']} / {_ct_carry_forward['stale_groups']}")
    cf5.metric('투자 실행 권한', '없음')
    cfa1, cfa2, cfa3 = st.columns(3)
    cfa1.metric('처리 기한 상한 초과', _locale.code(_ct_carry_forward['sla_breaches']))
    cfa2.metric('가장 오래된 경과 기간', f"{_ct_carry_forward['oldest_age_days']}d")
    cfa3.metric('확인 필요 초과분', _locale.code(_ct_capacity['attention_overflow']))
    if _ct_carry_forward['sla_breaches'] > 0:
        st.warning('운영 처리 기한 검토 · 같은 행동 그룹이 여러 작업 세션에 걸쳐 미해결로 남아 있습니다. 가격 변동보다 원본 검토 사유와 투자 근거/무결성을 먼저 확인하세요.')
    elif _ct_capacity['attention_overflow'] > 0:
        st.info('확인 필요 그룹이 작업 세션 처리 용량 5개를 초과합니다. 상위 작업 목록을 먼저 검토하고 나머지는 자동 완료 없이 다음 검토로 이월합니다.')
    else:
        st.success('현재 다음 검토로 이월 경과 기간 / 검토 처리 용량이 설정 범위 안에 있습니다.')
    with st.expander('다음 검토로 이월 경과 기간 상세', expanded=False):
        _ct_cf_table = _ct_carry_forward['table']
        if _ct_cf_table.empty:
            st.info('현재 행동 그룹이 없습니다.')
        else:
            _locale.dataframe(st, _ct_cf_table, width='stretch', hide_index=True)
    _ct_cf_note = st.text_input('다음 검토로 이월 상태 기록 메모', value='', key='operations_carry_forward_snapshot_note', placeholder='예: 주간 처리 용량 검토 / 금지 자동 해결')
    if st.button('운영 다음 검토로 이월 상태 기록 저장', key='operations_carry_forward_snapshot_save'):
        _ct_cf_row = build_carry_forward_snapshot(_ct_carry_forward, _ct_capacity, note=_ct_cf_note)
        _ct_cf_hist = load_csv('operations_carry_forward_snapshots.csv')
        for _col in CARRY_FORWARD_SNAPSHOT_COLS:
            if _col not in _ct_cf_hist.columns:
                _ct_cf_hist[_col] = ''
        _ct_cf_hist = pd.concat([_ct_cf_hist[CARRY_FORWARD_SNAPSHOT_COLS], pd.DataFrame([_ct_cf_row])], ignore_index=True)
        verified_save_feedback(_ct_cf_hist, 'operations_carry_forward_snapshots.csv', f"Operations Carry-forward Snapshot 저장 · Aging {_ct_cf_row['aging_groups']} · SLA Breach {_ct_cf_row['sla_breaches']} · Execution Authorization = NONE.", rerun=False)
    st.caption('운영 처리 기한은 내부 운영 우선순위 기준입니다. 매수/매도 신호나 투자 승인 기준이 아니며, 행동 그룹을 자동 완료하지 않습니다.')
    _ct_recurrence = build_recurrence_diagnostics(_ct_carry_forward['table'])
    _ct_rebalance = build_capacity_rebalance_plan(_ct_recurrence, session_capacity=5)
    _ct_recurrence_queue = build_recurrence_queue(_ct_recurrence, _ct_rebalance)
    st.subheader('1D. 다음 검토로 이월 근본 원인 / 반복 / 처리 용량 재조정')
    rr1, rr2, rr3, rr4, rr5 = st.columns(5)
    rr1.metric('반복 그룹', _locale.code(_ct_recurrence['recurring_groups']))
    rr2.metric('지속적 / 반복적', f"{_ct_recurrence['persistent_groups']} / {_ct_recurrence['chronic_groups']}")
    rr3.metric('처리 기한 상한 초과 그룹', _locale.code(_ct_recurrence['sla_breach_groups']))
    rr4.metric('선택됨 / 보류됨', f"{_ct_rebalance['selected_groups']} / {_ct_rebalance['deferred_groups']}")
    rr5.metric('투자 실행 권한', '없음')
    if _ct_recurrence['top_root_cause']:
        st.caption(f"상위 근본 원인 · {_ct_recurrence['top_root_cause']} · 작업 세션 처리 용량 {_ct_rebalance['session_capacity']}")
    with st.expander('근본 원인 요약', expanded=False):
        _rr_summary = _ct_recurrence['root_cause_summary']
        if _rr_summary.empty:
            st.info('현재 근본 원인 요약이 없습니다.')
        else:
            _locale.dataframe(st, _rr_summary, width='stretch', hide_index=True)
    st.markdown('**이번 작업 세션 처리 용량 재조정됨 작업 목록**')
    _rr_worklist = _ct_rebalance['worklist']
    if _rr_worklist.empty:
        st.success('현재 재조정됨 작업 목록이 없습니다.')
    else:
        _locale.dataframe(st, _rr_worklist, width='stretch', hide_index=True)
    _rr_note = st.text_input('반복 / 처리 용량 상태 기록 메모', value='', key='operations_recurrence_snapshot_note', placeholder='예: 반복 검토됨 / 처리 용량 5 / 금지 자동 해결')
    if st.button('운영 반복 상태 기록 저장', key='operations_recurrence_snapshot_save'):
        _rr_row = build_recurrence_snapshot(_ct_recurrence, _ct_rebalance, note=_rr_note)
        _rr_hist = load_csv('operations_recurrence_snapshots.csv')
        for _col in RECURRENCE_SNAPSHOT_COLS:
            if _col not in _rr_hist.columns:
                _rr_hist[_col] = ''
        _rr_hist = pd.concat([_rr_hist[RECURRENCE_SNAPSHOT_COLS], pd.DataFrame([_rr_row])], ignore_index=True)
        verified_save_feedback(_rr_hist, 'operations_recurrence_snapshots.csv', f"Operations Recurrence Snapshot 저장 · Persistent {_rr_row['persistent_groups']} · Chronic {_rr_row['chronic_groups']} · Execution Authorization = NONE.", rerun=False)
    st.caption('처리 용량 재조정은 이번 작업 세션에 먼저 볼 그룹의 순서만 조정합니다. 원본 검토를 삭제·완료하거나 투자행동을 승인하지 않습니다.')
    _ct_overrides = load_csv('operations_capacity_overrides.csv')
    _ct_active_override = latest_active_override(_ct_overrides, today=date.today())
    _ct_effective_capacity = effective_capacity(5, _ct_active_override)
    _ct_sla_gate = build_sla_release_gate(_ct_recurrence, _ct_rebalance, _ct_active_override, _ct_effective_capacity)
    _ct_sla_queue = build_sla_queue(_ct_sla_gate, _ct_active_override)
    st.subheader('1E. 운영 처리 기한 종결 / 처리 용량 예외 승인 관리 기준')
    sg1, sg2, sg3, sg4, sg5 = st.columns(5)
    sg1.metric('처리 기한 기술 점검', _locale.code(_ct_sla_gate['release_gate']))
    sg2.metric('처리 기한 상태', _locale.code(_ct_sla_gate['sla_state']))
    sg3.metric('기준 / 유효 처리 용량', f"5 / {_ct_effective_capacity['effective_capacity']}")
    sg4.metric('활성 예외 승인', _locale.code(_ct_active_override.get('override_id', 'NONE') if _ct_active_override else '없음'))
    sg5.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _ct_sla_gate['checks'], width='stretch', hide_index=True)
    if _ct_sla_gate['release_gate'] == 'PASS':
        st.success('운영 처리 기한 기술 점검 정상 · 반복 / 비중 재조정 / 예외 승인 기술 무결성이 정상입니다.')
    else:
        st.error('운영 처리 기한 기술 점검 차단됨 · 진단 / 예외 승인 무결성을 먼저 확인하세요.')
    if _ct_sla_gate['operating_status'] == 'REVIEW':
        st.warning('운영 검토는 정상적인 미해결 운영 상태입니다. 처리 용량 예외 승인은 예외적 운영 도구이며 자동 적용되지 않습니다.')
    with st.expander('처리 용량 예외 승인 제안', expanded=False):
        _ov_base = 5
        _ov_requested = st.number_input('요청됨 작업 세션 처리 용량', min_value=6, max_value=10, value=6, step=1, key='operations_capacity_override_requested')
        _ov_days = st.number_input('예외 승인 기간 (일수)', min_value=1, max_value=14, value=3, step=1, key='operations_capacity_override_days')
        _ov_reason = st.text_area('예외 승인 사유', key='operations_capacity_override_reason', placeholder='예: 반복된 처리 기한 상한 초과 / 예외적인 투자 근거 미처리 작업')
        _ov_evidence = st.text_area('예외 승인 투자 근거', key='operations_capacity_override_evidence', placeholder='예: 처리 기한 상한 초과 그룹, 반복, 인력 배치/처리 용량 투자 근거')
        ov1, ov2 = st.columns(2)
        _ov_human = ov1.checkbox('처리 용량 예외 승인의 사유·기간·상한을 직접 사용자 검토했습니다.', key='operations_capacity_override_human')
        _ov_no_auto = ov2.checkbox('예외 승인 저장은 작업 세션 처리 용량을 자동 적용하지 않음을 확인했습니다.', key='operations_capacity_override_no_auto')
        _ov_no_exec = st.checkbox('처리 용량 예외 승인은 투자 실행 권한을 생성하지 않음을 확인했습니다.', key='operations_capacity_override_no_exec')
        _ov_note = st.text_input('처리 용량 예외 승인 메모', key='operations_capacity_override_note')
        _ov_validation = validate_capacity_override(_ct_recurrence, _ct_rebalance, base_capacity=_ov_base, requested_capacity=_ov_requested, reason=_ov_reason, evidence=_ov_evidence, duration_days=_ov_days, human_review_confirmed=_ov_human, no_auto_apply_confirmed=_ov_no_auto, no_execution_authorization_confirmed=_ov_no_exec)
        ovg1, ovg2, ovg3 = st.columns(3)
        ovg1.metric('예외 승인 점검', _locale.code(_ov_validation['override_gate']))
        ovg2.metric('예외 승인 상태', _locale.code(_ov_validation['override_status']))
        ovg3.metric('투자 실행 권한', '없음')
        if st.button('처리 용량 예외 승인 관리 기준 기록 저장', disabled=_ov_validation['override_gate'] != 'PASS', key='operations_capacity_override_save'):
            _ov_row = build_capacity_override_record(_ct_recurrence, _ct_rebalance, _ov_validation, reason=_ov_reason, evidence=_ov_evidence, human_review_confirmed=_ov_human, no_auto_apply_confirmed=_ov_no_auto, no_execution_authorization_confirmed=_ov_no_exec, note=_ov_note)
            _ov_hist = load_csv('operations_capacity_overrides.csv')
            for _col in CAPACITY_OVERRIDE_COLS:
                if _col not in _ov_hist.columns:
                    _ov_hist[_col] = ''
            _ov_hist = pd.concat([_ov_hist[CAPACITY_OVERRIDE_COLS], pd.DataFrame([_ov_row])], ignore_index=True)
            verified_save_feedback(_ov_hist, 'operations_capacity_overrides.csv', f"Capacity Override Governance 저장 · {_ov_row['override_status']} · {_ov_row['base_capacity']}→{_ov_row['requested_capacity']} · Execution Authorization = NONE.", rerun=False)
    _sla_note = st.text_input('운영 처리 기한 종결 상태 기록 메모', key='operations_sla_closure_note', placeholder='예: 처리 기한 검토됨 / 금지 자동 해결')
    if st.button('운영 처리 기한 종결 상태 기록 저장', key='operations_sla_closure_snapshot_save'):
        _sla_row = build_sla_closure_snapshot(_ct_recurrence, _ct_rebalance, _ct_sla_gate, _ct_active_override, _ct_effective_capacity, base_capacity=5, note=_sla_note)
        _sla_hist = load_csv('operations_sla_closure_snapshots.csv')
        for _col in SLA_CLOSURE_SNAPSHOT_COLS:
            if _col not in _sla_hist.columns:
                _sla_hist[_col] = ''
        _sla_hist = pd.concat([_sla_hist[SLA_CLOSURE_SNAPSHOT_COLS], pd.DataFrame([_sla_row])], ignore_index=True)
        verified_save_feedback(_sla_hist, 'operations_sla_closure_snapshots.csv', f"Operating SLA Closure Snapshot 저장 · {_sla_row['sla_state']} · Technical {_sla_row['technical_gate']} · Execution Authorization = NONE.", rerun=False)
    st.caption('처리 용량 예외 승인은 일시적 운영 검토 기록이며 자동 처리 용량 변경, 원본 검토 완료, 투자 실행을 하지 않습니다.')
    _ct_flow_history = load_csv('operations_flow_snapshots.csv')
    _ct_previous_flow = latest_flow_snapshot(_ct_flow_history)
    _ct_flow = build_flow_diagnostics(_ct_recurrence['table'], _ct_previous_flow, capacity=5)
    _ct_flow_queue = build_flow_queue(_ct_flow)
    st.subheader('1F. 검토 처리 흐름 / 대기 작업 처리-하락 / 대기 목록 처리량')
    fl1, fl2, fl3, fl4, fl5 = st.columns(5)
    fl1.metric('대기 작업 감소', _locale.code(_ct_flow['burn_down_status']))
    fl2.metric('현재 / 확인 필요', f"{_ct_flow['current_group_count']} / {_ct_flow['current_attention_count']}")
    fl3.metric('신규 / 저장 / 종료', f"{_ct_flow['new_groups']} / {_ct_flow['persisting_groups']} / {_ct_flow['exited_groups']}")
    fl4.metric('처리 용량 부담', f"{_ct_flow['capacity_pressure']:.2f}x")
    fl5.metric('투자 실행 권한', '없음')
    fld1, fld2, fld3 = st.columns(3)
    fld1.metric('미처리 작업 Δ', _locale.code(_ct_flow['backlog_delta']))
    fld2.metric('확인 필요 Δ', _locale.code(_ct_flow['attention_delta']))
    fld3.metric('대기 목록 종료 비율', f"{_ct_flow['queue_exit_rate']:.1%}")
    if _ct_flow['burn_down_status'] == 'FIRST_SNAPSHOT':
        st.info('첫 검토 처리 흐름 상태 기록 전 상태입니다. 현재 대기 목록을 기준 상태로 저장하면 다음부터 신규/저장/종료를 비교합니다.')
    elif _ct_flow['burn_down_status'] == 'IMPROVING':
        st.success('대기 작업 처리-하락 개선 중 · 대기 목록 종료가 신규 유입보다 많고 전체 그룹 수가 감소했습니다.')
    elif _ct_flow['burn_down_status'] == 'GROWING':
        st.warning('미처리 작업 증가 중 · 신규 유입이 대기 목록 종료보다 많습니다. 근본 원인과 RQ0/RQ1 유입을 먼저 확인하세요.')
    elif _ct_flow['burn_down_status'] == 'STALLED':
        st.warning('미처리 작업 정체 · 대기 목록 구성 변화가 없습니다. 반복 그룹의 원본 검토를 우선 확인하세요.')
    else:
        st.info('미처리 작업 혼합 · 신규/지속/종료가 함께 발생했습니다.')
    with st.expander('검토 처리 흐름 상세', expanded=False):
        _locale.dataframe(st, _ct_flow['details'], width='stretch', hide_index=True)
    _flow_note = st.text_input('검토 처리 흐름 상태 기록 메모', value='', key='operations_flow_snapshot_note', placeholder='예: 기준 상태 처리 흐름 상태 기록 / 금지 자동 해결')
    if st.button('운영 검토 처리 흐름 상태 기록 저장', key='operations_flow_snapshot_save'):
        _flow_row = build_flow_snapshot(_ct_flow, note=_flow_note)
        _flow_hist = load_csv('operations_flow_snapshots.csv')
        for _col in FLOW_SNAPSHOT_COLS:
            if _col not in _flow_hist.columns:
                _flow_hist[_col] = ''
        _flow_hist = pd.concat([_flow_hist[FLOW_SNAPSHOT_COLS], pd.DataFrame([_flow_row])], ignore_index=True)
        verified_save_feedback(_flow_hist, 'operations_flow_snapshots.csv', f"Operations Review Flow Snapshot 저장 · {_flow_row['burn_down_status']} · Groups {_flow_row['current_group_count']} · Attention {_flow_row['current_attention_count']} · Execution Authorization = NONE.", rerun=False)
    st.caption("대기 목록 종료는 '현재 대기 목록에서 사라짐'을 뜻하는 운영 추정치가며 실제 투자 가설 해결/증명을 자동 의미하지 않습니다. 원본 검토 완료 여부는 해당 원본 화면에서 별도로 확인해야 합니다.")
    _ct_flow_trend_history = load_csv('operations_flow_trend_snapshots.csv')
    _ct_flow_trend = build_flow_trend(_ct_recurrence['table'], _ct_flow_trend_history, capacity=5, forecast_min_snapshots=3, history_window=5)
    _ct_flow_trend_queue = build_flow_trend_queue(_ct_flow_trend)
    st.subheader('1G. 처리 흐름 추세 / 근본 원인 유입-종료 / 처리량 전망')
    ft1, ft2, ft3, ft4, ft5 = st.columns(5)
    ft1.metric('추세 상태', _locale.code(_ct_flow_trend['trend_state']))
    ft2.metric('이력 상태 기록', _locale.code(_ct_flow_trend['history_snapshots']))
    ft3.metric('유입 / 종료', f"{_ct_flow_trend['arrivals']} / {_ct_flow_trend['exits']}")
    ft4.metric('예측 상태', _locale.code(_ct_flow_trend['forecast_state']))
    ft5.metric('투자 실행 권한', '없음')
    ftt1, ftt2, ftt3 = st.columns(3)
    ftt1.metric('계속 남은 항목', _locale.code(_ct_flow_trend['persisting']))
    ftt2.metric('평균 유입 / 종료 단위당 구간', f"{_ct_flow_trend['avg_arrivals_per_interval']:.2f} / {_ct_flow_trend['avg_exits_per_interval']:.2f}")
    ftt3.metric('예상 처리 완료 구간', _locale.code('-' if _ct_flow_trend['estimated_clearance_intervals'] is None else f"{_ct_flow_trend['estimated_clearance_intervals']:.0f}"))
    if _ct_flow_trend['trend_state'] == 'BASELINE_REQUIRED':
        st.info('근본 원인 유입/종료 비교용 추세 기준 상태가 없습니다. 현재 그룹→근본 원인 대응 관계를 첫 추세 상태 기록으로 저장하면 다음부터 정확한 유입/종료 비교가 시작됩니다.')
    elif _ct_flow_trend['trend_state'] == 'IMPROVING':
        st.success('처리 흐름 추세 개선 중 · 종료가 유입보다 많고 그룹 미처리 작업이 감소했습니다.')
    elif _ct_flow_trend['trend_state'] == 'GROWING':
        st.warning('처리 흐름 추세 증가 중 · 유입이 종료보다 많습니다. 근본 원인별 신규 유입을 먼저 확인하세요.')
    elif _ct_flow_trend['trend_state'] == 'STALLED':
        st.warning('처리 흐름 추세 정체 · 그룹 구성 변화가 없습니다.')
    else:
        st.info('처리 흐름 추세 혼합 · 유입 / 종료 / 계속 남은 항목이 함께 발생했습니다.')
    if _ct_flow_trend['forecast_state'] == 'INSUFFICIENT_HISTORY':
        st.caption('처리량 전망은 저장된 추세 상태 기록이 3개 이상일 때만 계산합니다. 초기 구간에서는 숫자를 억지로 예측하지 않습니다.')
    elif _ct_flow_trend['forecast_state'] == 'PROJECTED_BURN_DOWN':
        st.caption('예상 처리 완료 구간은 최근 상태 기록 구간당 평균 종료-유입 속도를 단순 연장한 운영 전망입니다. 보장이나 투자 판단 기준이 아닙니다.')
    elif _ct_flow_trend['forecast_state'] == 'NO_CLEARING_TREND':
        st.caption('최근 관측에서 종료가 유입을 초과하지 않아 처리 완료 전망을 만들지 않습니다.')
    with st.expander('근본 원인 유입 / 종료 상세', expanded=False):
        _ft_root = _ct_flow_trend['root_cause_flow']
        if _ft_root.empty:
            st.info('비교 가능한 근본 원인 처리 흐름이 아직 없습니다.')
        else:
            _locale.dataframe(st, _ft_root, width='stretch', hide_index=True)
    with st.expander('처리량 이력 상세', expanded=False):
        _ft_history = _ct_flow_trend['history_table']
        if _ft_history.empty:
            st.info('저장된 추세 이력이 아직 없습니다.')
        else:
            _locale.dataframe(st, _ft_history, width='stretch', hide_index=True)
    _ft_note = st.text_input('처리 흐름 추세 상태 기록 메모', value='', key='operations_flow_trend_snapshot_note', placeholder='예: 근본 원인 추세 기준 상태 / 금지 자동 해결')
    if st.button('운영 처리 흐름 추세 상태 기록 저장', key='operations_flow_trend_snapshot_save'):
        _ft_row = build_flow_trend_snapshot(_ct_recurrence['table'], capacity=5, note=_ft_note)
        _ft_hist = load_csv('operations_flow_trend_snapshots.csv')
        for _col in FLOW_TREND_SNAPSHOT_COLS:
            if _col not in _ft_hist.columns:
                _ft_hist[_col] = ''
        _ft_hist = pd.concat([_ft_hist[FLOW_TREND_SNAPSHOT_COLS], pd.DataFrame([_ft_row])], ignore_index=True)
        verified_save_feedback(_ft_hist, 'operations_flow_trend_snapshots.csv', f"Operations Flow Trend Snapshot 저장 · Groups {_ft_row['current_group_count']} · Attention {_ft_row['attention_group_count']} · Execution Authorization = NONE.", rerun=False)
    st.caption('유입/종료는 동일 그룹 식별번호의 대기 목록 유입/이탈을 추적합니다. 종료는 원본 검토 해결을 자동 증명하지 않으며 원본 화면 확인이 필요합니다.')
    _ct_flow_calibration = build_flow_calibration(_ct_flow_trend, _ct_recurrence['table'], _ct_flow_trend_history, capacity=5, min_saved_snapshots=3)
    _ct_flow_evidence = build_flow_evidence_quality(_ct_flow_trend_history, load_csv('operations_sessions.csv'), min_qualified_endpoints=3)
    _ct_flow_qualified_trend = build_flow_trend(_ct_recurrence['table'], _ct_flow_evidence['qualified_trend_history'], capacity=5, forecast_min_snapshots=3, history_window=5)
    _ct_flow_calibration = build_flow_calibration(_ct_flow_qualified_trend, _ct_recurrence['table'], _ct_flow_evidence['qualified_trend_history'], capacity=5, min_saved_snapshots=3)
    _ct_flow_qualified_trend = build_closed_session_calibration_trend(_ct_flow_qualified_trend, _ct_flow_evidence)
    _ct_flow_calibration = build_flow_calibration(_ct_flow_qualified_trend, _ct_recurrence['table'], _ct_flow_evidence['qualified_trend_history'], capacity=5, min_saved_snapshots=3, min_observed_intervals=2)
    _ct_flow_calibration = apply_flow_evidence_guard(_ct_flow_calibration, _ct_flow_evidence)
    _ct_flow_calibration_promotion = build_flow_calibration_promotion(_ct_flow_calibration, _ct_flow_evidence, min_promotion_intervals=3, min_positive_burn_ratio=2 / 3, max_negative_intervals=0)
    _ct_flow_calibration = apply_flow_calibration_promotion_guard(_ct_flow_calibration, _ct_flow_calibration_promotion)
    _ct_flow_calibration_promotion_queue = build_flow_calibration_promotion_queue(_ct_flow_calibration_promotion)
    _ct_flow_calibration_queue = build_flow_calibration_queue(_ct_flow_calibration)
    _ct_flow_calibration_history = load_csv('operations_flow_calibration_snapshots.csv')
    _ct_latest_flow_calibration = latest_flow_calibration_snapshot(_ct_flow_calibration_history)
    _ct_flow_evidence_history = load_csv('operations_flow_evidence_snapshots.csv')
    _ct_latest_flow_evidence = latest_flow_evidence_snapshot(_ct_flow_evidence_history)
    _ct_flow_evidence_queue = build_flow_evidence_queue(_ct_flow_evidence)
    st.subheader('1H-Q. 처리 흐름 투자 근거 적격성 확인 / 종료된 세션 표본 추출 보호 점검')
    fe1, fe2, fe3, fe4, fe5, fe6 = st.columns(6)
    fe1.metric('투자 근거 상태', _locale.code(_ct_flow_evidence['evidence_state']))
    fe2.metric('적격 연결 주소', f"{_ct_flow_evidence['qualified_endpoints']}/{_ct_flow_evidence['min_qualified_endpoints']}")
    fe3.metric('적격 구간', _locale.code(_ct_flow_evidence['qualified_intervals']))
    fe4.metric('종료됨 작업 세션 날짜', _locale.code(_ct_flow_evidence['closed_session_dates']))
    fe5.metric('이력 보호 점검', _locale.code(_ct_flow_evidence['calibration_history_guard']))
    fe6.metric('투자 실행 권한', '없음')
    fee1, fee2, fee3, fee4 = st.columns(4)
    fee1.metric('원본 / 유효 추세', f"{_ct_flow_evidence['raw_trend_snapshots']} / {_ct_flow_evidence['valid_trend_snapshots']}")
    fee2.metric('당일 대체됨', _locale.code(_ct_flow_evidence['same_day_superseded']))
    fee3.metric('종료됨 날짜 w/o 추세', _locale.code(_ct_flow_evidence['closed_dates_without_trend']))
    fee4.metric('종료됨-날짜 확인 범위', f"{_ct_flow_evidence['coverage_ratio']:.1%}")
    _fe_boundary_counts = _ct_flow_evidence.get('boundary_status_counts', {})
    feb1, feb2, feb3, feb4 = st.columns(4)
    feb1.metric('작업 세션 쌍 문제', _locale.code(_ct_flow_evidence.get('invalid_session_pairs', 0)))
    feb2.metric('사후-종료 추세 전용', _locale.code(_fe_boundary_counts.get('POST_CLOSE_TREND_ONLY', 0)))
    feb3.metric('사전-진행 중 추세 전용', _locale.code(_fe_boundary_counts.get('PRE_OPEN_TREND_ONLY', 0)))
    feb4.metric('금지 당일 추세', _locale.code(_fe_boundary_counts.get('NO_SAME_DAY_TREND', 0)))
    few1, few2, few3, few4, few5 = st.columns(5)
    few1.metric('전체 기간 적격', _locale.code(_ct_flow_evidence.get('lifetime_qualified_endpoints', _ct_flow_evidence['qualified_endpoints'])))
    few2.metric('연속 기간', _locale.code(_ct_flow_evidence.get('recent_consecutive_endpoints', _ct_flow_evidence['qualified_endpoints'])))
    few3.metric('처리 용량 시장 국면', f"{_ct_flow_evidence.get('capacity_regime_endpoints', _ct_flow_evidence['qualified_endpoints'])} @ {_ct_flow_evidence.get('latest_capacity', 0)}")
    few4.metric('기간 상태', _locale.code(_ct_flow_evidence.get('evidence_window_state', 'LEGACY')))
    few5.metric('최신 경계', _locale.code(_ct_flow_evidence.get('latest_boundary_status', 'NONE')))
    _fe_boundary_table = _ct_flow_evidence.get('boundary_table', pd.DataFrame())
    if isinstance(_fe_boundary_table, pd.DataFrame) and (not _fe_boundary_table.empty):
        with st.expander('종료된 세션 경계 진단', expanded=False):
            _locale.dataframe(st, _fe_boundary_table, width='stretch', hide_index=True)
    _fe_state = _ct_flow_evidence['evidence_state']
    if _fe_state == 'INTEGRITY_REVIEW':
        st.error('처리 흐름 투자 근거 무결성 오류가 있어 보정 이력 사용을 차단했습니다.')
    elif _fe_state == 'CLOSED_SESSION_EVIDENCE_REQUIRED':
        st.info('보정 투자 근거는 일일 운영 작업 세션 종료와 연결된 추세 연결 주소부터 계산합니다. 같은 날 상태 기록을 반복 저장해 이력을 늘리지 않습니다.')
    elif _fe_state == 'EVIDENCE_MATURING':
        st.info('적격 처리 흐름 투자 근거가 축적 중입니다. 각 종료된 세션 날짜의 종료 이전 최신 추세 상태 기록만 1개 연결 주소로 계산합니다.')
    else:
        st.success('처리 흐름 투자 근거 준비 완료 · 종료된 세션 적격 이력을 보정 입력으로 사용합니다.')
    _fe_window_state = _ct_flow_evidence.get('evidence_window_state', '')
    if _fe_window_state == 'RECENT_SESSION_GAP':
        st.warning('최근 종료됨 작업 세션에 적격 추세 연결 주소가 없어 보정 투자 근거 기간을 과거 연결 주소로 이어 붙이지 않습니다. 다음 실제 작업 세션에서 새 연속 기간을 시작하세요.')
    elif _fe_window_state == 'CAPACITY_REGIME_MATURING':
        st.warning('최근 종료된 세션 투자 근거는 연속이지만 처리 용량 시장 국면이 변경되었습니다. 이전 처리 용량 연결 주소는 검증 이력으로만 보존하고 새 처리 용량 시장 국면에서 보정 기한을 다시 축적합니다.')
    if _fe_boundary_counts.get('POST_CLOSE_TREND_ONLY', 0) > 0:
        st.warning('현재 종료된 세션 중 종료 이후에만 추세 상태 기록이 존재하는 구간이 있습니다. 과거 종료 뒤 상태 기록을 소급 투자 근거로 사용하지 않습니다. 다음 실제 작업 세션에서는 진행 중 → 추세 상태 기록 → 종료 순서를 사용하세요.')
    if _fe_boundary_counts.get('PRE_OPEN_TREND_ONLY', 0) > 0:
        st.warning('현재 종료된 세션 중 진행 중 이전 상태 기록만 존재하는 구간이 있습니다. 해당 작업 세션의 투자 근거는 진행 중 이후 저장된 상태 기록부터 인정합니다.')
    if not _ct_flow_evidence['endpoint_table'].empty:
        with st.expander('적격 처리 흐름 투자 근거 연결 주소', expanded=False):
            _locale.dataframe(st, _ct_flow_evidence['endpoint_table'], width='stretch', hide_index=True)
    if not _ct_flow_evidence_queue.empty:
        with st.expander('처리 흐름 투자 근거 적격성 확인 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_flow_evidence_queue, width='stretch', hide_index=True)
    if _ct_latest_flow_evidence:
        _fe_latest_integrity = flow_evidence_snapshot_integrity(_ct_latest_flow_evidence)
        st.caption(f"최신 투자 근거 상태 기록 · {_ct_latest_flow_evidence.get('evidence_snapshot_id', '')} · {_locale.code(_ct_latest_flow_evidence.get('evidence_state', ''))} · 무결성 {_locale.code(_fe_latest_integrity['status'])}")
    _fe_note = st.text_input('처리 흐름 투자 근거 적격성 확인 상태 기록 메모', value='', key='operations_flow_evidence_snapshot_note', placeholder='예: 종료된 세션 투자 근거 검토 / 금지 상태 기록 불필요한 반복 생성')
    if st.button('운영 처리 흐름 투자 근거 적격성 확인 상태 기록 저장', key='operations_flow_evidence_snapshot_save'):
        _fe_row = build_flow_evidence_snapshot(_ct_flow_evidence, note=_fe_note)
        _fe_hist = load_csv('operations_flow_evidence_snapshots.csv')
        for _col in FLOW_EVIDENCE_SNAPSHOT_COLS:
            if _col not in _fe_hist.columns:
                _fe_hist[_col] = ''
        _fe_hist = pd.concat([_fe_hist[FLOW_EVIDENCE_SNAPSHOT_COLS], pd.DataFrame([_fe_row])], ignore_index=True)
        verified_save_feedback(_fe_hist, 'operations_flow_evidence_snapshots.csv', f"Flow Evidence Snapshot 저장 · {_fe_row['evidence_state']} · Qualified {_fe_row['qualified_endpoints']} · Execution Authorization = NONE.", rerun=False)
    st.caption('보정 이력은 원본 상태 기록 개수가 아니라 종료됨 일일 운영 작업 세션과 연결된 적격 추세 연결 주소를 사용합니다. 같은 날 여러 번 저장한 상태 기록은 이력을 부풀리지 않습니다.')
    st.caption(f"종료된 세션 보정 구간 보호 점검 · 연결 주소 {_ct_flow_calibration.get('saved_trend_snapshots', 0)} · 종료됨 구간 {_ct_flow_calibration.get('observed_intervals', 0)} · 예상 {_ct_flow_evidence.get('qualified_intervals', 0)} · 일치 {_locale.code(_ct_flow_calibration.get('interval_alignment_status', ''))} · 실전 구간은 보정 평균/긍정 처리 비율에서 제외됩니다.")
    st.subheader('1H. 처리 흐름 추세 보정 / 처리 용량 효율 / 전망 보호 점검')
    fc1, fc2, fc3, fc4, fc5 = st.columns(5)
    fc1.metric('보정 상태', _locale.code(_ct_flow_calibration['calibration_state']))
    fc2.metric('저장됨 상태 기록 / 구간', f"{_ct_flow_calibration['saved_trend_snapshots']} / {_ct_flow_calibration['observed_intervals']}")
    fc3.metric('긍정 처리 비율', f"{_ct_flow_calibration['positive_burn_ratio']:.1%}")
    fc4.metric('전망 보호 점검', _locale.code(_ct_flow_calibration['projection_guard']))
    fc5.metric('투자 실행 권한', '없음')
    fce1, fce2, fce3, fce4 = st.columns(4)
    fce1.metric('평균 유입 / 종료', f"{_ct_flow_calibration['avg_arrivals_per_interval']:.2f} / {_ct_flow_calibration['avg_exits_per_interval']:.2f}")
    fce2.metric('종료 / 처리 용량', f"{_ct_flow_calibration['exit_per_capacity']:.2f}x")
    fce3.metric('확인 필요 / 미처리 작업 부담', f"{_ct_flow_calibration['attention_pressure']:.2f}x / {_ct_flow_calibration['backlog_pressure']:.2f}x")
    fce4.metric('상위 근본 원인 비중', _locale.code('-' if not _ct_flow_calibration['top_root_cause'] else f"{_ct_flow_calibration['root_cause_concentration']:.1%}"))
    if _ct_flow_calibration['calibration_state'] == 'INSUFFICIENT_HISTORY':
        st.info('처리 흐름 보정은 아직 이력이 부족합니다. 실제 대기 목록 변화가 생길 때 추세 상태 기록을 추가해 최소 3개의 저장 관측치를 확보하세요.')
    elif _ct_flow_calibration['calibration_state'] == 'INTEGRITY_REVIEW':
        st.error('추세 상태 기록 무결성 문제로 보정을 사용할 수 없습니다.')
    elif _ct_flow_calibration['projection_guard'] == 'ALLOW_PROJECTION_REVIEW':
        st.success('전망 보호 점검 = 허용 · 전망 · 검토 · 관측된 종료-유입 흐름이 최소 이력/일관성 기준을 통과했습니다. 여전히 운영 전망일 뿐 보장이 아닙니다.')
    else:
        st.warning(f"전망 보호 점검 = {_ct_flow_calibration['projection_guard']} · 현재 관측으로는 대기 작업 감소 전망을 신뢰하기에 충분하지 않습니다.")
    if _ct_flow_calibration['top_root_cause']:
        st.caption(f"상위 근본 원인 · {_ct_flow_calibration['top_root_cause']} · 그룹 비중 {_ct_flow_calibration['root_cause_concentration']:.1%}")
    with st.expander('보정 구간 상세', expanded=False):
        _fc_intervals = _ct_flow_calibration['intervals']
        if _fc_intervals.empty:
            st.info('보정 구간 이력이 아직 없습니다.')
        else:
            _locale.dataframe(st, _fc_intervals, width='stretch', hide_index=True)
    with st.expander('근본 원인 처리 용량 부담', expanded=False):
        _fc_root = _ct_flow_calibration['root_cause_burden']
        if _fc_root.empty:
            st.info('근본 원인 부담 데이터가 없습니다.')
        else:
            _locale.dataframe(st, _fc_root, width='stretch', hide_index=True)
    if _ct_latest_flow_calibration:
        _fc_latest_integrity = flow_calibration_snapshot_integrity(_ct_latest_flow_calibration)
        st.caption(f"최신 보정 상태 기록 · {_ct_latest_flow_calibration.get('calibration_snapshot_id', '')} · {_locale.code(_ct_latest_flow_calibration.get('calibration_state', ''))} · 무결성 {_locale.code(_fc_latest_integrity['status'])}")
    _fc_note = st.text_input('처리 흐름 보정 상태 기록 메모', value='', key='operations_flow_calibration_snapshot_note', placeholder='예: 이력 보정 검토 / 금지 자동 전망')
    if st.button('운영 처리 흐름 보정 상태 기록 저장', key='operations_flow_calibration_snapshot_save'):
        _fc_row = build_flow_calibration_snapshot(_ct_flow_calibration, note=_fc_note)
        _fc_hist = load_csv('operations_flow_calibration_snapshots.csv')
        for _col in FLOW_CALIBRATION_SNAPSHOT_COLS:
            if _col not in _fc_hist.columns:
                _fc_hist[_col] = ''
        _fc_hist = pd.concat([_fc_hist[FLOW_CALIBRATION_SNAPSHOT_COLS], pd.DataFrame([_fc_row])], ignore_index=True)
        verified_save_feedback(_fc_hist, 'operations_flow_calibration_snapshots.csv', f"Operations Flow Calibration Snapshot 저장 · {_fc_row['calibration_state']} · Projection {_fc_row['projection_guard']} · Execution Authorization = NONE.", rerun=False)
    st.caption('보정은 관측된 운영 대기 목록 흐름을 검증하는 도구입니다. 전망 보호 점검이 허용되어도 투자 결과나 검토 완료 시점을 보장하지 않습니다.')
    _ct_flow_calibration_promotion_history = load_csv('operations_flow_calibration_promotion_snapshots.csv')
    _ct_latest_flow_calibration_promotion = latest_flow_calibration_promotion_snapshot(_ct_flow_calibration_promotion_history)
    st.subheader('1H-P. 보정 승격 / 처리 속도 안정성 / 전망 수용 점검')
    cp1, cp2, cp3, cp4, cp5, cp6 = st.columns(6)
    cp1.metric('승격 상태', _locale.code(_ct_flow_calibration_promotion['promotion_state']))
    cp2.metric('승격 구간', f"{_ct_flow_calibration_promotion['observed_intervals']}/{_ct_flow_calibration_promotion['target_intervals']}")
    cp3.metric('긍정 처리 비율', f"{_ct_flow_calibration_promotion['positive_burn_ratio']:.1%}")
    cp4.metric('부정 구간', _locale.code(_ct_flow_calibration_promotion['negative_burn_intervals']))
    cp5.metric('유효 보호 점검', _locale.code(_ct_flow_calibration['projection_guard']))
    cp6.metric('투자 실행 권한', '없음')
    cpd1, cpd2, cpd3, cpd4 = st.columns(4)
    cpd1.metric('원본 보정 보호 점검', _locale.code(_ct_flow_calibration_promotion['raw_projection_guard']))
    cpd2.metric('평균 순현금 소진액', f"{_ct_flow_calibration_promotion['avg_net_burn_per_interval']:.2f}")
    cpd3.metric('최신 순현금 소진액', f"{_ct_flow_calibration_promotion['latest_net_burn']:.2f}")
    cpd4.metric('전망 권한', '없음')
    _cp_state = _ct_flow_calibration_promotion['promotion_state']
    if _cp_state == 'PROMOTION_INTEGRITY_REVIEW':
        st.error('보정 승격 무결성/일치 문제가 있어 전망 수용을 차단했습니다.')
    elif _cp_state == 'PROMOTION_EVIDENCE_MATURING':
        st.info('보정 승격 투자 근거가 아직 충분하지 않습니다. 기본 기준은 같은 처리 용량 시장 국면의 완료 종료된 세션 구간 3개입니다.')
    elif _cp_state == 'PROMOTION_NO_CLEARING':
        st.warning('승격 기간의 평균 순현금 소진액이 양수가 아니므로 전망 수용을 열지 않습니다.')
    elif _cp_state in {'PROMOTION_ADVERSE_INTERVAL_REVIEW', 'PROMOTION_MIXED_BURN'}:
        st.warning('평균 보정이 양수여도 승격 기간의 불리한/혼합 처리 때문에 전망 수용을 보류합니다.')
    else:
        st.success('보정 승격 준비 완료 · 최소 종료된 세션 처리 속도 안정성 기준을 통과했습니다. 이는 전망 검토 수용일 뿐 실행 승인이 아닙니다.')
    if not _ct_flow_calibration_promotion_queue.empty:
        with st.expander('보정 승격 검토 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_flow_calibration_promotion_queue, width='stretch', hide_index=True)
    if _ct_latest_flow_calibration_promotion:
        _cp_latest_integrity = flow_calibration_promotion_snapshot_integrity(_ct_latest_flow_calibration_promotion)
        st.caption(f"최신 승격 상태 기록 · {_ct_latest_flow_calibration_promotion.get('promotion_snapshot_id', '')} · {_locale.code(_ct_latest_flow_calibration_promotion.get('promotion_state', ''))} · 무결성 {_locale.code(_cp_latest_integrity['status'])}")
    _cp_note = st.text_input('처리 흐름 보정 승격 상태 기록 메모', value='', key='operations_flow_calibration_promotion_snapshot_note', placeholder='예: 종료됨-구간 승격 확인 근거 / 금지 자동 전망')
    if st.button('운영 처리 흐름 보정 승격 상태 기록 저장', key='operations_flow_calibration_promotion_snapshot_save'):
        _cp_row = build_flow_calibration_promotion_snapshot(_ct_flow_calibration_promotion, note=_cp_note)
        _cp_hist = load_csv('operations_flow_calibration_promotion_snapshots.csv')
        for _col in FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS:
            if _col not in _cp_hist.columns:
                _cp_hist[_col] = ''
        _cp_hist = pd.concat([_cp_hist[FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS], pd.DataFrame([_cp_row])], ignore_index=True)
        verified_save_feedback(_cp_hist, 'operations_flow_calibration_promotion_snapshots.csv', f"Calibration Promotion Snapshot 저장 · {_cp_row['promotion_state']} · Guard {_cp_row['effective_projection_guard']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('v1.31 승격 점검은 원본 보정이 허용여도 종료된 세션 구간 확인 근거가 충분하지 않거나 불리한 구간이 있으면 전망을 추가로 유지합니다.')
    _ct_flow_projection_admission = build_flow_projection_admission(_ct_flow_calibration, _ct_flow_calibration_promotion, _ct_latest_flow_calibration, _ct_latest_flow_calibration_promotion)
    _ct_flow_projection_admission_queue = build_flow_projection_admission_queue(_ct_flow_projection_admission)
    _ct_flow_projection_admission_history = load_csv('operations_flow_projection_admission_snapshots.csv')
    _ct_latest_projection_admission = latest_flow_projection_admission_snapshot(_ct_flow_projection_admission_history)
    st.subheader('1H-A. 전망 수용 출처 고정 / 승격 최신성 보호 점검')
    pa1, pa2, pa3, pa4, pa5, pa6 = st.columns(6)
    pa1.metric('수용 상태', _locale.code(_ct_flow_projection_admission['admission_state']))
    pa2.metric('보정 출처', _locale.code(_ct_flow_projection_admission['calibration_source_freshness']))
    pa3.metric('승격 출처', _locale.code(_ct_flow_projection_admission['promotion_source_freshness']))
    pa4.metric('출처 주문', _locale.code(_ct_flow_projection_admission['source_order_state']))
    pa5.metric('유효 보호 점검', _locale.code(_ct_flow_projection_admission['effective_projection_guard']))
    pa6.metric('투자 실행 권한', '없음')
    _pa_state = _ct_flow_projection_admission['admission_state']
    if _pa_state == 'ADMISSION_UPSTREAM_HOLD':
        st.info('전망 수용은 현재 선행 자료 승격/보정 유지를 그대로 유지합니다. 현재 단계에서는 상태 기록을 억지로 저장해 수용을 열 필요가 없습니다.')
    elif _pa_state == 'ADMISSION_CALIBRATION_SOURCE_REQUIRED':
        st.warning('승격 · 준비 완료 이후에는 현재 보정 상태 기록이 필요합니다. 1H에서 보정 상태 기록을 먼저 저장하세요.')
    elif _pa_state == 'ADMISSION_PROMOTION_SOURCE_REQUIRED':
        st.warning('보정 상태 기록 현재 확인 후 승격 · 준비 완료 상태를 승격 검증 상태 기록으로 저장하세요.')
    elif _pa_state in {'ADMISSION_CALIBRATION_SOURCE_INTEGRITY_REVIEW', 'ADMISSION_CALIBRATION_SOURCE_DRIFT_REVIEW', 'ADMISSION_PROMOTION_SOURCE_INTEGRITY_REVIEW', 'ADMISSION_PROMOTION_SOURCE_DRIFT_REVIEW', 'ADMISSION_PROMOTION_AFTER_CALIBRATION_REQUIRED', 'ADMISSION_SOURCE_TIME_INTEGRITY_REVIEW'}:
        st.warning(f'{_locale.code(_pa_state)} · 보정 상태 기록 → 승격 검증 상태 기록 순서와 현재/무결성을 확인하세요.')
    else:
        st.success('전망 수용 준비 완료 · 현재 보정 + 현재 승격 검증 + 출처 주문이 일치합니다. 이는 전망 검토 수용이며 실행 승인이 아닙니다.')
    if not _ct_flow_projection_admission_queue.empty:
        with st.expander('전망 수용 검토 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_flow_projection_admission_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_admission:
        _pa_latest_integrity = flow_projection_admission_snapshot_integrity(_ct_latest_projection_admission)
        st.caption(f"최신 수용 상태 기록 · {_ct_latest_projection_admission.get('admission_snapshot_id', '')} · {_locale.code(_ct_latest_projection_admission.get('admission_state', ''))} · 무결성 {_locale.code(_pa_latest_integrity['status'])}")
    _pa_note = st.text_input('처리 흐름 전망 수용 상태 기록 메모', value='', key='operations_flow_projection_admission_snapshot_note', placeholder='예: 보정 + 승격 출처 고정 / 금지 자동 전망')
    if st.button('운영 처리 흐름 전망 수용 상태 기록 저장', key='operations_flow_projection_admission_snapshot_save'):
        _pa_row = build_flow_projection_admission_snapshot(_ct_flow_projection_admission, note=_pa_note)
        _pa_hist = load_csv('operations_flow_projection_admission_snapshots.csv')
        for _col in FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS:
            if _col not in _pa_hist.columns:
                _pa_hist[_col] = ''
        _pa_hist = pd.concat([_pa_hist[FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS], pd.DataFrame([_pa_row])], ignore_index=True)
        verified_save_feedback(_pa_hist, 'operations_flow_projection_admission_snapshots.csv', f"Projection Admission Snapshot 저장 · {_pa_row['admission_state']} · Guard {_pa_row['effective_projection_guard']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('승격 · 준비 완료 이후에는 보정 상태 기록과 승격 검증 상태 기록이 모두 현재여야 전망 검토 수용이 열립니다. 이전 승격 확인 근거를 새 보정에 재사용하지 않습니다.')
    _ct_flow_projection = build_flow_projection(_ct_flow_calibration, _ct_latest_flow_calibration, admission=_ct_flow_projection_admission)
    _ct_flow_projection_queue = build_flow_projection_queue(_ct_flow_projection)
    _ct_flow_projection_history = load_csv('operations_flow_projection_snapshots.csv')
    _ct_latest_flow_projection = latest_flow_projection_snapshot(_ct_flow_projection_history)
    st.subheader('1I. 처리 흐름 전망 검토 / 처리 완료 시나리오 / 최신성 보호 점검')
    fp1, fp2, fp3, fp4, fp5 = st.columns(5)
    fp1.metric('전망 상태', _locale.code(_ct_flow_projection['projection_state']))
    fp2.metric('출처 최신성', _locale.code(_ct_flow_projection['source_freshness']))
    fp3.metric('기준 처리 완료', _locale.code('-' if _ct_flow_projection['base_clearance_intervals'] is None else f"{_ct_flow_projection['base_clearance_intervals']} 구간"))
    fp4.metric('위기 상황 처리 완료', _locale.code('-' if _ct_flow_projection['stress_clearance_intervals'] is None else f"{_ct_flow_projection['stress_clearance_intervals']} 구간"))
    fp5.metric('투자 실행 권한', '없음')
    fpd1, fpd2, fpd3, fpd4 = st.columns(4)
    fpd1.metric('전망 보호 점검', _locale.code(_ct_flow_projection['projection_guard']))
    fpd2.metric('관찰된 구간', _locale.code(_ct_flow_projection['observed_intervals']))
    fpd3.metric('긍정 처리 비율', f"{_ct_flow_projection['positive_burn_ratio']:.1%}")
    fpd4.metric('전망 권한', '없음')
    _fp_state = _ct_flow_projection['projection_state']
    if _fp_state == 'SOURCE_CALIBRATION_REQUIRED':
        st.info('처리 흐름 전망은 검증된 보정 상태 기록을 출처로 사용합니다. 1H에서 현재 보정 상태 기록을 먼저 저장하세요.')
    elif _fp_state == 'SOURCE_CALIBRATION_INTEGRITY_REVIEW':
        st.error('저장된 보정 상태 기록 무결성이 일치하지 않아 전망을 차단했습니다.')
    elif _fp_state == 'SOURCE_CALIBRATION_DRIFT_REVIEW':
        st.warning('현재 보정과 최신 저장 상태 기록이 달라 전망을 차단했습니다. 현재 상태를 검토한 뒤 새 보정 상태 기록을 저장하세요.')
        _fp_mismatches = _ct_flow_projection.get('source_mismatches', [])
        if _fp_mismatches:
            st.caption('기준 이탈 항목 · ' + ', '.join((str(x) for x in _fp_mismatches)))
    elif _fp_state == 'READY_FOR_REVIEW':
        st.success('전망 준비 완료 · 대상 · 검토 · 검증된 보정 출처와 현재 상태가 일치합니다. 아래 값은 운영 민감도 시나리오이며 검토 완료 시점이나 투자 결과를 보장하지 않습니다.')
        _locale.dataframe(st, _ct_flow_projection['scenario_table'], width='stretch', hide_index=True)
    else:
        st.info(f'전망 {_locale.code(_fp_state)} · 현재 전망 보호 점검을 유지합니다. 이력/보정 조건을 억지로 변경하지 않습니다.')
    if _ct_latest_flow_projection:
        _fp_latest_integrity = flow_projection_snapshot_integrity(_ct_latest_flow_projection)
        st.caption(f"최신 전망 상태 기록 · {_ct_latest_flow_projection.get('projection_snapshot_id', '')} · {_locale.code(_ct_latest_flow_projection.get('projection_state', ''))} · 무결성 {_locale.code(_fp_latest_integrity['status'])}")
    _fp_note = st.text_input('처리 흐름 전망 상태 기록 메모', value='', key='operations_flow_projection_snapshot_note', placeholder='예: 보호 조건을 적용한 처리 완료 시나리오 검토 / 금지 자동 처리 용량 행동')
    if st.button('운영 처리 흐름 전망 상태 기록 저장', key='operations_flow_projection_snapshot_save'):
        if not _ct_flow_projection['snapshot_eligible']:
            st.warning('전망 상태 기록 저장 보류 · 현재 + 무결성 정상인 보정 출처가 필요합니다.')
        else:
            _fp_row = build_flow_projection_snapshot(_ct_flow_projection, note=_fp_note)
            _fp_hist = load_csv('operations_flow_projection_snapshots.csv')
            for _col in FLOW_PROJECTION_SNAPSHOT_COLS:
                if _col not in _fp_hist.columns:
                    _fp_hist[_col] = ''
            _fp_hist = pd.concat([_fp_hist[FLOW_PROJECTION_SNAPSHOT_COLS], pd.DataFrame([_fp_row])], ignore_index=True)
            verified_save_feedback(_fp_hist, 'operations_flow_projection_snapshots.csv', f"Operations Flow Projection Snapshot 저장 · {_fp_row['projection_state']} · Source {_fp_row['source_freshness']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('위기 상황/기준/없음-유입 값은 운영 민감도 시나리오입니다. 자동 처리 용량 확대/축소, 검토 완료, 투자 주문 또는 투자 실행 승인을 생성하지 않습니다.')
    _ct_ready_projection_source = latest_ready_flow_projection_snapshot(_ct_flow_projection_history)
    _ct_projection_review_history = load_csv('operations_flow_projection_review_snapshots.csv')
    _ct_projection_review = build_flow_projection_review_context(_ct_flow_projection_history, _ct_projection_review_history)
    _ct_projection_review_queue = build_flow_projection_review_queue(_ct_projection_review)
    st.subheader('1I-R. 전망 사용자 검토 기준 계약 / 시나리오 고정')
    pr1, pr2, pr3, pr4, pr5, pr6 = st.columns(6)
    pr1.metric('검토 상태', _locale.code(_ct_projection_review['review_state']))
    pr2.metric('출처 무결성', _locale.code(_ct_projection_review['source_projection_integrity']))
    pr3.metric('출처 현재', _locale.code('YES' if _ct_projection_review['source_current'] else '금지'))
    pr4.metric('검토 고정', _locale.code('고정됨' if _ct_projection_review['review_locked'] else '진행 중'))
    pr5.metric('전망 권한', '없음')
    pr6.metric('투자 실행 권한', '없음')
    _pr_state = _ct_projection_review['review_state']
    if _pr_state == 'PROJECTION_REVIEW_SOURCE_REQUIRED':
        st.info('사용자 검토 기준 계약은 준비 완료 · 대상 · 검토 전망 상태 기록이 생긴 뒤 시작합니다. 현재 유지 · 이력 상태에서는 검토 고정을 만들 필요가 없습니다.')
    elif _pr_state == 'PROJECTION_REVIEW_REQUIRED':
        st.warning('준비 완료 전망 출처가 있습니다. 시나리오 의미와 출처 연결 이력을 직접 확인한 뒤 사용자 검토 고정을 저장해야 결과 추적이 시작됩니다.')
    elif _pr_state == 'PROJECTION_REVIEW_SOURCE_SUPERSEDED':
        st.warning('새 준비 완료 전망이 저장되어 기존 검토 고정이 오래됨 상태가 되었습니다. 새 출처를 다시 검토해야 결과 추적을 재개할 수 있습니다.')
    elif _pr_state == 'PROJECTION_REVIEW_LOCKED':
        st.success('전망 사용자 검토 고정됨 · 최신 준비 완료 전망과 검토 기준 계약이 일치합니다. 이 고정은 결과 추적의 시작 조건일 뿐 전망/처리 용량/투자 실행 승인이 아닙니다.')
    else:
        st.error(f'{_locale.code(_pr_state)} · 전망 검토 검증/출처 무결성을 먼저 복구하세요.')
    if not _ct_projection_review_queue.empty:
        with st.expander('전망 사용자 검토 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_projection_review_queue, width='stretch', hide_index=True)
    _pr_can_lock = _pr_state in {'PROJECTION_REVIEW_REQUIRED', 'PROJECTION_REVIEW_SOURCE_SUPERSEDED'}
    if _pr_can_lock:
        _pr_source_confirm = st.checkbox('준비 완료 전망 출처의 식별번호/무결성 해시 연결 이력과 현재 출처를 확인했습니다.', key='projection_review_source_lineage_confirm')
        _pr_scenario_confirm = st.checkbox('위기 상황/기준/없음-유입 시나리오가 예측 보장이 아닌 운영 민감도임을 확인했습니다.', key='projection_review_scenario_semantics_confirm')
        _pr_capacity_confirm = st.checkbox('전망 검토 고정이 자동 처리 용량 확대/축소를 승인하지 않음을 확인했습니다.', key='projection_review_no_auto_capacity_confirm')
        _pr_execution_confirm = st.checkbox('전망 검토 고정이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='projection_review_no_execution_authorization_confirm')
        _pr_human_confirm = st.checkbox('현재 전망 시나리오를 최종 사용자 검토했습니다.', key='projection_review_human_confirm')
        _pr_note = st.text_input('전망 사용자 검토 고정 메모', value='', key='projection_human_review_lock_note', placeholder='예: 시나리오 의미 + 출처 연결 이력 검토됨')
        if st.button('전망 사용자 검토 고정 저장', key='projection_human_review_lock_save'):
            try:
                _pr_row = build_flow_projection_review_lock(_ct_ready_projection_source, source_lineage_confirmed=_pr_source_confirm, scenario_semantics_confirmed=_pr_scenario_confirm, no_auto_capacity_confirmed=_pr_capacity_confirm, no_execution_authorization_confirmed=_pr_execution_confirm, human_review_confirmed=_pr_human_confirm, note=_pr_note)
                _pr_hist = load_csv('operations_flow_projection_review_snapshots.csv')
                for _col in FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS:
                    if _col not in _pr_hist.columns:
                        _pr_hist[_col] = ''
                _pr_hist = pd.concat([_pr_hist[FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS], pd.DataFrame([_pr_row])], ignore_index=True)
                verified_save_feedback(_pr_hist, 'operations_flow_projection_review_snapshots.csv', f"Projection Human Review Lock 저장 · {_pr_row['source_projection_snapshot_id']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except Exception as _pr_exc:
                st.warning(f'전망 사용자 검토 고정 저장 보류 · {_pr_exc}')
    if _ct_projection_review.get('latest_review_snapshot_id'):
        st.caption(f"최신 검토 고정 · {_ct_projection_review.get('latest_review_snapshot_id', '')} · 무결성 {_ct_projection_review.get('latest_review_integrity', '')}")
    st.caption('결과 추적은 사용자 검토 고정이 걸린 최신 준비 완료 전망부터 시작합니다. 새 준비 완료 전망이 저장되면 기존 고정은 자동으로 대체됨되어 재검토가 필요합니다.')
    _ct_ready_projection_source = latest_reviewed_projection_source(_ct_flow_projection_history, _ct_projection_review_history)
    _ct_projection_outcome = build_flow_projection_outcome(_ct_ready_projection_source, _ct_flow_trend_history, min_evaluation_intervals=2, max_evaluation_intervals=20, relative_error_threshold=0.5)
    _ct_guarded_projection_outcome = build_guarded_flow_projection_outcome(_ct_flow_projection_history, _ct_projection_review_history, _ct_flow_trend_history, load_csv('operations_sessions.csv'), min_evaluation_endpoints=2, max_evaluation_endpoints=20, relative_error_threshold=0.5)
    _ct_projection_outcome_evidence = _ct_guarded_projection_outcome['window']
    _ct_projection_outcome = _ct_guarded_projection_outcome['outcome']
    _ct_projection_outcome_evidence_queue = build_flow_projection_outcome_evidence_queue(_ct_projection_outcome_evidence)
    _ct_projection_outcome_evidence_history = load_csv('operations_flow_projection_outcome_evidence_snapshots.csv')
    _ct_latest_projection_outcome_evidence = latest_flow_projection_outcome_evidence_snapshot(_ct_projection_outcome_evidence_history)
    _ct_projection_outcome_queue = build_flow_projection_outcome_queue(_ct_projection_outcome)
    _ct_projection_outcome_history = load_csv('operations_flow_projection_outcome_snapshots.csv')
    _ct_latest_projection_outcome = latest_flow_projection_outcome_snapshot(_ct_projection_outcome_history)
    st.subheader('1I-E. 전망 결과 투자 근거 / 사후 판단 왜곡 방지 / 종료된 세션 보호 점검')
    oe1, oe2, oe3, oe4, oe5, oe6 = st.columns(6)
    oe1.metric('결과 투자 근거', _locale.code(_ct_projection_outcome_evidence['window_state']))
    oe2.metric('추적 보호 점검', _locale.code(_ct_projection_outcome_evidence['tracking_guard']))
    oe3.metric('적격 연결 주소', _locale.code(_ct_projection_outcome_evidence['eligible_endpoints']))
    oe4.metric('종료됨 작업 세션', _locale.code(_ct_projection_outcome_evidence['post_lock_closed_sessions']))
    oe5.metric('사후 판단 왜곡 방지', _locale.code(_ct_projection_outcome_evidence['prelock_contamination_count']))
    oe6.metric('투자 실행 권한', '없음')
    oeg1, oeg2, oeg3, oeg4 = st.columns(4)
    oeg1.metric('투자 근거 차이', _locale.code(_ct_projection_outcome_evidence['closed_session_gap_count']))
    oeg2.metric('처리 용량 기준 이탈', _locale.code(_ct_projection_outcome_evidence['capacity_drift_endpoints']))
    oeg3.metric('검토 고정', _locale.code('고정됨' if _ct_projection_outcome_evidence['review_state'] == 'PROJECTION_REVIEW_LOCKED' else '진행 중'))
    oeg4.metric('전망 권한', '없음')
    _oe_state = _ct_projection_outcome_evidence['window_state']
    if _oe_state == 'OUTCOME_REVIEW_SOURCE_REQUIRED':
        st.info('결과 투자 근거는 사용자 검토 고정됨 준비 완료 전망이 생긴 뒤 시작합니다. 현재 HOLD_HISTORY에서는 정상이며 별도 조작이 필요하지 않습니다.')
    elif _oe_state in {'OUTCOME_REVIEW_LOCK_REQUIRED', 'OUTCOME_REVIEW_SOURCE_SUPERSEDED'}:
        st.warning(f'{_locale.code(_oe_state)} · 최신 준비 완료 전망에 대한 사용자 검토 고정이 필요합니다.')
    elif _oe_state in {'OUTCOME_REVIEW_INTEGRITY_REVIEW', 'OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW', 'OUTCOME_EVIDENCE_INTEGRITY_REVIEW'}:
        st.error(f'{_locale.code(_oe_state)} · 검토/추세 투자 근거 무결성을 먼저 복구해야 합니다.')
    elif _oe_state == 'OUTCOME_ANTI_HINDSIGHT_REVIEW':
        st.error('전망 생성 후 사용자 검토 고정 전에 추세 상태 기록이 이미 관측되었습니다. 사후정보가 섞일 수 있으므로 이 전망의 결과 평가를 차단합니다. 새 전망을 만든 뒤 미래 투자 근거 전에 검토 고정을 완료하세요.')
    elif _oe_state == 'OUTCOME_EVIDENCE_GAP_REVIEW':
        st.warning('검토 고정 이후 종료된 세션 투자 근거 차이가 있습니다. 누락 구간을 건너뛰어 모형 오류를 계산하지 않으며 새 전망/검토 주기로 기준 재설정해야 합니다.')
    elif _oe_state == 'OUTCOME_WAIT_CLOSED_SESSION':
        st.info('검토 고정 이후 정상 종료된 세션 투자 근거를 기다리고 있습니다. 작업 세션 진행 중 → 추세 상태 기록 → 종료 순서로 실제 투자 근거를 축적하세요.')
    elif _oe_state == 'OUTCOME_EVIDENCE_MATURING':
        st.info('결과 종료된 세션 투자 근거가 축적 중입니다. 같은 작업 세션 상태 기록 반복 저장은 투자 근거 건수를 늘리지 않습니다.')
    else:
        st.success('결과 투자 근거 준비 완료 · 검토 고정 이후 연속 종료된 세션 연결 주소만 결과 평가에 사용합니다.')
    if not _ct_projection_outcome_evidence['endpoint_table'].empty:
        with st.expander('결과 적격 종료된 세션 연결 주소', expanded=False):
            _locale.dataframe(st, _ct_projection_outcome_evidence['endpoint_table'], width='stretch', hide_index=True)
    if not _ct_projection_outcome_evidence_queue.empty:
        with st.expander('전망 결과 투자 근거 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_projection_outcome_evidence_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_outcome_evidence:
        _oe_latest_integrity = flow_projection_outcome_evidence_snapshot_integrity(_ct_latest_projection_outcome_evidence)
        st.caption(f"최신 결과 투자 근거 상태 기록 · {_ct_latest_projection_outcome_evidence.get('outcome_evidence_snapshot_id', '')} · {_locale.code(_ct_latest_projection_outcome_evidence.get('window_state', ''))} · 무결성 {_locale.code(_oe_latest_integrity['status'])}")
    _oe_note = st.text_input('전망 결과 투자 근거 상태 기록 메모', value='', key='operations_flow_projection_outcome_evidence_snapshot_note', placeholder='예: 사후-검토 종료된 세션 기간 / 금지 사후 판단')
    if st.button('운영 처리 흐름 전망 결과 투자 근거 상태 기록 저장', key='operations_flow_projection_outcome_evidence_snapshot_save'):
        _oe_row = build_flow_projection_outcome_evidence_snapshot(_ct_projection_outcome_evidence, note=_oe_note)
        _oe_hist = load_csv('operations_flow_projection_outcome_evidence_snapshots.csv')
        for _col in FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS:
            if _col not in _oe_hist.columns:
                _oe_hist[_col] = ''
        _oe_hist = pd.concat([_oe_hist[FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS], pd.DataFrame([_oe_row])], ignore_index=True)
        verified_save_feedback(_oe_hist, 'operations_flow_projection_outcome_evidence_snapshots.csv', f"Projection Outcome Evidence Snapshot 저장 · {_oe_row['window_state']} · Eligible {_oe_row['eligible_endpoints']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('결과 평가는 사용자 검토 고정 이후의 종료된 세션 추세 연결 주소만 사용합니다. 검토 전에 이미 관측된 추세, 작업 세션 차이, 무결성 오류를 건너뛰어 모델 성능을 계산하지 않습니다.')
    st.subheader('1J. 전망 결과 / 오류 원인 분석 / 처리 용량 판단 관리 기준')
    fo1, fo2, fo3, fo4, fo5, fo6 = st.columns(6)
    fo1.metric('결과 상태', _locale.code(_ct_projection_outcome['evaluation_state']))
    fo2.metric('투자 근거 구간', _locale.code(_ct_projection_outcome['evidence_intervals']))
    _fo_realized = _ct_projection_outcome['realized_avg_net_burn']
    fo3.metric('실현 처리', _locale.code('-' if _fo_realized is None else f'{_fo_realized:.2f}/구간'))
    fo4.metric('기준 처리', _locale.code('-' if not _ct_ready_projection_source else f"{_ct_projection_outcome['base_burn_rate']:.2f}/구간"))
    _fo_error = _ct_projection_outcome['base_abs_pct_error']
    fo5.metric('기준 절대값 오류', _locale.code('-' if _fo_error is None else f'{_fo_error:.1%}'))
    fo6.metric('투자 실행 권한', '없음')
    fod1, fod2, fod3, fod4, fod5 = st.columns(5)
    fod1.metric('처리 완료', _locale.code(_ct_projection_outcome['clearance_state']))
    fod2.metric('재보정', _locale.code(_ct_projection_outcome['recalibration_state']))
    fod3.metric('처리 용량 판단', _locale.code(_ct_projection_outcome['capacity_decision_state']))
    fod4.metric('처리 용량 권한', '없음')
    fod5.metric('전망 권한', '없음')
    _fo_state = _ct_projection_outcome['evaluation_state']
    if _fo_state == 'PROJECTION_SOURCE_REQUIRED':
        st.info('전망 결과는 준비 완료 · 대상 · 검토 상태로 저장된 전망 상태 기록부터 추적합니다. 현재 보호 점검이 HOLD_HISTORY라면 정상이며, 이력을 인위적으로 만들거나 보호 점검을 강제로 열지 않습니다.')
    elif _fo_state == 'SOURCE_PROJECTION_INTEGRITY_REVIEW':
        st.error('결과 출처 전망 상태 기록 무결성이 일치하지 않아 평가를 차단했습니다.')
    elif _fo_state == 'EVIDENCE_INTEGRITY_REVIEW':
        st.error('전망 이후 추세 투자 근거 중 무결성 오류가 있어 결과 평가를 차단했습니다.')
    elif _fo_state in {'WAIT_EVIDENCE', 'EVIDENCE_MATURING'}:
        st.info('전망 이후 실제 처리 흐름 투자 근거가 아직 충분하지 않습니다. 대기 목록 변화가 발생할 때 정상 추세 상태 기록을 추가 축적하세요.')
    elif _fo_state == 'ASSUMPTION_DRIFT_REVIEW':
        st.warning('전망 이후 처리 용량 투자 가정이 변경되었습니다. 이를 모형 오류로 단정하지 않고 새 보정/전망으로 기준 재설정해야 합니다.')
    elif _fo_state in {'BASE_CLEARANCE_MISS_REVIEW', 'MODEL_BREAK_REVIEW', 'MODEL_ERROR_REVIEW'}:
        st.warning(f'{_locale.code(_fo_state)} · 예상 대비 실제 처리 흐름 차이가 커졌습니다. 처리 용량을 자동 변경하지 말고 먼저 재보정과 원인 분해를 수행하세요.')
    elif _fo_state in {'WITHIN_REVIEW_BAND', 'CLEARED_REVIEW'}:
        st.success(f'{_locale.code(_fo_state)} · 현재 투자 근거는 설정된 넓은 검토 구간 안에 있습니다. 이는 미래 성능 보장이나 처리 용량 변경 승인이 아닙니다.')
    _fo_table = _ct_projection_outcome['evidence_table']
    if not _fo_table.empty:
        _locale.dataframe(st, _fo_table, width='stretch', hide_index=True)
    if not _ct_projection_outcome_queue.empty:
        with st.expander('전망 결과 검토 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_projection_outcome_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_outcome:
        _fo_latest_integrity = flow_projection_outcome_snapshot_integrity(_ct_latest_projection_outcome)
        st.caption(f"최신 결과 상태 기록 · {_ct_latest_projection_outcome.get('outcome_snapshot_id', '')} · {_locale.code(_ct_latest_projection_outcome.get('evaluation_state', ''))} · 무결성 {_locale.code(_fo_latest_integrity['status'])}")
    _fo_note = st.text_input('처리 흐름 전망 결과 상태 기록 메모', value='', key='operations_flow_projection_outcome_snapshot_note', placeholder='예: 사후-전망 투자 근거 검토 / 금지 자동 처리 용량 행동')
    if st.button('운영 처리 흐름 전망 결과 상태 기록 저장', key='operations_flow_projection_outcome_snapshot_save'):
        if not _ct_projection_outcome['snapshot_eligible']:
            st.warning('결과 상태 기록 저장 보류 · 무결성 정상인 준비 완료 전망과 1개 이상의 유효 사후-전망 추세 투자 근거가 필요합니다.')
        else:
            _fo_row = build_flow_projection_outcome_snapshot(_ct_projection_outcome, note=_fo_note)
            _fo_hist = load_csv('operations_flow_projection_outcome_snapshots.csv')
            for _col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
                if _col not in _fo_hist.columns:
                    _fo_hist[_col] = ''
            _fo_hist = pd.concat([_fo_hist[FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_fo_row])], ignore_index=True)
            verified_save_feedback(_fo_hist, 'operations_flow_projection_outcome_snapshots.csv', f"Projection Outcome Snapshot 저장 · {_fo_row['evaluation_state']} · Evidence {_fo_row['evidence_intervals']} · Capacity Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('결과 오류는 저장 전망 이후 실제 추세 투자 근거와의 차이입니다. 오차가 커도 자동 처리 용량 변경, 자동 재보정, 검토 완료, 투자 주문을 생성하지 않습니다.')
    _ct_projection_outcome_history_for_scorecard = load_csv('operations_flow_projection_outcome_snapshots.csv')
    _ct_scorecard_input = build_flow_scorecard_input_qualification(_ct_projection_outcome_history_for_scorecard, load_csv('operations_flow_projection_outcome_evidence_snapshots.csv'), load_csv('operations_flow_projection_review_snapshots.csv'), load_csv('operations_flow_projection_snapshots.csv'))
    _ct_scorecard_input_queue = build_flow_scorecard_input_queue(_ct_scorecard_input)
    _ct_scorecard_input_history = load_csv('operations_flow_scorecard_input_snapshots.csv')
    _ct_latest_scorecard_input = latest_flow_scorecard_input_snapshot(_ct_scorecard_input_history)
    st.subheader('1J-Q. 평가표 입력 적격성 확인 / 결과 투자 근거 연결 이력 보호 점검')
    sci1, sci2, sci3, sci4, sci5, sci6 = st.columns(6)
    sci1.metric('입력 상태', _locale.code(_ct_scorecard_input['qualification_state']))
    sci2.metric('결과 기록', _locale.code(_ct_scorecard_input['outcome_records_total']))
    sci3.metric('적격 결과', _locale.code(_ct_scorecard_input['qualified_outcomes']))
    sci4.metric('부적격', _locale.code(_ct_scorecard_input['unqualified_outcomes']))
    sci5.metric('평가표 보호 점검', _locale.code(_ct_scorecard_input['scorecard_guard']))
    sci6.metric('투자 실행 권한', '없음')
    scii1, scii2, scii3, scii4 = st.columns(4)
    scii1.metric('준비 완료 투자 근거 검증 기록', _locale.code(_ct_scorecard_input['ready_evidence_audits']))
    scii2.metric('유효하지 않음 결과', _locale.code(_ct_scorecard_input['invalid_outcome_records']))
    scii3.metric('연결 이력 불일치', _locale.code(_ct_scorecard_input['lineage_mismatch_count']))
    scii4.metric('중복 결과', _locale.code(_ct_scorecard_input['duplicate_outcomes']))
    _sci_state = _ct_scorecard_input['qualification_state']
    if _sci_state == 'SCORECARD_INPUT_HISTORY_REQUIRED':
        st.info('평가표 투자 근거 유효기간은 검증된 전망 결과 상태 기록부터 시작합니다. 현재 결과 이력이 없으면 정상이며, 결과 상태 기록을 인위적으로 만들지 않습니다.')
    elif _sci_state == 'SCORECARD_INPUT_EVIDENCE_AUDIT_REQUIRED':
        st.warning('결과 상태 기록은 있으나 일치하는 결과 · 투자 근거 · 준비 완료 검증이 없습니다. 1I-E 결과 투자 근거 검증을 먼저 저장한 뒤 1J 결과 상태 기록을 생성하세요.')
    elif _sci_state in {'SCORECARD_INPUT_INTEGRITY_REVIEW', 'SCORECARD_INPUT_LINEAGE_REVIEW', 'SCORECARD_INPUT_TIME_ORDER_REVIEW', 'SCORECARD_INPUT_UNQUALIFIED_REVIEW'}:
        st.warning(f'{_locale.code(_sci_state)} · 평가표 / 투자 근거 유효기간 입력을 유지합니다. 결과 → 투자 근거 검증 → 검토 고정 → 전망 연결 이력과 저장 순서를 확인하세요.')
    else:
        st.success('평가표 입력 준비 완료 · 사후 판단 왜곡 방지 / 종료된 세션 투자 근거 검증과 연결 이력이 확인된 결과 상태 기록만 투자 근거 유효기간 입력으로 사용합니다.')
    _locale.dataframe(st, _ct_scorecard_input_queue, width='stretch', hide_index=True)
    if _ct_latest_scorecard_input:
        _sci_latest_integrity = flow_scorecard_input_snapshot_integrity(_ct_latest_scorecard_input)
        st.caption(f"최신 평가표 입력 상태 기록 · {_ct_latest_scorecard_input.get('scorecard_input_snapshot_id', '')} · {_locale.code(_ct_latest_scorecard_input.get('qualification_state', ''))} · 무결성 {_locale.code(_sci_latest_integrity['status'])}")
    _sci_note = st.text_input('평가표 입력 적격성 확인 상태 기록 메모', value='', key='operations_flow_scorecard_input_snapshot_note', placeholder='예: 검증된 결과 연결 이력 / 금지 확인 근거-기한 과다 계산')
    if st.button('운영 처리 흐름 평가표 입력 적격성 확인 상태 기록 저장', key='operations_flow_scorecard_input_snapshot_save'):
        _sci_row = build_flow_scorecard_input_snapshot(_ct_scorecard_input, note=_sci_note)
        _sci_hist = load_csv('operations_flow_scorecard_input_snapshots.csv')
        for _col in FLOW_SCORECARD_INPUT_SNAPSHOT_COLS:
            if _col not in _sci_hist.columns:
                _sci_hist[_col] = ''
        _sci_hist = pd.concat([_sci_hist[FLOW_SCORECARD_INPUT_SNAPSHOT_COLS], pd.DataFrame([_sci_row])], ignore_index=True)
        verified_save_feedback(_sci_hist, 'operations_flow_scorecard_input_snapshots.csv', f"Scorecard Input Snapshot 저장 · {_sci_row['qualification_state']} · Qualified {_sci_row['qualified_outcomes']} · Capacity Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('평가표는 결과 상태 기록 개수가 아니라, 저장된 결과 · 투자 근거 · 준비 완료 검증 이후 생성되고 검토/전망/추세 연결 이력이 확인된 결과만 사용합니다. 기존/부적격 결과는 투자 근거 유효기간을 늘리지 않습니다.')
    _ct_projection_outcome_history_for_scorecard = _ct_scorecard_input['qualified_outcome_history']
    _ct_projection_scorecard = build_flow_projection_scorecard(_ct_projection_outcome_history_for_scorecard, min_outcome_evidence_intervals=2, proof_clock_target=3, broad_error_threshold=0.5, override_review_ttl_intervals=2)
    _ct_projection_scorecard_queue = build_flow_projection_scorecard_queue(_ct_projection_scorecard)
    _ct_projection_scorecard_history = load_csv('operations_flow_projection_scorecard_snapshots.csv')
    _ct_latest_projection_scorecard = latest_flow_projection_scorecard_snapshot(_ct_projection_scorecard_history)
    st.subheader('1K. 전망 평가표 / 재보정 투자 근거 유효기간 / 처리 용량 예외 승인 점검')
    fs1, fs2, fs3, fs4, fs5, fs6 = st.columns(6)
    fs1.metric('평가표 상태', _locale.code(_ct_projection_scorecard['scorecard_state']))
    fs2.metric('오류 시장 국면', _locale.code(_ct_projection_scorecard['error_regime']))
    fs3.metric('투자 근거 유효기간', f"{_ct_projection_scorecard['proof_clock_count']}/{_ct_projection_scorecard['proof_clock_target']}")
    fs4.metric('예외 승인 검토 점검', _locale.code(_ct_projection_scorecard['capacity_override_review_gate']))
    fs5.metric('예외 승인 승인', _locale.code(_ct_projection_scorecard['override_review_approval_state']))
    fs6.metric('투자 실행 권한', '없음')
    fss1, fss2, fss3, fss4, fss5 = st.columns(5)
    fss1.metric('고유 투자 근거', _locale.code(_ct_projection_scorecard['unique_evidence_endpoints']))
    _fsc_avg_err = _ct_projection_scorecard['avg_abs_pct_error']
    fss2.metric('평균 절대값 오류', _locale.code('-' if _fsc_avg_err is None else f'{_fsc_avg_err:.1%}'))
    _fsc_latest_err = _ct_projection_scorecard['latest_abs_pct_error']
    fss3.metric('최신 절대값 오류', _locale.code('-' if _fsc_latest_err is None else f'{_fsc_latest_err:.1%}'))
    fss4.metric('처리 용량 예외 승인 권한', '없음')
    fss5.metric('전망 권한', '없음')
    _fsc_state = _ct_projection_scorecard['scorecard_state']
    _fsc_gate = _ct_projection_scorecard['capacity_override_review_gate']
    if _fsc_state == 'SCORECARD_HISTORY_REQUIRED':
        st.info('평가표는 저장된 전망 결과 상태 기록부터 시작합니다. 현재 유지 · 이력 / 전망 출처 없음 상태라면 정상입니다. 중복 저장이나 임의 이력 생성으로 투자 근거 유효기간을 늘리지 않습니다.')
    elif _fsc_state == 'OUTCOME_INTEGRITY_REVIEW':
        st.error('결과 상태 기록 무결성 오류가 있어 평가표 / 예외 승인 검토를 차단했습니다.')
    elif _fsc_state == 'SCORECARD_EVIDENCE_MATURING':
        st.info('평가표 투자 근거가 아직 성숙하지 않았습니다. 새로운 실제 투자 근거 연결 주소가 생성될 때만 투자 근거 유효기간을 평가합니다.')
    elif _fsc_state == 'REBASE_REQUIRED':
        st.warning('처리 용량 투자 가정 기준 이탈이 확인되어 기존 전망의 모형 오류로 단정할 수 없습니다. 새 보정/전망으로 기준 재설정한 뒤 투자 근거 유효기간을 다시 시작합니다.')
    elif _fsc_state == 'RECALIBRATION_PROOF_MATURING':
        st.warning('재보정 반대가설을 검토할 투자 근거가 축적 중입니다. 투자 근거 유효기간은 고유 투자 근거 연결 주소만 계산합니다.')
    elif _fsc_state == 'RECALIBRATION_PROOF_MET':
        st.warning('재보정 투자 근거 유효기간이 기준에 도달했습니다. 이는 처리 용량 변경 승인이 아니라 모형/매개변수/실행/외부 요인 원인 분해를 시작할 조건입니다.')
    else:
        st.success('현재 평가표는 점검 상태입니다. 추가 투자 근거를 축적하며 자동 처리 용량 변경은 하지 않습니다.')
    if _fsc_gate == 'OPEN_FOR_HUMAN_REVIEW':
        st.warning(f"처리 용량 예외 승인 검토 점검이 사용자 검토에 열렸습니다. 승인 필요 · 투자 근거 {_ct_projection_scorecard['override_review_expires_after_evidence']} 이후에는 재검토가 필요합니다. 처리 용량 예외 승인 권한은 여전히 없음입니다.")
    _fsc_table = _ct_projection_scorecard['scorecard_table']
    if not _fsc_table.empty:
        with st.expander('전망 평가표 투자 근거', expanded=False):
            _locale.dataframe(st, _fsc_table, width='stretch', hide_index=True)
    if not _ct_projection_scorecard_queue.empty:
        with st.expander('전망 평가표 / 예외 승인 검토 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_projection_scorecard_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_scorecard:
        _fsc_latest_integrity = flow_projection_scorecard_snapshot_integrity(_ct_latest_projection_scorecard)
        st.caption(f"최신 평가표 상태 기록 · {_ct_latest_projection_scorecard.get('scorecard_snapshot_id', '')} · {_locale.code(_ct_latest_projection_scorecard.get('scorecard_state', ''))} · 무결성 {_locale.code(_fsc_latest_integrity['status'])}")
    _fsc_note = st.text_input('처리 흐름 전망 평가표 상태 기록 메모', value='', key='operations_flow_projection_scorecard_snapshot_note', placeholder='예: 투자 근거 유효기간 검토 / 금지 처리 용량 예외 승인 권한')
    if st.button('운영 처리 흐름 전망 평가표 상태 기록 저장', key='operations_flow_projection_scorecard_snapshot_save'):
        if not _ct_projection_scorecard['snapshot_eligible']:
            st.warning('평가표 상태 기록 저장 보류 · 무결성 정상인 결과 상태 기록 이력이 필요합니다.')
        else:
            _fsc_row = build_flow_projection_scorecard_snapshot(_ct_projection_scorecard, note=_fsc_note)
            _fsc_hist = load_csv('operations_flow_projection_scorecard_snapshots.csv')
            for _col in FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS:
                if _col not in _fsc_hist.columns:
                    _fsc_hist[_col] = ''
            _fsc_hist = pd.concat([_fsc_hist[FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS], pd.DataFrame([_fsc_row])], ignore_index=True)
            verified_save_feedback(_fsc_hist, 'operations_flow_projection_scorecard_snapshots.csv', f"Projection Scorecard Snapshot 저장 · {_fsc_row['scorecard_state']} · Proof {_fsc_row['proof_clock_count']}/{_fsc_row['proof_clock_target']} · Capacity Override Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('투자 근거 유효기간은 같은 투자 근거 연결 주소를 중복 저장해도 증가하지 않습니다. 예외 승인 검토 점검이 열려도 사용자 승인/만료/재보정 검토가 필요하며 처리 용량 예외 승인 권한과 투자 실행 승인은 자동 생성되지 않습니다.')
    _ct_recalibration_review_history = load_csv('operations_flow_recalibration_review_snapshots.csv')
    _ct_recalibration_review = build_flow_recalibration_review(_ct_projection_scorecard, _ct_latest_projection_scorecard, _ct_recalibration_review_history)
    _ct_recalibration_review_queue = build_flow_recalibration_review_queue(_ct_recalibration_review)
    st.subheader('1K-R. 재보정 오류 원인 분석 / 사용자 검토 기준 계약')
    rr1, rr2, rr3, rr4, rr5, rr6 = st.columns(6)
    rr1.metric('재보정 상태', _locale.code(_ct_recalibration_review['review_state']))
    rr2.metric('평가표 출처', _locale.code(_ct_recalibration_review['source_scorecard_freshness']))
    rr3.metric('오류 시장 국면', _locale.code(_ct_recalibration_review['error_regime'] or '-'))
    rr4.metric('투자 근거 유효기간', f"{_ct_recalibration_review['proof_clock_count']}/{_ct_recalibration_review['proof_clock_target']}")
    rr5.metric('검토 보호 점검', _locale.code(_ct_recalibration_review['review_guard']))
    rr6.metric('투자 실행 권한', '없음')
    _rr_state = _ct_recalibration_review['review_state']
    if _rr_state == 'RECALIBRATION_UPSTREAM_WAIT':
        st.info('재보정 검토는 적격 결과와 투자 근거 유효기간이 충분히 쌓인 뒤 시작합니다. 현재 단계에서는 평가표 상태 기록이나 원인 분석 기준 계약을 억지로 만들 필요가 없습니다.')
    elif _rr_state == 'RECALIBRATION_NOT_REQUIRED':
        st.success('현재 평가표는 점검 상태입니다. 자동 재보정 없이 추가 투자 근거를 관찰합니다.')
    elif _rr_state == 'RECALIBRATION_REBASE_FIRST':
        st.warning('처리 용량 투자 가정 기준 이탈이 먼저 확인되었습니다. 모형 오류로 단정하지 말고 새 보정/전망으로 기준 재설정한 뒤 새 투자 근거 기한을 시작하세요.')
    elif _rr_state == 'RECALIBRATION_PROOF_MATURING':
        st.info('재보정 투자 근거 유효기간이 아직 성숙 중입니다. 같은 연결 주소의 중복 저장으로 기한을 늘리지 않습니다.')
    elif _rr_state == 'RECALIBRATION_SCORECARD_SOURCE_REQUIRED':
        st.warning('투자 근거 유효기간이 기준에 도달했습니다. 원인 분해 전 1K에서 현재 평가표 상태 기록을 저장하세요.')
    elif _rr_state in {'RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW', 'RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW', 'RECALIBRATION_CONTRACT_INTEGRITY_REVIEW'}:
        st.error(f'{_locale.code(_rr_state)} · 평가표 / 재보정 검토 검증 출처를 먼저 복구해야 합니다.')
    elif _rr_state == 'RECALIBRATION_CONTRACT_SUPERSEDED':
        st.warning('새 평가표 출처가 생성되어 이전 재보정 기준 계약이 대체됨되었습니다. 새 평가표 기준으로 원인 분해를 다시 검토하세요.')
    elif _rr_state == 'RECALIBRATION_CONTRACT_LOCKED':
        _rr_contract = _ct_recalibration_review.get('latest_contract') or {}
        st.success(f"재보정 기준 계약 고정됨 · 공식 원문 {_rr_contract.get('primary_attribution', '')} · 자동 매개변수 변경/처리 용량 변경/투자 실행 승인은 생성되지 않았습니다.")
    else:
        st.warning('재보정 확인 근거가 기준에 도달했습니다. 모형 / 매개변수 / 실행 / 외부 요인 원인을 독립적으로 검토한 뒤 사용자 기준 계약을 저장하세요.')
    if not _ct_recalibration_review_queue.empty:
        with st.expander('재보정 검토 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_recalibration_review_queue, width='stretch', hide_index=True)
    if _rr_state == 'RECALIBRATION_ATTRIBUTION_REQUIRED':
        _rr_primary = st.selectbox('공식 원문 오류 원인 분석', ['MODEL', 'PARAMETER', 'EXECUTION', 'EXOGENOUS'], key='flow_recalibration_primary_attribution', format_func=_locale.option())
        _rr_secondary = st.selectbox('보조 오류 원인 분석 (선택)', ['', 'MODEL', 'PARAMETER', 'EXECUTION', 'EXOGENOUS'], key='flow_recalibration_secondary_attribution', format_func=_locale.option())
        _rr_detail = st.text_area('원인 분석 근거', value='', key='flow_recalibration_attribution_detail', placeholder='예: 지속적 낙관적 편향이 매개변수 잘못된 설정인지 실행 효과인지 구분한 근거')
        rrc1, rrc2 = st.columns(2)
        with rrc1:
            _rr_source_confirm = st.checkbox('현재 평가표 출처 식별번호/무결성 해시/현재를 직접 확인했습니다.', key='flow_recalibration_source_confirmed')
            _rr_alt_confirm = st.checkbox('모형 / 매개변수 / 실행 / 외부 요인 반대 원인을 모두 검토했습니다.', key='flow_recalibration_alternatives_reviewed')
            _rr_no_auto_recal = st.checkbox('이 기준 계약이 자동 재보정이나 매개변수 변경을 승인하지 않음을 확인했습니다.', key='flow_recalibration_no_auto_recalibration')
        with rrc2:
            _rr_no_capacity = st.checkbox('원인 원인 분석만으로 처리 용량을 자동 확대/축소하지 않음을 확인했습니다.', key='flow_recalibration_no_auto_capacity')
            _rr_no_exec = st.checkbox('투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='flow_recalibration_no_execution')
            _rr_human = st.checkbox('현재 재보정 원인 분해를 최종 사용자 검토했습니다.', key='flow_recalibration_human_review')
        _rr_note = st.text_input('재보정 검토 메모', value='', key='flow_recalibration_review_note', placeholder='예: 근본 원인 원인 분석 고정됨 / 금지 자동 모형 변경')
        if st.button('재보정 사용자 검토 기준 계약 저장', key='flow_recalibration_review_save'):
            try:
                _rr_row = build_flow_recalibration_review_lock(_ct_recalibration_review, primary_attribution=_rr_primary, secondary_attribution=_rr_secondary, attribution_detail=_rr_detail, source_review_confirmed=_rr_source_confirm, alternatives_reviewed=_rr_alt_confirm, no_auto_recalibration_confirmed=_rr_no_auto_recal, no_auto_capacity_confirmed=_rr_no_capacity, no_execution_authorization_confirmed=_rr_no_exec, human_review_confirmed=_rr_human, note=_rr_note)
                _rr_hist = load_csv('operations_flow_recalibration_review_snapshots.csv')
                for _col in FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS:
                    if _col not in _rr_hist.columns:
                        _rr_hist[_col] = ''
                _rr_hist = pd.concat([_rr_hist[FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS], pd.DataFrame([_rr_row])], ignore_index=True)
                verified_save_feedback(_rr_hist, 'operations_flow_recalibration_review_snapshots.csv', f"Recalibration Contract 저장 · {_rr_row['primary_attribution']} · Recalibration Authorization = NONE · Capacity Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('예측 오차는 모형 / 매개변수 / 실행 / 외부 요인으로 분해합니다. 기준 계약은 원인 원인 분석을 잠글 뿐 자동 모형 변경, 처리 용량 변경, 투자 실행을 승인하지 않습니다.')
    _ct_recalibration_proposal_history = load_csv('operations_flow_recalibration_proposal_snapshots.csv')
    _ct_recalibration_proposal = build_flow_recalibration_proposal(_ct_recalibration_review, _ct_latest_projection_scorecard, _ct_recalibration_proposal_history, max_parameter_delta_pct=0.5)
    _ct_recalibration_proposal_queue = build_flow_recalibration_proposal_queue(_ct_recalibration_proposal)
    _ct_latest_recalibration_proposal = latest_recalibration_proposal_snapshot(_ct_recalibration_proposal_history)
    st.subheader('1K-P. 재보정 제안 / 변경 범위 / 적용 금지 보호 점검')
    rp1, rp2, rp3, rp4, rp5, rp6 = st.columns(6)
    rp1.metric('제안 상태', _locale.code(_ct_recalibration_proposal['proposal_state']))
    rp2.metric('공식 원문 원인 분석', _locale.code(_ct_recalibration_proposal['primary_attribution'] or '-'))
    rp3.metric('제안 범위', _locale.code(_ct_recalibration_proposal['proposal_scope'] or '-'))
    rp4.metric('제안 보호 점검', _locale.code(_ct_recalibration_proposal['proposal_guard']))
    rp5.metric('재보정 권한', '없음')
    rp6.metric('투자 실행 권한', '없음')
    _rp_state = _ct_recalibration_proposal['proposal_state']
    if _rp_state == 'RECALIBRATION_PROPOSAL_UPSTREAM_WAIT':
        st.info('재보정 제안은 투자 근거 유효기간과 사용자 원인 분석 기준 계약이 잠긴 뒤 시작합니다. 현재 단계에서는 제안을 억지로 만들 필요가 없습니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_NOT_REQUIRED':
        st.success('현재 재보정 제안이 필요하지 않습니다. 운영 모형/매개변수를 변경하지 않고 투자 근거를 계속 관찰합니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_REBASE_FIRST':
        st.warning('처리 용량 투자 가정 기준 이탈이 우선입니다. 모형/매개변수 제안보다 새 보정/전망 기준 재설정이 먼저입니다.')
    elif _rp_state == 'RECALIBRATION_EXECUTION_REMEDIATION_ONLY':
        st.warning('공식 원문 원인 분석이 실행입니다. 모형/매개변수 변경 제안 대신 실행 절차 개선 조치를 검토하세요.')
    elif _rp_state == 'RECALIBRATION_EXOGENOUS_OBSERVE_ONLY':
        st.info('공식 원문 원인 분석이 외부 요인입니다. 모형/매개변수 변경보다 시장 국면 정상화와 추가 투자 근거를 관찰합니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW':
        st.error('재보정 기준 계약 / 평가표 / 제안 검증 무결성이 일치하지 않아 제안을 차단했습니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_SUPERSEDED':
        st.warning('새 재보정 기준 계약이 생성되어 이전 제안이 대체됨되었습니다. 현재 기준 계약 기준으로 다시 검토하세요.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_LOCKED':
        _rp_locked = _ct_recalibration_proposal.get('latest_proposal') or {}
        st.success(f"격리 모의 전용 재보정 제안 고정됨 · {_rp_locked.get('proposal_scope', '')} · 운영 모형/매개변수 변경, 처리 용량 변경, 투자 실행 승인은 생성되지 않았습니다.")
    elif _rp_state == 'RECALIBRATION_PARAMETER_DELTA_REQUIRED':
        st.warning(f"매개변수 원인 분석 · 현재 기준 · 처리 · 비율 {_ct_recalibration_proposal['current_value']:.4f}. 실전 값을 바꾸지 않는 범위 제한 격리 모의 제안만 허용됩니다.")
    else:
        st.warning('모형 원인 분석 · 운영 모형을 직접 변경하지 않고 격리 모의 모형 명세 제안을 먼저 잠급니다.')
    if not _ct_recalibration_proposal_queue.empty:
        with st.expander('재보정 제안 대기 목록', expanded=False):
            _locale.dataframe(st, _ct_recalibration_proposal_queue, width='stretch', hide_index=True)
    if _ct_latest_recalibration_proposal:
        _rp_latest_integrity = recalibration_proposal_snapshot_integrity(_ct_latest_recalibration_proposal)
        st.caption(f"최신 제안 · {_ct_latest_recalibration_proposal.get('recalibration_proposal_id', '')} · {_ct_latest_recalibration_proposal.get('proposal_scope', '')} · 무결성 {_locale.code(_rp_latest_integrity['status'])}")
    if _rp_state in {'RECALIBRATION_PARAMETER_DELTA_REQUIRED', 'RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED'}:
        if _rp_state == 'RECALIBRATION_PARAMETER_DELTA_REQUIRED':
            _rp_proposed_value = st.number_input('격리 모의 제안된 기준 · 처리 · 비율', min_value=0.0001, value=max(0.0001, float(_ct_recalibration_proposal['current_value'])), step=0.01, key='flow_recalibration_proposal_value')
        else:
            _rp_proposed_value = None
        _rp_detail = st.text_area('재보정 제안 근거', value='', key='flow_recalibration_proposal_detail', placeholder='예: 격리 모의 전용 매개변수/모형 명세 제안 · 운영 매개변수에는 적용하지 않고 다음 검증 단계에서만 검증')
        rpc1, rpc2 = st.columns(2)
        with rpc1:
            _rp_shadow = st.checkbox('이 제안은 격리 모의 전용이며 운영 모형에 적용되지 않음을 확인했습니다.', key='flow_recalibration_proposal_shadow_only')
            _rp_no_live = st.checkbox('이 제안이 운영 모형/매개변수를 자동 변경하지 않음을 확인했습니다.', key='flow_recalibration_proposal_no_live_change')
            _rp_no_capacity = st.checkbox('이 제안만으로 처리 용량을 자동 확대/축소하지 않음을 확인했습니다.', key='flow_recalibration_proposal_no_capacity')
        with rpc2:
            _rp_no_exec = st.checkbox('투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='flow_recalibration_proposal_no_execution')
            _rp_human = st.checkbox('현재 제안 범위/값/근거를 최종 사용자 검토했습니다.', key='flow_recalibration_proposal_human_review')
        _rp_note = st.text_input('재보정 제안 메모', value='', key='flow_recalibration_proposal_note', placeholder='예: 격리 모의 제안 고정됨 / 금지 실전 적용')
        if st.button('재보정 격리 모의 제안 저장', key='flow_recalibration_proposal_save'):
            try:
                _rp_row = build_flow_recalibration_proposal_lock(_ct_recalibration_proposal, proposed_value=_rp_proposed_value, proposal_detail=_rp_detail, shadow_only_confirmed=_rp_shadow, no_live_parameter_change_confirmed=_rp_no_live, no_auto_capacity_confirmed=_rp_no_capacity, no_execution_authorization_confirmed=_rp_no_exec, human_review_confirmed=_rp_human, note=_rp_note)
                _rp_hist = load_csv('operations_flow_recalibration_proposal_snapshots.csv')
                for _col in FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS:
                    if _col not in _rp_hist.columns:
                        _rp_hist[_col] = ''
                _rp_hist = pd.concat([_rp_hist[FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS], pd.DataFrame([_rp_row])], ignore_index=True)
                verified_save_feedback(_rp_hist, 'operations_flow_recalibration_proposal_snapshots.csv', f"Recalibration Shadow Proposal 저장 · {_rp_row['proposal_scope']} · Proposal Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('재보정 제안은 원인 분석을 실제 변경안으로 바로 적용하지 않습니다. 모형/매개변수는 격리 모의 전용 제안으로 잠그고, 실행/외부 요인은 모형 변경을 허용하지 않습니다.')
    _ct_shadow_validation_plan_history = load_csv('operations_flow_shadow_validation_plan_snapshots.csv')
    _ct_shadow_validation_plan = build_flow_shadow_validation_plan(_ct_recalibration_proposal, _ct_shadow_validation_plan_history, default_min_future_outcomes=3, default_min_future_closed_intervals=2, default_min_relative_error_improvement_pct=0.15, default_max_relative_error_degradation_pct=0.1)
    _ct_shadow_validation_plan_queue = build_flow_shadow_validation_plan_queue(_ct_shadow_validation_plan)
    _ct_latest_shadow_validation_plan = latest_shadow_validation_plan_snapshot(_ct_shadow_validation_plan_history)
    st.subheader('1K-S. 격리 모의 검증 사전 등록 / 검증 전용 표본 적용 금지 보호 점검')
    sv1, sv2, sv3, sv4, sv5, sv6 = st.columns(6)
    sv1.metric('검증 상태', _locale.code(_ct_shadow_validation_plan['plan_state']))
    sv2.metric('제안 범위', _locale.code(_ct_shadow_validation_plan['proposal_scope'] or '-'))
    sv3.metric('평가 지표', _locale.code(_ct_shadow_validation_plan['evaluation_metric'] or '-'))
    sv4.metric('미래 결과', _locale.code(_ct_shadow_validation_plan['min_future_outcomes']))
    sv5.metric('계획 보호 점검', _locale.code(_ct_shadow_validation_plan['plan_guard']))
    sv6.metric('투자 실행 권한', '없음')
    _sv_state = _ct_shadow_validation_plan['plan_state']
    if _sv_state == 'SHADOW_VALIDATION_UPSTREAM_WAIT':
        st.info('격리 모의 검증 계획은 고정됨 재보정 제안이 생긴 뒤 시작합니다. 현재 단계에서는 계획을 억지로 만들 필요가 없습니다.')
    elif _sv_state == 'SHADOW_VALIDATION_NOT_REQUIRED':
        st.success('현재 원인 분석은 격리 모의 모형/매개변수 검증이 필요하지 않습니다. 운영 모형/매개변수는 변경하지 않고 투자 근거를 계속 관찰합니다.')
    elif _sv_state == 'SHADOW_VALIDATION_PROPOSAL_REQUIRED':
        st.info('모형/매개변수 제안이 아직 고정됨되지 않았습니다. 검증 기준을 정하기 전에 격리 모의 전용 제안 사용자 검토를 완료하세요.')
    elif _sv_state == 'SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW':
        st.error('재보정 제안 또는 격리 모의 검증 계획 검증 무결성이 일치하지 않아 검증을 차단했습니다.')
    elif _sv_state == 'SHADOW_VALIDATION_PLAN_SUPERSEDED':
        st.warning('새 재보정 제안이 생성되어 기존 검증 계획이 대체됨되었습니다. 현재 제안 기준으로 성공/실패 기준을 다시 사전등록하세요.')
    elif _sv_state == 'SHADOW_VALIDATION_PLAN_LOCKED':
        _sv_locked = _ct_shadow_validation_plan.get('latest_plan') or {}
        st.success(f"격리 모의 검증 계획 고정됨 · 미래 결과 {_sv_locked.get('min_future_outcomes', 0)} · 최소 개선 {float(_sv_locked.get('min_relative_error_improvement_pct', 0)):.0%} · 실전 적용 없음.")
    else:
        st.warning('격리 모의 검증 계획이 필요합니다. 미래 투자 근거가 생기기 전에 성공/실패 기준을 먼저 잠그세요.')
    _locale.dataframe(st, _ct_shadow_validation_plan_queue, width='stretch', hide_index=True)
    if _ct_latest_shadow_validation_plan:
        _sv_latest_integrity = shadow_validation_plan_snapshot_integrity(_ct_latest_shadow_validation_plan)
        st.caption(f"최신 격리 모의 검증 계획 · {_ct_latest_shadow_validation_plan.get('shadow_validation_plan_id', '')} · {_locale.code(_ct_latest_shadow_validation_plan.get('plan_state', ''))} · 무결성 {_locale.code(_sv_latest_integrity['status'])}")
    if _sv_state == 'SHADOW_VALIDATION_PLAN_REQUIRED':
        _sv_min_outcomes = st.number_input('격리 모의 검증 최소 미래 적격 결과', min_value=3, max_value=20, value=3, step=1, key='shadow_validation_min_future_outcomes')
        _sv_min_intervals = st.number_input('격리 모의 검증 최소 미래 종료된 세션 구간', min_value=2, max_value=20, value=2, step=1, key='shadow_validation_min_future_intervals')
        _sv_min_improvement = st.number_input('최소 상대 오류 개선율', min_value=0.0, max_value=0.5, value=0.15, step=0.05, format='%.2f', key='shadow_validation_min_improvement')
        _sv_max_degradation = st.number_input('허용 상대 오류 악화율', min_value=0.0, max_value=0.25, value=0.1, step=0.05, format='%.2f', key='shadow_validation_max_degradation')
        _sv_detail = st.text_area('격리 모의 검증 계획 상세', value='', key='shadow_validation_plan_detail', placeholder='예: 미래 종료된 세션 적격 결과만 사용하고 기준 상태 대비 오류 reduction을 검증 전용 표본으로 검증')
        _sv_c1 = st.checkbox('미래 투자 근거를 보기 전에 성공/실패 기준을 사전등록했음을 확인', key='shadow_validation_preregistration_confirmed')
        _sv_c2 = st.checkbox('이 계획은 격리 모의 전용이며 운영 모형/매개변수에 적용하지 않음을 확인', key='shadow_validation_shadow_only_confirmed')
        _sv_c3 = st.checkbox('검증 결과가 나와도 자동 실전 적용이 없음을 확인', key='shadow_validation_no_live_apply_confirmed')
        _sv_c4 = st.checkbox('이 계획이 자동 처리 용량 변경을 승인하지 않음을 확인', key='shadow_validation_no_capacity_confirmed')
        _sv_c5 = st.checkbox('이 계획이 투자 실행/주문 권한을 생성하지 않음을 확인', key='shadow_validation_no_execution_confirmed')
        _sv_c6 = st.checkbox('현재 검증 계획을 최종 사용자 검토했음을 확인', key='shadow_validation_human_review_confirmed')
        _sv_note = st.text_input('격리 모의 검증 계획 상태 기록 메모', value='', key='shadow_validation_plan_note', placeholder='예: 사전 등록됨 검증 전용 표본 검증 / 금지 실전 적용')
        if st.button('운영 처리 흐름 격리 모의 검증 계획 저장', key='shadow_validation_plan_save'):
            try:
                _sv_row = build_flow_shadow_validation_plan_lock(_ct_shadow_validation_plan, plan_detail=_sv_detail, min_future_outcomes=int(_sv_min_outcomes), min_future_closed_intervals=int(_sv_min_intervals), min_relative_error_improvement_pct=float(_sv_min_improvement), max_relative_error_degradation_pct=float(_sv_max_degradation), require_same_capacity=True, require_no_assumption_drift=True, preregistration_confirmed=_sv_c1, shadow_only_confirmed=_sv_c2, no_live_apply_confirmed=_sv_c3, no_auto_capacity_confirmed=_sv_c4, no_execution_authorization_confirmed=_sv_c5, human_review_confirmed=_sv_c6, note=_sv_note)
                _sv_hist = load_csv('operations_flow_shadow_validation_plan_snapshots.csv')
                for _col in FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS:
                    if _col not in _sv_hist.columns:
                        _sv_hist[_col] = ''
                _sv_hist = pd.concat([_sv_hist[FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS], pd.DataFrame([_sv_row])], ignore_index=True)
                verified_save_feedback(_sv_hist, 'operations_flow_shadow_validation_plan_snapshots.csv', f"Shadow Validation Plan 저장 · {_sv_row['proposal_scope']} · future outcomes {_sv_row['min_future_outcomes']} · Plan Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('격리 모의 검증 계획은 제안이 고정됨된 뒤 미래 투자 근거를 보기 전에 성공/실패 기준을 사전등록합니다. 계획 고정됨은 운영 모형/매개변수 적용 승인이 아닙니다.')
    _ct_shadow_validation_outcome = build_flow_shadow_validation_outcome(_ct_shadow_validation_plan, _ct_recalibration_proposal, _ct_projection_scorecard_history, _ct_scorecard_input['qualified_outcome_history'])
    _ct_shadow_validation_outcome_queue = build_flow_shadow_validation_outcome_queue(_ct_shadow_validation_outcome)
    _ct_shadow_validation_outcome_history = load_csv('operations_flow_shadow_validation_outcome_snapshots.csv')
    _ct_latest_shadow_validation_outcome = latest_shadow_validation_outcome_snapshot(_ct_shadow_validation_outcome_history)
    st.subheader('1K-V. 격리 모의 검증 결과 / 검증 전용 표본 투자 근거 / 승격 금지 보호 점검')
    svo1, svo2, svo3, svo4, svo5, svo6 = st.columns(6)
    svo1.metric('평가 상태', _locale.code(_ct_shadow_validation_outcome['validation_state']))
    svo2.metric('범위', _locale.code(_ct_shadow_validation_outcome['proposal_scope'] or '-'))
    svo3.metric('적격 결과', f"{_ct_shadow_validation_outcome['eligible_outcomes']}/{_ct_shadow_validation_outcome['required_future_outcomes']}")
    svo4.metric('기준 상태 절대값 오류', _locale.code('-' if _ct_shadow_validation_outcome['eligible_outcomes'] == 0 else f"{_ct_shadow_validation_outcome['baseline_mean_abs_error']:.4f}"))
    svo5.metric('격리 모의 절대값 오류', _locale.code('-' if _ct_shadow_validation_outcome['eligible_outcomes'] == 0 else f"{_ct_shadow_validation_outcome['shadow_mean_abs_error']:.4f}"))
    svo6.metric('투자 실행 권한', '없음')
    svoa1, svoa2, svoa3, svoa4, svoa5 = st.columns(5)
    svoa1.metric('상대 개선', _locale.code('-' if _ct_shadow_validation_outcome['eligible_outcomes'] < _ct_shadow_validation_outcome['required_future_outcomes'] else f"{_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}"))
    svoa2.metric('투자 가정 기준 이탈', _locale.code(_ct_shadow_validation_outcome['assumption_drift_outcomes']))
    svoa3.metric('기준 상태 기준 이탈', _locale.code(_ct_shadow_validation_outcome['baseline_drift_outcomes']))
    svoa4.metric('중복', _locale.code(_ct_shadow_validation_outcome['duplicate_outcomes']))
    svoa5.metric('검증 보호 점검', _locale.code(_ct_shadow_validation_outcome['validation_guard']))
    _svo_state = _ct_shadow_validation_outcome['validation_state']
    if _svo_state == 'SHADOW_EVAL_UPSTREAM_WAIT':
        st.info('격리 모의 검증 전용 표본 평가는 고정됨 검증 계획이 생긴 뒤 시작합니다. 현재 단계에서는 결과를 억지로 만들 필요가 없습니다.')
    elif _svo_state == 'SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED':
        st.warning('MODEL_SHADOW은 현재 문장 명세만 존재하므로 정량 대안 가정을 계산하지 않습니다. 실행 가능한 격리 모의 평가 도구가 별도로 정의되기 전 성능 결론을 내리지 않습니다.')
    elif _svo_state in {'SHADOW_EVAL_WAIT_FUTURE_OUTCOMES', 'SHADOW_EVAL_EVIDENCE_MATURING'}:
        st.info('사전등록된 계획 이후의 새 전망/검토/종료된 세션 적격 결과만 검증 전용 표본 투자 근거로 축적합니다.')
    elif _svo_state in {'SHADOW_EVAL_PLAN_INTEGRITY_REVIEW', 'SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW', 'SHADOW_EVAL_SCORECARD_SOURCE_REVIEW', 'SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW'}:
        st.error('격리 모의 검증 출처/투자 근거 무결성이 일치하지 않아 평가를 차단했습니다.')
    elif _svo_state in {'SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW', 'SHADOW_EVAL_BASELINE_DRIFT_REVIEW'}:
        st.warning('사전등록된 비교 결과 조건이 깨졌습니다. 처리 용량/기준 상태 기준 이탈을 건너뛰어 결과를 합치지 않습니다.')
    elif _svo_state == 'SHADOW_EVAL_PASS':
        st.success(f"격리 모의 검증 정상 · 상대 오류 개선 {_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}. 정상은 실전 적용/재보정 승인이 아니며 별도 채택 점검이 필요합니다.")
    elif _svo_state == 'SHADOW_EVAL_FAIL':
        st.warning(f"격리 모의 검증 실패 · 상대 오류 개선 {_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}. 실전 적용 없이 제안을 폐기/재검토합니다.")
    elif _svo_state == 'SHADOW_EVAL_INCONCLUSIVE':
        st.info(f"격리 모의 검증 결론 불충분 · 상대 오류 개선 {_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}. 결과를 본 뒤 기준을 바꾸지 않습니다.")
    else:
        st.info('현재 제안 범위에는 정량 격리 모의 평가가 필요하지 않습니다.')
    _locale.dataframe(st, _ct_shadow_validation_outcome_queue, width='stretch', hide_index=True)
    if not _ct_shadow_validation_outcome['evidence_table'].empty:
        with st.expander('격리 모의 검증 검증 전용 표본 투자 근거', expanded=False):
            _locale.dataframe(st, _ct_shadow_validation_outcome['evidence_table'], width='stretch', hide_index=True)
    if _ct_latest_shadow_validation_outcome:
        _svo_latest_integrity = shadow_validation_outcome_snapshot_integrity(_ct_latest_shadow_validation_outcome)
        st.caption(f"최신 격리 모의 검증 결과 · {_ct_latest_shadow_validation_outcome.get('shadow_validation_outcome_id', '')} · {_locale.code(_ct_latest_shadow_validation_outcome.get('validation_state', ''))} · 무결성 {_locale.code(_svo_latest_integrity['status'])}")
    _svo_note = st.text_input('격리 모의 검증 결과 상태 기록 메모', value='', key='shadow_validation_outcome_note', placeholder='예: 사전 검증 전용 표본 검증 / 금지 실전 승격')
    if st.button('운영 처리 흐름 격리 모의 검증 결과 상태 기록 저장', key='shadow_validation_outcome_save'):
        _svo_row = build_flow_shadow_validation_outcome_snapshot(_ct_shadow_validation_outcome, note=_svo_note)
        _svo_hist = load_csv('operations_flow_shadow_validation_outcome_snapshots.csv')
        for _col in FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS:
            if _col not in _svo_hist.columns:
                _svo_hist[_col] = ''
        _svo_hist = pd.concat([_svo_hist[FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_svo_row])], ignore_index=True)
        verified_save_feedback(_svo_hist, 'operations_flow_shadow_validation_outcome_snapshots.csv', f"Shadow Validation Outcome 저장 · {_svo_row['validation_state']} · Eligible {_svo_row['eligible_outcomes']} · Validation Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('격리 모의 검증은 검증 계획 이후 생성된 미래 전망의 검증된 결과만 사용합니다. 정상도 운영 모형/매개변수 적용, 재보정, 처리 용량 변경, 투자 실행을 승인하지 않습니다.')
    _ct_shadow_adoption_review_history = load_csv('operations_flow_shadow_adoption_review_snapshots.csv')
    _ct_shadow_adoption_review = build_flow_shadow_adoption_review(_ct_shadow_validation_outcome, _ct_shadow_validation_outcome_history, _ct_shadow_adoption_review_history)
    _ct_shadow_adoption_queue = build_flow_shadow_adoption_queue(_ct_shadow_adoption_review)
    _ct_latest_shadow_adoption_review = latest_shadow_adoption_review_snapshot(_ct_shadow_adoption_review_history)
    st.subheader('1K-W. 격리 모의 검증 채택 / 사용자 판단 / 운영 적용 금지 보호 점검')
    sar1, sar2, sar3, sar4, sar5, sar6 = st.columns(6)
    sar1.metric('채택 상태', _locale.code(_ct_shadow_adoption_review['adoption_state']))
    sar2.metric('검증 출처', _locale.code(_ct_shadow_adoption_review['source_validation_outcome_integrity'] if _ct_shadow_adoption_review['source_validation_outcome_id'] else '아님 · 필요'))
    sar3.metric('판단', _locale.code(_ct_shadow_adoption_review['decision'] or '-'))
    sar4.metric('개선', _locale.code('-' if _ct_shadow_adoption_review['eligible_outcomes'] == 0 else f"{_ct_shadow_adoption_review['relative_error_improvement_pct']:.1%}"))
    sar5.metric('채택 보호 점검', _locale.code(_ct_shadow_adoption_review['adoption_guard']))
    sar6.metric('투자 실행 권한', '없음')
    _sar_state = _ct_shadow_adoption_review['adoption_state']
    if _sar_state == 'ADOPTION_UPSTREAM_WAIT':
        st.info('사용자 채택 검토는 변경 불가 격리 모의 · 평가 · 정상 검증이 생긴 뒤 시작합니다. 현재 단계에서는 채택 판단을 억지로 만들 필요가 없습니다.')
    elif _sar_state == 'ADOPTION_VALIDATION_FAILED':
        st.warning('격리 모의 검증 실패 · 실전 적용 없이 제안을 폐기하거나 새 제안/계획 주기를 검토합니다.')
    elif _sar_state == 'ADOPTION_VALIDATION_INCONCLUSIVE':
        st.info('격리 모의 검증 결론 불충분 · 결과를 본 뒤 사전 등록됨 기준을 변경하지 않습니다.')
    elif _sar_state == 'ADOPTION_VALIDATION_AUDIT_REQUIRED':
        st.warning('실전 격리 모의 정상은 있으나 변경 불가 검증 결과 검증이 없습니다. 채택 검토 전에 격리 모의 검증 결과 상태 기록을 먼저 저장하세요.')
    elif _sar_state in {'ADOPTION_VALIDATION_INTEGRITY_REVIEW', 'ADOPTION_SOURCE_SUPERSEDED'}:
        st.warning('격리 모의 검증 / 채택 출처가 오래됨 또는 무결성 검토 상태입니다. 현재 변경 불가 정상 검증 기준으로 다시 검토하세요.')
    elif _sar_state == 'ADOPTION_REVIEW_REQUIRED':
        st.warning('격리 모의 검증 정상은 자동 승격이 아닙니다. 수락 · 대상 · 통제된 · 시험 운영 / 거절 / 보류 중 하나를 사용자 검토로 결정하세요.')
    elif _sar_state == 'ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL':
        st.success('사용자 채택 판단 = 수락 · 대상 · 통제된 · 시험 운영 · 이는 통제된 시험 운영 설계를 검토할 수 있다는 뜻일 뿐 실전 적용/재보정 승인이 아닙니다.')
    elif _sar_state == 'ADOPTION_REJECTED':
        st.info('사용자 채택 판단 = 거절 · 운영 모형/매개변수에는 어떤 변경도 적용되지 않습니다.')
    else:
        st.info('사용자 채택 판단 = 보류 · 새 투자 근거 또는 새 제안 주기까지 실전 적용 없이 대기합니다.')
    _locale.dataframe(st, _ct_shadow_adoption_queue, width='stretch', hide_index=True)
    if _ct_latest_shadow_adoption_review:
        _sar_latest_integrity = shadow_adoption_review_snapshot_integrity(_ct_latest_shadow_adoption_review)
        st.caption(f"최신 격리 모의 검증 채택 검토 · {_ct_latest_shadow_adoption_review.get('shadow_adoption_review_id', '')} · {_locale.code(_ct_latest_shadow_adoption_review.get('adoption_state', ''))} · 무결성 {_locale.code(_sar_latest_integrity['status'])}")
    if _sar_state == 'ADOPTION_REVIEW_REQUIRED':
        _sar_decision = st.selectbox('격리 모의 검증 채택 사용자 판단', ['ACCEPT_FOR_CONTROLLED_TRIAL', 'REJECT', 'DEFER'], key='shadow_adoption_decision', format_func=_locale.option())
        _sar_detail = st.text_area('격리 모의 검증 채택 판단 근거', value='', key='shadow_adoption_decision_detail', placeholder='예: 사전 검증 전용 표본 정상 투자 근거와 되돌림 위험을 검토했고, 실전 적용 없이 통제된 시험 운영 설계만 다음 단계에서 검토')
        _sar_c1 = st.checkbox('SHADOW_EVAL_PASS의 사전 투자 근거 / 계획 기준 / 출처 연결 이력을 검토했음을 확인', key='shadow_adoption_validation_evidence_reviewed')
        _sar_c2 = st.checkbox('정상이 재현되지 않을 경우의 되돌림/이전 버전 복원 조건을 검토했음을 확인', key='shadow_adoption_risk_reversal_reviewed')
        _sar_c3 = st.checkbox('수락 시에도 다음 단계는 통제된-시험 운영-전용임을 확인', key='shadow_adoption_trial_only_confirmed')
        _sar_c4 = st.checkbox('이 판단이 운영 모형/매개변수 적용을 승인하지 않음을 확인', key='shadow_adoption_no_live_apply_confirmed')
        _sar_c5 = st.checkbox('이 판단이 자동 재보정을 승인하지 않음을 확인', key='shadow_adoption_no_recalibration_confirmed')
        _sar_c6 = st.checkbox('이 판단이 자동 처리 용량 변경을 승인하지 않음을 확인', key='shadow_adoption_no_capacity_confirmed')
        _sar_c7 = st.checkbox('이 판단이 투자 실행/주문 권한을 생성하지 않음을 확인', key='shadow_adoption_no_execution_confirmed')
        _sar_c8 = st.checkbox('현재 격리 모의 검증 채택 판단을 최종 사용자 검토했음을 확인', key='shadow_adoption_human_review_confirmed')
        _sar_note = st.text_input('격리 모의 검증 채택 검토 상태 기록 메모', value='', key='shadow_adoption_review_note', placeholder='예: 검증 전용 표본 정상 사용자 채택 판단 / 금지 실전 적용')
        if st.button('운영 처리 흐름 격리 모의 검증 채택 검토 저장', key='shadow_adoption_review_save'):
            try:
                _sar_row = build_flow_shadow_adoption_review_lock(_ct_shadow_adoption_review, decision=_sar_decision, decision_detail=_sar_detail, validation_evidence_reviewed=_sar_c1, risk_reversal_reviewed=_sar_c2, controlled_trial_only_confirmed=_sar_c3, no_live_apply_confirmed=_sar_c4, no_auto_recalibration_confirmed=_sar_c5, no_auto_capacity_confirmed=_sar_c6, no_execution_authorization_confirmed=_sar_c7, human_review_confirmed=_sar_c8, note=_sar_note)
                _sar_hist = load_csv('operations_flow_shadow_adoption_review_snapshots.csv')
                for _col in FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS:
                    if _col not in _sar_hist.columns:
                        _sar_hist[_col] = ''
                _sar_hist = pd.concat([_sar_hist[FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS], pd.DataFrame([_sar_row])], ignore_index=True)
                verified_save_feedback(_sar_hist, 'operations_flow_shadow_adoption_review_snapshots.csv', f"Shadow Adoption Review 저장 · {_sar_row['decision']} · {_sar_row['adoption_state']} · Adoption Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('SHADOW_EVAL_PASS는 사용자 채택 검토의 입력일 뿐입니다. 수락 결정도 통제된 시험 운영 설계 검토만 허용하며 실전 적용/재보정/처리 용량/투자 실행 승인을 만들지 않습니다.')
    _ct_controlled_trial_design_history = load_csv('operations_flow_controlled_trial_design_snapshots.csv')
    _ct_controlled_trial_design = build_flow_controlled_trial_design(_ct_shadow_adoption_review, _ct_controlled_trial_design_history, default_max_trial_scope_pct=0.1, default_max_trial_sessions=3, default_min_trial_outcomes=3, default_max_relative_error_degradation_pct=0.1)
    _ct_controlled_trial_design_queue = build_flow_controlled_trial_design_queue(_ct_controlled_trial_design)
    _ct_latest_controlled_trial_design = latest_controlled_trial_design_snapshot(_ct_controlled_trial_design_history)
    st.subheader('1K-X. 통제된 시험 운영 설계 / 제한 시험 범위 / 이전 버전 복원 기준 계약')
    ctd1, ctd2, ctd3, ctd4, ctd5, ctd6 = st.columns(6)
    ctd1.metric('시험 운영 설계 상태', _locale.code(_ct_controlled_trial_design['design_state']))
    ctd2.metric('방식', _locale.code(_ct_controlled_trial_design['trial_mode'] or '-'))
    ctd3.metric('최대 범위', f"{_ct_controlled_trial_design['max_trial_scope_pct']:.0%}")
    ctd4.metric('작업 세션 상한', _locale.code(_ct_controlled_trial_design['max_trial_sessions']))
    ctd5.metric('설계 보호 점검', _locale.code(_ct_controlled_trial_design['design_guard']))
    ctd6.metric('투자 실행 권한', '없음')
    _ctd_state = _ct_controlled_trial_design['design_state']
    if _ctd_state == 'TRIAL_DESIGN_UPSTREAM_WAIT':
        st.info('통제된 시험 운영 설계는 사용자 채택 판단이 ACCEPT_FOR_CONTROLLED_TRIAL로 고정됨된 뒤 시작합니다. 현재 단계에서는 시험 운영 설계를 억지로 만들 필요가 없습니다.')
    elif _ctd_state == 'TRIAL_DESIGN_NOT_REQUIRED':
        st.success('현재 채택 판단에서는 통제된 시험 운영이 필요하지 않습니다. 실전 적용 없이 새 투자 근거/제안 주기를 관찰합니다.')
    elif _ctd_state == 'TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED':
        st.warning('수락 상태지만 변경 불가 사용자 채택 검토 출처가 없습니다. 시험 운영 설계 전에 채택 검토 검증을 먼저 확인하세요.')
    elif _ctd_state == 'TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW':
        st.error('채택 출처 또는 통제된 시험 운영 설계 검증 무결성이 일치하지 않아 시험 운영 설계를 차단했습니다.')
    elif _ctd_state == 'TRIAL_DESIGN_SUPERSEDED':
        st.warning('새 사용자 채택 출처가 생성되어 기존 시험 운영 설계가 대체됨되었습니다. 현재 수락 출처 기준으로 범위/이전 버전 복원 기준 계약을 다시 검토하세요.')
    elif _ctd_state == 'TRIAL_DESIGN_LOCKED':
        _ctd_locked = _ct_controlled_trial_design.get('latest_design') or {}
        st.success(f"통제된 시험 운영 설계 고정됨 · 범위 <= {float(_ctd_locked.get('max_trial_scope_pct', 0)):.0%} · 작업 세션 <= {int(float(_ctd_locked.get('max_trial_sessions', 0) or 0))} · 시험 운영 시작 권한 = 없음.")
    else:
        st.warning('통제된 시험 운영 설계가 필요합니다. 제한 시험 범위와 이전 버전 복원 기준 계약을 사용자 검토 후 잠그세요.')
    _locale.dataframe(st, _ct_controlled_trial_design_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_design:
        _ctd_latest_integrity = controlled_trial_design_snapshot_integrity(_ct_latest_controlled_trial_design)
        st.caption(f"최신 통제된 시험 운영 설계 · {_ct_latest_controlled_trial_design.get('controlled_trial_design_id', '')} · {_locale.code(_ct_latest_controlled_trial_design.get('design_state', ''))} · 무결성 {_locale.code(_ctd_latest_integrity['status'])}")
    if _ctd_state == 'TRIAL_DESIGN_REQUIRED':
        _ctd_scope = st.number_input('통제된 시험 운영 최대 범위', min_value=0.01, max_value=0.1, value=0.05, step=0.01, format='%.2f', key='controlled_trial_max_scope_pct')
        _ctd_sessions = st.number_input('통제된 시험 운영 최대 작업 세션 수', min_value=1, max_value=5, value=3, step=1, key='controlled_trial_max_sessions')
        _ctd_outcomes = st.number_input('통제된 시험 운영 최소 적격 결과', min_value=3, max_value=20, value=3, step=1, key='controlled_trial_min_outcomes')
        _ctd_degradation = st.number_input('이전 버전 복원 상대 오류 악화 한도', min_value=0.0, max_value=0.1, value=0.05, step=0.01, format='%.2f', key='controlled_trial_max_error_degradation')
        _ctd_rollback_detail = st.text_area('통제된 시험 운영 이전 버전 복원 기준 계약', value='', key='controlled_trial_rollback_detail', placeholder='예: 오류 악화 / 투자 가정 기준 이탈 / 무결성 실패 / 출처 대체 이력 중 하나라도 발생하면 즉시 기준 상태-전용 상태로 되돌리고 시험 운영을 중단')
        _ctd_c1 = st.checkbox('수락 · 대상 · 통제된 · 시험 운영 출처 검증과 사전 정상 투자 근거를 검토했음을 확인', key='controlled_trial_source_review_confirmed')
        _ctd_c2 = st.checkbox('시험 운영 범위가 기존 운영 의사결정과 분리된 SHADOW_CANARY_ONLY임을 확인', key='controlled_trial_isolation_confirmed')
        _ctd_c3 = st.checkbox('시험 운영은 별도 수동 시작 점검 없이는 시작되지 않음을 확인', key='controlled_trial_manual_start_required_confirmed')
        _ctd_c4 = st.checkbox('오류 악화 / 투자 가정 기준 이탈 / 무결성 실패 / 출처 대체 이력 이전 버전 복원 경로를 확인', key='controlled_trial_rollback_path_confirmed')
        _ctd_c5 = st.checkbox('설계 고정됨이 운영 모형/매개변수 적용을 승인하지 않음을 확인', key='controlled_trial_no_live_apply_confirmed')
        _ctd_c6 = st.checkbox('설계 고정됨이 자동 처리 용량 변경을 승인하지 않음을 확인', key='controlled_trial_no_capacity_confirmed')
        _ctd_c7 = st.checkbox('설계 고정됨이 투자 실행/주문 권한을 생성하지 않음을 확인', key='controlled_trial_no_execution_confirmed')
        _ctd_c8 = st.checkbox('현재 통제된 시험 운영 설계를 최종 사용자 검토했음을 확인', key='controlled_trial_human_review_confirmed')
        _ctd_note = st.text_input('통제된 시험 운영 설계 상태 기록 메모', value='', key='controlled_trial_design_note', placeholder='예: 격리 모의 제한 시험 범위 + 이전 버전 복원 기준 계약 / 금지 시작 권한')
        if st.button('운영 처리 흐름 통제된 시험 운영 설계 저장', key='controlled_trial_design_save'):
            try:
                _ctd_row = build_flow_controlled_trial_design_lock(_ct_controlled_trial_design, max_trial_scope_pct=float(_ctd_scope), max_trial_sessions=int(_ctd_sessions), min_trial_outcomes=int(_ctd_outcomes), max_relative_error_degradation_pct=float(_ctd_degradation), rollback_detail=_ctd_rollback_detail, rollback_on_error_degradation=True, rollback_on_assumption_drift=True, rollback_on_integrity_failure=True, rollback_on_source_supersession=True, source_review_confirmed=_ctd_c1, isolation_confirmed=_ctd_c2, manual_start_required_confirmed=_ctd_c3, rollback_path_confirmed=_ctd_c4, no_live_apply_confirmed=_ctd_c5, no_auto_capacity_confirmed=_ctd_c6, no_execution_authorization_confirmed=_ctd_c7, human_review_confirmed=_ctd_c8, note=_ctd_note)
                _ctd_hist = load_csv('operations_flow_controlled_trial_design_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS:
                    if _col not in _ctd_hist.columns:
                        _ctd_hist[_col] = ''
                _ctd_hist = pd.concat([_ctd_hist[FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS], pd.DataFrame([_ctd_row])], ignore_index=True)
                verified_save_feedback(_ctd_hist, 'operations_flow_controlled_trial_design_snapshots.csv', f"Controlled Trial Design 저장 · scope {_ctd_row['max_trial_scope_pct']:.0%} · sessions {_ctd_row['max_trial_sessions']} · Trial Start Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('통제된 시험 운영 설계 고정됨은 시험 운영 시작 승인이 아닙니다. 격리 모의 · 제한 시험 · 전용 범위/이전 버전 복원 기준 계약만 사전등록하며 별도 시험 운영 시작 점검이 필요합니다.')
    _ct_controlled_trial_start_history = load_csv('operations_flow_controlled_trial_start_snapshots.csv')
    _ct_controlled_trial_start = build_flow_controlled_trial_start(_ct_controlled_trial_design, _ct_controlled_trial_start_history)
    _ct_controlled_trial_start_queue = build_flow_controlled_trial_start_queue(_ct_controlled_trial_start)
    _ct_latest_controlled_trial_start = latest_controlled_trial_start_snapshot(_ct_controlled_trial_start_history)
    st.subheader('1K-Y. 통제된 시험 운영 시작 / 격리 모의 실행 허가 / 긴급 중단 점검')
    cts1, cts2, cts3, cts4, cts5, cts6 = st.columns(6)
    cts1.metric('시험 운영 시작 상태', _locale.code(_ct_controlled_trial_start['start_state']))
    cts2.metric('방식', _locale.code(_ct_controlled_trial_start['trial_mode'] or '-'))
    cts3.metric('허가 범위', _locale.code('-' if _ct_controlled_trial_start['permit_scope_pct'] <= 0 else f"{_ct_controlled_trial_start['permit_scope_pct']:.0%}"))
    cts4.metric('작업 세션 예산', _locale.code('-' if _ct_controlled_trial_start['permit_session_budget'] <= 0 else _ct_controlled_trial_start['permit_session_budget']))
    cts5.metric('시작 보호 점검', _locale.code(_ct_controlled_trial_start['start_guard']))
    cts6.metric('투자 실행 권한', '없음')
    _cts_state = _ct_controlled_trial_start['start_state']
    if _cts_state == 'TRIAL_START_UPSTREAM_WAIT':
        st.info('통제된 시험 운영 시작 검토는 시험 운영 · 설계 · 고정됨 이후에 시작합니다. 현재 단계에서는 시험 운영 시작 판단을 억지로 만들 필요가 없습니다.')
    elif _cts_state == 'TRIAL_START_NOT_REQUIRED':
        st.success('현재 시험 운영 설계 출처에서는 시험 운영 시작이 필요하지 않습니다.')
    elif _cts_state == 'TRIAL_START_DESIGN_SOURCE_REQUIRED':
        st.warning('시험 운영 · 설계 · 고정됨 상태지만 변경 불가 설계 출처가 없습니다. 시험 운영 시작 전에 통제된 시험 운영 설계 검증을 확인하세요.')
    elif _cts_state == 'TRIAL_START_SOURCE_INTEGRITY_REVIEW':
        st.error('통제된 시험 운영 설계 또는 시험 운영 시작 검증 무결성이 일치하지 않아 시작 점검을 차단했습니다.')
    elif _cts_state == 'TRIAL_START_SOURCE_SUPERSEDED':
        st.warning('새 통제된 시험 운영 설계가 생성되어 기존 시작 판단이 대체됨되었습니다. 현재 설계 기준으로 긴급 중단/이전 버전 복원 준비 상태를 다시 확인하세요.')
    elif _cts_state == 'TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY':
        st.success(f"격리 모의 시험 운영 허가 발급됨 · 범위 {_ct_controlled_trial_start['permit_scope_pct']:.0%} · 작업 세션 {_ct_controlled_trial_start['permit_session_budget']} · 투자 실행 권한 = 없음.")
    elif _cts_state == 'TRIAL_START_REJECTED':
        st.info('사용자 시험 운영 시작 판단 = 거절 · 시험 운영은 시작되지 않습니다.')
    elif _cts_state == 'TRIAL_START_DEFERRED':
        st.info('사용자 시험 운영 시작 판단 = 보류 · 새 투자 근거/운영 조건 확인 후 재검토합니다.')
    else:
        st.warning('통제된 시험 운영 시작 사용자 검토가 필요합니다. 긴급 중단 전환 / 이전 버전 복원 준비 상태 / 격리를 다시 확인하세요.')
    _locale.dataframe(st, _ct_controlled_trial_start_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_start:
        _cts_latest_integrity = controlled_trial_start_snapshot_integrity(_ct_latest_controlled_trial_start)
        st.caption(f"최신 통제된 시험 운영 시작 · {_ct_latest_controlled_trial_start.get('controlled_trial_start_id', '')} · {_locale.code(_ct_latest_controlled_trial_start.get('start_state', ''))} · 무결성 {_locale.code(_cts_latest_integrity['status'])}")
    if _cts_state == 'TRIAL_START_REVIEW_REQUIRED':
        _cts_decision = st.selectbox('통제된 시험 운영 시작 사용자 판단', ['ISSUE_SHADOW_TRIAL_PERMIT', 'REJECT', 'DEFER'], key='controlled_trial_start_decision', format_func=_locale.option())
        _cts_scope = st.number_input('격리 모의 시험 운영 허가 범위', min_value=0.01, max_value=float(min(0.1, _ct_controlled_trial_start['design_max_scope_pct'])), value=float(min(0.05, _ct_controlled_trial_start['design_max_scope_pct'])), step=0.01, format='%.2f', key='controlled_trial_start_scope_pct')
        _cts_sessions = st.number_input('격리 모의 시험 운영 작업 세션 예산', min_value=1, max_value=max(1, int(_ct_controlled_trial_start['design_session_cap'])), value=max(1, min(2, int(_ct_controlled_trial_start['design_session_cap']))), step=1, key='controlled_trial_start_session_budget')
        _cts_detail = st.text_area('통제된 시험 운영 시작 근거', value='', key='controlled_trial_start_detail', placeholder='예: 변경 불가 시험 운영 설계 출처, 격리, 긴급 중단 전환, 이전 버전 복원 준비 상태를 확인했고 격리 모의 · 제한 시험 · 전용 허가만 발급하며 실전 적용은 금지')
        _cts_c1 = st.checkbox('현재 시험 운영 · 설계 · 고정됨 출처 식별번호/무결성 해시 및 이전 버전 복원 기준 계약을 검토했음을 확인', key='controlled_trial_start_design_source_reviewed')
        _cts_c2 = st.checkbox('시험 운영 격리가 SHADOW_CANARY_ONLY로 유지됨을 재확인', key='controlled_trial_start_isolation_rechecked')
        _cts_c3 = st.checkbox('즉시 중단 가능한 긴급 중단 전환이 준비되었음을 확인', key='controlled_trial_start_kill_switch_ready')
        _cts_c4 = st.checkbox('이전 버전 복원 경로가 실제로 실행 가능한 상태임을 확인', key='controlled_trial_start_rollback_ready')
        _cts_c5 = st.checkbox('이 판단은 자동 시작이 아닌 수동 사용자 시작 판단임을 확인', key='controlled_trial_start_manual_confirmed')
        _cts_c6 = st.checkbox('격리 모의 시험 운영 허가가 운영 모형/매개변수 적용을 승인하지 않음을 확인', key='controlled_trial_start_no_live_apply')
        _cts_c7 = st.checkbox('격리 모의 시험 운영 허가가 자동 재보정을 승인하지 않음을 확인', key='controlled_trial_start_no_recalibration')
        _cts_c8 = st.checkbox('격리 모의 시험 운영 허가가 자동 처리 용량 변경을 승인하지 않음을 확인', key='controlled_trial_start_no_capacity')
        _cts_c9 = st.checkbox('격리 모의 시험 운영 허가가 투자 실행/주문 권한을 생성하지 않음을 확인', key='controlled_trial_start_no_execution')
        _cts_c10 = st.checkbox('현재 통제된 시험 운영 시작 판단을 최종 사용자 검토했음을 확인', key='controlled_trial_start_human_review')
        _cts_note = st.text_input('통제된 시험 운영 시작 상태 기록 메모', value='', key='controlled_trial_start_note', placeholder='예: 격리 모의 시험 운영 허가 / 긴급 중단 준비 완료 / 금지 실전 적용')
        if st.button('운영 처리 흐름 통제된 시험 운영 시작 검토 저장', key='controlled_trial_start_save'):
            try:
                _cts_row = build_flow_controlled_trial_start_lock(_ct_controlled_trial_start, start_decision=_cts_decision, start_detail=_cts_detail, permit_scope_pct=float(_cts_scope), permit_session_budget=int(_cts_sessions), design_source_reviewed=_cts_c1, isolation_rechecked=_cts_c2, kill_switch_ready_confirmed=_cts_c3, rollback_ready_confirmed=_cts_c4, manual_start_confirmed=_cts_c5, no_live_apply_confirmed=_cts_c6, no_auto_recalibration_confirmed=_cts_c7, no_auto_capacity_confirmed=_cts_c8, no_execution_authorization_confirmed=_cts_c9, human_review_confirmed=_cts_c10, note=_cts_note)
                _cts_hist = load_csv('operations_flow_controlled_trial_start_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS:
                    if _col not in _cts_hist.columns:
                        _cts_hist[_col] = ''
                _cts_hist = pd.concat([_cts_hist[FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS], pd.DataFrame([_cts_row])], ignore_index=True)
                verified_save_feedback(_cts_hist, 'operations_flow_controlled_trial_start_snapshots.csv', f"Controlled Trial Start Review 저장 · {_cts_row['start_decision']} · {_cts_row['start_state']} · Shadow Permission {_cts_row['shadow_trial_permission']} · Trial Start Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('ISSUE_SHADOW_TRIAL_PERMIT은 범위 제한 격리 모의 실행 환경을 위한 사용자 허가 기록일 뿐입니다. 시험 운영 시작 권한/투자 실행 권한은 없음이며 운영 모형/매개변수/처리 용량/투자 실행 권한을 만들지 않습니다.')
    _ct_controlled_trial_runtime_history = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
    _ct_controlled_trial_runtime = build_flow_controlled_trial_runtime(_ct_controlled_trial_start, _ct_controlled_trial_runtime_history)
    _ct_controlled_trial_runtime_queue = build_flow_controlled_trial_runtime_queue(_ct_controlled_trial_runtime)
    _ct_latest_controlled_trial_runtime = latest_controlled_trial_runtime_snapshot(_ct_controlled_trial_runtime_history)
    st.subheader('1K-Z. 통제된 시험 운영 실행 환경 / 격리 모의 실행 / 긴급 중단 강제 적용')
    ctr1, ctr2, ctr3, ctr4, ctr5, ctr6 = st.columns(6)
    ctr1.metric('실행 환경 상태', _locale.code(_ct_controlled_trial_runtime['runtime_state']))
    ctr2.metric('허가', _locale.code(_ct_controlled_trial_runtime['shadow_trial_permission']))
    ctr3.metric('작업 세션', _locale.code(f"{_ct_controlled_trial_runtime['sessions_used']}/{_ct_controlled_trial_runtime['permit_session_budget']}" if _ct_controlled_trial_runtime['permit_session_budget'] > 0 else '-'))
    ctr4.metric('활성 작업 세션', _locale.code(_ct_controlled_trial_runtime['active_session_id'] or '-'))
    ctr5.metric('긴급 중단 전환', _locale.code('중단 상태 유지' if _ct_controlled_trial_runtime['kill_switch_latched'] else '실행 준비됨'))
    ctr6.metric('투자 실행 권한', '없음')
    _ctr_state = _ct_controlled_trial_runtime['runtime_state']
    if _ctr_state == 'TRIAL_RUNTIME_UPSTREAM_WAIT':
        st.info('통제된 시험 운영 실행 환경은 격리 모의 · 제한 시험 · 전용 시작 허가가 발급된 뒤 시작합니다. 현재 단계에서는 실행 환경 작업 세션을 억지로 열 필요가 없습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_NOT_REQUIRED':
        st.success('현재 시험 운영 시작 판단에서는 격리 모의 실행 환경이 필요하지 않습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_DEFERRED':
        st.info('시험 운영 시작이 보류되어 격리 모의 실행 환경도 대기합니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED':
        st.warning('시작 허가 상태는 있으나 변경 불가 출처 검증을 확인할 수 없습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW':
        st.error('시작 허가 또는 실행 환경 기록 검증 무결성이 일치하지 않아 실행 환경을 차단했습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_SOURCE_SUPERSEDED':
        st.warning('새 시작 허가로 기존 실행 환경 출처가 대체됨되었습니다. 기존 실행 환경을 재사용하지 않습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_KILL_SWITCHED':
        st.error(f"긴급 중단 전환 중단 상태 유지 · 발동 조건 {_ct_controlled_trial_runtime['kill_switch_trigger']} · 이전 버전 복원 필요. 실행 환경 재개는 금지됩니다.")
    elif _ctr_state == 'TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED':
        st.success('격리 모의 실행 환경 작업 세션 예산을 모두 사용했습니다. 추가 진행 중은 금지되며 별도 시험 운영 결과 검토가 필요합니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_ACTIVE':
        st.warning('격리 모의 실행 환경 작업 세션 활성 · 실전 적용/실행 권한은 없습니다. 긴급 중단 전환과 이전 버전 복원 준비 상태를 유지하면서 종료 또는 KILL_SWITCH를 결정하세요.')
    else:
        st.info('격리 모의 실행 환경 준비 완료 · 사용자 검토 후 범위 제한 관찰 작업 세션을 열 수 있습니다.')
    _locale.dataframe(st, _ct_controlled_trial_runtime_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_runtime:
        _ctr_latest_integrity = controlled_trial_runtime_snapshot_integrity(_ct_latest_controlled_trial_runtime)
        st.caption(f"최신 통제된 시험 운영 실행 환경 · {_ct_latest_controlled_trial_runtime.get('controlled_trial_runtime_event_id', '')} · {_ct_latest_controlled_trial_runtime.get('event_type', '')} · 무결성 {_locale.code(_ctr_latest_integrity['status'])}")
    if _ctr_state == 'TRIAL_RUNTIME_READY':
        _ctr_open_detail = st.text_area('격리 모의 실행 환경 진행 중 근거', value='', key='controlled_trial_runtime_open_detail', placeholder='예: 현재 변경 불가 허가 출처, 격리, 긴급 중단 전환, 이전 버전 복원 경로를 재확인했고 범위 제한 격리 모의 관찰 작업 세션만 연다')
        _ctr_o1 = st.checkbox('현재 격리 모의 시험 운영 허가 출처 식별번호/무결성 해시를 직접 검토했습니다.', key='controlled_trial_runtime_open_source_reviewed')
        _ctr_o2 = st.checkbox('실행 환경은 격리 모의 · 제한 시험 · 전용 격리를 유지합니다.', key='controlled_trial_runtime_open_isolation')
        _ctr_o3 = st.checkbox('긴급 중단 전환 경로가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_open_kill_path')
        _ctr_o4 = st.checkbox('이전 버전 복원 경로가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_open_rollback_path')
        _ctr_o5 = st.checkbox('실행 환경 진행 중이 운영 모형/매개변수 적용을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_live')
        _ctr_o6 = st.checkbox('실행 환경 진행 중이 자동 재보정을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_recal')
        _ctr_o7 = st.checkbox('실행 환경 진행 중이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_capacity')
        _ctr_o8 = st.checkbox('실행 환경 진행 중이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_exec')
        _ctr_o9 = st.checkbox('현재 격리 모의 실행 환경 진행 중을 최종 사용자 검토했습니다.', key='controlled_trial_runtime_open_human')
        _ctr_open_note = st.text_input('격리 모의 실행 환경 진행 중 메모', value='', key='controlled_trial_runtime_open_note', placeholder='예: 범위 제한 격리 모의 실행 / 긴급 중단 실행 준비됨 / 금지 실전 실행')
        if st.button('통제된 시험 운영 실행 환경 작업 세션 진행 중 저장', key='controlled_trial_runtime_open_save'):
            try:
                _ctr_row = build_flow_controlled_trial_runtime_open(_ct_controlled_trial_runtime, runtime_detail=_ctr_open_detail, permit_source_reviewed=_ctr_o1, shadow_isolation_confirmed=_ctr_o2, kill_switch_path_confirmed=_ctr_o3, rollback_path_confirmed=_ctr_o4, no_live_apply_confirmed=_ctr_o5, no_auto_recalibration_confirmed=_ctr_o6, no_auto_capacity_confirmed=_ctr_o7, no_execution_authorization_confirmed=_ctr_o8, human_review_confirmed=_ctr_o9, note=_ctr_open_note)
                _ctr_hist = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _ctr_hist.columns:
                        _ctr_hist[_col] = ''
                _ctr_hist = pd.concat([_ctr_hist[FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_ctr_row])], ignore_index=True)
                verified_save_feedback(_ctr_hist, 'operations_flow_controlled_trial_runtime_snapshots.csv', f"Shadow Runtime OPEN · {_ctr_row['runtime_session_id']} · session {_ctr_row['session_index']} · Trial Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    elif _ctr_state == 'TRIAL_RUNTIME_ACTIVE':
        _ctr_active_detail = st.text_area('활성 실행 환경 종료 / 긴급 중단 근거', value='', key='controlled_trial_runtime_active_detail', placeholder='예: 작업 세션 관찰 완료 포함 금지 상한 초과, 또는 긴급 중단 발동 조건 및 이전 버전 복원 근거')
        _ctr_a1 = st.checkbox('현재 허가 출처를 다시 확인했습니다.', key='controlled_trial_runtime_active_source_reviewed')
        _ctr_a2 = st.checkbox('격리 모의 격리가 유지되고 있음을 확인했습니다.', key='controlled_trial_runtime_active_isolation')
        _ctr_a3 = st.checkbox('긴급 중단 전환 경로가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_active_kill_path')
        _ctr_a4 = st.checkbox('이전 버전 복원 경로가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_active_rollback_path')
        _ctr_a5 = st.checkbox('종료/긴급 중단 판단이 운영 모형/매개변수 적용을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_live')
        _ctr_a6 = st.checkbox('종료/긴급 중단 판단이 자동 재보정을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_recal')
        _ctr_a7 = st.checkbox('종료/긴급 중단 판단이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_capacity')
        _ctr_a8 = st.checkbox('종료/긴급 중단 판단이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_exec')
        _ctr_a9 = st.checkbox('현재 실행 환경 판단을 최종 사용자 검토했습니다.', key='controlled_trial_runtime_active_human')
        _ctr_active_note = st.text_input('활성 실행 환경 기록 메모', value='', key='controlled_trial_runtime_active_note', placeholder='예: 정상 종료 / 위험 중지 / 이전 버전 복원 필요')
        _ctr_col_close, _ctr_col_kill = st.columns(2)
        if _ctr_col_close.button('격리 모의 실행 환경 작업 세션 종료 저장', key='controlled_trial_runtime_close_save'):
            try:
                _ctr_row = build_flow_controlled_trial_runtime_close(_ct_controlled_trial_runtime, runtime_detail=_ctr_active_detail, permit_source_reviewed=_ctr_a1, shadow_isolation_confirmed=_ctr_a2, kill_switch_path_confirmed=_ctr_a3, rollback_path_confirmed=_ctr_a4, no_live_apply_confirmed=_ctr_a5, no_auto_recalibration_confirmed=_ctr_a6, no_auto_capacity_confirmed=_ctr_a7, no_execution_authorization_confirmed=_ctr_a8, human_review_confirmed=_ctr_a9, note=_ctr_active_note)
                _ctr_hist = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _ctr_hist.columns:
                        _ctr_hist[_col] = ''
                _ctr_hist = pd.concat([_ctr_hist[FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_ctr_row])], ignore_index=True)
                verified_save_feedback(_ctr_hist, 'operations_flow_controlled_trial_runtime_snapshots.csv', f"Shadow Runtime CLOSE · {_ctr_row['runtime_session_id']} · {_ctr_row['runtime_state']} · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
        _ctr_kill_trigger = st.selectbox('긴급 중단 전환 발동 조건', sorted(KILL_SWITCH_TRIGGERS), key='controlled_trial_runtime_kill_trigger')
        if _ctr_col_kill.button('긴급 중단 전환 중단 상태 고정 저장', key='controlled_trial_runtime_kill_save'):
            try:
                _ctr_row = build_flow_controlled_trial_runtime_kill_switch(_ct_controlled_trial_runtime, kill_switch_trigger=_ctr_kill_trigger, runtime_detail=_ctr_active_detail, permit_source_reviewed=_ctr_a1, shadow_isolation_confirmed=_ctr_a2, kill_switch_path_confirmed=_ctr_a3, rollback_path_confirmed=_ctr_a4, no_live_apply_confirmed=_ctr_a5, no_auto_recalibration_confirmed=_ctr_a6, no_auto_capacity_confirmed=_ctr_a7, no_execution_authorization_confirmed=_ctr_a8, human_review_confirmed=_ctr_a9, note=_ctr_active_note)
                _ctr_hist = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _ctr_hist.columns:
                        _ctr_hist[_col] = ''
                _ctr_hist = pd.concat([_ctr_hist[FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_ctr_row])], ignore_index=True)
                verified_save_feedback(_ctr_hist, 'operations_flow_controlled_trial_runtime_snapshots.csv', f"Kill Switch LATCHED · {_ctr_row['kill_switch_trigger']} · Rollback Required = TRUE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('통제된 시험 운영 실행 환경은 범위 제한 격리 모의 · 제한 시험 · 전용 관찰 작업 세션 등록부입니다. 실행 환경 활성도 운영 모형/매개변수/처리 용량/투자 실행 권한을 만들지 않으며 긴급 중단 전환이 중단 상태 고정되면 재개하지 않습니다.')
    _ct_controlled_trial_outcome_history = load_csv('operations_flow_controlled_trial_outcome_snapshots.csv')
    _ct_controlled_trial_outcome = build_flow_controlled_trial_outcome(_ct_controlled_trial_runtime, _ct_controlled_trial_runtime_history, _ct_recalibration_proposal_history, _ct_scorecard_input['qualified_outcome_history'])
    _ct_controlled_trial_outcome_queue = build_flow_controlled_trial_outcome_queue(_ct_controlled_trial_outcome)
    _ct_latest_controlled_trial_outcome = latest_controlled_trial_outcome_snapshot(_ct_controlled_trial_outcome_history)
    st.subheader('1K-AA. 통제된 시험 운영 결과 / 제한 시험 투자 근거 / 이전 버전 복원 보호 점검')
    cto1, cto2, cto3, cto4, cto5, cto6 = st.columns(6)
    cto1.metric('시험 운영 결과 상태', _locale.code(_ct_controlled_trial_outcome['outcome_state']))
    cto2.metric('실행 환경 상태', _locale.code(_ct_controlled_trial_outcome['source_runtime_state'] or '-'))
    cto3.metric('적격 결과', f"{_ct_controlled_trial_outcome['eligible_trial_outcomes']}/{_ct_controlled_trial_outcome['required_trial_outcomes']}")
    cto4.metric('상대 개선', _locale.code('-' if _ct_controlled_trial_outcome['eligible_trial_outcomes'] < _ct_controlled_trial_outcome['required_trial_outcomes'] else f"{_ct_controlled_trial_outcome['relative_error_improvement_pct']:.1%}"))
    cto5.metric('이전 버전 복원 필요', _locale.code('YES' if _ct_controlled_trial_outcome['rollback_required'] else '금지'))
    cto6.metric('투자 실행 권한', '없음')
    ctoa1, ctoa2, ctoa3, ctoa4, ctoa5 = st.columns(5)
    ctoa1.metric('완료 작업 세션', _locale.code(f"{_ct_controlled_trial_outcome['completed_sessions']}/{_ct_controlled_trial_outcome['permit_session_budget']}" if _ct_controlled_trial_outcome['permit_session_budget'] > 0 else '-'))
    ctoa2.metric('범위 밖 작업 세션', _locale.code(_ct_controlled_trial_outcome['outside_session_outcomes']))
    ctoa3.metric('사전-진행 중 전망', _locale.code(_ct_controlled_trial_outcome['preopen_projection_outcomes']))
    ctoa4.metric('기준 이탈', f"{_ct_controlled_trial_outcome['assumption_drift_outcomes']} / {_ct_controlled_trial_outcome['baseline_drift_outcomes']}")
    ctoa5.metric('결과 보호 점검', _locale.code(_ct_controlled_trial_outcome['outcome_guard']))
    _cto_state = _ct_controlled_trial_outcome['outcome_state']
    if _cto_state == 'TRIAL_OUTCOME_UPSTREAM_WAIT':
        st.info('통제된 시험 운영 결과 검토는 격리 모의 실행 환경 투자 근거가 생긴 뒤 시작합니다. 현재 단계에서는 결과를 억지로 만들 필요가 없습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_NOT_REQUIRED':
        st.success('현재 실행 환경 출처에서는 통제된 시험 운영 결과 검토가 필요하지 않습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT':
        st.warning('격리 모의 실행 환경 작업 세션이 활성입니다. 종료 또는 긴급 중단 · 전환 전에는 시험 운영 결과 결론을 내리지 않습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW':
        st.error('실행 환경 / 제안 / 적격 결과 출처 무결성이 일치하지 않아 시험 운영 결과를 차단했습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED':
        st.warning('MODEL_SHADOW는 실행 가능한 시험 운영 대안 가정 평가 도구가 아직 정의되지 않아 성능 결론을 내리지 않습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_EVIDENCE_MATURING':
        st.info('시험 운영 작업 세션 예산과 사전 적격 결과 투자 근거가 아직 성숙 중입니다. 사후 기준 변경 없이 현재 허가/설계 조건을 유지합니다.')
    elif _cto_state in {'TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED'}:
        st.error('통제된 시험 운영 결과는 이전 버전 복원 필요 상태입니다. 새 실행 환경/승격보다 이전 버전 복원 종결과 사후 분석이 우선입니다.')
    elif _cto_state == 'TRIAL_OUTCOME_PASS_NO_PROMOTION':
        st.success(f"통제된 시험 운영 정상 · 상대 오류 개선 {_ct_controlled_trial_outcome['relative_error_improvement_pct']:.1%}. 정상은 실전 승격/재보정/처리 용량/투자 실행 승인이 아닙니다.")
    else:
        st.info('통제된 시험 운영 결과 = 결론 불충분 · 기준을 사후 변경하지 않으며 실전 승격은 없습니다.')
    _locale.dataframe(st, _ct_controlled_trial_outcome_queue, width='stretch', hide_index=True)
    if not _ct_controlled_trial_outcome['evidence_table'].empty:
        with st.expander('통제된 시험 운영 제한 시험 투자 근거', expanded=False):
            _locale.dataframe(st, _ct_controlled_trial_outcome['evidence_table'], width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_outcome:
        _cto_latest_integrity = controlled_trial_outcome_snapshot_integrity(_ct_latest_controlled_trial_outcome)
        st.caption(f"최신 통제된 시험 운영 결과 · {_ct_latest_controlled_trial_outcome.get('controlled_trial_outcome_id', '')} · {_locale.code(_ct_latest_controlled_trial_outcome.get('outcome_state', ''))} · 무결성 {_locale.code(_cto_latest_integrity['status'])}")
    _cto_terminal_states = {'TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_PASS_NO_PROMOTION', 'TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION'}
    if _cto_state in _cto_terminal_states:
        _cto_note = st.text_input('통제된 시험 운영 결과 상태 기록 메모', value='', key='controlled_trial_outcome_note', placeholder='예: 제한 시험 결과 검토 / 이전 버전 복원 필요 또는 정상-승격 금지')
        if st.button('운영 처리 흐름 통제된 시험 운영 결과 상태 기록 저장', key='controlled_trial_outcome_save'):
            _cto_row = build_flow_controlled_trial_outcome_snapshot(_ct_controlled_trial_outcome, note=_cto_note)
            _cto_hist = load_csv('operations_flow_controlled_trial_outcome_snapshots.csv')
            for _col in FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS:
                if _col not in _cto_hist.columns:
                    _cto_hist[_col] = ''
            _cto_hist = pd.concat([_cto_hist[FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_cto_row])], ignore_index=True)
            verified_save_feedback(_cto_hist, 'operations_flow_controlled_trial_outcome_snapshots.csv', f"Controlled Trial Outcome 저장 · {_cto_row['outcome_state']} · Eligible {_cto_row['eligible_trial_outcomes']} · Rollback {_cto_row['rollback_required']} · Trial Outcome Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('통제된 시험 운영 결과는 종료됨 실행 환경 작업 세션 안에서 생성된 사전 적격 결과만 사용합니다. 정상도 운영 모형/매개변수 승격을 승인하지 않으며 이전 버전 복원 필요 상태에서는 새 시험 운영보다 이전 버전 복원 종결이 우선입니다.')
    _ct_controlled_trial_closure_history = load_csv('operations_flow_controlled_trial_closure_snapshots.csv')
    _ct_controlled_trial_closure = build_flow_controlled_trial_closure(_ct_controlled_trial_outcome, _ct_controlled_trial_outcome_history, _ct_controlled_trial_closure_history)
    _ct_controlled_trial_closure_queue = build_flow_controlled_trial_closure_queue(_ct_controlled_trial_closure)
    _ct_latest_controlled_trial_closure = latest_controlled_trial_closure_snapshot(_ct_controlled_trial_closure_history)
    st.subheader('1K-AB. 통제된 시험 운영 종결 / 사용자 결과 판단 / 이전 버전 복원 종결')
    ctc1, ctc2, ctc3, ctc4, ctc5, ctc6 = st.columns(6)
    ctc1.metric('종결 상태', _locale.code(_ct_controlled_trial_closure['closure_state']))
    ctc2.metric('결과 출처', _locale.code(_ct_controlled_trial_closure['source_trial_outcome_integrity'] if _ct_controlled_trial_closure['source_trial_outcome_id'] else '아님 · 필요'))
    ctc3.metric('판단', _locale.code(_ct_controlled_trial_closure['decision'] or '-'))
    ctc4.metric('이전 버전 복원', _locale.code('필요' if _ct_controlled_trial_closure['rollback_required'] else '금지'))
    ctc5.metric('운영 변경 허가', _locale.code(_ct_controlled_trial_closure['live_change_review_permission']))
    ctc6.metric('투자 실행 권한', '없음')
    _ctc_state = _ct_controlled_trial_closure['closure_state']
    if _ctc_state == 'TRIAL_CLOSURE_UPSTREAM_WAIT':
        st.info('통제된 시험 운영 종결은 종료 상태 시험 운영 결과와 변경 불가 결과 검증이 생긴 뒤 시작합니다. 현재 단계에서는 종결 판단을 억지로 만들 필요가 없습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_NOT_REQUIRED':
        st.success('현재 시험 운영 결과 출처에서는 종결 검토가 필요하지 않습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_OUTCOME_AUDIT_REQUIRED':
        st.warning('종료 상태 시험 운영 결과는 있으나 변경 불가 시험 운영 결과 검증이 없습니다. 종결 검토 전에 시험 운영 결과 상태 기록을 먼저 저장하세요.')
    elif _ctc_state == 'TRIAL_CLOSURE_SOURCE_INTEGRITY_REVIEW':
        st.error('시험 운영 결과 또는 종결 검증 무결성이 일치하지 않아 종결을 차단했습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_SOURCE_SUPERSEDED':
        st.warning('새 시험 운영 결과 검증이 생겨 기존 종결 판단이 대체됨되었습니다. 현재 결과 검증 기준으로 다시 사용자 검토하세요.')
    elif _ctc_state == 'TRIAL_CLOSURE_REVIEW_REQUIRED':
        st.warning('시험 운영 결과는 자동 승격 신호가 아닙니다. 정상은 수락 · 대상 · 실전 · 변경 · 검토 / 거절 / 보류, 결론 불충분은 거절 / 보류만 사용자 검토로 결정합니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_ROLLBACK_REQUIRED':
        st.error('이전 버전 복원 필요 · 새 시험 운영/운영 변경보다 이전 버전 복원 완료, 이전 기준 상태 복원, 무결성 검증, 사후 분석 종결이 우선입니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW':
        st.success('사용자 종결 판단 = 수락 · 대상 · 실전 · 변경 · 검토 · 이는 다음 운영 변경 설계를 검토할 수 있다는 뜻일 뿐 실전 적용 승인이 아닙니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_ROLLBACK_CLOSED':
        st.success('이전 버전 복원 종결 검증됨 · 이전 기준 상태 복원과 종결 검증이 확인되었습니다. 실전 적용/실행 권한은 생성되지 않습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_REJECTED':
        st.info('사용자 종결 판단 = 거절 · 운영 모형/매개변수에는 어떤 변경도 적용되지 않습니다.')
    else:
        st.info('사용자 종결 판단 = 보류 · 새 투자 근거 또는 새 시험 운영 주기까지 실전 적용 없이 대기합니다.')
    _locale.dataframe(st, _ct_controlled_trial_closure_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_closure:
        _ctc_latest_integrity = controlled_trial_closure_snapshot_integrity(_ct_latest_controlled_trial_closure)
        st.caption(f"최신 통제된 시험 운영 종결 · {_ct_latest_controlled_trial_closure.get('controlled_trial_closure_id', '')} · {_locale.code(_ct_latest_controlled_trial_closure.get('closure_state', ''))} · 무결성 {_locale.code(_ctc_latest_integrity['status'])}")
    if _ctc_state in {'TRIAL_CLOSURE_REVIEW_REQUIRED', 'TRIAL_CLOSURE_ROLLBACK_REQUIRED'}:
        _ctc_outcome_state = _ct_controlled_trial_closure['outcome_state']
        if _ctc_state == 'TRIAL_CLOSURE_ROLLBACK_REQUIRED':
            _ctc_options = ['ROLLBACK_CLOSED']
        elif _ctc_outcome_state == 'TRIAL_OUTCOME_PASS_NO_PROMOTION':
            _ctc_options = ['ACCEPT_FOR_LIVE_CHANGE_REVIEW', 'REJECT', 'DEFER']
        else:
            _ctc_options = ['REJECT', 'DEFER']
        _ctc_decision = st.selectbox('통제된 시험 운영 종결 사용자 판단', _ctc_options, key='controlled_trial_closure_decision')
        _ctc_detail = st.text_area('통제된 시험 운영 종결 판단 근거', value='', key='controlled_trial_closure_decision_detail', placeholder='예: 종료 상태 제한 시험 투자 근거, 이전 버전 복원 상태, 되돌림 위험을 검토했고 실전 적용 없이 다음 검토-전용 단계 또는 종결을 선택')
        _ctc_rollback_detail = st.text_area('이전 버전 복원 종결 상세', value='', key='controlled_trial_closure_rollback_detail', placeholder='ROLLBACK_CLOSED일 때 이전 기준 상태 복원, 무결성 검증, 사후 분석 결과를 기록')
        _ctc_c1 = st.checkbox('현재 변경 불가 시험 운영 결과 출처 식별번호/무결성 해시를 검토했음을 확인', key='controlled_trial_closure_source_reviewed')
        _ctc_c2 = st.checkbox('시험 운영 투자 근거 / 제한 시험 결과 / 작업 세션 조건을 검토했음을 확인', key='controlled_trial_closure_evidence_reviewed')
        _ctc_c3 = st.checkbox('결정이 틀렸을 때의 되돌림 / 하락 위험 위험을 검토했음을 확인', key='controlled_trial_closure_reversal_reviewed')
        _ctc_c4 = st.checkbox('수락 시에도 다음 단계는 운영 변경 설계 검토 전용임을 확인', key='controlled_trial_closure_live_change_review_only')
        _ctc_c5 = st.checkbox('이전 버전 복원이 실제 완료되었음을 확인', key='controlled_trial_closure_rollback_completed')
        _ctc_c6 = st.checkbox('이전 기준 상태가 복원되었음을 확인', key='controlled_trial_closure_prior_baseline_restored')
        _ctc_c7 = st.checkbox('이전 버전 복원 이후 무결성을 검증했음을 확인', key='controlled_trial_closure_rollback_integrity')
        _ctc_c8 = st.checkbox('이전 버전 복원 원인과 재발방지 사후 분석을 검토했음을 확인', key='controlled_trial_closure_postmortem')
        _ctc_c9 = st.checkbox('이 판단이 운영 모형/매개변수 적용을 승인하지 않음을 확인', key='controlled_trial_closure_no_live_apply')
        _ctc_c10 = st.checkbox('이 판단이 자동 재보정을 승인하지 않음을 확인', key='controlled_trial_closure_no_recalibration')
        _ctc_c11 = st.checkbox('이 판단이 자동 처리 용량 변경을 승인하지 않음을 확인', key='controlled_trial_closure_no_capacity')
        _ctc_c12 = st.checkbox('이 판단이 투자 실행/주문 권한을 생성하지 않음을 확인', key='controlled_trial_closure_no_execution')
        _ctc_c13 = st.checkbox('현재 통제된 시험 운영 종결 판단을 최종 사용자 검토했음을 확인', key='controlled_trial_closure_human_review')
        _ctc_note = st.text_input('통제된 시험 운영 종결 상태 기록 메모', value='', key='controlled_trial_closure_note', placeholder='예: 정상 검토-전용 / 거절 / 보류 / 이전 버전 복원 종결')
        if st.button('운영 처리 흐름 통제된 시험 운영 종결 저장', key='controlled_trial_closure_save'):
            try:
                _ctc_row = build_flow_controlled_trial_closure_lock(_ct_controlled_trial_closure, decision=_ctc_decision, decision_detail=_ctc_detail, rollback_detail=_ctc_rollback_detail, outcome_source_reviewed=_ctc_c1, trial_evidence_reviewed=_ctc_c2, reversal_risk_reviewed=_ctc_c3, live_change_review_only_confirmed=_ctc_c4, rollback_completed_confirmed=_ctc_c5, prior_baseline_restored_confirmed=_ctc_c6, rollback_integrity_verified=_ctc_c7, postmortem_reviewed=_ctc_c8, no_live_apply_confirmed=_ctc_c9, no_auto_recalibration_confirmed=_ctc_c10, no_auto_capacity_confirmed=_ctc_c11, no_execution_authorization_confirmed=_ctc_c12, human_review_confirmed=_ctc_c13, note=_ctc_note)
                _ctc_hist = load_csv('operations_flow_controlled_trial_closure_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS:
                    if _col not in _ctc_hist.columns:
                        _ctc_hist[_col] = ''
                _ctc_hist = pd.concat([_ctc_hist[FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS], pd.DataFrame([_ctc_row])], ignore_index=True)
                verified_save_feedback(_ctc_hist, 'operations_flow_controlled_trial_closure_snapshots.csv', f"Controlled Trial Closure 저장 · {_ctc_row['decision']} · {_ctc_row['closure_state']} · Live Change Permission {_ctc_row['live_change_review_permission']} · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('통제된 시험 운영 종결은 종료 상태 시험 운영 결과의 사용자 판단과 이전 버전 복원 종결을 기록합니다. ACCEPT_FOR_LIVE_CHANGE_REVIEW도 설계 · 검토 · 전용 허가일 뿐 실전 적용/재보정/처리 용량/투자 실행 승인을 만들지 않습니다.')
    _ct_live_change_design_history = load_csv('operations_flow_live_change_design_snapshots.csv')
    _ct_live_change_design = build_flow_live_change_design(_ct_controlled_trial_closure, _ct_controlled_trial_closure_history, load_csv('operations_flow_recalibration_proposal_snapshots.csv'), _ct_live_change_design_history)
    _ct_live_change_design_queue = build_flow_live_change_design_queue(_ct_live_change_design)
    _ct_latest_live_change_design = latest_live_change_design_snapshot(_ct_live_change_design_history)
    st.subheader('1K-AC. 운영 변경 설계 / 제한 시험 범위 / 기준 상태 고정 / 이전 버전 복원 계획')
    lcd1, lcd2, lcd3, lcd4, lcd5, lcd6 = st.columns(6)
    lcd1.metric('설계 상태', _locale.code(_ct_live_change_design['design_state']))
    lcd2.metric('변경 방식', _locale.code(_ct_live_change_design['change_mode'] or '-'))
    lcd3.metric('범위 상한', f"{_ct_live_change_design['max_live_scope_pct']:.0%}")
    lcd4.metric('작업 세션', _locale.code(_ct_live_change_design['max_live_sessions']))
    lcd5.metric('설계 보호 점검', _locale.code(_ct_live_change_design['design_guard']))
    lcd6.metric('투자 실행 권한', '없음')
    lcdb1, lcdb2, lcdb3, lcdb4, lcdb5 = st.columns(5)
    lcdb1.metric('기준 상태', _locale.code('-' if not _ct_live_change_design['source_proposal_id'] else f"{_ct_live_change_design['baseline_value']:.4f}"))
    lcdb2.metric('후보', _locale.code('-' if not _ct_live_change_design['source_proposal_id'] else f"{_ct_live_change_design['candidate_value']:.4f}"))
    lcdb3.metric('이전 버전 복원 대상', _locale.code('-' if not _ct_live_change_design['source_proposal_id'] else f"{_ct_live_change_design['rollback_target_value']:.4f}"))
    lcdb4.metric('변경 후 결과', _locale.code(_ct_live_change_design['min_post_change_outcomes']))
    lcdb5.metric('설계 허가', _locale.code(_ct_live_change_design['live_change_design_permission']))
    _lcd_state = _ct_live_change_design['design_state']
    if _lcd_state == 'LIVE_CHANGE_DESIGN_UPSTREAM_WAIT':
        st.info('운영 변경 설계는 사용자 시험 운영 종결이 ACCEPT_FOR_LIVE_CHANGE_REVIEW로 닫힌 뒤 시작합니다. 현재 단계에서는 설계를 억지로 만들 필요가 없습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_NOT_REQUIRED':
        st.success('현재 시험 운영 종결 판단에서는 운영 변경 설계가 필요하지 않습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_DEFERRED':
        st.info('시험 운영 종결이 보류되어 운영 변경 설계도 대기합니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED':
        st.warning('수락됨 종결 상태는 있으나 변경 불가 종결 검증을 확인할 수 없습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW':
        st.error('시험 운영 종결 또는 운영 변경 설계 출처 무결성이 일치하지 않아 설계를 차단했습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW':
        st.error('원본 고정됨 재보정 제안 출처를 확인할 수 없습니다. 운영 변경 설계 전에 제안 식별번호/무결성 해시/무결성을 복구하세요.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED':
        st.warning('새 시험 운영 종결 또는 제안 출처가 생겨 기존 운영 변경 설계가 대체됨되었습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_LOCKED':
        st.success('운영 변경 설계 고정됨 · 기준 상태/후보/제한 시험 범위/이전 버전 복원 계획이 사전등록되었습니다. 이 상태도 실전 적용 승인이 아니며 별도 사용자 적용 점검이 필요합니다.')
    else:
        st.warning('운영 변경 설계 사용자 검토가 필요합니다. 기준 상태 버전 고정, 제한 시험 격리, 이전 버전 복원 계획, 수동 적용 점검을 사전등록하세요.')
    _locale.dataframe(st, _ct_live_change_design_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_design:
        _lcd_latest_integrity = live_change_design_snapshot_integrity(_ct_latest_live_change_design)
        st.caption(f"최신 운영 변경 설계 · {_ct_latest_live_change_design.get('live_change_design_id', '')} · {_locale.code(_ct_latest_live_change_design.get('design_state', ''))} · 무결성 {_locale.code(_lcd_latest_integrity['status'])}")
    if _lcd_state == 'LIVE_CHANGE_DESIGN_REQUIRED':
        _lcd_scope = st.number_input('운영 변경 제한 시험 범위', min_value=0.01, max_value=0.05, value=0.01, step=0.01, format='%.2f', key='live_change_design_scope')
        _lcd_sessions = st.number_input('운영 변경 작업 세션 상한', min_value=1, max_value=3, value=1, step=1, key='live_change_design_sessions')
        _lcd_outcomes = st.number_input('최소 변경 후 적격 결과', min_value=3, max_value=20, value=3, step=1, key='live_change_design_outcomes')
        _lcd_degradation = st.number_input('최대 상대 오류 악화', min_value=0.0, max_value=0.05, value=0.03, step=0.01, format='%.2f', key='live_change_design_degradation')
        _lcd_artifact = st.text_input('버전이 지정된 변경 산출물 참조', value='', key='live_change_design_artifact_ref', placeholder='PARAMETER_SHADOW는 비워두면 대상 지표로 고정됩니다. MODEL_SHADOW는 버전이 지정된 산출물 참조 필수')
        _lcd_detail = st.text_area('운영 변경 설계 상세', value='', key='live_change_design_detail', placeholder='예: 이전 기준 상태를 버전 고정하고 1% 제한 시험 범위에서만 후보를 검증하며 별도 사용자 적용 점검 전까지 실전 적용하지 않는다')
        _lcd_rollback = st.text_area('이전 버전 복원 계획 상세', value='', key='live_change_design_rollback_detail', placeholder='예: 오류 악화, 투자 가정 기준 이탈, 무결성 실패, 출처 대체 이력 발생 시 즉시 후보 중단 후 고정됨 이전 기준 상태로 복원하고 변경 후 투자 근거를 폐기한다')
        _lcd_c1 = st.checkbox('현재 변경 불가 시험 운영 종결과 원본 고정됨 제안 출처 식별번호/무결성 해시를 검토했습니다.', key='live_change_design_source_reviewed')
        _lcd_c2 = st.checkbox('현재 이전 기준 상태/버전을 이전 버전 복원 대상으로 고정했음을 확인했습니다.', key='live_change_design_baseline_locked')
        _lcd_c3 = st.checkbox('운영 변경은 작은 제한 시험 격리 범위에서만 검토될 것임을 확인했습니다.', key='live_change_design_canary_isolation')
        _lcd_c4 = st.checkbox('설계 고정 이후에도 별도 사용자 적용 점검 없이는 적용되지 않음을 확인했습니다.', key='live_change_design_manual_apply_gate')
        _lcd_c5 = st.checkbox('이전 버전 복원 경로가 실제 복원 가능한 이전 기준 상태를 가리킴을 확인했습니다.', key='live_change_design_rollback_path')
        _lcd_c6 = st.checkbox('이 설계 저장이 자동 실전 적용을 승인하지 않음을 확인했습니다.', key='live_change_design_no_auto_apply')
        _lcd_c7 = st.checkbox('이 설계 저장이 자동 재보정을 승인하지 않음을 확인했습니다.', key='live_change_design_no_recalibration')
        _lcd_c8 = st.checkbox('이 설계 저장이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='live_change_design_no_capacity')
        _lcd_c9 = st.checkbox('이 설계 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_design_no_execution')
        _lcd_c10 = st.checkbox('현재 운영 변경 설계를 최종 사용자 검토했습니다.', key='live_change_design_human_review')
        _lcd_note = st.text_input('운영 변경 설계 상태 기록 메모', value='', key='live_change_design_note', placeholder='예: 제한 시험 설계 / 기준 상태 고정 / 이전 버전 복원 계획 / 금지 실전 적용')
        if st.button('운영 처리 흐름 운영 변경 설계 저장', key='live_change_design_save'):
            try:
                _lcd_row = build_flow_live_change_design_lock(_ct_live_change_design, max_live_scope_pct=float(_lcd_scope), max_live_sessions=int(_lcd_sessions), min_post_change_outcomes=int(_lcd_outcomes), max_relative_error_degradation_pct=float(_lcd_degradation), artifact_ref=_lcd_artifact, design_detail=_lcd_detail, rollback_detail=_lcd_rollback, source_reviewed=_lcd_c1, baseline_version_locked_confirmed=_lcd_c2, canary_isolation_confirmed=_lcd_c3, manual_apply_gate_required_confirmed=_lcd_c4, rollback_path_confirmed=_lcd_c5, no_auto_apply_confirmed=_lcd_c6, no_auto_recalibration_confirmed=_lcd_c7, no_auto_capacity_confirmed=_lcd_c8, no_execution_authorization_confirmed=_lcd_c9, human_review_confirmed=_lcd_c10, note=_lcd_note)
                _lcd_hist = load_csv('operations_flow_live_change_design_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS:
                    if _col not in _lcd_hist.columns:
                        _lcd_hist[_col] = ''
                _lcd_hist = pd.concat([_lcd_hist[FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS], pd.DataFrame([_lcd_row])], ignore_index=True)
                verified_save_feedback(_lcd_hist, 'operations_flow_live_change_design_snapshots.csv', f"Live Change Design 저장 · {_lcd_row['change_mode']} · scope {_lcd_row['max_live_scope_pct']:.1%} · rollback target {_lcd_row['rollback_target_value']:.4f} · Live Change Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('운영 변경 설계는 설계 · 검토 · 전용 허가로 기준 상태/후보/제한 시험/이전 버전 복원 조건을 사전등록하는 단계입니다. LIVE_CHANGE_DESIGN_LOCKED도 실전 적용/재보정/처리 용량/투자 실행 승인을 만들지 않습니다.')
    _ct_live_change_apply_history = load_csv('operations_flow_live_change_apply_snapshots.csv')
    _ct_live_change_apply = build_flow_live_change_apply(_ct_live_change_design, _ct_live_change_apply_history)
    _ct_live_change_apply_queue = build_flow_live_change_apply_queue(_ct_live_change_apply)
    _ct_latest_live_change_apply = latest_live_change_apply_snapshot(_ct_live_change_apply_history)
    st.subheader('1K-AD. 운영 변경 적용 사전 검사 / 수동 제한 시험 허가 / 자동 적용 금지 보호 점검')
    lca1, lca2, lca3, lca4, lca5, lca6 = st.columns(6)
    lca1.metric('적용 상태', _locale.code(_ct_live_change_apply['apply_state']))
    lca2.metric('판단', _locale.code(_ct_live_change_apply['apply_decision'] or '-'))
    lca3.metric('허가 범위', _locale.code('-' if _ct_live_change_apply['permit_scope_pct'] <= 0 else f"{_ct_live_change_apply['permit_scope_pct']:.0%}"))
    lca4.metric('작업 세션 예산', _locale.code('-' if _ct_live_change_apply['permit_session_budget'] <= 0 else _ct_live_change_apply['permit_session_budget']))
    lca5.metric('적용 보호 점검', _locale.code(_ct_live_change_apply['apply_guard']))
    lca6.metric('투자 실행 권한', '없음')
    lcap1, lcap2, lcap3, lcap4, lcap5 = st.columns(5)
    lcap1.metric('기준 상태', _locale.code('-' if not _ct_live_change_apply['source_live_change_design_id'] else f"{_ct_live_change_apply['baseline_value']:.4f}"))
    lcap2.metric('후보', _locale.code('-' if not _ct_live_change_apply['source_live_change_design_id'] else f"{_ct_live_change_apply['candidate_value']:.4f}"))
    lcap3.metric('이전 버전 복원 대상', _locale.code('-' if not _ct_live_change_apply['source_live_change_design_id'] else f"{_ct_live_change_apply['rollback_target_value']:.4f}"))
    lcap4.metric('적용 허가', _locale.code(_ct_live_change_apply['live_change_apply_permission']))
    lcap5.metric('적용 권한', '없음')
    _lca_state = _ct_live_change_apply['apply_state']
    if _lca_state == 'LIVE_CHANGE_APPLY_UPSTREAM_WAIT':
        st.info('운영 변경 적용 검토는 실전 · 변경 · 설계 · 고정됨 이후에 시작합니다. 현재 단계에서는 적용 판단을 억지로 만들 필요가 없습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_NOT_REQUIRED':
        st.success('현재 운영 변경 설계 출처에서는 적용 검토가 필요하지 않습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_DEFERRED':
        st.info('사용자 운영 변경 적용 판단이 보류되어 적용 검토도 대기합니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED':
        st.warning('실전 · 변경 · 설계 · 고정됨 상태지만 변경 불가 설계 출처가 없습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW':
        st.error('운영 변경 설계 또는 적용 검증 무결성이 일치하지 않아 적용 점검을 차단했습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED':
        st.warning('새 운영 변경 설계가 생성되어 기존 적용 판단이 대체됨되었습니다. 현재 설계 기준으로 기준 상태/후보/이전 버전 복원 준비 상태를 다시 확인하세요.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY':
        st.success(f"수동 제한 시험 적용 허가 발급됨 · 범위 {_ct_live_change_apply['permit_scope_pct']:.0%} · 작업 세션 {_ct_live_change_apply['permit_session_budget']} · 운영 변경 적용 권한 = 없음 · 투자 실행 권한 = 없음.")
    elif _lca_state == 'LIVE_CHANGE_APPLY_REJECTED':
        st.info('사용자 운영 변경 적용 판단 = 거절 · 운영 변경은 적용되지 않습니다.')
    else:
        st.warning('운영 변경 적용 사용자 검토가 필요합니다. 기준 상태 최신성, 후보 산출물, 제한 시험 격리, 이전 버전 복원 준비 상태를 재확인하세요.')
    _locale.dataframe(st, _ct_live_change_apply_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_apply:
        _lca_latest_integrity = live_change_apply_snapshot_integrity(_ct_latest_live_change_apply)
        st.caption(f"최신 운영 변경 적용 검토 · {_ct_latest_live_change_apply.get('live_change_apply_id', '')} · {_locale.code(_ct_latest_live_change_apply.get('apply_state', ''))} · 무결성 {_locale.code(_lca_latest_integrity['status'])}")
    if _lca_state == 'LIVE_CHANGE_APPLY_REVIEW_REQUIRED':
        _lca_decision = st.selectbox('운영 변경 적용 사용자 판단', ['ISSUE_MANUAL_CANARY_APPLY_PERMIT', 'REJECT', 'DEFER'], key='live_change_apply_decision', format_func=_locale.option())
        _lca_scope = st.number_input('수동 제한 시험 적용 범위', min_value=0.01, max_value=float(min(0.05, _ct_live_change_apply['design_max_scope_pct'])), value=float(min(0.01, _ct_live_change_apply['design_max_scope_pct'])), step=0.01, format='%.2f', key='live_change_apply_scope')
        _lca_sessions = st.number_input('수동 제한 시험 적용 작업 세션 예산', min_value=1, max_value=max(1, int(_ct_live_change_apply['design_max_sessions'])), value=1, step=1, key='live_change_apply_sessions')
        _lca_detail = st.text_area('운영 변경 적용 근거', value='', key='live_change_apply_detail', placeholder='예: 변경 불가 설계 출처, 기준 상태 최신성, 후보 산출물, 제한 시험 격리, 이전 버전 복원 준비 상태를 재확인했고 별도 실행 환경 점검이 소비할 수동 제한 시험 허가만 발급한다')
        _lca_c1 = st.checkbox('현재 변경 불가 운영 변경 설계 출처 식별번호/무결성 해시를 직접 검토했습니다.', key='live_change_apply_source_reviewed')
        _lca_c2 = st.checkbox('현재 이전 기준 상태가 설계에 잠긴 기준 상태와 동일함을 재확인했습니다.', key='live_change_apply_baseline_revalidated')
        _lca_c3 = st.checkbox('후보 매개변수/모형 산출물이 설계 출처와 일치함을 확인했습니다.', key='live_change_apply_candidate_verified')
        _lca_c4 = st.checkbox('제한 시험 격리 범위가 고정됨 설계 상한 안에 있음을 재확인했습니다.', key='live_change_apply_canary_isolation')
        _lca_c5 = st.checkbox('변경 창(변경 기간)과 관찰 책임자를 검토했습니다.', key='live_change_apply_window_reviewed')
        _lca_c6 = st.checkbox('즉시 이전 기준 상태로 복원 가능한 이전 버전 복원 경로가 준비되었음을 확인했습니다.', key='live_change_apply_rollback_ready')
        _lca_c7 = st.checkbox('이 허가는 사람이 직접 수행하는 수동 제한 시험 적용 전제조건일 뿐임을 확인했습니다.', key='live_change_apply_manual_only')
        _lca_c8 = st.checkbox('이 허가 저장이 자동 실전 적용을 실행하지 않음을 확인했습니다.', key='live_change_apply_no_auto_apply')
        _lca_c9 = st.checkbox('이 허가 저장이 자동 재보정을 승인하지 않음을 확인했습니다.', key='live_change_apply_no_recal')
        _lca_c10 = st.checkbox('이 허가 저장이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='live_change_apply_no_capacity')
        _lca_c11 = st.checkbox('이 허가 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_apply_no_execution')
        _lca_c12 = st.checkbox('현재 운영 변경 적용 판단을 최종 사용자 검토했습니다.', key='live_change_apply_human_review')
        _lca_note = st.text_input('운영 변경 적용 상태 기록 메모', value='', key='live_change_apply_note', placeholder='예: 수동 제한 시험 허가 / 기준 상태 재검증됨 / 이전 버전 복원 준비 완료 / 금지 자동 설치')
        if st.button('운영 처리 흐름 운영 변경 적용 검토 저장', key='live_change_apply_save'):
            try:
                _lca_row = build_flow_live_change_apply_lock(_ct_live_change_apply, apply_decision=_lca_decision, permit_scope_pct=float(_lca_scope), permit_session_budget=int(_lca_sessions), apply_detail=_lca_detail, design_source_reviewed=_lca_c1, baseline_revalidated_confirmed=_lca_c2, candidate_artifact_verified=_lca_c3, canary_isolation_rechecked=_lca_c4, change_window_reviewed=_lca_c5, rollback_ready_confirmed=_lca_c6, manual_apply_only_confirmed=_lca_c7, no_auto_apply_confirmed=_lca_c8, no_auto_recalibration_confirmed=_lca_c9, no_auto_capacity_confirmed=_lca_c10, no_execution_authorization_confirmed=_lca_c11, human_review_confirmed=_lca_c12, note=_lca_note)
                _lca_hist = load_csv('operations_flow_live_change_apply_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS:
                    if _col not in _lca_hist.columns:
                        _lca_hist[_col] = ''
                _lca_hist = pd.concat([_lca_hist[FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS], pd.DataFrame([_lca_row])], ignore_index=True)
                verified_save_feedback(_lca_hist, 'operations_flow_live_change_apply_snapshots.csv', f"Live Change Apply Review 저장 · {_lca_row['apply_decision']} · {_lca_row['apply_state']} · Permission {_lca_row['live_change_apply_permission']} · Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('ISSUE_MANUAL_CANARY_APPLY_PERMIT은 자동 적용 명령이 아니라 다음 운영 변경 실행 환경/시작 점검을 위한 범위 제한 사용자 허가 기록입니다. 운영 변경 적용 권한/투자 실행 권한은 없음입니다.')
    _ct_live_change_runtime_history = load_csv('operations_flow_live_change_runtime_snapshots.csv')
    _ct_live_change_runtime = build_flow_live_change_runtime(_ct_live_change_apply, _ct_live_change_runtime_history)
    _ct_live_change_runtime_queue = build_flow_live_change_runtime_queue(_ct_live_change_runtime)
    _ct_latest_live_change_runtime = latest_live_change_runtime_snapshot(_ct_live_change_runtime_history)
    st.subheader('1K-AE. 운영 변경 실행 환경 / 수동 시작 / 긴급 중단 / 이전 버전 복원 보호 점검')
    lcr1, lcr2, lcr3, lcr4, lcr5, lcr6 = st.columns(6)
    lcr1.metric('실행 환경 상태', _locale.code(_ct_live_change_runtime['runtime_state']))
    lcr2.metric('허가', _locale.code(_ct_live_change_runtime['live_change_runtime_permission']))
    lcr3.metric('작업 세션', _locale.code(f"{_ct_live_change_runtime['sessions_used']}/{_ct_live_change_runtime['permit_session_budget']}" if _ct_live_change_runtime['permit_session_budget'] > 0 else '-'))
    lcr4.metric('활성 작업 세션', _locale.code(_ct_live_change_runtime['active_session_id'] or '-'))
    lcr5.metric('이전 버전 복원', _locale.code('필요' if _ct_live_change_runtime['rollback_required'] else '실행 준비됨'))
    lcr6.metric('투자 실행 권한', '없음')
    lcrb1, lcrb2, lcrb3, lcrb4 = st.columns(4)
    lcrb1.metric('기준 상태', _locale.code('-' if not _ct_live_change_runtime['source_live_change_apply_id'] else f"{_ct_live_change_runtime['baseline_value']:.4f}"))
    lcrb2.metric('후보', _locale.code('-' if not _ct_live_change_runtime['source_live_change_apply_id'] else f"{_ct_live_change_runtime['candidate_value']:.4f}"))
    lcrb3.metric('이전 버전 복원 대상', _locale.code('-' if not _ct_live_change_runtime['source_live_change_apply_id'] else f"{_ct_live_change_runtime['rollback_target_value']:.4f}"))
    lcrb4.metric('실행 환경 권한', '없음')
    _lcr_state = _ct_live_change_runtime['runtime_state']
    if _lcr_state == 'LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT':
        st.info('운영 변경 실행 환경은 수동 · 제한 시험 · 적용 · 전용 허가가 발급된 뒤 시작합니다. 현재 단계에서는 시작 기록을 억지로 만들 필요가 없습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_NOT_REQUIRED':
        st.success('현재 적용 판단에서는 운영 변경 실행 환경이 필요하지 않습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_DEFERRED':
        st.info('적용 판단이 보류되어 실행 환경도 대기합니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED':
        st.warning('적용 허가 상태는 있으나 변경 불가 적용 출처를 확인할 수 없습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW':
        st.error('적용 허가 또는 실행 환경 기록 검증 무결성이 일치하지 않아 실행 환경을 차단했습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED':
        st.warning('새 적용 허가로 기존 실행 환경 출처가 대체됨되었습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED':
        st.error(f"긴급 중단 전환 중단 상태 유지 · 발동 조건 {_ct_live_change_runtime['kill_switch_trigger']} · 이전 버전 복원 필요. 같은 출처 주기에서는 재활성화하지 않습니다.")
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED':
        st.success('수동 제한 시험 작업 세션 예산을 모두 사용했습니다. 추가 시작은 금지되며 이후 변경 후 결과 평가로 이동합니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_ACTIVE_CANARY':
        st.warning('수동 제한 시험 활성 · 이 운영 시스템이 자동으로 매개변수/모형을 바꾼 것이 아닙니다. 외부 수동 시작 접수를 기록한 상태이며 종료 또는 KILL_SWITCH만 허용됩니다.')
    else:
        st.info('수동 시작 준비 완료 · 외부에서 실제 제한 시험 변경을 사람이 수행한 뒤 접수와 관찰된 값을 검증해 활성화 기록을 저장할 수 있습니다.')
    _locale.dataframe(st, _ct_live_change_runtime_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_runtime:
        _lcr_latest_integrity = live_change_runtime_snapshot_integrity(_ct_latest_live_change_runtime)
        st.caption(f"최신 운영 변경 실행 환경 · {_ct_latest_live_change_runtime.get('live_change_runtime_event_id', '')} · {_ct_latest_live_change_runtime.get('event_type', '')} · 무결성 {_locale.code(_lcr_latest_integrity['status'])}")
    if _lcr_state == 'LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION':
        _lcr_receipt = st.text_input('외부 수동 시작 접수 / 변경 참조', value='', key='live_change_runtime_activation_receipt', placeholder='예: CHG-20260929-001 / 배포 접수 / 매개변수 변경 요청 건')
        _lcr_pre = st.number_input('관찰된 값 변경 전 수동 시작', value=float(_ct_live_change_runtime['baseline_value']), format='%.6f', key='live_change_runtime_observed_pre')
        _lcr_post = st.number_input('관찰된 값 변경 후 수동 시작', value=float(_ct_live_change_runtime['candidate_value']), format='%.6f', key='live_change_runtime_observed_post')
        _lcr_detail = st.text_area('수동 시작 근거', value='', key='live_change_runtime_activate_detail', placeholder='예: 현재 기준 상태, 후보 산출물, 허가 범위, 변경 기간, 이전 버전 복원 경로를 확인했고 외부 수동 제한 시험 변경 완료 접수를 바탕으로 시작 기록만 기록한다')
        _lcr_a1 = st.checkbox('현재 변경 불가 수동 제한 시험 적용 허가 출처 식별번호/무결성 해시를 검토했습니다.', key='live_change_runtime_activate_permit_reviewed')
        _lcr_a2 = st.checkbox('시작 직전 기준 상태가 고정됨 기준 상태와 동일함을 확인했습니다.', key='live_change_runtime_activate_baseline')
        _lcr_a3 = st.checkbox('후보 매개변수/모형 산출물이 고정됨 후보와 일치함을 확인했습니다.', key='live_change_runtime_activate_candidate')
        _lcr_a4 = st.checkbox('제한 시험 격리가 허가 범위 안에서 유지됨을 확인했습니다.', key='live_change_runtime_activate_isolation')
        _lcr_a5 = st.checkbox('현재 변경 기간이 승인된 사전 검사 조건과 일치함을 확인했습니다.', key='live_change_runtime_activate_window')
        _lcr_a6 = st.checkbox('즉시 이전 기준 상태로 복원 가능한 이전 버전 복원 경로가 준비되어 있음을 확인했습니다.', key='live_change_runtime_activate_rollback')
        _lcr_a7 = st.checkbox('실제 변경은 운영 시스템이 자동 실행한 것이 아니라 사람이 외부에서 수동 수행했음을 확인했습니다.', key='live_change_runtime_activate_external_manual')
        _lcr_a8 = st.checkbox('이 실행 환경 기록이 추가 자동 적용을 실행하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_auto_apply')
        _lcr_a9 = st.checkbox('이 실행 환경 기록이 자동 재보정을 승인하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_recal')
        _lcr_a10 = st.checkbox('이 실행 환경 기록이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_capacity')
        _lcr_a11 = st.checkbox('이 실행 환경 기록이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_exec')
        _lcr_a12 = st.checkbox('현재 수동 시작 기록을 최종 사용자 검토했습니다.', key='live_change_runtime_activate_human')
        _lcr_note = st.text_input('운영 변경 실행 환경 상태 기록 메모', value='', key='live_change_runtime_activate_note', placeholder='예: 외부 수동 제한 시험 활성화됨 / 이전 버전 복원 실행 준비됨 / 금지 자동 설치')
        if st.button('운영 변경 실행 환경 활성화 기록 저장', key='live_change_runtime_activate_save'):
            try:
                _lcr_row = build_flow_live_change_runtime_activate(_ct_live_change_runtime, activation_receipt_ref=_lcr_receipt, observed_pre_value=float(_lcr_pre), observed_post_value=float(_lcr_post), runtime_detail=_lcr_detail, permit_source_reviewed=_lcr_a1, baseline_freshness_confirmed=_lcr_a2, candidate_artifact_verified=_lcr_a3, canary_isolation_confirmed=_lcr_a4, change_window_confirmed=_lcr_a5, rollback_path_confirmed=_lcr_a6, manual_external_activation_confirmed=_lcr_a7, no_auto_apply_confirmed=_lcr_a8, no_auto_recalibration_confirmed=_lcr_a9, no_auto_capacity_confirmed=_lcr_a10, no_execution_authorization_confirmed=_lcr_a11, human_review_confirmed=_lcr_a12, note=_lcr_note)
                _lcr_hist = load_csv('operations_flow_live_change_runtime_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _lcr_hist.columns:
                        _lcr_hist[_col] = ''
                _lcr_hist = pd.concat([_lcr_hist[FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_lcr_row])], ignore_index=True)
                verified_save_feedback(_lcr_hist, 'operations_flow_live_change_runtime_snapshots.csv', f"Live Change Runtime ACTIVATE recorded · {_lcr_row['runtime_session_id']} · receipt {_lcr_row['activation_receipt_ref']} · Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_ACTIVE_CANARY':
        _lcr_active_detail = st.text_area('활성 제한 시험 종료 / 긴급 중단 근거', value='', key='live_change_runtime_active_detail', placeholder='예: 제한 시험 관찰 완료 및 기준 상태 복원됨, 또는 위험 발동 조건 필요한 긴급 중단 전환')
        _lcr_restored = st.number_input('관찰된 값 변경 후 기준 상태 복원', value=float(_ct_live_change_runtime['rollback_target_value']), format='%.6f', key='live_change_runtime_restored_value')
        _lcr_c1 = st.checkbox('현재 변경 불가 적용 허가 출처를 다시 확인했습니다.', key='live_change_runtime_active_permit_reviewed')
        _lcr_c2 = st.checkbox('이전 버전 복원 경로가 즉시 사용 가능한 상태임을 확인했습니다.', key='live_change_runtime_active_rollback_path')
        _lcr_c3 = st.checkbox('이 기록 저장이 추가 자동 적용을 실행하지 않음을 확인했습니다.', key='live_change_runtime_active_no_auto_apply')
        _lcr_c4 = st.checkbox('이 기록 저장이 자동 재보정을 승인하지 않음을 확인했습니다.', key='live_change_runtime_active_no_recal')
        _lcr_c5 = st.checkbox('이 기록 저장이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='live_change_runtime_active_no_capacity')
        _lcr_c6 = st.checkbox('이 기록 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_runtime_active_no_exec')
        _lcr_c7 = st.checkbox('현재 종료/긴급 중단 판단을 최종 사용자 검토했습니다.', key='live_change_runtime_active_human')
        _lcr_close_restore = st.checkbox('정상 종료 전에 이전 기준 상태 복원을 완료했습니다.', key='live_change_runtime_close_restore_confirmed')
        _lcr_kill_rollback = st.checkbox('긴급 중단 전환 선택 시 이전 버전 복원을 즉시 시작했음을 확인합니다.', key='live_change_runtime_kill_rollback_started')
        _lcr_active_note = st.text_input('활성 제한 시험 기록 메모', value='', key='live_change_runtime_active_note', placeholder='예: 정상 종료 / 기준 상태 복원됨 / 수동 위험 중지')
        _lcr_col_close, _lcr_col_kill = st.columns(2)
        if _lcr_col_close.button('운영 변경 실행 환경 종료 저장', key='live_change_runtime_close_save'):
            try:
                _lcr_row = build_flow_live_change_runtime_close(_ct_live_change_runtime, observed_restored_value=float(_lcr_restored), runtime_detail=_lcr_active_detail, baseline_restore_confirmed=_lcr_close_restore, permit_source_reviewed=_lcr_c1, rollback_path_confirmed=_lcr_c2, no_auto_apply_confirmed=_lcr_c3, no_auto_recalibration_confirmed=_lcr_c4, no_auto_capacity_confirmed=_lcr_c5, no_execution_authorization_confirmed=_lcr_c6, human_review_confirmed=_lcr_c7, note=_lcr_active_note)
                _lcr_hist = load_csv('operations_flow_live_change_runtime_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _lcr_hist.columns:
                        _lcr_hist[_col] = ''
                _lcr_hist = pd.concat([_lcr_hist[FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_lcr_row])], ignore_index=True)
                verified_save_feedback(_lcr_hist, 'operations_flow_live_change_runtime_snapshots.csv', f"Live Change Runtime CLOSE · {_lcr_row['runtime_session_id']} · {_lcr_row['runtime_state']} · baseline restored · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
        _lcr_trigger = st.selectbox('운영 변경 긴급 중단 전환 발동 조건', sorted(LIVE_CHANGE_RUNTIME_KILL_TRIGGERS), key='live_change_runtime_kill_trigger')
        if _lcr_col_kill.button('운영 변경 긴급 중단 전환 중단 상태 고정 저장', key='live_change_runtime_kill_save'):
            try:
                _lcr_row = build_flow_live_change_runtime_kill_switch(_ct_live_change_runtime, kill_switch_trigger=_lcr_trigger, observed_restored_value=float(_lcr_restored), runtime_detail=_lcr_active_detail, rollback_initiated_confirmed=_lcr_kill_rollback, permit_source_reviewed=_lcr_c1, rollback_path_confirmed=_lcr_c2, no_auto_apply_confirmed=_lcr_c3, no_auto_recalibration_confirmed=_lcr_c4, no_auto_capacity_confirmed=_lcr_c5, no_execution_authorization_confirmed=_lcr_c6, human_review_confirmed=_lcr_c7, note=_lcr_active_note)
                _lcr_hist = load_csv('operations_flow_live_change_runtime_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _lcr_hist.columns:
                        _lcr_hist[_col] = ''
                _lcr_hist = pd.concat([_lcr_hist[FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_lcr_row])], ignore_index=True)
                verified_save_feedback(_lcr_hist, 'operations_flow_live_change_runtime_snapshots.csv', f"Live Change Kill Switch LATCHED · {_lcr_row['kill_switch_trigger']} · baseline restored {_lcr_row['baseline_restore_confirmed']} · Rollback Required = TRUE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('v1.48 실행 환경은 자동 실전 변경 엔진이 아니라 외부 수동 제한 시험 시작의 변경 불가 투자 근거 등록부입니다. 활성화는 외부 접수와 관찰된 기준 상태/후보를 검증해 기록할 뿐이며 실행 환경/투자 실행 권한은 없음입니다.')
    _ct_live_change_outcome_history = load_csv('operations_flow_live_change_outcome_snapshots.csv')
    _ct_live_change_outcome = build_flow_live_change_outcome(_ct_live_change_runtime, _ct_live_change_runtime_history, _ct_scorecard_input['qualified_outcome_history'])
    _ct_live_change_outcome_queue = build_flow_live_change_outcome_queue(_ct_live_change_outcome)
    _ct_latest_live_change_outcome = latest_live_change_outcome_snapshot(_ct_live_change_outcome_history)
    st.subheader('1K-AF. 운영 변경 결과 / 변경 후 투자 근거 / 영구 채택 보호 점검')
    lco1, lco2, lco3, lco4, lco5, lco6 = st.columns(6)
    lco1.metric('결과 상태', _locale.code(_ct_live_change_outcome['outcome_state']))
    lco2.metric('실행 환경 상태', _locale.code(_ct_live_change_outcome['source_runtime_state'] or '-'))
    lco3.metric('적격 결과', f"{_ct_live_change_outcome['eligible_post_change_outcomes']}/{_ct_live_change_outcome['required_post_change_outcomes']}")
    lco4.metric('상대 개선', _locale.code('-' if _ct_live_change_outcome['eligible_post_change_outcomes'] < _ct_live_change_outcome['required_post_change_outcomes'] else f"{_ct_live_change_outcome['relative_error_improvement_pct']:.1%}"))
    lco5.metric('영구 채택', _locale.code(_ct_live_change_outcome['permanent_adoption_permission']))
    lco6.metric('투자 실행 권한', '없음')
    lcoa1, lcoa2, lcoa3, lcoa4, lcoa5 = st.columns(5)
    lcoa1.metric('완료 작업 세션', _locale.code(f"{_ct_live_change_outcome['completed_sessions']}/{_ct_live_change_outcome['permit_session_budget']}" if _ct_live_change_outcome['permit_session_budget'] > 0 else '-'))
    lcoa2.metric('범위 밖 작업 세션', _locale.code(_ct_live_change_outcome['outside_session_outcomes']))
    lcoa3.metric('사전-시작 전망', _locale.code(_ct_live_change_outcome['preactivation_projection_outcomes']))
    lcoa4.metric('기준 이탈', f"{_ct_live_change_outcome['assumption_drift_outcomes']} / {_ct_live_change_outcome['candidate_drift_outcomes']}")
    lcoa5.metric('이전 버전 복원 필요', _locale.code('YES' if _ct_live_change_outcome['rollback_required'] else '금지'))
    _lco_state = _ct_live_change_outcome['outcome_state']
    if _lco_state == 'LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT':
        st.info('운영 변경 결과 검토는 수동 제한 시험 실행 환경 투자 근거가 생긴 뒤 시작합니다. 현재 단계에서는 결과를 억지로 만들 필요가 없습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_NOT_REQUIRED':
        st.success('현재 실행 환경 출처에서는 운영 변경 결과 검토가 필요하지 않습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT':
        st.warning('수동 제한 시험 실행 환경이 활성입니다. 종료 또는 긴급 중단 · 전환 전에는 결과 결론을 내리지 않습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW':
        st.error('실행 환경 / 적격 결과 출처 무결성이 일치하지 않아 운영 변경 결과를 차단했습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED':
        st.warning('MODEL_SHADOW는 실행 가능한 변경 후 대안 가정 평가 도구가 아직 정의되지 않아 영구 채택 결론을 내리지 않습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING':
        st.info('변경 후 투자 근거와 제한 시험 작업 세션 예산이 아직 성숙 중입니다. 긍정적 중간 결과만으로 조기 영구 채택을 허용하지 않습니다.')
    elif _lco_state in {'LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED'}:
        st.error('운영 변경 결과는 이전 버전 복원 필요 상태입니다. 새 시작이나 영구 채택보다 기준 상태 유지/복원과 이전 버전 복원 종결이 우선입니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION':
        st.success(f"운영 변경 제한 시험 정상 · 상대 오류 개선 {_ct_live_change_outcome['relative_error_improvement_pct']:.1%}. 정상은 영구 모형/매개변수 채택이나 투자 실행 승인이 아닙니다.")
    else:
        st.info('운영 변경 결과 = 결론 불충분 · 기준을 사후 변경하지 않으며 영구 채택은 없습니다.')
    _locale.dataframe(st, _ct_live_change_outcome_queue, width='stretch', hide_index=True)
    if not _ct_live_change_outcome['evidence_table'].empty:
        with st.expander('운영 변경 변경 후 투자 근거', expanded=False):
            _locale.dataframe(st, _ct_live_change_outcome['evidence_table'], width='stretch', hide_index=True)
    if _ct_latest_live_change_outcome:
        _lco_latest_integrity = live_change_outcome_snapshot_integrity(_ct_latest_live_change_outcome)
        st.caption(f"최신 운영 변경 결과 · {_ct_latest_live_change_outcome.get('live_change_outcome_id', '')} · {_locale.code(_ct_latest_live_change_outcome.get('outcome_state', ''))} · 무결성 {_locale.code(_lco_latest_integrity['status'])}")
    _lco_terminal_states = {'LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION', 'LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION'}
    if _lco_state in _lco_terminal_states:
        _lco_note = st.text_input('운영 변경 결과 상태 기록 메모', value='', key='live_change_outcome_note', placeholder='예: 변경 후 투자 근거 검토 / 정상-금지-영구-채택 / 이전 버전 복원 필요')
        if st.button('운영 처리 흐름 운영 변경 결과 상태 기록 저장', key='live_change_outcome_save'):
            _lco_row = build_flow_live_change_outcome_snapshot(_ct_live_change_outcome, note=_lco_note)
            _lco_hist = load_csv('operations_flow_live_change_outcome_snapshots.csv')
            for _col in FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS:
                if _col not in _lco_hist.columns:
                    _lco_hist[_col] = ''
            _lco_hist = pd.concat([_lco_hist[FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_lco_row])], ignore_index=True)
            verified_save_feedback(_lco_hist, 'operations_flow_live_change_outcome_snapshots.csv', f"Live Change Outcome 저장 · {_lco_row['outcome_state']} · Eligible {_lco_row['eligible_post_change_outcomes']} · Rollback {_lco_row['rollback_required']} · Permanent Change Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('운영 변경 결과는 활성화→종료 구간 안에서 생성된 사전 적격 결과만 사용합니다. 정상도 영구 채택을 승인하지 않으며 별도 사용자 운영 변경 결과 종결이 필요합니다.')
    _ct_live_change_closure_history = load_csv('operations_flow_live_change_outcome_closure_snapshots.csv')
    _ct_live_change_closure = build_flow_live_change_outcome_closure(_ct_live_change_outcome, _ct_live_change_outcome_history, _ct_live_change_closure_history)
    _ct_live_change_closure_queue = build_flow_live_change_outcome_closure_queue(_ct_live_change_closure)
    _ct_latest_live_change_closure = latest_live_change_outcome_closure_snapshot(_ct_live_change_closure_history)
    st.subheader('1K-AG. 운영 변경 결과 종결 / 사용자 최종 정식 채택 검토 / 이전 버전 복원 종결')
    lcc1, lcc2, lcc3, lcc4, lcc5, lcc6 = st.columns(6)
    lcc1.metric('종결 상태', _locale.code(_ct_live_change_closure['closure_state']))
    lcc2.metric('결과 출처', _locale.code(_ct_live_change_closure['source_live_change_outcome_integrity'] if _ct_live_change_closure['source_live_change_outcome_id'] else '아님 · 필요'))
    lcc3.metric('판단', _locale.code(_ct_live_change_closure['decision'] or '-'))
    lcc4.metric('이전 버전 복원', _locale.code('YES' if _ct_live_change_closure['rollback_required'] else '금지'))
    lcc5.metric('영구 설계 허가', _locale.code(_ct_live_change_closure['permanent_change_design_permission']))
    lcc6.metric('투자 실행 권한', '없음')
    _lcc_state = _ct_live_change_closure['closure_state']
    if _lcc_state == 'LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT':
        st.info('영구 채택 검토는 종료 상태 운영 변경 결과와 변경 불가 결과 검증이 생긴 뒤 시작합니다. 현재 단계에서는 종결 판단을 억지로 만들 필요가 없습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_NOT_REQUIRED':
        st.success('현재 운영 변경 결과 출처에서는 영구 채택 검토가 필요하지 않습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED':
        st.warning('종료 상태 운영 변경 결과는 있으나 변경 불가 결과 검증이 아직 없습니다. 먼저 1K-AF에서 결과 상태 기록을 저장하세요.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW':
        st.error('운영 변경 결과 또는 종결 검증 무결성이 일치하지 않아 영구 채택 검토를 차단했습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED':
        st.warning('새 운영 변경 결과 검증이 생겨 기존 종결 판단이 대체됨되었습니다. 현재 결과 출처 기준으로 다시 사용자 검토하세요.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED':
        st.warning('사용자 최종 정식 채택 검토가 필요합니다. 정상도 바로 영구 채택하지 않으며 수락은 다음 영구 변경 설계 검토만 엽니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED':
        st.error('이전 버전 복원 필요 결과입니다. 영구 채택 검토보다 기준 상태 복원, 이전 버전 복원 무결성, 사후 분석이 우선입니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW':
        st.success('사용자 검토 = 수락 · 대상 · 영구 · 변경 · 설계 · 검토 · 영구 · 설계 · 검토 · 전용 허가만 부여됩니다. 영구 적용 권한은 없음입니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_REJECTED':
        st.info('사용자 검토 = 거절 · 후보의 영구 채택은 없습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_DEFERRED':
        st.info('사용자 검토 = 보류 · 새 투자 근거/제한 시험 주기까지 영구 채택 검토를 보류합니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED':
        st.success('이전 버전 복원 종결 검증됨 · 이전 기준 상태 복원/무결성/사후 분석 확인이 완료되었습니다. 이 상태도 새 영구 변경 승인을 생성하지 않습니다.')
    _locale.dataframe(st, _ct_live_change_closure_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_closure:
        _lcc_integrity = live_change_outcome_closure_snapshot_integrity(_ct_latest_live_change_closure)
        st.caption(f"최신 운영 변경 종결 · {_ct_latest_live_change_closure.get('live_change_outcome_closure_id', '')} · {_ct_latest_live_change_closure.get('decision', '')} · 무결성 {_locale.code(_lcc_integrity['status'])}")
    if _lcc_state in {'LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED', 'LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED'}:
        _lcc_outcome_state = _ct_live_change_closure['outcome_state']
        if _lcc_state == 'LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED':
            _lcc_options = ['ROLLBACK_CLOSED']
        elif _lcc_outcome_state == 'LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION':
            _lcc_options = ['ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW', 'REJECT', 'DEFER']
        else:
            _lcc_options = ['REJECT', 'DEFER']
        _lcc_decision = st.selectbox('사용자 최종 정식 채택 판단', _lcc_options, key='live_change_closure_decision')
        _lcc_detail = st.text_area('영구 채택 검토 근거', value='', key='live_change_closure_detail', placeholder='예: 사전 변경 후 투자 근거, 제한 시험 범위, 되돌림 위험, 영구성 위험을 검토했으며 수락은 영구 설계 검토에만 진입시키고 실제 영구 적용은 승인하지 않는다')
        _lcc_rollback_detail = st.text_area('이전 버전 복원 종결 상세', value='', key='live_change_closure_rollback_detail', placeholder='이전 버전 복원 · 종료됨 선택 시 기준 상태 복원, 무결성 검증, 사후 분석 결과와 재발방지 조치를 기록')
        _lcc_c1 = st.checkbox('현재 변경 불가 운영 변경 결과 출처 식별번호/무결성 해시와 무결성을 검토했습니다.', key='live_change_closure_source_reviewed')
        _lcc_c2 = st.checkbox('활성화→종료 사전 변경 후 투자 근거와 평가 결과를 검토했습니다.', key='live_change_closure_evidence_reviewed')
        _lcc_c3 = st.checkbox('제한 시험 성공의 지속가능성, 되돌림 위험, 영구성 위험을 검토했습니다.', key='live_change_closure_permanence_risk')
        _lcc_c4 = st.checkbox('수락은 영구 변경 설계 검토만 허용하며 실제 영구 적용 승인이 아님을 확인했습니다.', key='live_change_closure_design_review_only')
        _lcc_rb1 = st.checkbox('이전 버전 복원이 실제 완료되었음을 확인했습니다.', key='live_change_closure_rollback_completed')
        _lcc_rb2 = st.checkbox('이전 기준 상태가 복원되었음을 확인했습니다.', key='live_change_closure_baseline_restored')
        _lcc_rb3 = st.checkbox('이전 버전 복원 무결성을 검증했습니다.', key='live_change_closure_rollback_integrity')
        _lcc_rb4 = st.checkbox('사후 분석을 검토했습니다.', key='live_change_closure_postmortem')
        _lcc_c5 = st.checkbox('이 종결 저장이 영구 모형/매개변수 적용을 승인하지 않음을 확인했습니다.', key='live_change_closure_no_permanent_apply')
        _lcc_c6 = st.checkbox('이 종결 저장이 자동 재보정을 승인하지 않음을 확인했습니다.', key='live_change_closure_no_recal')
        _lcc_c7 = st.checkbox('이 종결 저장이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='live_change_closure_no_capacity')
        _lcc_c8 = st.checkbox('이 종결 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_closure_no_execution')
        _lcc_c9 = st.checkbox('현재 영구 채택 / 이전 버전 복원 종결 판단을 최종 사용자 검토했습니다.', key='live_change_closure_human_review')
        _lcc_note = st.text_input('운영 변경 결과 종결 상태 기록 메모', value='', key='live_change_closure_note', placeholder='예: 영구-설계-검토-전용 / 거절 / 보류 / 이전 버전 복원 종료됨')
        if st.button('운영 처리 흐름 운영 변경 결과 종결 저장', key='live_change_closure_save'):
            try:
                _lcc_row = build_flow_live_change_outcome_closure_lock(_ct_live_change_closure, decision=_lcc_decision, decision_detail=_lcc_detail, rollback_detail=_lcc_rollback_detail, outcome_source_reviewed=_lcc_c1, post_change_evidence_reviewed=_lcc_c2, permanence_risk_reviewed=_lcc_c3, permanent_design_review_only_confirmed=_lcc_c4, rollback_completed_confirmed=_lcc_rb1, prior_baseline_restored_confirmed=_lcc_rb2, rollback_integrity_verified=_lcc_rb3, postmortem_reviewed=_lcc_rb4, no_permanent_apply_confirmed=_lcc_c5, no_auto_recalibration_confirmed=_lcc_c6, no_auto_capacity_confirmed=_lcc_c7, no_execution_authorization_confirmed=_lcc_c8, human_review_confirmed=_lcc_c9, note=_lcc_note)
                _lcc_hist = load_csv('operations_flow_live_change_outcome_closure_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS:
                    if _col not in _lcc_hist.columns:
                        _lcc_hist[_col] = ''
                _lcc_hist = pd.concat([_lcc_hist[FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS], pd.DataFrame([_lcc_row])], ignore_index=True)
                verified_save_feedback(_lcc_hist, 'operations_flow_live_change_outcome_closure_snapshots.csv', f"Live Change Outcome Closure 저장 · {_lcc_row['decision']} · {_lcc_row['closure_state']} · Permission {_lcc_row['permanent_change_design_permission']} · Permanent Change Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('영구 채택 검토는 정상을 바로 영구 적용하지 않습니다. 수락은 영구 · 설계 · 검토 · 전용 허가만 만들며 실제 영구 변경에는 별도 설계/적용 관리 기준이 필요합니다.')
    _ct_permanent_change_design_history = load_csv('operations_flow_permanent_change_design_snapshots.csv')
    _ct_permanent_change_design = build_flow_permanent_change_design(_ct_live_change_closure, _ct_live_change_closure_history, _ct_permanent_change_design_history)
    _ct_permanent_change_design_queue = build_flow_permanent_change_design_queue(_ct_permanent_change_design)
    _ct_latest_permanent_change_design = latest_permanent_change_design_snapshot(_ct_permanent_change_design_history)
    st.subheader('1K-AH. 영구 변경 설계 / 기준 상태 고정 / 단계적 단계적 적용 / 이전 버전 복원 계획')
    pcd1, pcd2, pcd3, pcd4, pcd5, pcd6 = st.columns(6)
    pcd1.metric('설계 상태', _locale.code(_ct_permanent_change_design['design_state']))
    pcd2.metric('종결 출처', _locale.code(_ct_permanent_change_design['source_live_change_closure_integrity'] if _ct_permanent_change_design['source_live_change_closure_id'] else '아님 · 필요'))
    pcd3.metric('대상 범위', _locale.code('-' if _ct_permanent_change_design['design_state'] != 'PERMANENT_CHANGE_DESIGN_LOCKED' else f"{_ct_permanent_change_design['target_scope_pct']:.1%}"))
    pcd4.metric('초기 단계', _locale.code('-' if _ct_permanent_change_design['design_state'] != 'PERMANENT_CHANGE_DESIGN_LOCKED' else f"{_ct_permanent_change_design['initial_stage_scope_pct']:.1%}"))
    pcd5.metric('설계 허가', _locale.code(_ct_permanent_change_design['permanent_change_design_permission']))
    pcd6.metric('투자 실행 권한', '없음')
    pcda1, pcda2, pcda3, pcda4, pcda5 = st.columns(5)
    pcda1.metric('기준 상태', _locale.code('-' if _ct_permanent_change_design['baseline_value'] == 0 else f"{_ct_permanent_change_design['baseline_value']:.4f}"))
    pcda2.metric('후보', _locale.code('-' if _ct_permanent_change_design['candidate_value'] == 0 else f"{_ct_permanent_change_design['candidate_value']:.4f}"))
    pcda3.metric('이전 버전 복원 대상', _locale.code('-' if _ct_permanent_change_design['rollback_target_value'] == 0 else f"{_ct_permanent_change_design['rollback_target_value']:.4f}"))
    pcda4.metric('단계', _locale.code('-' if _ct_permanent_change_design['design_state'] != 'PERMANENT_CHANGE_DESIGN_LOCKED' else _ct_permanent_change_design['rollout_stage_count']))
    pcda5.metric('영구 적용 권한', '없음')
    _pcd_state = _ct_permanent_change_design['design_state']
    if _pcd_state == 'PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT':
        st.info('영구 변경 설계는 사용자 최종 정식 채택 종결이 ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW로 종료된 뒤 시작합니다. 현재 단계에서는 설계를 억지로 만들 필요가 없습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_NOT_REQUIRED':
        st.success('현재 사용자 종결 출처에서는 영구 변경 설계가 필요하지 않습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_DEFERRED':
        st.info('사용자 최종 정식 채택 검토가 보류 상태입니다. 새 투자 근거/제한 시험 주기 전에는 영구 변경 설계를 진행하지 않습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED':
        st.warning('영구 설계 검토 허가는 있으나 변경 불가 종결 출처가 없습니다. 먼저 1K-AG의 종결 상태 기록을 확인하세요.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW':
        st.error('사용자 종결 또는 영구 설계 출처 무결성이 일치하지 않아 설계를 차단했습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED':
        st.warning('새 사용자 종결 출처가 생겨 기존 영구 설계가 대체됨되었습니다. 현재 출처 기준으로 다시 설계하세요.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_REQUIRED':
        st.warning('사용자 영구 변경 설계 검토가 필요합니다. 이 단계는 단계적 단계적 적용/기준 상태/이전 버전 복원/모니터링을 설계할 뿐 실제 영구 적용을 승인하지 않습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_LOCKED':
        st.success('영구 변경 설계 고정됨 · 영구 · 설계 · 고정됨 · 금지 · 적용 허가만 부여됩니다. 별도 영구 변경 적용 사전 검사 전에는 실제 영구 변경을 적용하지 않습니다.')
    _locale.dataframe(st, _ct_permanent_change_design_queue, width='stretch', hide_index=True)
    if _ct_latest_permanent_change_design:
        _pcd_integrity = permanent_change_design_snapshot_integrity(_ct_latest_permanent_change_design)
        st.caption(f"최신 영구 변경 설계 · {_ct_latest_permanent_change_design.get('permanent_change_design_id', '')} · {_locale.code(_ct_latest_permanent_change_design.get('design_state', ''))} · 무결성 {_locale.code(_pcd_integrity['status'])}")
    if _pcd_state == 'PERMANENT_CHANGE_DESIGN_REQUIRED':
        _pcd_target_scope = st.number_input('영구 대상 범위', min_value=0.01, max_value=1.0, value=1.0, step=0.05, format='%.2f', key='permanent_change_target_scope')
        _pcd_stage_scope = st.number_input('초기 단계적 단계적 적용 범위', min_value=0.01, max_value=0.1, value=0.05, step=0.01, format='%.2f', key='permanent_change_initial_stage_scope')
        _pcd_stages = st.number_input('단계적 적용 단계 건수', min_value=2, max_value=10, value=3, step=1, key='permanent_change_rollout_stages')
        _pcd_proof_days = st.number_input('투자 근거 유효기간 (일수)', min_value=7, max_value=365, value=30, step=1, key='permanent_change_proof_clock_days')
        _pcd_min_outcomes = st.number_input('최소 변경 후 결과', min_value=5, max_value=100, value=5, step=1, key='permanent_change_min_outcomes')
        _pcd_degradation = st.number_input('최대 상대 오류 악화', min_value=0.0, max_value=0.1, value=0.03, step=0.01, format='%.2f', key='permanent_change_max_degradation')
        _pcd_rollback_hours = st.number_input('이전 버전 복원 관찰 기간 (시간)', min_value=24, max_value=720, value=72, step=24, key='permanent_change_rollback_hours')
        _pcd_design_detail = st.text_area('영구 변경 설계 상세', value='', key='permanent_change_design_detail', placeholder='기준·후보의 출처, 범위, 영구 반영이 타당한 이유와 설계에서 명시적으로 제외한 내용을 60자 이상 기록하세요.')
        _pcd_rollout_detail = st.text_area('단계적 단계적 적용 계획', value='', key='permanent_change_rollout_detail', placeholder='초기 단계 → 투자 근거 확인 → 다음 단계 상위 확인 요청 기준과 각 단계에서 자동 확대가 금지된다는 내용을 60자 이상 기록')
        _pcd_rollback_detail = st.text_area('영구 이전 버전 복원 계획', value='', key='permanent_change_rollback_detail', placeholder='악화/기준 이탈/무결성 실패 발생 시 이전 기준 상태 또는 이전 산출물로 복원하는 절차를 60자 이상 기록')
        _pcd_monitoring_detail = st.text_area('변경 후 모니터링 계획', value='', key='permanent_change_monitoring_detail', placeholder='투자 근거 유효기간, 변경 후 결과, 기준 이탈/품질 핵심 성과 지표, 추가-보류/이전 버전 복원 발동 조건을 60자 이상 기록')
        _pcd_c1 = st.checkbox('현재 변경 불가 사용자 최종 정식 채택 종결 출처 식별번호/무결성 해시/무결성을 검토했습니다.', key='permanent_change_source_reviewed')
        _pcd_c2 = st.checkbox('제한 시험의 사전 변경 후 투자 근거와 사용자 종결 근거를 검토했습니다.', key='permanent_change_evidence_reviewed')
        _pcd_c3 = st.checkbox('이전 기준 상태/이전 버전 복원 대상을 현재 변경 불가 출처에 고정했습니다.', key='permanent_change_baseline_locked')
        _pcd_c4 = st.checkbox('영구 후보 매개변수/모형 산출물 식별 정보를 검증했습니다.', key='permanent_change_candidate_verified')
        _pcd_c5 = st.checkbox('전체-범위 전환이 아닌 단계적 단계적 적용을 사용하며 각 단계는 투자 근거 후에만 다음 단계로 진행함을 확인했습니다.', key='permanent_change_staged_rollout')
        _pcd_c6 = st.checkbox('각 단계적 적용 단계가 복원 가능한하며 복원할 수 없는 일방향 운영 전환을 금지함을 확인했습니다.', key='permanent_change_reversible')
        _pcd_c7 = st.checkbox('이전 기준 상태/산출물로의 이전 버전 복원 경로와 관찰 기간을 확인했습니다.', key='permanent_change_rollback_path')
        _pcd_c8 = st.checkbox('투자 근거 유효기간, 변경 후 결과, 기준 이탈/악화 모니터링 계획을 확인했습니다.', key='permanent_change_monitoring_plan')
        _pcd_c9 = st.checkbox('이 설계 고정과 실제 영구 적용 사이에 별도 사용자 적용 점검이 필요함을 확인했습니다.', key='permanent_change_separate_apply_gate')
        _pcd_c10 = st.checkbox('이 설계 저장이 영구 매개변수/모형 적용을 승인하지 않음을 확인했습니다.', key='permanent_change_no_apply')
        _pcd_c11 = st.checkbox('이 설계 저장이 자동 재보정을 승인하지 않음을 확인했습니다.', key='permanent_change_no_recal')
        _pcd_c12 = st.checkbox('이 설계 저장이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='permanent_change_no_capacity')
        _pcd_c13 = st.checkbox('이 설계 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='permanent_change_no_execution')
        _pcd_c14 = st.checkbox('현재 영구 변경 설계를 최종 사용자 검토했습니다.', key='permanent_change_human_review')
        _pcd_note = st.text_input('영구 변경 설계 상태 기록 메모', value='', key='permanent_change_design_note', placeholder='예: 단계적 영구 설계 전용 / 금지 적용')
        if st.button('운영 처리 흐름 영구 변경 설계 고정 저장', key='permanent_change_design_save'):
            try:
                _pcd_row = build_flow_permanent_change_design_lock(_ct_permanent_change_design, target_scope_pct=_pcd_target_scope, initial_stage_scope_pct=_pcd_stage_scope, rollout_stage_count=int(_pcd_stages), proof_clock_days=int(_pcd_proof_days), min_post_change_outcomes=int(_pcd_min_outcomes), max_relative_error_degradation_pct=_pcd_degradation, rollback_observation_hours=int(_pcd_rollback_hours), design_detail=_pcd_design_detail, rollout_detail=_pcd_rollout_detail, rollback_detail=_pcd_rollback_detail, monitoring_detail=_pcd_monitoring_detail, source_reviewed=_pcd_c1, post_change_evidence_reviewed=_pcd_c2, baseline_locked_confirmed=_pcd_c3, candidate_artifact_verified=_pcd_c4, staged_rollout_confirmed=_pcd_c5, reversible_rollout_confirmed=_pcd_c6, rollback_path_confirmed=_pcd_c7, monitoring_plan_confirmed=_pcd_c8, separate_apply_gate_required_confirmed=_pcd_c9, no_permanent_apply_confirmed=_pcd_c10, no_auto_recalibration_confirmed=_pcd_c11, no_auto_capacity_confirmed=_pcd_c12, no_execution_authorization_confirmed=_pcd_c13, human_review_confirmed=_pcd_c14, note=_pcd_note)
                _pcd_hist = load_csv('operations_flow_permanent_change_design_snapshots.csv')
                for _col in FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS:
                    if _col not in _pcd_hist.columns:
                        _pcd_hist[_col] = ''
                _pcd_hist = pd.concat([_pcd_hist[FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS], pd.DataFrame([_pcd_row])], ignore_index=True)
                verified_save_feedback(_pcd_hist, 'operations_flow_permanent_change_design_snapshots.csv', f"Permanent Change Design 저장 · {_pcd_row['design_state']} · Target {_pcd_row['target_scope_pct']:.1%} · Stage1 {_pcd_row['initial_stage_scope_pct']:.1%} · Permission {_pcd_row['permanent_change_design_permission']} · Permanent Change Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('영구 변경 설계는 사용자 종결 수락 이후 기준 상태/후보/이전 버전 복원/단계적 단계적 적용을 고정하는 단계입니다. DESIGN_LOCKED는 실제 영구 적용이 아니며 별도 영구 변경 적용 사전 검사가 필요합니다.')
    _ct_permanent_change_apply_history = load_csv('operations_flow_permanent_change_apply_snapshots.csv')
    _ct_permanent_change_apply = build_flow_permanent_change_apply(_ct_permanent_change_design, _ct_permanent_change_design_history, _ct_permanent_change_apply_history)
    _ct_permanent_change_apply_queue = build_flow_permanent_change_apply_queue(_ct_permanent_change_apply)
    _ct_latest_permanent_change_apply = latest_permanent_change_apply_snapshot(_ct_permanent_change_apply_history)
    st.subheader('1K-AI. 영구 변경 적용 사전 검사 / 사용자 1단계 허가 / 자동 적용 금지 보호 점검')
    pca1, pca2, pca3, pca4, pca5, pca6 = st.columns(6)
    pca1.metric('적용 상태', _locale.code(_ct_permanent_change_apply['apply_state']))
    pca2.metric('판단', _locale.code(_ct_permanent_change_apply['apply_decision'] or '-'))
    pca3.metric('허가 단계', _locale.code('-' if _ct_permanent_change_apply['permit_stage_number'] == 0 else _ct_permanent_change_apply['permit_stage_number']))
    pca4.metric('허가 범위', _locale.code('-' if _ct_permanent_change_apply['permit_scope_pct'] == 0 else f"{_ct_permanent_change_apply['permit_scope_pct']:.1%}"))
    pca5.metric('적용 허가', _locale.code(_ct_permanent_change_apply['permanent_change_apply_permission']))
    pca6.metric('투자 실행 권한', '없음')
    pcaa1, pcaa2, pcaa3, pcaa4, pcaa5 = st.columns(5)
    pcaa1.metric('기준 상태', _locale.code('-' if _ct_permanent_change_apply['baseline_value'] == 0 else f"{_ct_permanent_change_apply['baseline_value']:.4f}"))
    pcaa2.metric('후보', _locale.code('-' if _ct_permanent_change_apply['candidate_value'] == 0 else f"{_ct_permanent_change_apply['candidate_value']:.4f}"))
    pcaa3.metric('이전 버전 복원 대상', _locale.code('-' if _ct_permanent_change_apply['rollback_target_value'] == 0 else f"{_ct_permanent_change_apply['rollback_target_value']:.4f}"))
    pcaa4.metric('시작 기간', _locale.code('-' if _ct_permanent_change_apply['permit_activation_window_hours'] == 0 else f"{_ct_permanent_change_apply['permit_activation_window_hours']}h"))
    pcaa5.metric('영구 적용 권한', '없음')
    _pca_state = _ct_permanent_change_apply['apply_state']
    if _pca_state == 'PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT':
        st.info('영구 변경 적용 검토는 영구 변경 설계가 고정됨 된 뒤 시작합니다. 현재 단계에서는 적용 판단을 억지로 만들 필요가 없습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_NOT_REQUIRED':
        st.success('현재 영구 설계 출처에서는 적용 검토가 필요하지 않습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_DEFERRED':
        st.info('사용자 영구 변경 적용 검토 = 보류 · 조건/투자 근거 갱신 전에는 실제 변경을 허용하지 않습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED':
        st.warning('고정됨 설계 상태이나 변경 불가 설계 출처가 없습니다. 먼저 1K-AH 영구 변경 설계 상태 기록을 확인하세요.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW':
        st.error('영구 설계 또는 적용 검증 무결성이 일치하지 않아 적용 검토를 차단했습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED':
        st.warning('사용자 영구 변경 적용 사전 검사가 필요합니다. 허용되는 허가는 MANUAL_PERMANENT_STAGE1_APPLY_ONLY뿐이며 자동 단계 상위 확인 요청은 금지됩니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED':
        st.warning('새 영구 설계가 생겨 기존 적용 판단이 대체됨되었습니다. 현재 설계 출처 기준으로 다시 사용자 검토하세요.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY':
        st.success('수동 영구 1단계 적용 허가 발급됨 · 이 허가는 외부/수동 1단계 시작만 허용합니다. 영구 적용 권한/실행 환경 권한/투자 실행 권한은 없음입니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_REJECTED':
        st.info('사용자 영구 변경 적용 판단 = 거절 · 실제 영구 적용은 없습니다.')
    _locale.dataframe(st, _ct_permanent_change_apply_queue, width='stretch', hide_index=True)
    if _ct_latest_permanent_change_apply:
        _pca_integrity = permanent_change_apply_snapshot_integrity(_ct_latest_permanent_change_apply)
        st.caption(f"최신 영구 변경 적용 · {_ct_latest_permanent_change_apply.get('permanent_change_apply_id', '')} · {_ct_latest_permanent_change_apply.get('apply_decision', '')} · 무결성 {_locale.code(_pca_integrity['status'])}")
    if _pca_state == 'PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED':
        _pca_decision = st.selectbox('사용자 영구 변경 적용 판단', ['ISSUE_MANUAL_STAGE1_APPLY_PERMIT', 'REJECT', 'DEFER'], key='permanent_change_apply_decision', format_func=_locale.option())
        _pca_scope_max = max(0.01, float(_ct_permanent_change_apply['initial_stage_scope_pct']))
        _pca_scope = st.number_input('1단계 허가 범위', min_value=0.01, max_value=float(min(0.1, _pca_scope_max)), value=float(min(0.05, _pca_scope_max)), step=0.01, format='%.2f', key='permanent_change_apply_scope')
        _pca_window = st.number_input('수동 시작 기간 (시간)', min_value=1, max_value=168, value=24, step=1, key='permanent_change_apply_window')
        _pca_detail = st.text_area('영구 변경 적용 검토 근거', value='', key='permanent_change_apply_detail', placeholder='고정됨 설계, 기준 상태/후보/산출물, 1단계 범위, 이전 버전 복원/모니터링 준비 상태, 수동 외부 적용 전용, 금지 자동 상위 확인 요청을 60자 이상 기록')
        _pca_c1 = st.checkbox('현재 변경 불가 영구 변경 설계 출처 식별번호/무결성 해시/무결성을 검토했습니다.', key='permanent_apply_design_source_reviewed')
        _pca_c2 = st.checkbox('영구 변경 설계 검증 무결성과 영구 · 설계 · 고정됨 · 금지 · 적용 허가를 검증했습니다.', key='permanent_apply_design_integrity')
        _pca_c3 = st.checkbox('이전 기준 상태/이전 버전 복원 대상이 여전히 현재 출처와 일치함을 재검증했습니다.', key='permanent_apply_baseline_revalidated')
        _pca_c4 = st.checkbox('영구 후보 매개변수/모형 산출물 식별 정보를 재검증했습니다.', key='permanent_apply_candidate_verified')
        _pca_c5 = st.checkbox('허가 범위가 고정됨 초기 단계 범위 이하임을 확인했습니다.', key='permanent_apply_stage1_scope')
        _pca_c6 = st.checkbox('1단계 단계적 적용이 다른 단계와 격리되며 자동 확대되지 않음을 확인했습니다.', key='permanent_apply_stage_isolation')
        _pca_c7 = st.checkbox('수동 시작 기간과 변경 가능 시간을 검토했습니다.', key='permanent_apply_change_window')
        _pca_c8 = st.checkbox('이전 기준 상태/산출물 이전 버전 복원 경로와 이전 버전 복원 관찰 기간이 준비되어 있음을 확인했습니다.', key='permanent_apply_rollback_ready')
        _pca_c9 = st.checkbox('투자 근거 유효기간, 변경 후 결과, 기준 이탈/악화 모니터링이 준비되어 있음을 확인했습니다.', key='permanent_apply_monitoring_ready')
        _pca_c10 = st.checkbox('실제 1단계 적용은 이 운영 시스템이 자동 수행하지 않고 외부에서 수동으로 수행함을 확인했습니다.', key='permanent_apply_manual_external')
        _pca_c11 = st.checkbox('1단계 성공이 다음 단계로 자동 상위 확인 요청되지 않음을 확인했습니다.', key='permanent_apply_no_auto_stage')
        _pca_c12 = st.checkbox('이 허가 저장이 전체-범위 영구 적용을 자동 승인하지 않음을 확인했습니다.', key='permanent_apply_no_auto_permanent')
        _pca_c13 = st.checkbox('이 허가 저장이 자동 재보정을 승인하지 않음을 확인했습니다.', key='permanent_apply_no_recal')
        _pca_c14 = st.checkbox('이 허가 저장이 자동 처리 용량 변경을 승인하지 않음을 확인했습니다.', key='permanent_apply_no_capacity')
        _pca_c15 = st.checkbox('이 허가 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='permanent_apply_no_execution')
        _pca_c16 = st.checkbox('현재 영구 변경 적용 판단을 최종 사용자 검토했습니다.', key='permanent_apply_human_review')
        _pca_note = st.text_input('영구 변경 적용 상태 기록 메모', value='', key='permanent_change_apply_note', placeholder='예: 수동 1단계 허가 전용 / 거절 / 보류')
        if st.button('운영 처리 흐름 영구 변경 적용 판단 저장', key='permanent_change_apply_save'):
            try:
                _pca_row = build_flow_permanent_change_apply_lock(_ct_permanent_change_apply, apply_decision=_pca_decision, permit_scope_pct=_pca_scope, permit_activation_window_hours=int(_pca_window), apply_detail=_pca_detail, design_source_reviewed=_pca_c1, design_integrity_verified=_pca_c2, baseline_revalidated_confirmed=_pca_c3, candidate_artifact_verified=_pca_c4, stage1_scope_confirmed=_pca_c5, staged_rollout_isolation_confirmed=_pca_c6, change_window_reviewed=_pca_c7, rollback_ready_confirmed=_pca_c8, monitoring_ready_confirmed=_pca_c9, manual_external_apply_only_confirmed=_pca_c10, no_auto_stage_escalation_confirmed=_pca_c11, no_auto_permanent_apply_confirmed=_pca_c12, no_auto_recalibration_confirmed=_pca_c13, no_auto_capacity_confirmed=_pca_c14, no_execution_authorization_confirmed=_pca_c15, human_review_confirmed=_pca_c16, note=_pca_note)
                _pca_hist = load_csv('operations_flow_permanent_change_apply_snapshots.csv')
                for _col in FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS:
                    if _col not in _pca_hist.columns:
                        _pca_hist[_col] = ''
                _pca_hist = pd.concat([_pca_hist[FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS], pd.DataFrame([_pca_row])], ignore_index=True)
                verified_save_feedback(_pca_hist, 'operations_flow_permanent_change_apply_snapshots.csv', f"Permanent Change Apply 저장 · {_pca_row['apply_decision']} · {_pca_row['apply_state']} · Permission {_pca_row['permanent_change_apply_permission']} · Permanent Change Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('영구 변경 적용 사전 검사는 고정됨 영구 설계에서 1단계 수동 허가만 검토합니다. ISSUE_MANUAL_STAGE1_APPLY_PERMIT도 실제 변경을 수행하지 않으며 별도 영구 실행 환경/시작 점검이 필요합니다.')
    _ct_permanent_change_runtime_history = load_csv('operations_flow_permanent_change_runtime_events.csv')
    _ct_permanent_change_runtime = build_flow_permanent_change_runtime(_ct_permanent_change_apply, _ct_permanent_change_apply_history, _ct_permanent_change_runtime_history)
    _ct_permanent_change_runtime_queue = build_flow_permanent_change_runtime_queue(_ct_permanent_change_runtime)
    _ct_latest_permanent_change_runtime = latest_permanent_change_runtime_event(_ct_permanent_change_runtime_history)
    st.subheader('1K-AJ. 영구 변경 실행 환경 / 외부 수동 1단계 시작 / 긴급 중단 / 이전 버전 복원 보호 점검')
    pcr1, pcr2, pcr3, pcr4, pcr5, pcr6 = st.columns(6)
    pcr1.metric('실행 환경 상태', _locale.code(_ct_permanent_change_runtime['runtime_state']))
    pcr2.metric('실행 환경 기록', _locale.code(_ct_permanent_change_runtime['runtime_event'] or '-'))
    pcr3.metric('1단계 범위', _locale.code('-' if _ct_permanent_change_runtime['permit_scope_pct'] == 0 else f"{_ct_permanent_change_runtime['permit_scope_pct']:.1%}"))
    pcr4.metric('시작 접수', _locale.code(_ct_permanent_change_runtime['activation_receipt_ref'] or '-'))
    pcr5.metric('실행 환경 허가', _locale.code(_ct_permanent_change_runtime['permanent_change_runtime_permission']))
    pcr6.metric('투자 실행 권한', '없음')
    pcra1, pcra2, pcra3, pcra4, pcra5 = st.columns(5)
    pcra1.metric('기준 상태', _locale.code('-' if _ct_permanent_change_runtime['baseline_value'] == 0 else f"{_ct_permanent_change_runtime['baseline_value']:.4f}"))
    pcra2.metric('후보', _locale.code('-' if _ct_permanent_change_runtime['candidate_value'] == 0 else f"{_ct_permanent_change_runtime['candidate_value']:.4f}"))
    pcra3.metric('관찰된 사전', _locale.code('-' if _ct_permanent_change_runtime['observed_pre_value'] == 0 else f"{_ct_permanent_change_runtime['observed_pre_value']:.4f}"))
    pcra4.metric('관찰된 사후/현재', _locale.code('-' if _ct_permanent_change_runtime['observed_post_value'] == 0 and _ct_permanent_change_runtime['observed_current_value'] == 0 else f"{max(_ct_permanent_change_runtime['observed_post_value'], _ct_permanent_change_runtime['observed_current_value']):.4f}"))
    pcra5.metric('이전 버전 복원', _locale.code('필요' if _ct_permanent_change_runtime['rollback_required'] else '확인됨' if _ct_permanent_change_runtime['rollback_confirmed'] else '실행 준비됨'))
    _pcr_state = _ct_permanent_change_runtime['runtime_state']
    if _pcr_state == 'PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT':
        st.info('영구 변경 실행 환경은 수동 · 영구 · 1단계 · 적용 · 전용 허가가 발급된 뒤 시작합니다. 현재 단계에서는 시작 기록을 만들 필요가 없습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION':
        st.warning('1단계 시작 준비 상태입니다. 실제 변경은 운영 시스템이 수행하지 않습니다. 외부에서 수동 시작을 수행한 뒤 접수와 관찰된 사전/사후 투자 근거만 기록합니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1':
        st.warning('영구 1단계 활성 · 이전 버전 복원 실행 준비됨 · 자동 2단계 상위 확인 요청 및 전체-범위 영구 적용은 금지됩니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED':
        st.success('1단계 실행 환경 종료 · 별도 결과 검토 전에는 2단계로 자동 확대하지 않습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED':
        st.error('긴급 중단 중단 상태 유지 · 외부 수동 이전 버전 복원 후 기준 상태 복원을 검증해야 합니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED':
        st.success('이전 버전 복원 확인됨 · 새 영구 설계/적용 검토 없이 재활성화하지 않습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED':
        st.warning('새 영구 적용 허가가 생겨 기존 실행 환경 기록이 대체됨되었습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW':
        st.error('적용 허가 또는 실행 환경 기록 무결성 불일치로 실행 환경을 차단했습니다.')
    _locale.dataframe(st, _ct_permanent_change_runtime_queue, width='stretch', hide_index=True)
    if _ct_latest_permanent_change_runtime:
        _pcr_integrity = permanent_change_runtime_event_integrity(_ct_latest_permanent_change_runtime)
        st.caption(f"최신 영구 실행 환경 · {_ct_latest_permanent_change_runtime.get('permanent_change_runtime_event_id', '')} · {_ct_latest_permanent_change_runtime.get('runtime_event', '')} · 무결성 {_locale.code(_pcr_integrity['status'])}")
    if _pcr_state == 'PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION':
        _pcr_receipt = st.text_input('외부 수동 시작 접수 / 참조', value='', key='permanent_runtime_activation_receipt', placeholder='예: OPS-변경-20261004-001')
        _pcr_pre = st.number_input('관찰된 사전-시작 값', value=float(_ct_permanent_change_runtime['baseline_value']), format='%.6f', key='permanent_runtime_observed_pre')
        _pcr_post = st.number_input('관찰된 사후-시작 값', value=float(_ct_permanent_change_runtime['candidate_value']), format='%.6f', key='permanent_runtime_observed_post')
        _pcr_detail = st.text_area('1단계 시작 투자 근거 / 근거', value='', key='permanent_runtime_activation_detail', placeholder='외부 수동 시작, 출처 허가, 관찰된 기준 상태/후보, 범위 격리, 모니터링/이전 버전 복원 준비 상태를 60자 이상 기록')
        _pcr_c1 = st.checkbox('실제 1단계 변경은 이 운영 시스템이 아니라 외부에서 수동으로 수행되었음을 확인했습니다.', key='permanent_runtime_external_manual')
        _pcr_c2 = st.checkbox('현재 변경 불가 영구 적용 허가 식별번호/무결성 해시/무결성을 검토했습니다.', key='permanent_runtime_source_permit')
        _pcr_c3 = st.checkbox('관찰된 사전-시작 값이 고정됨 기준 상태와 일치함을 확인했습니다.', key='permanent_runtime_baseline_obs')
        _pcr_c4 = st.checkbox('관찰된 사후-시작 값/후보 산출물이 고정됨 후보와 일치함을 확인했습니다.', key='permanent_runtime_candidate_obs')
        _pcr_c5 = st.checkbox('1단계 범위가 허가 범위 안에서 격리되어 있음을 확인했습니다.', key='permanent_runtime_scope_isolation')
        _pcr_c6 = st.checkbox('1단계 모니터링과 이전 버전 복원 준비 상태가 활성화되어 있음을 확인했습니다.', key='permanent_runtime_monitoring')
        _pcr_c7 = st.checkbox('1단계 성공이 2단계로 자동 상위 확인 요청되지 않음을 확인했습니다.', key='permanent_runtime_no_auto_stage')
        _pcr_c8 = st.checkbox('이 실행 환경 기록이 전체-범위 영구 적용을 자동 승인하지 않음을 확인했습니다.', key='permanent_runtime_no_auto_perm')
        _pcr_c9 = st.checkbox('현재 시작 투자 근거를 최종 사용자 검토했습니다.', key='permanent_runtime_human_review')
        _pcr_note = st.text_input('영구 실행 환경 기록 메모', value='', key='permanent_runtime_event_note')
        if st.button('영구 1단계 활성화 기록 저장', key='permanent_runtime_activate'):
            try:
                _pcr_row = build_flow_permanent_change_runtime_event(_ct_permanent_change_runtime, runtime_event='ACTIVATE', activation_receipt_ref=_pcr_receipt, observed_pre_value=_pcr_pre, observed_post_value=_pcr_post, runtime_detail=_pcr_detail, external_manual_activation_confirmed=_pcr_c1, source_permit_reviewed=_pcr_c2, baseline_observation_confirmed=_pcr_c3, candidate_observation_confirmed=_pcr_c4, scope_isolation_confirmed=_pcr_c5, monitoring_active_confirmed=_pcr_c6, no_auto_stage_escalation_confirmed=_pcr_c7, no_auto_permanent_apply_confirmed=_pcr_c8, human_review_confirmed=_pcr_c9, note=_pcr_note)
                _pcr_hist = load_csv('operations_flow_permanent_change_runtime_events.csv')
                for _col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
                    if _col not in _pcr_hist.columns:
                        _pcr_hist[_col] = ''
                _pcr_hist = pd.concat([_pcr_hist[FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS], pd.DataFrame([_pcr_row])], ignore_index=True)
                verified_save_feedback(_pcr_hist, 'operations_flow_permanent_change_runtime_events.csv', f"Permanent Runtime ACTIVATE 저장 · {_pcr_row['runtime_state']} · Stage {_pcr_row['permit_stage_number']} · Scope {_pcr_row['permit_scope_pct']:.1%} · Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1':
        _pcr_action = st.selectbox('1단계 실행 환경 기록', ['CLOSE', 'KILL_SWITCH'], key='permanent_runtime_active_action', format_func=_locale.option())
        _pcr_current = st.number_input('관찰된 현재 값', value=float(_ct_permanent_change_runtime['candidate_value']), format='%.6f', key='permanent_runtime_observed_current')
        _pcr_trigger = st.selectbox('긴급 중단 발동 조건', [''] + sorted(PERMANENT_CHANGE_KILL_TRIGGERS), key='permanent_runtime_kill_trigger')
        _pcr_detail = st.text_area('실행 환경 종료 / 긴급 중단 투자 근거', value='', key='permanent_runtime_active_detail', placeholder='종료면 1단계 투자 근거/결과-검토 인계를, KILL_SWITCH면 발동 조건과 이전 버전 복원 시작을 60자 이상 기록')
        _pcr_monitor = st.checkbox('현재 모니터링 투자 근거를 검토했습니다.', key='permanent_runtime_active_monitor')
        _pcr_scope = st.checkbox('1단계 범위 격리가 유지되었음을 확인했습니다.', key='permanent_runtime_active_scope')
        _pcr_no_stage = st.checkbox('2단계 자동 상위 확인 요청이 없음을 확인했습니다.', key='permanent_runtime_active_no_stage')
        _pcr_no_perm = st.checkbox('전체-범위 영구 적용 자동 승인이 없음을 확인했습니다.', key='permanent_runtime_active_no_perm')
        _pcr_rollback_start = st.checkbox('긴급 중단 선택 시 외부 수동 이전 버전 복원을 즉시 시작했음을 확인했습니다.', key='permanent_runtime_rollback_start')
        _pcr_human = st.checkbox('현재 실행 환경 기록을 최종 사용자 검토했습니다.', key='permanent_runtime_active_human')
        if st.button('영구 1단계 실행 환경 기록 저장', key='permanent_runtime_active_save'):
            try:
                _pcr_row = build_flow_permanent_change_runtime_event(_ct_permanent_change_runtime, runtime_event=_pcr_action, observed_current_value=_pcr_current, kill_switch_trigger=_pcr_trigger, runtime_detail=_pcr_detail, scope_isolation_confirmed=_pcr_scope, monitoring_active_confirmed=_pcr_monitor, no_auto_stage_escalation_confirmed=_pcr_no_stage, no_auto_permanent_apply_confirmed=_pcr_no_perm, rollback_initiated_confirmed=_pcr_rollback_start, human_review_confirmed=_pcr_human)
                _pcr_hist = load_csv('operations_flow_permanent_change_runtime_events.csv')
                for _col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
                    if _col not in _pcr_hist.columns:
                        _pcr_hist[_col] = ''
                _pcr_hist = pd.concat([_pcr_hist[FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS], pd.DataFrame([_pcr_row])], ignore_index=True)
                verified_save_feedback(_pcr_hist, 'operations_flow_permanent_change_runtime_events.csv', f"Permanent Runtime {_pcr_row['runtime_event']} 저장 · {_pcr_row['runtime_state']} · Permanent Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED':
        _pcr_restored = st.number_input('관찰된 복원됨 값', value=float(_ct_permanent_change_runtime['rollback_target_value']), format='%.6f', key='permanent_runtime_restored_value')
        _pcr_detail = st.text_area('이전 버전 복원 완료 / 기준 상태 복원 투자 근거', value='', key='permanent_runtime_rollback_detail', placeholder='외부 수동 이전 버전 복원 완료, 복원됨 기준 상태, 무결성/모니터링 상태를 60자 이상 기록')
        _pcr_done = st.checkbox('외부 수동 이전 버전 복원이 완료되었음을 확인했습니다.', key='permanent_runtime_rollback_done')
        _pcr_baseline = st.checkbox('관찰된 복원됨 값이 고정됨 이전 버전 복원 대상/기준 상태와 일치함을 확인했습니다.', key='permanent_runtime_rollback_baseline')
        _pcr_no_stage = st.checkbox('이전 버전 복원 후 자동 단계 상위 확인 요청이 없음을 확인했습니다.', key='permanent_runtime_rollback_no_stage')
        _pcr_no_perm = st.checkbox('이전 버전 복원 후 자동 영구 적용이 없음을 확인했습니다.', key='permanent_runtime_rollback_no_perm')
        _pcr_human = st.checkbox('이전 버전 복원 완료 투자 근거를 최종 사용자 검토했습니다.', key='permanent_runtime_rollback_human')
        if st.button('영구 실행 환경 이전 버전 복원 · 확인 저장', key='permanent_runtime_rollback_confirm'):
            try:
                _pcr_row = build_flow_permanent_change_runtime_event(_ct_permanent_change_runtime, runtime_event='ROLLBACK_CONFIRM', observed_restored_value=_pcr_restored, runtime_detail=_pcr_detail, no_auto_stage_escalation_confirmed=_pcr_no_stage, no_auto_permanent_apply_confirmed=_pcr_no_perm, rollback_completed_confirmed=_pcr_done, baseline_restore_confirmed=_pcr_baseline, human_review_confirmed=_pcr_human)
                _pcr_hist = load_csv('operations_flow_permanent_change_runtime_events.csv')
                for _col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
                    if _col not in _pcr_hist.columns:
                        _pcr_hist[_col] = ''
                _pcr_hist = pd.concat([_pcr_hist[FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS], pd.DataFrame([_pcr_row])], ignore_index=True)
                verified_save_feedback(_pcr_hist, 'operations_flow_permanent_change_runtime_events.csv', f"Permanent Runtime ROLLBACK_CONFIRM 저장 · restored {_pcr_row['observed_restored_value']:.4f} · Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(_locale.message(str(exc)))
    st.caption('v1.53 영구 실행 환경은 자동 변경 엔진이 아닙니다. 활성화는 외부 수동 시작 접수/투자 근거를 기록하고, 종료/긴급 중단 · 전환/ROLLBACK_CONFIRM도 변경 불가 투자 근거 등록부만 수행합니다. 영구 실행 환경 권한과 투자 실행 권한은 없음입니다.')
    st.subheader('2. 오늘의 안전한 운영 순서')
    _ct_sequence = build_daily_operating_sequence(_ct_tower)
    _locale.dataframe(st, _ct_sequence, width='stretch', hide_index=True)
    st.subheader('3. 핵심 점검 상태 기록')
    cg1, cg2, cg3, cg4 = st.columns(4)
    cg1.metric('학습', _locale.code(_ct_learning['release_gate']))
    cg2.metric('예측', _locale.code(_ct_forecast['release_gate']))
    cg3.metric('복구', _locale.code(_ct_recovery['recovery_release']['release_gate']))
    cg4.metric('저장 구조', _locale.code(_ct_schema_release['release_gate']))
    cg5, cg6, cg7, cg8 = st.columns(4)
    cg5.metric('통합', _locale.code(_ct_integration_summary['status']))
    cg6.metric('표 데이터 실패', _locale.code(_ct_csv_fail))
    cg7.metric('기한 초과', _locale.code(_ct_queue_summary['overdue']))
    cg8.metric('오늘 / 지금 확인', _locale.code(_ct_queue_summary['attention_now']))
    st.caption('제어 종합 관리는 기존 원본 점검을 복제해 승인하지 않습니다. 원본 화면의 상태를 압축해 어디를 먼저 볼지 안내하며 주문/매매를 실행하지 않습니다.')
