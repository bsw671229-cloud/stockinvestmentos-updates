from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('조건 검색')
    st.caption('후보 선별 점수는 후보 압축용입니다. 생존/하락 시나리오/투자 근거/가치 평가 검토를 대체하지 않습니다.')
    edited = _locale.editor(st, watchlist, num_rows='dynamic', width='stretch', key='watch_editor')
    if st.button('관심종목 저장'):
        verified_save_feedback(edited, 'watchlist.csv', 'Watchlist를 저장했습니다.')
    if not edited.empty:
        screened = screen_candidates(edited)
        cols = [c for c in ['name', 'survival_pass', 'quality_score', 'risk_penalty', 'triage_score', 'normalized_fcf_yield', 'roic', 'iroic', 'bear_downside'] if c in screened.columns]
        _locale.dataframe(st, screened[cols], width='stretch', hide_index=True)
