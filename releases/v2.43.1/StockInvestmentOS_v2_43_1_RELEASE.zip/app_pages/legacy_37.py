from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('자본 이동')
    st.caption('다음 1원을 어디에 둘지 비교합니다. 기존 종목을 줄였다고 자금 수령 자산을 자동으로 사지 않으며, 적격 자금 수령 자산이 없으면 현금이 대기 장소가 될 수 있습니다.')
    st.markdown('**초보자용 순서:** `Donor 선택 → 기존 Factor Breach 확인 → Recipient 자격 → Cash/재배분 효과 → Forward ER → Net Switching Gap → 최종 검토`')
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap) if not watchlist.empty else pd.DataFrame()
    plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    thesis_df = build_thesis_monitor(watchlist, state_df, plans, kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120))) if not watchlist.empty else pd.DataFrame()
    current_cash = portfolio_cash_krw(portfolio, total_assets)
    donor_holdings = []
    if not portfolio.empty:
        ptmp = portfolio.copy()
        if 'asset_type' not in ptmp.columns:
            ptmp['asset_type'] = ''
        if 'name' not in ptmp.columns:
            ptmp['name'] = ''
        cash_mask = ptmp['asset_type'].fillna('').astype(str).str.lower().eq('cash') | ptmp['name'].fillna('').astype(str).str.strip().isin(['현금', 'CASH', 'Cash'])
        donor_holdings = [x for x in ptmp.loc[~cash_mask, 'name'].fillna('').astype(str).tolist() if str(x).strip()]
        donor_holdings = list(dict.fromkeys(donor_holdings))
    donor_options = ['현금 (CASH)'] + donor_holdings
    recipient_options = ['현금 (CASH)'] + (list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist())) if not watchlist.empty else [])
    if st.session_state.get('migration_donor') not in donor_options:
        st.session_state['migration_donor'] = donor_options[0]
    if st.session_state.get('migration_recipient') not in recipient_options:
        st.session_state['migration_recipient'] = recipient_options[0]
    handoff_source = str(st.session_state.get('migration_handoff_source', '') or '').strip()
    if handoff_source:
        st.info(f'**{handoff_source}에서 연결됨** · 자금 제공 자산과 이동 검토금액을 이어받았습니다. 자금 수령 자산은 우선 현금으로 검토한 뒤 같은 화면에서 다른 종목으로 바꿔 비교할 수 있습니다.')
        _handoff_origin_donor = str(st.session_state.get('migration_handoff_donor_original', st.session_state.get('migration_donor', '')) or '').strip()
        _handoff_origin_amount = float(st.session_state.get('migration_handoff_amount_original', st.session_state.get('migration_amount_krw', 0.0)) or 0.0)
        _handoff_created = str(st.session_state.get('migration_handoff_created_at', '') or '').strip()
        st.caption(f"인계 원본 · 자금 제공 자산 {_handoff_origin_donor or '-'} · 금액 {_handoff_origin_amount:,.0f}원" + (f' · {_handoff_created}' if _handoff_created else ''))
    st.subheader('1. 자금 제공 자산 / 자금 수령 자산 선택')
    dcol, rcol = st.columns(2)
    donor_choice = dcol.selectbox('자금 제공 자산 · 돈이 나오는 곳', donor_options, key='migration_donor', help='현재 보유종목 또는 현금을 선택합니다.')
    recipient_choice = rcol.selectbox('자금 수령 자산 · 돈이 가는 곳', recipient_options, key='migration_recipient', help='관심종목 종목 또는 현금을 선택합니다.')
    donor_kind = 'CASH' if donor_choice == '현금 (CASH)' else 'SECURITY'
    recipient_kind = 'CASH' if recipient_choice == '현금 (CASH)' else 'SECURITY'
    donor_available = current_cash if donor_kind == 'CASH' else 0.0
    donor_downside = 0.0
    donor_lifecycle = 'CASH' if donor_kind == 'CASH' else 'UNTRACKED'
    donor_ticker = ''
    donor_primary_factor = ''
    if donor_kind == 'SECURITY' and (not portfolio.empty):
        dhit = portfolio.loc[portfolio['name'].fillna('').astype(str).eq(str(donor_choice))]
        if not dhit.empty:
            vals = pd.to_numeric(dhit.get('current_value_krw', pd.Series(index=dhit.index, dtype=float)), errors='coerce').fillna(0.0).clip(lower=0.0)
            donor_available = float(vals.sum())
            ddowns = pd.to_numeric(dhit.get('bear_downside', pd.Series(index=dhit.index, dtype=float)), errors='coerce').fillna(0.0).clip(lower=0.0)
            if vals.sum() > 0:
                donor_downside = float((ddowns * vals).sum() / vals.sum())
            elif len(ddowns):
                donor_downside = float(ddowns.iloc[0])
            donor_ticker = str(dhit.iloc[0].get('ticker', '') or '').strip()
            donor_primary_factor = str(dhit.iloc[0].get('factor', '') or '').strip()
        if not state_df.empty and 'name' in state_df.columns:
            ds = state_df.loc[state_df['name'].fillna('').astype(str).eq(str(donor_choice))]
            if not ds.empty:
                donor_lifecycle = str(ds.iloc[0].get('lifecycle_state', 'UNTRACKED'))
    recipient_lifecycle = 'CASH' if recipient_kind == 'CASH' else 'UNTRACKED'
    recipient_execution_status = 'PASS' if recipient_kind == 'CASH' else 'REVIEW'
    recipient_add_freeze = 'OFF' if recipient_kind == 'CASH' else 'REVIEW'
    recipient_survival = 'PASS' if recipient_kind == 'CASH' else 'REVIEW'
    recipient_fit_status = 'PASS' if recipient_kind == 'CASH' else 'REVIEW'
    recipient_headroom_krw = float('inf') if recipient_kind == 'CASH' else 0.0
    recipient_downside = 0.0
    recipient_price = 0.0
    recipient_factor = ''
    recipient_sector = ''
    recipient_ticker = ''
    recipient_no_chase = 0.0
    recipient_exec_headroom = float('inf') if recipient_kind == 'CASH' else 0.0
    recipient_portfolio_headroom = float('inf') if recipient_kind == 'CASH' else 0.0
    recipient_fit = None
    recipient_wr = {}
    if recipient_kind == 'SECURITY' and (not watchlist.empty):
        rhit = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(str(recipient_choice))]
        if not rhit.empty:
            recipient_wr = rhit.iloc[0].to_dict()
            recipient_ticker = str(recipient_wr.get('ticker', '') or '').strip()
            shared_rec = resolve_shared_risk_assumptions(watchlist, recipient_choice, recipient_ticker, default_downside=0.5, default_price=0.0)
            recipient_downside = float(shared_rec['plausible_downside'])
            recipient_price = float(shared_rec['price_krw'])
            recipient_factor = str(recipient_wr.get('factor', '') or '').strip()
            recipient_sector = str(recipient_wr.get('sector', '') or '').strip()
            recipient_survival = str(recipient_wr.get('refinancing_gate', 'REVIEW') or 'REVIEW').strip().upper()
            ncv = pd.to_numeric(pd.Series([recipient_wr.get('no_chase_ceiling')]), errors='coerce').iloc[0]
            recipient_no_chase = 0.0 if pd.isna(ncv) else max(0.0, float(ncv))
            if not state_df.empty:
                rs = state_df.loc[state_df['name'].fillna('').astype(str).eq(str(recipient_choice))]
                if not rs.empty:
                    recipient_lifecycle = str(rs.iloc[0].get('lifecycle_state', 'UNTRACKED'))
            if not thesis_df.empty:
                tm = thesis_df.loc[thesis_df['company'].fillna('').astype(str).eq(str(recipient_choice))]
                if not tm.empty:
                    recipient_add_freeze = str(tm.iloc[0].get('add_freeze', 'REVIEW')).strip().upper()
            recipient_fit = portfolio_fit_review(portfolio=portfolio, total_assets=total_assets, candidate_name=recipient_choice, candidate_ticker=recipient_ticker, plausible_downside=recipient_downside, loss_budget=loss_budget, single_name_cap=single_cap, factor=recipient_factor, sector=recipient_sector, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), price_krw=recipient_price, requested_add_weight=0.0, reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), factor_loadings=factor_loadings)
            recipient_fit_status = str(recipient_fit['fit_status'])
            recipient_portfolio_headroom = float(recipient_fit['max_add_krw']) if recipient_fit_status == 'PASS' else 0.0
            raw_r, final_r = final_position_max(loss_budget, recipient_downside, single_cap, 1.0, 1.0, 1.0)
            risk_shares, _, _ = shares_for_weight(total_assets, final_r, recipient_price)
            eg = position_sizing_execution_gate(risk_shares, recipient_lifecycle, recipient_price, recipient_no_chase, float(settings.get('trade_plan_pilot_fraction', 0.5)))
            recipient_execution_status = str(eg['execution_status'])
            stage_cap_krw = float(eg['executable_shares']) * recipient_price if recipient_execution_status == 'PASS' else 0.0
            current_recipient_value = float(recipient_fit.get('current_value_krw', 0.0))
            recipient_exec_headroom = max(0.0, stage_cap_krw - current_recipient_value)
            recipient_headroom_krw = max(0.0, min(recipient_portfolio_headroom, recipient_exec_headroom))
    factor_cap_policy = float(settings.get('factor_cap', 0.1))
    repair_contexts = pd.DataFrame()
    if donor_kind == 'SECURITY':
        repair_contexts = breached_factor_contexts_for_asset(portfolio=portfolio, total_assets=total_assets, name=donor_choice, ticker=donor_ticker, factor_cap=factor_cap_policy, factor_loadings=factor_loadings)
    risk_repair_mode = False
    selected_repair_factor = ''
    repair_context_row = {}
    if not repair_contexts.empty:
        st.subheader('2. 기존 투자 요인 상한 초과 / 위험 보완 연결')
        repair_factor_options = repair_contexts['factor'].fillna('').astype(str).tolist()
        if st.session_state.get('migration_repair_factor') not in repair_factor_options:
            st.session_state['migration_repair_factor'] = repair_factor_options[0]
        if 'migration_factor_repair_mode' not in st.session_state:
            st.session_state['migration_factor_repair_mode'] = False
        selected_repair_factor = st.selectbox('위험 보완으로 추적할 투자 요인', repair_factor_options, key='migration_repair_factor')
        risk_repair_mode = st.checkbox('이 자본 이동을 투자 요인 위험 보완 모드로 평가', key='migration_factor_repair_mode', help='켜짐이면 해당 사전-기존 상한 초과 투자 요인이 실제로 감소하는지도 필수 점검으로 봅니다. 자금 수령 자산이 같은 투자 요인을 다시 늘리면 위험 보완으로 통과하지 않습니다.')
        ctx_hit = repair_contexts.loc[repair_contexts['factor'].astype(str).eq(selected_repair_factor)]
        if not ctx_hit.empty:
            repair_context_row = ctx_hit.iloc[0].to_dict()
            r1, r2, r3, r4 = st.columns(4)
            r1.metric('현재 투자 요인 노출', _locale.code(pct(repair_context_row.get('current_exposure', 0.0))))
            r2.metric('정책 상한', _locale.code(pct(repair_context_row.get('factor_cap', 0.0))))
            r3.metric('초과', _locale.code(pct(repair_context_row.get('excess_exposure', 0.0))))
            r4.metric('자금 제공 자산 투자 요인 기여', _locale.code(pct(repair_context_row.get('donor_factor_exposure', 0.0))))
            st.caption(f"{donor_choice}의 {selected_repair_factor} 노출 계수 {float(repair_context_row.get('donor_loading', 0.0)):.1%}. 이 값은 투자 요인 기여도 설명이며 매도 우선순위가 아닙니다.")
    else:
        st.session_state['migration_factor_repair_mode'] = False
        st.session_state['migration_repair_factor'] = ''
        if donor_kind == 'SECURITY':
            st.subheader('2. 기존 투자 요인 상한 초과 / 위험 보완 연결')
            st.info('선택 자금 제공 자산이 현재 사전-기존 상한 초과 투자 요인에 기여하는 항목이 없습니다. 일반 자본 이동 비교로 진행합니다.')
    st.subheader('3. 현재 시스템 점검')
    g1, g2, g3, g4 = st.columns(4)
    g1.metric('자금 제공 자산 투자 단계', _locale.code(donor_lifecycle))
    g2.metric('자금 수령 자산 투자 단계', _locale.code(recipient_lifecycle))
    g3.metric('실행', _locale.code(recipient_execution_status))
    g4.metric('추가 투자 보류', _locale.code(recipient_add_freeze))
    if recipient_kind == 'SECURITY':
        system_rows = pd.DataFrame([['Survival', recipient_survival], ['Portfolio Fit', recipient_fit_status], ['Execution Gate', recipient_execution_status], ['Add Freeze', recipient_add_freeze], ['Portfolio Headroom', krw(recipient_portfolio_headroom)], ['Execution Headroom', krw(recipient_exec_headroom)], ['Qualified Headroom', krw(recipient_headroom_krw)]], columns=['항목', '현재 상태'])
        _locale.dataframe(st, system_rows, width='stretch', hide_index=True)
        if recipient_lifecycle == 'OBSERVE' or recipient_execution_status == 'BLOCKED':
            st.warning('자금 수령 자산이 아직 실행 가능 단계가 아닙니다. 예상 수익률이 높아 보여도 투자 단계 / 실행 점검을 우회하지 않습니다.')
    else:
        st.info('자금 수령 자산이 현금이므로 종목 투자 단계 / 실행 / 포트폴리오 적합성 점검을 적용하지 않습니다.')
    st.subheader('3A. 자본 효율 투자 가정 연결')
    st.caption('자본 효율에서 사용자-검토됨 / 작동 상태 정상인 예상 수익률·위험 차감치를 자본 이동의 같은 기간 비교가정으로 연결합니다. 이 연결은 값의 일관성만 확인하며 실행을 승인하지 않습니다.')
    cm_cp_context = build_capital_productivity_health_context(portfolio, watchlist, load_csv('capital_productivity_inputs.csv'), total_assets, state_df, audit_evidence, load_csv('fundamental_snapshots.csv'), load_csv('scenario_refresh_reviews.csv'), load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'), today=date.today())
    cm_assumption_bridge = build_migration_assumption_bridge(cm_cp_context['universe'], cm_cp_context['health'], donor_choice, recipient_choice)
    mb1, mb2, mb3, mb4, mb5 = st.columns(5)
    mb1.metric('연결 대응 관계 점검', _locale.code(cm_assumption_bridge['mapping_gate']))
    mb2.metric('자금 제공 자산 작동 상태', _locale.code(cm_assumption_bridge['donor_health'] or '-'))
    mb3.metric('자금 수령 자산 작동 상태', _locale.code(cm_assumption_bridge['recipient_health'] or '-'))
    mb4.metric('연결됨 위험 Δ', _locale.code('-' if cm_assumption_bridge['mapped_incremental_risk_penalty'] is None else pct(cm_assumption_bridge['mapped_incremental_risk_penalty'])))
    mb5.metric('투자 실행 권한', '없음')
    bridge_rows = pd.DataFrame([{'Side': 'Donor', 'Name': donor_choice, 'Forward ER': cm_assumption_bridge.get('donor_forward_er'), 'Risk Penalty': cm_assumption_bridge.get('donor_risk_penalty'), 'Risk-adjusted ER': cm_assumption_bridge.get('donor_risk_adjusted_er'), 'Health': cm_assumption_bridge.get('donor_health'), 'Input': cm_assumption_bridge.get('donor_input_status')}, {'Side': 'Recipient', 'Name': recipient_choice, 'Forward ER': cm_assumption_bridge.get('recipient_forward_er'), 'Risk Penalty': cm_assumption_bridge.get('recipient_risk_penalty'), 'Risk-adjusted ER': cm_assumption_bridge.get('recipient_risk_adjusted_er'), 'Health': cm_assumption_bridge.get('recipient_health'), 'Input': cm_assumption_bridge.get('recipient_input_status')}])
    for _c in ['Forward ER', 'Risk Penalty', 'Risk-adjusted ER']:
        bridge_rows[_c] = pd.to_numeric(bridge_rows[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
    _locale.dataframe(st, bridge_rows, width='stretch', hide_index=True)
    st.caption('정확한 경제적 대응 관계는 `Recipient Risk Penalty - Donor Risk Penalty`가 0 이상일 때만 가능합니다. 음수이면 현재 이전의 단일 추가 위험 차감치 입력으로 같은 경제를 정확히 표현할 수 없어 검토로 남깁니다.')
    if cm_assumption_bridge['mapping_gate'] != 'PASS':
        st.warning(_locale.message('자본 효율 투자 가정 연결 검토 · ' + ' | '.join(cm_assumption_bridge['issues'])))
    else:
        st.success('자본 효율 승인가정을 이전 입력으로 정확히 대응 관계할 수 있습니다. 아래 버튼은 값만 복사하며 실행/주문을 만들지 않습니다.')
        if st.button('자본 효율 승인가정 → 이전 입력값 복사', key='migration_cp_assumption_bridge_apply'):
            st.session_state[f'migration_donor_er::{donor_choice}'] = float(cm_assumption_bridge['donor_forward_er'])
            st.session_state[f'migration_recipient_er::{recipient_choice}'] = float(cm_assumption_bridge['recipient_forward_er'])
            st.session_state['migration_risk_penalty'] = float(cm_assumption_bridge['mapped_incremental_risk_penalty'])
            st.session_state['migration_assumption_bridge_hash'] = cm_assumption_bridge['assumption_snapshot_hash']
            st.session_state['_save_flash'] = ('success', 'Capital Productivity 승인가정을 Migration 입력에 복사했습니다. Execution Authorization = NONE.')
            st.rerun()
    st.subheader('4. 이동금액과 예상 수익률 가정')
    a, b, c = st.columns(3)
    if 'migration_amount_krw' not in st.session_state:
        st.session_state['migration_amount_krw'] = 0.0
    migration_amount = a.number_input('이동 검토금액(원화)', min_value=0.0, step=10000.0, key='migration_amount_krw', help='실제 주문이 아니라 비교할 금액입니다.')
    donor_er_default = 0.0 if donor_kind == 'CASH' else 0.04
    recipient_er_default = 0.0 if recipient_kind == 'CASH' else 0.12
    donor_er = b.number_input('자금 제공 자산 예상 수익률', min_value=-1.0, max_value=5.0, value=float(donor_er_default), format='%.3f', key=f'migration_donor_er::{donor_choice}', help='자금 수령 자산과 같은 향후 기간을 사용하세요. 예: 둘 다 향후 12개월.')
    recipient_er = c.number_input('자금 수령 자산 예상 수익률', min_value=-1.0, max_value=5.0, value=float(recipient_er_default), format='%.3f', key=f'migration_recipient_er::{recipient_choice}', help='자금 제공 자산과 같은 향후 기간을 사용하세요.')
    a2, b2, c2, d2 = st.columns(4)
    tax = a2.number_input('세금 비용', min_value=0.0, max_value=1.0, value=0.0, format='%.3f', key='migration_tax')
    trading = b2.number_input('매매 비용', min_value=0.0, max_value=1.0, value=0.002, format='%.3f', key='migration_trading')
    risk_penalty = c2.number_input('추가 위험 차감치', min_value=0.0, max_value=1.0, value=0.02, format='%.3f', key='migration_risk_penalty', help='기대수익률에 반영되지 않은 추가 위험을 보수적으로 차감하는 수동 가정입니다.')
    hurdle = d2.number_input('이전 최소 요구수익률', min_value=0.0, max_value=1.0, value=float(settings.get('migration_hurdle', 0.02)), format='%.3f', key='migration_hurdle')
    repair_effect = {}
    repair_gate = 'N/A'
    repair_status = 'N/A'
    factor_pre_exposure = 0.0
    factor_post_exposure = 0.0
    factor_net_change = 0.0
    if risk_repair_mode and selected_repair_factor:
        repair_effect = factor_migration_effect(portfolio=portfolio, total_assets=total_assets, factor=selected_repair_factor, factor_cap=factor_cap_policy, donor_name=donor_choice, donor_ticker=donor_ticker, donor_primary_factor=donor_primary_factor, recipient_name=recipient_choice, recipient_ticker=recipient_ticker, recipient_primary_factor=recipient_factor, recipient_kind=recipient_kind, migration_amount_krw=migration_amount, factor_loadings=factor_loadings)
        repair_gate = str(repair_effect.get('repair_gate', 'REVIEW'))
        repair_status = str(repair_effect.get('repair_status', 'REVIEW'))
        factor_pre_exposure = float(repair_effect.get('current_exposure', 0.0) or 0.0)
        factor_post_exposure = float(repair_effect.get('post_exposure', 0.0) or 0.0)
        factor_net_change = float(repair_effect.get('net_factor_change', 0.0) or 0.0)
        st.subheader('5. 투자 요인 위험 보완 효과')
        q1, q2, q3, q4 = st.columns(4)
        q1.metric('이동 전 노출', _locale.code(pct(factor_pre_exposure)))
        q2.metric('자금 제공 자산 감소 효과', _locale.code('-' + pct(repair_effect.get('donor_factor_relief', 0.0))))
        q3.metric('자금 수령 자산 재유입', _locale.code('+' + pct(repair_effect.get('recipient_factor_added', 0.0))))
        q4.metric('이동 후 노출', _locale.code(pct(factor_post_exposure)))
        q5, q6, q7 = st.columns(3)
        q5.metric('위험 보완 점검', _locale.code(repair_gate))
        q6.metric('보완 상태', _locale.code(repair_status))
        q7.metric('순 투자 요인 변화', _locale.code(('+' if factor_net_change > 0 else '') + pct(factor_net_change)))
        if repair_gate == 'PASS':
            st.success(f"{_locale.code(repair_status)} · {repair_effect.get('detail', '')}")
        elif repair_gate == 'BLOCKED':
            st.error(f"{_locale.code(repair_status)} · {repair_effect.get('detail', '')}")
        else:
            st.warning(f"{_locale.code(repair_status)} · {repair_effect.get('detail', '')}")
        if recipient_kind == 'CASH':
            st.caption('현재는 자금 제공 자산 → 현금 대기 경로입니다. 위 자금 수령 자산 선택을 다른 종목으로 바꾸면 같은 금액이 그 종목으로 재배분될 때 투자 요인 노출이 얼마나 다시 들어오는지 즉시 비교됩니다.')
        else:
            st.caption(f"자금 수령 자산의 {selected_repair_factor} 실질 구성자산 분석 노출 계수 {float(repair_effect.get('recipient_loading', 0.0)):.1%}. 위험 보완 모드에서는 자금 수령 자산 기대수익이 높아도 해당 투자 요인 위험을 줄이지 못하면 통과하지 않습니다.")
    elif not repair_contexts.empty:
        st.subheader('5. 투자 요인 위험 보완 효과')
        st.info('위험 보완 모드가 꺼짐입니다. 일반 자본 이동으로 비교합니다. 기존 투자 요인 상한 초과 복구 목적이라면 위 체크박스를 켜짐으로 바꾸세요.')
    review = capital_migration_review(total_assets=total_assets, migration_amount_krw=migration_amount, donor_name=donor_choice, donor_kind=donor_kind, donor_available_krw=donor_available, donor_lifecycle=donor_lifecycle, donor_downside=donor_downside, recipient_name=recipient_choice, recipient_kind=recipient_kind, recipient_lifecycle=recipient_lifecycle, recipient_execution_status=recipient_execution_status, recipient_add_freeze=recipient_add_freeze, recipient_survival_gate=recipient_survival, recipient_fit_status=recipient_fit_status, recipient_headroom_krw=recipient_headroom_krw, recipient_downside=recipient_downside, current_cash_krw=current_cash, minimum_cash_weight=float(settings.get('minimum_cash_weight', 0.2)), donor_forward_er=donor_er, recipient_forward_er=recipient_er, tax_cost=tax, trading_cost=trading, incremental_risk_penalty=risk_penalty, migration_hurdle=hurdle, risk_repair_mode=risk_repair_mode, risk_repair_factor=selected_repair_factor, risk_repair_gate=repair_gate, factor_repair_status=repair_status, factor_pre_exposure=factor_pre_exposure, factor_post_exposure=factor_post_exposure, factor_net_change=factor_net_change)
    st.subheader('6. 비용 차감 후 교체 효과 / 최종 점검')
    m1, m2, m3, m4 = st.columns(4)
    m1.metric('비용 차감 후 교체 효과', _locale.code(pct(review['net_switching_gap'])))
    m2.metric('이전 최소 요구수익률', _locale.code(pct(review['migration_hurdle'])))
    m3.metric('손실위험자본 변화', _locale.code(('+' if review['car_delta'] > 0 else '') + pct(review['car_delta'])))
    m4.metric('최종 상태', _locale.code(review['decision_status']))
    gate_data = [['Donor Capacity', review['donor_capacity_gate']], ['Recipient Lifecycle', review['lifecycle_gate']], ['Recipient Execution', review['execution_gate']], ['Recipient Add Freeze', review['add_freeze_gate']], ['Recipient Survival', review['survival_gate']], ['Portfolio Fit', review['fit_gate']], ['Recipient Capacity', review['recipient_capacity_gate']], ['Cash Reserve', review['cash_reserve_gate']]]
    if risk_repair_mode:
        gate_data.append(['Factor Risk Repair', review['risk_repair_gate']])
    gate_data.append(['Switching Gap' if review.get('switching_gap_binding', True) else 'Switching Gap (정보)', review['switching_gap_gate'] if review.get('switching_gap_binding', True) else 'INFO'])
    gate_rows = pd.DataFrame(gate_data, columns=['Gate', 'Status'])
    _locale.dataframe(st, gate_rows, width='stretch', hide_index=True)
    cm_bridge_reconciliation = reconcile_migration_assumption_bridge(cm_assumption_bridge, donor_forward_er=donor_er, recipient_forward_er=recipient_er, incremental_risk_penalty=risk_penalty, tax_cost=tax, trading_cost=trading, migration_net_switching_gap=review['net_switching_gap'], tolerance=float(settings.get('migration_assumption_bridge_tolerance', 0.0005)))
    st.subheader('6A. 자본 효율 ↔ 이전 투자 가정 대조')
    br1, br2, br3, br4 = st.columns(4)
    br1.metric('대조 점검', _locale.code(cm_bridge_reconciliation['reconciliation_gate']))
    br2.metric('자본 효율 순액 차이 참조', _locale.code('-' if cm_bridge_reconciliation['cp_net_switching_gap_reference'] is None else pct(cm_bridge_reconciliation['cp_net_switching_gap_reference'])))
    br3.metric('이전 순액 차이', _locale.code('-' if cm_bridge_reconciliation['migration_net_switching_gap'] is None else pct(cm_bridge_reconciliation['migration_net_switching_gap'])))
    br4.metric('순액 차이 Δ', _locale.code('-' if cm_bridge_reconciliation['net_gap_delta'] is None else pct(cm_bridge_reconciliation['net_gap_delta'])))
    reconcile_table = pd.DataFrame([['Donor Forward ER', cm_assumption_bridge.get('donor_forward_er'), donor_er, cm_bridge_reconciliation.get('donor_er_delta')], ['Recipient Forward ER', cm_assumption_bridge.get('recipient_forward_er'), recipient_er, cm_bridge_reconciliation.get('recipient_er_delta')], ['Incremental Risk Penalty', cm_assumption_bridge.get('mapped_incremental_risk_penalty'), risk_penalty, cm_bridge_reconciliation.get('risk_penalty_delta')], ['Net Switching Gap', cm_bridge_reconciliation.get('cp_net_switching_gap_reference'), review.get('net_switching_gap'), cm_bridge_reconciliation.get('net_gap_delta')]], columns=['Item', 'Capital Productivity Reference', 'Migration Input/Result', 'Delta'])
    for _c in ['Capital Productivity Reference', 'Migration Input/Result', 'Delta']:
        reconcile_table[_c] = pd.to_numeric(reconcile_table[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
    _locale.dataframe(st, reconcile_table, width='stretch', hide_index=True)
    if cm_bridge_reconciliation['reconciliation_gate'] == 'PASS':
        st.success('자본 효율과 자본 이동의 향후 경제가 일치합니다. 이 정상은 입력 일관성 확인이며 이전 실행 승인이나 매수/매도 결론이 아닙니다.')
    else:
        st.warning(_locale.message('투자 가정 대조 검토 · ' + ' | '.join(cm_bridge_reconciliation['issues'])))
    _bridge_note = st.text_input('투자 가정 연결 검토 메모', value='', key='migration_assumption_bridge_note', placeholder='예: 자본 효율 승인됨 가정 연결됨 / 금지 투자 실행 권한')
    if st.button('투자 가정 연결 검토 기록 저장', key='save_migration_assumption_bridge_review'):
        _bridge_row = migration_bridge_review_row(cm_assumption_bridge, cm_bridge_reconciliation, note=_bridge_note)
        _bridge_hist = load_csv('capital_migration_assumption_bridge_reviews.csv')
        for _col in MIGRATION_BRIDGE_REVIEW_COLS:
            if _col not in _bridge_hist.columns:
                _bridge_hist[_col] = ''
        _bridge_hist = pd.concat([_bridge_hist[MIGRATION_BRIDGE_REVIEW_COLS], pd.DataFrame([_bridge_row])], ignore_index=True)
        verified_save_feedback(_bridge_hist, 'capital_migration_assumption_bridge_reviews.csv', f"Capital Productivity ↔ Migration Assumption Bridge 검토기록을 저장했습니다. Reconciliation {cm_bridge_reconciliation['reconciliation_gate']} · Execution Authorization = NONE.", rerun=False)
    if review['decision_status'] == 'MIGRATION REVIEW':
        st.success('이전 검토 · 현재 입력값에서는 모든 점검과 교체 차이가 통과했습니다. 이 상태는 자동매수/자동매도 명령이 아닙니다.')
    elif review['decision_status'] == 'CASH / FACTOR RISK REPAIR':
        st.info(_locale.message(review['decision_reason'] + ' 현금에 머문 뒤 다른 자금 수령 자산을 비교할 수 있지만, 적격 자금 수령 자산이 없으면 현금 유지도 허용됩니다.'))
    elif review['decision_status'] in {'CASH MIGRATION REVIEW', 'CASH / RISK REPAIR'}:
        st.info(_locale.message(review['decision_reason']))
    elif review['decision_status'] == 'NO SWITCH':
        st.info(_locale.message(review['decision_reason']))
    elif review['decision_status'] == 'REVIEW':
        st.warning(_locale.message(review['decision_reason']))
    else:
        st.error(_locale.message(review['decision_reason']))
    if review['reasons']:
        st.markdown('**막히거나 추가 확인이 필요한 이유**')
        for reason in review['reasons']:
            st.write(f'- {reason}')
    cinfo1, cinfo2, cinfo3 = st.columns(3)
    cinfo1.metric('현재 현금', _locale.code(krw(review['current_cash_krw'])))
    cinfo2.metric('이동 후 예상 현금', _locale.code(krw(review['post_cash_krw'])))
    cinfo3.metric('최소 현금 기준', _locale.code(krw(review['minimum_cash_krw'])))
    if recipient_kind == 'SECURITY' and (not review['qualified_recipient']):
        st.info('현재 자금 수령 자산이 적격 상태가 아닙니다. 자금 제공 자산을 반드시 줄여야 하는 별도 위험사유가 있다면 현금을 중간 대기장소로 검토할 수 있지만, 이 화면은 자동으로 자금 제공 자산→현금 이동을 결정하지 않습니다.')
    st.subheader('7. 위험 보완 예외 승인 관리 기준')
    st.caption('교체 차이가 경제적으로 불리해도 포트폴리오 위험 보완 목적의 현금 이동을 별도 검토할 수 있습니다. 이 경로는 실행 허가가 아니라 더 높은 증거·사람 검토·만료를 요구하는 관리 기준 절차입니다.')
    cm_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    cm_liq_overlays = normalize_liquidity_overlays(load_csv('liquidity_operational_overlays.csv'))
    cm_liq_editor = liquidity_overlay_editor_rows(portfolio, cm_liq_overlays, legacy_overlays=normalize_risk_overlays(load_csv('asset_risk_overlays.csv')))
    cm_liq_status = liquidity_status_table(portfolio, cm_liq_editor, total_assets, liquidity_days_limit=float(settings.get('liquidity_days_limit', 5.0)))
    if donor_kind == 'CASH':
        cm_donor_liquidity_gate = 'PASS'
        cm_donor_liquidity_row = pd.DataFrame()
    else:
        cm_donor_liquidity_row = cm_liq_status.loc[cm_liq_status['name'].fillna('').astype(str).eq(str(donor_choice))].copy() if not cm_liq_status.empty else pd.DataFrame()
        if cm_donor_liquidity_row.empty:
            cm_donor_liquidity_gate = 'REVIEW'
        elif not cm_donor_liquidity_row['status'].fillna('').astype(str).str.upper().eq('PASS').all():
            cm_donor_liquidity_gate = 'REVIEW'
        elif cm_donor_liquidity_row['liquidity_status'].fillna('').astype(str).str.upper().eq('TIGHT').any():
            cm_donor_liquidity_gate = 'TIGHT'
        else:
            cm_donor_liquidity_gate = 'PASS'
    rr_factor_gate = review.get('risk_repair_gate', 'N/A') if risk_repair_mode else 'N/A'
    rr_eligibility = risk_repair_eligibility(review, recipient_kind=recipient_kind, donor_lifecycle=donor_lifecycle, reconciliation_gate=cm_recon['status'], donor_liquidity_gate=cm_donor_liquidity_gate, factor_risk_repair_gate=rr_factor_gate)
    economic_switching_gate = str(review.get('switching_gap_gate', 'REVIEW') or 'REVIEW').upper()
    rg1, rg2, rg3, rg4 = st.columns(4)
    rg1.metric('경제적 교체 점검', _locale.code(economic_switching_gate))
    rg2.metric('위험 보완 적격성', _locale.code(rr_eligibility['status']))
    rg3.metric('손실위험자본 완화', _locale.code('-' + pct(abs(min(0.0, float(review.get('car_delta', 0.0) or 0.0)))) if float(review.get('car_delta', 0.0) or 0.0) < 0 else pct(0.0)))
    rg4.metric('투자 실행 권한', '없음')
    sys1, sys2, sys3 = st.columns(3)
    sys1.metric('자금 제공 자산 투자 단계', _locale.code(donor_lifecycle))
    sys2.metric('대조', _locale.code(cm_recon['status']))
    sys3.metric('자금 제공 자산 유동성', _locale.code(cm_donor_liquidity_gate))
    if rr_eligibility['status'] == 'PASS':
        st.success('위험 보완 경로의 시스템 자격은 정상입니다. 이것은 실행 허가가 아니라 관리 기준 검토를 시작할 수 있다는 뜻입니다.')
    elif rr_eligibility['status'] == 'REVIEW':
        st.warning(_locale.message('위험 보완 적격성 검토 · ' + rr_eligibility['reason']))
    else:
        st.error(_locale.message('위험 보완 적격성 차단됨 · ' + rr_eligibility['reason']))
    rr_reason = st.text_area('위험 보완 사유', value='', key='risk_repair_override_reason', height=90, placeholder='예: 상위 손실위험자본 집중도가 정책 상한을 초과해 수익률 우위가 아니라 포트폴리오 생존/위험 예산 복구 목적으로 검토')
    rr_c1, rr_c2, rr_c3 = st.columns(3)
    rr_thesis = rr_c1.checkbox('자금 제공 자산 투자 가설 / 투자 단계를 다시 검토했습니다.', key='risk_repair_override_thesis')
    rr_valuation = rr_c2.checkbox('자금 제공 자산 가치 평가 / 예상 수익률을 다시 검토했습니다.', key='risk_repair_override_valuation')
    rr_cost = rr_c3.checkbox('세금 / 매매 비용 가정을 직접 확인했습니다.', key='risk_repair_override_cost')
    rr_c4, rr_c5, rr_c6 = st.columns(3)
    rr_liq_recon = rr_c4.checkbox('유동성 / 대조 상태를 직접 확인했습니다.', key='risk_repair_override_liquidity_recon')
    rr_purpose = rr_c5.checkbox('이 경로가 기대수익 우위가 아니라 위험 보완 목적임을 확인했습니다.', key='risk_repair_override_purpose')
    rr_human = rr_c6.checkbox('최종 사용자 검토를 완료했습니다.', key='risk_repair_override_human')
    rr_default_days = int(settings.get('risk_repair_override_default_review_days', 30))
    rr_max_days = int(settings.get('risk_repair_override_max_review_days', 90))
    rr_due = st.date_input('예외 승인 만료 / 다음 검토 날짜', value=date.today() + timedelta(days=max(1, rr_default_days)), key='risk_repair_override_due_date', help=f'위험 보완 검토의 재확인/만료 날짜입니다. 정책 최대 {rr_max_days}일 이내만 정상 처리합니다.')
    rr_note = st.text_input('위험 보완 관리 기준 메모', value='', key='risk_repair_override_note', placeholder='예: 실행 전 실제 주문수량·세금·시장상태 재확인')
    rr_governance = risk_repair_governance_gate(eligibility_status=rr_eligibility['status'], economic_switching_gate=economic_switching_gate, risk_repair_reason=rr_reason, thesis_lifecycle_confirmed=rr_thesis, valuation_confirmed=rr_valuation, cost_confirmed=rr_cost, liquidity_reconciliation_confirmed=rr_liq_recon, risk_purpose_confirmed=rr_purpose, human_confirmed=rr_human, review_due_date=rr_due, max_review_days=rr_max_days)
    gg1, gg2, gg3 = st.columns(3)
    gg1.metric('관리 기준 점검', _locale.code(rr_governance['governance_gate']))
    gg2.metric('최종 판단', _locale.code(rr_governance['final_decision']))
    gg3.metric('만료 점검', _locale.code(rr_governance['expiry_gate']))
    if rr_governance['governance_gate'] == 'PASS':
        st.success('관리 기준 검토가 완료되었습니다. 투자 실행 권한은 여전히 없음이며, 실제 주문은 별도 실행 검토를 거쳐야 합니다.')
    else:
        st.warning(_locale.message('사용자 검토 필요 · ' + (' | '.join(rr_governance['missing']) if rr_governance['missing'] else '추가 확인 필요')))
    if st.button('위험 보완 관리 기준 검토 기록 저장', key='save_risk_repair_override_review'):
        rr_row = risk_repair_override_record(handoff_source=handoff_source, donor=donor_choice, recipient=recipient_choice, migration_amount_krw=migration_amount, review=review, eligibility=rr_eligibility, governance=rr_governance, donor_lifecycle=donor_lifecycle, reconciliation_gate=cm_recon['status'], donor_liquidity_gate=cm_donor_liquidity_gate, risk_repair_reason=rr_reason, thesis_lifecycle_confirmed=rr_thesis, valuation_confirmed=rr_valuation, cost_confirmed=rr_cost, liquidity_reconciliation_confirmed=rr_liq_recon, risk_purpose_confirmed=rr_purpose, human_confirmed=rr_human, note=rr_note)
        rr_hist = load_csv('risk_repair_override_reviews.csv')
        for _col in RISK_REPAIR_OVERRIDE_COLS:
            if _col not in rr_hist.columns:
                rr_hist[_col] = ''
        rr_hist = pd.concat([rr_hist[RISK_REPAIR_OVERRIDE_COLS], pd.DataFrame([rr_row])], ignore_index=True)
        verified_save_feedback(rr_hist, 'risk_repair_override_reviews.csv', 'Risk Repair Governance 검토 기록을 저장했습니다. 실행 주문은 생성하지 않았습니다.', rerun=False)
    rr_history = load_csv('risk_repair_override_reviews.csv')
    if not rr_history.empty:
        with st.expander('위험 보완 관리 기준 최근 기록', expanded=False):
            _locale.dataframe(st, rr_history.tail(20), width='stretch', hide_index=True)
    st.subheader('8. 자본 이동 2.0 · 상세 비용 / 자금 수령 자산 신규위험')
    st.caption('총액 자금 제공 자산 금액과 실제 자금 수령 자산에 도착하는 순액 자본을 분리하고, 세금·거래비용·환율/기타 비용·투자 요인 신규위험을 함께 봅니다.')
    st.warning('세율과 과세대상 이익비율은 계좌·상품·거주지·세법에 따라 다를 수 있으므로 시스템이 자동 추정하지 않습니다. 아래 값은 사용자가 확인한 가정만 입력하세요. 평균매입가는 투자판단 기준이 아니라 세금 계산 근거가 필요한 경우에만 별도로 확인합니다.')
    with st.expander('상세 비용 가정 입력', expanded=True):
        vc1, vc2, vc3 = st.columns(3)
        taxable_gain_fraction = vc1.number_input('과세대상 이익 비율', min_value=0.0, max_value=1.0, value=0.0, format='%.4f', key='migration_v2_taxable_gain_fraction', help='매도금액 중 실제 과세대상 이익으로 보는 비율입니다. 세법을 자동 추정하지 않습니다.')
        capital_gains_tax_rate = vc2.number_input('자본이득 세율', min_value=0.0, max_value=1.0, value=0.0, format='%.4f', key='migration_v2_capital_gains_tax_rate')
        sell_transaction_tax_rate = vc3.number_input('매도 거래세율', min_value=0.0, max_value=1.0, value=0.0, format='%.4f', key='migration_v2_sell_transaction_tax_rate')
        vc4, vc5, vc6 = st.columns(3)
        sell_execution_cost_rate = vc4.number_input('매도 체결비용률', min_value=0.0, max_value=1.0, value=0.0, format='%.4f', key='migration_v2_sell_execution_cost_rate', help='수수료·슬리피지 등 사용자가 적용하려는 보수적 비용률.')
        buy_execution_cost_rate = vc5.number_input('매수 체결비용률', min_value=0.0, max_value=1.0, value=0.0, format='%.4f', key='migration_v2_buy_execution_cost_rate')
        fx_other_cost_rate = vc6.number_input('환율 / 기타 전환비용률', min_value=0.0, max_value=1.0, value=0.0, format='%.4f', key='migration_v2_fx_other_cost_rate')
    v2_costs = estimate_switching_costs(gross_migration_krw=migration_amount, donor_kind=donor_kind, recipient_kind=recipient_kind, taxable_gain_fraction=taxable_gain_fraction, capital_gains_tax_rate=capital_gains_tax_rate, sell_transaction_tax_rate=sell_transaction_tax_rate, sell_execution_cost_rate=sell_execution_cost_rate, buy_execution_cost_rate=buy_execution_cost_rate, fx_other_cost_rate=fx_other_cost_rate)
    v2_factor_risk = recipient_factor_risk_impact(portfolio=portfolio, total_assets=total_assets, donor_name=donor_choice, donor_ticker=donor_ticker, donor_kind=donor_kind, donor_primary_factor=donor_primary_factor, gross_migration_krw=migration_amount, recipient_name=recipient_choice, recipient_ticker=recipient_ticker, recipient_kind=recipient_kind, recipient_primary_factor=recipient_factor, net_recipient_capital_krw=v2_costs['net_recipient_capital_krw'], factor_cap=factor_cap_policy, factor_loadings=factor_loadings)
    v2_review = capital_migration_review_v2(total_assets=total_assets, gross_migration_krw=migration_amount, donor_name=donor_choice, donor_kind=donor_kind, donor_available_krw=donor_available, donor_downside=donor_downside, recipient_name=recipient_choice, recipient_kind=recipient_kind, recipient_headroom_krw=recipient_headroom_krw, recipient_downside=recipient_downside, current_cash_krw=current_cash, minimum_cash_weight=float(settings.get('minimum_cash_weight', 0.2)), recipient_lifecycle_gate=review['lifecycle_gate'], recipient_execution_gate=review['execution_gate'], recipient_add_freeze_gate=review['add_freeze_gate'], recipient_survival_gate=review['survival_gate'], recipient_fit_gate=review['fit_gate'], donor_forward_er=donor_er, recipient_forward_er=recipient_er, costs=v2_costs, factor_risk=v2_factor_risk, incremental_risk_penalty_rate=risk_penalty, migration_hurdle_rate=hurdle, risk_repair_mode=risk_repair_mode, risk_repair_factor=selected_repair_factor, risk_repair_gate=repair_gate)
    v21, v22, v23, v24 = st.columns(4)
    v21.metric('총액 자금 제공 자산 금액', _locale.code(krw(v2_review['gross_migration_krw'])))
    v22.metric('총 명시적 비용', _locale.code(krw(v2_costs['total_friction_krw'])))
    v23.metric('비용 차감 효과', _locale.code(pct(v2_costs['total_friction_rate'])))
    v24.metric('순액 자금 수령 자산 자본', _locale.code(krw(v2_review['net_recipient_capital_krw'])))
    cost_rows = pd.DataFrame([['Capital Gains Tax', v2_costs['capital_gains_tax_krw']], ['Sell Transaction Tax', v2_costs['sell_transaction_tax_krw']], ['Sell Execution', v2_costs['sell_execution_cost_krw']], ['Buy Execution', v2_costs['buy_execution_cost_krw']], ['FX / Other', v2_costs['fx_other_cost_krw']]], columns=['비용 항목', 'KRW'])
    cost_rows['KRW'] = cost_rows['KRW'].map(krw)
    _locale.dataframe(st, cost_rows, width='stretch', hide_index=True)
    st.markdown('**자금 수령 자산 신규 투자 요인 위험**')
    v2_factor_table = v2_factor_risk.get('table', pd.DataFrame()).copy()
    if v2_factor_table.empty:
        st.info('변화하거나 이미 상한 초과인 투자 요인이 없습니다.')
    else:
        for c in ['before_exposure', 'donor_loading', 'donor_relief', 'recipient_loading', 'recipient_added', 'net_factor_change', 'post_exposure', 'policy_cap', 'post_excess']:
            if c in v2_factor_table.columns:
                v2_factor_table[c] = pd.to_numeric(v2_factor_table[c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
        _locale.dataframe(st, v2_factor_table, width='stretch', hide_index=True)
    if v2_factor_risk['gate'] == 'BLOCKED':
        st.error(_locale.message('자금 수령 자산 투자 요인 위험 점검 = 차단됨 · ' + ' / '.join(v2_factor_risk.get('blockers', []))))
    else:
        st.success('자금 수령 자산 투자 요인 위험 점검 = 정상 · 새로운 투자 요인 상한 위반을 만들거나 기존 상한 초과를 악화시키지 않습니다.')
    st.markdown('**비용-조정된 교체 경제성**')
    ve1, ve2, ve3, ve4 = st.columns(4)
    ve1.metric('위험 조정 우위', _locale.code(krw(v2_review['risk_adjusted_advantage_krw'])))
    ve2.metric('비용 차감 후 교체 효과 2.0', _locale.code(pct(v2_review['net_switching_gap_v2'])))
    break_even = v2_review.get('break_even_recipient_er', float('inf'))
    ve3.metric('자금 수령 자산 손익분기 기대수익률', _locale.code('∞' if break_even == float('inf') else pct(break_even)))
    ve4.metric('경제성 점검', _locale.code('참고' if not v2_review.get('economics_binding', True) else v2_review['economics_gate']))
    vr1, vr2, vr3, vr4 = st.columns(4)
    vr1.metric('자금 제공 자산 손실위험자본 감소', _locale.code('-' + pct(v2_review['donor_car_relieved'])))
    vr2.metric('자금 수령 자산 손실위험자본 추가', _locale.code('+' + pct(v2_review['recipient_car_added'])))
    vr3.metric('순액 손실위험자본 변화', _locale.code(('+' if v2_review['car_delta'] > 0 else '') + pct(v2_review['car_delta'])))
    vr4.metric('최종 상태 2.0', _locale.code(v2_review['decision_status']))
    v2_gate_rows = pd.DataFrame([['Donor Capacity', v2_review['donor_capacity_gate']], ['Recipient Capacity · NET 기준', v2_review['recipient_capacity_gate']], ['Cash Reserve', v2_review['cash_reserve_gate']], ['Recipient Operational', v2_review['operational_gate']], ['Recipient Factor Risk', v2_review['recipient_factor_risk_gate']], ['Switching Economics' if v2_review.get('economics_binding', True) else 'Switching Economics (정보)', v2_review['economics_gate'] if v2_review.get('economics_binding', True) else 'INFO']], columns=['Migration 2.0 Gate', 'Status'])
    if risk_repair_mode:
        v2_gate_rows = pd.concat([v2_gate_rows, pd.DataFrame([['Existing Factor Risk Repair', v2_review['risk_repair_gate']]], columns=v2_gate_rows.columns)], ignore_index=True)
    _locale.dataframe(st, v2_gate_rows, width='stretch', hide_index=True)
    if v2_review['decision_status'] in {'MIGRATION REVIEW 2.0', 'CASH MIGRATION REVIEW 2.0'}:
        st.success(_locale.message(v2_review['decision_reason']))
    elif v2_review['decision_status'] == 'CASH / FACTOR RISK REPAIR 2.0':
        st.info(_locale.message(v2_review['decision_reason']))
    elif v2_review['decision_status'] == 'NO SWITCH':
        st.info(_locale.message(v2_review['decision_reason']))
    elif v2_review['decision_status'] == 'REVIEW':
        st.warning(_locale.message(v2_review['decision_reason']))
    else:
        st.error(_locale.message(v2_review['decision_reason']))
    st.caption('손익분기 기대수익률은 같은 향후 기간 기준입니다. 세금·수수료를 0으로 두면 그 비용은 미반영됩니다. 자금 수령 자산 투자 요인 점검은 새 상한 위반 또는 기존 상한 초과 악화를 차단하지만, 기존에 이미 존재하는 관련 없는 상한 초과를 자동 매도 사유로 사용하지 않습니다.')
    st.subheader('8A. 현금 예비금 보완 / 두 단계-단계 이전')
    st.caption('현재 현금이 최소 현금 기준보다 부족하면, 먼저 자금 제공 자산→현금으로 예비금을 복구한 뒤 남는 자금 제공 자산 처리 용량과 자금 수령 자산 추가 허용 여력을 다시 비교합니다. 이전 2.0의 상세 비용 가정을 재사용하며 주문을 만들지 않습니다.')
    _cm_cp_recipient_hit = cm_cp_context['universe'].loc[cm_cp_context['universe']['name'].fillna('').astype(str).eq(recipient_choice)] if not cm_cp_context['universe'].empty and 'name' in cm_cp_context['universe'].columns else pd.DataFrame()
    _cm_cp_recipient_row = _cm_cp_recipient_hit.iloc[-1].to_dict() if not _cm_cp_recipient_hit.empty else {}
    _recipient_cp_hurdle_spread = 0.0 if recipient_kind == 'CASH' else pd.to_numeric(pd.Series([_cm_cp_recipient_row.get('hurdle_spread')]), errors='coerce').iloc[0]
    if pd.isna(_recipient_cp_hurdle_spread):
        _recipient_cp_hurdle_spread = None
    cm_cash_repair = build_cash_reserve_repair_plan(total_assets=total_assets, current_cash_krw=current_cash, minimum_cash_weight=float(settings.get('minimum_cash_weight', 0.2)), donor_name=donor_choice, donor_kind=donor_kind, donor_available_krw=donor_available, recipient_name=recipient_choice, recipient_kind=recipient_kind, recipient_headroom_krw=recipient_headroom_krw, taxable_gain_fraction=taxable_gain_fraction, capital_gains_tax_rate=capital_gains_tax_rate, sell_transaction_tax_rate=sell_transaction_tax_rate, sell_execution_cost_rate=sell_execution_cost_rate, buy_execution_cost_rate=buy_execution_cost_rate, fx_other_cost_rate=fx_other_cost_rate, recipient_hurdle_spread=_recipient_cp_hurdle_spread, bridge_mapping_gate=cm_assumption_bridge['mapping_gate'], recipient_lifecycle_gate=review['lifecycle_gate'], recipient_execution_gate=review['execution_gate'], recipient_add_freeze_gate=review['add_freeze_gate'], recipient_survival_gate=review['survival_gate'], recipient_fit_gate=review['fit_gate'])
    cr1, cr2, cr3, cr4 = st.columns(4)
    cr1.metric('현재 현금', _locale.code(krw(cm_cash_repair['current_cash_krw'])))
    cr2.metric('최소 필요 현금', _locale.code(krw(cm_cash_repair['minimum_cash_krw'])))
    cr3.metric('필요 현금 보완', _locale.code(krw(cm_cash_repair['cash_shortfall_krw'])))
    cr4.metric('단계 1 점검', _locale.code(cm_cash_repair['step1_cash_repair_gate']))
    cs1, cs2, cs3, cs4 = st.columns(4)
    cs1.metric('총액 비중 축소 필요한', _locale.code('-' if cm_cash_repair['step1_required_gross_trim_krw'] is None else krw(cm_cash_repair['step1_required_gross_trim_krw'])))
    cs2.metric('추정 단계 1 비용', _locale.code(krw(cm_cash_repair['step1_estimated_cost_krw'])))
    cs3.metric('순액 현금 추가됨', _locale.code(krw(cm_cash_repair['step1_net_cash_added_krw'])))
    cs4.metric('사후-단계 1 현금', _locale.code(krw(cm_cash_repair['post_step1_cash_krw'])))
    st.caption('단계 1 총액 비중 축소는 현금 부족분을 채우기 위한 수학적 최소치입니다. 자본 이익 세금은 `매도금액 × 과세대상 이익비율 × 세율` 추정치로 반영하며, 매도 거래세·매도 체결비용·환율/기타 비용을 함께 차감합니다. 입력 비용률이 0이면 해당 비용은 미반영입니다.')
    ct1, ct2, ct3, ct4 = st.columns(4)
    ct1.metric('잔여 자금 제공 자산 처리 용량', _locale.code(krw(cm_cash_repair['residual_donor_capacity_krw'])))
    ct2.metric('자금 수령 자산 추가 허용 여력', _locale.code(krw(cm_cash_repair['recipient_headroom_krw'])))
    ct3.metric('단계 2 최대 순액 자금 수령 자산', _locale.code(krw(cm_cash_repair['step2_max_net_recipient_krw'])))
    ct4.metric('단계 2 자금 수령 자산 점검', _locale.code(cm_cash_repair['step2_recipient_gate']))
    st.markdown('**두 단계-단계 상태**')
    st.write(cm_cash_repair['two_step_status'])
    two_step_rows = pd.DataFrame([['Step 1 Sell Friction Rate', pct(cm_cash_repair['step1_sell_friction_rate'])], ['Step 1 Gross Trim Needed', '-' if cm_cash_repair['step1_required_gross_trim_krw'] is None else krw(cm_cash_repair['step1_required_gross_trim_krw'])], ['Step 1 Net Cash Added', krw(cm_cash_repair['step1_net_cash_added_krw'])], ['Step 1 Post Cash', krw(cm_cash_repair['post_step1_cash_krw'])], ['Residual Donor Capacity', krw(cm_cash_repair['residual_donor_capacity_krw'])], ['Step 2 Total Friction Rate', pct(cm_cash_repair['step2_total_friction_rate'])], ['Step 2 Max Gross Donor', krw(cm_cash_repair['step2_max_gross_donor_krw'])], ['Step 2 Max Net Recipient', krw(cm_cash_repair['step2_max_net_recipient_krw'])], ['Recipient Hurdle Spread', '-' if cm_cash_repair['recipient_hurdle_spread'] is None else pct(cm_cash_repair['recipient_hurdle_spread'])], ['Bridge Mapping Gate', cm_cash_repair['bridge_mapping_gate']], ['Recipient Operational Gate', cm_cash_repair['recipient_operational_gate']], ['Execution Authorization', 'NONE']], columns=['Item', 'Value'])
    _locale.dataframe(st, two_step_rows, width='stretch', hide_index=True)
    if cm_cash_repair['step1_cash_repair_gate'] in {'PASS', 'ALREADY_PASS'}:
        st.success('단계 1 현금 예비금 보완은 수학적으로 검토 가능한 상태입니다. 이는 매도 실행 지시가 아니며 세금/거래비용 입력이 정확한지 별도 확인해야 합니다.')
    else:
        st.warning('단계 1 현금 예비금 보완이 아직 준비되지 않았습니다.')
    if cm_cash_repair['step2_recipient_gate'] == 'PASS':
        st.success('현금 예비금 복구 후 자금 수령 자산 소규모 시험 처리 용량까지 점검이 통과했습니다. 실제 Scale은 새로운 투자 근거와 기존 이전 점검을 다시 확인해야 합니다.')
    elif cm_cash_repair['step2_recipient_gate'] == 'REVIEW':
        st.warning('단계 2 자금 수령 자산은 추가 검토가 필요합니다. 처리 용량이 존재해도 최소 요구수익률 / 연결 / 운영 점검이 통과하지 않으면 자금 수령 자산 이동으로 해석하지 않습니다.')
    if cm_cash_repair['issues']:
        st.markdown('**현금 보완 / 두 단계-단계 추가 확인 이유**')
        for _issue in cm_cash_repair['issues']:
            st.write(f'- {_issue}')
    _cash_repair_note = st.text_input('현금 보완 / 두 단계-단계 검토 메모', value='', key='migration_cash_repair_note', placeholder='예: 최소 현금을 우선 회복 / 자금 수령 자산은 검토 상태 유지')
    if st.button('현금 보완 / 두 단계-단계 검토 기록 저장', key='save_migration_cash_repair_review'):
        _cash_repair_row = cash_repair_review_row(cm_cash_repair, note=_cash_repair_note)
        _cash_repair_hist = load_csv('capital_migration_cash_repair_reviews.csv')
        for _col in CASH_REPAIR_REVIEW_COLS:
            if _col not in _cash_repair_hist.columns:
                _cash_repair_hist[_col] = ''
        _cash_repair_hist = pd.concat([_cash_repair_hist[CASH_REPAIR_REVIEW_COLS], pd.DataFrame([_cash_repair_row])], ignore_index=True)
        verified_save_feedback(_cash_repair_hist, 'capital_migration_cash_repair_reviews.csv', 'Cash Reserve Repair / Two-step 검토기록을 저장했습니다. Execution Authorization = NONE.', rerun=False)
    st.subheader('8B. 현금 보완 주문 단위 / 실행 실행 가능성')
    st.caption('8A의 연속 원화 최소 총액 비중 축소를 실제 보유수량 단위로 올림합니다. 증권사의 소수 단위 매매가나 별도 주문 단위 조건은 자동 추정하지 않으며 기본 전체-수량 1단위만 사용합니다.')
    _cash_qty_donor_hit = portfolio.loc[portfolio['name'].fillna('').astype(str).eq(donor_choice)].copy() if donor_kind == 'SECURITY' and (not portfolio.empty) and ('name' in portfolio.columns) else pd.DataFrame()
    if _cash_qty_donor_hit.empty:
        _cash_donor_quantity = None
        _cash_unit_value_proxy = None
    else:
        _qty_series = pd.to_numeric(_cash_qty_donor_hit.get('quantity', pd.Series(index=_cash_qty_donor_hit.index, dtype=float)), errors='coerce').dropna()
        _cash_donor_quantity = float(_qty_series.sum()) if not _qty_series.empty else None
        _cash_unit_value_proxy = float(donor_available) / _cash_donor_quantity if _cash_donor_quantity is not None and _cash_donor_quantity > 0.0 else None
    cm_cash_quantity = build_cash_repair_quantity_step(cm_cash_repair, donor_quantity=_cash_donor_quantity, unit_value_proxy_krw=_cash_unit_value_proxy, lot_size=1)
    cq1, cq2, cq3, cq4 = st.columns(4)
    cq1.metric('현재 수량', _locale.code('-' if cm_cash_quantity['current_quantity'] is None else f"{cm_cash_quantity['current_quantity']:,.0f}"))
    cq2.metric('단위 값 추정치', _locale.code('-' if cm_cash_quantity['unit_value_proxy_krw'] is None else krw(cm_cash_quantity['unit_value_proxy_krw'])))
    cq3.metric('필요 매도 수량', _locale.code('-' if cm_cash_quantity['required_sell_quantity'] is None else f"{cm_cash_quantity['required_sell_quantity']:,.0f}"))
    cq4.metric('주문 단위 점검', _locale.code(cm_cash_quantity['quantity_step_gate']))
    ce1, ce2, ce3, ce4 = st.columns(4)
    ce1.metric('실행 가능 수량 총액 비중 축소', _locale.code(krw(cm_cash_quantity['executable_gross_trim_krw'])))
    ce2.metric('순액 현금 추가됨', _locale.code(krw(cm_cash_quantity['net_cash_added_krw'])))
    ce3.metric('매매 후 현금', _locale.code(krw(cm_cash_quantity['post_trade_cash_krw'])))
    ce4.metric('현금 초과-보완', _locale.code(krw(cm_cash_quantity['cash_over_repair_krw'])))
    qr1, qr2, qr3, qr4 = st.columns(4)
    qr1.metric('남은 수량', _locale.code('-' if cm_cash_quantity['remaining_quantity'] is None else f"{cm_cash_quantity['remaining_quantity']:,.0f}"))
    qr2.metric('잔여 자금 제공 자산 값', _locale.code(krw(cm_cash_quantity['residual_donor_value_krw'])))
    qr3.metric('단계 2 최대 순액 자금 수령 자산', _locale.code(krw(cm_cash_quantity['step2_max_net_recipient_krw'])))
    qr4.metric('단계 2 자금 수령 자산 점검', _locale.code(cm_cash_quantity['step2_recipient_gate']))
    quantity_rows = pd.DataFrame([['Mathematical Gross Trim', '-' if cm_cash_quantity['mathematical_gross_trim_krw'] is None else krw(cm_cash_quantity['mathematical_gross_trim_krw'])], ['Required Sell Quantity', '-' if cm_cash_quantity['required_sell_quantity'] is None else f"{cm_cash_quantity['required_sell_quantity']:,.0f}"], ['Executable Sell Quantity', f"{cm_cash_quantity['executable_sell_quantity']:,.0f}"], ['Executable Gross Trim', krw(cm_cash_quantity['executable_gross_trim_krw'])], ['Estimated Sell Friction', krw(cm_cash_quantity['estimated_sell_cost_krw'])], ['Net Cash Added', krw(cm_cash_quantity['net_cash_added_krw'])], ['Minimum Cash', krw(cm_cash_quantity['minimum_cash_krw'])], ['Post-Trade Cash', krw(cm_cash_quantity['post_trade_cash_krw'])], ['Shortfall After Trade', krw(cm_cash_quantity['cash_shortfall_after_trade_krw'])], ['Cash Over-repair', krw(cm_cash_quantity['cash_over_repair_krw'])], ['Residual Donor Value', krw(cm_cash_quantity['residual_donor_value_krw'])], ['Step 2 Max Gross Donor', krw(cm_cash_quantity['step2_max_gross_donor_krw'])], ['Step 2 Max Net Recipient', krw(cm_cash_quantity['step2_max_net_recipient_krw'])], ['Execution Authorization', 'NONE']], columns=['Quantity-step Item', 'Value'])
    _locale.dataframe(st, quantity_rows, width='stretch', hide_index=True)
    st.caption('단위 값 추정치 = 현재 자금 제공 자산 값 ÷ 기록 수량입니다. 실제 체결가격·세금·슬리피지는 달라질 수 있습니다. 필요 매도 수량은 현금 예비금을 수학적으로 충족시키는 최소 전체-수량이며 실행 추천이 아닙니다.')
    st.markdown('**주문 단위 상태**')
    st.write(cm_cash_quantity['two_step_quantity_status'])
    if cm_cash_quantity['quantity_step_gate'] == 'PASS':
        st.success('정수 수량 기준으로 단계 1 현금 예비금 복구가 가능한 상태입니다. 실제 주문 전에는 체결가격과 비용을 다시 확인해야 합니다.')
    elif cm_cash_quantity['quantity_step_gate'] in {'REVIEW', 'BLOCKED'}:
        st.warning('정수 수량 기준 현금 보완은 추가 검토가 필요합니다.')
    if cm_cash_quantity['step2_recipient_gate'] == 'REVIEW':
        st.warning('단계 1 수량 현실화와 별개로 자금 수령 자산 단계 2는 아직 검토입니다. 최소 요구수익률 / 연결 / 운영 점검을 우회하지 않습니다.')
    if cm_cash_quantity['issues']:
        st.markdown('**주문 단위 추가 확인 이유**')
        for _issue in cm_cash_quantity['issues']:
            st.write(f'- {_issue}')
    _quantity_note = st.text_input('주문 단위 검토 메모', value='', key='migration_cash_repair_quantity_note', placeholder='예: 전체-비중 수량 실행 가능성 / 금지 투자 실행 권한')
    if st.button('현금 보완 주문 단위 검토 기록 저장', key='save_migration_cash_repair_quantity_review'):
        _quantity_row = cash_repair_quantity_review_row(cm_cash_quantity, note=_quantity_note)
        _quantity_hist = load_csv('capital_migration_cash_repair_quantity_reviews.csv')
        for _col in CASH_REPAIR_QUANTITY_REVIEW_COLS:
            if _col not in _quantity_hist.columns:
                _quantity_hist[_col] = ''
        _quantity_hist = pd.concat([_quantity_hist[CASH_REPAIR_QUANTITY_REVIEW_COLS], pd.DataFrame([_quantity_row])], ignore_index=True)
        verified_save_feedback(_quantity_hist, 'capital_migration_cash_repair_quantity_reviews.csv', 'Cash Repair Quantity-step 검토기록을 저장했습니다. Execution Authorization = NONE.', rerun=False)
    st.subheader('8C. 가격 / 체결 오차 민감도 & 수량 경계')
    st.caption('현재 단위 값 추정치가 실제 체결가격보다 낮아질 때 필요한 정수 매도수량이 언제 증가하는지 확인합니다. 가격 충격은 시장가격 하락, 추가 체결 오차는 그 가격에서 추가로 체결되는 보수적 차감입니다.')
    ps1, ps2, ps3 = st.columns(3)
    _cash_sensitivity_max_shock = ps1.number_input('최대 가격 충격', min_value=0.0, max_value=0.5, value=float(settings.get('cash_repair_sensitivity_max_price_shock', 0.1)), step=0.01, format='%.3f', key='cash_repair_sensitivity_max_price_shock', help='단위 값 추정치 대비 최대 가격하락 시나리오. 예: 0.10 = -10%.')
    _cash_sensitivity_extra_slippage = ps2.number_input('추가 체결 오차 보수적 차감', min_value=0.0, max_value=0.2, value=0.0, step=0.001, format='%.3f', key='cash_repair_sensitivity_extra_slippage', help='이전 2.0의 매도 체결비용률과 별도의 추가 체결가격 보수적 차감입니다. 기존 매도 체결비용률에 체결 오차를 이미 포함했다면 0으로 두어 중복차감을 피하세요.')
    _cash_sensitivity_steps = ps3.number_input('민감도 단계', min_value=1, max_value=20, value=int(settings.get('cash_repair_sensitivity_steps', 4)), step=1, key='cash_repair_sensitivity_steps', help='0%부터 최대 가격 충격까지 나누는 구간 수.')
    cm_cash_sensitivity = build_cash_repair_price_sensitivity(cm_cash_repair, cm_cash_quantity, max_price_shock_rate=_cash_sensitivity_max_shock, additional_slippage_haircut_rate=_cash_sensitivity_extra_slippage, sensitivity_steps=int(_cash_sensitivity_steps))
    pb1, pb2, pb3, pb4 = st.columns(4)
    pb1.metric('손익분기 매도 가격', _locale.code('-' if cm_cash_sensitivity['break_even_sell_price_krw'] is None else krw(cm_cash_sensitivity['break_even_sell_price_krw'])))
    pb2.metric('가격 여유분 대상 수량 단계-증가', _locale.code('-' if cm_cash_sensitivity['price_buffer_rate'] is None else pct(cm_cash_sensitivity['price_buffer_rate'])))
    pb3.metric('최악의 경우 필요 수량', _locale.code('-' if cm_cash_sensitivity['worst_case_required_sell_quantity'] is None else f"{cm_cash_sensitivity['worst_case_required_sell_quantity']:,.0f}"))
    pb4.metric('수량 견고성 점검', _locale.code(cm_cash_sensitivity['robustness_gate']))
    pw1, pw2, pw3, pw4 = st.columns(4)
    pw1.metric('최악의 경우 충격', _locale.code('-' if cm_cash_sensitivity['worst_case_price_shock_rate'] is None else '-' + pct(cm_cash_sensitivity['worst_case_price_shock_rate'])))
    pw2.metric('최악의 경우 매도 가격', _locale.code('-' if cm_cash_sensitivity['worst_case_effective_sell_price_krw'] is None else krw(cm_cash_sensitivity['worst_case_effective_sell_price_krw'])))
    pw3.metric('최악의 경우 매매 후 현금', _locale.code('-' if cm_cash_sensitivity['worst_case_post_trade_cash_krw'] is None else krw(cm_cash_sensitivity['worst_case_post_trade_cash_krw'])))
    pw4.metric('경계 상태', _locale.code(cm_cash_sensitivity['boundary_status']))
    _sensitivity_table = cm_cash_sensitivity['table'].copy()
    if _sensitivity_table.empty:
        st.warning('가격 민감도 Table을 계산할 수 없습니다.')
    else:
        for _c in ['price_shock_rate', 'additional_slippage_haircut_rate', 'sell_friction_rate']:
            _sensitivity_table[_c] = pd.to_numeric(_sensitivity_table[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
        for _c in ['market_price_krw', 'effective_sell_price_krw', 'net_cash_per_unit_krw', 'executable_gross_trim_krw', 'estimated_friction_cost_krw', 'net_cash_added_krw', 'post_trade_cash_krw', 'cash_shortfall_after_trade_krw', 'cash_over_repair_krw']:
            _sensitivity_table[_c] = pd.to_numeric(_sensitivity_table[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}원')
        for _c in ['required_sell_quantity', 'executable_sell_quantity', 'quantity_step_up']:
            _sensitivity_table[_c] = pd.to_numeric(_sensitivity_table[_c], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:,.0f}')
        _locale.dataframe(st, _sensitivity_table, width='stretch', hide_index=True)
    st.caption('손익분기 매도 가격은 현재 필요 매도 수량을 그대로 유지하면서 최소 필요 현금을 충족시키는 최소 기준가격입니다. 가격 여유분을 넘어 가격이 하락하면 필요한 정수수량이 한 단계 증가합니다.')
    if cm_cash_sensitivity['robustness_gate'] == 'PASS':
        st.success('선택한 가격/체결 오차 구간 전 구간에서 현재 필요 매도 수량이 그대로 현금 예비금을 복구합니다.')
    elif cm_cash_sensitivity['robustness_gate'] == 'REVIEW':
        st.warning('선택한 구간 안에서 현금 보완은 가능하지만 필요한 정수수량이 증가하는 구간이 있습니다. 실제 가격을 확인한 뒤 수량을 다시 계산해야 합니다.')
    else:
        st.error('선택한 구간 중 보유수량으로 현금 예비금을 복구할 수 없는 시나리오가 있습니다.')
    if cm_cash_sensitivity['issues']:
        st.markdown('**가격 / 체결 오차 민감도 추가 확인 이유**')
        for _issue in cm_cash_sensitivity['issues']:
            st.write(f'- {_issue}')
    _sensitivity_note = st.text_input('가격 / 체결 오차 민감도 검토 메모', value='', key='cash_repair_sensitivity_note', placeholder='예: 가격 구간 견고성 / 금지 투자 실행 권한')
    if st.button('가격 / 체결 오차 민감도 검토 기록 저장', key='save_cash_repair_sensitivity_review'):
        _sensitivity_row = cash_repair_sensitivity_review_row(cm_cash_sensitivity, note=_sensitivity_note)
        _sensitivity_hist = load_csv('capital_migration_cash_repair_sensitivity_reviews.csv')
        for _col in CASH_REPAIR_SENSITIVITY_REVIEW_COLS:
            if _col not in _sensitivity_hist.columns:
                _sensitivity_hist[_col] = ''
        _sensitivity_hist = pd.concat([_sensitivity_hist[CASH_REPAIR_SENSITIVITY_REVIEW_COLS], pd.DataFrame([_sensitivity_row])], ignore_index=True)
        verified_save_feedback(_sensitivity_hist, 'capital_migration_cash_repair_sensitivity_reviews.csv', f"Price / Slippage Sensitivity 검토기록을 저장했습니다. Robustness {cm_cash_sensitivity['robustness_gate']} · Execution Authorization = NONE.", rerun=False)
    st.subheader('8D. 매매 전 가격 경계 / 호가 검증 관리 기준')
    st.caption('실제 주문 직전 사용자가 직접 확인한 호가를 손익분기 가격과 다시 비교합니다. 호가 출처·기록 시각·최신성·전체-수량을 확인할 뿐 주문은 생성하지 않습니다.')
    qv1, qv2 = st.columns(2)
    _pretrade_quote_price = qv1.number_input('관찰된 호가 가격 (원화)', min_value=0.0, value=0.0, step=100.0, format='%.2f', key='cash_repair_pretrade_quote_price', help='실제 주문 직전 직접 확인한 매도 기준 호가를 입력합니다. 단위 값 추정치를 자동으로 호가로 간주하지 않습니다.')
    _pretrade_quote_source = qv2.text_input('호가 출처', value='', key='cash_repair_pretrade_quote_source', placeholder='예: 증권사 호가창 / 거래소 호가')
    qv3, qv4 = st.columns(2)
    _pretrade_quote_timestamp = qv3.text_input('호가 시각(국제 표준 날짜·시간 형식과 시간대)', value='', key='cash_repair_pretrade_quote_timestamp', placeholder='예: 2026-09-21T17:20:00+09:00', help='시간대 offset가 포함된 기록 시각이 필요합니다.')
    _pretrade_extra_slippage = qv4.number_input('매매 전 추가 체결 오차 보수적 차감', min_value=0.0, max_value=0.2, value=0.0, step=0.001, format='%.3f', key='cash_repair_pretrade_extra_slippage', help='관찰된 호가에서 추가로 보수적으로 보수적 차감할 비율입니다. 이전 2.0 매도 체결비용률에 이미 체결 오차를 반영했다면 0으로 두세요.')
    _pretrade_human_confirmed = st.checkbox('호가 가격 / 출처 / 기록 시각을 직접 확인했습니다.', key='cash_repair_pretrade_human_confirmed')
    cm_quote_validation = validate_cash_repair_pretrade_quote(cm_cash_repair, cm_cash_quantity, cm_cash_sensitivity, quote_price_krw=_pretrade_quote_price, quote_timestamp=_pretrade_quote_timestamp, quote_source=_pretrade_quote_source, additional_slippage_haircut_rate=_pretrade_extra_slippage, human_quote_confirmed=_pretrade_human_confirmed, max_quote_age_minutes=float(settings.get('cash_repair_quote_max_age_minutes', 5.0)), future_tolerance_minutes=float(settings.get('cash_repair_quote_future_tolerance_minutes', 2.0)))
    qg1, qg2, qg3, qg4 = st.columns(4)
    qg1.metric('호가 검증 점검', _locale.code(cm_quote_validation['quote_validation_gate']))
    qg2.metric('호가 최신성', _locale.code(cm_quote_validation['quote_freshness_gate']))
    qg3.metric('경계 상태', _locale.code(cm_quote_validation['boundary_status']))
    qg4.metric('투자 실행 권한', '없음')
    qb1, qb2, qb3, qb4 = st.columns(4)
    qb1.metric('손익분기 호가 가격', _locale.code('-' if cm_quote_validation['break_even_quote_price_krw'] is None else krw(cm_quote_validation['break_even_quote_price_krw'])))
    qb2.metric('관찰된 호가', _locale.code('-' if cm_quote_validation['quote_price_krw'] is None else krw(cm_quote_validation['quote_price_krw'])))
    qb3.metric('필요 수량 @ 호가', _locale.code('-' if cm_quote_validation['quote_required_sell_quantity'] is None else f"{cm_quote_validation['quote_required_sell_quantity']:,.0f}"))
    qb4.metric('호가 경과 기간', _locale.code('-' if cm_quote_validation['quote_age_minutes'] is None else f"{cm_quote_validation['quote_age_minutes']:.1f} 최소"))
    qp1, qp2, qp3, qp4 = st.columns(4)
    qp1.metric('유효 매도 가격', _locale.code('-' if cm_quote_validation['effective_sell_price_krw'] is None else krw(cm_quote_validation['effective_sell_price_krw'])))
    qp2.metric('매매 후 현금', _locale.code(krw(cm_quote_validation['post_trade_cash_krw'])))
    qp3.metric('현금 부족액 변경 후', _locale.code(krw(cm_quote_validation['cash_shortfall_after_trade_krw'])))
    qp4.metric('현금 초과-보완', _locale.code(krw(cm_quote_validation['cash_over_repair_krw'])))
    if cm_quote_validation['quote_validation_gate'] == 'PASS':
        st.success('최신 호가 기준으로 현재 계획수량이 현금 예비금 경계를 충족합니다. 이 정상은 호가/수량 검증일 뿐 실행 승인이나 매도 지시가 아닙니다.')
    elif cm_quote_validation['quote_validation_gate'] == 'BLOCKED':
        st.error('현재 호가와 보유수량으로 현금 예비금 경계를 충족할 수 없습니다.')
    else:
        st.warning('매매 전 호가 검증은 검토입니다. 호가 최신성 / 출처 / 사용자 확인 또는 주문 단위-증가를 확인하세요.')
    if cm_quote_validation['issues']:
        st.markdown('**호가 검증 추가 확인 이유**')
        for _issue in cm_quote_validation['issues']:
            st.write(f'- {_issue}')
    _quote_validation_note = st.text_input('호가 검증 검토 메모', value='', key='cash_repair_quote_validation_note', placeholder='예: 최신 증권사 호가 확인됨 / 금지 투자 실행 권한')
    if st.button('매매 전 호가 검증 검토 기록 저장', key='save_cash_repair_quote_validation_review'):
        _quote_row = cash_repair_quote_validation_review_row(cm_quote_validation, note=_quote_validation_note)
        _quote_hist = load_csv('capital_migration_cash_repair_quote_validations.csv')
        for _col in CASH_REPAIR_QUOTE_VALIDATION_COLS:
            if _col not in _quote_hist.columns:
                _quote_hist[_col] = ''
        _quote_hist = pd.concat([_quote_hist[CASH_REPAIR_QUOTE_VALIDATION_COLS], pd.DataFrame([_quote_row])], ignore_index=True)
        verified_save_feedback(_quote_hist, 'capital_migration_cash_repair_quote_validations.csv', f"Pre-Trade Quote Validation 검토기록을 저장했습니다. Gate {cm_quote_validation['quote_validation_gate']} · Execution Authorization = NONE.", rerun=False)
    st.subheader('8E. 매매 전 판단 자료 묶음 / 상태 기록 고정')
    st.caption('투자 가정 / 포트폴리오 / 이전 점검 / 현금 보완 / 수량 / 민감도 / 최신 호가를 하나의 불변 상태 기록으로 묶습니다. 자료 묶음 완성은 투자승인이나 주문승인이 아니라 해당 시점의 검토상태를 감사 가능하게 고정하는 절차입니다.')
    cm_pretrade_context = build_pretrade_packet_context(donor_name=donor_choice, recipient_name=recipient_choice, donor_kind=donor_kind, recipient_kind=recipient_kind, comparison_amount_krw=migration_amount, portfolio=portfolio, assumption_health=cm_cp_context['health'], assumption_bridge=cm_assumption_bridge, bridge_reconciliation=cm_bridge_reconciliation, migration_review=review, migration_v2_review=v2_review, cash_repair_plan=cm_cash_repair, quantity_plan=cm_cash_quantity, sensitivity_plan=cm_cash_sensitivity, quote_validation=cm_quote_validation)
    pt1, pt2, pt3, pt4 = st.columns(4)
    pt1.metric('자료 묶음 맥락', _locale.code(cm_pretrade_context['completeness_gate']))
    pt2.metric('판단 상태', _locale.code(cm_pretrade_context['decision_state']))
    pt3.metric('상태 기록 무결성 해시', _locale.code(cm_pretrade_context['snapshot_hash'][:12] if cm_pretrade_context['snapshot_hash'] else '-'))
    pt4.metric('투자 실행 권한', '없음')
    packet_gate_rows = pd.DataFrame([['Assumption Bridge', cm_pretrade_context['bridge_mapping_gate']], ['Bridge Reconciliation', cm_pretrade_context['bridge_reconciliation_gate']], ['Donor Assumption Health', cm_pretrade_context['donor_health']], ['Recipient Assumption Health', cm_pretrade_context['recipient_health']], ['Cash Repair', cm_pretrade_context['cash_repair_gate']], ['Quantity-step', cm_pretrade_context['quantity_step_gate']], ['Sensitivity', cm_pretrade_context['sensitivity_gate']], ['Fresh Quote Validation', cm_pretrade_context['quote_validation_gate']], ['Quote Freshness', cm_pretrade_context['quote_freshness_gate']], ['Recipient Lifecycle', cm_pretrade_context['recipient_lifecycle_gate']], ['Recipient Execution', cm_pretrade_context['recipient_execution_gate']], ['Recipient Add Freeze', cm_pretrade_context['recipient_add_freeze_gate']], ['Recipient Survival', cm_pretrade_context['recipient_survival_gate']], ['Portfolio Fit', cm_pretrade_context['recipient_fit_gate']], ['Recipient Capacity', cm_pretrade_context['recipient_capacity_gate']], ['Cash Reserve', cm_pretrade_context['cash_reserve_gate']], ['Switching Gap', cm_pretrade_context['switching_gap_gate']], ['Recipient Factor Risk', cm_pretrade_context['recipient_factor_risk_gate']]], columns=['Packet Component / Gate', 'Snapshot Status'])
    _locale.dataframe(st, packet_gate_rows, width='stretch', hide_index=True)
    st.caption('자료 묶음 맥락 정상은 상태 기록에 필요한 출처/투자 가정/호가 무결성이 준비됐다는 뜻입니다. 아래 이전/현금/최소 요구수익률 점검이 검토/차단됨라면 그 상태 역시 그대로 자료 묶음에 잠깁니다.')
    if cm_pretrade_context['issues']:
        st.warning(_locale.message('자료 묶음 맥락 미완료 · ' + ' | '.join(cm_pretrade_context['issues'])))
    _packet_review_basis = st.text_area('매매 전 자료 묶음 검토 근거', value='', key='pretrade_packet_review_basis', height=100, placeholder='예: 승인됨 가정 / 현재 포트폴리오 / 이전 점검 항목 / 현금 보완 / 수량 경계 / 최신 호가를 동일 시점 기준으로 검토.')
    pc1, pc2 = st.columns(2)
    _packet_source_confirm = pc1.checkbox('투자 가정 작동 상태 / 연결 / 포트폴리오 상태 기록 근거를 직접 확인했습니다.', key='pretrade_packet_source_confirm')
    _packet_decision_confirm = pc2.checkbox('이전 / 현금 예비금 / 자금 수령 자산 점검의 정상·검토·차단됨 상태를 그대로 확인했습니다.', key='pretrade_packet_decision_confirm')
    pc3, pc4 = st.columns(2)
    _packet_quote_confirm = pc3.checkbox('최신 호가 검증과 가격/수량 경계를 직접 확인했습니다.', key='pretrade_packet_quote_confirm')
    _packet_no_exec_confirm = pc4.checkbox('이 자료 묶음은 투자 실행 권한을 생성하지 않으며 주문 지시가 아님을 확인했습니다.', key='pretrade_packet_no_exec_confirm')
    _packet_human_confirm = st.checkbox('현재 매매 전 판단 자료 묶음을 최종 사용자 검토했습니다.', key='pretrade_packet_human_confirm')
    _packet_review_note = st.text_input('매매 전 자료 묶음 메모', value='', key='pretrade_packet_review_note', placeholder='예: 검토 완료 / 판단 상태 보존됨 / 금지 투자 실행 권한')
    cm_pretrade_review = validate_pretrade_packet_review(cm_pretrade_context, review_basis=_packet_review_basis, source_gate_confirmed=_packet_source_confirm, decision_gate_confirmed=_packet_decision_confirm, quote_gate_confirmed=_packet_quote_confirm, no_execution_authorization_confirmed=_packet_no_exec_confirm, human_review_confirmed=_packet_human_confirm)
    pr1, pr2, pr3 = st.columns(3)
    pr1.metric('자료 묶음 검토 점검', _locale.code(cm_pretrade_review['review_gate']))
    pr2.metric('검토-완료 상태', _locale.code(cm_pretrade_review['final_packet_status']))
    pr3.metric('투자 실행 권한', '없음')
    if cm_pretrade_review['review_gate'] == 'PASS':
        st.success('자료 묶음 검토 정상. REVIEW_COMPLETE로 저장해도 현재 판단 상태와 모든 점검은 그대로 기록되며 주문이나 실행권한은 생성되지 않습니다.')
    else:
        st.warning(_locale.message('자료 묶음 검토 미완료 · ' + ' | '.join(cm_pretrade_review['issues'])))
    pbs1, pbs2 = st.columns(2)
    if pbs1.button('매매 전 자료 묶음 초안 저장', key='save_pretrade_packet_draft'):
        _packet_row = build_pretrade_packet_record(cm_pretrade_context, cm_pretrade_review, save_status='DRAFT', review_basis=_packet_review_basis, source_gate_confirmed=_packet_source_confirm, decision_gate_confirmed=_packet_decision_confirm, quote_gate_confirmed=_packet_quote_confirm, no_execution_authorization_confirmed=_packet_no_exec_confirm, human_review_confirmed=_packet_human_confirm, review_note=_packet_review_note)
        _packet_hist = load_csv('pretrade_decision_packets.csv')
        for _col in PRETRADE_PACKET_COLS:
            if _col not in _packet_hist.columns:
                _packet_hist[_col] = ''
        _packet_hist = pd.concat([_packet_hist[PRETRADE_PACKET_COLS], pd.DataFrame([_packet_row])], ignore_index=True)
        verified_save_feedback(_packet_hist, 'pretrade_decision_packets.csv', f"Pre-Trade Packet DRAFT 저장 · {_packet_row['packet_id']} · Execution Authorization = NONE.", rerun=False)
    if pbs2.button('매매 전 자료 묶음 검토 · 완료 저장', disabled=cm_pretrade_review['review_gate'] != 'PASS', key='save_pretrade_packet_review_complete'):
        _packet_row = build_pretrade_packet_record(cm_pretrade_context, cm_pretrade_review, save_status='REVIEW_COMPLETE', review_basis=_packet_review_basis, source_gate_confirmed=_packet_source_confirm, decision_gate_confirmed=_packet_decision_confirm, quote_gate_confirmed=_packet_quote_confirm, no_execution_authorization_confirmed=_packet_no_exec_confirm, human_review_confirmed=_packet_human_confirm, review_note=_packet_review_note)
        _packet_hist = load_csv('pretrade_decision_packets.csv')
        for _col in PRETRADE_PACKET_COLS:
            if _col not in _packet_hist.columns:
                _packet_hist[_col] = ''
        _packet_hist = pd.concat([_packet_hist[PRETRADE_PACKET_COLS], pd.DataFrame([_packet_row])], ignore_index=True)
        verified_save_feedback(_packet_hist, 'pretrade_decision_packets.csv', f"Pre-Trade Packet REVIEW_COMPLETE 저장 · {_packet_row['packet_id']} · Decision State {_packet_row['decision_state']} · Execution Authorization = NONE.", rerun=False)
    _packet_history = load_csv('pretrade_decision_packets.csv')
    if not _packet_history.empty:
        _packet_view = _packet_history.tail(20).copy()
        if 'snapshot_payload_json' in _packet_view.columns:
            _packet_view = _packet_view.drop(columns=['snapshot_payload_json'])
        with st.expander('매매 전 판단 자료 묶음 최근 기록', expanded=False):
            _locale.dataframe(st, _packet_view, width='stretch', hide_index=True)
            _latest_packet = _packet_history.iloc[-1].to_dict()
            _latest_integrity = pretrade_packet_integrity(_latest_packet)
            st.caption(f"최신 자료 묶음 무결성 · 상태 기록 {_locale.code(_latest_integrity['snapshot_hash_status'])} · 기록 {_locale.code(_latest_integrity['record_hash_status'])} · 전체 {_locale.code(_latest_integrity['integrity_status'])}")
    st.subheader('8F. 자료 묶음 최신성 / 가설 무효화 점검')
    st.caption('저장된 검토 · 완료 자료 묶음의 불변 상태 기록과 현재 실전 상태를 다시 비교합니다. 현재는 현재 상태 기록이 아직 같은 상태라는 뜻일 뿐 투자승인/주문승인이 아닙니다. 실전 상태가 바뀌거나 호가가 만료되면 오래됨, 저장된 자료 묶음 자체의 무결성 해시/검토 무결성이 깨지면 무효화됨입니다.')
    _packet_monitor_history = load_csv('pretrade_decision_packets.csv')
    if _packet_monitor_history.empty:
        st.info('감시할 매매 전 자료 묶음이 없습니다. 먼저 8E에서 검토 · 완료 자료 묶음을 저장하세요.')
    else:
        if 'packet_status' not in _packet_monitor_history.columns:
            _packet_monitor_history['packet_status'] = ''
        _packet_monitor_complete = _packet_monitor_history.loc[_packet_monitor_history['packet_status'].fillna('').astype(str).str.upper().eq('REVIEW_COMPLETE')].copy()
        if _packet_monitor_complete.empty:
            st.info("검토 · 완료 자료 묶음이 없습니다. 8E의 '매매 전 자료 묶음 검토 · 완료 저장'을 먼저 완료하세요.")
        else:
            _packet_monitor_indices = list(_packet_monitor_complete.index[::-1])

            def _packet_monitor_label(_idx):
                _row = _packet_monitor_complete.loc[_idx]
                return f"{_row.get('packet_id', '')} | {_row.get('created_at', '')} | Decision {_row.get('decision_state', '')}"
            _packet_monitor_idx = st.selectbox('감시할 검토 · 완료 자료 묶음', options=_packet_monitor_indices, index=0, format_func=_packet_monitor_label, key='pretrade_packet_monitor_index')
            _packet_monitor_row = _packet_monitor_complete.loc[_packet_monitor_idx].to_dict()
            cm_packet_freshness = evaluate_pretrade_packet_freshness(_packet_monitor_row, cm_pretrade_context, now=datetime.now().astimezone().isoformat(), max_quote_age_minutes=float(settings.get('cash_repair_quote_max_age_minutes', 5.0)), future_tolerance_minutes=float(settings.get('cash_repair_quote_future_tolerance_minutes', 2.0)))
            pf1, pf2, pf3, pf4 = st.columns(4)
            pf1.metric('자료 묶음 실전 상태', _locale.code(cm_packet_freshness['live_status']))
            pf2.metric('고정됨 판단 상태', _locale.code(cm_packet_freshness['locked_decision_state']))
            pf3.metric('고정됨 호가 경과 기간', _locale.code('-' if cm_packet_freshness['quote_age_minutes'] is None else f"{cm_packet_freshness['quote_age_minutes']:.1f} 최소"))
            pf4.metric('투자 실행 권한', '없음')
            if cm_packet_freshness['live_status'] == 'CURRENT':
                st.success('현재 · 저장된 자료 묶음 무결성과 현재 실전 상태 기록이 일치하고 고정됨 호가가 최신 범위 안입니다. 기초자산 판단 상태는 별도이며 투자 실행 권한은 없음입니다.')
            elif cm_packet_freshness['live_status'] == 'STALE':
                st.warning('오래됨 · 저장된 자료 묶음 자체는 보존되어 있지만 시간 경과 또는 실전 상태 변경으로 현재 실행 전 근거로 재사용할 수 없습니다. 새 투자 근거/호가 기준으로 8E 자료 묶음을 다시 만들어야 합니다.')
            else:
                st.error('무효화됨 · 저장된 자료 묶음 자체의 상태 기록/기록/관리 기준 무결성에 문제가 있습니다. 이 자료 묶음은 실행 전 근거로 사용할 수 없습니다.')
            _packet_status_table = pd.DataFrame([['Stored Packet Integrity', cm_packet_freshness['integrity_status']], ['Identity / Amount', cm_packet_freshness['identity_status']], ['Assumption Snapshot', cm_packet_freshness['assumption_status']], ['Portfolio Snapshot', cm_packet_freshness['portfolio_status']], ['Migration Context', cm_packet_freshness['migration_status']], ['Sensitivity Scenario', cm_packet_freshness['sensitivity_status']], ['Quote Snapshot', cm_packet_freshness['quote_status']], ['Full Packet Snapshot', cm_packet_freshness['full_snapshot_status']]], columns=['Freshness Component', 'Status'])
            _locale.dataframe(st, _packet_status_table, width='stretch', hide_index=True)
            if cm_packet_freshness['issues']:
                st.warning(_locale.message('최신성 / 가설 무효화 사유 · ' + ' | '.join(cm_packet_freshness['issues'])))
            with st.expander('자료 묶음 상태 기록 기준 이탈 상세 비교', expanded=False):
                _component_checks_df = pd.DataFrame(cm_packet_freshness['component_checks'])
                _locale.dataframe(st, _component_checks_df, width='stretch', hide_index=True)
                st.caption(f"상태 기록 무결성 해시 · {_locale.code(cm_packet_freshness['snapshot_hash_status'])} / 기록 무결성 해시 · {_locale.code(cm_packet_freshness['record_hash_status'])} / 전체 무결성 · {_locale.code(cm_packet_freshness['integrity_status'])}")
            _freshness_note = st.text_input('자료 묶음 최신성 판정 메모', value='', key='pretrade_packet_freshness_note', placeholder='예: 기능 검사 / 현재 상태 요약 확인 / 금지 투자 실행 권한')
            if st.button('자료 묶음 최신성 / 가설 무효화 지금 다시 판정', key='rerun_pretrade_packet_freshness'):
                st.rerun()
            if st.button('자료 묶음 최신성 판정 기록 저장', key='save_pretrade_packet_freshness_review'):
                _freshness_row = build_pretrade_packet_freshness_record(cm_packet_freshness, note=_freshness_note)
                _freshness_hist = load_csv('pretrade_packet_freshness_reviews.csv')
                for _col in PRETRADE_PACKET_FRESHNESS_COLS:
                    if _col not in _freshness_hist.columns:
                        _freshness_hist[_col] = ''
                _freshness_hist = pd.concat([_freshness_hist[PRETRADE_PACKET_FRESHNESS_COLS], pd.DataFrame([_freshness_row])], ignore_index=True)
                verified_save_feedback(_freshness_hist, 'pretrade_packet_freshness_reviews.csv', f"Packet Freshness 판정 저장 · {_freshness_row['live_status']} · {_freshness_row['packet_id']} · Execution Authorization = NONE.", rerun=False)
            _freshness_history = load_csv('pretrade_packet_freshness_reviews.csv')
            if not _freshness_history.empty:
                with st.expander('자료 묶음 최신성 최근 판정 기록', expanded=False):
                    _locale.dataframe(st, _freshness_history.tail(20), width='stretch', hide_index=True)
    v2_note = st.text_input('이전 2.0 검토 메모', value='', key='migration_v2_note', placeholder='예: 증권사 수수료 확인 전 잠정 근거')
    if st.button('현재 자본 이동 2.0 검토 저장', key='save_migration_v2_review'):
        v2_row = migration_v2_review_row(review=v2_review, costs=v2_costs, factor_risk=v2_factor_risk, donor_name=donor_choice, donor_kind=donor_kind, recipient_name=recipient_choice, recipient_kind=recipient_kind, donor_forward_er=donor_er, recipient_forward_er=recipient_er, risk_repair_mode=risk_repair_mode, risk_repair_factor=selected_repair_factor, note=v2_note)
        v2_hist = load_csv('migration_v2_reviews.csv')
        for col in MIGRATION_V2_REVIEW_COLS:
            if col not in v2_hist.columns:
                v2_hist[col] = ''
        v2_hist = pd.concat([v2_hist[MIGRATION_V2_REVIEW_COLS], pd.DataFrame([v2_row])], ignore_index=True)
        verified_save_feedback(v2_hist, 'migration_v2_reviews.csv', 'Capital Migration 2.0 검토를 저장했습니다.', rerun=False)
    v2_history = load_csv('migration_v2_reviews.csv')
    if not v2_history.empty:
        _locale.dataframe(st, v2_history.tail(20), width='stretch', hide_index=True)
    st.subheader('9. 기존 자본 이동 검토 기록')
    st.caption('기존 v1 방식의 검토기록도 그대로 유지합니다. 이전 2.0 기록은 migration_v2_reviews.csv에 별도로 저장됩니다.')
    if st.button('현재 자본 이동 검토 저장', key='save_migration_review'):
        row = migration_review_row(review, donor_forward_er=donor_er, recipient_forward_er=recipient_er, tax_cost=tax, trading_cost=trading, incremental_risk_penalty=risk_penalty)
        hist = load_csv('migration_reviews.csv')
        for col in MIGRATION_REVIEW_COLS:
            if col not in hist.columns:
                hist[col] = ''
        hist = pd.concat([hist[MIGRATION_REVIEW_COLS], pd.DataFrame([row])], ignore_index=True)
        save_csv(hist, 'migration_reviews.csv')
        st.success('자본 이동 검토를 저장했습니다.')
    history = load_csv('migration_reviews.csv')
    if not history.empty:
        _locale.dataframe(st, history.tail(20), width='stretch', hide_index=True)
    st.caption('자본 이동은 다음 1원의 비교도구입니다. 투자 요인 위험 보완은 기존 집중위험을 줄이는지 별도로 확인하고, 예상 수익률은 같은 기간·같은 기준으로 비교합니다. 실제 실행 전에는 투자 단계 / 실행 점검 / 투자 가설 / 포트폴리오 적합성을 다시 확인하세요.')
