from __future__ import annotations
import ui_locale as _locale
if True:
    st.title('저장 센터')
    st.caption('저장이 실제로 완료됐는지 확인하고, 사용자 데이터를 한 번에 백업하는 화면입니다.')
    st.info(f'{VERSION} · 표 데이터 저장은 `백업 → 임시파일 저장 → 원본 교체 → 즉시 재읽기 검증`을 거칩니다. 정상이라면 저장 버튼을 여러 번 누를 필요가 없습니다.')
    save_health = verify_user_data_health()
    fail_count = int((save_health['status'] == 'FAIL').sum()) if not save_health.empty else 0
    pass_count = int((save_health['status'] == 'PASS').sum()) if not save_health.empty else 0
    st.subheader('1. 현재 저장 상태')
    s1, s2, s3 = st.columns(3)
    s1.metric('표 데이터 정상', _locale.code(pass_count))
    s2.metric('표 데이터 실패', _locale.code(fail_count))
    s3.metric('검사 파일', _locale.code(len(save_health)))
    if fail_count == 0:
        st.success('현재 읽을 수 없는 표 데이터 파일이 없습니다.')
    else:
        st.error('읽기 실패한 표 데이터가 있습니다. 아래 오류 열을 확인하세요.')
    if save_health.empty:
        st.info('데이터 폴더에 표 데이터 파일이 없습니다.')
    else:
        _locale.dataframe(st, save_health, width='stretch', hide_index=True)
    _sc_learning_release = build_learning_cycle_release_gate(load_csv('decision_learning_lineage.csv'), load_csv('learning_feedback_proposals.csv'), load_csv('learning_feedback_revalidation_drafts.csv'), load_csv('learning_feedback_change_lineage.csv'), load_csv('capital_productivity_inputs.csv'), load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'), today=date.today())
    st.subheader('1A. v1.22 학습 배포 데이터 점검')
    sd1, sd2, sd3, sd4 = st.columns(4)
    sd1.metric('표 데이터 데이터 점검', _locale.code('정상' if fail_count == 0 else '실패'))
    sd2.metric('학습 배포 점검', _locale.code(_sc_learning_release['release_gate']))
    sd3.metric('학습 연결되지 않은 항목', _locale.code(_sc_learning_release['orphan_count']))
    sd4.metric('투자 실행 권한', '없음')
    st.caption('여기서는 저장 가능성 + 학습 주기 데이터 무결성을 같이 봅니다. 진행 중 주기는 허용하지만 표 데이터 실패 / 무결성 해시 불일치 / 연결되지 않은 항목은 배포 전에 해결합니다.')
    _sc_forecast_release = build_forecast_calibration_release_gate(load_csv('forecast_change_registry.csv'), load_csv('forecast_change_implementation_events.csv'), load_csv('forecast_change_effect_reviews.csv'), load_csv('decision_learning_lineage.csv'), today=date.today())
    st.subheader('1B. v1.23 예측 정확도 점검 배포 데이터 점검')
    fd1, fd2, fd3, fd4 = st.columns(4)
    fd1.metric('표 데이터 데이터 점검', _locale.code('정상' if fail_count == 0 else '실패'))
    fd2.metric('예측 배포 점검', _locale.code(_sc_forecast_release['release_gate']))
    fd3.metric('상위 연결 문제', _locale.code(_sc_forecast_release['parent_link_issues']))
    fd4.metric('투자 실행 권한', '없음')
    st.caption('예측 변경 계획 / 변경 이행 기록 / 효과 검토의 저장 무결성과 상위 연결 이력을 확인합니다. 진행 중 확인 근거 검토는 허용하지만 표 데이터 실패 / 무결성 해시 불일치 / 누락 상위는 배포 전에 해결합니다.')
    _sc_v123_crosscheck = build_v123_data_crosscheck(csv_fail_count=fail_count, learning_release_gate=_sc_learning_release['release_gate'], forecast_release_gate=_sc_forecast_release['release_gate'])
    st.subheader('1C. v1.23 전체 연결 흐름 배포 데이터 교차 점검')
    scc1, scc2, scc3 = st.columns(3)
    scc1.metric('데이터 교차 점검', _locale.code(_sc_v123_crosscheck['status']))
    scc2.metric('차단 사유 점검 항목', _locale.code(_sc_v123_crosscheck['blocking_count']))
    scc3.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v123_crosscheck['checks'], width='stretch', hide_index=True)
    if _sc_v123_crosscheck['status'] == 'PASS':
        st.success('v1.23 배포 데이터 교차 점검 정상 · 표 데이터 / 학습 / 예측 데이터 무결성 차단 사유 점검이 없습니다.')
    else:
        st.error('v1.23 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 학습/예측 데이터 점검을 확인하세요.')
    _sc_latest_backup = latest_user_backup()
    _sc_save_events = get_save_events(50)
    _sc_recovery = build_recovery_readiness(csv_pass=pass_count, csv_fail=fail_count, current_csv_files=len(save_health), backup_info=_sc_latest_backup, save_events=_sc_save_events, max_backup_age_days=7, recent_event_window=20, now=datetime.now().astimezone())
    st.subheader('1D. 복구 준비 상태 / 백업 최신성 보호 점검')
    rr1, rr2, rr3, rr4, rr5 = st.columns(5)
    rr1.metric('복구 준비 상태', _locale.code(_sc_recovery['recovery_status']))
    rr2.metric('백업 존재 여부', _locale.code('YES' if _sc_recovery['backup_exists'] else '금지'))
    rr3.metric('백업 경과 기간', _locale.code('-' if _sc_recovery['backup_age_days'] is None else f"{max(0.0, _sc_recovery['backup_age_days']):.1f}d"))
    rr4.metric('최근 저장 실패', _locale.code(_sc_recovery['recent_save_failures']))
    rr5.metric('복원 권한', '없음')
    _locale.dataframe(st, _sc_recovery['checks'], width='stretch', hide_index=True)
    if _sc_recovery['recovery_status'] == 'BLOCKED':
        st.error('복구 준비 상태 차단됨 · 현재 읽기 실패 표 데이터가 있어 백업보다 원본 데이터 복구가 우선입니다.')
    elif _sc_recovery['recovery_status'] == 'REVIEW':
        st.warning('복구 준비 상태 검토 · 백업 존재/신선도/확인 범위 또는 최근 저장 실패를 확인하세요.')
    else:
        st.success('복구 준비 상태 정상 · 현재 표 데이터 작동 상태와 최근 전체 백업의 기본 복구 준비 상태가 정상입니다.')
    st.caption('백업 확인 범위 추정치는 `최근 백업 파일 수 ≥ 현재 CSV 파일 수`를 보는 보수적 점검입니다. 실제 복원을 수행하거나 원본 파일을 덮어쓰지 않습니다. 복원 권한 = 없음.')
    _sc_recovery_note = st.text_input('복구 준비 상태 상태 기록 메모', value='', key='save_center_recovery_snapshot_note', placeholder='예: 주간 백업 준비 상태 검토 / 금지 복원 실행됨')
    if st.button('복구 준비 상태 상태 기록 저장', key='save_center_recovery_snapshot_save'):
        _rr_row = build_recovery_snapshot(_sc_recovery, note=_sc_recovery_note)
        _rr_hist = load_csv('recovery_readiness_snapshots.csv')
        for _col in RECOVERY_SNAPSHOT_COLS:
            if _col not in _rr_hist.columns:
                _rr_hist[_col] = ''
        _rr_hist = pd.concat([_rr_hist[RECOVERY_SNAPSHOT_COLS], pd.DataFrame([_rr_row])], ignore_index=True)
        verified_save_feedback(_rr_hist, 'recovery_readiness_snapshots.csv', f"Recovery Readiness Snapshot 저장 · {_rr_row['recovery_status']} · Restore Authorization = NONE.", rerun=False)
    _sc_backup_discovery = discover_latest_backup_folder(Path.cwd(), _sc_latest_backup)
    _sc_manifest_verify = verify_backup_manifest(_sc_backup_discovery)
    _sc_restore_dryrun = restore_dry_run(_sc_manifest_verify)
    _sc_recovery_locks = load_csv('recovery_point_locks.csv')
    _sc_matching_lock = latest_matching_recovery_point(_sc_recovery_locks, _sc_manifest_verify.get('manifest_sha256', ''))
    st.subheader('1E. 백업 파일 명세 검증 / 복원 모의 실행 / 복구 시점 고정')
    bm1, bm2, bm3, bm4, bm5 = st.columns(5)
    bm1.metric('백업 탐색', _locale.code(_sc_backup_discovery['status']))
    bm2.metric('파일 명세', _locale.code(_sc_manifest_verify['manifest_status']))
    bm3.metric('복원 모의 실행', _locale.code(_sc_restore_dryrun['dryrun_status']))
    bm4.metric('무결성 해시 불일치', _locale.code(_sc_manifest_verify['hash_mismatch']))
    bm5.metric('복원 권한', '없음')
    st.caption(f"백업 폴더 · {_sc_backup_discovery.get('folder_name', '-')} · 탐색 {_sc_backup_discovery.get('discovery_source', 'NONE')} · 파일 명세 항목 {_sc_manifest_verify.get('manifest_entries', 0)} · 검증됨 파일 {_sc_manifest_verify.get('files_ok', 0)} · 누락 {_sc_manifest_verify.get('missing_files', 0)}")
    if _sc_manifest_verify['manifest_status'] == 'PASS':
        st.success('파일 명세 검증 정상 · manifest.json의 SHA-256과 백업 파일이 일치합니다.')
    elif _sc_manifest_verify['manifest_status'] == 'REVIEW':
        st.warning('파일 명세 검증 검토 · 최신 백업 폴더/manifest.json 탐지가 필요합니다.')
    else:
        st.error('파일 명세 검증 차단됨 · 누락 파일 또는 SHA-256 불일치를 확인하세요.')
    if _sc_restore_dryrun['dryrun_status'] == 'PASS':
        st.success('복원 모의 실행 정상 · 표 데이터/구조화 원문을 읽기 전용으로 검사했으며 실제 파일 복원/덮어쓰기는 수행하지 않았습니다.')
    else:
        st.warning('복원 모의 실행이 아직 정상이 아닙니다. 파일 명세 문제 또는 구문 분석 실패를 먼저 확인하세요.')
    dr1, dr2, dr3, dr4 = st.columns(4)
    dr1.metric('모의 실행 파일', _locale.code(_sc_restore_dryrun['files_checked']))
    dr2.metric('표 데이터 읽기 가능', _locale.code(_sc_restore_dryrun['csv_ok']))
    dr3.metric('구조화 원문 읽기 가능', _locale.code(_sc_restore_dryrun['json_ok']))
    dr4.metric('구문 분석 실패', _locale.code(_sc_restore_dryrun['parse_fail']))
    with st.expander('파일 명세 검증 상세', expanded=False):
        _mv_rows = _sc_manifest_verify.get('entry_rows')
        if isinstance(_mv_rows, pd.DataFrame) and (not _mv_rows.empty):
            _locale.dataframe(st, _mv_rows[['manifest_path', 'status']], width='stretch', hide_index=True)
        else:
            st.info('표시할 파일 명세 항목이 없습니다.')
    with st.expander('복원 모의 실행 상세', expanded=False):
        _dr_rows = _sc_restore_dryrun.get('rows')
        if isinstance(_dr_rows, pd.DataFrame) and (not _dr_rows.empty):
            _locale.dataframe(st, _dr_rows, width='stretch', hide_index=True)
        else:
            st.info('표시할 모의 실행 결과가 없습니다.')
    if _sc_matching_lock:
        _sc_lock_integrity = recovery_point_lock_integrity(_sc_matching_lock)
        st.info(f"현재 파일 명세와 일치하는 복구 시점 고정 · {_sc_matching_lock.get('recovery_point_id', '')} · 무결성 {_locale.code(_sc_lock_integrity['status'])} · 복원 권한 없음")
    else:
        _sc_lock_integrity = {'status': 'NONE'}
    _rpl_c1, _rpl_c2 = st.columns(2)
    _rpl_manifest_confirm = _rpl_c1.checkbox('파일 명세 항목 수, 누락 수, 무결성 해시 불일치 수를 직접 확인했습니다.', value=False, key='recovery_point_manifest_confirm')
    _rpl_dryrun_confirm = _rpl_c2.checkbox('복원 모의 실행이 읽기 전용 검사이며 원본/백업 파일을 수정하지 않았음을 확인했습니다.', value=False, key='recovery_point_dryrun_confirm')
    _rpl_c3, _rpl_c4 = st.columns(2)
    _rpl_no_restore = _rpl_c3.checkbox('복구 시점 고정은 실제 복원 권한을 생성하지 않음을 확인했습니다.', value=False, key='recovery_point_no_restore_confirm')
    _rpl_human = _rpl_c4.checkbox('현재 복구 시점을 최종 사용자 검토했습니다.', value=False, key='recovery_point_human_confirm')
    _rpl_note = st.text_input('복구 시점 고정 메모', value='', key='recovery_point_lock_note', placeholder='예: 검증됨 전체 백업 / 모의 실행 전용 / 금지 복원 권한')
    _rpl_validation = validate_recovery_point_lock(_sc_manifest_verify, _sc_restore_dryrun, manifest_confirmed=_rpl_manifest_confirm, dryrun_no_write_confirmed=_rpl_dryrun_confirm, no_restore_authorization_confirmed=_rpl_no_restore, human_review_confirmed=_rpl_human)
    lg1, lg2, lg3 = st.columns(3)
    lg1.metric('복구 시점 점검', _locale.code(_rpl_validation['lock_gate']))
    lg2.metric('고정 상태', _locale.code(_rpl_validation['lock_status']))
    lg3.metric('복원 권한', '없음')
    if _rpl_validation['issues']:
        st.caption('고정 저장 전 확인 · ' + ' | '.join(_rpl_validation['issues']))
    if st.button('복구 시점 고정 저장', disabled=_rpl_validation['lock_gate'] != 'PASS', key='recovery_point_lock_save'):
        _rpl_row = build_recovery_point_lock_record(_sc_backup_discovery, _sc_manifest_verify, _sc_restore_dryrun, _rpl_validation, backup_modified=_sc_latest_backup.get('modified', ''), manifest_confirmed=_rpl_manifest_confirm, dryrun_no_write_confirmed=_rpl_dryrun_confirm, no_restore_authorization_confirmed=_rpl_no_restore, human_review_confirmed=_rpl_human, note=_rpl_note)
        _rpl_hist = load_csv('recovery_point_locks.csv')
        for _col in RECOVERY_POINT_LOCK_COLS:
            if _col not in _rpl_hist.columns:
                _rpl_hist[_col] = ''
        _rpl_hist = pd.concat([_rpl_hist[RECOVERY_POINT_LOCK_COLS], pd.DataFrame([_rpl_row])], ignore_index=True)
        verified_save_feedback(_rpl_hist, 'recovery_point_locks.csv', f"Recovery Point Lock 저장 · {_rpl_row['lock_status']} · Manifest {_rpl_row['manifest_sha256'][:8]} · Restore Authorization = NONE.", rerun=False)
    st.caption('복구 시점 고정은 검증된 백업의 파일 명세 무결성 해시와 모의 실행 결과를 추가 기록 전용으로 고정합니다. 실제 복원 실행, 파일 복사, 원본 덮어쓰기는 하지 않습니다.')
    _sc_drift = build_recovery_point_drift(_sc_manifest_verify, _sc_restore_dryrun, _sc_recovery_locks)
    _sc_rotation = build_backup_rotation_plan(_sc_recovery_locks, current_manifest_sha256=_sc_manifest_verify.get('manifest_sha256', ''), keep_latest=3)
    _sc_simulation = build_restore_simulation_plan(_sc_manifest_verify, _sc_restore_dryrun, _sc_drift)
    st.subheader('1F. 복구 시점 기준 이탈 / 백업 교체 / 복원 모의검증 계획')
    rs1, rs2, rs3, rs4, rs5 = st.columns(5)
    rs1.metric('복구 시점 기준 이탈', _locale.code(_sc_drift['drift_status']))
    rs2.metric('고정됨 시점', _locale.code(_sc_rotation['locked_points']))
    rs3.metric('교체', _locale.code(_sc_rotation['rotation_status']))
    rs4.metric('복원 모의검증', _locale.code(_sc_simulation['simulation_status']))
    rs5.metric('복원 권한', '없음')
    st.caption(f"현재 파일 명세 · {_sc_drift.get('current_manifest_sha256', '')[:12]} · 일치하는 고정 · {_sc_drift.get('matching_recovery_point_id', '-')} · 고정 무결성 {_sc_drift.get('matching_lock_integrity', 'NONE')} · 유지 최신 {_sc_rotation.get('keep_latest', 3)} · 보관 후보 {_sc_rotation.get('archive_candidates', 0)}")
    if _sc_drift['drift_status'] == 'CURRENT':
        st.success('복구 시점 현재 · 최신 검증 백업 파일 명세가 현재 복구 시점 고정과 일치합니다.')
    elif _sc_drift['drift_status'] == 'DRIFTED':
        st.warning('복구 시점 변경 감지 · 새 전체 백업이 생성됐지만 현재 파일 명세에 대한 복구 시점 고정이 아직 없습니다.')
    elif _sc_drift['drift_status'] == 'UNLOCKED':
        st.warning('복구 시점 고정 안 됨 · 검증된 백업은 있으나 복구 시점 고정 기록이 없습니다.')
    else:
        st.error('복구 시점 무결성 검토가 필요합니다. 파일 명세 / 모의 실행 / 고정 무결성 해시를 먼저 확인하세요.')
    if _sc_rotation['rotation_status'] == 'REVIEW':
        st.warning('백업 교체 검토 · 오래된 복구 시점이 보관 후보입니다. 자동 삭제/파일 삭제는 수행하지 않습니다.')
    elif _sc_rotation['rotation_status'] == 'INTEGRITY_REVIEW':
        st.error('백업 교체 무결성 검토 · 고정 무결성 해시 문제를 먼저 해결하세요.')
    elif _sc_rotation['rotation_status'] == 'PASS':
        st.success('백업 교체 정상 · 현재 보존 기준에서 보관 후보가 없습니다.')
    else:
        st.info('백업 교체 · 아직 복구 시점 고정이 없습니다.')
    if _sc_simulation['simulation_status'] == 'READY':
        st.success('복원 모의검증 준비 완료 · 복구 절차 계획을 검토할 수 있습니다. 실제 복원은 여전히 승인되지 않았습니다.')
    else:
        st.warning('복원 모의검증 차단됨 · 현재 복구 시점, 파일 명세 정상, 모의 실행 정상이 필요합니다.')
    with st.expander('백업 교체 계획 상세', expanded=False):
        _rotation_view = _sc_rotation.get('rotation_view')
        if isinstance(_rotation_view, pd.DataFrame) and (not _rotation_view.empty):
            _locale.dataframe(st, _rotation_view, width='stretch', hide_index=True)
        else:
            st.info('표시할 복구 시점 교체 항목이 없습니다.')
    with st.expander('복원 모의검증 계획 상세', expanded=False):
        _sim_steps = _sc_simulation.get('steps')
        if isinstance(_sim_steps, pd.DataFrame) and (not _sim_steps.empty):
            _locale.dataframe(st, _sim_steps, width='stretch', hide_index=True)
        else:
            st.info('표시할 복원 모의검증 단계가 없습니다.')
    _rs_note = st.text_input('복구 복원력 상태 기록 메모', value='', key='recovery_resilience_snapshot_note', placeholder='예: 현재 고정 검증됨 / 교체 검토됨 / 모의검증 계획 전용')
    if st.button('복구 복원력 상태 기록 저장', key='recovery_resilience_snapshot_save'):
        _rs_row = build_recovery_resilience_snapshot(_sc_drift, _sc_rotation, _sc_simulation, note=_rs_note)
        _rs_hist = load_csv('recovery_resilience_snapshots.csv')
        for _col in RECOVERY_RESILIENCE_SNAPSHOT_COLS:
            if _col not in _rs_hist.columns:
                _rs_hist[_col] = ''
        _rs_hist = pd.concat([_rs_hist[RECOVERY_RESILIENCE_SNAPSHOT_COLS], pd.DataFrame([_rs_row])], ignore_index=True)
        verified_save_feedback(_rs_hist, 'recovery_resilience_snapshots.csv', f"Recovery Resilience Snapshot 저장 · Drift {_rs_row['drift_status']} · Simulation {_rs_row['restore_simulation_status']} · Restore Authorization = NONE.", rerun=False)
    st.caption('교체는 부가 정보 검토 계획일 뿐 백업 폴더/파일을 삭제하지 않습니다. 복원 모의검증은 절차 계획만 생성하며 실제 파일 복원/복사/덮어쓰기를 수행하지 않습니다.')
    _sc_recovery_release = build_recovery_release_gate(_sc_recovery, _sc_manifest_verify, _sc_restore_dryrun, _sc_drift, _sc_rotation, _sc_simulation)
    _sc_runbook_locks = load_csv('disaster_recovery_runbook_locks.csv')
    _sc_current_runbook = latest_matching_runbook_lock(_sc_runbook_locks, _sc_manifest_verify.get('manifest_sha256', ''))
    st.subheader('1G. 복구 배포 점검 / 검증 종결 / 재해 복구 운영 절차 고정')
    rg1, rg2, rg3, rg4, rg5 = st.columns(5)
    rg1.metric('복구 배포 점검', _locale.code(_sc_recovery_release['release_gate']))
    rg2.metric('기술 정상', _locale.code(_sc_recovery_release['technical_pass']))
    rg3.metric('기술 실패', _locale.code(_sc_recovery_release['technical_fail']))
    rg4.metric('운영', _locale.code(_sc_recovery_release['operating_status']))
    rg5.metric('복원 권한', '없음')
    _locale.dataframe(st, _sc_recovery_release['checks'], width='stretch', hide_index=True)
    if _sc_recovery_release['release_gate'] == 'PASS':
        st.success('복구 배포 점검 정상 · 복구 준비 상태 / 파일 명세 / 모의 실행 / 현재 고정 / 모의검증 기술 무결성이 정상입니다.')
    else:
        st.error('복구 배포 점검 차단됨 · 기술 실패 항목을 먼저 해결하세요.')
    st.caption('백업 교체 보관 후보는 운영 검토가며 그 자체로 기술 배포를 차단하지 않습니다. 실제 복원과 자동 삭제는 계속 금지됩니다.')
    if _sc_current_runbook:
        _sc_runbook_integrity = dr_runbook_lock_integrity(_sc_current_runbook)
        st.info(f"현재 파일 명세와 일치하는 재해 복구 운영 절차 고정 · {_sc_current_runbook.get('runbook_lock_id', '')} · 검증 {_locale.code(_sc_current_runbook.get('audit_closure_status', ''))} · 무결성 {_locale.code(_sc_runbook_integrity['status'])} · 복원 권한 없음")
    else:
        _sc_runbook_integrity = {'status': 'NONE'}
    rb1, rb2 = st.columns(2)
    _rb_release_confirm = rb1.checkbox('복구 배포 점검의 8개 기술 확인과 현재 복구 시점을 직접 확인했습니다.', value=False, key='dr_runbook_release_confirm')
    _rb_emergency_confirm = rb2.checkbox('향후 실제 복구 전 현재 데이터 긴급 사본을 먼저 만든다는 운영 절차 원칙을 확인했습니다.', value=False, key='dr_runbook_emergency_copy_confirm')
    rb3, rb4 = st.columns(2)
    _rb_staging_confirm = rb3.checkbox('향후 복구는 격리된 임시 임시 검증 공간에서 검증 후 덮어쓰기 범위를 비교한다는 절차를 확인했습니다.', value=False, key='dr_runbook_staging_confirm')
    _rb_no_auto_confirm = rb4.checkbox('이 운영 절차 고정은 자동 백업 삭제나 실제 복원 권한을 생성하지 않음을 확인했습니다.', value=False, key='dr_runbook_no_auto_confirm')
    _rb_human_confirm = st.checkbox('현재 재해 복구 운영 절차 / 복구 검증 종결을 최종 사용자 검토했습니다.', value=False, key='dr_runbook_human_confirm')
    _rb_note = st.text_input('재해 복구 운영 절차 고정 메모', value='', key='dr_runbook_lock_note', placeholder='예: 복구 점검 검토됨 / 모의검증 계획 고정됨 / 금지 복원 권한')
    _rb_validation = validate_dr_runbook_lock(_sc_recovery_release, _sc_drift, _sc_simulation, _sc_current_runbook, release_evidence_confirmed=_rb_release_confirm, emergency_copy_plan_confirmed=_rb_emergency_confirm, isolated_staging_confirmed=_rb_staging_confirm, no_auto_delete_restore_confirmed=_rb_no_auto_confirm, human_review_confirmed=_rb_human_confirm)
    rbg1, rbg2, rbg3 = st.columns(3)
    rbg1.metric('운영 절차 점검', _locale.code(_rb_validation['runbook_gate']))
    rbg2.metric('검증 종결', _locale.code(_rb_validation['audit_closure_status']))
    rbg3.metric('복원 권한', '없음')
    if _rb_validation['issues']:
        st.caption('운영 절차 고정 저장 전 확인 · ' + ' | '.join(_rb_validation['issues']))
    if st.button('재해 복구 운영 절차 고정 저장', disabled=_rb_validation['runbook_gate'] != 'PASS', key='dr_runbook_lock_save'):
        _rb_row = build_dr_runbook_lock_record(_sc_recovery_release, _sc_drift, _sc_rotation, _sc_simulation, _rb_validation, current_manifest_sha256=_sc_manifest_verify.get('manifest_sha256', ''), release_evidence_confirmed=_rb_release_confirm, emergency_copy_plan_confirmed=_rb_emergency_confirm, isolated_staging_confirmed=_rb_staging_confirm, no_auto_delete_restore_confirmed=_rb_no_auto_confirm, human_review_confirmed=_rb_human_confirm, note=_rb_note)
        _rb_hist = load_csv('disaster_recovery_runbook_locks.csv')
        for _col in DR_RUNBOOK_LOCK_COLS:
            if _col not in _rb_hist.columns:
                _rb_hist[_col] = ''
        _rb_hist = pd.concat([_rb_hist[DR_RUNBOOK_LOCK_COLS], pd.DataFrame([_rb_row])], ignore_index=True)
        verified_save_feedback(_rb_hist, 'disaster_recovery_runbook_locks.csv', f"DR Runbook Lock 저장 · {_rb_row['audit_closure_status']} · {_rb_row['runbook_version']} · Restore Authorization = NONE.", rerun=False)
    st.caption('재해 복구 운영 절차 고정은 현재 복구 시점, 8-단계 모의검증 계획, 배포 점검을 추가 기록 전용으로 고정합니다. 실제 복원 실행/파일 복사/원본 덮어쓰기/자동 삭제는 수행하지 않습니다.')
    _sc_recovery_integration_status = 'REVIEW'
    if _sc_current_runbook:
        if _sc_runbook_integrity['status'] != 'OK':
            _sc_recovery_integration_status = 'BLOCKED'
        elif str(_sc_current_runbook.get('audit_closure_status', '') or '').upper() == 'RECOVERY_AUDIT_CLOSED':
            _sc_recovery_integration_status = 'PASS'
    _sc_v124_crosscheck = build_v124_data_crosscheck(csv_fail_count=fail_count, recovery_release_gate=_sc_recovery_release['release_gate'], recovery_integration_status=_sc_recovery_integration_status)
    st.subheader('1H. v1.24 복구 배포 데이터 교차 점검')
    rdc1, rdc2, rdc3, rdc4 = st.columns(4)
    rdc1.metric('복구 데이터 점검', _locale.code(_sc_v124_crosscheck['status']))
    rdc2.metric('차단 사유 점검 항목', _locale.code(_sc_v124_crosscheck['blocking_count']))
    rdc3.metric('검증 종결', _locale.code(_sc_recovery_integration_status))
    rdc4.metric('복원 권한', '없음')
    _locale.dataframe(st, _sc_v124_crosscheck['checks'], width='stretch', hide_index=True)
    if _sc_v124_crosscheck['status'] == 'PASS':
        st.success('v1.24 복구 배포 데이터 교차 점검 정상 · 표 데이터 / 복구 배포 / 검증 종결 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.24 복구 배포 데이터 교차 점검 아직 차단됨 · 현재 운영 절차 검증 종결 또는 복구 점검을 확인하세요.')
    _sc_schema_scan = inspect_csv_schemas(ROOT / 'data')
    _sc_schema_summary = schema_scan_summary(_sc_schema_scan)
    _sc_schema_baselines = load_csv('schema_baseline_locks.csv')
    _sc_schema_baseline = latest_schema_baseline(_sc_schema_baselines)
    _sc_schema_compare = compare_schema_to_baseline(_sc_schema_scan, _sc_schema_baseline)
    _sc_schema_dryrun = build_schema_migration_dry_run(_sc_schema_compare)
    st.subheader('1I. 데이터 저장 구조 변경 보호 점검 / 이전 모의 실행 / 기준 상태 고정')
    sg1, sg2, sg3, sg4, sg5 = st.columns(5)
    sg1.metric('저장 구조 상태', _locale.code(_sc_schema_compare['schema_status']))
    sg2.metric('표 데이터 구조 정의', _locale.code(_sc_schema_summary['file_count']))
    sg3.metric('변경됨 파일', _locale.code(_sc_schema_compare['changed_files']))
    sg4.metric('차단 사유 변경 사항', _locale.code(_sc_schema_compare['blocking_changes']))
    sg5.metric('이전 권한', '없음')
    st.caption(f"구문 분석 실패 {_sc_schema_summary['parse_fail']} · 중복-열 파일 {_sc_schema_summary['duplicate_schema_files']} · 추가됨 파일 {_sc_schema_compare['added_files']} · 누락 파일 {_sc_schema_compare['missing_files']} · 검토 변경 사항 {_sc_schema_compare['review_changes']}")
    if _sc_schema_compare['schema_status'] == 'NO_BASELINE':
        st.info('아직 저장 구조 기준 상태 고정이 없습니다. 현재 표 데이터 머리글이 정상인지 확인한 뒤 첫 기준 상태를 사용자 검토로 잠급니다.')
    elif _sc_schema_compare['schema_status'] == 'CURRENT':
        st.success('저장 구조 현재 · 현재 표 데이터 파일/열 구조가 잠긴 기준 상태와 일치합니다.')
    elif _sc_schema_compare['schema_status'] == 'REVIEW':
        st.warning('저장 구조 검토 · 추가된 파일/열 또는 열 순서 변화가 있습니다. 자동 이전은 수행하지 않습니다.')
    else:
        st.error('저장 구조 차단됨 · 누락 파일/열, 호환성 훼손 변경 또는 기준 상태/표 데이터 무결성 문제를 먼저 해결하세요.')
    with st.expander('표 데이터 저장 구조 조회 상세', expanded=False):
        if _sc_schema_scan.empty:
            st.info('표시할 표 데이터 저장 구조가 없습니다.')
        else:
            _locale.dataframe(st, _sc_schema_scan[['file', 'parse_status', 'column_count', 'duplicate_columns', 'schema_hash']], width='stretch', hide_index=True)
    with st.expander('저장 구조 변경 비교 상세', expanded=False):
        _schema_diff = _sc_schema_compare.get('diff')
        if isinstance(_schema_diff, pd.DataFrame) and (not _schema_diff.empty):
            _locale.dataframe(st, _schema_diff, width='stretch', hide_index=True)
        else:
            st.info('현재 표시할 저장 구조 변경 비교가 없습니다.')
    with st.expander('이전 모의 실행 계획 상세', expanded=False):
        if _sc_schema_dryrun.empty:
            st.info('이전 모의 실행 대상이 없습니다.')
        else:
            _locale.dataframe(st, _sc_schema_dryrun, width='stretch', hide_index=True)
    if _sc_schema_baseline:
        _sc_baseline_integrity = schema_baseline_integrity(_sc_schema_baseline)
        st.info(f"최신 저장 구조 기준 상태 · {_sc_schema_baseline.get('schema_baseline_id', '')} · 파일 {_sc_schema_baseline.get('file_count', '')} · 무결성 {_locale.code(_sc_baseline_integrity['status'])} · 이전 권한 없음")
    else:
        _sc_baseline_integrity = {'status': 'NONE'}
    sb1, sb2 = st.columns(2)
    _sb_schema_confirm = sb1.checkbox('현재 표 데이터 파일 목록과 각 머리글/열 구조를 직접 확인했습니다.', value=False, key='schema_baseline_schema_confirm')
    _sb_no_auto_confirm = sb2.checkbox('저장 구조 기준 상태 고정은 표 데이터를 자동 이전하거나 열을 변경하지 않음을 확인했습니다.', value=False, key='schema_baseline_no_auto_confirm')
    sb3, sb4 = st.columns(2)
    _sb_no_destructive = sb3.checkbox('누락 열/파일 또는 호환성 훼손 저장 구조는 자동 보정하지 않고 별도 이전 검토가 필요함을 확인했습니다.', value=False, key='schema_baseline_no_destructive_confirm')
    _sb_human = sb4.checkbox('현재 데이터 저장 구조 기준 상태를 최종 사용자 검토했습니다.', value=False, key='schema_baseline_human_confirm')
    _sb_note = st.text_input('저장 구조 기준 상태 고정 메모', value='', key='schema_baseline_note', placeholder='예: v1.25 초기 저장 구조 기준 상태 / 금지 자동 이전')
    _sb_validation = validate_schema_baseline_lock(_sc_schema_scan, _sc_schema_compare, _sc_schema_baseline, schema_review_confirmed=_sb_schema_confirm, no_auto_migration_confirmed=_sb_no_auto_confirm, no_destructive_change_confirmed=_sb_no_destructive, human_review_confirmed=_sb_human)
    sbg1, sbg2, sbg3 = st.columns(3)
    sbg1.metric('기준 상태 점검', _locale.code(_sb_validation['baseline_gate']))
    sbg2.metric('기준 상태 상태', _locale.code(_sb_validation['baseline_status']))
    sbg3.metric('이전 권한', '없음')
    if _sb_validation['issues']:
        st.caption('기준 상태 저장 전 확인 · ' + ' | '.join(_sb_validation['issues']))
    if st.button('데이터 저장 구조 기준 상태 고정 저장', disabled=_sb_validation['baseline_gate'] != 'PASS', key='schema_baseline_lock_save'):
        _sb_row = build_schema_baseline_lock_record(_sc_schema_scan, _sb_validation, schema_review_confirmed=_sb_schema_confirm, no_auto_migration_confirmed=_sb_no_auto_confirm, no_destructive_change_confirmed=_sb_no_destructive, human_review_confirmed=_sb_human, note=_sb_note)
        _sb_hist = load_csv('schema_baseline_locks.csv')
        for _col in SCHEMA_BASELINE_LOCK_COLS:
            if _col not in _sb_hist.columns:
                _sb_hist[_col] = ''
        _sb_hist = pd.concat([_sb_hist[SCHEMA_BASELINE_LOCK_COLS], pd.DataFrame([_sb_row])], ignore_index=True)
        verified_save_feedback(_sb_hist, 'schema_baseline_locks.csv', f"Data Schema Baseline Lock 저장 · {_sb_row['baseline_status']} · Files {_sb_row['file_count']} · Migration Authorization = NONE.", rerun=False)
    st.caption('저장 구조 변경 보호 점검은 머리글 구조를 감시하고 이전 모의 실행 계획만 생성합니다. 표 데이터 열 추가/삭제/이름 변경/파일 삭제를 자동 수행하지 않습니다.')
    _sc_schema_compat = build_schema_compatibility_matrix(_sc_schema_compare)
    _sc_migration_summary = migration_proposal_summary(_sc_schema_compare, _sc_schema_compat)
    _sc_schema_contracts = load_csv('schema_contract_locks.csv')
    _sc_schema_contract = latest_schema_contract(_sc_schema_contracts)
    _sc_contract_assessment = assess_schema_contract(_sc_schema_contract, _sc_schema_baseline, _sc_schema_compare)
    st.subheader('1J. 저장 구조 이전 제안 / 호환성 행렬 / 읽기·쓰기 기준 계약 고정')
    cm1, cm2, cm3, cm4, cm5 = st.columns(5)
    cm1.metric('호환성', _locale.code(_sc_schema_compat['compatibility_status']))
    cm2.metric('이전 제안', _locale.code(_sc_migration_summary['proposal_status']))
    cm3.metric('기준 계약', _locale.code(_sc_contract_assessment['contract_status']))
    cm4.metric('변경됨 파일', _locale.code(_sc_schema_compare['changed_files']))
    cm5.metric('이전 권한', '없음')
    st.caption(f"호환됨 파일 {_sc_schema_compat['pass_files']} · 검토 파일 {_sc_schema_compat['review_files']} · 차단됨 파일 {_sc_schema_compat['blocked_files']} · 기준 계약 무결성 {_sc_contract_assessment['contract_integrity']}")
    with st.expander('읽기 도구 / 쓰기 도구 호환성 행렬', expanded=False):
        _compat_matrix = _sc_schema_compat.get('matrix')
        if isinstance(_compat_matrix, pd.DataFrame) and (not _compat_matrix.empty):
            _locale.dataframe(st, _compat_matrix, width='stretch', hide_index=True)
        else:
            st.info('표시할 호환성 행렬이 없습니다.')
    if _sc_schema_compare['changed_files'] == 0:
        st.success('현재 저장 구조 변경이 없어 이전 제안이 필요하지 않습니다.')
    else:
        _proposal_diff = _sc_schema_compare.get('diff')
        if isinstance(_proposal_diff, pd.DataFrame) and (not _proposal_diff.empty):
            _proposal_candidates = _proposal_diff.loc[_proposal_diff['migration_type'].ne('CURRENT')].copy()
            if not _proposal_candidates.empty:
                _proposal_indices = list(_proposal_candidates.index)

                def _proposal_label(_idx):
                    _r = _proposal_candidates.loc[_idx]
                    return f"{_r.get('file', '')} | {_r.get('migration_type', '')} | {_r.get('status', '')}"
                _proposal_idx = st.selectbox('이전 제안 대상 저장 구조 변경', options=_proposal_indices, format_func=_proposal_label, key='schema_migration_proposal_target')
                _proposal_source = _proposal_candidates.loc[_proposal_idx].to_dict()
                _compat_rows = _sc_schema_compat['matrix']
                _compat_hit = _compat_rows.loc[_compat_rows['file'].astype(str).eq(str(_proposal_source.get('file', '')))]
                _proposal_compat = _compat_hit.iloc[0].to_dict() if not _compat_hit.empty else {}
                pc1, pc2, pc3 = st.columns(3)
                pc1.metric('이전 유형', _locale.code(_proposal_source.get('migration_type', '')))
                pc2.metric('위험', _locale.code(_proposal_compat.get('risk_level', '')))
                pc3.metric('권한', '없음')
                _proposal_reason = st.text_area('이전 사유', key='schema_migration_reason', placeholder='왜 저장 구조 변경이 필요한지, 어떤 원본 기능/데이터 요구가 있는지 기록')
                _proposal_transform = st.text_area('제안된 변환', key='schema_migration_transform', placeholder='어떤 파일/열 변환을 검토할지 기록. 이 화면에서는 적용하지 않음.')
                _proposal_rollback = st.text_area('이전 버전 복원 계획', key='schema_migration_rollback', placeholder='문제가 생기면 어떤 기준 상태/백업으로 되돌릴지 기록')
                _proposal_proof = st.text_area('확인 근거 / 호환성 검사 계획', key='schema_migration_proof', placeholder='읽기·쓰기 호환성과 저장/재읽기 무결성을 어떻게 검증할지 기록')
                mp1, mp2 = st.columns(2)
                _mp_source_confirm = mp1.checkbox('선택한 저장 구조 변경 비교와 호환성 행렬을 직접 확인했습니다.', key='schema_migration_source_confirm')
                _mp_no_auto = mp2.checkbox('이전 제안 저장은 실제 표 데이터/열 변경을 자동 적용하지 않음을 확인했습니다.', key='schema_migration_no_auto_confirm')
                mp3, mp4 = st.columns(2)
                _mp_no_destructive = mp3.checkbox('명시적 검토 없이 파일/열 삭제·이름 변경·원본을 손상하는 쓰기를 수행하지 않음을 확인했습니다.', key='schema_migration_no_destructive_confirm')
                _mp_human = mp4.checkbox('현재 이전 제안을 최종 사용자 검토했습니다.', key='schema_migration_human_confirm')
                _mp_note = st.text_input('이전 제안 메모', key='schema_migration_proposal_note')
                _mp_validation = validate_schema_migration_proposal(_proposal_source, _proposal_compat, migration_reason=_proposal_reason, proposed_transform=_proposal_transform, rollback_plan=_proposal_rollback, proof_plan=_proposal_proof, source_diff_confirmed=_mp_source_confirm, no_auto_apply_confirmed=_mp_no_auto, no_destructive_write_confirmed=_mp_no_destructive, human_review_confirmed=_mp_human)
                mpg1, mpg2, mpg3 = st.columns(3)
                mpg1.metric('제안 점검', _locale.code(_mp_validation['proposal_gate']))
                mpg2.metric('제안 상태', _locale.code(_mp_validation['proposal_status']))
                mpg3.metric('이전 권한', '없음')
                if st.button('저장 구조 이전 제안 저장', disabled=_mp_validation['proposal_gate'] != 'PASS', key='schema_migration_proposal_save'):
                    _current_snapshot_hash = build_schema_snapshot(_sc_schema_scan)['snapshot_hash']
                    _mp_row = build_schema_migration_proposal_record(_proposal_source, _proposal_compat, _mp_validation, baseline_schema_hash=_sc_schema_baseline.get('schema_snapshot_hash', ''), current_schema_hash=_current_snapshot_hash, migration_reason=_proposal_reason, proposed_transform=_proposal_transform, rollback_plan=_proposal_rollback, proof_plan=_proposal_proof, source_diff_confirmed=_mp_source_confirm, no_auto_apply_confirmed=_mp_no_auto, no_destructive_write_confirmed=_mp_no_destructive, human_review_confirmed=_mp_human, note=_mp_note)
                    _mp_hist = load_csv('schema_migration_proposals.csv')
                    for _col in SCHEMA_MIGRATION_PROPOSAL_COLS:
                        if _col not in _mp_hist.columns:
                            _mp_hist[_col] = ''
                    _mp_hist = pd.concat([_mp_hist[SCHEMA_MIGRATION_PROPOSAL_COLS], pd.DataFrame([_mp_row])], ignore_index=True)
                    verified_save_feedback(_mp_hist, 'schema_migration_proposals.csv', f"Schema Migration Proposal 저장 · {_mp_row['proposal_status']} · {_mp_row['migration_type']} · Migration Authorization = NONE.", rerun=False)
    if _sc_schema_contract:
        _contract_integrity = schema_contract_integrity(_sc_schema_contract)
        st.info(f"최신 읽기·쓰기 기준 계약 · {_sc_schema_contract.get('schema_contract_id', '')} · 상태 {_locale.code(_sc_contract_assessment['contract_status'])} · 무결성 {_locale.code(_contract_integrity['status'])} · 이전 권한 없음")
    else:
        _contract_integrity = {'status': 'NONE'}
    cc1, cc2 = st.columns(2)
    _cc_baseline_confirm = cc1.checkbox('현재 저장 구조 기준 상태 무결성과 호환성 행렬을 직접 확인했습니다.', key='schema_contract_baseline_confirm')
    _cc_additive_confirm = cc2.checkbox('추가 파일/열도 자동 호환으로 가정하지 않고 읽기·쓰기 영향을 별도 검토한다는 기준 계약 원칙을 확인했습니다.', key='schema_contract_additive_confirm')
    cc3, cc4 = st.columns(2)
    _cc_writer_confirm = cc3.checkbox('쓰기 도구는 잠긴 필수 파일/열을 명시적 이전 없이 삭제·이름 변경하지 않는다는 보존 원칙을 확인했습니다.', key='schema_contract_writer_confirm')
    _cc_no_auto = cc4.checkbox('이 기준 계약 고정은 실제 이전을 자동 실행하지 않음을 확인했습니다.', key='schema_contract_no_auto_confirm')
    _cc_human = st.checkbox('현재 읽기·쓰기 저장 구조 계약을 최종 사용자 검토했습니다.', key='schema_contract_human_confirm')
    _cc_note = st.text_input('읽기·쓰기 기준 계약 고정 메모', key='schema_contract_note', placeholder='예: v1.25 저장 구조 계약 v1 / 현재 기준 상태 / 금지 자동 이전')
    _cc_validation = validate_schema_contract_lock(_sc_schema_baseline, _sc_schema_compare, _sc_schema_compat, _sc_schema_contract, baseline_review_confirmed=_cc_baseline_confirm, additive_change_review_confirmed=_cc_additive_confirm, writer_preservation_confirmed=_cc_writer_confirm, no_auto_migration_confirmed=_cc_no_auto, human_review_confirmed=_cc_human)
    ccg1, ccg2, ccg3 = st.columns(3)
    ccg1.metric('기준 계약 점검', _locale.code(_cc_validation['contract_gate']))
    ccg2.metric('기준 계약 상태', _locale.code(_cc_validation['contract_status']))
    ccg3.metric('이전 권한', '없음')
    if _cc_validation['issues']:
        st.caption('기준 계약 저장 전 확인 · ' + ' | '.join(_cc_validation['issues']))
    if st.button('읽기·쓰기 저장 구조 계약 고정 저장', disabled=_cc_validation['contract_gate'] != 'PASS', key='schema_contract_lock_save'):
        _cc_row = build_schema_contract_lock_record(_sc_schema_scan, _sc_schema_baseline, _sc_schema_compat, _cc_validation, baseline_review_confirmed=_cc_baseline_confirm, additive_change_review_confirmed=_cc_additive_confirm, writer_preservation_confirmed=_cc_writer_confirm, no_auto_migration_confirmed=_cc_no_auto, human_review_confirmed=_cc_human, note=_cc_note)
        _cc_hist = load_csv('schema_contract_locks.csv')
        for _col in SCHEMA_CONTRACT_LOCK_COLS:
            if _col not in _cc_hist.columns:
                _cc_hist[_col] = ''
        _cc_hist = pd.concat([_cc_hist[SCHEMA_CONTRACT_LOCK_COLS], pd.DataFrame([_cc_row])], ignore_index=True)
        verified_save_feedback(_cc_hist, 'schema_contract_locks.csv', f"Reader-Writer Schema Contract Lock 저장 · {_cc_row['contract_status']} · {_cc_row['contract_version']} · Migration Authorization = NONE.", rerun=False)
    st.caption('호환성 행렬은 저장 구조 차이의 위험을 분류하는 관리 기준 도구입니다. 실제 모든 읽기·쓰기 코드 경로의 호환성을 자동 증명하지 않으며, 이전은 별도 사용자 검토가 필요합니다.')
    _sc_schema_contract_drift = build_schema_contract_drift(_sc_schema_contract, _sc_schema_baseline, _sc_schema_compare, _sc_schema_compat)
    _sc_schema_proposals = load_csv('schema_migration_proposals.csv')
    _sc_schema_proofs = load_csv('schema_migration_proof_reviews.csv')
    _sc_compat_closure = build_compatibility_closure(_sc_schema_compare, _sc_schema_contract_drift, _sc_schema_proposals, _sc_schema_proofs, _sc_schema_scan)
    st.subheader('1K. 저장 구조 계약 기준 이탈 / 이전 확인 근거 / 호환성 종결')
    sp1, sp2, sp3, sp4, sp5 = st.columns(5)
    sp1.metric('기준 계약 기준 이탈', _locale.code(_sc_schema_contract_drift['contract_drift_status']))
    sp2.metric('호환성 종결', _locale.code(_sc_compat_closure['closure_status']))
    sp3.metric('변경됨 파일', _locale.code(_sc_compat_closure['changed_files']))
    sp4.metric('확인 근거 수락됨', _locale.code(_sc_compat_closure['proof_accepted']))
    sp5.metric('이전 권한', '없음')
    st.caption(f"제안 누락 {_sc_compat_closure['proposal_missing']} · 확인 근거 대기 {_sc_compat_closure['proof_pending']} · 무결성 문제 {_sc_compat_closure['integrity_issues']} · 현재 저장 구조 {_sc_compat_closure['current_schema_hash'][:12]}")
    if _sc_schema_contract_drift['contract_drift_status'] == 'CURRENT':
        st.success('저장 구조 계약 현재 · 현재 저장 구조 / 기준 상태 / 읽기·쓰기 기준 계약이 일치합니다.')
    elif _sc_schema_contract_drift['contract_drift_status'] == 'DRIFTED':
        st.warning('저장 구조 계약 변경 감지 · 이전 제안 / 확인 근거 / 기준 상태 새로 읽기 검토가 필요합니다.')
    else:
        st.error('저장 구조 계약 기준 이탈이 차단됨/금지 · 기준 계약 상태입니다. 기준 상태/기준 계약 무결성부터 확인하세요.')
    if _sc_compat_closure['closure_status'] == 'NO_CHANGE':
        st.success('호환성 종결 = 금지 · 변경 · 현재 이전 제안 / 확인 근거 검토가 필요하지 않습니다.')
    elif _sc_compat_closure['closure_status'] == 'READY_FOR_BASELINE_REFRESH':
        st.info('변경됨 파일의 이전 확인 근거가 모두 수락됨되었습니다. 새 기준 상태/기준 계약 새로 읽기는 아직 자동 수행하지 않습니다.')
    with st.expander('호환성 종결 상세', expanded=False):
        _closure_details = _sc_compat_closure.get('details')
        if isinstance(_closure_details, pd.DataFrame) and (not _closure_details.empty):
            _locale.dataframe(st, _closure_details, width='stretch', hide_index=True)
        else:
            st.info('현재 호환성 종결 대상 저장 구조 변경이 없습니다.')
    st.caption('이전 확인 근거는 실제 저장 구조 변경이 있을 때만 사용합니다. 표 데이터/열 자동 변경, 기준 상태 자동 새로 읽기, 이전 자동 승인은 하지 않습니다.')
    _sc_refresh_approvals = load_csv('schema_refresh_approvals.csv')
    _sc_target_schema_hash = _sc_compat_closure['current_schema_hash']
    _sc_refresh_approval = latest_schema_refresh_approval(_sc_refresh_approvals, _sc_target_schema_hash)
    _sc_refresh_closure = build_schema_refresh_closure(_sc_schema_scan, _sc_compat_closure, _sc_refresh_approvals, _sc_schema_baselines, _sc_schema_contracts)
    st.subheader('1L. 통제된 기준 상태 새로 읽기 / 기준 계약 다시 고정 / 이전 종결')
    sr1, sr2, sr3, sr4, sr5 = st.columns(5)
    sr1.metric('새로 읽기 상태', _locale.code(_sc_refresh_closure['refresh_status']))
    sr2.metric('승인', _locale.code(_sc_refresh_approval.get('approval_status', 'NONE') if _sc_refresh_approval else '없음'))
    sr3.metric('신규 기준 상태', _locale.code(_sc_refresh_closure['refreshed_baseline_id'] or 'NONE'))
    sr4.metric('기준 계약 다시 고정', _locale.code(_sc_refresh_closure['relocked_contract_id'] or 'NONE'))
    sr5.metric('이전 권한', '없음')
    st.caption(f"대상 저장 구조 {_sc_refresh_closure['target_schema_snapshot_hash'][:12]} · 승인 무결성 {_sc_refresh_closure['approval_integrity']} · 기준 상태 무결성 {_sc_refresh_closure['refreshed_baseline_integrity']} · 기준 계약 무결성 {_sc_refresh_closure['relocked_contract_integrity']}")
    if _sc_refresh_closure['refresh_status'] == 'NOT_REQUIRED':
        st.success('현재 저장 구조 이전이 없어 기준 상태 새로 읽기 / 기준 계약 다시 고정이 필요하지 않습니다.')
    elif _sc_refresh_closure['refresh_status'] == 'MIGRATION_CLOSED':
        st.success('저장 구조 이전 종결 완료 · 수락됨 확인 근거 → 새로 읽기 승인 → 신규 기준 상태 → 기준 계약 다시 고정 연결 이력이 닫혔습니다.')
    elif _sc_refresh_closure['refresh_status'] == 'BASELINE_REFRESH_PENDING':
        st.warning('새로 읽기 승인 완료 · 저장 센터 1I에서 현재 대상 저장 구조를 새 기준 상태로 사용자 검토 후 고정하세요.')
    elif _sc_refresh_closure['refresh_status'] == 'CONTRACT_RELOCK_PENDING':
        st.warning('신규 기준 상태 완료 · 저장 센터 1J에서 새 기준 상태 기준 읽기·쓰기 기준 계약 다시 고정이 필요합니다.')
    elif _sc_refresh_closure['refresh_status'] == 'INTEGRITY_REVIEW':
        st.error('저장 구조 새로 읽기 연결 이력 무결성 문제가 있습니다. 승인/기준 상태/기준 계약 무결성 해시를 먼저 확인하세요.')
    else:
        st.info('저장 구조 새로 읽기는 이전 확인 근거가 READY_FOR_BASELINE_REFRESH가 된 뒤 별도 사용자 검토로 진행합니다.')
    if _sc_compat_closure['closure_status'] == 'READY_FOR_BASELINE_REFRESH':
        ra1, ra2 = st.columns(2)
        _ra_proof_confirm = ra1.checkbox('변경됨 파일 전체의 이전 · 확인 근거 · 수락됨 확인 범위와 확인 근거 연결 이력을 직접 확인했습니다.', key='schema_refresh_proof_confirm')
        _ra_target_confirm = ra2.checkbox('현재 표 데이터 저장 구조 상태 기록이 승인하려는 대상 저장 구조와 일치함을 확인했습니다.', key='schema_refresh_target_confirm')
        ra3, ra4 = st.columns(2)
        _ra_no_auto = ra3.checkbox('새로 읽기 승인은 새 기준 상태/기준 계약을 자동 생성하거나 이전을 자동 적용하지 않음을 확인했습니다.', key='schema_refresh_no_auto_confirm')
        _ra_no_destructive = ra4.checkbox('새 기준 상태/기준 계약 다시 고정은 별도 사용자 검토가며 원본을 손상하는 이전을 자동 수행하지 않음을 확인했습니다.', key='schema_refresh_no_destructive_confirm')
        _ra_human = st.checkbox('현재 저장 구조 기준 상태 새로 읽기 승인을 최종 사용자 검토했습니다.', key='schema_refresh_human_confirm')
        _ra_reason = st.text_area('새로 읽기 사유', key='schema_refresh_reason', placeholder='수락됨 이전 확인 근거를 근거로 왜 새 기준 상태가 필요한지 기록')
        _ra_scope = st.text_area('새로 읽기 범위', key='schema_refresh_scope', placeholder='새 기준 상태에 포함할 파일/열 변경 범위를 기록')
        _ra_rollback = st.text_input('이전 버전 복원 참조', key='schema_refresh_rollback', placeholder='예: 검증됨 백업 / 이전 기준 상태 식별번호 / 복구 시점')
        _ra_note = st.text_input('저장 구조 새로 읽기 승인 메모', key='schema_refresh_note')
        _ra_validation = validate_schema_refresh_approval(_sc_schema_scan, _sc_schema_baseline, _sc_schema_contract, _sc_compat_closure, _sc_schema_proofs, _sc_refresh_approval, refresh_reason=_ra_reason, refresh_scope=_ra_scope, rollback_reference=_ra_rollback, proof_coverage_confirmed=_ra_proof_confirm, target_schema_confirmed=_ra_target_confirm, no_auto_refresh_confirmed=_ra_no_auto, no_destructive_migration_confirmed=_ra_no_destructive, human_review_confirmed=_ra_human)
        rag1, rag2, rag3 = st.columns(3)
        rag1.metric('새로 읽기 승인 점검', _locale.code(_ra_validation['approval_gate']))
        rag2.metric('승인 상태', _locale.code(_ra_validation['approval_status']))
        rag3.metric('이전 권한', '없음')
        if _ra_validation['issues']:
            st.caption('새로 읽기 승인 저장 전 확인 · ' + ' | '.join(_ra_validation['issues']))
        if st.button('저장 구조 기준 상태 새로 읽기 승인 저장', disabled=_ra_validation['approval_gate'] != 'PASS', key='schema_refresh_approval_save'):
            _ra_row = build_schema_refresh_approval_record(_sc_schema_scan, _sc_schema_baseline, _sc_schema_contract, _sc_compat_closure, _ra_validation, refresh_reason=_ra_reason, refresh_scope=_ra_scope, rollback_reference=_ra_rollback, proof_coverage_confirmed=_ra_proof_confirm, target_schema_confirmed=_ra_target_confirm, no_auto_refresh_confirmed=_ra_no_auto, no_destructive_migration_confirmed=_ra_no_destructive, human_review_confirmed=_ra_human, note=_ra_note)
            _ra_hist = load_csv('schema_refresh_approvals.csv')
            for _col in SCHEMA_REFRESH_APPROVAL_COLS:
                if _col not in _ra_hist.columns:
                    _ra_hist[_col] = ''
            _ra_hist = pd.concat([_ra_hist[SCHEMA_REFRESH_APPROVAL_COLS], pd.DataFrame([_ra_row])], ignore_index=True)
            verified_save_feedback(_ra_hist, 'schema_refresh_approvals.csv', f"Schema Baseline Refresh Approval 저장 · {_ra_row['approval_status']} · Changed Files {_ra_row['changed_files']} · Migration Authorization = NONE.", rerun=False)
    st.caption('통제된 새로 읽기는 수락됨 확인 근거가 있는 저장 구조 변경에 대해서만 승인 부가 정보를 남깁니다. 새 기준 상태는 1I, 기준 계약 다시 고정은 1J에서 각각 별도 사용자 검토로 저장하며 자동 갱신하지 않습니다.')
    _sc_schema_release_context = build_schema_governance_context(data_dir=ROOT / 'data', baselines=_sc_schema_baselines, contracts=_sc_schema_contracts, proposals=_sc_schema_proposals, proofs=_sc_schema_proofs, approvals=_sc_refresh_approvals)
    _sc_schema_release = build_schema_governance_release_gate(_sc_schema_release_context)
    _sc_v125_data = build_v125_data_crosscheck(csv_fail_count=fail_count, schema_release_gate=_sc_schema_release['release_gate'], baseline_integrity=_sc_schema_release_context['baseline_integrity'], contract_integrity=_sc_schema_release_context['contract_integrity'])
    st.subheader('1M. v1.25 저장 구조 관리 배포 데이터 교차 점검')
    sdc1, sdc2, sdc3, sdc4 = st.columns(4)
    sdc1.metric('저장 구조 데이터 점검', _locale.code(_sc_v125_data['status']))
    sdc2.metric('차단 사유 점검 항목', _locale.code(_sc_v125_data['blocking_count']))
    sdc3.metric('저장 구조 배포', _locale.code(_sc_schema_release['release_gate']))
    sdc4.metric('이전 권한', '없음')
    _locale.dataframe(st, _sc_v125_data['checks'], width='stretch', hide_index=True)
    if _sc_v125_data['status'] == 'PASS':
        st.success('v1.25 저장 구조 관리 배포 데이터 교차 점검 정상 · 표 데이터 / 기준 상태 / 기준 계약 / 저장 구조 배포 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.25 저장 구조 관리 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 저장 구조 기준 상태/기준 계약/배포 점검을 확인하세요.')
    _sc_operations_release = build_operations_session_release_gate(load_csv('operations_sessions.csv'))
    _sc_v126_data = build_v126_data_crosscheck(csv_fail_count=fail_count, operations_release_gate=_sc_operations_release['release_gate'], latest_close_integrity=_sc_operations_release['latest_close_integrity'])
    st.subheader('1N. v1.26 운영 작업 세션 배포 데이터 교차 점검')
    odc1, odc2, odc3, odc4 = st.columns(4)
    odc1.metric('운영 데이터 점검', _locale.code(_sc_v126_data['status']))
    odc2.metric('차단 사유 점검 항목', _locale.code(_sc_v126_data['blocking_count']))
    odc3.metric('최신 종료 무결성', _locale.code(_sc_operations_release['latest_close_integrity']))
    odc4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v126_data['checks'], width='stretch', hide_index=True)
    if _sc_v126_data['status'] == 'PASS':
        st.success('v1.26 운영 작업 세션 배포 데이터 교차 점검 정상 · 표 데이터 / 작업 세션 배포 / 최신 종료 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.26 운영 작업 세션 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 작업 세션 기록 무결성을 확인하세요.')
    _sc_v127_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    _sc_v127_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    _sc_v127_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    _sc_v127_thesis = build_thesis_monitor(watchlist, _sc_v127_states, _sc_v127_plans, _sc_v127_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=date.today())
    _sc_v127_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    _sc_v127_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _sc_v127_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=_sc_v127_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=_sc_v127_kpis, state_df=_sc_v127_states, thesis_monitor=_sc_v127_thesis, audit_df=_sc_v127_audit, reconciliation=_sc_v127_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=date.today())
    _sc_v127_context = build_v127_operating_context(review_queue=_sc_v127_queue, sessions=load_csv('operations_sessions.csv'), overrides=load_csv('operations_capacity_overrides.csv'), sla_snapshots=load_csv('operations_sla_closure_snapshots.csv'), today=date.today(), session_capacity=5)
    _sc_v127_gate = build_v127_technical_release_gate(_sc_v127_context)
    _sc_v127_data = build_v127_data_crosscheck(csv_fail_count=fail_count, sla_release_gate=_sc_v127_gate['release_gate'], snapshot_integrity=_sc_v127_gate['latest_snapshot_integrity'])
    st.subheader('1O. v1.27 다음 검토로 이월 / 처리 기한 배포 데이터 교차 점검')
    sdc1, sdc2, sdc3, sdc4 = st.columns(4)
    sdc1.metric('처리 기한 데이터 점검', _locale.code(_sc_v127_data['status']))
    sdc2.metric('차단 사유 점검 항목', _locale.code(_sc_v127_data['blocking_count']))
    sdc3.metric('최신 처리 기한 상태 기록', _locale.code(_sc_v127_gate['latest_snapshot_integrity']))
    sdc4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v127_data['checks'], width='stretch', hide_index=True)
    if _sc_v127_data['status'] == 'PASS':
        st.success('v1.27 다음 검토로 이월 / 처리 기한 배포 데이터 교차 점검 정상 · 표 데이터 / 처리 기한 배포 / 상태 기록 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.27 다음 검토로 이월 / 처리 기한 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 처리 기한 상태 기록/기술 점검을 확인하세요.')
    _sc_v128_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    _sc_v128_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    _sc_v128_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    _sc_v128_thesis = build_thesis_monitor(watchlist, _sc_v128_states, _sc_v128_plans, _sc_v128_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=date.today())
    _sc_v128_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    _sc_v128_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _sc_v128_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=_sc_v128_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=_sc_v128_kpis, state_df=_sc_v128_states, thesis_monitor=_sc_v128_thesis, audit_df=_sc_v128_audit, reconciliation=_sc_v128_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=date.today())
    _sc_v128_context = build_v128_flow_context(review_queue=_sc_v128_queue, sessions=load_csv('operations_sessions.csv'), flow_snapshots=load_csv('operations_flow_snapshots.csv'), trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), calibration_snapshots=load_csv('operations_flow_calibration_snapshots.csv'), today=date.today(), capacity=5)
    _sc_v128_gate = build_v128_flow_release_gate(_sc_v128_context)
    _sc_v128_data = build_v128_data_crosscheck(csv_fail_count=fail_count, flow_release_gate=_sc_v128_gate['release_gate'], latest_calibration_integrity=_sc_v128_gate['latest_calibration_integrity'])
    st.subheader('1P. v1.28 처리 흐름 배포 데이터 교차 점검')
    fdc1, fdc2, fdc3, fdc4 = st.columns(4)
    fdc1.metric('처리 흐름 데이터 점검', _locale.code(_sc_v128_data['status']))
    fdc2.metric('차단 사유 점검 항목', _locale.code(_sc_v128_data['blocking_count']))
    fdc3.metric('최신 보정', _locale.code(_sc_v128_gate['latest_calibration_integrity']))
    fdc4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v128_data['checks'], width='stretch', hide_index=True)
    if _sc_v128_data['status'] == 'PASS':
        st.success('v1.28 처리 흐름 배포 데이터 교차 점검 정상 · 표 데이터 / 처리 흐름 배포 / 보정 상태 기록 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.28 처리 흐름 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 처리 흐름/보정 무결성을 확인하세요.')
    _sc_v129_context = build_v129_projection_context(flow_context=_sc_v128_context, trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), calibration_snapshots=load_csv('operations_flow_calibration_snapshots.csv'), projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), outcome_snapshots=load_csv('operations_flow_projection_outcome_snapshots.csv'), scorecard_snapshots=load_csv('operations_flow_projection_scorecard_snapshots.csv'))
    _sc_v129_gate = build_v129_projection_technical_release_gate(_sc_v129_context)
    _sc_v129_lineage = build_v129_projection_lineage_gate(_sc_v129_context)
    _sc_v129_data = build_v129_data_crosscheck(csv_fail_count=fail_count, projection_release_gate=_sc_v129_gate['release_gate'], lineage_release_gate=_sc_v129_lineage['release_gate'], latest_projection_integrity=_sc_v129_gate['latest_projection_integrity'], latest_outcome_integrity=_sc_v129_gate['latest_outcome_integrity'], latest_scorecard_integrity=_sc_v129_gate['latest_scorecard_integrity'])
    st.subheader('1Q. v1.29 전망 관리 기준 배포 데이터 교차 점검')
    pgd1, pgd2, pgd3, pgd4 = st.columns(4)
    pgd1.metric('전망 데이터 점검', _locale.code(_sc_v129_data['status']))
    pgd2.metric('차단 사유 점검 항목', _locale.code(_sc_v129_data['blocking_count']))
    pgd3.metric('연결 이력 점검', _locale.code(_sc_v129_lineage['release_gate']))
    pgd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v129_data['checks'], width='stretch', hide_index=True)
    if _sc_v129_data['status'] == 'PASS':
        st.success('v1.29 전망 관리 기준 배포 데이터 교차 점검 정상 · 표 데이터 / 전망 기술 / 연결 이력 / 최신 상태 기록 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.29 전망 관리 기준 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 전망 관리 기준 무결성/연결 이력을 확인하세요.')
    _sc_v130_context = build_v130_evidence_context(flow_context=_sc_v128_context, sessions=load_csv('operations_sessions.csv'), trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), evidence_snapshots=load_csv('operations_flow_evidence_snapshots.csv'))
    _sc_v130_gate = build_v130_evidence_technical_release_gate(_sc_v130_context)
    _sc_v130_lineage = build_v130_evidence_lineage_gate(_sc_v130_context)
    _sc_v130_data = build_v130_data_crosscheck(csv_fail_count=fail_count, evidence_release_gate=_sc_v130_gate['release_gate'], evidence_lineage_gate=_sc_v130_lineage['release_gate'], latest_evidence_integrity=_sc_v130_gate['latest_evidence_integrity'])
    st.subheader('1R. v1.30 처리 흐름 투자 근거 적격성 확인 배포 데이터 교차 점검')
    fed1, fed2, fed3, fed4 = st.columns(4)
    fed1.metric('투자 근거 데이터 점검', _locale.code(_sc_v130_data['status']))
    fed2.metric('차단 사유 점검 항목', _locale.code(_sc_v130_data['blocking_count']))
    fed3.metric('연결 이력 점검', _locale.code(_sc_v130_lineage['release_gate']))
    fed4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v130_data['checks'], width='stretch', hide_index=True)
    if _sc_v130_data['status'] == 'PASS':
        st.success('v1.30 처리 흐름 투자 근거 적격성 확인 배포 데이터 교차 점검 정상 · 표 데이터 / 투자 근거 기술 / 연결 이력 / 최신 투자 근거 상태 기록 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.30 처리 흐름 투자 근거 적격성 확인 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 투자 근거 적격성 확인 무결성/연결 이력을 확인하세요.')
    _sc_v131_context = build_v131_promotion_context(flow_context=_sc_v128_context, promotion_snapshots=load_csv('operations_flow_calibration_promotion_snapshots.csv'))
    _sc_v131_gate = build_v131_promotion_technical_release_gate(_sc_v131_context)
    _sc_v131_audit = build_v131_promotion_audit_gate(_sc_v131_context)
    _sc_v131_data = build_v131_data_crosscheck(csv_fail_count=fail_count, promotion_release_gate=_sc_v131_gate['release_gate'], promotion_audit_gate=_sc_v131_audit['release_gate'], latest_promotion_integrity=_sc_v131_gate['latest_promotion_integrity'])
    st.subheader('1S. v1.31 보정 승격 배포 데이터 교차 점검')
    cpd1, cpd2, cpd3, cpd4 = st.columns(4)
    cpd1.metric('승격 데이터 점검', _locale.code(_sc_v131_data['status']))
    cpd2.metric('차단 사유 점검 항목', _locale.code(_sc_v131_data['blocking_count']))
    cpd3.metric('검증 점검', _locale.code(_sc_v131_audit['release_gate']))
    cpd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v131_data['checks'], width='stretch', hide_index=True)
    if _sc_v131_data['status'] == 'PASS':
        st.success('v1.31 보정 승격 배포 데이터 교차 점검 정상 · 표 데이터 / 승격 기술 / 검증 / 최신 승격 상태 기록 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.31 보정 승격 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 승격 관리 기준 무결성을 확인하세요.')
    _sc_v132_context = build_v132_admission_context(flow_context=_sc_v128_context, calibration_snapshots=load_csv('operations_flow_calibration_snapshots.csv'), promotion_snapshots=load_csv('operations_flow_calibration_promotion_snapshots.csv'), admission_snapshots=load_csv('operations_flow_projection_admission_snapshots.csv'))
    _sc_v132_gate = build_v132_admission_technical_release_gate(_sc_v132_context)
    _sc_v132_audit = build_v132_admission_audit_gate(_sc_v132_context)
    _sc_v132_data = build_v132_data_crosscheck(csv_fail_count=fail_count, admission_release_gate=_sc_v132_gate['release_gate'], admission_audit_gate=_sc_v132_audit['release_gate'], latest_admission_integrity=_sc_v132_gate['latest_admission_integrity'])
    st.subheader('1T. v1.32 전망 수용 배포 데이터 교차 점검')
    padt1, padt2, padt3, padt4 = st.columns(4)
    padt1.metric('수용 데이터 점검', _locale.code(_sc_v132_data['status']))
    padt2.metric('차단 사유 점검 항목', _locale.code(_sc_v132_data['blocking_count']))
    padt3.metric('검증 점검', _locale.code(_sc_v132_audit['release_gate']))
    padt4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v132_data['checks'], width='stretch', hide_index=True)
    if _sc_v132_data['status'] == 'PASS':
        st.success('v1.32 전망 수용 배포 데이터 교차 점검 정상 · 표 데이터 / 수용 기술 / 검증 / 최신 수용 상태 기록 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.32 전망 수용 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 수용 관리 기준 무결성을 확인하세요.')
    _sc_v133_context = build_v133_review_context(projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), review_snapshots=load_csv('operations_flow_projection_review_snapshots.csv'))
    _sc_v133_gate = build_v133_review_technical_release_gate(_sc_v133_context)
    _sc_v133_audit = build_v133_review_audit_gate(_sc_v133_context)
    _sc_v133_data = build_v133_data_crosscheck(csv_fail_count=fail_count, review_release_gate=_sc_v133_gate['release_gate'], review_audit_gate=_sc_v133_audit['release_gate'], latest_review_integrity=_sc_v133_gate['latest_review_integrity'])
    st.subheader('1U. v1.33 전망 사용자 검토 배포 데이터 교차 점검')
    prd1, prd2, prd3, prd4 = st.columns(4)
    prd1.metric('검토 데이터 점검', _locale.code(_sc_v133_data['status']))
    prd2.metric('차단 사유 점검 항목', _locale.code(_sc_v133_data['blocking_count']))
    prd3.metric('검증 점검', _locale.code(_sc_v133_audit['release_gate']))
    prd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v133_data['checks'], width='stretch', hide_index=True)
    if _sc_v133_data['status'] == 'PASS':
        st.success('v1.33 전망 사용자 검토 배포 데이터 교차 점검 정상 · 표 데이터 / 검토 기술 / 검증 / 최신 검토 검증 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.33 전망 사용자 검토 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 검토 검증/출처 무결성을 확인하세요.')
    _sc_v134_context = build_v134_outcome_evidence_context(projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), review_snapshots=load_csv('operations_flow_projection_review_snapshots.csv'), trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), sessions=load_csv('operations_sessions.csv'), outcome_evidence_snapshots=load_csv('operations_flow_projection_outcome_evidence_snapshots.csv'))
    _sc_v134_gate = build_v134_outcome_evidence_technical_release_gate(_sc_v134_context)
    _sc_v134_audit = build_v134_outcome_evidence_audit_gate(_sc_v134_context)
    _sc_v134_data = build_v134_data_crosscheck(csv_fail_count=fail_count, outcome_evidence_release_gate=_sc_v134_gate['release_gate'], outcome_evidence_audit_gate=_sc_v134_audit['release_gate'], latest_outcome_evidence_integrity=_sc_v134_gate['latest_audit_integrity'])
    st.subheader('1V. v1.34 전망 결과 투자 근거 배포 데이터 교차 점검')
    oed1, oed2, oed3, oed4 = st.columns(4)
    oed1.metric('결과 투자 근거 데이터 점검', _locale.code(_sc_v134_data['status']))
    oed2.metric('차단 사유 점검 항목', _locale.code(_sc_v134_data['blocking_count']))
    oed3.metric('검증 점검', _locale.code(_sc_v134_audit['release_gate']))
    oed4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v134_data['checks'], width='stretch', hide_index=True)
    if _sc_v134_data['status'] == 'PASS':
        st.success('v1.34 전망 결과 투자 근거 배포 데이터 교차 점검 정상 · 표 데이터 / 결과 투자 근거 기술 / 검증 / 최신 검증 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.34 전망 결과 투자 근거 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 결과 투자 근거 검증/출처 연결 이력을 확인하세요.')
    _sc_v135_context = build_v135_scorecard_input_context(outcome_snapshots=load_csv('operations_flow_projection_outcome_snapshots.csv'), outcome_evidence_snapshots=load_csv('operations_flow_projection_outcome_evidence_snapshots.csv'), review_snapshots=load_csv('operations_flow_projection_review_snapshots.csv'), projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), scorecard_input_snapshots=load_csv('operations_flow_scorecard_input_snapshots.csv'))
    _sc_v135_gate = build_v135_scorecard_input_technical_release_gate(_sc_v135_context)
    _sc_v135_audit = build_v135_scorecard_input_audit_gate(_sc_v135_context)
    _sc_v135_data = build_v135_data_crosscheck(csv_fail_count=fail_count, scorecard_input_release_gate=_sc_v135_gate['release_gate'], scorecard_input_audit_gate=_sc_v135_audit['release_gate'], latest_scorecard_input_integrity=_sc_v135_gate['latest_scorecard_input_integrity'])
    st.subheader('1W. v1.35 평가표 입력 적격성 확인 배포 데이터 교차 점검')
    sid1, sid2, sid3, sid4 = st.columns(4)
    sid1.metric('평가표 입력 데이터 점검', _locale.code(_sc_v135_data['status']))
    sid2.metric('차단 사유 점검 항목', _locale.code(_sc_v135_data['blocking_count']))
    sid3.metric('검증 점검', _locale.code(_sc_v135_audit['release_gate']))
    sid4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v135_data['checks'], width='stretch', hide_index=True)
    if _sc_v135_data['status'] == 'PASS':
        st.success('v1.35 평가표 입력 적격성 확인 배포 데이터 교차 점검 정상 · 표 데이터 / 평가표 입력 기술 / 검증 / 최신 검증 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.35 평가표 입력 적격성 확인 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 평가표 입력 검증/무결성을 확인하세요.')
    _sc_v136_context = build_v136_recalibration_context(v135_context=_sc_v135_context, scorecard_snapshots=load_csv('operations_flow_projection_scorecard_snapshots.csv'), recalibration_review_snapshots=load_csv('operations_flow_recalibration_review_snapshots.csv'))
    _sc_v136_gate = build_v136_recalibration_technical_release_gate(_sc_v136_context)
    _sc_v136_audit = build_v136_recalibration_audit_gate(_sc_v136_context)
    _sc_v136_data = build_v136_data_crosscheck(csv_fail_count=fail_count, recalibration_release_gate=_sc_v136_gate['release_gate'], recalibration_audit_gate=_sc_v136_audit['release_gate'], latest_recalibration_review_integrity=_sc_v136_gate['latest_recalibration_review_integrity'])
    st.subheader('1X. v1.36 재보정 사용자 검토 배포 데이터 교차 점검')
    srr1, srr2, srr3, srr4 = st.columns(4)
    srr1.metric('재보정 데이터 점검', _locale.code(_sc_v136_data['status']))
    srr2.metric('차단 사유 점검 항목', _locale.code(_sc_v136_data['blocking_count']))
    srr3.metric('검증 점검', _locale.code(_sc_v136_audit['release_gate']))
    srr4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v136_data['checks'], width='stretch', hide_index=True)
    if _sc_v136_data['status'] == 'PASS':
        st.success('v1.36 재보정 사용자 검토 배포 데이터 교차 점검 정상 · 표 데이터 / 재보정 기술 / 검증 / 최신 기준 계약 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.36 재보정 사용자 검토 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 재보정 기준 계약 검증/무결성을 확인하세요.')
    _sc_v137_context = build_v137_proposal_context(v136_context=_sc_v136_context, recalibration_proposal_snapshots=load_csv('operations_flow_recalibration_proposal_snapshots.csv'))
    _sc_v137_gate = build_v137_proposal_technical_release_gate(_sc_v137_context)
    _sc_v137_audit = build_v137_proposal_audit_gate(_sc_v137_context)
    _sc_v137_data = build_v137_data_crosscheck(csv_fail_count=fail_count, proposal_release_gate=_sc_v137_gate['release_gate'], proposal_audit_gate=_sc_v137_audit['release_gate'], latest_proposal_integrity=_sc_v137_gate['latest_recalibration_proposal_integrity'])
    st.subheader('1Y. v1.37 재보정 제안 배포 데이터 교차 점검')
    srp1, srp2, srp3, srp4 = st.columns(4)
    srp1.metric('제안 데이터 점검', _locale.code(_sc_v137_data['status']))
    srp2.metric('차단 사유 점검 항목', _locale.code(_sc_v137_data['blocking_count']))
    srp3.metric('검증 점검', _locale.code(_sc_v137_audit['release_gate']))
    srp4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v137_data['checks'], width='stretch', hide_index=True)
    if _sc_v137_data['status'] == 'PASS':
        st.success('v1.37 재보정 제안 배포 데이터 교차 점검 정상 · 표 데이터 / 제안 기술 / 검증 / 최신 제안 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.37 재보정 제안 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 제안 검증/무결성을 확인하세요.')
    _sc_v138_context = build_v138_shadow_validation_context(v137_context=_sc_v137_context, shadow_validation_plan_snapshots=load_csv('operations_flow_shadow_validation_plan_snapshots.csv'))
    _sc_v138_gate = build_v138_shadow_validation_technical_release_gate(_sc_v138_context)
    _sc_v138_audit = build_v138_shadow_validation_audit_gate(_sc_v138_context)
    _sc_v138_data = build_v138_data_crosscheck(csv_fail_count=fail_count, shadow_validation_release_gate=_sc_v138_gate['release_gate'], shadow_validation_audit_gate=_sc_v138_audit['release_gate'], latest_plan_integrity=_sc_v138_gate['latest_shadow_validation_plan_integrity'])
    st.subheader('1Z. v1.38 격리 모의 검증 사전 등록 배포 데이터 교차 점검')
    svd1, svd2, svd3, svd4 = st.columns(4)
    svd1.metric('검증 데이터 점검', _locale.code(_sc_v138_data['status']))
    svd2.metric('차단 사유 점검 항목', _locale.code(_sc_v138_data['blocking_count']))
    svd3.metric('검증 점검', _locale.code(_sc_v138_audit['release_gate']))
    svd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v138_data['checks'], width='stretch', hide_index=True)
    if _sc_v138_data['status'] == 'PASS':
        st.success('v1.38 격리 모의 검증 사전 등록 배포 데이터 교차 점검 정상 · 표 데이터 / 검증 기술 / 검증 / 최신 계획 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.38 격리 모의 검증 사전 등록 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 검증 계획 검증/무결성을 확인하세요.')
    _sc_v139_context = build_v139_shadow_evaluation_context(v138_context=_sc_v138_context, scorecard_snapshots=load_csv('operations_flow_projection_scorecard_snapshots.csv'), qualified_outcomes=_sc_v135_context['qualification'].get('qualified_outcome_history', pd.DataFrame()), shadow_validation_outcome_snapshots=load_csv('operations_flow_shadow_validation_outcome_snapshots.csv'))
    _sc_v139_gate = build_v139_shadow_evaluation_technical_release_gate(_sc_v139_context)
    _sc_v139_audit = build_v139_shadow_evaluation_audit_gate(_sc_v139_context)
    _sc_v139_data = build_v139_data_crosscheck(csv_fail_count=fail_count, shadow_evaluation_release_gate=_sc_v139_gate['release_gate'], shadow_evaluation_audit_gate=_sc_v139_audit['release_gate'], latest_shadow_evaluation_integrity=_sc_v139_gate['latest_shadow_validation_outcome_integrity'])
    st.subheader('1AA. v1.39 격리 모의 검증 결과 배포 데이터 교차 점검')
    sod1, sod2, sod3, sod4 = st.columns(4)
    sod1.metric('격리 모의 평가 데이터 점검', _locale.code(_sc_v139_data['status']))
    sod2.metric('차단 사유 점검 항목', _locale.code(_sc_v139_data['blocking_count']))
    sod3.metric('검증 점검', _locale.code(_sc_v139_audit['release_gate']))
    sod4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v139_data['checks'], width='stretch', hide_index=True)
    if _sc_v139_data['status'] == 'PASS':
        st.success('v1.39 격리 모의 검증 결과 배포 데이터 교차 점검 정상 · 표 데이터 / 격리 모의 평가 기술 / 검증 / 최신 결과 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.39 격리 모의 검증 결과 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 격리 모의 평가 검증/무결성을 확인하세요.')
    _sc_v140_context = build_v140_adoption_context(v139_context=_sc_v139_context, shadow_validation_outcome_snapshots=load_csv('operations_flow_shadow_validation_outcome_snapshots.csv'), shadow_adoption_review_snapshots=load_csv('operations_flow_shadow_adoption_review_snapshots.csv'))
    _sc_v140_gate = build_v140_adoption_technical_release_gate(_sc_v140_context)
    _sc_v140_audit = build_v140_adoption_audit_gate(_sc_v140_context)
    _sc_v140_data = build_v140_data_crosscheck(csv_fail_count=fail_count, adoption_release_gate=_sc_v140_gate['release_gate'], adoption_audit_gate=_sc_v140_audit['release_gate'], latest_adoption_integrity=_sc_v140_gate['latest_shadow_adoption_integrity'])
    st.subheader('1AB. v1.40 격리 모의 검증 채택 사용자 판단 배포 데이터 교차 점검')
    sad1, sad2, sad3, sad4 = st.columns(4)
    sad1.metric('채택 데이터 점검', _locale.code(_sc_v140_data['status']))
    sad2.metric('차단 사유 점검 항목', _locale.code(_sc_v140_data['blocking_count']))
    sad3.metric('검증 점검', _locale.code(_sc_v140_audit['release_gate']))
    sad4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v140_data['checks'], width='stretch', hide_index=True)
    if _sc_v140_data['status'] == 'PASS':
        st.success('v1.40 격리 모의 검증 채택 배포 데이터 교차 점검 정상 · 표 데이터 / 채택 기술 / 검증 / 최신 사용자 판단 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.40 격리 모의 검증 채택 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 채택 검증/무결성을 확인하세요.')
    _sc_v141_context = build_v141_trial_design_context(v140_context=_sc_v140_context, controlled_trial_design_snapshots=load_csv('operations_flow_controlled_trial_design_snapshots.csv'))
    _sc_v141_gate = build_v141_trial_design_technical_release_gate(_sc_v141_context)
    _sc_v141_audit = build_v141_trial_design_audit_gate(_sc_v141_context)
    _sc_v141_data = build_v141_data_crosscheck(csv_fail_count=fail_count, trial_design_release_gate=_sc_v141_gate['release_gate'], trial_design_audit_gate=_sc_v141_audit['release_gate'], latest_trial_design_integrity=_sc_v141_gate['latest_trial_design_integrity'])
    st.subheader('1AC. v1.41 통제된 시험 운영 설계 배포 데이터 교차 점검')
    ctdc1, ctdc2, ctdc3, ctdc4 = st.columns(4)
    ctdc1.metric('시험 운영 설계 데이터 점검', _locale.code(_sc_v141_data['status']))
    ctdc2.metric('차단 사유 점검 항목', _locale.code(_sc_v141_data['blocking_count']))
    ctdc3.metric('검증 점검', _locale.code(_sc_v141_audit['release_gate']))
    ctdc4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v141_data['checks'], width='stretch', hide_index=True)
    if _sc_v141_data['status'] == 'PASS':
        st.success('v1.41 통제된 시험 운영 설계 배포 데이터 교차 점검 정상 · 표 데이터 / 시험 운영 설계 기술 / 검증 / 최신 설계 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.41 통제된 시험 운영 설계 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 시험 운영 설계 검증/무결성을 확인하세요.')
    _sc_v142_context = build_v142_trial_start_context(v141_context=_sc_v141_context, controlled_trial_start_snapshots=load_csv('operations_flow_controlled_trial_start_snapshots.csv'))
    _sc_v142_gate = build_v142_trial_start_technical_release_gate(_sc_v142_context)
    _sc_v142_audit = build_v142_trial_start_audit_gate(_sc_v142_context)
    _sc_v142_data = build_v142_data_crosscheck(csv_fail_count=fail_count, trial_start_release_gate=_sc_v142_gate['release_gate'], trial_start_audit_gate=_sc_v142_audit['release_gate'], latest_trial_start_integrity=_sc_v142_gate['latest_trial_start_integrity'])
    st.subheader('1AD. v1.42 통제된 시험 운영 시작 배포 데이터 교차 점검')
    ctsd1, ctsd2, ctsd3, ctsd4 = st.columns(4)
    ctsd1.metric('시험 운영 시작 데이터 점검', _locale.code(_sc_v142_data['status']))
    ctsd2.metric('차단 사유 점검 항목', _locale.code(_sc_v142_data['blocking_count']))
    ctsd3.metric('검증 점검', _locale.code(_sc_v142_audit['release_gate']))
    ctsd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v142_data['checks'], width='stretch', hide_index=True)
    if _sc_v142_data['status'] == 'PASS':
        st.success('v1.42 통제된 시험 운영 시작 배포 데이터 교차 점검 정상 · 표 데이터 / 시험 운영 시작 기술 / 검증 / 최신 시작 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.42 통제된 시험 운영 시작 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 시험 운영 시작 검증/무결성을 확인하세요.')
    _sc_v143_context = build_v143_trial_runtime_context(v142_context=_sc_v142_context, controlled_trial_runtime_snapshots=load_csv('operations_flow_controlled_trial_runtime_snapshots.csv'))
    _sc_v143_gate = build_v143_trial_runtime_technical_release_gate(_sc_v143_context)
    _sc_v143_audit = build_v143_trial_runtime_audit_gate(_sc_v143_context)
    _sc_v143_data = build_v143_data_crosscheck(csv_fail_count=fail_count, trial_runtime_release_gate=_sc_v143_gate['release_gate'], trial_runtime_audit_gate=_sc_v143_audit['release_gate'], latest_trial_runtime_integrity=_sc_v143_gate['latest_trial_runtime_integrity'])
    st.subheader('1AE. v1.43 통제된 시험 운영 실행 환경 배포 데이터 교차 점검')
    ctrd1, ctrd2, ctrd3, ctrd4 = st.columns(4)
    ctrd1.metric('시험 운영 실행 환경 데이터 점검', _locale.code(_sc_v143_data['status']))
    ctrd2.metric('차단 사유 점검 항목', _locale.code(_sc_v143_data['blocking_count']))
    ctrd3.metric('검증 점검', _locale.code(_sc_v143_audit['release_gate']))
    ctrd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v143_data['checks'], width='stretch', hide_index=True)
    if _sc_v143_data['status'] == 'PASS':
        st.success('v1.43 통제된 시험 운영 실행 환경 배포 데이터 교차 점검 정상 · 표 데이터 / 실행 환경 기술 / 검증 / 최신 실행 환경 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.43 통제된 시험 운영 실행 환경 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 실행 환경 검증/무결성을 확인하세요.')
    _sc_v144_context = build_v144_trial_outcome_context(v143_context=_sc_v143_context, recalibration_proposal_snapshots=_sc_v137_context['recalibration_proposal_snapshots'], qualified_outcomes=_sc_v135_context['qualification'].get('qualified_outcome_history', pd.DataFrame()), controlled_trial_outcome_snapshots=load_csv('operations_flow_controlled_trial_outcome_snapshots.csv'))
    _sc_v144_gate = build_v144_trial_outcome_technical_release_gate(_sc_v144_context)
    _sc_v144_audit = build_v144_trial_outcome_audit_gate(_sc_v144_context)
    _sc_v144_data = build_v144_data_crosscheck(csv_fail_count=fail_count, trial_outcome_release_gate=_sc_v144_gate['release_gate'], trial_outcome_audit_gate=_sc_v144_audit['release_gate'], latest_trial_outcome_integrity=_sc_v144_gate['latest_trial_outcome_integrity'])
    st.subheader('1AF. v1.44 통제된 시험 운영 결과 배포 데이터 교차 점검')
    ctod1, ctod2, ctod3, ctod4 = st.columns(4)
    ctod1.metric('시험 운영 결과 데이터 점검', _locale.code(_sc_v144_data['status']))
    ctod2.metric('차단 사유 점검 항목', _locale.code(_sc_v144_data['blocking_count']))
    ctod3.metric('검증 점검', _locale.code(_sc_v144_audit['release_gate']))
    ctod4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v144_data['checks'], width='stretch', hide_index=True)
    if _sc_v144_data['status'] == 'PASS':
        st.success('v1.44 통제된 시험 운영 결과 배포 데이터 교차 점검 정상 · 표 데이터 / 시험 운영 결과 기술 / 검증 / 최신 결과 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.44 통제된 시험 운영 결과 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 시험 운영 결과 검증/무결성을 확인하세요.')
    _sc_v145_context = build_v145_trial_closure_context(v144_context=_sc_v144_context, controlled_trial_closure_snapshots=load_csv('operations_flow_controlled_trial_closure_snapshots.csv'))
    _sc_v145_gate = build_v145_trial_closure_technical_release_gate(_sc_v145_context)
    _sc_v145_audit = build_v145_trial_closure_audit_gate(_sc_v145_context)
    _sc_v145_data = build_v145_data_crosscheck(csv_fail_count=fail_count, trial_closure_release_gate=_sc_v145_gate['release_gate'], trial_closure_audit_gate=_sc_v145_audit['release_gate'], latest_trial_closure_integrity=_sc_v145_gate['latest_trial_closure_integrity'])
    st.subheader('1AG. v1.45 통제된 시험 운영 종결 배포 데이터 교차 점검')
    ctcd1, ctcd2, ctcd3, ctcd4 = st.columns(4)
    ctcd1.metric('시험 운영 종결 데이터 점검', _locale.code(_sc_v145_data['status']))
    ctcd2.metric('차단 사유 점검 항목', _locale.code(_sc_v145_data['blocking_count']))
    ctcd3.metric('검증 점검', _locale.code(_sc_v145_audit['release_gate']))
    ctcd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v145_data['checks'], width='stretch', hide_index=True)
    if _sc_v145_data['status'] == 'PASS':
        st.success('v1.45 통제된 시험 운영 종결 배포 데이터 교차 점검 정상 · 표 데이터 / 시험 운영 종결 기술 / 검증 / 최신 종결 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.45 통제된 시험 운영 종결 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 시험 운영 종결 검증/무결성을 확인하세요.')
    _sc_v146_context = build_v146_live_change_design_context(v145_context=_sc_v145_context, recalibration_proposal_snapshots=load_csv('operations_flow_recalibration_proposal_snapshots.csv'), live_change_design_snapshots=load_csv('operations_flow_live_change_design_snapshots.csv'))
    _sc_v146_gate = build_v146_live_change_design_technical_release_gate(_sc_v146_context)
    _sc_v146_audit = build_v146_live_change_design_audit_gate(_sc_v146_context)
    _sc_v146_data = build_v146_data_crosscheck(csv_fail_count=fail_count, live_change_design_release_gate=_sc_v146_gate['release_gate'], live_change_design_audit_gate=_sc_v146_audit['release_gate'], latest_live_change_design_integrity=_sc_v146_gate['latest_live_change_design_integrity'])
    st.subheader('1AH. v1.46 운영 변경 설계 배포 데이터 교차 점검')
    lcdd1, lcdd2, lcdd3, lcdd4 = st.columns(4)
    lcdd1.metric('운영 변경 설계 데이터 점검', _locale.code(_sc_v146_data['status']))
    lcdd2.metric('차단 사유 점검 항목', _locale.code(_sc_v146_data['blocking_count']))
    lcdd3.metric('검증 점검', _locale.code(_sc_v146_audit['release_gate']))
    lcdd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v146_data['checks'], width='stretch', hide_index=True)
    if _sc_v146_data['status'] == 'PASS':
        st.success('v1.46 운영 변경 설계 배포 데이터 교차 점검 정상 · 표 데이터 / 설계 기술 / 검증 / 최신 설계 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.46 운영 변경 설계 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 운영 변경 설계 검증/무결성을 확인하세요.')
    _sc_v147_context = build_v147_live_change_apply_context(v146_context=_sc_v146_context, live_change_apply_snapshots=load_csv('operations_flow_live_change_apply_snapshots.csv'))
    _sc_v147_gate = build_v147_live_change_apply_technical_release_gate(_sc_v147_context)
    _sc_v147_audit = build_v147_live_change_apply_audit_gate(_sc_v147_context)
    _sc_v147_data = build_v147_data_crosscheck(csv_fail_count=fail_count, live_change_apply_release_gate=_sc_v147_gate['release_gate'], live_change_apply_audit_gate=_sc_v147_audit['release_gate'], latest_live_change_apply_integrity=_sc_v147_gate['latest_live_change_apply_integrity'])
    st.subheader('1AI. v1.47 운영 변경 적용 배포 데이터 교차 점검')
    lcad1, lcad2, lcad3, lcad4 = st.columns(4)
    lcad1.metric('운영 변경 적용 데이터 점검', _locale.code(_sc_v147_data['status']))
    lcad2.metric('차단 사유 점검 항목', _locale.code(_sc_v147_data['blocking_count']))
    lcad3.metric('검증 점검', _locale.code(_sc_v147_audit['release_gate']))
    lcad4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v147_data['checks'], width='stretch', hide_index=True)
    if _sc_v147_data['status'] == 'PASS':
        st.success('v1.47 운영 변경 적용 배포 데이터 교차 점검 정상 · 표 데이터 / 적용 기술 / 검증 / 최신 적용 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.47 운영 변경 적용 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 운영 변경 적용 검증/무결성을 확인하세요.')
    _sc_v148_context = build_v148_live_change_runtime_context(v147_context=_sc_v147_context, live_change_runtime_snapshots=load_csv('operations_flow_live_change_runtime_snapshots.csv'))
    _sc_v148_gate = build_v148_live_change_runtime_technical_release_gate(_sc_v148_context)
    _sc_v148_audit = build_v148_live_change_runtime_audit_gate(_sc_v148_context)
    _sc_v148_data = build_v148_data_crosscheck(csv_fail_count=fail_count, live_change_runtime_release_gate=_sc_v148_gate['release_gate'], live_change_runtime_audit_gate=_sc_v148_audit['release_gate'], latest_live_change_runtime_integrity=_sc_v148_gate['latest_live_change_runtime_integrity'])
    st.subheader('1AJ. v1.48 운영 변경 실행 환경 배포 데이터 교차 점검')
    lcrd1, lcrd2, lcrd3, lcrd4 = st.columns(4)
    lcrd1.metric('운영 변경 실행 환경 데이터 점검', _locale.code(_sc_v148_data['status']))
    lcrd2.metric('차단 사유 점검 항목', _locale.code(_sc_v148_data['blocking_count']))
    lcrd3.metric('검증 점검', _locale.code(_sc_v148_audit['release_gate']))
    lcrd4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v148_data['checks'], width='stretch', hide_index=True)
    if _sc_v148_data['status'] == 'PASS':
        st.success('v1.48 운영 변경 실행 환경 배포 데이터 교차 점검 정상 · 표 데이터 / 실행 환경 기술 / 검증 / 최신 실행 환경 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.48 운영 변경 실행 환경 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 운영 변경 실행 환경 검증/무결성을 확인하세요.')
    _sc_v149_context = build_v149_live_change_outcome_context(v148_context=_sc_v148_context, qualified_outcomes=_sc_v135_context['qualification'].get('qualified_outcome_history', pd.DataFrame()), live_change_outcome_snapshots=load_csv('operations_flow_live_change_outcome_snapshots.csv'))
    _sc_v149_gate = build_v149_live_change_outcome_technical_release_gate(_sc_v149_context)
    _sc_v149_audit = build_v149_live_change_outcome_audit_gate(_sc_v149_context)
    _sc_v149_data = build_v149_data_crosscheck(csv_fail_count=fail_count, live_change_outcome_release_gate=_sc_v149_gate['release_gate'], live_change_outcome_audit_gate=_sc_v149_audit['release_gate'], latest_live_change_outcome_integrity=_sc_v149_gate['latest_live_change_outcome_integrity'])
    st.subheader('1AK. v1.49 운영 변경 결과 배포 데이터 교차 점검')
    lcod1, lcod2, lcod3, lcod4 = st.columns(4)
    lcod1.metric('운영 변경 결과 데이터 점검', _locale.code(_sc_v149_data['status']))
    lcod2.metric('차단 사유 점검 항목', _locale.code(_sc_v149_data['blocking_count']))
    lcod3.metric('검증 점검', _locale.code(_sc_v149_audit['release_gate']))
    lcod4.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v149_data['checks'], width='stretch', hide_index=True)
    if _sc_v149_data['status'] == 'PASS':
        st.success('v1.49 운영 변경 결과 배포 데이터 교차 점검 정상 · 표 데이터 / 결과 기술 / 검증 / 최신 결과 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.49 운영 변경 결과 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 운영 변경 결과 검증/무결성을 확인하세요.')
    _sc_v150_context = build_v150_live_change_closure_context(v149_context=_sc_v149_context, live_change_closure_snapshots=load_csv('operations_flow_live_change_outcome_closure_snapshots.csv'))
    _sc_v150_gate = build_v150_live_change_closure_technical_release_gate(_sc_v150_context)
    _sc_v150_audit = build_v150_live_change_closure_audit_gate(_sc_v150_context)
    _sc_v150_rm_status = release_manager_status_report(ROOT, include_candidates=False)
    _sc_v150_migration_verify = work_ready_verify_migration(Path(_WORK_READY_LAYOUT['home_root'])) if _WORK_READY_LAYOUT.get('active') else {'status': 'LEGACY', 'checks': {}}
    _sc_v150_work_context = build_v150_work_ready_context(code_root=ROOT, layout=_WORK_READY_LAYOUT, release_manager_status=_sc_v150_rm_status, migration_verify=_sc_v150_migration_verify)
    _sc_v150_work_gate = build_v150_work_ready_release_gate(_sc_v150_work_context)
    _sc_v150_data = build_v150_data_crosscheck(csv_fail_count=fail_count, closure_release_gate=_sc_v150_gate['release_gate'], closure_audit_gate=_sc_v150_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_closure_integrity=_sc_v150_gate['latest_live_change_closure_integrity'])
    st.subheader('1AL. v1.50 운영 준비 환경 사용자 종결 배포 데이터 교차 점검')
    scv1501, scv1502, scv1503, scv1504 = st.columns(4)
    scv1501.metric('v1.50 데이터 점검', _locale.code(_sc_v150_data['status']))
    scv1502.metric('차단 사유 점검 항목', _locale.code(_sc_v150_data['blocking_count']))
    scv1503.metric('운영 준비 환경 점검', _locale.code(_sc_v150_work_gate['release_gate']))
    scv1504.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v150_data['checks'], width='stretch', hide_index=True)
    if _sc_v150_data['status'] == 'PASS':
        st.success('v1.50 배포 데이터 교차 점검 정상 · 표 데이터 / 사용자 종결 / 운영 준비 환경 / 최신 종결 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.50 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 사용자 종결/운영 준비 환경 검증/무결성을 확인하세요.')
    _sc_v151_context = build_v151_permanent_change_design_context(v150_context=_sc_v150_context, permanent_change_design_snapshots=load_csv('operations_flow_permanent_change_design_snapshots.csv'))
    _sc_v151_gate = build_v151_permanent_change_design_technical_release_gate(_sc_v151_context)
    _sc_v151_audit = build_v151_permanent_change_design_audit_gate(_sc_v151_context)
    _sc_v151_data = build_v151_data_crosscheck(csv_fail_count=fail_count, design_release_gate=_sc_v151_gate['release_gate'], design_audit_gate=_sc_v151_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_design_integrity=_sc_v151_gate['latest_permanent_change_design_integrity'])
    st.subheader('1AM. v1.51 영구 변경 설계 배포 데이터 교차 점검')
    scv1511, scv1512, scv1513, scv1514 = st.columns(4)
    scv1511.metric('v1.51 데이터 점검', _locale.code(_sc_v151_data['status']))
    scv1512.metric('차단 사유 점검 항목', _locale.code(_sc_v151_data['blocking_count']))
    scv1513.metric('운영 준비 환경 점검', _locale.code(_sc_v150_work_gate['release_gate']))
    scv1514.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v151_data['checks'], width='stretch', hide_index=True)
    if _sc_v151_data['status'] == 'PASS':
        st.success('v1.51 배포 데이터 교차 점검 정상 · 표 데이터 / 영구 설계 / 운영 준비 환경 / 최신 설계 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.51 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 영구 설계/운영 준비 환경 검증/무결성을 확인하세요.')
    _sc_v152_context = build_v152_permanent_change_apply_context(v151_context=_sc_v151_context, permanent_change_apply_snapshots=load_csv('operations_flow_permanent_change_apply_snapshots.csv'))
    _sc_v152_gate = build_v152_permanent_change_apply_technical_release_gate(_sc_v152_context)
    _sc_v152_audit = build_v152_permanent_change_apply_audit_gate(_sc_v152_context)
    _sc_v152_data = build_v152_data_crosscheck(csv_fail_count=fail_count, apply_release_gate=_sc_v152_gate['release_gate'], apply_audit_gate=_sc_v152_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_apply_integrity=_sc_v152_gate['latest_permanent_change_apply_integrity'])
    st.subheader('1AN. v1.52 영구 변경 적용 배포 데이터 교차 점검')
    scv1521, scv1522, scv1523, scv1524 = st.columns(4)
    scv1521.metric('v1.52 데이터 점검', _locale.code(_sc_v152_data['status']))
    scv1522.metric('차단 사유 점검 항목', _locale.code(_sc_v152_data['blocking_count']))
    scv1523.metric('운영 준비 환경 점검', _locale.code(_sc_v150_work_gate['release_gate']))
    scv1524.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v152_data['checks'], width='stretch', hide_index=True)
    if _sc_v152_data['status'] == 'PASS':
        st.success('v1.52 배포 데이터 교차 점검 정상 · 표 데이터 / 영구 적용 / 운영 준비 환경 / 최신 적용 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.52 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 영구 적용/운영 준비 환경 검증/무결성을 확인하세요.')
    _sc_v153_context = build_v153_permanent_change_runtime_context(v152_context=_sc_v152_context, permanent_change_runtime_events=load_csv('operations_flow_permanent_change_runtime_events.csv'))
    _sc_v153_gate = build_v153_permanent_change_runtime_technical_release_gate(_sc_v153_context)
    _sc_v153_audit = build_v153_permanent_change_runtime_audit_gate(_sc_v153_context)
    _sc_v153_data = build_v153_data_crosscheck(csv_fail_count=fail_count, runtime_release_gate=_sc_v153_gate['release_gate'], runtime_audit_gate=_sc_v153_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_runtime_integrity=_sc_v153_gate['latest_permanent_change_runtime_integrity'])
    st.subheader('1AO. v1.53 영구 변경 실행 환경 배포 데이터 교차 점검')
    scv1531, scv1532, scv1533, scv1534 = st.columns(4)
    scv1531.metric('v1.53 데이터 점검', _locale.code(_sc_v153_data['status']))
    scv1532.metric('차단 사유 점검 항목', _locale.code(_sc_v153_data['blocking_count']))
    scv1533.metric('운영 준비 환경 점검', _locale.code(_sc_v150_work_gate['release_gate']))
    scv1534.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v153_data['checks'], width='stretch', hide_index=True)
    if _sc_v153_data['status'] == 'PASS':
        st.success('v1.53 배포 데이터 교차 점검 정상 · 표 데이터 / 영구 실행 환경 / 운영 준비 환경 / 최신 실행 환경 무결성 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.53 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 영구 실행 환경/운영 준비 환경 검증/무결성을 확인하세요.')
    _sc_v154_context = build_v154_updater2_context(ROOT)
    _sc_v154_gate = build_v154_updater2_technical_release_gate(_sc_v154_context)
    _sc_v154_audit = build_v154_updater2_audit_gate(_sc_v154_context)
    _sc_v154_data = build_v154_data_crosscheck(csv_fail_count=fail_count, updater2_release_gate=_sc_v154_gate['release_gate'], updater2_audit_gate=_sc_v154_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'])
    st.subheader('1AP. v1.54 업데이트 도구 2 배포 데이터 교차 점검')
    scv1541, scv1542, scv1543, scv1544 = st.columns(4)
    scv1541.metric('v1.54 데이터 점검', _locale.code(_sc_v154_data['status']))
    scv1542.metric('차단 사유 점검 항목', _locale.code(_sc_v154_data['blocking_count']))
    scv1543.metric('운영 준비 환경 점검', _locale.code(_sc_v150_work_gate['release_gate']))
    scv1544.metric('투자 실행 권한', '없음')
    _locale.dataframe(st, _sc_v154_data['checks'], width='stretch', hide_index=True)
    if _sc_v154_data['status'] == 'PASS':
        st.success('v1.54 배포 데이터 교차 점검 정상 · 표 데이터 / 업데이트 도구 2 / 운영 준비 환경 차단 사유 점검이 없습니다.')
    else:
        st.warning('v1.54 배포 데이터 교차 점검 차단됨 · 표 데이터 또는 업데이트 도구 2/운영 준비 환경 검증/무결성을 확인하세요.')
    st.subheader('2. 전체 사용자 데이터 백업')
    latest_backup = latest_user_backup()
    if latest_backup.get('exists'):
        st.caption(f"최근 전체 백업: {latest_backup['modified']} · {latest_backup['files']}개 파일")
    else:
        st.caption('아직 전체 사용자 데이터 백업이 없습니다.')
    if st.button('사용자 데이터 전체 백업', type='primary', key='save_center_full_backup'):
        try:
            folder = backup_user_data()
            st.session_state['_save_flash'] = ('success', f'전체 사용자 데이터 백업 완료 · {folder.name}')
            st.rerun()
        except Exception as e:
            st.error(f'전체 백업 실패: {e}')
    st.caption('전체 백업에는 data/*.csv와 settings.json이 포함되며, 각 파일 SHA-256이 manifest.json에 기록됩니다. .env가 있으면 로컬 백업 폴더에만 복사하며 앱 화면에는 표시하지 않습니다.')
    st.subheader('3. 최근 저장 기록')
    events = get_save_events(50)
    if events.empty:
        st.info('아직 저장 기록이 없습니다. 다음 저장부터 기록됩니다.')
    else:
        _locale.dataframe(st, events.iloc[::-1].reset_index(drop=True), width='stretch', hide_index=True)
        failed_events = events.loc[events['status'].astype(str).eq('FAIL')]
        if not failed_events.empty:
            st.warning('최근 저장 실패 기록이 있습니다. 원인 해결 후 해당 화면에서 다시 한 번 저장하세요.')
    st.subheader('4. 저장이 안 될 때')
    st.write('- 표 데이터를 Excel에서 열어 둔 경우 닫아 주세요.\n- OneDrive/백신이 잠시 파일을 잠그면 앱이 자동으로 여러 번 재시도합니다.\n- 저장 성공 메시지에 `저장 검증 PASS`가 보이면 다시 누르지 않아도 됩니다.\n- 저장 실패 시 버튼을 연속으로 누르기보다 표시된 오류 내용을 먼저 확인하세요.')
    if st.button('저장 상태 다시 검사', key='save_center_recheck'):
        st.rerun()
    st.caption('저장 센터는 주문 기능과 무관하며 사용자 데이터의 저장/백업 상태만 점검합니다.')
