"""Explicit local order history navigation; never initiates broker requests."""
import streamlit as st
from connectors.kis_broker import BrokerError
from engine.order_review import order_counts,order_page


def review_records(client,journal):
    context=(id(client),client.credentials.identity,client.credentials.mode,str(journal.path.resolve()))
    state=st.session_state
    if state.get('_kis_review_context')!=context:
        for key in ('_kis_review_page','kis_review_scope','kis_history'):state.pop(key,None)
        state['_kis_review_context']=context
    if 'kis_review_scope' not in state:
        state['kis_review_scope']='ACTIVE' if order_counts(journal,context[1])['active'] else 'ALL'
    scope=st.radio('주문 기록 범위',['ACTIVE','ALL'],format_func=lambda x:'미완료 주문' if x=='ACTIVE' else '전체 주문 기록',horizontal=True,key='kis_review_scope')
    saved=state.get('_kis_review_page')
    if saved and saved['scope']!=scope:
        saved=None;state.pop('_kis_review_page',None);state.pop('kis_history',None)
    first=st.button('주문 기록 처음부터 다시 읽기',key='kis_orders_first')
    cursor=None if first or not saved else saved['cursor']
    if first:state.pop('kis_history',None)
    page=order_page(journal,context[1],scope=scope,cursor=cursor)
    following=st.button('다음 주문 기록 100건',key='kis_orders_next',disabled=not page['next_cursor'])
    if following:
        state['_kis_review_page']=dict(scope=scope,cursor=page['next_cursor'],next_cursor=None)
        state.pop('kis_history',None)
        st.rerun()
    if context!=(id(client),client.credentials.identity,client.credentials.mode,str(journal.path.resolve())):
        state.pop('_kis_review_page',None)
        raise BrokerError('연결이 바뀌었습니다. 현재 연결의 기록을 처음부터 다시 읽으세요.')
    state['_kis_review_page']=dict(scope=scope,cursor=cursor,next_cursor=page['next_cursor'])
    st.info(f"현재 연결의 미완료 주문 {page['counts']['active']}건 · 전체 기록 {page['counts']['all']}건 · 이번 표시 {len(page['records'])}건 · 이후 범위 {page['remaining']}건")
    st.caption('로컬 주문 기록 확인 시각 (UTC): '+page['checked_at'])
    st.caption('미완료에는 접수·미체결·부분 체결·결과 불명확 주문과 확인 시간이 남은 전송 전 준비를 포함합니다. 범위 이동은 로컬 기록만 읽습니다. 증권사 조회·주문·취소·차단 해제를 실행하지 않습니다. 새로 추가된 기록은 처음부터 다시 읽기로 확인하세요.')
    if not page['records']:
        st.caption('선택한 범위에 표시할 주문이 없습니다. 전체 주문 기록을 선택하거나 처음부터 다시 읽으세요.')
    return page['records']
