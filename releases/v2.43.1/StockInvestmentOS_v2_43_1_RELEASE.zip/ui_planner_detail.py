"""Translate exact engine descriptions only when corroborated by source summary."""
SPECS = {
 'Canonical Assumption': ('assumption_approval','REVIEW','Assumption Approval','가정 승인',{'APPROVED':'승인됨','REVIEW':'검토 필요'}),
 'Thesis Invalidation': ('invalidation_status','NOT TRIGGERED','Invalidation','투자 가설 무효화',{'NOT TRIGGERED':'미발생','TRIGGERED':'발생','CHECK':'확인 필요'}),
 'Lifecycle': ('lifecycle','OBSERVE','Lifecycle','투자 단계',{'OBSERVE':'관찰','INITIAL':'초기','CORE':'핵심','MAX':'최대','EXIT':'청산'}),
 'Add Freeze': ('add_freeze','REVIEW','Add Freeze','추가 투자 보류',{'OFF':'해제','ON':'설정','REVIEW':'검토 필요'}),
 'Portfolio Fit': ('portfolio_fit','REVIEW','Portfolio Fit','포트폴리오 적합성',{'PASS':'정상','REVIEW':'검토 필요','BLOCKED':'진행 차단'}),
}

def detail_text(gate, detail, summary):
    if not isinstance(gate,str) or not isinstance(detail,str) or not isinstance(summary,dict): return detail
    spec=SPECS.get(gate)
    if spec is None: return generated_detail(gate,detail,summary)
    key,default,prefix,label,values=spec
    raw=summary.get(key)
    value='' if raw is None else str(raw).strip()
    if value.lower() in {'nan','none','nat'}: value=''
    value=value.upper() or default
    if value not in values or detail != f'{prefix} = {value}': return detail
    return f'{label} = {values[value]}'

def _text(value):
    if value is None:return ''
    text=str(value).strip()
    return '' if text.lower() in {'nan','none','nat'} else text

def generated_detail(gate, detail, summary):
    import re
    if gate=='Execution':
        try:
            risk=int(summary.get('risk_ceiling_shares',0) or 0)
            executable=int(summary.get('executable_shares',0) or 0)
        except (ValueError,TypeError,OverflowError):return detail
        if detail==f'Risk Ceiling {risk:,}주 / Executable {executable:,}주':
            return f'위험 상한 {risk:,}주 / 실행 가능 {executable:,}주'
    if gate=='Price / No-Chase' and detail==_text(summary.get('price_gate_detail')):
        matched=re.fullmatch(r'현재가 ([0-9,]+)원 (>|<=) No-Chase Ceiling ([0-9,]+)원',detail)
        if matched:return f'현재가 {matched[1]}원 {matched[2]} 추격 매수 금지 상한 {matched[3]}원'
        if detail=='No-Chase Ceiling이 필요합니다.':return '추격 매수 금지 상한이 필요합니다.'
    if gate=='Incremental Factor Risk':
        factor=_text(summary.get('factor')) or 'Factor'
        state=_text(summary.get('factor_breach_status')).upper() or 'REVIEW'
        states={'WITHIN CAP':'상한 이내','PRE-EXISTING BREACH':'기존 상한 초과','AT CAP':'상한 도달','REVIEW':'검토 필요'}
        if state in states:
            suffix=' · 동일 Factor 신규 위험 Headroom은 0%로 봅니다.' if state in {'PRE-EXISTING BREACH','AT CAP'} else ''
            if detail==f'{factor} = {state}'+suffix:
                name='투자 요인' if factor=='Factor' and not _text(summary.get('factor')) else factor
                return f'{name} = {states[state]}'+(' · 동일 투자 요인의 신규 위험 여유는 0%로 봅니다.' if suffix else '')
    return SCENARIO_DETAILS.get(gate,{}).get(detail,detail)

SCENARIO_DETAILS={
'Scenario Reconciliation':{
'APPROVED Scenario Refresh가 없습니다. 현재 Canonical 원장을 사용합니다.':'검토 승인된 시나리오 갱신이 없습니다. 현재 기준 가정 원장을 사용합니다.',
'Latest APPROVED Scenario가 Canonical 원장과 명시적으로 Reconciliation되었습니다.':'최근 검토 승인된 시나리오를 기준 가정 원장과 명시적으로 대조·조정했습니다.',
'Latest APPROVED Scenario를 Canonical 원장과 Reconciliation하기 전에는 신규 위험을 늘리지 않습니다.':'최근 검토 승인된 시나리오를 기준 가정 원장과 대조·조정하기 전에는 신규 위험을 늘리지 않습니다.'},
'Scenario Signal':{
'Latest Scenario가 Thesis Break Review를 요구합니다.':'최근 시나리오에 따라 투자 가설 훼손 여부를 검토해야 합니다.',
'Latest Scenario의 약화 Evidence를 Red Team 검토해야 합니다.':'최근 시나리오의 약화 근거를 반대 관점에서 검토해야 합니다.',
'Scenario의 Model Risk 신호가 있습니다. Reconciliation 상태와 Canonical 위험가정을 함께 봅니다.':'시나리오의 모형 위험 신호가 있습니다. 대조·조정 상태와 기준 위험 가정을 함께 확인합니다.',
'Scenario 신호는 자동 매수·매도 Gate가 아닙니다.':'시나리오 신호는 자동 매수·매도 조건이 아닙니다.'}}
