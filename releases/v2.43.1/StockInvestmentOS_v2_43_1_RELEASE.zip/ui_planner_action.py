"""Display-only exact translations for execution planner instructions."""
from ui_decision_reason import reason_label

ACTIONS = {
 'Primary Source / Thesis / Proof Clock 업데이트':'공식 원문 / 투자 가설 / 근거 유효기간 갱신',
 'Cash 유지 또는 신규 위험을 늘리지 않는 대기':'현금 유지 또는 신규 위험을 늘리지 않는 대기',
 '기존 Factor Risk Repair 시뮬레이션 검토':'기존 투자 요인 위험 조정 모의 분석 검토',
 'Scenario / Canonical Reconciliation 재검토':'시나리오 / 기준 가정 일치 여부 재검토',
 'Risk Ceiling을 목표수량으로 해석':'위험상한을 목표 수량으로 해석',
 'PASS/READY를 자동 주문 신호로 해석':'정상/준비 완료를 자동 주문 신호로 해석',
 'Add Freeze 해제 전 추가매수':'추가 투자 보류 해제 전 추가 매수',
 'APPROVED Scenario 미조정 상태에서 신규 위험 확대':'검토 승인된 시나리오를 기준 가정과 조정하기 전에 신규 위험 확대',
 'No-Chase / Price Gate 우회':'추격 매수 금지 / 가격 조건 우회',
 'Portfolio Headroom 초과':'포트폴리오 추가 투자 여력 초과',
 'Thesis Break 검토 전 신규 위험 확대':'투자 가설 훼손 검토 전 신규 위험 확대',
}
NEXT = {
 '공통값과 모듈 연결의 BLOCKED 항목을 먼저 수정':'공통값과 모듈 연결의 진행 차단 항목을 먼저 수정',
 'Canonical Assumption과 Integration REVIEW를 먼저 해결':'기준 가정과 시스템 통합의 검토 필요 사항을 먼저 해결',
 '반대 가설·Invalidation·Primary Source를 먼저 재검토':'반대 가설·가설 무효화·공식 원문을 먼저 재검토',
 '추가 위험보다 Exit / Re-entry 조건을 먼저 검토':'추가 위험보다 청산 / 재진입 조건을 먼저 검토',
 '신규 Add보다 기존 포지션의 위험복구 시나리오를 먼저 검토':'신규 추가 투자보다 기존 보유 자산의 위험 조정 시나리오를 먼저 검토',
 'Add Freeze 해제에 필요한 Evidence 조건을 확인':'추가 투자 보류 해제에 필요한 근거 조건을 확인',
 'Lifecycle 전환 조건과 다음 Evidence를 확인':'투자 단계 전환 조건과 다음 근거를 확인',
 'Latest APPROVED Scenario를 Canonical 원장과 먼저 조정':'최근 검토 승인된 시나리오를 기준 가정 원장과 먼저 조정',
 '기존 Factor 집중위험과 신규 Headroom을 분리해 검토':'기존 투자 요인 집중 위험과 신규 투자 여력을 나누어 검토',
 'Portfolio Fit / Headroom을 먼저 검토':'포트폴리오 적합성 / 추가 투자 여력을 먼저 검토',
 'Price / No-Chase / Lifecycle 실행 Gate를 확인':'가격 / 추격 매수 금지 / 투자 단계의 실행 조건을 확인',
 'Executable 수량 범위에서 주문계획을 최종 검토':'실행 검토 수량 범위에서 주문 계획을 최종 검토',
 '0주가 된 원인을 Decision Summary에서 확인':'0주가 된 원인을 투자 판단 요약에서 확인',
}
PAGES = {
 'System Integration':'시스템 통합 점검','Thesis Monitor':'투자 근거 점검',
 'Investment State':'투자 상태','Portfolio Risk Repair':'포트폴리오 위험 조정',
 'Scenario Reconciliation':'시나리오 일치 점검','Factor Risk Repair':'투자 요인 위험 조정',
 'Portfolio Fit':'포트폴리오 적합성','Position Sizing':'투자 규모 산정',
 'Execution Checklist':'실행 전 체크리스트','Decision Summary':'투자 판단 요약',
}

def action_text(value):
    return ACTIONS.get(value, value) if isinstance(value, str) else value

def next_text(value):
    return NEXT.get(value, value) if isinstance(value, str) else value

def page_text(value):
    return PAGES.get(value, value) if isinstance(value, str) else value

def blocking_text(value, summary, plan):
    """Require matching engine gate/detail; never translate arbitrary price details."""
    if not isinstance(value, str): return value
    rows = plan.get('gate_rows')
    if rows is None or not {'gate','detail','blocks_new_risk'}.issubset(rows.columns): return value
    names={'Canonical Assumption':'기준 가정','Lifecycle':'투자 단계',
           'Add Freeze':'추가 투자 보류','Portfolio Fit':'포트폴리오 적합성',
           'Thesis Invalidation':'투자 가설 무효화'}
    for row in rows.to_dict('records'):
        gate, detail = row.get('gate'), row.get('detail')
        if not row.get('blocks_new_risk') or value != f'{gate}: {detail}': continue
        if gate in names:
            translated = reason_label(detail, summary)
            if translated != detail: return f'{names[gate]}: {translated}'
        if gate == 'Scenario Reconciliation' and detail == 'Latest APPROVED Scenario를 Canonical 원장과 Reconciliation하기 전에는 신규 위험을 늘리지 않습니다.':
            return '시나리오 일치 점검: 최근 검토 승인된 시나리오를 기준 가정 원장과 대조·조정하기 전에는 신규 위험을 늘리지 않습니다.'
    return value
