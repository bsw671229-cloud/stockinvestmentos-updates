"""Plan editor UI. Loading never starts an automation or changes its journal."""
import ui_locale as _locale
import streamlit as st
from engine.paper_plans import PlanStore, editor_values
from engine.broker_execution import digest
from engine.plan_preview import preview


def clear_editor_confirmation():
    st.session_state.pop('_paper_rehearsal', None)
    st.session_state.pop('paper_attested', None)
    st.session_state.pop('live_confirmation', None)


def clear_plan_context():
    for key in list(st.session_state):
        if key.startswith(('paper_daily_', 'paper_plan_', 'paper_remove_rule_')) or key in ('paper_minutes','_paper_loaded_plan','_paper_plan_reference','_paper_plan_notice','_paper_plan_preview'):
            st.session_state.pop(key, None)


def _preview(payload, *, mode):
    draft = st.session_state.get('_paper_auto_draft', [])
    budgets = {c: {field: st.session_state.get('paper_daily_'+field+'_'+c, default)
                  for field, default in (('cost','0'),('loss','0'),('count',1))}
               for c in sorted({r['order']['currency'] for r in draft})}
    result = preview(payload, draft, budgets, st.session_state.get('paper_minutes',10), mode=mode)
    st.markdown('**불러올 계획 미리보기**')
    st.caption(f"조건 {len(result['rules'])}개 · 실행 시간 {result['minutes']}분")
    _locale.dataframe(st, result['rules'], hide_index=True, width='stretch', alt='저장한 계획의 모든 매매 조건')
    _locale.dataframe(st, result['budgets'], hide_index=True, width='stretch', alt='저장한 계획의 통화별 하루 한도')
    st.markdown('**현재 반영값과 비교**')
    st.caption('등록된 조건의 순서와 마지막으로 제출한 하루 한도·실행 시간을 비교합니다. 아직 추가하지 않은 조건과 제출하지 않은 한도 입력은 포함되지 않습니다. 아래의 현재 한도 입력을 비교에 반영 버튼으로 갱신하세요.')
    if result['changes']:
        st.caption(f"불러오면 {len(result['changes'])}개 항목이 달라집니다. 조건 순서 변경도 변경으로 표시합니다.")
        _locale.dataframe(st, result['changes'], hide_index=True, width='stretch', alt='현재 반영값과 저장한 계획의 변경 항목')
    else:
        st.info('현재 반영값과 저장한 계획이 같습니다.')


def library(client, journal, *, mode='PAPER'):
    notice = st.session_state.pop('_paper_plan_notice', None)
    if notice:
        st.success(_locale.message(notice))
    with st.expander('저장한 자동매매 계획'):
        label = '실전' if mode == 'LIVE' else '모의'
        st.caption('현재 '+label+'계좌의 조건·하루 한도·실행 시간을 이 PC에 저장합니다. 저장·불러오기는 주문을 시작하지 않습니다.')
        st.caption('실전·모의 계획과 계좌별 목록은 분리됩니다. 외부 연결 키·시세·잔고·시작 확인은 계획에 저장하지 않습니다.')
        store = PlanStore(journal, mode=mode)
        try:
            plans = store.list(client)
        except Exception:
            st.error('저장 계획 목록을 읽지 못했습니다. 기존 계획을 덮어쓰지 않습니다.')
            return
        if not plans:
            st.session_state.pop('_paper_plan_preview', None)
            st.caption('아직 저장한 계획이 없습니다. 아래 조건과 하루 한도를 입력한 뒤 계획을 저장하세요.')
            return
        by_id = {r['id']:r for r in plans}
        selected = st.selectbox('불러올 계획', list(by_id), index=None,
            format_func=lambda key: by_id[key]['name'], key='paper_plan_select')
        if selected not in by_id:
            st.session_state.pop('_paper_plan_preview', None)
            return
        row = by_id[selected]
        st.caption('저장 시각(UTC): '+row['created'])
        st.caption('불러오면 작성 중인 조건을 교체합니다. 저장한 시세·잔고는 없으며 시작 전 다시 조회합니다.')
        previous = st.session_state.pop('_paper_plan_preview', None)
        payload, binding = None, None
        try:
            payload = store.load(client, selected, row['revision'])
            _preview(payload, mode=mode)
            binding = (client.credentials.identity, id(client), mode, selected, row['revision'], digest(payload))
            st.session_state['_paper_plan_preview'] = binding
        except Exception:
            payload = None
            st.error('계획 미리보기를 확인하지 못했습니다. 목록과 저장 상태를 확인하세요.')
        a, b = st.columns(2)
        if a.button('불러오기 · 작성 중 조건 교체', key='paper_plan_load', disabled=payload is None):
            clear_editor_confirmation()
            try:
                if binding is None or previous != binding:
                    raise ValueError('preview changed')
                payload = store.load(client, selected, row['revision'])
                if digest(payload) != binding[-1]:
                    raise ValueError('plan changed after preview')
                rules, budgets, minutes = editor_values(payload, mode=mode)
                for key in list(st.session_state):
                    if key.startswith('paper_daily_'):
                        st.session_state.pop(key, None)
                st.session_state['_paper_auto_draft'] = rules
                for currency, cap in budgets.items():
                    for field, value in cap.items():
                        st.session_state['paper_daily_'+field+'_'+currency] = value
                st.session_state['paper_minutes'] = minutes
                st.session_state['_paper_loaded_plan'] = row['name']
                st.session_state['_paper_plan_reference'] = dict(id=selected, revision=row['revision'], digest=digest(payload))
                st.session_state['_paper_plan_notice'] = '계획을 불러왔습니다. 조건·예산을 확인하고 전체 조건 점검을 다시 실행하세요.'
                st.rerun()
            except Exception:
                st.error('계획을 불러오지 못했습니다. 계획이 바뀌었을 수 있으니 최신 미리보기와 저장 상태를 다시 확인하세요.')
        if b.button('목록에서 보관', key='paper_plan_archive'):
            try:
                store.archive(client, selected, row['revision'])
                st.session_state['_paper_plan_notice'] = '계획을 목록에서 보관했습니다. 작성 중 조건과 실행 기록은 유지됩니다.'
                st.rerun()
            except Exception:
                st.error('계획을 보관하지 못했습니다. 목록을 다시 확인하세요.')
        st.caption('보관하면 목록에서 숨기며 원본 기록은 이 PC에 유지합니다.')
    if st.session_state.get('_paper_loaded_plan'):
        st.text('불러온 계획: '+st.session_state['_paper_loaded_plan'])
