"""Local, account-scoped order review pages. No broker calls or state changes."""
from datetime import datetime,timezone
import hashlib,json,math,time
from connectors.kis_broker import BrokerError
from engine.broker_execution import ACTIVE

PAGE_SIZE=100

def _unfinished(now):
    return "(status IN ("+','.join('?' for _ in ACTIVE)+") OR (status='PREPARED' AND expires>?))",(*ACTIVE,now)

def _counts(db,account,now):
    clause,params=_unfinished(now)
    return dict(all=db.execute('SELECT COUNT(*) FROM orders WHERE account=?',(account,)).fetchone()[0],
        active=db.execute('SELECT COUNT(*) FROM orders WHERE account=? AND '+clause,(account,*params)).fetchone()[0])

def order_counts(journal,account):
    with journal.transaction() as db:return _counts(db,account,time.time())

def order_page(journal,account,*,scope='ACTIVE',cursor=None):
    if scope not in ('ACTIVE','ALL'):raise BrokerError('주문 기록 범위를 확인하세요.')
    context=dict(account=account,scope=scope,journal=hashlib.sha256(str(journal.path.resolve()).encode()).hexdigest())
    if cursor is not None:
        if (not isinstance(cursor,dict) or set(cursor)!=set(context)|{'created','id'}
                or any(cursor.get(k)!=v for k,v in context.items())
                or type(cursor['created']) not in (float,int) or not math.isfinite(cursor['created'])
                or not isinstance(cursor['id'],str) or not 1<=len(cursor['id'])<=128):
            raise BrokerError('기록 범위가 현재 연결과 다릅니다. 처음부터 다시 읽으세요.')
    now=time.time();clause,params=_unfinished(now)
    where='account=?';values=(account,)
    if scope=='ACTIVE':where+=' AND '+clause;values+=params
    if cursor is not None:
        where+=' AND (created<? OR (created=? AND id<?))'
        values+=(cursor['created'],cursor['created'],cursor['id'])
    with journal.transaction() as db:
        counts=_counts(db,account,now)
        raw=[dict(r) for r in db.execute('SELECT * FROM orders WHERE '+where+' ORDER BY created DESC,id DESC LIMIT ? ',(*values,PAGE_SIZE+1))]
        records=raw[:PAGE_SIZE];remaining=0
        if len(raw)>PAGE_SIZE:
            tail=records[-1]
            remaining=db.execute('SELECT COUNT(*) FROM orders WHERE '+where+' AND (created<? OR (created=? AND id<?))',(*values,tail['created'],tail['created'],tail['id'])).fetchone()[0]
    for row in records:
        try:
            row['payload']=json.loads(row['payload']);row['result']=json.loads(row['result'])
            if not isinstance(row['payload'],dict) or not isinstance(row['result'],dict):raise ValueError()
        except (ValueError,TypeError):raise BrokerError('주문 기록을 읽지 못했습니다. 기록을 보존하고 운영 점검을 확인하세요.') from None
    next_cursor=dict(context,created=records[-1]['created'],id=records[-1]['id']) if remaining else None
    return dict(records=records,counts=counts,scope=scope,remaining=remaining,next_cursor=next_cursor,
        checked_at=datetime.fromtimestamp(now,timezone.utc).isoformat())
