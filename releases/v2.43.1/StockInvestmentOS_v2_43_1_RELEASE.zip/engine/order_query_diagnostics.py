"""Source-owned reconciliation diagnostics. Never classify arbitrary broker text."""
from connectors.kis_broker import BrokerError

CHECKS={
 'CONNECTION_CHANGED':('조회 중 연결 계좌 또는 투자 환경이 변경되었습니다. 기존 주문 기록을 유지합니다','조회 중 계좌·투자 환경 변경','현재 연결 계좌·투자 환경을 확인하고 주문 기록을 처음부터 다시 읽으세요.'),
 'ORDER_NUMBER_MISSING':('접수번호가 없는 미확인 주문입니다. 한국투자증권 앱에서 체결·미체결을 직접 확인하세요. 자동 재전송하지 않습니다','접수번호 확인 불가','증권사 앱의 접수·미체결·체결 내역을 직접 확인하세요. 접수 여부를 추정하지 마세요.'),
 'ORDER_MATCH_AMBIGUOUS':('주문번호에 대응하는 단일 기록을 확인하지 못했습니다. 기존 상태를 유지합니다','대응 주문 기록을 하나로 확인하지 못함','증권사 앱의 주문번호·종목·매수/매도 구분을 기존 주문과 대조하세요.'),
 'ORDER_PRICE_MISMATCH':('주문 가격과 증권사 기록이 일치하지 않습니다','주문 가격 불일치','증권사 앱의 주문번호와 지정가를 기존 주문과 대조하세요. 새 주문으로 대체하지 마세요.'),
 'ORDER_DATE_MISMATCH':('주문 날짜와 증권사 기록이 일치하지 않습니다','주문 날짜 불일치','증권사 앱의 주문번호·접수 날짜와 기존 주문을 대조하세요.'),
 'ORDER_TIME_MISMATCH':('주문 시각과 증권사 기록이 일치하지 않습니다','주문 접수 시각 불일치','증권사 앱의 주문번호·접수 시각과 기존 주문을 대조하세요.'),
 'ORDER_EXCHANGE_MISMATCH':('거래소가 일치하지 않습니다','미국 주문 거래소 불일치','증권사 앱의 주문 거래소와 기존 주문 거래소를 대조하세요.'),
 'ORDER_QUANTITY_MISMATCH':('주문 수량과 체결 기록이 일치하지 않습니다','주문·체결 수량 불일치','증권사 앱의 주문 수량·체결 수량을 기존 주문과 대조하세요.'),
 'OLDER_FILL_RECORD':('이전보다 오래된 체결 기록입니다. 기존 상태를 유지합니다','이전보다 체결 수량이 적은 기록','이전 근거를 유지합니다. 증권사 최신 체결 내역을 직접 확인한 뒤 다시 조회하세요.'),
 'REMAINING_QUANTITY_CONFLICT':('체결·잔여 수량을 검증하지 못했습니다','체결·잔여 수량 합계 불일치','증권사 앱의 주문 수량·체결·잔여 수량을 함께 확인하세요.'),
 'TERMINAL_STATE_UNCLEAR':('완료 상태가 불명확합니다. 증권사에서 확인하세요','주문 완료 상태 확인 불가','증권사 앱에서 미체결·취소·거절·체결 상태를 확인하세요. 완료로 추정하지 마세요.'),
 'TERMINAL_RECORD_MISMATCH':('완료 주문의 수량·상태와 재조회 결과가 다릅니다. 기존 기록을 유지합니다','기존 완료 주문과 재조회 수량·상태 불일치','기존 완료 기록을 유지합니다. 증권사 앱과 기존 완료 수량·상태를 대조하세요. 자동 재개하지 마세요.'),
}
UNKNOWN=dict(code='UNCLASSIFIED',message='원인을 확정할 수 없는 조회 실패',next_action='연결·현재 계좌와 투자 환경을 확인한 뒤 다시 조회하거나 증권사 앱에서 주문·체결 내역을 확인하세요.')

class EvidenceCheckError(BrokerError):
    def __init__(self,code):
        if code not in CHECKS:raise ValueError('Unsupported local evidence diagnostic code')
        self.code=code
        super().__init__(CHECKS[code][0])


def diagnostic(exc):
    if type(exc) is EvidenceCheckError and type(exc.code) is str and exc.code in CHECKS:
        _,message,action=CHECKS[exc.code]
        return dict(code=exc.code,message=message,next_action=action)
    # Deliberately never call str(exc) or consume arbitrary exception attributes.
    return dict(UNKNOWN)
