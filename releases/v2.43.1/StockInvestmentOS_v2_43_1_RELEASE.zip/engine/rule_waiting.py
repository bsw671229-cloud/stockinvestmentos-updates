"""Explain a local snapshot, without quotes, order requests or state changes."""
from connectors.kis_broker import BrokerError, number
from engine.paper_automation import matches


def explain(item, items, *, run_state, run_valid, dependency, market_open):
    def result(code,message):return dict(code=code,message=message)
    state=item['state']
    if state!='WAITING':
        if state=='PENDING':
            if run_state!='ARMED' or not run_valid:
                return result('ORDER_PENDING_REVIEW','자동 확인이 진행되지 않는 상태 · 주문·체결 관리에서 직접 확인하세요. 접수된 주문은 자동 취소되지 않습니다.')
            return result('ORDER_PENDING','접수·체결 결과 확인 중')
        if state in ('CLAIMED','UNKNOWN'):return result('ATTEMPT_REVIEW','이전 주문 시도 결과 확인 필요')
        if state=='SKIPPED':return result('PARENT_CANCELLED','선행 매수 취소로 실행 제외')
        if state=='ALTERNATIVE_SKIPPED':return result('OTHER_EXIT_SELECTED','다른 연결 매도 선택으로 실행 제외')
        return result('FINISHED','현재 주문 상태 확인 · 자동 재시도 없음')
    if run_state!='ARMED':return result('RUN_INACTIVE','실행 중이 아님 · 자동 재개 없음')
    if not run_valid:return result('RUN_REVIEW','실행 시간·연결·차단 상태 확인 필요')
    if any(r['state'] in ('CLAIMED','UNKNOWN') for r in items):
        return result('OTHER_ATTEMPT_REVIEW','이전 주문 시도 확인 우선 · 새 주문 대기')
    if any(r['state']=='PENDING' for r in items):
        return result('OTHER_ORDER_PENDING','기존 주문 접수·체결 확인 우선 · 새 주문 대기')
    if dependency=='WAIT':return result('PARENT_WAIT','선행 매수 전량 체결 대기')
    if dependency=='SKIP':return result('PARENT_CANCEL_PENDING','선행 매수 취소 확인 · 실행 제외 처리 대기')
    if dependency!='READY':return result('DEPENDENCY_REVIEW','연결 매수·체결 기록 확인 필요')
    if market_open is False:return result('MARKET_CLOSED','등록된 정규 거래시간 밖 · 시간 대기')
    if market_open is not True:return result('CALENDAR_REVIEW','등록된 거래시간 확인 필요')
    if not item['price']:return result('QUOTE_NOT_RECORDED','가격 기록 없음 · 조건 조회 대기')
    try:
        hit=matches(item['rule'],number(item['price'],positive=True))
    except (BrokerError,ValueError,TypeError,KeyError):
        return result('PRICE_REVIEW','최근 기록 가격 확인 필요')
    if hit:return result('RECORDED_MATCH','최근 기록상 가격 조건 충족 · 추가 점검 대기')
    return result('RECORDED_NO_MATCH','최근 기록상 가격 조건 미충족 · 다음 조회 대기')
