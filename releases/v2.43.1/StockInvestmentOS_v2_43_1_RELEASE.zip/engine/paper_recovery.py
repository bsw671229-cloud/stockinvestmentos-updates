"""Stopped PAPER run review. No send, cancel, unhalt, or resume operations."""
import json
import hashlib
import time
from datetime import datetime, timezone

from connectors.kis_broker import BrokerError
from engine.broker_execution import ACTIVE, TERMINAL, reconcile_order
from engine.broker_fills import fill_view, fill_totals
from engine import paper_automation as pa
from engine.run_diagnostics import diagnose

UNRESOLVED = ('CLAIMED','PENDING','UNKNOWN')


def _attempt_summary(db, account, mode):
    """Read current order evidence without changing an attempt or inferring a fill."""
    recorded = synced = 0
    rows = db.execute("SELECT a.order_id,o.status,o.payload FROM paper_attempts a LEFT JOIN orders o ON o.id=a.order_id AND o.account=a.account WHERE a.account=? AND a.state IN ('CLAIMED','PENDING','UNKNOWN')", (account,))
    for row in rows:
        recorded += 1
        if row['status'] not in TERMINAL:
            continue
        try:
            payload = json.loads(row['payload'])
            matches = isinstance(payload,dict) and payload.get('mode') == mode
        except (ValueError,TypeError):
            matches = False
        if matches:
            synced += 1
    return dict(recorded_unresolved=recorded, order_check_required=recorded-synced,
                result_sync_pending=synced)


def history(automation, client):
    automation._check_client(client)
    account = client.credentials.identity
    now = time.time()
    with automation.journal.transaction() as db:
        runs = db.execute('SELECT * FROM paper_runs WHERE account=? ORDER BY rowid DESC LIMIT 10', (account,)).fetchall()
        attempt_summary = _attempt_summary(db,account,automation.mode)
        unresolved = attempt_summary['recorded_unresolved']
        halted = bool(db.execute('SELECT 1 FROM controls WHERE account=? AND halted=1', (account,)).fetchone())
        output = []
        for run in runs:
            effective = run['state']
            diagnostics = diagnose(dict(run), now=now, process=pa.PROCESS,
                                   day=pa._day(), halted=halted, max_gap=pa.MAX_GAP)
            if effective == 'ARMED' and any(d['basis'] == 'CURRENT' for d in diagnostics):
                effective = 'REVIEW_REQUIRED'
            rows = []
            for row in db.execute('SELECT * FROM paper_rules WHERE run_id=? ORDER BY idx', (run['id'],)):
                rule = json.loads(row['payload'])
                order = rule['order']
                record = db.execute('SELECT status,result FROM orders WHERE id=? AND account=?', (row['order_id'],account)).fetchone()
                parent = rule.get('after_buy')
                choice = db.execute('SELECT selected_idx FROM paper_exit_choices WHERE run_id=? AND parent_idx=?', (run['id'],parent)).fetchone() if parent is not None else None
                rows.append(dict(index=row['idx']+1, market=order['market'], symbol=order['symbol'],
                    after_buy_index=parent+1 if parent is not None else None,
                    selected_exit_index=choice['selected_idx']+1 if choice else None,
                    side=order['side'], quantity=order['quantity'], limit_price=order['limit_price'],
                    currency=order['currency'], state=record['status'] if record else row['state'],
                    order_reference=row['order_id'],
                    fill_details=fill_view(order,json.loads(record['result']) if record else {})))
            output.append(dict(run_reference=run['id'], state=effective,
                recorded_state=run['state'], diagnostics=diagnostics,
                plan_origin=json.loads(run['config']).get('plan_origin'),
                expires=datetime.fromtimestamp(run['expires'],timezone.utc).isoformat(), rules=rows))
    automation._check_client(client, account)
    return dict(schema_version=2, generated_at=datetime.fromtimestamp(now,timezone.utc).isoformat(),
        mode=automation.mode, account_label=client.credentials.masked_account, halted=halted,
        unresolved_attempts=unresolved, attempt_summary=attempt_summary, coverage='최근 10회 실행 · 미확인 수는 전체 기록 기준', runs=output,
        fill_totals=fill_totals([r for run in output for r in run['rules']]),
        fill_coverage='최근 10회에 연결된 주문의 누적 체결 금액 · 비용·세금·환전 제외 · 실현손익 아님')


class _HistoryClient:
    def __init__(self, client, account, mode='PAPER'):
        self.client, self.account, self.mode = client, account, mode

    @property
    def credentials(self):
        from engine.paper_rehearsal import check_mode
        check_mode(self.client, self.account, mode=self.mode)
        return self.client.credentials

    @property
    def base_url(self):
        self.credentials  # Validate the bound connection before exposing its host.
        return self.client.base_url

    def order_history(self, order, *dates):
        from engine.paper_rehearsal import check_mode
        check_mode(self.client, self.account, mode=self.mode)
        result = self.client.order_history(order, *dates)
        from engine.paper_rehearsal import check_mode
        check_mode(self.client, self.account, mode=self.mode)
        return result


def review_stopped(automation, client, *, confirmed=False, cursor=None):
    if confirmed is not True:
        raise BrokerError('신규 주문 중지와 이전 결과 확인을 선택하세요.')
    automation._check_client(client)
    account = client.credentials.identity
    journal = automation.journal
    context = dict(account=account, mode=automation.mode,
                   journal=hashlib.sha256(str(journal.path.resolve()).encode()).hexdigest())
    after, upper = 0, None
    if cursor is not None:
        if (not isinstance(cursor, dict) or any(cursor.get(k) != v for k,v in context.items())
                or type(cursor.get('after')) is not int or type(cursor.get('upper')) is not int
                or not 0 <= cursor['after'] <= cursor['upper']):
            raise BrokerError('검토 범위가 현재 연결과 다릅니다. 처음부터 다시 확인하세요.')
        after, upper = cursor['after'], cursor['upper']
    automation.stop(account, '이전 실행 결과 확인을 위해 신규 주문을 중지했습니다.')
    checked = closed = failed = synced = 0
    # Run invalidation precedes all local closures and broker reads. Existing in-flight
    # requests can still complete; SENDING/UNKNOWN without a receipt are never guessed.
    with journal.transaction() as db:
        if upper is None:
            upper = db.execute("SELECT COALESCE(MAX(rowid),0) FROM paper_attempts WHERE account=?",(account,)).fetchone()[0]
        attempts = [dict(r) for r in db.execute("SELECT rowid AS review_rowid,* FROM paper_attempts WHERE account=? AND rowid>? AND rowid<=? AND state IN ('CLAIMED','PENDING','UNKNOWN') ORDER BY rowid LIMIT 20", (account,after,upper))]
    reader = _HistoryClient(client, account, automation.mode)
    for attempt in attempts:
        automation._check_client(client, account)
        run_id, idx, order_id = attempt['run_id'], attempt['idx'], attempt['order_id']
        if not order_id:
            with journal.transaction() as db:
                protocol = db.execute("SELECT 1 FROM paper_prepare_protocol WHERE run_id=? AND idx=? AND protocol='ATOMIC_V1'", (run_id,idx)).fetchone()
                # Older orphan reservations have no proof of atomic linkage. Preserve
                # their unresolved state even when no matching order can be found.
                if protocol:
                    changed = db.execute("UPDATE paper_attempts SET state='FAILED_PRECHECK' WHERE run_id=? AND idx=? AND account=? AND state='CLAIMED' AND order_id=''", (run_id,idx,account)).rowcount
                    if changed:
                        db.execute("UPDATE paper_rules SET state='FAILED_PRECHECK' WHERE run_id=? AND idx=? AND order_id=''", (run_id,idx))
                        journal._event(db,None,automation.mode+'_PRE_SEND_CLOSED',run_id+':'+str(idx))
                        closed += 1
            continue
        try:
            record = journal.get(order_id,account)
            if record['payload']['mode'] != automation.mode:
                raise BrokerError('현재 연결 환경의 주문 기록이 아닙니다.')
            if record['status'] == 'PREPARED':
                journal.update(order_id,account,'FAILED_PRECHECK',{},expected=record)
                record = journal.get(order_id,account)
                if record['status'] == 'FAILED_PRECHECK': closed += 1
            if record['status'] in ACTIVE:
                record = reconcile_order(reader,journal,order_id)
                checked += 1
            with journal.transaction() as db:
                # Re-read under the write lock so a concurrent fill is never lost.
                current = db.execute('SELECT status FROM orders WHERE id=? AND account=?', (order_id,account)).fetchone()
                state = current['status'] if current['status'] in TERMINAL else ('UNKNOWN' if current['status'] in ('SENDING','UNKNOWN','CANCEL_UNKNOWN') else 'PENDING')
                for table in ('paper_attempts','paper_rules'):
                    db.execute(f'UPDATE {table} SET state=? WHERE run_id=? AND idx=? AND order_id=?', (state,run_id,idx,order_id))
                if state in TERMINAL:
                    synced += 1
        except Exception:
            failed += 1  # Never expose raw provider exceptions or infer non-receipt.
    automation._check_client(client,account)
    result = history(automation,client)
    last = attempts[-1]['review_rowid'] if attempts else upper
    with journal.transaction() as db:
        remaining = db.execute("SELECT COUNT(*) FROM paper_attempts WHERE account=? AND rowid>? AND rowid<=? AND state IN ('CLAIMED','PENDING','UNKNOWN')",(account,last,upper)).fetchone()[0]
        newer = db.execute("SELECT COUNT(*) FROM paper_attempts WHERE account=? AND rowid>? AND state IN ('CLAIMED','PENDING','UNKNOWN')",(account,upper)).fetchone()[0]
    automation._check_client(client,account)
    result['review'] = dict(result_synced=synced, history_checked=checked, pre_send_closed=closed, check_required=failed,
        examined=len(attempts), remaining_in_scope=remaining, newer_unresolved=newer,
        next_cursor=dict(context,after=last,upper=upper) if remaining else None,
        scope_complete=not remaining, unresolved_total=result['unresolved_attempts'])
    return result
