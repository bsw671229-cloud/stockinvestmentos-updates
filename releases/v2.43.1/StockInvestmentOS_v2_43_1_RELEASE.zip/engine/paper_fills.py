"""Explicit evidence-only refresh for terminal orders in the bound account/mode."""
import hashlib
from connectors.kis_broker import BrokerError
from engine.broker_execution import reconcile_order
from engine.broker_fills import fill_view
from engine.paper_recovery import _HistoryClient, history


def refresh_fills(automation,client,*,confirmed=False,cursor=None):
    if confirmed is not True: raise BrokerError('완료 주문 체결 금액 조회를 선택하세요.')
    automation._check_client(client)
    account=client.credentials.identity
    before=history(automation,client)
    context=hashlib.sha256((account+'|'+automation.mode+'|'+str(automation.journal.path.resolve())).encode()).hexdigest()
    if cursor is None:
        all_references=list(dict.fromkeys(r['order_reference'] for run in before['runs'] for r in run['rules']
            if r['order_reference'] and r['state'] in ('FILLED','CANCELLED','REJECTED')))
        offset=0
    else:
        if (not isinstance(cursor,dict) or cursor.get('context')!=context
                or not isinstance(cursor.get('references'),list)
                or not 1<=len(cursor['references'])<=100
                or any(not isinstance(r,str) or not r for r in cursor['references'])
                or len(set(cursor['references']))!=len(cursor['references'])
                or type(cursor.get('offset')) is not int
                or not 0<cursor['offset']<len(cursor['references'])):
            raise BrokerError('체결 조회 범위가 현재 연결과 다릅니다. 처음부터 다시 조회하세요.')
        all_references=list(cursor['references']);offset=cursor['offset']
    references=all_references[offset:offset+20]
    checked=failed=skipped=verified=uncertain=0
    items=[]
    reader=_HistoryClient(client,account,automation.mode)
    for reference in references:
        automation._check_client(client,account)
        try:
            record=automation.journal.get(reference,account)
            if record['payload']['mode']!=automation.mode: raise BrokerError('현재 연결 환경의 주문 기록이 아닙니다.')
            if record['status'] not in ('FILLED','CANCELLED','REJECTED'):
                skipped+=1; items.append(dict(reference=reference,outcome='STATUS_CHANGED')); continue
            if not record['result'].get('order_no') or 'filled_quantity' not in record['result']:
                skipped+=1; items.append(dict(reference=reference,outcome='EVIDENCE_MISSING')); continue
            updated=reconcile_order(reader,automation.journal,reference,refresh_terminal=True)
            checked+=1
            detail=fill_view(updated['payload']['order'],updated['result'])
            if detail['status'] in ('VERIFIED','ZERO_FILL'):
                verified+=1; items.append(dict(reference=reference,outcome='VERIFIED'))
            else:
                uncertain+=1; items.append(dict(reference=reference,outcome='AMOUNT_CHECK_REQUIRED'))
        except Exception:
            failed+=1  # Keep prior evidence and never export raw provider messages.
            items.append(dict(reference=reference,outcome='QUERY_FAILED'))
    automation._check_client(client,account)
    result=history(automation,client)
    end=offset+len(references)
    remaining=len(all_references)-end
    next_cursor=dict(context=context,references=all_references,offset=end) if remaining else None
    result['fill_refresh']=dict(items=items,checked_at=result['generated_at'],examined=len(references),total_in_scope=len(all_references),
        remaining_in_scope=remaining,next_cursor=next_cursor,scope_complete=not remaining,checked=checked,failed=failed,skipped=skipped,limit=20,
        amount_verified=verified,amount_check_required=uncertain,
        order_transmission='NOT_PERFORMED',scope='최근 10회 실행의 완료 주문 중 최대 20건')
    return result
