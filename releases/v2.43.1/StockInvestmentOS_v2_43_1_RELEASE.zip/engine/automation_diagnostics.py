"""Fixed source-owned read-error guidance. Never inspect arbitrary error text."""
from connectors.kis_broker import BrokerHttpError,READ_ROUTES

PHASES=frozenset({'실행 시간·연결·신규 주문 차단 확인','접수·체결 결과 확인',
    '하루 예산·이전 주문 상태 확인','가격 조건·잔고 점검 및 주문 결과 확인','시세·가격 조건 확인'})
READ_OPERATIONS=frozenset(value[0] for value in READ_ROUTES.values())|{'인증'}
UNKNOWN='원인을 확정할 수 없는 중단입니다. 연결 상태와 이전 주문 결과를 직접 확인하세요.'
GUIDANCE={
    401:'인증 확인이 필요한 응답입니다. 연결 환경과 인증 상태를 직접 확인하고 조회부터 점검하세요.',
    403:'접근이 거절된 응답입니다. 요청 권한과 연결 환경을 직접 확인하세요.',
    429:'요청 빈도 제한 응답입니다. 반복 요청을 멈추고 증권사 안내를 확인한 뒤 직접 다시 조회하세요.',
    500:'서버 오류 응답입니다. 증권사 상태를 확인한 뒤 조회부터 점검하세요. 회복 시점은 확정할 수 없습니다.',
    502:'서버 연결 오류 응답입니다. 증권사 상태를 확인한 뒤 조회부터 점검하세요. 회복 시점은 확정할 수 없습니다.',
    503:'서버가 요청을 처리하지 못한 응답입니다. 증권사 상태를 확인한 뒤 조회부터 점검하세요. 회복 시점은 확정할 수 없습니다.',
    504:'서버 응답 지연 오류입니다. 증권사 상태를 확인한 뒤 조회부터 점검하세요. 회복 시점은 확정할 수 없습니다.',
}

def stop_note(phase,exc):
    phase=phase if type(phase) is str and phase in PHASES else '실행 상태 확인'
    detail=UNKNOWN
    if type(exc) is BrokerHttpError:
        status=getattr(exc,'status',None);operation=getattr(exc,'operation',None);attempts=getattr(exc,'attempts',None)
        if (type(status) is int and status in GUIDANCE
            and type(operation) is str and len(operation)<=32 and operation in READ_OPERATIONS
            and type(attempts) is int and attempts in (1,2)):
            detail=GUIDANCE[status]
    return ('자동매매 중지 · '+phase+'이 필요합니다. '+detail+
            ' 신규 주문 차단을 유지합니다. 접수 여부·체결 결과는 주문·체결 관리에서 확인하세요. 자동 재전송·자동 재개·자동 취소는 하지 않습니다.')
