"""Contextual display labels; canonical plan values are never modified."""
from ui_decision_status import status_label, scenario_signal_label
LABELS = {'HOLD / MONITOR':'보유 / 관찰','TRIM REVIEW':'비중 축소 검토','EXIT REVIEW':'청산 검토','EXISTING FACTOR RISK REVIEW · NO FORCED SALE':'기존 투자 요인 위험 검토 · 강제 매도 없음','NO APPROVED REFRESH':'검토 승인된 갱신 없음'}
def planner_status(value):
    if not isinstance(value,str):return value
    return LABELS.get(value,scenario_signal_label(status_label(value)))
