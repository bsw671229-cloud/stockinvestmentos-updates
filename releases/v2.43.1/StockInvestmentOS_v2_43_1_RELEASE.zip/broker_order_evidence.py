"""Selected-order evidence and explicit inquiry feedback, without execution authority."""
from datetime import datetime, timezone
import streamlit as st
from engine.broker_execution import ACTIVE
from engine.broker_fills import fill_view
from engine.order_query_diagnostics import diagnostic
import json,re

NOTICE='_kis_order_query_notice'
TERMINAL=('FILLED','CANCELLED','REJECTED')


def _context(client,journal):
    return (id(client),client.credentials.identity,client.credentials.mode,str(journal.path.resolve()))


def _same_connection(client,journal,context):
    return (_context(client,journal)==context and
            st.session_state.get('_kis_client',client) is client and
            st.session_state.get('kis_mode',context[2])==context[2])


def _stamp(value):
    try:
        stamp=datetime.fromisoformat(str(value))
        if stamp.tzinfo is None:return None
        return stamp.astimezone(timezone.utc).isoformat()
    except (ValueError,TypeError,OverflowError):return None


def _eligibility(record):
    if record['status'] not in (*ACTIVE,*TERMINAL):
        return False,'이 기록은 증권사 체결 조회 대상이 아닙니다. 전송 전 준비·만료·사전 점검 실패 기록은 접수된 주문으로 간주하지 않습니다.'
    if not record['result'].get('order_no'):
        return False,'접수번호가 없어 이 화면에서 조회하지 않습니다. 증권사 앱의 주문·체결 내역을 직접 확인하세요. 자동 재전송하거나 차단을 해제하지 않습니다.'
    return True,''


def query_selected(client,journal,reference,reconcile):
    context=_context(client,journal)
    notice=dict(context=context,reference=reference,status='FAILED',attempted_at=datetime.now(timezone.utc).isoformat())
    st.session_state.pop(NOTICE,None)
    try:
        if not _same_connection(client,journal,context):raise ValueError('connection changed')
        record=journal.get(reference,context[1])
        if record['payload']['mode']!=context[2]:raise ValueError('environment mismatch')
        eligible,reason=_eligibility(record)
        if not eligible:
            notice.update(status='SKIPPED',reason=reason)
        else:
            before=_stamp(record['result'].get('last_checked_at'))
            terminal=record['status'] in TERMINAL
            result=reconcile(client,journal,reference,**({'refresh_terminal':True} if terminal else {}))
            if not _same_connection(client,journal,context):raise ValueError('connection changed')
            checked=_stamp(result['result'].get('last_checked_at'))
            # A normal engine early return or a concurrent transition is not a fresh broker check.
            if checked and checked!=before:
                notice.update(status='PASS',checked_at=checked)
            else:
                notice.update(status='SKIPPED',reason='이번 요청에서 새로운 증권사 조회 근거가 저장되지 않았습니다. 현재 기록을 다시 확인하세요.')
    except Exception as exc:
        detail=diagnostic(exc)
        notice['diagnostic']=detail
        notice.update(status='FAILED',reason='이번 체결 조회를 확인하지 못했습니다. 아래 저장된 자료는 이전 조회 근거입니다. '+detail['next_action']+' 자동 재전송·취소·차단 해제는 하지 않습니다.')
    st.session_state[NOTICE]=notice


def render_query_notice(client,journal):
    notice=st.session_state.pop(NOTICE,None)
    if not notice or notice['context']!=_context(client,journal):return
    reference=notice['reference'][-6:]
    if notice['status']=='PASS':
        st.success('체결 조회 완료 · 기록 '+reference+' · 증권사 조회 시각 (UTC): '+notice['checked_at'])
        st.caption('조회 결과에 따라 해당 주문이 미완료 범위에서 사라질 수 있습니다. 전체 주문 기록에서 확인하세요.')
    elif notice['status']=='SKIPPED':st.info('증권사 조회 안 함 · 기록 '+reference+' · '+notice['reason'])
    else:st.error('체결 조회 확인 실패 · 기록 '+reference+' · '+notice['reason'])
    st.caption('이번 요청 확인 시각 (UTC): '+notice['attempted_at'])
    if notice['status']=='FAILED':
        detail=notice['diagnostic']
        st.caption('확인된 검사 결과: '+detail['message'])
        st.caption('다음 확인: '+detail['next_action'])
    st.download_button('이번 조회 진단 저장',json.dumps(diagnostic_report(notice),ensure_ascii=False,indent=2),
        file_name='ORDER_QUERY_DIAGNOSTIC.json',mime='application/json',key='kis_query_diagnostic_download',on_click='ignore')


def render_order_evidence(client,journal,record,reconcile,status_label):
    order=record['payload']['order'];receipt=record['result'];detail=fill_view(order,receipt)
    st.markdown('**선택 주문의 저장된 체결 근거**')
    st.write('기록 '+record['id'][-6:]+' · '+order['symbol']+' · '+status_label)
    st.caption('아래 자료는 저장된 마지막 조회 근거입니다. 화면을 여는 것만으로 증권사에 새로 조회하지 않습니다.')
    st.table([{'체결 수량':detail['quantity'] if detail['quantity'] is not None else '미확인',
        '통화':detail['currency'],'누적 체결 금액':detail['gross_amount'] if detail['gross_amount'] is not None else '미확인',
        '평균 체결가':detail['average_price'] if detail['average_price'] is not None else '미확인'}])
    stamp=_stamp(receipt.get('last_checked_at'))
    st.caption('마지막 증권사 주문·체결 조회 시각 (UTC): '+(stamp or '확인된 시각 없음'))
    if detail['checked_at']:st.caption('체결 금액 근거 확인 시각 (UTC): '+_stamp(detail['checked_at']))
    if detail['status'] not in ('VERIFIED','ZERO_FILL'):
        st.warning('체결 금액을 확인하지 못했습니다. 미확인을 0으로 계산하지 않습니다. 주문 상태와 체결 금액의 확인 여부는 별개입니다.')
    st.caption('체결 금액은 수수료·세금 차감 전 누적 금액이며 실현 손익이 아닙니다. 취소 확인 상태에서도 이미 체결된 수량과 금액이 있을 수 있습니다.')
    eligible,reason=_eligibility(record)
    if reason:st.info(reason)
    terminal=record['status'] in TERMINAL
    if terminal:st.caption('완료 주문 재조회는 기존 완료 상태·수량이 일치할 때 체결 근거만 갱신합니다. 주문을 다시 열거나 전송하지 않습니다.')
    st.button('완료 주문의 체결 근거 다시 조회' if terminal else '증권사에서 체결 상태 조회',key='kis_reconcile',disabled=not eligible,
        on_click=query_selected,args=(client,journal,record['id'],reconcile))


def diagnostic_report(notice):
    from engine.order_query_diagnostics import CHECKS,UNKNOWN
    status=notice.get('status') if notice.get('status') in ('PASS','FAILED','SKIPPED') else 'UNCONFIRMED'
    item=notice.get('diagnostic')
    code=item.get('code') if isinstance(item,dict) else None
    if type(code) is str and code in CHECKS:
        _,message,action=CHECKS[code]
    else:
        code=UNKNOWN['code'];message=UNKNOWN['message'];action=UNKNOWN['next_action']
    if status=='PASS':code,message,action='CHECK_SAVED','조회 완료','저장된 증권사 확인 시각과 주문 결과를 확인하세요.'
    if status=='SKIPPED':code,message,action='NO_NEW_CHECK','새로운 조회 근거 없음','주문 기록과 화면 안내를 확인하세요.'
    # Report contains fixed text plus a validated short opaque reference and timestamps only.
    reference=notice.get('reference')
    suffix=reference[-6:] if isinstance(reference,str) and re.fullmatch(r'[a-f0-9]{32}',reference) else None
    return dict(schema_version=1,operation='ORDER_EVIDENCE_QUERY',status=status,reference_suffix=suffix,
        attempted_at=_stamp(notice.get('attempted_at')),broker_checked_at=_stamp(notice.get('checked_at')),
        code=code,message=message,next_action=action)
