from __future__ import annotations
from ui_decision_readable import readable_metric
from ui_planner_status import planner_status
from ui_planner_table import gate_table
from ui_planner_action import action_text, next_text, page_text, blocking_text
if True:
    st.title('통합 실행 계획 / 최종 판단 조건')
    st.caption('시나리오·기준 가정·투자 가설·투자 단계·가격·포트폴리오 적합성·투자 요인 위험·실행 조건·검토 대기 목록을 모아 오늘 가능한 행동과 아직 금지된 행동을 정리합니다.')
    st.info('최종 판단 조건의 정상/실행 검토 표시는 매수 추천이 아닙니다. 이 화면은 기존 원본 조건을 요약하며, 조건을 우회하거나 증권사 주문을 전송하지 않습니다.')
    if watchlist.empty:
        st.warning('관심종목이 비어 있습니다.')
    else:
        ap_names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        handed = str(st.session_state.get('action_planner_company', '') or '').strip()
        ap_default = ap_names.index(handed) if handed in ap_names else 0
        ap_company = st.selectbox('실행 계획 검토 종목', ap_names, index=ap_default, key='action_planner_company_select')
        st.session_state['action_planner_company'] = ap_company
        ap_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
        ap_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
        ap_summary = build_one_page_decision_summary(company=ap_company, watchlist=watchlist, portfolio=portfolio, proof=proof, thesis_plans=ap_plans, kpis=ap_kpis, total_assets=total_assets, loss_budget=loss_budget, single_name_cap=single_cap, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), pilot_fraction=float(settings.get('trade_plan_pilot_fraction', 0.5)), reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), stale_days=int(settings.get('kpi_stale_days', 120)), factor_loadings=factor_loadings)
        ap_scenario_history = load_csv('scenario_refresh_reviews.csv')
        ap_latest_scenario = latest_approved_refresh(ap_scenario_history, ap_company)
        if ap_latest_scenario:
            ap_scenario_recon = reconciliation_status_for_scenario(load_csv('scenario_reconciliation_reviews.csv'), company=ap_company, scenario_row=ap_latest_scenario)
        else:
            ap_scenario_recon = {'status': 'NO APPROVED REFRESH'}
        ap_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
        ap_thesis = build_thesis_monitor(watchlist, ap_states, ap_plans, ap_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
        ap_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
        ap_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
        ap_queue_all = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=ap_plans, scenario_refreshes=ap_scenario_history, scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=ap_kpis, state_df=ap_states, thesis_monitor=ap_thesis, audit_df=ap_audit, reconciliation=ap_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)))
        if ap_queue_all.empty:
            ap_company_queue = pd.DataFrame()
        else:
            ap_subject = ap_queue_all['subject'].fillna('').astype(str).str.strip()
            ap_category = ap_queue_all['category'].fillna('').astype(str).str.strip()
            ap_factor = str(ap_summary.get('factor', '') or '').strip()
            ap_mask = ap_subject.eq(ap_company)
            if ap_factor:
                ap_mask |= ap_subject.eq(ap_factor)
            ap_mask |= ap_category.eq('Reconciliation')
            ap_company_queue = ap_queue_all.loc[ap_mask].copy()
        ap_plan = build_integrated_action_plan(summary=ap_summary, latest_scenario=ap_latest_scenario or None, scenario_reconciliation=ap_scenario_recon, company_queue=ap_company_queue)
        st.subheader('1. 오늘의 최종 행동 조건')
        a1, a2, a3, a4, a5 = st.columns(5)
        readable_metric(a1, '현재 행동', ap_plan['action_ko'])
        readable_metric(a2, '최종 판단 조건', planner_status(ap_plan['final_gate']))
        readable_metric(a3, '신규 위험 조건', planner_status(ap_plan['new_risk_gate']))
        a4.metric('최종 실행 검토 수량', f"{ap_plan['final_executable_shares']:,}주")
        readable_metric(a5, '기존 위험', planner_status(ap_plan['existing_risk_action']))
        if ap_plan['final_gate'] == 'BLOCKED':
            st.error(f"**{ap_plan['action_ko']}** · 신규 위험 확대는 현재 차단되어 있습니다.")
        elif ap_plan['final_gate'] == 'REVIEW':
            st.warning(f"**{ap_plan['action_ko']}** · 원본 조건의 검토 필요 사항을 먼저 해결합니다.")
        else:
            st.success('**실행 검토** · 시스템 조건은 주문계획 검토를 허용하지만 자동매수나 수익보장을 의미하지 않습니다.')
        st.subheader('2. 위험상한 ≠ 실행수량')
        n1, n2, n3, n4 = st.columns(4)
        n1.metric('위험상한 수량', f"{ap_plan['risk_ceiling_shares']:,}주")
        n2.metric('투자 단계·가격 기준 실행 수량', f"{ap_plan['executable_shares']:,}주")
        n3.metric('포트폴리오 최대 추가', f"{ap_plan['portfolio_max_add_shares']:,}주")
        n4.metric('최종 실행 검토 상한', f"{ap_plan['final_executable_shares']:,}주")
        st.caption('최종 실행 검토 상한은 여러 조건 중 더 작은 값으로 제한됩니다. 0주이면 위험상한 수량이 양수여도 현재 주문 가능 수량은 0주입니다.')
        st.subheader('3. 최종 판단 조건표')
        st.dataframe(gate_table(ap_plan['gate_rows']), width='stretch', hide_index=True, alt='최종 판단 조건과 신규 위험 확대 차단 여부')
        st.subheader('4. 오늘 할 수 있는 것 / 하면 안 되는 것')
        c1, c2 = st.columns(2)
        with c1:
            st.markdown('**오늘 할 수 있는 것**')
            for item in ap_plan['allowed_actions']:
                st.write(f'- {action_text(item)}')
        with c2:
            st.markdown('**현재 금지 / 우회 금지**')
            for item in ap_plan['prohibited_actions']:
                st.write(f'- {action_text(item)}')
        st.subheader('5. 왜 막혀 있는가?')
        if ap_plan['blocking_reasons']:
            for reason in ap_plan['blocking_reasons']:
                st.write(f'- {blocking_text(reason, ap_summary, ap_plan)}')
        else:
            st.success('현재 신규 위험 확대를 막는 원본 조건이 없습니다. 그래도 주문 전 실행 점검표를 별도로 확인합니다.')
        st.subheader('6. 시나리오·기준 가정·포트폴리오 현황')
        x1, x2, x3, x4 = st.columns(4)
        readable_metric(x1, '시나리오', planner_status(ap_plan['scenario_status']))
        readable_metric(x2, '시나리오 기준 가정 일치', planner_status(ap_plan['scenario_reconciliation_status']))
        readable_metric(x3, '포트폴리오 적합성', planner_status(ap_plan['portfolio_fit']))
        readable_metric(x4, '투자 요인 위험', planner_status(ap_plan['factor_breach_status']))
        if ap_latest_scenario:
            st.caption(f"최근 검토 승인된 시나리오 기준일: {ap_latest_scenario.get('event_date', '-')} · 하락 시나리오 예상 손실 {pct(ap_latest_scenario.get('modeled_bear_downside', 0.0))}")
        st.subheader('7. 오늘 / 임박한 검토 목록')
        q1, q2, q3 = st.columns(3)
        q1.metric('기한 초과', ap_plan['queue_overdue'])
        q2.metric('오늘 + 즉시', ap_plan['queue_now'])
        q3.metric('향후 7일', ap_plan['queue_next_7_days'])
        if ap_company_queue.empty:
            st.info('이 종목·투자 요인에 연결된 검토 대기 항목이 없습니다.')
        else:
            qshow = ap_company_queue.loc[ap_company_queue['bucket'].isin(['OVERDUE', 'TODAY', 'NOW', 'NEXT 7 DAYS'])].copy()
            if qshow.empty:
                st.info('오늘 또는 7일 이내 검토할 항목이 없습니다. 이후 일정은 검토 대기 목록에서 확인할 수 있습니다.')
            else:
                st.dataframe(qshow[['bucket', 'due_date', 'category', 'subject', 'status', 'issue', 'go_to']], width='stretch', hide_index=True)
        st.subheader('8. 다음 원본 화면')
        st.write(f"**우선 다음 행동:** {next_text(ap_plan['primary_next_action'])}")
        st.button(f"{page_text(ap_plan['primary_next_page'])} 화면 열기", type='primary', on_click=_navigate, args=(ap_plan['primary_next_page'],), key='action_planner_primary_go')
        nav1, nav2, nav3, nav4 = st.columns(4)
        nav1.button('투자 판단 요약', on_click=_navigate, args=('Decision Summary', {'decision_summary_company': ap_company}), key='ap_to_decision')
        nav2.button('검토 대기 목록', on_click=_navigate, args=('Review Queue',), key='ap_to_queue')
        nav3.button('투자 요인 위험 조정', on_click=_navigate, args=('Factor Risk Repair', {'factor_repair_factor': ap_plan.get('factor', '')}), key='ap_to_factor_repair', disabled=not bool(ap_plan.get('factor')))
        nav4.button('시나리오 갱신', on_click=_navigate, args=('Scenario Refresh', {'scenario_refresh_company': ap_company}), key='ap_to_scenario')
        st.subheader('9. 실행 계획 검토 이력')
        ap_note = st.text_input('검토 메모', value='', key=f'action_planner_note::{ap_company}', placeholder='예: 신규 추가 투자 금지 유지, 다음 실적 후 재검토')
        if st.button('현재 실행 계획 검토기록 저장', key=f'save_action_plan::{ap_company}'):
            row = action_plan_review_row(ap_plan, note=ap_note)
            ap_history = load_csv('action_plan_reviews.csv')
            for col in ACTION_PLAN_REVIEW_COLS:
                if col not in ap_history.columns:
                    ap_history[col] = ''
            ap_history = pd.concat([ap_history[ACTION_PLAN_REVIEW_COLS], pd.DataFrame([row])], ignore_index=True)
            verified_save_feedback(ap_history, 'action_plan_reviews.csv', '통합 실행 계획 검토기록을 저장했습니다.', rerun=True)
        ap_history = load_csv('action_plan_reviews.csv')
        if not ap_history.empty and 'company' in ap_history.columns:
            company_history = ap_history.loc[ap_history['company'].fillna('').astype(str).eq(ap_company)].copy()
            if not company_history.empty:
                ap_history_cols = ['timestamp', 'final_gate', 'current_action', 'new_risk_gate', 'existing_risk_action', 'executable_shares', 'portfolio_max_add_shares', 'scenario_reconciliation_status', 'queue_overdue', 'queue_now', 'next_check_date', 'note']
                ap_history_cols = [c for c in ap_history_cols if c in company_history.columns]
                st.dataframe(company_history[ap_history_cols].tail(20), width='stretch', hide_index=True)
        st.caption(f"실행 계획 엔진 {ap_plan['version']} · 좋은 기업 ≠ 좋은 주식 ≠ 좋은 가격. 최종 판단 조건은 투자판단 보조이며 증권사 주문을 전송하지 않습니다.")
