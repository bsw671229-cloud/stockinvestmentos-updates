"""Korean labels for a copy of the planner gate table; canonical data is untouched."""
import pandas as pd
import numpy as np

COLUMNS={'gate':'판단 조건','status':'상태','scope':'적용 범위','detail':'설명','blocks_new_risk':'신규 위험 확대 차단'}
GATES={'System Integration':'시스템 통합 점검','Canonical Assumption':'기준 가정','Scenario Reconciliation':'시나리오 일치 점검','Scenario Signal':'시나리오 신호','Thesis Invalidation':'투자 가설 무효화','Lifecycle':'투자 단계','Add Freeze':'추가 투자 보류','Price / No-Chase':'가격 / 추격 매수 금지','Portfolio Fit':'포트폴리오 적합성','Incremental Factor Risk':'추가 투자 요인 위험','Execution':'실행 조건'}
STATUS={'PASS':'정상','REVIEW':'검토 필요','BLOCKED':'진행 차단','INFO':'참고'}
SCOPE={'SYSTEM':'시스템','SCENARIO':'시나리오','THESIS':'투자 가설','EXECUTION':'실행','PORTFOLIO':'포트폴리오'}

def exact(value, labels):
    return labels.get(value,value) if isinstance(value,str) else value

def gate_table(frame):
    if not isinstance(frame,pd.DataFrame): return frame
    result=frame.copy(deep=True)
    if len(result.columns)==0: return result
    renamed=[COLUMNS.get(c,c) for c in result.columns]
    if not result.columns.is_unique or len(set(renamed))!=len(renamed): return result
    if 'gate' in result.columns:
        known=result['gate'].map(lambda v:isinstance(v,str) and v in GATES)
        # Only known engine rows have status/scope/boolean semantics we can translate.
        for column,labels in (('status',STATUS),('scope',SCOPE),('gate',GATES)):
            if column in result.columns:
                values=result[column].astype(object).tolist()
                result[column]=[exact(v,labels) if k else v for v,k in zip(values,known)]
        if 'blocks_new_risk' in result.columns:
            values=result['blocks_new_risk'].astype(object).tolist()
            result['blocks_new_risk']=[('예' if v else '아니요') if k and isinstance(v,(bool,np.bool_)) else v for v,k in zip(values,known)]
    return result.rename(columns=COLUMNS)
