"""Exact-code display adapter. Never change canonical data."""
import pandas as pd
STATUS = {'PASS':'정상','REVIEW':'검토 필요','BLOCKED':'진행 차단','PENDING':'대기','APPROVED':'검토 승인','WATCH':'관찰','READY':'검토 준비 완료','WITHIN CAP':'상한 이내','AT CAP':'상한 도달','PRE-EXISTING BREACH':'기존 상한 초과','ELIGIBLE':'대상 자격 충족','ELIGIBLE RECIPIENT':'자본 유입 대상 자격 충족','ON':'켜짐','OFF':'꺼짐','OVERDUE':'기한 초과','VALID':'유효','NO PROOF':'검증 근거 없음','PROVISIONAL':'잠정','ADD FREEZE':'추가 투자 보류','TRIM':'비중 축소 검토','EXIT':'청산 검토','EXECUTION REVIEW':'실행 검토 필요'}
STATUS.update({'OBSERVE':'관찰','ELIGIBLE FOR REVIEW':'대상 검토 가능','YES':'예','NO':'아니요','CORE':'핵심 보유','PILOT':'시험 투자','ADD':'추가 투자 검토','HOLD':'보유 검토','REVIEWED':'검토 완료','STRONG':'강함','WEAK':'약함','CONFIRMED':'확인됨','UNCONFIRMED':'미확인','FRESH':'최신','STALE':'오래된 자료','MATCH':'일치','MISMATCH':'불일치','OK':'정상','FAIL':'실패','NO DATE':'날짜 없음','DUE SOON':'기한 임박'})
STAGES={'Price Gate':'가격 조건','Position Sizing':'투자 규모 산정','Execution':'실행 조건','Lifecycle':'투자 단계','Thesis / Proof':'투자 가설 / 검증','Portfolio Fit':'포트폴리오 적합성','Factor Risk Repair':'투자 요인 위험 조정','Capital Migration':'자본 이동'}
def status_label(value):
    # Exact known codes only. Unknown strings, whitespace, IDs and user text stay intact.
    return STATUS.get(value,value) if isinstance(value,str) else value

def flow_display(frame):
    if not isinstance(frame,pd.DataFrame):return frame
    result=frame.copy(deep=True)
    # These two schema-owned columns contain engine tokens. Details may include user factors.
    if '상태' in result.columns:result['상태']=result['상태'].map(status_label)
    if '단계' in result.columns:result['단계']=result['단계'].map(lambda x:STAGES.get(x,x) if isinstance(x,str) else x)
    return result

# Context-specific codes: OPEN must never be relabeled in an order context.
PROOF_STATUS = {'OPEN':'점검 기한 전','CLOSED':'점검 종료','OVERDUE':'기한 초과','DUE SOON':'기한 임박','NO DATE':'날짜 없음','NO PROOF':'검증 근거 없음'}
SCENARIO_SIGNAL = {
 'THESIS BREAK REVIEW':'투자 가설 훼손 검토',
 'THESIS WEAKENED / RED TEAM REVIEW':'투자 가설 약화 / 반대 가설 검토',
 'EVIDENCE STRENGTHENED / RISK ASSUMPTION REVIEW':'근거 강화 / 위험 가정 검토',
 'THESIS STRENGTHENED · NO AUTO ADD':'투자 가설 강화 · 자동 추가 투자 없음',
 'MODEL RISK ASSUMPTION REVIEW':'모형 위험 가정 검토',
 'MIXED / MONITOR':'혼재 · 관찰',
}

def proof_status_label(value):
    return PROOF_STATUS.get(value,status_label(value)) if isinstance(value,str) else value

def scenario_signal_label(value):
    return SCENARIO_SIGNAL.get(value,value) if isinstance(value,str) else value
