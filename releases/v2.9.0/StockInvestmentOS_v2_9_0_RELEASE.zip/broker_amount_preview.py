"""Local arithmetic preview only: no client, journal, persistence or authority."""
from decimal import Decimal

from connectors.kis_broker import BrokerError, input_number, validate_order


def decimal_text(value):
    if not value:
        return '0'
    text = format(value, 'f')
    return text.rstrip('0').rstrip('.') if '.' in text else text


def money_text(value, currency):
    amount = Decimal(value)
    text = format(amount if amount else Decimal(0), ',f')
    if '.' in text:
        text = text.rstrip('0').rstrip('.')
    return text + ' ' + currency


def calculate_amounts(order, fee_buffer_pct, max_notional):
    """Match the existing guard's arithmetic; a cap is optional for preview."""
    checked = validate_order(order)
    fee = input_number(fee_buffer_pct, '비용 여유율')
    if fee > 5:
        raise BrokerError('비용 여유율: 0~5% 범위의 숫자를 입력하세요')
    gross = input_number(checked['limit_price'], '지정가', positive=True) * checked['quantity']
    comparison = gross * (1 + fee / 100)
    result = dict(order=checked, gross=decimal_text(gross),
                  buffer=decimal_text(gross * fee / 100),
                  comparison_amount=decimal_text(comparison), fee_buffer_pct=decimal_text(fee))
    if max_notional is None or (isinstance(max_notional, str) and not max_notional.strip()):
        return {**result, 'cap_status': 'MISSING'}
    try:
        cap = input_number(max_notional, '금액 상한')
    except BrokerError as exc:
        return {**result, 'cap_status': 'INVALID', 'cap_message': str(exc)}
    if cap == 0:
        return {**result, 'cap_status': 'MISSING'}
    return {**result, 'cap_status': 'WITHIN' if comparison <= cap else 'EXCEEDS',
            'cap': decimal_text(cap), 'difference': decimal_text(abs(cap - comparison))}
