"""Explicit, session-only LIVE KR calendar inspection, independent of orders."""
import streamlit as st
from engine import broker_market_session as gate


def clear_session_status():
    for key in ('_kis_session_calendar', '_kis_session_calendar_context'):
        st.session_state.pop(key, None)


def read_calendar(client):
    """One explicit call to the existing cached read-only adapter method."""
    before = gate.session_snapshot()
    day = before['date']
    failure = {'status': 'CHECK_REQUIRED', 'date': day,
               'checked_at': before['checked_at'], 'reason': 'LOOKUP_FAILED'}
    if client.credentials.mode != 'LIVE' or day is None:
        return {**failure, 'reason': 'NOT_APPLICABLE'}
    try:
        data = client.kr_open_day(day)
    except Exception:
        return failure
    after = gate.session_snapshot()
    if after['date'] != day:
        return {**failure, 'reason': 'DATE_CHANGED'}
    if not isinstance(data, dict) or data.get('date') != day or type(data.get('open')) is not bool:
        return {**failure, 'reason': 'INVALID_RESPONSE'}
    return {'status': 'PASS', 'date': day, 'open': data['open'], 'checked_at': after['checked_at']}


def render(client, market):
    if client.credentials.mode != 'LIVE' or market != 'KR':
        clear_session_status()
        return
    current = gate.session_snapshot()
    context = (client.credentials.identity, id(client), current['date'])
    if st.session_state.get('_kis_session_calendar_context') != context:
        clear_session_status()
        st.session_state['_kis_session_calendar_context'] = context
    with st.container(border=True):
        st.subheader('국내 거래시간·개장일')
        st.caption('조회 점검과 별도로 확인합니다. 조회 전용 점검은 거래시간 밖에도 실행할 수 있습니다.')
        st.button('시간 상태 새로 확인', key='kis_session_refresh')
        clicked = st.button('국내 개장일만 조회', key='kis_session_calendar_check', disabled=current['date'] is None)
        if clicked:
            st.session_state.pop('_kis_session_calendar', None)
            with st.spinner('오늘의 국내 개장일을 확인하고 있습니다…'):
                st.session_state['_kis_session_calendar'] = read_calendar(client)
        calendar = st.session_state.get('_kis_session_calendar')
        status = gate.session_snapshot(calendar)
        if status['status'] == 'BASIC_CONDITIONS_MET':
            st.info(status['message'])
        else:
            st.warning(status['message'])
        labels = {'UNCONFIRMED': '미확인', 'ERROR': '확인 실패', 'OPEN': '개장일', 'CLOSED': '휴장일'}
        st.write('증권사 개장일 조회: ' + labels[status['calendar']])
        if status['checked_at']:
            st.caption('시간 상태 확인: ' + status['checked_at'].replace('T', ' ') + ' (한국시간)')
        if status['calendar'] in ('OPEN', 'CLOSED'):
            st.caption('개장일 확인: ' + calendar['checked_at'].replace('T', ' '))
        if status['calendar'] == 'ERROR':
            st.caption('개장일 조회에 실패했습니다. 2분 후 버튼을 눌러 다시 확인하세요. 자동 재시도하지 않습니다.')
        st.caption('화면은 마지막 확인 시각 기준입니다. 새로 확인 버튼은 시간 상태만 갱신합니다. '
                   '개장일은 조회 버튼을 눌렀을 때만 확인하며, 같은 연결의 당일 성공 응답은 재사용합니다.')
        st.caption('이 표시는 주문 허용이나 체결 보장이 아닙니다. 임시 거래시간 변경·종목 거래정지·호가 규칙은 별도 확인이 필요합니다.')
