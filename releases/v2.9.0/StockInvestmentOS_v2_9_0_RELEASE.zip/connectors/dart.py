
from __future__ import annotations
import io, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import date
import pandas as pd
import requests

BASE = "https://opendart.fss.or.kr/api"

def _check_key(api_key: str) -> str:
    key = (api_key or "").strip()
    if not key:
        raise ValueError("DART API key is empty")
    return key

def download_corp_codes(api_key: str, save_csv: str | Path | None = None) -> pd.DataFrame:
    key = _check_key(api_key)
    r = requests.get(f"{BASE}/corpCode.xml", params={"crtfc_key": key}, timeout=30)
    r.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(r.content)) as zf:
        xml_bytes = zf.read(zf.namelist()[0])
    root = ET.fromstring(xml_bytes)
    rows = []
    for item in root.findall("list"):
        rows.append({
            "corp_code": item.findtext("corp_code", default=""),
            "corp_name": item.findtext("corp_name", default=""),
            "stock_code": item.findtext("stock_code", default=""),
            "modify_date": item.findtext("modify_date", default=""),
        })
    df = pd.DataFrame(rows)
    if save_csv:
        Path(save_csv).parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(save_csv, index=False, encoding="utf-8-sig")
    return df

def find_corp_code(stock_code: str, corp_codes: pd.DataFrame) -> str | None:
    code = str(stock_code).zfill(6)
    hit = corp_codes.loc[corp_codes["stock_code"].astype(str).str.zfill(6) == code]
    if hit.empty:
        return None
    return str(hit.iloc[0]["corp_code"]).zfill(8)

def full_financials(api_key: str, corp_code: str, business_year: int,
                    report_code: str = "11011", fs_div: str = "CFS") -> pd.DataFrame:
    key = _check_key(api_key)
    params = {
        "crtfc_key": key,
        "corp_code": str(corp_code).zfill(8),
        "bsns_year": str(business_year),
        "reprt_code": report_code,
        "fs_div": fs_div,
    }
    r = requests.get(f"{BASE}/fnlttSinglAcntAll.json", params=params, timeout=30)
    r.raise_for_status()
    payload = r.json()
    if payload.get("status") not in (None, "000"):
        raise RuntimeError(f"DART error {payload.get('status')}: {payload.get('message')}")
    return pd.DataFrame(payload.get("list", []))



def stock_total_status(
    api_key: str,
    corp_code: str,
    business_year: int,
    report_code: str = "11011",
) -> pd.DataFrame:
    """
    OpenDART stockTotqySttus endpoint.

    This is a share-count source, not a diluted-EPS denominator.
    The returned distributed/issued share counts must be interpreted by share class.
    """
    key = _check_key(api_key)
    params = {
        "crtfc_key": key,
        "corp_code": str(corp_code).zfill(8),
        "bsns_year": str(business_year),
        "reprt_code": str(report_code),
    }
    r = requests.get(
        f"{BASE}/stockTotqySttus.json",
        params=params,
        timeout=30,
    )
    r.raise_for_status()
    payload = r.json()
    status = str(payload.get("status", "000"))
    if status not in {"000", "013"}:
        raise RuntimeError(
            f"DART error {status}: {payload.get('message')}"
        )
    return pd.DataFrame(payload.get("list", []))


def summarize_share_count(df: pd.DataFrame) -> dict:
    """
    Conservative share-count summary.

    Preference:
    1) explicit 합계 row
    2) otherwise sum separate security-class rows

    `distributed_shares_proxy` is an issuer-wide share-count proxy.
    It is NOT automatically equivalent to weighted-average diluted shares used for EPS.
    """
    if df is None or df.empty:
        return {
            "distributed_shares_proxy": None,
            "issued_shares_proxy": None,
            "share_count_basis": "MISSING",
            "share_class_rows": 0,
            "source_rows": [],
        }

    work = df.copy()

    def _parse_share(v):
        return _to_number(v)

    se = (
        work.get("se", pd.Series("", index=work.index))
        .fillna("")
        .astype(str)
    )
    total_mask = se.str.contains("합계", regex=False, na=False)
    candidates = work.loc[total_mask].copy()
    basis = "EXPLICIT_TOTAL_ROW"

    if candidates.empty:
        candidates = work.copy()
        basis = "SUM_SECURITY_CLASS_ROWS"

    distributed = None
    issued = None

    if "distb_stock_co" in candidates.columns:
        vals = [
            _parse_share(v)
            for v in candidates["distb_stock_co"].tolist()
        ]
        vals = [v for v in vals if v is not None]
        if vals:
            distributed = vals[0] if basis == "EXPLICIT_TOTAL_ROW" else sum(vals)

    if "istc_totqy" in candidates.columns:
        vals = [
            _parse_share(v)
            for v in candidates["istc_totqy"].tolist()
        ]
        vals = [v for v in vals if v is not None]
        if vals:
            issued = vals[0] if basis == "EXPLICIT_TOTAL_ROW" else sum(vals)

    source_rows = []
    for _, row in work.iterrows():
        source_rows.append(
            {
                "se": str(row.get("se", "") or ""),
                "distb_stock_co": row.get("distb_stock_co"),
                "istc_totqy": row.get("istc_totqy"),
                "tesstk_co": row.get("tesstk_co"),
            }
        )

    status = "PASS_PROXY" if distributed is not None else (
        "ISSUED_ONLY_PROXY" if issued is not None else "MISSING"
    )

    return {
        "distributed_shares_proxy": distributed,
        "issued_shares_proxy": issued,
        "share_count_basis": basis if status != "MISSING" else "MISSING",
        "share_count_status": status,
        "share_class_rows": int(len(work)),
        "source_rows": source_rows,
        "warning": (
            "Distributed/issued shares are stock-total-status proxies. "
            "They are not automatically the weighted-average diluted EPS denominator, "
            "and multiple share classes require economic interpretation."
        ),
    }


def multi_company_accounts(
    api_key: str,
    corp_codes: list[str],
    business_year: int,
    report_code: str = "11011",
) -> pd.DataFrame:
    """OpenDART multi-company major accounts. Up to 100 corp codes per request."""
    key = _check_key(api_key)
    codes = [str(x).strip().zfill(8) for x in (corp_codes or []) if str(x).strip()]
    # de-duplicate while preserving order
    codes = list(dict.fromkeys(codes))
    if not codes:
        return pd.DataFrame()
    if len(codes) > 100:
        raise ValueError("OpenDART multi-company request supports at most 100 companies.")
    params = {
        "crtfc_key": key,
        "corp_code": ",".join(codes),
        "bsns_year": str(int(business_year)),
        "reprt_code": str(report_code),
    }
    r = requests.get(f"{BASE}/fnlttMultiAcnt.json", params=params, timeout=30)
    r.raise_for_status()
    payload = r.json()
    status = payload.get("status")
    if status not in (None, "000", "013"):
        raise RuntimeError(f"DART error {status}: {payload.get('message')}")
    return pd.DataFrame(payload.get("list", []))

REPORT_PRIORITY = [
    ("11014","Q3"),
    ("11012","H1"),
    ("11013","Q1"),
    ("11011","FY"),
]

def latest_available_financials(api_key: str, corp_code: str, fs_div: str = "CFS",
                                current_year: int | None = None) -> tuple[pd.DataFrame, dict]:
    """Try recent reports, newest practical period first. Returns raw financials + metadata."""
    y = current_year or date.today().year
    attempts = []
    # Current-year interim reports first; for prior years prefer the annual report.
    candidates = []
    candidates.extend([(y, "11014", "Q3"), (y, "11012", "H1"), (y, "11013", "Q1"), (y, "11011", "FY")])
    for year in range(y-1, y-3, -1):
        candidates.extend([(year, "11011", "FY"), (year, "11014", "Q3"), (year, "11012", "H1"), (year, "11013", "Q1")])
    for year, report_code, label in candidates:
        try:
            df = full_financials(api_key, corp_code, year, report_code, fs_div)
            attempts.append((year, report_code, label, len(df)))
            if not df.empty:
                return df, {"business_year":year, "report_code":report_code, "period":label,
                            "fs_div":fs_div, "attempts":attempts}
        except Exception as e:
            attempts.append((year, report_code, label, str(e)))
            continue
    raise RuntimeError(f"No recent financial statement returned. Attempts: {attempts[-6:]}")

def _to_number(v):
    if v is None:
        return None
    s = str(v).replace(",","").strip()
    if not s or s in {"-","nan","None"}:
        return None
    try:
        return float(s)
    except Exception:
        return None

def _pick_account(df: pd.DataFrame, candidates: list[str], prefer_current: bool = True) -> tuple[float | None, str | None]:
    if df.empty or "account_nm" not in df.columns:
        return None, None
    work = df.copy()
    work["_account"] = work["account_nm"].fillna("").astype(str).str.replace(" ","", regex=False)
    for name in candidates:
        key = name.replace(" ","")
        hit = work.loc[work["_account"].str.contains(key, regex=False)]
        if not hit.empty:
            row = hit.iloc[0]
            for col in (["thstrm_amount","thstrm_add_amount","frmtrm_amount"] if prefer_current else
                        ["thstrm_add_amount","thstrm_amount","frmtrm_amount"]):
                if col in row.index:
                    n = _to_number(row.get(col))
                    if n is not None:
                        return n, str(row.get("account_nm"))
    return None, None


def _pick_account_exact_first(
    df: pd.DataFrame,
    candidates: list[str],
    prefer_current: bool = True
) -> tuple[float | None, str | None]:
    """Prefer exact normalized account-name matches before substring fallback."""
    if df.empty or "account_nm" not in df.columns:
        return None, None
    work = df.copy()
    work["_account"] = (
        work["account_nm"].fillna("").astype(str)
        .str.replace(" ", "", regex=False)
        .str.replace("\u3000", "", regex=False)
    )
    cols = (["thstrm_amount","thstrm_add_amount","frmtrm_amount"] if prefer_current else
            ["thstrm_add_amount","thstrm_amount","frmtrm_amount"])

    # Exact normalized match first.
    for name in candidates:
        key = name.replace(" ","").replace("\u3000","")
        hit = work.loc[work["_account"].eq(key)]
        if not hit.empty:
            row = hit.iloc[0]
            for col in cols:
                if col in row.index:
                    n = _to_number(row.get(col))
                    if n is not None:
                        return n, str(row.get("account_nm"))

    # Issuer labels can contain prefixes/suffixes, so fall back to contains.
    for name in candidates:
        key = name.replace(" ","").replace("\u3000","")
        hit = work.loc[work["_account"].str.contains(key, regex=False)]
        if not hit.empty:
            row = hit.iloc[0]
            for col in cols:
                if col in row.index:
                    n = _to_number(row.get(col))
                    if n is not None:
                        return n, str(row.get("account_nm"))
    return None, None



def _pick_account_scoped(
    df: pd.DataFrame,
    candidates: list[str],
    *,
    statement_divs: tuple[str, ...] | list[str] | None = None,
    prefer_accumulated: bool = False,
) -> tuple[float | None, str | None, str | None, str | None]:
    """
    Pick one account from an intended financial-statement section.

    Returns:
        (value, account_name, sj_div, value_column)

    Why this exists:
    - fnlttSinglAcntAll can contain BS / IS / CIS / CF / SCE rows together.
    - The same or similar Korean account label can appear in more than one
      statement. Searching the whole DataFrame can therefore select the wrong
      statement row.
    - For interim income/cash-flow data, thstrm_add_amount is the cumulative
      period amount when provided. Balance-sheet items should use thstrm_amount.
    """
    if df is None or df.empty or "account_nm" not in df.columns:
        return None, None, None, None

    work = df.copy()

    if statement_divs and "sj_div" in work.columns:
        allowed = {str(x).upper() for x in statement_divs}
        work = work.loc[
            work["sj_div"].fillna("").astype(str).str.upper().isin(allowed)
        ].copy()

    if work.empty:
        return None, None, None, None

    work["_account"] = (
        work["account_nm"].fillna("").astype(str)
        .str.replace(" ", "", regex=False)
        .str.replace("\u3000", "", regex=False)
    )

    if prefer_accumulated:
        value_cols = ["thstrm_add_amount", "thstrm_amount", "frmtrm_amount"]
    else:
        value_cols = ["thstrm_amount", "thstrm_add_amount", "frmtrm_amount"]

    def _value_from_row(row):
        for col in value_cols:
            if col in row.index:
                n = _to_number(row.get(col))
                if n is not None:
                    return (
                        n,
                        str(row.get("account_nm", "") or ""),
                        str(row.get("sj_div", "") or ""),
                        col,
                    )
        return None

    # Exact normalized account-name match first.
    for name in candidates:
        key = str(name).replace(" ", "").replace("\u3000", "")
        hit = work.loc[work["_account"].eq(key)]
        for _, row in hit.iterrows():
            result = _value_from_row(row)
            if result is not None:
                return result

    # Conservative substring fallback only inside the intended statement scope.
    for name in candidates:
        key = str(name).replace(" ", "").replace("\u3000", "")
        hit = work.loc[work["_account"].str.contains(key, regex=False, na=False)]
        for _, row in hit.iterrows():
            result = _value_from_row(row)
            if result is not None:
                return result

    return None, None, None, None


def summarize_financials(df: pd.DataFrame) -> dict:
    """
    Best-effort extraction with statement-scoped account matching.

    Guardrails:
    - BS only: cash and debt components
    - IS/CIS only: revenue, operating profit, interest/finance cost
    - CF only: CFO and capex
    - Interim flow items prefer cumulative thstrm_add_amount when available
    - FCF proxy is produced only when both CFO and capex are found
    """
    cash, cash_src, cash_sj, cash_col = _pick_account_scoped(
        df,
        ["현금및현금성자산", "현금및현금성자산및단기금융상품"],
        statement_divs=("BS",),
        prefer_accumulated=False,
    )

    revenue, revenue_src, revenue_sj, revenue_col = _pick_account_scoped(
        df,
        ["매출액", "영업수익", "수익(매출액)"],
        statement_divs=("IS", "CIS"),
        prefer_accumulated=True,
    )

    op, op_src, op_sj, op_col = _pick_account_scoped(
        df,
        ["영업이익(손실)", "영업이익"],
        statement_divs=("IS", "CIS"),
        prefer_accumulated=True,
    )

    pretax_income, pretax_src, pretax_sj, pretax_col = _pick_account_scoped(
        df,
        [
            "법인세비용차감전순이익(손실)",
            "법인세비용차감전순이익",
            "세전이익",
        ],
        statement_divs=("IS", "CIS"),
        prefer_accumulated=True,
    )

    income_tax_expense, tax_src, tax_sj, tax_col = _pick_account_scoped(
        df,
        [
            "법인세비용(수익)",
            "법인세비용",
        ],
        statement_divs=("IS", "CIS"),
        prefer_accumulated=True,
    )

    total_equity, equity_src, equity_sj, equity_col = _pick_account_scoped(
        df,
        [
            "자본총계",
            "자본",
        ],
        statement_divs=("BS",),
        prefer_accumulated=False,
    )

    cfo, cfo_src, cfo_sj, cfo_col = _pick_account_scoped(
        df,
        [
            "영업활동현금흐름",
            "영업활동으로인한현금흐름",
            "영업활동으로부터의현금흐름",
        ],
        statement_divs=("CF",),
        prefer_accumulated=True,
    )

    capex, capex_src, capex_sj, capex_col = _pick_account_scoped(
        df,
        [
            "유형자산의취득",
            "유형자산취득",
            "유형자산의증가",
            "유형자산의 증가",
        ],
        statement_divs=("CF",),
        prefer_accumulated=True,
    )

    dividends_paid, dividends_src, dividends_sj, dividends_col = _pick_account_scoped(
        df,
        [
            "배당금의 지급",
            "배당금 지급",
            "배당금의지급",
            "현금배당금의 지급",
            "현금배당금 지급",
        ],
        statement_divs=("CF",),
        prefer_accumulated=True,
    )

    treasury_purchase, treasury_purchase_src, treasury_purchase_sj, treasury_purchase_col = _pick_account_scoped(
        df,
        [
            "자기주식의 취득",
            "자기주식 취득",
            "자기주식의취득",
        ],
        statement_divs=("CF",),
        prefer_accumulated=True,
    )

    treasury_disposal, treasury_disposal_src, treasury_disposal_sj, treasury_disposal_col = _pick_account_scoped(
        df,
        [
            "자기주식의 처분",
            "자기주식 처분",
            "자기주식의처분",
        ],
        statement_divs=("CF",),
        prefer_accumulated=True,
    )

    # Debt components must come from the balance sheet only. Without the BS
    # scope, substring fallback can accidentally match cash-flow rows such as
    # "단기차입금의 증가".
    debt_categories = [
        ("short_term_borrowings", ["단기차입금", "유동차입금"]),
        (
            "current_portion_longterm",
            ["유동성장기부채", "유동성장기차입금", "유동성장기차입부채", "유동성장기채무"],
        ),
        ("current_bonds", ["유동성사채", "유동사채"]),
        ("long_term_borrowings", ["장기차입금", "비유동차입금"]),
        ("bonds", ["사채", "비유동사채"]),
        ("current_lease_liabilities", ["유동리스부채", "유동성리스부채"]),
        ("lease_liabilities", ["리스부채", "비유동리스부채"]),
    ]

    debt = 0.0
    debt_sources = []
    debt_components = {}
    debt_source_details = {}
    used_source_names = set()
    any_debt = False

    for key, candidates in debt_categories:
        v, src, sj, value_col = _pick_account_scoped(
            df,
            candidates,
            statement_divs=("BS",),
            prefer_accumulated=False,
        )
        normalized_src = (src or "").replace(" ", "")
        if v is not None and (not normalized_src or normalized_src not in used_source_names):
            amount = max(0.0, float(v))
            debt_components[key] = amount
            debt_source_details[key] = {
                "account": src or "",
                "sj_div": sj or "",
                "value_column": value_col or "",
            }
            debt += amount
            any_debt = True
            if src:
                debt_sources.append(src)
                used_source_names.add(normalized_src)
        else:
            debt_components[key] = None
            debt_source_details[key] = {
                "account": src or "",
                "sj_div": sj or "",
                "value_column": value_col or "",
            }

    # Prefer a true interest-expense line. If unavailable, finance cost is a
    # broader proxy and is explicitly labeled as such.
    interest_expense, interest_src, interest_sj, interest_col = _pick_account_scoped(
        df,
        ["이자비용"],
        statement_divs=("IS", "CIS"),
        prefer_accumulated=True,
    )
    interest_quality = "INTEREST_LINE"

    if interest_expense is None:
        interest_expense, interest_src, interest_sj, interest_col = _pick_account_scoped(
            df,
            ["금융비용", "금융원가"],
            statement_divs=("IS", "CIS"),
            prefer_accumulated=True,
        )
        interest_quality = "BROAD_FINANCE_COST_PROXY" if interest_expense is not None else "MISSING"

    # Do not silently equate CFO with FCF. FCF proxy requires both CFO and a
    # capex line. This is still only a PPE-capex proxy; other investment cash
    # outflows may require manual review.
    fcf_proxy = None
    if cfo is not None and capex is not None:
        fcf_proxy = float(cfo) - abs(float(capex))

    if cfo is None:
        fcf_status = "MISSING_CFO"
    elif capex is None:
        fcf_status = "MISSING_CAPEX"
    else:
        fcf_status = "PASS_PROXY"

    debt_value = debt if any_debt else None
    net_cash_proxy = None
    cash_to_debt_proxy = None
    if cash is not None and debt_value is not None:
        net_cash_proxy = float(cash) - float(debt_value)
        if debt_value > 0:
            cash_to_debt_proxy = float(cash) / float(debt_value)

    effective_tax_rate_proxy = None
    effective_tax_rate_proxy_status = "MISSING"
    if (
        pretax_income is not None
        and float(pretax_income) > 0
        and income_tax_expense is not None
    ):
        _tax_rate = float(income_tax_expense) / float(pretax_income)
        if 0.0 <= _tax_rate <= 0.50:
            effective_tax_rate_proxy = _tax_rate
            effective_tax_rate_proxy_status = "PASS_PROXY"
        else:
            effective_tax_rate_proxy_status = "REVIEW_RANGE"

    invested_capital_proxy = None
    invested_capital_proxy_status = "MISSING"
    if (
        total_equity is not None
        and debt_value is not None
        and cash is not None
    ):
        invested_capital_proxy = (
            float(total_equity)
            + float(debt_value)
            - float(cash)
        )
        invested_capital_proxy_status = (
            "PASS_PROXY"
            if invested_capital_proxy > 0
            else "REVIEW_NONPOSITIVE"
        )

    # Data-integrity status: this is not an investment PASS. It only reports
    # whether the intended source statements/accounts were found.
    source_checks = {
        "cash_bs": cash is not None and cash_sj == "BS",
        "revenue_is_cis": revenue is None or revenue_sj in {"IS", "CIS"},
        "op_is_cis": op is None or op_sj in {"IS", "CIS"},
        "pretax_is_cis": pretax_income is None or pretax_sj in {"IS", "CIS"},
        "tax_is_cis": income_tax_expense is None or tax_sj in {"IS", "CIS"},
        "equity_bs": total_equity is None or equity_sj == "BS",
        "cfo_cf": cfo is None or cfo_sj == "CF",
        "capex_cf": capex is None or capex_sj == "CF",
        "dividends_cf": dividends_paid is None or dividends_sj == "CF",
        "treasury_purchase_cf": treasury_purchase is None or treasury_purchase_sj == "CF",
        "treasury_disposal_cf": treasury_disposal is None or treasury_disposal_sj == "CF",
        "debt_bs": all(
            (d["sj_div"] in {"", "BS"})
            for d in debt_source_details.values()
        ),
    }
    extraction_integrity_status = (
        "PASS" if all(source_checks.values()) else "REVIEW"
    )

    return {
        "cash": cash,
        "cash_source_account": cash_src,
        "cash_source_statement": cash_sj,
        "cash_value_column": cash_col,

        "interest_bearing_debt_proxy": debt_value,
        "debt_source_accounts": "; ".join(debt_sources),
        "short_term_borrowings_proxy": debt_components["short_term_borrowings"],
        "current_portion_longterm_proxy": debt_components["current_portion_longterm"],
        "current_bonds_proxy": debt_components["current_bonds"],
        "long_term_borrowings_proxy": debt_components["long_term_borrowings"],
        "bonds_proxy": debt_components["bonds"],
        "current_lease_liabilities_proxy": debt_components["current_lease_liabilities"],
        "lease_liabilities_proxy": debt_components["lease_liabilities"],
        "debt_source_details": debt_source_details,
        "debt_proxy_review_status": "REVIEW_NOTES" if any_debt else "MISSING",

        "net_cash_proxy": net_cash_proxy,
        "cash_to_debt_proxy": cash_to_debt_proxy,

        "interest_expense_proxy": interest_expense,
        "interest_expense_source_account": interest_src,
        "interest_expense_source_statement": interest_sj,
        "interest_expense_value_column": interest_col,
        "interest_expense_proxy_quality": interest_quality,

        "revenue": revenue,
        "revenue_source_account": revenue_src,
        "revenue_source_statement": revenue_sj,
        "revenue_value_column": revenue_col,

        "operating_profit": op,
        "operating_profit_source_account": op_src,
        "operating_profit_source_statement": op_sj,
        "operating_profit_value_column": op_col,

        "pretax_income": pretax_income,
        "pretax_income_source_account": pretax_src,
        "pretax_income_source_statement": pretax_sj,
        "pretax_income_value_column": pretax_col,

        "income_tax_expense": income_tax_expense,
        "income_tax_expense_source_account": tax_src,
        "income_tax_expense_source_statement": tax_sj,
        "income_tax_expense_value_column": tax_col,

        "effective_tax_rate_proxy": effective_tax_rate_proxy,
        "effective_tax_rate_proxy_status": effective_tax_rate_proxy_status,

        "total_equity": total_equity,
        "total_equity_source_account": equity_src,
        "total_equity_source_statement": equity_sj,
        "total_equity_value_column": equity_col,

        "invested_capital_proxy": invested_capital_proxy,
        "invested_capital_proxy_status": invested_capital_proxy_status,
        "invested_capital_proxy_scope": "Total Equity + Interest-bearing Debt Proxy - Cash",

        "cfo": cfo,
        "cfo_source_account": cfo_src,
        "cfo_source_statement": cfo_sj,
        "cfo_value_column": cfo_col,

        "capex_proxy": capex,
        "capex_source_account": capex_src,
        "capex_source_statement": capex_sj,
        "capex_value_column": capex_col,

        "dividends_paid_proxy": None if dividends_paid is None else abs(float(dividends_paid)),
        "dividends_paid_source_account": dividends_src,
        "dividends_paid_source_statement": dividends_sj,
        "dividends_paid_value_column": dividends_col,

        "treasury_share_purchase_proxy": None if treasury_purchase is None else abs(float(treasury_purchase)),
        "treasury_share_purchase_source_account": treasury_purchase_src,
        "treasury_share_purchase_source_statement": treasury_purchase_sj,
        "treasury_share_purchase_value_column": treasury_purchase_col,

        "treasury_share_disposal_proxy": None if treasury_disposal is None else abs(float(treasury_disposal)),
        "treasury_share_disposal_source_account": treasury_disposal_src,
        "treasury_share_disposal_source_statement": treasury_disposal_sj,
        "treasury_share_disposal_value_column": treasury_disposal_col,

        "fcf_proxy": fcf_proxy,
        "fcf_proxy_review_status": fcf_status,
        "fcf_proxy_scope": "CFO - abs(PPE acquisition capex only)",

        "extraction_integrity_status": extraction_integrity_status,
        "extraction_source_checks": source_checks,

        "note": (
            "Best-effort extraction from OpenDART account labels with statement scoping. "
            "BS is used for cash/debt/equity, IS/CIS for revenue/operating profit/pretax/tax/finance cost, "
            "and CF for CFO/capex/dividends/treasury-share cash flows. Interim flow items prefer cumulative thstrm_add_amount. "
            "FCF proxy is only produced when both CFO and PPE capex are found. "
            "Verify debt maturities, covenants, lease debt, finance-cost composition and "
            "other investment cash outflows against the original filing notes."
        ),
    }


def disclosure_list(
    api_key: str,
    corp_code: str | None = None,
    begin_date: str | None = None,
    end_date: str | None = None,
    page_count: int = 50,
) -> pd.DataFrame:
    """OpenDART disclosure search (list.json). Dates: YYYYMMDD."""
    key = _check_key(api_key)
    params = {
        "crtfc_key": key,
        "page_no": 1,
        "page_count": min(max(int(page_count), 1), 100),
        "sort": "date",
        "sort_mth": "desc",
    }
    if corp_code:
        params["corp_code"] = str(corp_code).zfill(8)
    if begin_date:
        params["bgn_de"] = begin_date
    if end_date:
        params["end_de"] = end_date

    r = requests.get(f"{BASE}/list.json", params=params, timeout=30)
    r.raise_for_status()
    payload = r.json()
    status = payload.get("status")
    if status not in (None, "000", "013"):
        raise RuntimeError(f"DART error {status}: {payload.get('message')}")
    return pd.DataFrame(payload.get("list", []))

def recent_disclosures_for_watchlist(
    api_key: str,
    watchlist: pd.DataFrame,
    corp_codes: pd.DataFrame,
    begin_date: str,
    end_date: str,
    per_company: int = 20,
) -> pd.DataFrame:
    rows = []
    if watchlist is None or watchlist.empty:
        return pd.DataFrame()
    for _, row in watchlist.iterrows():
        stock_code = str(row.get("code", "") or "").strip().zfill(6)
        name = str(row.get("name", "") or "")
        if not stock_code or stock_code == "000000":
            continue
        corp_code = find_corp_code(stock_code, corp_codes)
        if not corp_code:
            rows.append({
                "stock_code": stock_code, "watch_name": name, "status": "ERROR",
                "message": "corp_code not found"
            })
            continue
        try:
            df = disclosure_list(api_key, corp_code, begin_date, end_date, per_company)
            if df.empty:
                rows.append({
                    "stock_code": stock_code, "watch_name": name, "corp_code": corp_code,
                    "status": "NONE", "message": "No disclosure in period"
                })
                continue
            for _, d in df.iterrows():
                rows.append({
                    "stock_code": stock_code,
                    "watch_name": name,
                    "corp_code": corp_code,
                    "corp_name": d.get("corp_name", ""),
                    "report_nm": d.get("report_nm", ""),
                    "rcept_no": d.get("rcept_no", ""),
                    "flr_nm": d.get("flr_nm", ""),
                    "rcept_dt": d.get("rcept_dt", ""),
                    "rm": d.get("rm", ""),
                    "status": "OK",
                    "message": "",
                })
        except Exception as e:
            rows.append({
                "stock_code": stock_code, "watch_name": name, "corp_code": corp_code,
                "status": "ERROR", "message": str(e)
            })
    out = pd.DataFrame(rows)
    if not out.empty and "rcept_dt" in out.columns:
        out = out.sort_values("rcept_dt", ascending=False, na_position="last")
    return out
