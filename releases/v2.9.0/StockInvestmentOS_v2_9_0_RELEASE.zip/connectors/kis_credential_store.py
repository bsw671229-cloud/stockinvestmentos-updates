"""Opt-in, user-scoped Windows DPAPI storage; never stores tokens or order permissions."""
from pathlib import Path
import ctypes
from ctypes import wintypes
import hashlib, hmac, json, os, tempfile
from threading import RLock
from connectors.kis_broker import Credentials

MAGIC = b'SIO-KIS-DPAPI-1\x00'
MAX_SIZE = 16384
_LOCK = RLock()


class CredentialStoreError(RuntimeError):
    pass


def supported():
    return os.name == 'nt'


def _mode(mode):
    if mode not in ('LIVE', 'PAPER'):
        raise CredentialStoreError('모의 또는 실전 환경을 확인하세요.')
    return mode


class _Blob(ctypes.Structure):
    _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]


def _crypt(data, mode, *, decrypt=False):
    _mode(mode)
    if not supported():
        raise CredentialStoreError('연결정보 기억하기는 Windows에서 사용할 수 있습니다.')
    if not isinstance(data, bytes) or not 0 < len(data) <= MAX_SIZE:
        raise CredentialStoreError('저장정보 형식을 확인하지 못했습니다. 직접 입력해 다시 저장하세요.')
    source = ctypes.create_string_buffer(data)
    entropy_bytes = ('StockInvestmentOS/KIS/credential/v1/' + mode).encode('ascii')
    entropy_buf = ctypes.create_string_buffer(entropy_bytes)
    blob = _Blob(len(data), ctypes.cast(source, ctypes.POINTER(ctypes.c_ubyte)))
    entropy = _Blob(len(entropy_bytes), ctypes.cast(entropy_buf, ctypes.POINTER(ctypes.c_ubyte)))
    output = _Blob()
    kernel = None
    try:
        crypt = ctypes.WinDLL('crypt32.dll', use_last_error=True, winmode=0x800)
        kernel = ctypes.WinDLL('kernel32.dll', use_last_error=True, winmode=0x800)
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        function = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
        function.argtypes = [ctypes.POINTER(_Blob), ctypes.c_void_p if decrypt else wintypes.LPCWSTR,
                            ctypes.POINTER(_Blob), ctypes.c_void_p, ctypes.c_void_p,
                            wintypes.DWORD, ctypes.POINTER(_Blob)]
        function.restype = wintypes.BOOL
        # UI forbidden, current-user protection. Never use CRYPTPROTECT_LOCAL_MACHINE.
        if not function(ctypes.byref(blob), None if decrypt else 'StockInvestmentOS KIS',
                        ctypes.byref(entropy), None, None, 1, ctypes.byref(output)):
            raise ValueError('DPAPI failed')
        if not output.pbData or not 0 < output.cbData <= MAX_SIZE:
            raise ValueError('DPAPI output size')
        return ctypes.string_at(output.pbData, output.cbData)
    except Exception:
        raise CredentialStoreError('Windows 보호 저장정보를 처리하지 못했습니다. 같은 Windows 계정에서 직접 입력해 다시 저장하세요.') from None
    finally:
        ctypes.memset(source, 0, len(source))
        if output.pbData and kernel is not None:
            ctypes.memset(output.pbData, 0, output.cbData)
            kernel.LocalFree(output.pbData)


def _path(control_root, mode):
    _mode(mode)
    operations = Path(control_root).resolve()/'broker_operations'
    folder = operations/'credentials'
    path = folder/(mode.lower()+'.dpapi')
    for value in (operations, folder, path):
        if value.is_symlink() or value.is_junction():
            raise CredentialStoreError('저장 경로를 확인하지 못했습니다. 연결정보는 직접 입력해 주세요.')
    return path


def _encode(credentials):
    checked = Credentials.from_input(_mode(credentials.mode), credentials.app_key,
                                     credentials.app_secret, credentials.account+'-'+credentials.product)
    value = dict(schema=1, mode=checked.mode, app_key=checked.app_key,
                 app_secret=checked.app_secret, account=checked.account, product=checked.product)
    raw = json.dumps(value, separators=(',', ':'), ensure_ascii=True).encode('utf-8')
    return hashlib.sha256(raw).digest()+raw


def save(control_root, credentials):
    """Encrypt before any disk write; failed replacement leaves the old profile intact."""
    temporary = None
    try:
        with _LOCK:
            target = _path(control_root, credentials.mode)
            payload = MAGIC + _crypt(_encode(credentials), credentials.mode)
            target.parent.mkdir(parents=True, exist_ok=True)
            # Repeat path check after directory creation and before replacement.
            _path(control_root, credentials.mode)
            with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.saving-', delete=False) as handle:
                temporary = Path(handle.name)
                handle.write(payload);handle.flush();os.fsync(handle.fileno())
            _path(control_root, credentials.mode)
            os.replace(temporary, target)
    except CredentialStoreError:
        raise
    except Exception:
        raise CredentialStoreError('연결은 유지되지만 저장하지 못했습니다. 기존 저장정보는 삭제하지 않았습니다.') from None
    finally:
        if temporary is not None:
            try: temporary.unlink(missing_ok=True)
            except OSError: pass


def load(control_root, mode):
    try:
        with _LOCK:
            target = _path(control_root, mode)
            if not target.exists():
                raise CredentialStoreError('이 환경에 저장한 연결정보가 없습니다. 처음 한 번 직접 입력한 뒤 기억하기를 선택하세요.')
            with target.open('rb') as handle: encrypted = handle.read(MAX_SIZE+1)
            if len(encrypted)>MAX_SIZE or not encrypted.startswith(MAGIC): raise ValueError('format')
            plain = _crypt(encrypted[len(MAGIC):], mode, decrypt=True)
            digest, raw = plain[:32], plain[32:]
            if not raw or not hmac.compare_digest(digest, hashlib.sha256(raw).digest()): raise ValueError('integrity')
            value = json.loads(raw)
            expected = {'schema','mode','app_key','app_secret','account','product'}
            if not isinstance(value,dict) or set(value)!=expected or type(value['schema']) is not int or value['schema']!=1:
                raise ValueError('schema')
            if value['mode']!=mode or value['product']!='01' or any(not isinstance(value[k],str) for k in expected-{'schema'}):
                raise ValueError('mode')
            return Credentials.from_input(mode,value['app_key'],value['app_secret'],value['account']+'-'+value['product'])
    except CredentialStoreError:
        raise
    except Exception:
        raise CredentialStoreError('저장정보를 확인하지 못했습니다. 직접 입력한 뒤 다시 기억하기를 선택하세요.') from None


def delete(control_root, mode):
    try:
        with _LOCK:
            _path(control_root, mode).unlink(missing_ok=True)
    except CredentialStoreError:
        raise
    except Exception:
        raise CredentialStoreError('저장정보를 삭제하지 못했습니다. 파일 접근 상태를 확인하세요.') from None
