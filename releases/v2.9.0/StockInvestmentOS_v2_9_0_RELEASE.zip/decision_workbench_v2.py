"""Manual review screen. Does not read or write legacy investment data."""
from datetime import datetime, timezone, timedelta
import pandas as pd
import streamlit as st
from engine.decision_contract_v2 import review_contract


def render():
    st.title("투자·포트폴리오 검토 v2")
    st.caption("수동 입력한 손실 가정과 근거 시점으로 위험 상한을 검토합니다. 주문을 전송하지 않습니다.")
    st.info("아래 기본값은 가상의 예시입니다. 실제 검토에는 보유 비중·하방·출처를 직접 입력하고 확인하세요. 출처의 진위나 현재 가격을 자동 검증하지 않습니다.")
    kst=timezone(timedelta(hours=9))
    now=datetime.now(kst)
    # Keep the original evidence clock stable across reruns; rendering is not verification.
    initial_observed=st.session_state.setdefault('_v2_initial_evidence_clock',now)
    with st.form("decision_workbench_v2"):
        real=st.checkbox("예시가 아닌 실제 검토 입력입니다",value=False)
        symbol=st.text_input("검토 종목 식별자",value="EXAMPLE")
        factor=st.text_input("투자 요인",value="예시 산업")
        a,b=st.columns(2)
        proposed=a.number_input("검토 비중 (%)",min_value=0.0,max_value=100.0,value=3.0)
        downside=b.number_input("종목 하방 가정 (%)",min_value=0.0,max_value=100.0,value=40.0)
        assets=st.number_input("포트폴리오 총자산 (원)",min_value=0.0,max_value=1e15,value=10000000.0)
        st.markdown("**손실 예산과 비중 상한**")
        position_loss=st.number_input("종목 허용손실 / 총자산 (%)",min_value=0.0,max_value=100.0,value=1.0)
        portfolio_loss=st.number_input("포트폴리오 허용손실 / 총자산 (%)",min_value=0.0,max_value=100.0,value=10.0)
        caps={}
        for key,label,value in [("single_name_cap","개별 종목 상한 (%)",5.0),("factor_cap","같은 투자 요인 상한 (%)",25.0),("liquidity_cap","유동성 상한 (%)",10.0),("strategy_cap","전략 상한 (%)",10.0)]:
            caps[key]=st.number_input(label,min_value=0.0,max_value=100.0,value=value)/100
        st.markdown("**현재 보유 내역**")
        st.caption("현금 이외의 보유를 모두 입력하세요. 미입력 비중은 현금·하방 0으로 가정합니다. 같은 종목은 한 행만 입력하며, 비중·하방은 %입니다. 숏·레버리지·복수 요인 분석은 이 검토의 범위 밖입니다.")
        positions=st.data_editor(pd.DataFrame([{"종목":"OTHER","투자 요인":"다른 산업","비중 (%)":10.0,"하방 (%)":30.0}]),num_rows="dynamic",hide_index=True,key="v2_positions")
        st.markdown("**입력 근거**")
        source=st.text_input("출처 제목 또는 원문 주소",value="가상 예시")
        observed_date=st.date_input("근거 확인 날짜 (한국시간)",value=initial_observed.date(),key='v2_evidence_date')
        observed_time=st.time_input("근거 확인 시각 (한국시간)",value=initial_observed.time().replace(tzinfo=None,microsecond=0),key='v2_evidence_time')
        ttl=st.number_input("근거 유효 기간 (일)",min_value=1,max_value=365,value=3,step=1)
        attested=st.checkbox("보유 내역·하방 가정·출처·확인 시각을 검토했습니다",value=False)
        submitted=st.form_submit_button("위험 상한 검토")
    if not submitted:
        return
    if assets <= 0:
        st.error("손실 금액을 검토하려면 총자산이 0보다 커야 합니다")
        return
    if real and (symbol.strip().upper()=='EXAMPLE' or source.strip()=='가상 예시'):
        st.error("실제 검토에는 예시 종목과 예시 출처를 실제 입력으로 바꿔 주세요")
        return
    holdings=[]
    for row in positions.to_dict("records"):
        holdings.append(dict(symbol=row.get("종목"),factor=row.get("투자 요인"),weight=row.get("비중 (%)",float("nan"))/100,downside=row.get("하방 (%)",float("nan"))/100))
    contract=dict(schema_version=2,candidate=dict(symbol=symbol,factor=factor,downside=downside/100,proposed_weight=proposed/100),
                  budget=dict(position_loss=position_loss/100,portfolio_loss=portfolio_loss/100,**caps),positions=holdings,
                  evidence=dict(source=source,observed_at=datetime.combine(observed_date,observed_time,tzinfo=kst).isoformat(),max_age_days=int(ttl),user_attested=attested))
    result=review_contract(contract)
    if not real:
        st.warning("예시 계산 결과입니다. 실제 투자 판단이나 실행 근거로 사용할 수 없습니다.")
    if result["blockers"]:
        for blocker in result["blockers"]: st.error(blocker)
        return
    if result["status"]=="BLOCKED": st.error("위험 상한 초과 · 비중 확대 검토 중단")
    else: st.success("입력된 위험 상한 내 검토 가능 · 매수 또는 추가 투자 승인이 아닙니다")
    with st.container(horizontal=True):
        st.metric("최대 검토 비중",f'{result["max_weight"]:.2%}',width="content")
        st.metric("종목 가정 손실",f'{result["candidate_loss"]:.2%}',width="content")
        st.metric("포트폴리오 가정 손실",f'{result["modeled_portfolio_loss"]:.2%}',width="content")
    st.text(f'가정 손실 금액: 종목 {assets*result["candidate_loss"]:,.0f}원 / 포트폴리오 {assets*result["modeled_portfolio_loss"]:,.0f}원',wrap=True)
    names=dict(position_loss="종목 손실 예산",portfolio_loss="포트폴리오 잔여 손실 예산",single_name="개별 종목",factor="같은 투자 요인",liquidity="유동성",strategy="전략",capital="보유 가능 자본")
    st.text("제한 요인: "+", ".join(names[k] for k in result["limiting_factors"]),wrap=True)
    st.table(pd.DataFrame([{"제약":names[k],"상한":f'{v:.2%}'} for k,v in result["limits"].items()]))
    st.caption(result["model"])
    st.caption("입력 근거는 사용자 확인 기준입니다. 상관관계·하방의 실현 가능성·기업 가치·시장 기대를 자동 판정하지 않습니다.")
    with st.expander("검토 입력과 계산 근거"):
        st.json(contract)
        st.json(result)
