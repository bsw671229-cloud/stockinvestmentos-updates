from __future__ import annotations
if True:
    st.title('Portfolio Fit / Risk Headroom')
    st.caption('이 종목 자체가 좋아 보여도 내 계좌에 더 담을 여유가 있는지는 별도 문제입니다. Single-name → Factor → Sector 순서로 남은 위험 여유를 확인합니다.')
    st.markdown('**초보자용 핵심:** `Position Sizing = 종목 자체의 위험상한` → `Portfolio Fit = 내 계좌가 실제로 받아줄 수 있는 추가 상한`')
    if watchlist.empty:
        st.info('Watchlist가 비어 있습니다. Market Universe에서 종목을 Watchlist에 먼저 추가하세요.')
    else:
        fit_names = watchlist['name'].fillna('').astype(str).tolist()
        fit_company = st.selectbox('Portfolio Fit 확인 종목', fit_names, key='portfolio_fit_company')
        hit = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(str(fit_company))]
        if not hit.empty:
            wr = hit.iloc[0].to_dict()
            default_factor = str(wr.get('factor', '') or '').strip()
            default_sector = str(wr.get('sector', '') or '').strip()
            ticker = str(wr.get('ticker', '') or '').strip()
            if not portfolio.empty:
                phit = pd.DataFrame()
                if ticker and 'ticker' in portfolio.columns:
                    phit = portfolio.loc[portfolio['ticker'].fillna('').astype(str).str.strip().eq(ticker)]
                if phit.empty and 'name' in portfolio.columns:
                    phit = portfolio.loc[portfolio['name'].fillna('').astype(str).str.strip().eq(str(fit_company).strip())]
                if not phit.empty:
                    pr0 = phit.iloc[0]
                    if not default_factor:
                        default_factor = str(pr0.get('factor', '') or '').strip()
                    if not default_sector:
                        default_sector = str(pr0.get('sector', '') or '').strip()
            st.subheader('1. 종목 분류와 공통 위험 가정')
            shared_fit = resolve_shared_risk_assumptions(watchlist, fit_company, ticker, default_downside=0.5, default_price=0.0)
            a, b, c = st.columns(3)
            downside_fit = a.number_input('Plausible Downside', min_value=0.001, max_value=1.0, value=float(shared_fit['plausible_downside']), format='%.3f', key=f'portfolio_fit_downside::{fit_company}', help='Position Sizing과 공유되는 종목 공통 위험가정입니다. 예: 55%면 0.55')
            factor_fit = b.text_input('Factor', value=default_factor, key=f'portfolio_fit_factor::{fit_company}', placeholder='예: Korea Semiconductor', help='비슷한 위험요인이 함께 움직일 수 있는 그룹입니다.')
            sector_fit = c.text_input('Sector', value=default_sector, key=f'portfolio_fit_sector::{fit_company}', placeholder='예: Software', help='산업 집중도를 확인하기 위한 분류입니다.')
            a2, b2, c2 = st.columns(3)
            factor_cap_fit = a2.number_input('Factor Cap', min_value=0.001, max_value=1.0, value=float(settings.get('factor_cap', 0.1)), format='%.3f', key=f'portfolio_fit_factor_cap::{fit_company}')
            sector_cap_fit = b2.number_input('Sector Cap', min_value=0.001, max_value=1.0, value=float(settings.get('sector_cap', 0.25)), format='%.3f', key=f'portfolio_fit_sector_cap::{fit_company}')
            price_fit = c2.number_input('현재가격(KRW)', min_value=0.0, value=float(shared_fit['price_krw']), step=100.0, key=f'portfolio_fit_price::{fit_company}', help='Watchlist 가격이 없으면 직접 입력할 수 있습니다. 저장하면 Position Sizing에서도 같은 값을 사용합니다.')
            if st.button('공통가정 / Factor / Sector 저장', key='save_fit_shared'):
                try:
                    new_watch, new_port, meta = sync_shared_risk_assumptions(watchlist, portfolio, fit_company, ticker, price_fit, downside_fit)
                    for col in ['factor', 'sector']:
                        if col not in new_watch.columns:
                            new_watch[col] = ''
                        new_watch[col] = new_watch[col].astype('object')
                    idx = new_watch.index[new_watch['name'].fillna('').astype(str).eq(str(fit_company))][0]
                    old_factor = str(new_watch.at[idx, 'factor'] or '').strip()
                    old_sector = str(new_watch.at[idx, 'sector'] or '').strip()
                    new_watch.at[idx, 'factor'] = factor_fit.strip()
                    new_watch.at[idx, 'sector'] = sector_fit.strip()
                    if old_factor != factor_fit.strip() or old_sector != sector_fit.strip():
                        for acol in ['assumption_status', 'assumption_reviewed_at']:
                            if acol not in new_watch.columns:
                                new_watch[acol] = pd.Series([''] * len(new_watch), index=new_watch.index, dtype='object')
                            else:
                                new_watch[acol] = new_watch[acol].fillna('').astype('object')
                        new_watch.at[idx, 'assumption_status'] = 'REVIEW'
                        new_watch.at[idx, 'assumption_reviewed_at'] = ''
                    save_csv(new_watch, 'watchlist.csv')
                    if meta['portfolio_rows_synced'] > 0:
                        save_csv(new_port, 'portfolio.csv')
                    st.success(f'{fit_company} 저장 완료 · 현재가격 {krw(price_fit)} · Downside {pct(downside_fit)}')
                    st.rerun()
                except Exception as e:
                    st.error(str(e))
            review0 = portfolio_fit_review(portfolio=portfolio, total_assets=total_assets, candidate_name=fit_company, candidate_ticker=ticker, plausible_downside=downside_fit, loss_budget=loss_budget, single_name_cap=single_cap, factor=factor_fit, sector=sector_fit, factor_cap=factor_cap_fit, sector_cap=sector_cap_fit, price_krw=price_fit, requested_add_weight=0.0, reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), factor_loadings=factor_loadings)
            st.subheader('2. Risk Headroom')
            h1, h2, h3, h4 = st.columns(4)
            h1.metric('현재 종목 비중', pct(review0['current_weight']))
            h2.metric('종목 위험상한', pct(review0['name_risk_cap']))
            if review0['fit_status'] == 'PASS':
                h3.metric('최종 추가 Headroom', pct(review0['qualified_headroom']))
                h4.metric('Portfolio 최대 추가수량', f"{review0['max_add_shares']:,}주" if price_fit > 0 else '현재가격 필요')
            else:
                h3.metric('최종 추가 Headroom', '0.0%')
                h4.metric('Portfolio 최대 추가수량', '0주')
            st.caption('Portfolio Fit는 Position Sizing 상한을 줄일 수는 있지만 늘리지는 않습니다. Factor/Sector가 미분류면 안전하게 REVIEW로 두고 최종 추가 Headroom을 0으로 처리합니다.')
            gate_table = pd.DataFrame([{'Gate': 'Data', 'Status': review0['data_gate'], '설명': review0['data_detail']}, {'Gate': 'Single-name', 'Status': review0['name_gate'], '설명': review0['name_detail']}, {'Gate': 'Factor', 'Status': review0['factor_gate'], '설명': review0['factor_detail']}, {'Gate': 'Sector', 'Status': review0['sector_gate'], '설명': review0['sector_detail']}, {'Gate': '수량계산 가격', 'Status': review0['price_gate'], '설명': review0['price_detail']}])
            st.dataframe(gate_table, width='stretch', hide_index=True)
            if factor_fit:
                st.caption(f"Factor 계산: Look-through · 후보 Loading {review0.get('candidate_factor_loading', 1.0):.1%} ({review0.get('candidate_factor_loading_status', 'CONSERVATIVE')})")
                factor_breakdown = review0.get('factor_breakdown', pd.DataFrame())
                if isinstance(factor_breakdown, pd.DataFrame) and (not factor_breakdown.empty):
                    with st.expander('Factor Look-through 기여도 보기'):
                        fb = factor_breakdown.copy()
                        for col in ['portfolio_weight', 'loading', 'factor_exposure']:
                            if col in fb.columns:
                                fb[col] = pd.to_numeric(fb[col], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
                        st.dataframe(fb, width='stretch', hide_index=True)
            if review0['fit_status'] == 'PASS':
                st.success('Portfolio Fit = PASS · 현재 분류와 Cap 기준으로 추가 위험 여유가 있습니다.')
            elif review0['fit_status'] == 'REVIEW':
                st.warning('Portfolio Fit = REVIEW · Factor 또는 Sector 등 필요한 분류/정보를 먼저 확인하세요.')
            else:
                st.error('Portfolio Fit = BLOCKED · 현재 계좌의 집중도 또는 위험상한 때문에 추가 위험을 늘리지 않습니다.')
            st.subheader('3. Capital-at-Risk')
            r1, r2, r3, r4 = st.columns(4)
            r1.metric('현재 종목 CAR', pct(review0['current_name_car']))
            r2.metric('현재 Portfolio CAR', pct(review0['portfolio_car']))
            r3.metric('현금 비중', pct(review0['cash_weight']))
            r4.metric('위험상한 추가금액', krw(review0['max_add_krw']) if review0['fit_status'] == 'PASS' else '0원')
            if review0['fit_status'] == 'PASS' and price_fit > 0:
                st.caption(f"정수주 반영: {review0['max_add_shares']:,}주 / {krw(review0['lot_adjusted_add_krw'])}")
            elif review0['fit_status'] == 'PASS':
                st.warning('Headroom 금액은 계산됐지만 현재가격이 없어 정수주 수량은 계산하지 않았습니다. 위의 현재가격(KRW)을 입력하고 저장하세요.')
            st.caption('CAR = 비중 × Plausible Downside. Portfolio CAR는 각 보유자산의 Bear Downside를 단순 합산한 스트레스 지표입니다.')
            st.subheader('4. 원하는 추가금액 테스트')
            st.caption("실제로 주문하는 기능이 아닙니다. '이 금액을 더 담는다면 Portfolio Gate를 통과하는가?'만 계산합니다.")
            requested_add_krw = st.number_input('검토할 추가금액(KRW)', min_value=0.0, value=0.0, step=10000.0, key='portfolio_fit_requested_krw')
            requested_add_weight = requested_add_krw / total_assets if total_assets > 0 else 0.0
            review = portfolio_fit_review(portfolio=portfolio, total_assets=total_assets, candidate_name=fit_company, candidate_ticker=ticker, plausible_downside=downside_fit, loss_budget=loss_budget, single_name_cap=single_cap, factor=factor_fit, sector=sector_fit, factor_cap=factor_cap_fit, sector_cap=sector_cap_fit, price_krw=price_fit, requested_add_weight=requested_add_weight, reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), factor_loadings=factor_loadings)
            t1, t2, t3, t4 = st.columns(4)
            t1.metric('테스트 상태', review['requested_status'])
            t2.metric('추가 비중', pct(requested_add_weight))
            t3.metric('추가 CAR', pct(review['incremental_car']))
            t4.metric('추가 후 종목 비중', pct(review['post_name_weight']))
            if requested_add_krw > 0:
                if review['requested_status'] == 'PASS':
                    st.success(review['requested_detail'])
                elif review['requested_status'] == 'REVIEW':
                    st.warning(review['requested_detail'])
                else:
                    st.error(review['requested_detail'])
                post_rows = [['Single-name', review['post_name_weight'], review['name_risk_cap']]]
                if review['post_factor_exposure'] is not None:
                    post_rows.append([f"Factor · {review['factor']}", review['post_factor_exposure'], review['factor_cap']])
                if review['post_sector_exposure'] is not None:
                    post_rows.append([f"Sector · {review['sector']}", review['post_sector_exposure'], review['sector_cap']])
                post_df = pd.DataFrame(post_rows, columns=['구분', '추가 후 비중', 'Cap'])
                post_df['추가 후 비중'] = post_df['추가 후 비중'].map(pct)
                post_df['Cap'] = post_df['Cap'].map(pct)
                st.dataframe(post_df, width='stretch', hide_index=True)
            st.info('Portfolio Fit PASS도 매수 신호가 아닙니다. 실제 실행은 Lifecycle · Execution Gate · Thesis Monitor · Portfolio Fit을 모두 따로 확인해야 합니다.')
