from __future__ import annotations
if True:
    st.title('Dashboard')
    p = normalize_portfolio(portfolio, total_assets if total_assets > 0 else None)
    s = portfolio_summary(p, total_assets if total_assets > 0 else None)
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap) if not watchlist.empty else watchlist
    recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric('Portfolio Assets', krw(s['assets_krw']))
    c2.metric('Known Positions', krw(s['known_value_krw']))
    c3.metric('Top Position', s['top_name'] or '-')
    c4.metric('Top Weight', pct(s['top_weight']))
    c5.metric('Bear CAR', pct(s['bear_car']))
    if recon['status'] != 'PASS':
        st.error(f"Portfolio reconciliation mismatch: declared {krw(recon['declared_total_assets'])} vs known {krw(recon['known_portfolio_value'])} (gap {krw(recon['gap_krw'])}). Trade funding should remain blocked until reconciled.")
    if s['top_weight'] > single_cap:
        st.warning(f'단일종목 비중이 Single-name Cap {pct(single_cap)}을 초과합니다. 신규매수보다 concentration risk를 먼저 확인하세요.')
    if not p.empty:
        st.subheader('Portfolio')
        cols = [c for c in ['name', 'current_value_krw', 'weight', 'bear_downside', 'capital_at_risk', 'factor'] if c in p.columns]
        st.dataframe(p[cols], width='stretch', hide_index=True)
        fx = factor_exposure(p)
        st.subheader('Factor Exposure')
        st.bar_chart(fx.set_index('factor')['weight'])
    st.subheader('Lifecycle State')
    if state_df.empty:
        st.info('Watchlist가 비어 있습니다.')
    else:
        cols = [c for c in ['name', 'price', 'lifecycle_state', 'state_reason', 'evidence_status', 'thesis_status', 'initial_ceiling', 'core_ceiling', 'bear_downside'] if c in state_df.columns]
        st.dataframe(state_df[cols], width='stretch', hide_index=True)
    clock = enrich_proof_clock(proof)
    if not clock.empty:
        urgent = clock[clock['clock_status'].isin(['OVERDUE', 'DUE SOON'])]
        if not urgent.empty:
            st.subheader('Proof Clock Alerts')
            st.dataframe(urgent[['company', 'proof_item', 'due_date', 'clock_status', 'days_to_due', 'status']], width='stretch', hide_index=True)
