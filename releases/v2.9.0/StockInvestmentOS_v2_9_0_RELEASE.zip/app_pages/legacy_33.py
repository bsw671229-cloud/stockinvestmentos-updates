from __future__ import annotations
if True:
    st.title('Position Sizing')
    st.caption("먼저 손실예산으로 '얼마까지 보유할 수 있는지' 계산하고, 아래 Execution Gate에서 '지금 실행 가능한지'를 따로 확인합니다.")
    shared_names = ['직접 입력'] + (watchlist['name'].fillna('').astype(str).tolist() if not watchlist.empty else [])
    sizing_company = st.selectbox('종목 공통가정 불러오기', shared_names, key='position_sizing_company', help='Watchlist 종목을 선택하면 현재가격과 Plausible Downside를 같은 종목 공통값에서 불러옵니다.')
    selected_wr = {}
    selected_ticker = ''
    if sizing_company != '직접 입력':
        sh = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(str(sizing_company))]
        if not sh.empty:
            selected_wr = sh.iloc[0].to_dict()
            selected_ticker = str(selected_wr.get('ticker', '') or '').strip()
    shared = resolve_shared_risk_assumptions(watchlist, sizing_company if sizing_company != '직접 입력' else '', selected_ticker, default_downside=0.35, default_price=10000.0 if sizing_company == '직접 입력' else 0.0)
    total = st.number_input('총자산(KRW)', 0.0, value=total_assets, step=100000.0)
    a, b, c = st.columns(3)
    downside = a.number_input('Plausible Downside', 0.001, 1.0, float(shared['plausible_downside']), format='%.3f', key=f'position_sizing_downside::{sizing_company}', help='Watchlist 종목에서는 이 값이 Portfolio Fit과 공유되는 공통 위험가정입니다.')
    loss = a.number_input('1회 허용손실률', 0.001, 0.2, loss_budget, format='%.3f')
    single = b.number_input('Single-name Cap', 0.001, 1.0, single_cap, format='%.3f')
    factor = b.number_input('Factor Headroom', 0.0, 1.0, 0.1, format='%.3f')
    liq = c.number_input('Liquidity Cap', 0.0, 1.0, 1.0, format='%.3f')
    strat = c.number_input('Strategy Cap', 0.0, 1.0, 1.0, format='%.3f')
    price = c.number_input('현재가격(KRW)', 0.0, value=float(shared['price_krw']), step=100.0, key=f'position_sizing_price::{sizing_company}', help='0원이면 정수주 수량을 계산할 수 없습니다.')
    if sizing_company != '직접 입력':
        if st.button('현재가격 / Downside 공통가정 저장', key='save_position_shared_assumptions'):
            try:
                new_watch, new_port, meta = sync_shared_risk_assumptions(watchlist, portfolio, sizing_company, selected_ticker, price, downside)
                save_csv(new_watch, 'watchlist.csv')
                if meta['portfolio_rows_synced'] > 0:
                    save_csv(new_port, 'portfolio.csv')
                st.success(f'{sizing_company} 공통 위험가정을 저장했습니다. 현재가격 {krw(price)} / Downside {pct(downside)}')
                st.rerun()
            except Exception as e:
                st.error(str(e))
    raw, final = final_position_max(loss, downside, single, factor, liq, strat)
    shares, target, actual = shares_for_weight(total, final, price)
    x1, x2, x3, x4 = st.columns(4)
    x1.metric('Raw Risk Max', pct(raw))
    x2.metric('Final Max', pct(final))
    x3.metric('위험상한 수량', f'{shares:,}주' if price > 0 else '가격 필요')
    x4.metric('Lot-adjusted Weight', pct(actual) if price > 0 else '-')
    st.caption('Final Max와 위험상한 수량은 목표비중/주문수량이 아니라 손실예산 기준의 상한입니다. Watchlist 종목은 현재가격과 Downside를 Portfolio Fit과 같은 값으로 저장할 수 있습니다.')
    st.divider()
    st.subheader('Execution Gate')
    st.caption('위험상한 수량과 실제 실행 가능 수량을 분리합니다. OBSERVE이면 0주이며, 가격 Ceiling도 함께 통과해야 합니다.')
    lifecycle_options = ['OBSERVE', 'INITIAL', 'CORE', 'MAX', 'ADD FREEZE', 'TRIM', 'EXIT']
    lifecycle_default = 'OBSERVE'
    if selected_wr:
        try:
            ss = add_states(pd.DataFrame([selected_wr]), portfolio, total_assets, loss_budget, single_cap)
            if not ss.empty:
                lifecycle_default = str(ss.iloc[0].get('lifecycle_state', 'OBSERVE'))
        except Exception:
            lifecycle_default = 'OBSERVE'
    lifecycle_index = lifecycle_options.index(lifecycle_default) if lifecycle_default in lifecycle_options else 0
    g1, g2 = st.columns(2)
    lifecycle = g1.selectbox('Lifecycle', lifecycle_options, index=lifecycle_index, key=f'position_sizing_lifecycle::{sizing_company}')
    default_no_chase = pd.to_numeric(pd.Series([selected_wr.get('no_chase_ceiling') if selected_wr else 0]), errors='coerce').iloc[0]
    default_no_chase = 0.0 if pd.isna(default_no_chase) else max(0.0, float(default_no_chase))
    no_chase = g2.number_input('No-Chase Ceiling(KRW)', min_value=0.0, value=default_no_chase, step=100.0, key=f'position_sizing_no_chase::{sizing_company}', help='0이면 가격 Gate를 확인할 수 없으므로 안전하게 BLOCKED 처리합니다.')
    gate = position_sizing_execution_gate(shares, lifecycle, price, no_chase, float(settings.get('trade_plan_pilot_fraction', 0.5)))
    executable_shares = int(gate['executable_shares'])
    executable_weight = executable_shares * price / total if total > 0 and price > 0 else 0.0
    e1, e2, e3, e4 = st.columns(4)
    e1.metric('Lifecycle', gate['lifecycle'])
    e2.metric('Price Gate', gate['price_gate'])
    e3.metric('Execution Status', gate['execution_status'])
    e4.metric('실행 가능 수량', f'{executable_shares:,}주')
    if gate['execution_status'] == 'PASS':
        st.success(f'Execution Gate 통과 · 단계별 실행 상한 {executable_shares:,}주 (총자산의 {pct(executable_weight)})')
        st.caption(f"Lifecycle 단계비율 {pct(gate['stage_fraction'])} 적용. INITIAL은 Settings의 Pilot Fraction, CORE는 75%, MAX는 100%를 사용합니다.")
    else:
        reasons = gate.get('reasons', [])
        if reasons:
            st.error('차단 이유\n- ' + '\n- '.join(reasons))
        else:
            st.error('Execution Gate가 BLOCKED입니다.')
    st.caption('이 화면은 검토용 계산 도구이며 증권사 주문을 전송하지 않습니다.')
