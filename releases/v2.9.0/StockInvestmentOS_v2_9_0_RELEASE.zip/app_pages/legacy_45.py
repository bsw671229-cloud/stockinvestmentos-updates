from __future__ import annotations
if True:
    st.title('Fill Reconciliation')
    st.caption('사용자가 증권사에서 이미 체결한 거래만 기록합니다. 이 화면은 주문을 전송하지 않습니다. Preview → 확인 → Apply 순서입니다.')
    st.info('v1.21.0-dev3: 선택한 Pre-Trade REVIEW_COMPLETE Packet과 실제 Fill을 연결해 계획수량·Locked Quote·Break-even·실제 체결가·Slippage를 감사합니다. Lineage MATCH는 계획과 체결의 일치 여부일 뿐 주문승인이나 투자승인이 아닙니다.')
    st.subheader('1. Pre-Trade Packet Handoff (선택)')
    _fill_packet_history = load_csv('pretrade_decision_packets.csv')
    _fill_freshness_history = load_csv('pretrade_packet_freshness_reviews.csv')
    _fill_packet_selected = None
    if _fill_packet_history.empty:
        st.caption('REVIEW_COMPLETE Pre-Trade Packet이 없습니다. 기존 Fill 기록 기능은 그대로 사용할 수 있습니다.')
        _fill_packet_option = -1
    else:
        if 'packet_status' not in _fill_packet_history.columns:
            _fill_packet_history['packet_status'] = ''
        _fill_packet_complete = _fill_packet_history.loc[_fill_packet_history['packet_status'].fillna('').astype(str).str.upper().eq('REVIEW_COMPLETE')].copy()
        if _fill_packet_complete.empty:
            st.caption('REVIEW_COMPLETE Packet이 없습니다. 기존 Fill 기록 기능은 그대로 사용할 수 있습니다.')
            _fill_packet_option = -1
        else:
            _fill_packet_indices = list(_fill_packet_complete.index[::-1])
            _fill_packet_options = [-1] + _fill_packet_indices

            def _fill_packet_label(_idx):
                if _idx == -1:
                    return '연결 안 함'
                _r = _fill_packet_complete.loc[_idx]
                return f"{_r.get('packet_id', '')} | {_r.get('donor', '')} → {_r.get('recipient', '')} | Decision {_r.get('decision_state', '')}"
            _fill_packet_option = st.selectbox('연결할 REVIEW_COMPLETE Packet', options=_fill_packet_options, index=0, format_func=_fill_packet_label, key='fill_pretrade_packet_index')
            if _fill_packet_option != -1:
                _fill_packet_selected = _fill_packet_complete.loc[_fill_packet_option].to_dict()
    if _fill_packet_selected is not None:
        _fill_packet_integrity = pretrade_packet_integrity(_fill_packet_selected)
        _latest_freshness = {}
        if _fill_freshness_history is not None and (not _fill_freshness_history.empty) and ('packet_id' in _fill_freshness_history.columns):
            _fhit = _fill_freshness_history.loc[_fill_freshness_history['packet_id'].fillna('').astype(str).str.strip().eq(str(_fill_packet_selected.get('packet_id', '') or '').strip())].copy()
            if not _fhit.empty:
                if 'evaluated_at' in _fhit.columns:
                    _fhit['_ts'] = pd.to_datetime(_fhit['evaluated_at'], errors='coerce', utc=True)
                    _fhit = _fhit.sort_values('_ts', ascending=False, na_position='last')
                _latest_freshness = _fhit.iloc[0].to_dict()
        ph1, ph2, ph3, ph4 = st.columns(4)
        ph1.metric('Packet Integrity', _fill_packet_integrity['integrity_status'])
        ph2.metric('Locked Decision', str(_fill_packet_selected.get('decision_state', '') or '-'))
        ph3.metric('Latest Saved Freshness', str(_latest_freshness.get('live_status', 'NO_RECORD') or 'NO_RECORD'))
        ph4.metric('Execution Authorization', 'NONE')
        pp1, pp2, pp3, pp4 = st.columns(4)
        pp1.metric('Locked Donor', str(_fill_packet_selected.get('donor', '') or '-'))
        pp2.metric('Planned Sell Qty', '-' if pd.isna(pd.to_numeric(pd.Series([_fill_packet_selected.get('quote_required_quantity', '')]), errors='coerce').iloc[0]) else f"{float(pd.to_numeric(pd.Series([_fill_packet_selected.get('quote_required_quantity', '')]), errors='coerce').iloc[0]):g}")
        pp3.metric('Locked Quote', krw(_fill_packet_selected.get('quote_price_krw', 0)))
        pp4.metric('Break-even', krw(_fill_packet_selected.get('break_even_sell_price_krw', 0)))
        st.caption('Packet Handoff는 과거 Pre-Trade 근거를 실제 Fill과 연결하기 위한 Audit Link입니다. Packet이 REVIEW 상태였다는 사실도 그대로 보존되며 Execution Authorization은 생성되지 않습니다.')
    st.subheader('2. 실제 체결 입력')
    names = portfolio['name'].dropna().astype(str).tolist()
    if not names:
        names = ['']
    _packet_donor = str(_fill_packet_selected.get('donor', '') or '') if _fill_packet_selected is not None else ''
    default_idx = names.index(_packet_donor) if _packet_donor in names else names.index('삼성전자') if '삼성전자' in names else 0
    name = st.selectbox('종목', names, index=default_idx, key='fill_name')
    prow = portfolio.loc[portfolio['name'].fillna('').astype(str).str.strip().eq(str(name).strip())]
    ticker_default = '' if prow.empty else str(prow.iloc[0].get('ticker', '') or '')
    qty_current = 0 if prow.empty else int(pd.to_numeric(pd.Series([prow.iloc[0].get('quantity')]), errors='coerce').fillna(0).iloc[0])
    a, b, c = st.columns(3)
    ticker = a.text_input('ticker', value=ticker_default)
    side = b.selectbox('실제 체결 방향', ['SELL', 'BUY'])
    quantity = c.number_input('실제 체결 수량', min_value=1, step=1, value=1)
    a, b, c = st.columns(3)
    fill_price = a.number_input('실제 평균 체결가', min_value=0.0, value=0.0, step=100.0)
    fees_tax = b.number_input('수수료+세금', min_value=0.0, value=0.0, step=100.0)
    current_qty_view = c.number_input('현재 프로그램 수량(참고)', min_value=0, value=int(qty_current), step=1, disabled=True)
    actual_fill_timestamp = st.text_input('Actual Fill Timestamp (ISO 8601 + timezone)', value='', key='actual_fill_timestamp', placeholder='예: 2026-09-21T20:15:30+09:00 / 반드시 실제 증권사 체결시각')
    fill_timestamp_confirmed = st.checkbox('Actual Fill Timestamp를 증권사 실제 체결내역에서 직접 확인했습니다.', value=False, key='actual_fill_timestamp_confirmed')
    note = st.text_input('메모', value='Actual broker fill recorded manually')
    confirmed_actual = st.checkbox('이 거래는 증권사에서 이미 실제 체결된 내역입니다.', value=False)
    if st.button('Fill Preview', type='primary'):
        if not confirmed_actual:
            st.error('실제 체결내역 확인 체크가 필요합니다. 주문 계획이나 가상 거래는 여기서 Apply하지 마세요.')
        else:
            try:
                preview, summary = preview_actual_fill(portfolio, watchlist, name, ticker, side, int(quantity), float(fill_price), float(fees_tax))
                st.session_state['fill_preview_df'] = preview
                st.session_state['fill_preview_summary'] = summary
                st.session_state['fill_preview_note'] = note
                if _fill_packet_selected is not None:
                    _lineage_preview = evaluate_pretrade_fill_link(_fill_packet_selected, _fill_freshness_history, fill_name=name, fill_ticker=ticker, fill_side=side, quantity=float(quantity), fill_price=float(fill_price), fees_tax=float(fees_tax), actual_fill_timestamp=actual_fill_timestamp, fill_timestamp_confirmed=fill_timestamp_confirmed, max_quote_age_minutes=float(settings.get('cash_repair_quote_max_age_minutes', 5.0)), future_tolerance_minutes=float(settings.get('cash_repair_quote_future_tolerance_minutes', 2.0)), max_current_evidence_age_minutes=float(settings.get('cash_repair_quote_max_age_minutes', 5.0)))
                    st.session_state['pretrade_fill_lineage_preview'] = _lineage_preview
                    st.session_state['pretrade_fill_packet_snapshot'] = _fill_packet_selected
                else:
                    st.session_state.pop('pretrade_fill_lineage_preview', None)
                    st.session_state.pop('pretrade_fill_packet_snapshot', None)
            except Exception as e:
                st.error(str(e))
    if 'fill_preview_summary' in st.session_state:
        s = st.session_state['fill_preview_summary']
        st.subheader('3. Preview Summary')
        m1, m2, m3, m4 = st.columns(4)
        m1.metric('Qty Before', int(s['quantity_before']))
        m2.metric('Qty After', int(s['quantity_after']))
        m3.metric('Cash Before', krw(s['cash_before']))
        m4.metric('Cash After', krw(s['cash_after']))
        n1, n2, n3 = st.columns(3)
        n1.metric('Gross Amount', krw(s['gross_amount']))
        n2.metric('Fees/Tax', krw(s['fees_tax']))
        n3.metric('Cash Delta', krw(s['cash_delta']))
        st.write(f"Position valuation reference: **{krw(s['market_price_reference'])}** / Known portfolio value before: **{krw(s['known_value_before'])}** / after preview: **{krw(s['known_value_after'])}**")
        if 'pretrade_fill_lineage_preview' in st.session_state:
            lp = st.session_state['pretrade_fill_lineage_preview']
            st.subheader('4. Pre-Trade ↔ Actual Fill Lineage Preview')
            l1, l2, l3, l4 = st.columns(4)
            l1.metric('Lineage Status', lp['lineage_status'])
            l2.metric('Fill Leg', lp['fill_leg'])
            l3.metric('Quote Age @ Fill', '-' if lp['quote_age_at_fill_minutes'] is None else f"{lp['quote_age_at_fill_minutes']:.1f} min")
            l4.metric('Execution Authorization', 'NONE')
            l5, l6, l7, l8 = st.columns(4)
            l5.metric('Planned Qty', '-' if lp['planned_quantity'] is None else f"{lp['planned_quantity']:g}")
            l6.metric('Actual Qty', f"{lp['actual_quantity']:g}")
            l7.metric('Locked Quote', krw(lp['locked_quote_price_krw']))
            l8.metric('Actual Fill', krw(lp['actual_fill_price_krw']))
            l9, l10, l11, l12 = st.columns(4)
            l9.metric('Price Slippage', '-' if lp['price_slippage_bps'] is None else f"{lp['price_slippage_bps']:.1f} bps")
            l10.metric('Break-even', krw(lp['break_even_price_krw']))
            l11.metric('Boundary', lp['price_boundary_status'])
            l12.metric('Freshness Evidence', lp['freshness_evidence_status'])
            if lp['lineage_status'] == 'MATCH':
                st.success('MATCH · 실제 Fill의 locked-plan terms가 Packet과 일치합니다. 이 상태는 투자/주문 승인이 아니라 사후 reconciliation 결과입니다.')
            elif lp['lineage_status'] == 'INVALIDATED':
                st.error('INVALIDATED · 연결하려는 Packet/Lineage 무결성 문제가 있습니다. 실제 Fill 자체는 기록할 수 있지만 이 Packet을 실행 근거로 연결해서는 안 됩니다.')
            else:
                st.warning('REVIEW · 실제 Fill은 기록할 수 있지만 Packet 대비 차이 또는 Freshness evidence 부족이 있습니다.')
            if lp['issues']:
                st.warning('Lineage Review 사유 · ' + ' | '.join(lp['issues']))
        with st.expander('Portfolio Preview'):
            st.dataframe(st.session_state['fill_preview_df'], width='stretch', hide_index=True)
        recon_preview = reconcile_portfolio(st.session_state['fill_preview_df'], total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
        st.info(f"Preview Reconciliation: {recon_preview['status']} / gap {krw(recon_preview['gap_krw'])}. 체결 후 실제 계좌 총자산이 변했다면 Settings의 Portfolio Assets도 실제 계좌와 맞춰야 합니다.")
        st.warning('Apply는 로컬 Portfolio와 Fill Ledger만 수정합니다. 증권사 주문을 만들거나 전송하지 않습니다.')
        if st.button('Actual Fill Apply'):
            preview = st.session_state['fill_preview_df']
            summary = st.session_state['fill_preview_summary']
            log = load_csv('execution_fills.csv')
            new_log = fill_log_row(summary, st.session_state.get('fill_preview_note', ''))
            _lineage_preview = st.session_state.get('pretrade_fill_lineage_preview')
            if _lineage_preview and _lineage_preview.get('fill_timestamp_status') == 'PASS' and ('fill_timestamp' in new_log.columns):
                new_log.loc[:, 'fill_timestamp'] = _lineage_preview.get('actual_fill_timestamp', '')
            save_csv(preview, 'portfolio.csv')
            save_csv(pd.concat([log, new_log], ignore_index=True), 'execution_fills.csv')
            if _lineage_preview:
                _fill_id = str(new_log.iloc[0].get('fill_id', '') or '') if not new_log.empty else ''
                _lineage_row = build_pretrade_fill_lineage_record(_lineage_preview, fill_id=_fill_id, note=st.session_state.get('fill_preview_note', ''))
                _lineage_hist = load_csv('pretrade_fill_lineage.csv')
                for _col in PRETRADE_FILL_LINEAGE_COLS:
                    if _col not in _lineage_hist.columns:
                        _lineage_hist[_col] = ''
                _lineage_hist = pd.concat([_lineage_hist[PRETRADE_FILL_LINEAGE_COLS], pd.DataFrame([_lineage_row])], ignore_index=True)
                save_csv(_lineage_hist, 'pretrade_fill_lineage.csv')
            st.session_state.pop('fill_preview_df', None)
            st.session_state.pop('fill_preview_summary', None)
            st.session_state.pop('fill_preview_note', None)
            st.session_state.pop('pretrade_fill_lineage_preview', None)
            st.session_state.pop('pretrade_fill_packet_snapshot', None)
            st.success('실제 체결내역을 로컬 Portfolio와 execution_fills.csv에 반영했습니다. 선택한 Packet이 있으면 pretrade_fill_lineage.csv에도 감사 Lineage를 저장했습니다.')
            st.rerun()
    st.subheader('5. Fill Ledger')
    fills = ensure_cols(load_csv('execution_fills.csv'), FILL_COLS)
    if fills.empty:
        st.info('기록된 실제 체결내역이 없습니다.')
    else:
        st.dataframe(fills.sort_values('fill_timestamp', ascending=False), width='stretch', hide_index=True)
        st.download_button('Fill Ledger CSV 받기', fills.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'execution_fills.csv', 'text/csv')
    _fill_lineage_history = load_csv('pretrade_fill_lineage.csv')
    if not _fill_lineage_history.empty:
        st.subheader('6. Pre-Trade ↔ Fill Lineage Ledger')
        st.dataframe(_fill_lineage_history.tail(30), width='stretch', hide_index=True)
