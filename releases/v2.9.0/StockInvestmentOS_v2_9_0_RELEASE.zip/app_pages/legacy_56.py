from __future__ import annotations
if True:
    st.title('Evidence Register')
    ev = load_csv('evidence.csv')
    edited = st.data_editor(ev, num_rows='dynamic', width='stretch')
    if st.button('Evidence 저장', type='primary'):
        verified_save_feedback(edited, 'evidence.csv', 'Evidence를 저장했습니다.')
