from __future__ import annotations
if True:
    st.title('Migration Manager')
    st.caption('Work-ready Project Migration / Data-Secrets Separation / Integrity Transfer Manager · 기존 설치본은 삭제하거나 이동하지 않는 non-destructive migration입니다.')
    _mg_layout = load_work_ready_layout(ROOT)
    if _mg_layout.get('active'):
        st.success('현재 실행 중인 코드가 WORK_READY_SEPARATED layout을 사용하고 있습니다.')
        mg0, mg1, mg2, mg3 = st.columns(4)
        mg0.metric('Layout', 'WORK_READY')
        mg1.metric('Code Root', Path(_mg_layout['code_root']).name)
        mg2.metric('Runtime Data', 'EXTERNAL')
        mg3.metric('Secrets', 'EXTERNAL')
        with st.expander('Active Work-ready paths', expanded=False):
            st.json({'work_root': _mg_layout.get('work_root'), 'code_root': _mg_layout.get('code_root'), 'runtime_data_root': _mg_layout.get('runtime_data_root'), 'secrets_root': _mg_layout.get('secrets_root'), 'control_root': _mg_layout.get('control_root'), 'secret_env_path': _mg_layout.get('secret_env_path')})
        _mg_home = Path(_mg_layout['home_root'])
        if st.button('현재 Work-ready Migration Integrity 재검증', key='work_ready_verify_active'):
            _mg_verify = work_ready_verify_migration(_mg_home)
            if _mg_verify.get('status') == 'READY_FOR_WORK_CUTOVER':
                st.success('Migration integrity = READY_FOR_WORK_CUTOVER')
            else:
                st.error('Migration integrity BLOCKED')
            st.json(_mg_verify)
        if st.button('Work-ready Launcher Repair', key='work_ready_launcher_repair'):
            _mg_launcher_repair = repair_work_ready_launcher(_mg_home)
            if _mg_launcher_repair.get('status') == 'REPAIRED':
                st.success('run_work_ready.bat 복구 완료 · 검증된 work/app/run.bat를 호출하도록 수정했습니다.')
            else:
                st.error('Launcher repair BLOCKED/FAILED')
            st.json(_mg_launcher_repair)
        st.info('Work에는 work/ 폴더만 연결하는 것을 권장합니다. runtime-data/와 secrets/는 Work 권한 루트 밖에 유지됩니다.')
        st.caption('최초 Migration code manifest는 이관 시점의 역사적 receipt입니다. Hotfix/Release 이후 현재 코드 무결성은 현재 Managed Code baseline으로 검증합니다.')
    else:
        st.info('현재는 Legacy layout입니다. Migration은 새 target으로 복사하며 기존 설치본을 그대로 보존합니다.')
        _mg_default = str(default_target_home(ROOT))
        _mg_target = st.text_input('Work-ready Migration Target Home', value=_mg_default, key='work_ready_migration_target')
        _mg_plan = work_ready_plan_migration(ROOT, Path(_mg_target))
        mgp1, mgp2, mgp3, mgp4, mgp5 = st.columns(5)
        mgp1.metric('Plan', _mg_plan['status'])
        mgp2.metric('Managed Code', 'CLEAN' if _mg_plan['managed_code']['clean'] else 'DRIFT')
        mgp3.metric('Code Files', _mg_plan['code_summary']['files'])
        mgp4.metric('Runtime Data Files', _mg_plan['data_summary']['files'])
        mgp5.metric('Secret Files', _mg_plan['secret_summary']['files'])
        if _mg_plan['blockers']:
            st.error('Migration BLOCKED · ' + ' | '.join(_mg_plan['blockers']))
        if _mg_plan['warnings']:
            st.warning(' | '.join(_mg_plan['warnings']))
        st.code(f"Target layout\n{_mg_plan['target_home']}\n├─ work/                  ← Work 권한 권장 루트\n│  ├─ app/                ← 코드\n│  └─ control/            ← releases/backups/update_logs\n├─ runtime-data/          ← Work root 밖\n├─ secrets/               ← Work root 밖\n└─ run_work_ready.bat", language='text')
        with st.expander('Migration Plan detail', expanded=False):
            st.json({'source_root': _mg_plan['source_root'], 'source_version': _mg_plan['source_version'], 'target_home': _mg_plan['target_home'], 'estimated_copy_bytes': _mg_plan['estimated_copy_bytes'], 'managed_code': _mg_plan['managed_code'], 'data_summary': _mg_plan['data_summary'], 'secret_summary': _mg_plan['secret_summary']})
        st.warning('실제 Migration은 실행 중인 Streamlit에서 시작하지 않습니다. runtime CSV 일관성을 위해 앱을 종료한 뒤 아래 CLI 또는 Work에서 실행하십시오.')
        st.code(f'python migration\\migrate_work_ready.py migrate --target "{_mg_target}"', language='text')
        st.caption('Migration은 source를 수정/삭제하지 않습니다. 실패하거나 검증이 BLOCKED이면 cutover하지 말고 기존 설치본을 계속 사용하십시오.')
    st.divider()
    st.subheader('Work-ready Migration CLI')
    st.code('python -m migration.migrate_work_ready plan\npython -m migration.migrate_work_ready migrate --target <TARGET_HOME>\npython -m migration.migrate_work_ready verify --target <TARGET_HOME>\npython -m migration.migrate_work_ready repair-launcher --target <TARGET_HOME>', language='text')
    st.caption('Migration/Software Update 상태는 투자 Execution Authorization과 분리됩니다. Migration Manager는 주문·포지션·Execution Authorization을 변경하지 않습니다.')
