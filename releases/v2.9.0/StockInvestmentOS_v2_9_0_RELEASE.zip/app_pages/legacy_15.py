from __future__ import annotations
if True:
    st.title('Thesis Monitor')
    st.caption('가격보다 먼저 투자 가설이 아직 살아 있는지 확인합니다. Thesis KPI · Evidence · Proof Clock · Add Freeze · Invalidation을 한 화면에 모읍니다.')
    plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    monitor = build_thesis_monitor(watchlist, state_df, plans, kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
    st.markdown('**초보자용 순서:** `Thesis → KPI → Evidence → Proof Clock → Add Freeze → 다음 확인`')
    st.caption('Add Freeze가 ON이면 가격이 싸져도 추가 위험을 늘리지 않습니다. 예상했던 Evidence가 기한 내 나오지 않는 것도 새로운 Evidence로 취급합니다.')
    if monitor.empty:
        st.info('아직 Thesis Monitor에서 확인할 종목이 없습니다. Watchlist에 종목을 먼저 추가하세요.')
    else:
        company_options = monitor['company'].fillna('').astype(str).tolist()
        selected = st.selectbox('확인할 종목', company_options, key='thesis_monitor_company')
        hit = monitor.loc[monitor['company'].astype(str).eq(str(selected))]
        if not hit.empty:
            r = hit.iloc[0].to_dict()
            c1, c2, c3, c4 = st.columns(4)
            c1.metric('현재 Lifecycle', str(r.get('lifecycle', '-')))
            c2.metric('Evidence', str(r.get('evidence_status', '-')))
            c3.metric('Add Freeze', str(r.get('add_freeze', '-')))
            c4.metric('Proof Clock', str(r.get('proof_status', '-')))
            if str(r.get('add_freeze', '')) == 'ON':
                st.error('Add Freeze = ON · 현재는 추가 위험을 늘리지 않는 상태입니다. 가격하락만으로 해제하지 마세요.')
            elif str(r.get('add_freeze', '')) == 'REVIEW':
                st.warning('Add Freeze = REVIEW · Evidence/KPI/Proof Clock 중 추가 확인이 필요합니다.')
            else:
                st.success('Add Freeze = OFF · 모니터링상 Hard Freeze는 없습니다. 이 상태 자체가 매수 신호는 아닙니다.')
            st.subheader('1. 투자 가설')
            thesis_summary = str(r.get('thesis_summary', '') or '').strip()
            if thesis_summary:
                st.write(thesis_summary)
            else:
                st.info('아직 Thesis Summary가 없습니다. 아래 편집 영역에서 한 문장으로 적어 두세요.')
            st.subheader('2. Thesis KPI')
            selected_kpis, selected_proof = selected_company_details(selected, kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
            if selected_kpis.empty:
                st.info('등록된 Thesis KPI가 없습니다. KPI Monitor에서 기본 KPI 템플릿 또는 핵심 KPI를 추가하세요.')
            else:
                kcols = ['metric', 'monitor_status', 'actual', 'unit', 'good_threshold', 'bad_threshold', 'as_of', 'next_check_date', 'source_url', 'note']
                st.dataframe(selected_kpis[[c for c in kcols if c in selected_kpis.columns]], width='stretch', hide_index=True)
                k1, k2, k3 = st.columns(3)
                k1.metric('주의 KPI', int(r.get('kpi_attention_count', 0) or 0))
                k2.metric('FAIL', int(r.get('kpi_fail_count', 0) or 0))
                k3.metric('PASS', int(r.get('kpi_pass_count', 0) or 0))
            st.subheader('3. Evidence / Proof Clock')
            e1, e2, e3 = st.columns(3)
            e1.metric('Evidence Status', str(r.get('evidence_status', '-')))
            e2.metric('Invalidation', str(r.get('invalidation_status', '-')))
            e3.metric('다음 확인일', str(r.get('next_check_date', '') or 'NO DATE'))
            if selected_proof.empty:
                st.info('등록된 Proof Clock이 없습니다. 필요한 Evidence와 기한을 Proof Clock에 추가하세요.')
            else:
                pcols = ['proof_item', 'due_date', 'clock_status', 'days_to_due', 'invalidation_signal', 'source_url', 'last_checked', 'note']
                st.dataframe(selected_proof[[c for c in pcols if c in selected_proof.columns]], width='stretch', hide_index=True)
            st.subheader('4. 행동 규칙')
            rule1, rule2, rule3 = st.columns(3)
            with rule1:
                st.markdown('**Add Rule**')
                st.write(str(r.get('add_rule', '') or '미작성'))
            with rule2:
                st.markdown('**Add Freeze Rule**')
                st.write(str(r.get('add_freeze_rule', '') or '미작성'))
            with rule3:
                st.markdown('**Invalidation Rule**')
                st.write(str(r.get('invalidation_rule', '') or '미작성'))
            st.subheader('5. 다음 확인')
            next_source = str(r.get('next_check_source', '') or 'NO DATE')
            next_detail = str(r.get('next_check_detail', '') or '')
            next_note = str(r.get('next_check_note', '') or '')
            if r.get('next_check_date'):
                st.info(f"{r.get('next_check_date')} · {next_source}" + (f' · {next_detail}' if next_detail else '') + (f'\n\n{next_note}' if next_note else ''))
            else:
                st.warning('다음 확인 날짜가 없습니다. Proof Clock 또는 Thesis Plan에 날짜를 넣어 주세요.')
            st.caption('Evidence 상태는 Investment State의 watchlist 값, KPI는 KPI Monitor, Proof Clock은 Proof Clock 화면의 데이터를 읽습니다.')
        st.divider()
        st.subheader('Thesis Plan 편집')
        st.caption('숫자 KPI는 KPI Monitor에서 관리하고, 여기서는 투자 가설과 행동 규칙을 문장으로 고정합니다.')
        edit_company = st.selectbox('편집할 종목', company_options, key='thesis_plan_edit_company')
        plan_hit = plans.loc[plans['company'].fillna('').astype(str).str.strip().eq(str(edit_company).strip())]
        current_plan = plan_hit.iloc[0].to_dict() if not plan_hit.empty else {c: '' for c in THESIS_PLAN_COLS}

        def _plan_txt(v):
            if v is None:
                return ''
            s = str(v)
            return '' if s.lower() in {'nan', 'none'} else s
        with st.form('thesis_plan_form'):
            thesis_summary_in = st.text_area('Thesis Summary', value=_plan_txt(current_plan.get('thesis_summary')), placeholder='예: 검증 자동화 수요 증가가 매출·현금흐름으로 반복 확인되면 가치가 커진다.', height=90)
            a, b = st.columns(2)
            with a:
                add_rule_in = st.text_area('Add Rule', value=_plan_txt(current_plan.get('add_rule')), placeholder='예: 가격 기준 통과 + Value 유지/상향 + Evidence 강화', height=110)
                invalidation_rule_in = st.text_area('Invalidation Rule', value=_plan_txt(current_plan.get('invalidation_rule')), placeholder='예: 핵심 고객 둔화 + FCF 구조적 악화가 동시에 확인되면 가설 재검토', height=110)
            with b:
                add_freeze_rule_in = st.text_area('Add Freeze Rule', value=_plan_txt(current_plan.get('add_freeze_rule')), placeholder='예: Evidence FAIL/STALE, Proof Overdue, KPI FAIL이면 추가매수 중단', height=110)
                next_check_date_in = st.text_input('Next Check Date', value=_plan_txt(current_plan.get('next_check_date')), placeholder='YYYY-MM-DD')
                next_check_note_in = st.text_area('Next Check Note', value=_plan_txt(current_plan.get('next_check_note')), placeholder='예: 다음 분기 실적 또는 중요 공시 중 먼저 발생하는 시점', height=70)
            note_in = st.text_area('Note', value=_plan_txt(current_plan.get('note')), height=70)
            save_plan = st.form_submit_button('Thesis Plan 저장', type='primary')
        if save_plan:
            d = pd.to_datetime(next_check_date_in, errors='coerce')
            if str(next_check_date_in).strip() and pd.isna(d):
                st.error('Next Check Date는 YYYY-MM-DD 형식으로 입력해 주세요.')
            else:
                values = {'thesis_summary': thesis_summary_in, 'add_rule': add_rule_in, 'add_freeze_rule': add_freeze_rule_in, 'invalidation_rule': invalidation_rule_in, 'next_check_date': '' if not str(next_check_date_in).strip() else d.date().isoformat(), 'next_check_note': next_check_note_in, 'note': note_in}
                updated = upsert_thesis_plan(plans, edit_company, values)
                save_csv(updated, 'thesis_plans.csv')
                st.success(f'{edit_company} Thesis Plan을 저장했습니다.')
                st.rerun()
    st.divider()
    st.subheader('전체 Thesis Monitor')
    if monitor.empty:
        st.info('표시할 데이터가 없습니다.')
    else:
        summary_cols = ['company', 'lifecycle', 'evidence_status', 'add_freeze', 'invalidation_status', 'kpi_worst_status', 'proof_status', 'proof_due_date', 'next_check_date', 'next_check_source', 'monitor_version']
        st.dataframe(monitor[[c for c in summary_cols if c in monitor.columns]], width='stretch', hide_index=True)
    st.caption('Thesis Monitor는 모니터링 도구입니다. READY/PASS/OFF도 자동매수 신호가 아니며 증권사 주문을 전송하지 않습니다.')
