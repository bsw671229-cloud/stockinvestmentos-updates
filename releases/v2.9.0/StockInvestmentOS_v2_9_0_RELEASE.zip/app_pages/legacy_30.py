from __future__ import annotations
if True:
    st.title(f'Reverse DCF / Market-Implied Expectations · {VERSION}')
    st.caption('현재가격이 요구하는 FCF 성장·현금창출력·CAP·할인율을 역산하고, 독립적으로 검토한 Fundamental Future와 비교합니다.')
    st.info('핵심 원칙: Reverse DCF의 Normalized FCF/share는 현재가격과 독립된 근거가 있어야 합니다. Price × FCF Yield 방식의 Watchlist proxy는 참고 진단으로는 볼 수 있지만, 독립적 Anchor로 확인되기 전에는 Market-implied Growth를 투자 Edge로 해석하지 않습니다.')
    names = watchlist['name'].dropna().astype(str).tolist()
    selected = st.selectbox('Watchlist 종목', ['직접 입력'] + names, key='reverse_dcf_company')
    d = {}
    if selected != '직접 입력':
        d = watchlist.loc[watchlist['name'].astype(str).eq(selected)].iloc[0].to_dict()
    st.subheader('1. Input Provenance / Anchor Integrity')
    default_price = float(pd.to_numeric(pd.Series([d.get('price', 0)]), errors='coerce').fillna(0).iloc[0])
    default_yield = float(pd.to_numeric(pd.Series([d.get('normalized_fcf_yield', 0.05)]), errors='coerce').fillna(0.05).iloc[0])
    default_conf = float(pd.to_numeric(pd.Series([d.get('fcf_confidence', settings.get('default_fcf_confidence', 0.9))]), errors='coerce').fillna(0.9).iloc[0])
    default_rr = float(pd.to_numeric(pd.Series([d.get('required_return', settings.get('default_required_return', 0.1))]), errors='coerce').fillna(0.1).iloc[0])
    default_tg = float(pd.to_numeric(pd.Series([d.get('terminal_growth', settings.get('default_terminal_growth', 0.02))]), errors='coerce').fillna(0.02).iloc[0])
    watchlist_fcf_proxy = default_price * default_yield * default_conf
    _fund_history = normalize_fundamental_snapshots(load_csv('fundamental_snapshots.csv'))
    latest_fundamental = {}
    latest_fy_fundamental = {}
    if selected != '직접 입력' and (not _fund_history.empty):
        latest_fundamental = latest_fundamental_snapshot(_fund_history, selected)
        _company_fund = _fund_history.loc[_fund_history['company'].fillna('').astype(str).eq(selected)].copy()
        if not _company_fund.empty:
            _fy_mask = _company_fund['source_period'].fillna('').astype(str).str.upper().isin(['FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'])
            _fy_candidates = _company_fund.loc[_fy_mask].copy()
            if not _fy_candidates.empty:
                _fy_candidates['_created_sort'] = pd.to_datetime(_fy_candidates['created_at'], errors='coerce', utc=True)
                _fy_candidates = _fy_candidates.sort_values('_created_sort', ascending=False, na_position='last')
                for _, _row in _fy_candidates.iterrows():
                    _candidate = _row.drop(labels=['_created_sort'], errors='ignore').to_dict()
                    if snapshot_integrity_status(_candidate) == 'OK' and pd.to_numeric(pd.Series([_candidate.get('fcf_per_share')]), errors='coerce').fillna(0).iloc[0] > 0:
                        latest_fy_fundamental = _candidate
                        break
    p1, p2, p3, p4 = st.columns(4)
    p1.metric('Watchlist Price', krw(default_price))
    p2.metric('Normalized FCF Yield', pct(default_yield))
    p3.metric('FCF Confidence', pct(default_conf))
    p4.metric('Price-linked FCF/share reference', krw(watchlist_fcf_proxy))
    if latest_fundamental:
        lf1, lf2, lf3, lf4 = st.columns(4)
        lf1.metric('Latest Fundamental Period', f"{latest_fundamental.get('source_business_year', '')} {latest_fundamental.get('source_period', '')}".strip() or '-')
        lf2.metric('Period FCF/share proxy', krw(latest_fundamental.get('fcf_per_share')))
        lf3.metric('Period ROIC proxy', pct(latest_fundamental.get('roic')))
        lf4.metric('Fundamental Hash', snapshot_integrity_status(latest_fundamental))
        _latest_period = str(latest_fundamental.get('source_period', '') or '').strip().upper()
        if _latest_period not in {'FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'}:
            st.caption('최신 Fundamental Snapshot은 중간기간입니다. Period FCF/share·Revenue/share·ROIC를 Reverse DCF의 연간 Normalized Anchor로 자동 변환하지 않습니다.')
    if latest_fy_fundamental:
        st.success('Hash OK + REVIEWED 성격의 Full-year Fundamental FCF/share Anchor를 사용할 수 있습니다.')
    else:
        st.warning('현재 저장된 Full-year Fundamental FCF/share Anchor가 없습니다. Reverse DCF의 주 모델에는 독립적인 Normalized FCF/share를 직접 입력하고 Source를 확인해야 합니다.')
    st.subheader('2. Independent Normalized Anchor')
    if selected != '직접 입력':
        st.markdown('### 2-1. OpenDART FY Anchor Builder')
        st.caption('저장된 FY Fundamental Snapshot이 없을 때, 최근 연차 OpenDART 원문에서 가격과 독립적인 FY FCF/share reference를 만들 수 있습니다.')
        _dart_key_reverse = str(st.session_state.get('dart_api_key', os.getenv('DART_API_KEY', '')) or '').strip()
        _selected_code = str(d.get('code', '') or '').strip().zfill(6)
        _reverse_corp_code = ''
        if latest_fundamental:
            _reverse_corp_code = str(latest_fundamental.get('source_corp_code', '') or '').strip()
        if not _reverse_corp_code:
            _corp_cache = ROOT / 'data' / 'dart_corp_codes.csv'
            if _corp_cache.exists() and _selected_code:
                try:
                    _reverse_codes = pd.read_csv(_corp_cache, dtype=str)
                    _reverse_corp_code = find_corp_code(_selected_code, _reverse_codes) or ''
                except Exception:
                    _reverse_corp_code = ''
        _latest_year = None
        _latest_period = ''
        if latest_fundamental:
            try:
                _latest_year = int(float(latest_fundamental.get('source_business_year', '')))
            except Exception:
                _latest_year = None
            _latest_period = str(latest_fundamental.get('source_period', '') or '').strip().upper()
        if _latest_year is not None:
            _default_fy_year = _latest_year if _latest_period in {'FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'} else _latest_year - 1
        else:
            _default_fy_year = 2025
        _fy_year = st.number_input('FY Source Year', min_value=2015, max_value=2100, value=int(_default_fy_year), step=1, key=f'reverse_fy_year::{selected}')
        _fy_key = f'reverse_fy_anchor::{selected}::{int(_fy_year)}'
        _fy_source = st.session_state.get(_fy_key, {})
        fyc1, fyc2 = st.columns([1, 3])
        if fyc1.button('OpenDART FY Source 불러오기', type='primary', disabled=not bool(_dart_key_reverse and _reverse_corp_code), key=f'reverse_load_fy::{selected}::{int(_fy_year)}'):
            try:
                _fy_raw = full_financials(_dart_key_reverse, _reverse_corp_code, int(_fy_year), '11011', 'CFS')
                if _fy_raw.empty:
                    raise RuntimeError(f'{int(_fy_year)} FY 연결 재무제표가 비어 있습니다.')
                _fy_summary = summarize_financials(_fy_raw)
                _fy_share_raw = stock_total_status(_dart_key_reverse, _reverse_corp_code, int(_fy_year), '11011')
                _fy_share_summary = summarize_share_count(_fy_share_raw)
                _fy_anchor = build_annual_source_anchor(_fy_summary, _fy_share_summary, business_year=int(_fy_year), period='FY')
                st.session_state[_fy_key] = {'anchor': _fy_anchor, 'summary': _fy_summary, 'share_summary': _fy_share_summary, 'raw': _fy_raw, 'share_raw': _fy_share_raw, 'corp_code': _reverse_corp_code}
                st.rerun()
            except Exception as e:
                st.error(f'FY Anchor Source 조회 실패: {e}')
        if not _dart_key_reverse:
            fyc2.warning('DART API Key가 필요합니다.')
        elif not _reverse_corp_code:
            fyc2.warning('DART corp_code를 찾지 못했습니다. OpenDART Auto에서 종목을 한 번 수집하거나 Corp Code Cache를 확인하세요.')
        elif _fy_source:
            _fy_anchor_view = dict(_fy_source.get('anchor', {}) or {})
            if _fy_anchor_view.get('ready'):
                fyc2.success(f'{int(_fy_year)} FY Source READY · 가격 독립 FCF/share reference 사용 가능')
            else:
                fyc2.warning(f'{int(_fy_year)} FY Source REVIEW · Extraction/Share Source 상태를 확인하세요.')
        else:
            fyc2.info(f'{int(_fy_year)} FY CFS + 주식수 Source를 불러옵니다.')
        if _fy_source:
            _fy_anchor_view = dict(_fy_source.get('anchor', {}) or {})
            fy1, fy2, fy3, fy4 = st.columns(4)
            fy1.metric('FY FCF proxy', krw(_fy_anchor_view.get('fcf_proxy')))
            fy2.metric('FY Share Count proxy', '-' if _fy_anchor_view.get('share_count_proxy') is None else f"{_fy_anchor_view['share_count_proxy']:,.0f}")
            fy3.metric('FY FCF/share reference', krw(_fy_anchor_view.get('fcf_per_share')))
            fy4.metric('FY ROIC proxy', pct(_fy_anchor_view.get('roic_proxy')))
            fya1, fya2, fya3 = st.columns(3)
            fya1.metric('Extraction', _fy_anchor_view.get('extraction_integrity_status', '-') or '-')
            fya2.metric('Share Source', _fy_anchor_view.get('share_status', '-') or '-')
            fya3.metric('FY Revenue/share', krw(_fy_anchor_view.get('revenue_per_share')))
            st.warning(_fy_anchor_view.get('warning', 'FY Source proxy입니다.'))
            with st.expander('FY Anchor Source Audit', expanded=False):
                _fy_summary_view = dict(_fy_source.get('summary', {}) or {})
                _fy_share_view = dict(_fy_source.get('share_summary', {}) or {})
                st.dataframe(pd.DataFrame([{'item': 'Revenue', 'value': _fy_anchor_view.get('revenue'), 'source': _fy_summary_view.get('revenue_source_account', '')}, {'item': 'FCF proxy', 'value': _fy_anchor_view.get('fcf_proxy'), 'source': f"{_fy_summary_view.get('cfo_source_account', '')} - {_fy_summary_view.get('capex_source_account', '')}"}, {'item': 'Share Count proxy', 'value': _fy_anchor_view.get('share_count_proxy'), 'source': f"OpenDART stockTotqySttus · {_fy_share_view.get('share_count_basis', '')}"}, {'item': 'Tax proxy', 'value': _fy_anchor_view.get('effective_tax_rate_proxy'), 'source': 'Pretax Income / Income Tax Expense'}, {'item': 'Invested Capital proxy', 'value': _fy_anchor_view.get('invested_capital_proxy'), 'source': 'Equity + Debt proxy - Cash'}]), width='stretch', hide_index=True)
    else:
        _fy_source = {}
        _fy_anchor_view = {}
    anchor_options = ['Manual Independent']
    if _fy_source and _fy_anchor_view.get('ready'):
        anchor_options.append('OpenDART FY Source')
    if latest_fy_fundamental:
        anchor_options.append('Latest FY Fundamental')
    if selected != '직접 입력':
        anchor_options.append('Watchlist Price-linked Diagnostic')
    anchor_choice = st.radio('Normalized FCF/share Anchor Source', anchor_options, horizontal=True, key=f'reverse_anchor_source::{selected}')
    price = st.number_input('Current Price', min_value=0.0, value=default_price, step=100.0, key=f'reverse_price::{selected}')
    anchor_source_code = ''
    anchor_confirmed = False
    anchor_period = ''
    anchor_hash = ''
    anchor_note = ''
    if anchor_choice == 'Manual Independent':
        normalized_fcf_ps = st.number_input('Normalized Annual FCF / share', min_value=0.0, value=0.0, step=100.0, key=f'reverse_fcf_ps_manual::{selected}', help='현재가격에서 역산하지 않은 독립적 연간 Normalized FCF/share를 입력합니다. FY 재무, 장기 평균, 보수적 정상화 등 사용한 근거를 Review Note에 남기세요.')
        anchor_note = st.text_input('FCF Anchor Source / Review Note', value='', key=f'reverse_fcf_anchor_note::{selected}', placeholder='예: 2025 FY CFO/FCF + cycle normalization, maintenance capex 별도 검토')
        anchor_confirmed = st.checkbox('Normalized FCF/share가 현재가격과 독립된 Fundamental Source/가정에서 나온 값임을 직접 확인했습니다.', key=f'reverse_fcf_anchor_confirm::{selected}')
        anchor_source_code = 'MANUAL_INDEPENDENT'
    elif anchor_choice == 'OpenDART FY Source':
        normalized_fcf_ps = float(_fy_anchor_view.get('fcf_per_share', 0) or 0)
        anchor_period = 'FY'
        anchor_note = f"{_fy_anchor_view.get('business_year', '')} FY OpenDART CFS + stock total-status"
        anchor_confirmed = st.checkbox('FY 재무제표의 CFO/유형자산취득, 주식수 Source, Tax/Invested Capital proxy를 직접 검토했고 이 값이 현재가격과 독립된 FY FCF/share reference임을 확인했습니다.', key=f'reverse_fy_anchor_confirm::{selected}')
        st.metric('Normalized Annual FCF/share', krw(normalized_fcf_ps))
        st.caption(anchor_note)
        anchor_source_code = 'DART_FY_SOURCE'
    elif anchor_choice == 'Latest FY Fundamental':
        normalized_fcf_ps = float(pd.to_numeric(pd.Series([latest_fy_fundamental.get('fcf_per_share')]), errors='coerce').fillna(0).iloc[0])
        anchor_period = str(latest_fy_fundamental.get('source_period', '') or '')
        anchor_hash = snapshot_integrity_status(latest_fy_fundamental)
        anchor_note = f"{latest_fy_fundamental.get('source_business_year', '')} {anchor_period} Fundamental Snapshot"
        st.metric('Normalized Annual FCF/share', krw(normalized_fcf_ps))
        st.caption(anchor_note)
        anchor_confirmed = True
        anchor_source_code = 'FUNDAMENTAL_FY'
    else:
        normalized_fcf_ps = watchlist_fcf_proxy
        st.metric('Price-linked FCF/share diagnostic', krw(normalized_fcf_ps))
        anchor_confirmed = st.checkbox('이 값이 Current Price × FCF Yield × Confidence의 price-linked proxy이며 독립적 Fundamental Anchor로 검증되지 않았음을 이해했습니다.', key=f'reverse_legacy_anchor_ack::{selected}')
        anchor_source_code = 'WATCHLIST_PRICE_LINKED'
    anchor_status = anchor_integrity_status(anchor_source_code, normalized_fcf_ps, manual_confirmed=anchor_confirmed, fundamental_hash_status=anchor_hash, fundamental_period=anchor_period, source_integrity_status=_fy_anchor_view.get('extraction_integrity_status', '') if anchor_source_code == 'DART_FY_SOURCE' else '', share_status=_fy_anchor_view.get('share_status', '') if anchor_source_code == 'DART_FY_SOURCE' else '')
    ag1, ag2, ag3 = st.columns(3)
    ag1.metric('Anchor Integrity', anchor_status['status'])
    ag2.metric('Normalized FCF/share', krw(normalized_fcf_ps))
    ag3.metric('Decision-use Gate', 'PASS' if anchor_status['decision_ready'] else 'REVIEW')
    if anchor_status['status'] == 'DIAGNOSTIC_ONLY':
        st.warning('Price-linked Watchlist proxy는 Diagnostic Only입니다. 이 값으로 계산한 Implied Growth는 현재가격과 입력 Anchor가 연결되어 있어 독립적인 Market-vs-Fundamental Edge로 사용하지 않습니다.')
    elif not anchor_status['decision_ready']:
        st.warning(f"Anchor Gate REVIEW · {anchor_status['reason']}. Market-implied 계산은 Independent Anchor 확인 후 활성화됩니다.")
    else:
        st.success(f"Independent Anchor PASS · {anchor_status['reason']}")
    if anchor_source_code == 'DART_FY_SOURCE' and anchor_status['decision_ready']:
        st.markdown('**FY Source Reference → Assumption 입력 보조**')
        _fy_revenue_ps_ref = _fy_anchor_view.get('revenue_per_share')
        _fy_roic_ref = _fy_anchor_view.get('roic_proxy')
        _revenue_key = f'reverse_revenue_ps::{selected}'
        _roic_key = f'reverse_normalized_roic::{selected}'

        def _reference_is_applied(input_key, reference_value):
            if reference_value is None:
                return False
            try:
                current_value = float(st.session_state.get(input_key, 0.0) or 0.0)
                reference_number = float(reference_value)
            except Exception:
                return False
            scale = max(1.0, abs(current_value), abs(reference_number))
            return abs(current_value - reference_number) <= scale * 1e-09
        revenue_reference_applied = _reference_is_applied(_revenue_key, _fy_revenue_ps_ref)
        roic_reference_applied = _reference_is_applied(_roic_key, _fy_roic_ref)
        reference_applied_count = int(revenue_reference_applied) + int(roic_reference_applied)
        st.markdown(f'**FY Reference 적용 상태 · {reference_applied_count}/2**')
        ref1, ref2 = st.columns(2)
        if ref1.button('✓ FY Revenue/share reference 적용됨' if revenue_reference_applied else 'FY Revenue/share reference 복사', type='primary' if revenue_reference_applied else 'secondary', disabled=_fy_revenue_ps_ref is None or revenue_reference_applied, key=f'reverse_copy_fy_revenue::{selected}'):
            st.session_state[_revenue_key] = float(_fy_revenue_ps_ref)
            st.rerun()
        if revenue_reference_applied:
            ref1.success('적용됨')
        if ref2.button('✓ FY ROIC proxy reference 적용됨' if roic_reference_applied else 'FY ROIC proxy reference 복사', type='primary' if roic_reference_applied else 'secondary', disabled=_fy_roic_ref is None or roic_reference_applied, key=f'reverse_copy_fy_roic::{selected}'):
            st.session_state[_roic_key] = float(_fy_roic_ref)
            st.rerun()
        if roic_reference_applied:
            ref2.success('적용됨')
        st.caption('버튼이 ✓ 적용됨으로 바뀌고 초록색 `적용됨` 표시가 나오면 Assumption 입력칸에 FY reference가 반영된 상태입니다. Revenue/share와 Long-run ROIC의 Human-confirmed 체크박스는 별도 검토 단계이므로 자동 선택되지 않습니다.')
    st.subheader('3. Market Model / Fundamental Assumptions')
    i1, i2, i3 = st.columns(3)
    years = i1.number_input('Explicit Forecast Years', min_value=1, max_value=15, value=5, step=1, key=f'reverse_years::{selected}')
    required_return = i1.number_input('Required Return / WACC Proxy', min_value=0.001, max_value=0.8, value=default_rr, step=0.005, format='%.4f', key=f'reverse_wacc::{selected}')
    terminal_growth = i1.number_input('Terminal Growth', min_value=-0.1, max_value=0.15, value=default_tg, step=0.005, format='%.4f', key=f'reverse_tg::{selected}')
    fundamental_base_growth = i2.number_input('Fundamental Base FCF CAGR', min_value=-0.8, max_value=2.0, value=0.06, step=0.01, format='%.4f', key=f'reverse_base_growth::{selected}')
    base_growth_confirmed = i2.checkbox('Base FCF CAGR 가정을 직접 검토했습니다.', key=f'reverse_base_growth_confirm::{selected}')
    normalized_roic = i2.number_input('Long-run Normalized ROIC (optional)', min_value=0.0, max_value=3.0, value=0.0, step=0.01, format='%.4f', key=f'reverse_normalized_roic::{selected}')
    roic_confirmed = i2.checkbox('Long-run Normalized ROIC 가정을 직접 검토했습니다.', key=f'reverse_roic_confirm::{selected}')
    normalized_revenue_ps = i3.number_input('Normalized Annual Revenue / share (optional)', min_value=0.0, value=0.0, step=100.0, key=f'reverse_revenue_ps::{selected}')
    revenue_confirmed = i3.checkbox('Revenue/share가 연간 Normalized Source임을 확인했습니다.', key=f'reverse_revenue_confirm::{selected}')
    fundamental_cap = i3.number_input('Fundamental Reinvestment Rate / CAP (optional)', min_value=0.0, max_value=3.0, value=0.0, step=0.01, format='%.4f', key=f'reverse_fundamental_cap::{selected}', help='장기 정상화 기준의 Fundamental Reinvestment Rate입니다. H1 Capital Δ / Period NOPAT를 자동 복사하지 않습니다.')
    cap_confirmed = i3.checkbox('Fundamental CAP/Reinvestment 가정을 직접 검토했습니다.', key=f'reverse_cap_confirm::{selected}')
    cap_zero_intentional = i3.checkbox('0% CAP를 의도적으로 사용합니다.', key=f'reverse_cap_zero_intent::{selected}', disabled=not bool(cap_confirmed and fundamental_cap == 0), help='0.0000은 기본 미입력값과 구분하기 어렵기 때문에, 실제로 장기 Reinvestment 0%를 가정할 때만 선택합니다.')
    readiness = assumption_readiness(anchor_ready=anchor_status['decision_ready'], base_growth_confirmed=base_growth_confirmed, revenue_confirmed=revenue_confirmed, roic_confirmed=roic_confirmed, cap_confirmed=cap_confirmed, cap_value=fundamental_cap, cap_zero_intentional=cap_zero_intentional)
    st.markdown('**Assumption Readiness**')
    st.dataframe(readiness, width='stretch', hide_index=True)
    if cap_confirmed and fundamental_cap == 0 and (not cap_zero_intentional):
        st.warning('Fundamental CAP가 0.0000인데 확인 체크가 선택되어 있습니다. 0% CAP를 실제 가정하는 것이 아니라면 확인 체크를 해제하거나 값을 입력하세요. 이 상태에서는 CAP Gap을 계산하지 않습니다.')
    if required_return <= terminal_growth:
        st.error('WACC/Required Return은 Terminal Growth보다 커야 합니다.')
        model_ready = False
    else:
        model_ready = bool(price > 0 and normalized_fcf_ps > 0 and anchor_status['decision_ready'])
    if not model_ready:
        st.info('주 Market-implied 계산은 Independent Anchor PASS + Price > 0 + WACC > Terminal Growth일 때 활성화됩니다.')
    else:
        st.subheader('4. Market-Implied Expectations')
        implied_growth_result = solve_implied_growth(price, normalized_fcf_ps, required_return, terminal_growth, int(years))
        implied_growth = implied_growth_result.get('value')
        if base_growth_confirmed:
            required_fcf_result = required_fcf_per_share(price, fundamental_base_growth, required_return, terminal_growth, int(years))
            implied_margin_result = solve_implied_fcf_margin(price, normalized_revenue_ps, fundamental_base_growth, required_return, terminal_growth, int(years)) if revenue_confirmed else {'value': None, 'status': 'REVENUE_ANCHOR_NOT_CONFIRMED'}
            implied_wacc_result = solve_implied_required_return(price, normalized_fcf_ps, fundamental_base_growth, terminal_growth, int(years))
            implied_tg_result = solve_implied_terminal_growth(price, normalized_fcf_ps, fundamental_base_growth, required_return, int(years))
        else:
            required_fcf_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
            implied_margin_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
            implied_wacc_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
            implied_tg_result = {'value': None, 'status': 'BASE_GROWTH_NOT_CONFIRMED'}
        translated_cap = capital_intensity_translation(implied_growth, normalized_roic) if roic_confirmed else {'value': None, 'status': 'NORMALIZED_ROIC_NOT_CONFIRMED'}
        cap_comparison = cap_gap(implied_growth, normalized_roic if roic_confirmed else None, fundamental_cap if cap_confirmed else None, zero_is_intentional=cap_zero_intentional)
        m1, m2, m3, m4 = st.columns(4)
        m1.metric(f'Market-implied {int(years)}Y FCF CAGR', pct(implied_growth))
        m2.metric('Required FCF/share @ Base Growth', krw(required_fcf_result.get('value')))
        m3.metric('Implied FCF Margin @ Base Growth', pct(implied_margin_result.get('value')))
        m4.metric('Market-implied CAP @ Normalized ROIC', pct(translated_cap.get('value')))
        m5, m6, m7, m8 = st.columns(4)
        m5.metric('Fundamental Base FCF CAGR', pct(fundamental_base_growth) if base_growth_confirmed else '-')
        m6.metric('Growth Expectation Gap', pct(fundamental_base_growth - implied_growth) if base_growth_confirmed and implied_growth is not None else '-')
        m7.metric('CAP Gap (Fundamental - Market)', pct(cap_comparison.get('gap')), help="Fundamental CAP가 실제 입력/확인된 경우에만 계산합니다. 0.0000 기본값은 별도 '0% CAP 의도' 확인 없이는 미입력으로 처리합니다.")
        m8.metric('Anchor Status', anchor_status['status'])
        if not base_growth_confirmed:
            st.warning('Base FCF CAGR가 아직 Human-confirmed되지 않았습니다. 따라서 Required FCF/share, Implied FCF Margin, Growth Expectation Gap, Implied WACC, Implied Terminal Growth처럼 Base Growth에 의존하는 값은 표시하지 않습니다.')
        st.markdown('**Single-variable Break-even Diagnostics**')
        b1, b2 = st.columns(2)
        b1.metric('Implied WACC @ Base Growth', pct(implied_wacc_result.get('value')))
        b2.metric('Implied Terminal Growth @ Base Growth', pct(implied_tg_result.get('value')))
        st.caption('Implied WACC와 Implied Terminal Growth는 각각 다른 변수를 고정한 단일변수 Break-even입니다. 두 숫자를 동시에 성립하는 하나의 시장 가정으로 해석하면 안 됩니다.')
        expectation_rows = [{'Expectation': 'FCF Growth', 'Market-implied': implied_growth, 'Fundamental / Input': fundamental_base_growth if base_growth_confirmed else None, 'Gap': fundamental_base_growth - implied_growth if base_growth_confirmed and implied_growth is not None else None, 'Status': implied_growth_result.get('status')}, {'Expectation': 'Normalized FCF/share', 'Market-required @ Base Growth': required_fcf_result.get('value'), 'Fundamental / Input': normalized_fcf_ps, 'Gap': normalized_fcf_ps - required_fcf_result.get('value') if required_fcf_result.get('value') is not None else None, 'Status': required_fcf_result.get('status')}, {'Expectation': 'FCF Margin', 'Market-required @ Base Growth': implied_margin_result.get('value'), 'Fundamental / Input': normalized_fcf_ps / normalized_revenue_ps if revenue_confirmed and normalized_revenue_ps > 0 else None, 'Gap': normalized_fcf_ps / normalized_revenue_ps - implied_margin_result.get('value') if revenue_confirmed and normalized_revenue_ps > 0 and (implied_margin_result.get('value') is not None) else None, 'Status': implied_margin_result.get('status')}, {'Expectation': 'Reinvestment / CAP', 'Market-implied translation': translated_cap.get('value'), 'Fundamental / Input': fundamental_cap if cap_confirmed else None, 'Gap': cap_comparison.get('gap'), 'Status': cap_comparison.get('status')}]
        st.dataframe(pd.DataFrame(expectation_rows), width='stretch', hide_index=True)
        current_fcf_margin = normalized_fcf_ps / normalized_revenue_ps if revenue_confirmed and normalized_revenue_ps > 0 else None
        pressure = expectation_pressure_summary(current_fcf_per_share=normalized_fcf_ps, required_fcf_per_share=required_fcf_result.get('value') if base_growth_confirmed else None, current_fcf_margin=current_fcf_margin, required_fcf_margin=implied_margin_result.get('value') if base_growth_confirmed else None, implied_growth=implied_growth, normalized_roic=normalized_roic if roic_confirmed else None)
        st.markdown('**Expectation Pressure Diagnostics**')
        ep1, ep2, ep3 = st.columns(3)
        ep1.metric('Required FCF / Anchor FCF', '-' if pressure.get('required_fcf_multiple') is None else f"{pressure['required_fcf_multiple']:.2f}x")
        ep2.metric('Required Margin - Anchor Margin', pct(pressure.get('required_margin_gap')))
        ep3.metric('Implied CAP / Reinvestment', pct(pressure.get('implied_cap')))
        if pressure.get('flags'):
            st.warning('Expectation Pressure REVIEW · ' + ' | '.join(pressure['flags']))
        else:
            st.success('Expectation Pressure: 현재 입력 기준으로 추가 경고 Flag가 없습니다.')
        if translated_cap.get('value') is not None and translated_cap.get('value') > 1.0:
            st.warning('현재 Market-implied Growth를 입력한 Normalized ROIC로 설명하려면 CAP/Reinvestment가 100%를 초과합니다. Growth·ROIC·CAP 정의를 다시 확인해야 하는 일관성 신호입니다.')
        st.subheader('5. Break-even FCF / Margin Ladder')
        if not base_growth_confirmed:
            st.caption('Break-even Ladder 자체는 가격·WACC·Terminal Growth에 대한 진단표라 계속 표시합니다. 다만 6% Base Growth 행은 아직 검토된 Fundamental Base 가정이 아닙니다.')
        growth_ladder = sorted(set([-0.05, 0.0, 0.05, 0.1, 0.15, round(float(fundamental_base_growth), 6), round(float(implied_growth), 6) if implied_growth is not None else 0.0]))
        break_even_table = break_even_fcf_table(price, growth_ladder, required_return, terminal_growth, int(years), normalized_revenue_ps if revenue_confirmed else None)
        st.dataframe(break_even_table, width='stretch', hide_index=True)
        st.caption('각 Growth 가정에서 현재가격을 정당화하려면 필요한 시작 FCF/share와, Revenue Anchor가 있으면 필요한 FCF Margin을 보여줍니다.')
        st.subheader('6. Bull / Base / Bear / Tail')
        _base_driver_ready = bool(roic_confirmed and cap_confirmed and (fundamental_cap > 0 or (fundamental_cap == 0 and cap_zero_intentional)))
        _driver_seed = scenario_driver_seed(base_roic=normalized_roic, base_cap=fundamental_cap, base_ready=_base_driver_ready)
        scenario_seed = pd.DataFrame([{'Scenario': 'Bear', 'FCF CAGR': -0.03, 'Normalized ROIC': None, 'Reinvestment Rate': None, 'Contraction Driver': '', 'WACC': min(0.8, required_return + 0.02), 'Terminal Growth': min(terminal_growth, 0.01), 'Probability': 0.25, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}, {'Scenario': 'Base', 'FCF CAGR': fundamental_base_growth, 'Normalized ROIC': _driver_seed.get('base_roic'), 'Reinvestment Rate': _driver_seed.get('base_cap'), 'Contraction Driver': '', 'WACC': required_return, 'Terminal Growth': terminal_growth, 'Probability': 0.5, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}, {'Scenario': 'Bull', 'FCF CAGR': 0.12, 'Normalized ROIC': None, 'Reinvestment Rate': None, 'Contraction Driver': '', 'WACC': max(terminal_growth + 0.012, required_return - 0.01), 'Terminal Growth': min(terminal_growth + 0.005, max(terminal_growth + 0.001, required_return - 0.021)), 'Probability': 0.2, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}, {'Scenario': 'Tail', 'FCF CAGR': -0.2, 'Normalized ROIC': None, 'Reinvestment Rate': None, 'Contraction Driver': '', 'WACC': min(0.9, required_return + 0.05), 'Terminal Growth': min(terminal_growth, 0.0), 'Probability': 0.05, 'Trigger': '', 'Action Rule': '', 'Reviewed': False}])
        _scenario_drafts = normalize_reverse_scenario_drafts(load_csv('reverse_dcf_scenario_drafts.csv'))
        _saved_scenario_table, _saved_scenario_at = scenario_editor_from_saved_draft(_scenario_drafts, selected)
        _scenario_seed_source = 'DEFAULT'
        if selected != '직접 입력' and (not _saved_scenario_table.empty):
            scenario_seed = _saved_scenario_table.copy()
            _scenario_seed_source = 'SAVED_DRAFT'
        sd1, sd2, sd3 = st.columns(3)
        sd1.metric('Scenario Draft Source', _scenario_seed_source)
        sd2.metric('Saved Draft', 'YES' if _scenario_seed_source == 'SAVED_DRAFT' else 'NO')
        sd3.metric('Last Saved', _saved_scenario_at or '-')
        if _scenario_seed_source == 'SAVED_DRAFT':
            st.success('저장된 Reverse DCF Scenario Draft를 자동으로 불러왔습니다. 앱/버전 재시작 후에도 이 Draft가 유지됩니다.')
        else:
            st.caption('아직 저장된 Scenario Draft가 없습니다. 아래 입력 후 `Scenario Draft 저장`을 누르면 다음 재시작부터 자동 복원됩니다.')
        st.markdown('**Scenario Input Guide**')
        st.caption('ROIC/CAP는 자동으로 정답을 채우지 않습니다. 양(+)의 성장 Scenario는 입력한 한쪽 Driver를 기준으로 다른 쪽 Driver의 일관성 수준을 계산합니다. Bear/Tail처럼 FCF CAGR가 음수이면 음수 CAP를 역산하지 않고 Contraction Driver를 사람이 직접 기술합니다.')
        template_df = scenario_template_text()
        with st.expander('Trigger / Action Rule 템플릿 보기', expanded=False):
            st.dataframe(template_df, width='stretch', hide_index=True)
            st.caption('템플릿의 [기준]/[기간]은 사용자가 실제 KPI와 Evidence에 맞게 채워야 합니다. 버튼 하나로 자동 승인하거나 Reviewed를 체크하지 않습니다.')
        scenario_input = st.data_editor(scenario_seed, width='stretch', hide_index=True, disabled=['Scenario'], column_config={'FCF CAGR': st.column_config.NumberColumn('FCF CAGR', format='%.2f'), 'Normalized ROIC': st.column_config.NumberColumn('Normalized ROIC', format='%.2f', help='시나리오별 장기 ROIC 가정. 자동 채우지 않습니다.'), 'Reinvestment Rate': st.column_config.NumberColumn('Reinvestment Rate', format='%.2f', help='시나리오별 장기 CAP/Reinvestment 가정. 자동 채우지 않습니다.'), 'Contraction Driver': st.column_config.TextColumn('Contraction Driver', help='FCF CAGR가 음수인 Scenario에서는 ROIC×CAP 역산 대신 Volume/Margin/Asset rationalization/Capital release 등 실제 수축 Driver를 기술합니다.'), 'WACC': st.column_config.NumberColumn('WACC', format='%.2f'), 'Terminal Growth': st.column_config.NumberColumn('Terminal Growth', format='%.2f'), 'Probability': st.column_config.NumberColumn('Probability', format='%.2f'), 'Trigger': st.column_config.TextColumn('Trigger', help='이 Scenario를 활성화/재검토하게 만드는 관찰 가능한 Evidence 조건'), 'Action Rule': st.column_config.TextColumn('Action Rule', help='Scenario가 현실화될 때 취할 행동 원칙. 자동 주문이 아니라 Human Review 규칙'), 'Reviewed': st.column_config.CheckboxColumn('Reviewed', help='Growth/ROIC/CAP/WACC/TG/Probability/Trigger/Action을 직접 검토했을 때만 체크')}, key=f'reverse_scenario_editor::{selected}')
        _saved_fingerprint = scenario_draft_fingerprint(_saved_scenario_table) if not _saved_scenario_table.empty else ''
        _current_fingerprint = scenario_draft_fingerprint(scenario_input)
        _draft_dirty = _current_fingerprint != _saved_fingerprint
        sc1, sc2, sc3 = st.columns([1, 1, 2])
        sc1.metric('Draft State', 'UNSAVED' if _draft_dirty else 'SAVED')
        if sc2.button('Scenario Draft 저장', type='primary', disabled=selected == '직접 입력' or not _draft_dirty, key=f'reverse_scenario_draft_save::{selected}'):
            _updated_drafts = upsert_reverse_scenario_draft(_scenario_drafts, selected, scenario_input, datetime.now().isoformat())
            verified_save_feedback(_updated_drafts, 'reverse_dcf_scenario_drafts.csv', f'{selected} Reverse DCF Scenario Draft를 저장했습니다.', rerun=True)
        with sc3:
            _has_saved_draft = not _saved_scenario_table.empty
            _draft_reset_confirm = st.checkbox('저장된 Draft를 삭제하고 기본값으로 초기화', key=f'reverse_scenario_draft_reset_confirm::{selected}', disabled=not _has_saved_draft)
            if st.button('Scenario Draft 삭제 / 초기화', disabled=not _has_saved_draft or not _draft_reset_confirm, key=f'reverse_scenario_draft_reset::{selected}'):
                _cleaned_drafts, _removed_drafts = delete_reverse_scenario_draft(_scenario_drafts, selected)
                if _removed_drafts > 0:
                    save_csv(_cleaned_drafts, 'reverse_dcf_scenario_drafts.csv')
                    st.session_state.pop(f'reverse_scenario_editor::{selected}', None)
                    st.session_state['_save_flash'] = ('success', f'{selected} Scenario Draft를 삭제하고 기본값으로 초기화했습니다.')
                    st.rerun()
        st.caption('Scenario Draft 저장은 작업 중 입력을 보존하는 기능입니다. APPROVED/Scenario Gate PASS를 의미하지 않으며, Driver / Trigger / Action / Reviewed Human Review 절차는 그대로 유지됩니다.')
        driver_requirement_table = scenario_driver_requirements(scenario_input)
        with st.expander('Growth ↔ ROIC ↔ CAP 입력 보조', expanded=True):
            st.dataframe(driver_requirement_table, width='stretch', hide_index=True)
            st.caption('예: ROIC를 먼저 입력하면 `CAP required @ entered ROIC`가 계산됩니다. 이 값은 입력 보조용이며 Scenario 표에 자동 반영하지 않습니다.')
        scenario_result, scenario_summary = scenario_values(normalized_fcf_ps, scenario_input, price, int(years))
        st.markdown('**Trigger / Action 입력 보조 · 직접 편집 가능**')
        st.caption('이제 파란색 읽기 전용 카드가 아니라 직접 수정할 수 있는 입력칸입니다. 템플릿을 시작점으로 사용하되 [기준]/[기간]과 `예:` 문구는 실제 KPI/Evidence에 맞게 고친 뒤 Draft에 반영하세요.')
        _template_lookup = {row['Scenario']: row for _, row in template_df.iterrows()}
        _helper_version = _saved_fingerprint[:10] if _saved_fingerprint else 'default'
        template_cols = st.columns(4)
        for _idx, _scenario_name in enumerate(['Bear', 'Base', 'Bull', 'Tail']):
            _t = _template_lookup[_scenario_name]
            _scenario_hit = scenario_input.loc[scenario_input['Scenario'].fillna('').astype(str).eq(_scenario_name)]
            _current_row = _scenario_hit.iloc[0].to_dict() if not _scenario_hit.empty else {}
            _template_contraction = str(_t.get('Contraction Driver Template', '') or '').strip()
            _current_contraction = str(_current_row.get('Contraction Driver', '') or '').strip()
            _current_trigger = str(_current_row.get('Trigger', '') or '').strip()
            _current_action = str(_current_row.get('Action Rule', '') or '').strip()
            _default_contraction = _current_contraction if _current_contraction else _template_contraction
            _default_trigger = _current_trigger if _current_trigger else str(_t['Trigger Template'])
            _default_action = _current_action if _current_action else str(_t['Action Template'])
            with template_cols[_idx]:
                st.markdown(f'**{_scenario_name}**')
                if _template_contraction:
                    _edited_contraction = st.text_area('Contraction Driver', value=_default_contraction, height=105, key=f'scenario_helper_contraction::{selected}::{_scenario_name}::{_helper_version}')
                else:
                    _edited_contraction = ''
                _edited_trigger = st.text_area('Trigger', value=_default_trigger, height=105, key=f'scenario_helper_trigger::{selected}::{_scenario_name}::{_helper_version}')
                _edited_action = st.text_area('Action Rule', value=_default_action, height=105, key=f'scenario_helper_action::{selected}::{_scenario_name}::{_helper_version}')
                _text_same_as_draft = str(_edited_contraction or '').strip() == _current_contraction and str(_edited_trigger or '').strip() == _current_trigger and (str(_edited_action or '').strip() == _current_action)
                _has_current_scenario_text = bool(_current_trigger or _current_action or _current_contraction)
                _scenario_text_synced = bool(_text_same_as_draft and _has_current_scenario_text)
                if _scenario_text_synced:
                    st.success('✓ 현재 Scenario Draft와 동일')
                else:
                    st.warning('입력보조 내용에 Draft 미반영 변경이 있습니다.')
                if st.button(f'✓ {_scenario_name} Draft 반영됨' if _scenario_text_synced else f'{_scenario_name} 입력보조 → Draft 저장', type='primary' if _scenario_text_synced else 'secondary', disabled=bool(selected == '직접 입력' or _scenario_text_synced), key=f'scenario_helper_apply::{selected}::{_scenario_name}::{_helper_version}'):
                    _updated_scenario = apply_scenario_text_inputs(scenario_input, _scenario_name, contraction_driver=_edited_contraction, trigger=_edited_trigger, action_rule=_edited_action)
                    _updated_drafts = upsert_reverse_scenario_draft(_scenario_drafts, selected, _updated_scenario, datetime.now().isoformat())
                    st.session_state.pop(f'reverse_scenario_editor::{selected}', None)
                    verified_save_feedback(_updated_drafts, 'reverse_dcf_scenario_drafts.csv', f'{selected} · {_scenario_name} 입력보조 내용을 Scenario Draft에 저장했습니다. Reviewed는 다시 직접 확인해야 합니다.', rerun=True)
        st.caption('입력보조에서 편집 후 `Draft 저장`을 누르면 상단 Scenario 표와 영구 Draft CSV에 반영됩니다. Reviewed는 자동 체크되지 않고, 텍스트를 바꾸면 해당 Scenario의 Reviewed는 False로 되돌립니다.')
        s1, s2, s3 = st.columns(3)
        s1.metric('Probability Sum', pct(scenario_summary.get('probability_sum')))
        s2.metric('Probability-weighted Value (Math)', krw(scenario_summary.get('probability_weighted_value')))
        s3.metric('PW Upside / Downside (Math)', pct(scenario_summary.get('probability_weighted_upside')))
        if scenario_summary.get('status') != 'PASS':
            st.warning('Probability 합계 100%와 각 WACC > Terminal Growth 조건을 확인하세요.')
        st.dataframe(scenario_result, width='stretch', hide_index=True)
        st.markdown('**Scenario Driver Consistency**')
        driver_table, driver_summary = scenario_driver_diagnostics(scenario_input)
        d1, d2, d3, d4 = st.columns(4)
        d1.metric('Driver COMPLETE', driver_summary.get('complete', 0))
        d2.metric('Driver INCOMPLETE', driver_summary.get('incomplete', 0))
        d3.metric('CAP > 100%', driver_summary.get('cap_above_100pct', 0))
        d4.metric('WACC ≤ TG', driver_summary.get('wacc_tg_issues', 0))
        st.dataframe(driver_table, width='stretch', hide_index=True)
        st.caption('양(+)의 성장 Scenario에서는 ROIC × CAP로 장기 성장 일관성을 봅니다. `Growth - ROIC×CAP`은 투자판정 점수가 아니라 가정 간 불일치 진단값입니다. 음(-)의 성장 Scenario에서는 음수 CAP를 기계적으로 만들지 않고 Contraction Driver를 사용합니다.')
        st.markdown('**Scenario Governance Gate**')
        scenario_gate = scenario_governance_gate(scenario_input, scenario_summary, driver_table)
        g1, g2, g3, g4, g5 = st.columns(5)
        g1.metric('Scenario Gate', scenario_gate.get('status', 'REVIEW'))
        g2.metric('Driver', f"{scenario_gate.get('driver_complete', 0)}/{scenario_gate.get('driver_required', 0)}")
        g3.metric('Trigger', f"{scenario_gate.get('trigger_complete', 0)}/{scenario_gate.get('required_rows', 0)}")
        g4.metric('Action', f"{scenario_gate.get('action_complete', 0)}/{scenario_gate.get('required_rows', 0)}")
        g5.metric('Reviewed', f"{scenario_gate.get('reviewed_complete', 0)}/{scenario_gate.get('required_rows', 0)}")
        if scenario_gate.get('status') != 'PASS':
            st.warning('Scenario Decision-use Gate = REVIEW · ' + ' | '.join(scenario_gate.get('issues', [])))
            st.caption('Probability-weighted Value는 Valuation Math Diagnostic으로는 볼 수 있지만, ROIC/CAP Driver·Trigger·Action·Human Review가 모두 채워지기 전에는 완성된 Scenario Decision Model로 사용하지 않습니다.')
        else:
            st.success('Scenario Decision-use Gate PASS · Valuation Math / Drivers / Trigger / Action / Review가 모두 완성되었습니다.')
        _base_driver_status = ''
        if driver_table is not None and (not driver_table.empty):
            _base_hit = driver_table.loc[driver_table['Scenario'].fillna('').astype(str).eq('Base')]
            if not _base_hit.empty:
                _base_driver_status = str(_base_hit.iloc[0].get('Status', '') or '').upper()
        if not _base_driver_ready:
            if _base_driver_status == 'COMPLETE':
                st.success('Base Scenario ROIC/CAP Driver는 자동 seed가 아니라 사용자가 직접 입력해 COMPLETE 상태입니다.')
            else:
                st.info('Base Scenario ROIC/CAP Driver는 Fundamental CAP가 아직 Ready가 아니므로 자동 입력하지 않았습니다.')
        st.subheader('7. Growth × WACC Sensitivity')
        center_growth = implied_growth if implied_growth is not None else fundamental_base_growth
        growth_values = sorted(set((round(x, 8) for x in [max(-0.9, center_growth - 0.06), max(-0.9, center_growth - 0.03), center_growth, min(2.0, center_growth + 0.03), min(2.0, center_growth + 0.06)])))
        wacc_values = sorted(set((round(x, 8) for x in [max(terminal_growth + 0.005, required_return - 0.02), max(terminal_growth + 0.005, required_return - 0.01), required_return, min(0.8, required_return + 0.01), min(0.8, required_return + 0.02)])))
        sensitivity = sensitivity_matrix(normalized_fcf_ps, growth_values, wacc_values, terminal_growth, int(years))
        st.dataframe(sensitivity, width='stretch', hide_index=True)
        st.subheader('8. Decision Bridge')
        st.write('**확인 순서:** Independent FCF Anchor → Market-implied Growth → Break-even FCF/Margin → ROIC로 번역한 Market-implied CAP → Fundamental CAP → Bull/Base/Bear/Tail → Scenario Growth·ROIC·CAP 일관성 → Trigger → Action Rule → Human Review → Sensitivity.')
        st.caption('Fundamental Future와 Market-implied Future의 차이는 가정 차이입니다. 이 화면은 자동 매수·매도 판정을 하지 않습니다.')
        if selected != '직접 입력':
            b1, b2 = st.columns(2)
            b1.button('Scenario Refresh에서 Evidence 반영', key='reverse_dcf_to_scenario_refresh', on_click=_navigate, args=('Scenario Refresh', {'scenario_refresh_company': selected}))
            b2.button('Fundamental Engine 확인', key='reverse_dcf_to_fundamental', on_click=_navigate, args=('Fundamental Engine', {'fundamental_company': selected}))
