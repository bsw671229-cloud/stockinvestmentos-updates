from __future__ import annotations
if True:
    st.title('One-page Decision Summary')
    st.caption('여러 메뉴를 돌아다니지 않고 한 종목의 현재 상태, 막힌 이유, 위험상한, 실행 가능 수량, 가설/Portfolio 상태, 다음 확인을 한 화면에서 봅니다.')
    st.info('이 화면의 READY/PASS는 자동매수 신호가 아닙니다. 현재 데이터와 규칙이 어떤 행동을 허용하는지 요약하는 검토 화면입니다.')
    if watchlist.empty:
        st.warning('Watchlist가 비어 있습니다. Market Universe에서 종목을 먼저 등록하세요.')
    else:
        decision_names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        decision_company = st.selectbox('요약할 종목', decision_names, key='decision_summary_company')
        plans_d = normalize_thesis_plans(load_csv('thesis_plans.csv'))
        kpis_d = normalize_kpis(load_csv('thesis_kpis.csv'))
        summary = build_one_page_decision_summary(company=decision_company, watchlist=watchlist, portfolio=portfolio, proof=proof, thesis_plans=plans_d, kpis=kpis_d, total_assets=total_assets, loss_budget=loss_budget, single_name_cap=single_cap, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), pilot_fraction=float(settings.get('trade_plan_pilot_fraction', 0.5)), reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), stale_days=int(settings.get('kpi_stale_days', 120)), factor_loadings=factor_loadings)
        st.subheader('1. 지금 무엇을 해야 하나?')
        a1, a2, a3, a4 = st.columns(4)
        a1.metric('현재 행동', summary['action_ko'])
        a2.metric('Lifecycle', summary['lifecycle'])
        a3.metric('Execution', summary['action_code'] if summary['action_code'] == 'EXECUTION REVIEW' else 'PASS' if summary['executable_shares'] > 0 else 'BLOCKED')
        a4.metric('실행 가능 수량', f"{summary['executable_shares']:,}주")
        if summary['action_code'] in {'SYSTEM BLOCKED', 'EXIT REVIEW', 'RISK REPAIR', 'PORTFOLIO BLOCKED', 'EXECUTION BLOCKED', 'ADD FREEZE'}:
            st.error(f"**{summary['action_ko']}** · {summary['action_detail']}")
        elif summary['action_code'] in {'SYSTEM REVIEW', 'ASSUMPTION REVIEW', 'PORTFOLIO REVIEW', 'REVIEW'}:
            st.warning(f"**{summary['action_ko']}** · {summary['action_detail']}")
        else:
            st.success(f"**{summary['action_ko']}** · {summary['action_detail']}")
        st.subheader('2. 핵심 숫자')
        k1, k2, k3, k4, k5, k6 = st.columns(6)
        k1.metric('현재가격', krw(summary['price']))
        k2.metric('Downside', pct(summary['downside']))
        k3.metric('No-Chase', krw(summary['no_chase']))
        k4.metric('위험상한 수량', f"{summary['risk_ceiling_shares']:,}주")
        k5.metric('실행 가능 수량', f"{summary['executable_shares']:,}주")
        k6.metric('Portfolio 최대 추가', f"{summary['portfolio_max_add_shares']:,}주")
        if summary['risk_ceiling_shares'] > 0 and summary['executable_shares'] == 0:
            st.caption(f"초보자 핵심: **{summary['risk_ceiling_shares']:,}주 = 위험관리상 상한**, **0주 = 지금 실제 실행 가능 수량**입니다.")
        st.subheader('3. 왜 지금 이 상태인가?')
        if summary['reasons']:
            for reason in summary['reasons']:
                st.write(f'- {reason}')
        else:
            st.write('- 현재 핵심 Gate에서 별도 차단 이유가 없습니다.')
        st.subheader('4. 전체 투자 흐름')
        st.dataframe(summary['flow_rows'], width='stretch', hide_index=True)
        st.subheader('5. Thesis / Evidence')
        th1, th2, th3, th4 = st.columns(4)
        th1.metric('Assumption Approval', summary['assumption_approval'])
        th2.metric('Evidence', summary['evidence_status'])
        th3.metric('Add Freeze', summary['add_freeze'])
        th4.metric('Proof Clock', summary['proof_status'])
        thesis_summary = summary.get('thesis_summary', '')
        if thesis_summary:
            st.markdown('**투자 가설**')
            st.write(thesis_summary)
        else:
            st.info('Thesis Summary가 없습니다. Thesis Monitor에서 작성할 수 있습니다.')
        invalidation_rule = summary.get('invalidation_rule', '')
        if invalidation_rule:
            st.markdown('**가설 무효화 규칙**')
            st.write(invalidation_rule)
        add_rule = summary.get('add_rule', '')
        if add_rule:
            st.markdown('**Add Rule**')
            st.write(add_rule)
        st.subheader('5-1. Latest Scenario Refresh')
        decision_scenario_history = load_csv('scenario_refresh_reviews.csv')
        latest_scenario = latest_approved_refresh(decision_scenario_history, decision_company)
        if latest_scenario:
            decision_recon_history = load_csv('scenario_reconciliation_reviews.csv')
            decision_recon = reconciliation_status_for_scenario(decision_recon_history, company=decision_company, scenario_row=latest_scenario)
            sr1, sr2, sr3, sr4, sr5 = st.columns(5)
            sr1.metric('Refresh Event', str(latest_scenario.get('event_date', '') or '-'))
            sr2.metric('PW Value Δ', pct(latest_scenario.get('pw_value_delta', 0.0)))
            sr3.metric('Modeled Bear Downside', pct(latest_scenario.get('modeled_bear_downside', 0.0)))
            sr4.metric('Scenario Signal', str(latest_scenario.get('thesis_signal', '') or '-'))
            sr5.metric('Canonical Reconciliation', decision_recon.get('status', 'PENDING'))
            st.caption('Scenario Refresh는 Canonical Assumption이나 Lifecycle을 자동으로 바꾸지 않습니다. APPROVED는 사용자가 가정을 검토했다는 뜻이며 미래 결과의 확정을 뜻하지 않습니다.')
            st.button('Scenario → Canonical Reconciliation 검토', key='decision_to_scenario_reconciliation', on_click=_navigate, args=('Scenario Reconciliation', {'scenario_reconciliation_company': decision_company}))
        else:
            st.info('APPROVED Scenario Refresh가 없습니다. 새 실적/공시가 있으면 Scenario Refresh에서 첫 Baseline을 저장할 수 있습니다.')
        st.button('Scenario Refresh에서 가정 갱신 보기', key='decision_to_scenario_refresh', on_click=_navigate, args=('Scenario Refresh', {'scenario_refresh_company': decision_company}))
        st.subheader('5-2. Latest Evidence Provenance')
        decision_evidence_packets = load_csv('evidence_packets.csv')
        evidence_summary = approved_packet_summary(decision_evidence_packets, decision_company)
        if evidence_summary['status'] == 'NO APPROVED EVIDENCE':
            st.info('APPROVED Evidence Packet이 없습니다. 기존 Evidence Status는 Watchlist 원장을 그대로 사용합니다.')
        else:
            ep1, ep2, ep3, ep4, ep5 = st.columns(5)
            ep1.metric('Evidence Event', evidence_summary.get('event_date', '') or '-')
            ep2.metric('Signal', evidence_summary.get('evidence_signal', '') or '-')
            ep3.metric('Source Tier', evidence_summary.get('source_tier', '') or '-')
            ep4.metric('Freshness', evidence_summary.get('freshness_status', '') or '-')
            ep5.metric('Hash Integrity', evidence_summary.get('hash_status', '') or '-')
            st.caption(f"Provenance Status: **{evidence_summary.get('status', '-')}** · Evidence Packet은 사실/출처의 감사기록이며 Watchlist evidence_status를 자동 변경하지 않습니다.")
        st.button('Evidence Intake에서 원문·Provenance 보기', key='decision_to_evidence_intake', on_click=_navigate, args=('Evidence Intake', {'evidence_intake_company': decision_company}))
        st.subheader('5-3. Evidence → Decision Impact Review')
        decision_impact_reviews = load_csv('evidence_impact_reviews.csv')
        impact_summary = evidence_impact_status(decision_evidence_packets, decision_impact_reviews, decision_company)
        impact_status = impact_summary.get('status', '-')
        if impact_status == 'NO APPROVED EVIDENCE':
            st.info('APPROVED Evidence가 없어 Impact Review 대상도 없습니다.')
        elif impact_status == 'REVIEW REQUIRED':
            st.warning('Latest APPROVED Evidence가 아직 Thesis / Valuation / Risk 행동과 명시적으로 연결되어 검토되지 않았습니다.')
        elif impact_status == 'REVIEWED':
            ir1, ir2, ir3, ir4 = st.columns(4)
            ir1.metric('Impact Review', 'REVIEWED')
            ir2.metric('Thesis Impact', impact_summary.get('thesis_impact', '') or '-')
            ir3.metric('Valuation Action', impact_summary.get('valuation_action', '') or '-')
            ir4.metric('Scenario Action', impact_summary.get('scenario_action', '') or '-')
            st.caption(f"Add Freeze Review: **{impact_summary.get('add_freeze_action', '-')}** · Lifecycle Review: **{impact_summary.get('lifecycle_action', '-')}** · Portfolio Review: **{impact_summary.get('portfolio_action', '-')}**")
        else:
            st.error(f'Evidence Impact Status = {impact_status}. Evidence Intake와 Impact Review의 Hash/Link를 다시 확인하세요.')
        st.caption('Impact Review는 행동 후보를 구조화하는 감사기록입니다. Lifecycle, Add Freeze, Canonical, Scenario를 자동 변경하지 않습니다.')
        st.button('Evidence Impact Review 열기', key='decision_to_evidence_impact', on_click=_navigate, args=('Evidence Impact Review', {'evidence_impact_company': decision_company}))
        st.subheader('5-4. Decision Journal / Forecast Clock')
        decision_records_ds = load_csv('decision_records.csv')
        decision_outcomes_ds = load_csv('decision_outcome_reviews.csv')
        latest_decision_ds = latest_approved_decision(decision_records_ds, decision_outcomes_ds, decision_company)
        if not latest_decision_ds:
            st.info('APPROVED Decision Record가 없습니다. 현재 판단을 사전 기록하면 Proof Date 이후 Forecast Calibration이 가능합니다.')
        else:
            dj1, dj2, dj3, dj4, dj5 = st.columns(5)
            dj1.metric('Decision', latest_decision_ds.get('decision_type', '') or '-')
            dj2.metric('Action', latest_decision_ds.get('action', '') or '-')
            dj3.metric('Proof Date', latest_decision_ds.get('proof_date', '') or '-')
            dj4.metric('Outcome', latest_decision_ds.get('outcome_status', '') or '-')
            dj5.metric('Hash', latest_decision_ds.get('hash_status', '') or '-')
            st.caption(f"Proof Clock: **{latest_decision_ds.get('proof_status', '-')}** · Good Outcome ≠ Good Decision. 실제 결과는 Forecast Error 원인과 분리해 검토합니다.")
        st.button('Decision Journal 열기', key='decision_to_journal_v2', on_click=_navigate, args=('Decision Journal', {'decision_journal_company': decision_company}))
        st.subheader('6. Portfolio / Factor Risk / Capital Migration')
        p1, p2, p3, p4 = st.columns(4)
        p1.metric('Portfolio Fit', summary['portfolio_fit'])
        p2.metric('Factor Risk', summary.get('factor_breach_status', 'REVIEW'))
        p3.metric('Capital Migration Recipient', summary['migration_eligibility'])
        p4.metric('Integration Consistency', summary['integration_status'])
        if summary.get('factor_breach_status') == 'PRE-EXISTING BREACH':
            f1, f2, f3, f4 = st.columns(4)
            f1.metric('현재 Factor Exposure', pct(summary.get('factor_current_exposure', 0.0)))
            f2.metric('Factor Cap', pct(summary.get('factor_cap', 0.0)))
            f3.metric('Excess', pct(summary.get('factor_excess_exposure', 0.0)))
            f4.metric('신규 동일 Factor Headroom', pct(summary.get('factor_new_risk_headroom', 0.0)))
            largest = summary.get('largest_factor_contributor', '')
            if largest:
                st.warning(f"{summary.get('factor', '')}는 PRE-EXISTING BREACH입니다. 현재 가장 큰 기여자는 **{largest}**이고, Factor 기여는 {summary.get('largest_factor_contribution', 0.0):.2%}, Loading은 {summary.get('largest_factor_loading', 0.0):.1%}입니다. 이는 기여도 설명이지 매도 우선순위나 매도 권고가 아닙니다.")
            else:
                st.warning(f"{summary.get('factor', '')}는 PRE-EXISTING BREACH입니다. 같은 Factor의 신규 위험 Headroom은 0%입니다.")
            st.button('Factor Risk Repair에서 복구 시뮬레이션 보기', key='decision_to_factor_repair', on_click=_navigate, args=('Factor Risk Repair', {'factor_repair_factor': summary.get('factor', '')}))
        if summary['migration_eligibility'] == 'BLOCKED':
            st.caption('현재 이 종목은 Capital Migration의 Recipient 자격이 없습니다. Forward ER을 높게 입력해도 Lifecycle / Execution / Add Freeze / Portfolio Fit을 우회하지 않습니다.')
        else:
            st.caption('Recipient 자격은 통과했지만 실제 Capital Migration은 Donor와 Forward ER, 비용, Cash Reserve를 별도로 비교합니다.')
        st.subheader('7. 다음 확인')
        next_date = summary.get('next_check_date', '')
        next_detail = summary.get('next_check_detail', '')
        if next_date:
            st.info(f'다음 확인일: **{next_date}**' + (f'\n\n{next_detail}' if next_detail else ''))
        else:
            st.warning('다음 확인일이 없습니다. Thesis Monitor / Proof Clock에서 Evidence Clock을 설정하세요.')
        st.button('Action Planner에서 최종 행동 Gate 보기', key='decision_to_action_planner', on_click=_navigate, args=('Action Planner', {'action_planner_company': decision_company}))
        st.caption(f"Decision Summary Engine {summary['version']} · 이 화면은 증권사 주문을 전송하지 않습니다.")
