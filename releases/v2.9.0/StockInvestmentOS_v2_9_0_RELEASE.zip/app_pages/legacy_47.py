from __future__ import annotations
if True:
    st.title('Proof Clock')
    st.caption('예상 Evidence가 나오지 않는 것도 Evidence입니다. 공식 실적일을 알게 되면 due_date를 갱신하세요.')
    edited = st.data_editor(proof, num_rows='dynamic', width='stretch', key='proof_editor')
    if st.button('Proof Clock 저장', type='primary'):
        verified_save_feedback(edited, 'proof_clock.csv', 'Proof Clock을 저장했습니다.')
    clock = enrich_proof_clock(proof)
    if not clock.empty:
        order = {'OVERDUE': 0, 'DUE SOON': 1, 'OPEN': 2, 'NO DATE': 3, 'CLOSED': 4}
        clock['_order'] = clock['clock_status'].map(order).fillna(9)
        clock = clock.sort_values(['_order', 'due_date']).drop(columns=['_order'])
        st.dataframe(clock, width='stretch', hide_index=True)
        overdue = clock[clock['clock_status'] == 'OVERDUE']
        if not overdue.empty:
            st.warning(f'Overdue Proof: {len(overdue)}건. 가설이 유지된다고 자동 가정하지 마세요.')
