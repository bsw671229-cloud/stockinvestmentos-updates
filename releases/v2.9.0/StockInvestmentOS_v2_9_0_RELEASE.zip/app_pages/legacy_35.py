from __future__ import annotations
if True:
    st.title(f'Portfolio Risk 2.0 / {VERSION}')
    st.caption('Direct Bear CAR · Stress MRC · ETF Look-through · Factor · Economic Currency · FX Hedge · Liquidity를 한 화면에서 연결합니다.')
    st.info('이 화면은 Risk-only Workbench입니다. PASS는 매수 추천이 아니며 Lifecycle / Add Freeze / Evidence / Portfolio Fit / Price Gate를 우회하지 않습니다.')
    pr_corr_records = normalize_historical_correlation_records(load_csv('historical_correlation.csv'))
    pr_saved_corr = historical_correlation_matrix_from_records(pr_corr_records)
    pr_corr = st.session_state.get('stress_corr', pd.DataFrame())
    if not isinstance(pr_corr, pd.DataFrame):
        pr_corr = pd.DataFrame()
    if pr_corr.empty and (not pr_saved_corr.empty):
        pr_corr = pr_saved_corr.copy()
        st.session_state['stress_corr'] = pr_corr
    pr_corr_health = historical_correlation_source_health(pr_corr_records, portfolio, min_weight_coverage=float(settings.get('stress_corr_min_coverage', 0.6)), min_observations=int(settings.get('stress_corr_min_observations', 60)), max_data_age_days=int(settings.get('stress_corr_max_age_days', 10)))
    pr_snapshot = portfolio_stress_snapshot(portfolio, total_assets, pr_corr)
    portfolio_car_budget = float(settings.get('portfolio_car_budget', 0.25))
    liquidity_days_limit = float(settings.get('liquidity_days_limit', 5.0))
    fx_unhedged_cap = float(settings.get('fx_unhedged_cap', 0.15))
    corr_min_coverage = float(settings.get('stress_corr_min_coverage', 0.6))
    top_car_review_cap = float(settings.get('top_car_share_review_cap', 0.5))
    currency_lt_min_coverage = float(settings.get('currency_lookthrough_min_coverage', 0.8))
    budget_state = portfolio_risk_budget_snapshot(pr_snapshot, portfolio_car_budget)
    stress_reliability = stress_reliability_status(budget_state['corr_covered_weight'], min_coverage=corr_min_coverage, source_status=pr_corr_health['status'])
    concentration_state = risk_concentration_status(budget_state['top_car_share'], review_cap=top_car_review_cap)
    pr_holdings = ensure_cols(load_csv('etf_holdings.csv'), ETF_HOLDING_COLS)
    pr_lt = portfolio_lookthrough(portfolio, pr_holdings)
    direct_currency = direct_currency_exposure(portfolio, total_assets)
    if not pr_lt.empty:
        lookthrough_currency = exposure_summary(pr_lt, 'currency', total_assets if total_assets > 0 else None)
    else:
        lookthrough_currency = pd.DataFrame()
    currency_diag = currency_lookthrough_diagnostics(direct_currency, lookthrough_currency, cash_weight=budget_state['cash_weight'], min_coverage=currency_lt_min_coverage)
    st.subheader('1. Portfolio Risk Budget')
    r1, r2, r3, r4, r5, r6 = st.columns(6)
    r1.metric('Direct Bear Loss', pct(budget_state['direct_bear_loss']))
    r2.metric('Stress Proxy' if stress_reliability['decision_ready'] else 'Stress Proxy (Fallback)', pct(budget_state['stress_proxy']))
    r3.metric('Portfolio CAR Budget', pct(budget_state['portfolio_car_budget']))
    r4.metric('Direct Headroom', pct(budget_state['direct_headroom']))
    r5.metric('Cash Weight', pct(budget_state['cash_weight']))
    r6.metric('Risk Budget Gate', budget_state['status'])
    g1, g2, g3 = st.columns(3)
    g1.metric('Stress Reliability', stress_reliability['status'])
    g2.metric('Correlation Coverage', pct(stress_reliability['coverage']))
    g3.metric('Top CAR Concentration', concentration_state['status'])
    if budget_state['status'] == 'PRE_EXISTING_BREACH':
        st.warning('Portfolio Direct Bear Loss가 현재 CAR Budget을 초과합니다. 이는 자동 강제매도 신호가 아니라 기존 위험의 Risk Repair / 신규위험 제한 상태입니다.')
    else:
        st.success('현재 Direct Bear Loss는 Portfolio CAR Budget 이내입니다.')
    if stress_reliability['status'] == 'FALLBACK_DIRECT_CAR':
        st.warning('Correlation Coverage가 0%이므로 현재 Stress Proxy는 사실상 Direct CAR fallback입니다. 상관 스트레스로 해석하지 말고 Historical Correlation을 먼저 보강하세요.')
    elif stress_reliability['status'] == 'REVIEW':
        st.warning('Historical Correlation Coverage가 정책 최소치보다 낮아 Stress MRC 신뢰도가 제한됩니다.')
    if concentration_state['status'] == 'REVIEW':
        st.warning(f'Top CAR Share가 {top_car_review_cap:.0%} Review Cap을 초과합니다. 한 포지션이 Portfolio Bear Risk의 대부분을 설명하는지 확인하세요.')
    st.subheader('1B. Historical Correlation Source / Backfill')
    st.caption('가격이력 기반 Correlation Source를 저장해 앱 재시작 후에도 Stress MRC에 재사용합니다. 과거 상관은 위기 상관을 보장하지 않으며 Direct Bear Loss를 함께 봅니다.')
    hc1, hc2, hc3, hc4, hc5, hc6 = st.columns(6)
    hc1.metric('Correlation Source', pr_corr_health['status'])
    hc2.metric('Saved Period', pr_corr_health['period'] or '-')
    hc3.metric('Observations', pr_corr_health['observation_count'])
    hc4.metric('Ticker Count', pr_corr_health['ticker_count'])
    hc5.metric('Weight Coverage', pct(pr_corr_health['covered_weight']))
    hc6.metric('Data Age', '-' if pr_corr_health['data_age_days'] is None else f"{pr_corr_health['data_age_days']}일")
    st.caption(f"Sample: {pr_corr_health['sample_start'] or '-'} → {pr_corr_health['sample_end'] or '-'} · Reason: {pr_corr_health['reason']}")
    if pr_corr_health['missing_tickers']:
        st.warning('Correlation 미커버 Ticker: ' + ', '.join(pr_corr_health['missing_tickers']))
    hist_period_v2 = st.selectbox('Historical Correlation Period', ['6mo', '1y', '2y'], index=1, key='portfolio_risk_corr_period')
    p_corr = portfolio.copy()
    p_corr['ticker'] = p_corr.get('ticker', '').fillna('').astype(str).str.strip()
    usable_corr = p_corr.loc[p_corr['ticker'].ne('')].copy()
    if len(usable_corr) < 2:
        st.info('Ticker가 입력된 보유자산이 2개 이상 있어야 Historical Correlation을 계산할 수 있습니다.')
    elif st.button('Historical Correlation 계산 / 저장', type='primary', key='portfolio_risk_corr_build'):
        try:
            with st.spinner('가격 이력을 다운로드하고 Correlation Source를 만드는 중...'):
                _corr_prices = multi_price_matrix(usable_corr['ticker'].drop_duplicates().tolist(), hist_period_v2)
                _corr_matrix = returns_correlation(_corr_prices)
                _corr_records = historical_correlation_records_from_matrix(_corr_matrix, _corr_prices, period=hist_period_v2, source='connectors.market.multi_price_matrix')
            if _corr_records.empty:
                st.error('Correlation Source를 만들 가격이력이 충분하지 않습니다.')
            else:
                save_csv(_corr_records, 'historical_correlation.csv')
                st.session_state['stress_corr'] = historical_correlation_matrix_from_records(_corr_records)
                st.session_state['_save_flash'] = ('success', 'Historical Correlation Source를 저장했습니다.')
                st.rerun()
        except Exception as e:
            st.error(f'Historical Correlation 계산 실패: {e}')
    if not pr_corr.empty:
        with st.expander('저장된 Correlation Matrix', expanded=False):
            st.dataframe(pr_corr.style.format('{:.2f}'), width='stretch')
    st.subheader('2. Asset CAR / Stress MRC')
    pr_contrib = pr_snapshot.get('asset_contributions', pd.DataFrame())
    top_contrib = top_risk_contributors(pr_contrib, top_n=15)
    if top_contrib.empty:
        st.info('Asset Risk Contribution을 계산할 보유자산이 없습니다.')
    else:
        show_cols = ['name', 'ticker', 'current_value_krw', 'weight', 'bear_downside', 'capital_at_risk', 'direct_car_share', 'stress_mrc', 'stress_component', 'stress_component_share', 'stress_method']
        st.dataframe(top_contrib[[c for c in show_cols if c in top_contrib.columns]], width='stretch', hide_index=True)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric('Top CAR Share', pct(budget_state['top_car_share']))
        c2.metric('Risk HHI', f"{budget_state['hhi']:.4f}")
        c3.metric('Correlation Coverage', pct(budget_state['corr_covered_weight']))
        c4.metric('Top CAR Review Headroom', pct(concentration_state['headroom']))
    st.subheader('3. Look-through Exposure')
    pr_factor_raw = all_factor_exposures(portfolio, total_assets, factor_loadings, factor_cap=float(settings.get('factor_cap', 0.1)))
    pr_factor = factor_policy_view(pr_factor_raw, exempt_factors=('Cash',))
    exp_tabs = st.tabs(['Factor', 'Sector', 'Country', 'Currency'])
    with exp_tabs[0]:
        if pr_factor.empty:
            st.info('Factor Exposure가 없습니다.')
        else:
            factor_cols = ['factor', 'policy_scope', 'lookthrough_exposure', 'policy_cap', 'excess_exposure', 'breach_status', 'new_risk_headroom', 'approved_assets', 'conservative_assets', 'stale_assets']
            st.dataframe(pr_factor[[c for c in factor_cols if c in pr_factor.columns]], width='stretch', hide_index=True)
    for _tab, _dim in zip(exp_tabs[1:], ['sector', 'country', 'currency']):
        with _tab:
            if not pr_lt.empty:
                _ex = exposure_summary(pr_lt, _dim, total_assets if total_assets > 0 else None)
            elif _dim == 'currency':
                _ex = direct_currency
            else:
                _ex = pd.DataFrame()
            if _ex.empty:
                st.info(f'{_dim} Exposure 데이터가 없습니다.')
            else:
                st.dataframe(_ex, width='stretch', hide_index=True)
    st.markdown('**Direct Currency vs Economic Look-through Currency**')
    x1, x2, x3, x4 = st.columns(4)
    x1.metric('Direct Foreign Currency', pct(currency_diag['direct_foreign_weight']))
    x2.metric('Look-through Foreign Currency', pct(currency_diag['lookthrough_foreign_weight']))
    x3.metric('Hidden FX via KRW Wrappers', pct(currency_diag['hidden_foreign_weight']))
    x4.metric('Currency Look-through Coverage', pct(currency_diag['lookthrough_coverage']))
    if currency_diag['status'] != 'PASS':
        st.warning(f"Economic Currency Coverage = {currency_diag['status']} · {currency_diag['reason']}. KRW로 거래되는 해외자산 ETF는 Direct Currency만 보면 외화 경제노출을 놓칠 수 있습니다.")
    elif currency_diag['hidden_foreign_weight'] > 0:
        st.info('직접 거래통화보다 Look-through 외화노출이 더 큽니다. KRW 상장 해외 ETF의 underlying FX exposure가 포함될 수 있습니다.')
    st.subheader('4. Liquidity Operational Overlay')
    st.caption('Liquidity만 관리합니다. FX는 5A Asset / Wrapper Economic FX와 5B Business FX에서 별도로 검토합니다. Days-to-Exit는 Market Volume Source Assist로 계산을 보조할 수 있지만 Human Review 없이 자동 승인하지 않습니다.')
    st.markdown('**4A. Market Volume Source Assist**')
    st.caption('정상시장 거래량 proxy입니다. Days-to-Exit = 보유수량 ÷ (최근 ADV × 참여율)로 계산합니다. Bid-Ask spread, 시장충격, 거래정지, 위기시 거래량 급감은 반영하지 않으므로 Stress Liquidity 보장이 아닙니다.')
    la1, la2, la3 = st.columns(3)
    liq_history_period = la1.selectbox('Volume History Period', ['1mo', '3mo', '6mo', '1y'], index=1, key='liquidity_source_history_period')
    liq_adv_window = int(la2.number_input('ADV Window Days', 5, 120, int(settings.get('liquidity_adv_window_days', 20)), step=5, key='liquidity_source_adv_window'))
    liq_participation = float(la3.number_input('Participation Rate', 0.01, 1.0, float(settings.get('liquidity_participation_rate', 0.1)), step=0.01, format='%.2f', key='liquidity_source_participation', help='일평균 거래량 중 실제 청산에 사용한다고 가정하는 비율. 기본 10%는 운영 proxy이며 자동 승인값이 아닙니다.'))
    liq_min_obs = int(settings.get('liquidity_min_volume_observations', 10))
    saved_liq_assist = normalize_liquidity_source_assist(load_csv('liquidity_source_assist.csv'))
    if st.button('Liquidity Source Assist 계산 / 저장', type='primary', key='liquidity_source_assist_build'):
        _assist_rows = []
        for _, _asset in portfolio.iterrows():
            _asset_name = str(_asset.get('name', '') or '').strip()
            _asset_type = str(_asset.get('asset_type', '') or '').strip().lower()
            if not _asset_name or _asset_type == 'cash' or _asset_name.lower() in {'cash', '현금'}:
                continue
            _ticker = str(_asset.get('ticker', '') or '').strip()
            _market = str(_asset.get('market', '') or '').strip()
            _quantity = pd.to_numeric(pd.Series([_asset.get('quantity', None)]), errors='coerce').iloc[0]
            try:
                _hist = price_history(_ticker, _market, liq_history_period)
                _assist_row = liquidity_source_assist_from_history(name=_asset_name, ticker=_ticker, market=_market, quantity=None if pd.isna(_quantity) else float(_quantity), history=_hist, history_period=liq_history_period, volume_window_days=liq_adv_window, participation_rate=liq_participation, min_observations=liq_min_obs, source='connectors.market.price_history')
            except Exception as e:
                _assist_row = liquidity_source_assist_from_history(name=_asset_name, ticker=_ticker, market=_market, quantity=None if pd.isna(_quantity) else float(_quantity), history=pd.DataFrame(), history_period=liq_history_period, volume_window_days=liq_adv_window, participation_rate=liq_participation, min_observations=liq_min_obs, source='connectors.market.price_history')
                _assist_row['issues'] = (_assist_row.get('issues', '') + ' | ').strip(' |') + 'PRICE_HISTORY_ERROR: ' + str(e)
                _assist_row['status'] = 'REVIEW'
            _assist_rows.append(_assist_row)
        _assist_df = normalize_liquidity_source_assist(pd.DataFrame(_assist_rows))
        save_csv(_assist_df, 'liquidity_source_assist.csv')
        st.session_state['_save_flash'] = ('success', 'Liquidity Source Assist를 계산/저장했습니다. READY proxy도 Human Review 전에는 승인값이 아닙니다.')
        st.rerun()
    saved_liq_assist = normalize_liquidity_source_assist(load_csv('liquidity_source_assist.csv'))
    liq_assist_summary = liquidity_source_assist_summary(saved_liq_assist, portfolio, total_assets)
    ls1, ls2, ls3 = st.columns(3)
    ls1.metric('Assist READY', liq_assist_summary['ready_assets'])
    ls2.metric('Assist REVIEW', liq_assist_summary['review_assets'])
    ls3.metric('Assist Weight Coverage', pct(liq_assist_summary['weight_coverage']))
    if not saved_liq_assist.empty:
        assist_cols = ['name', 'ticker', 'quantity', 'observation_count', 'avg_daily_volume_shares', 'median_daily_volume_shares', 'participation_rate', 'days_to_exit_proxy', 'last_date', 'status', 'issues']
        st.dataframe(saved_liq_assist[[c for c in assist_cols if c in saved_liq_assist.columns]], width='stretch', hide_index=True)
    st.markdown('**4B. Human-confirmed Liquidity Overlay**')
    liquidity_overlays = normalize_liquidity_overlays(load_csv('liquidity_operational_overlays.csv'))
    legacy_risk_overlays = normalize_risk_overlays(load_csv('asset_risk_overlays.csv'))
    liquidity_editor = liquidity_overlay_editor_rows(portfolio, liquidity_overlays, legacy_overlays=legacy_risk_overlays)
    if not saved_liq_assist.empty and saved_liq_assist['status'].fillna('').astype(str).str.upper().eq('READY').any():
        _liq_assist_confirm = st.checkbox('READY Liquidity Source Assist의 계산식/ADV/참여율을 검토했습니다. Days-to-Exit와 Source만 Overlay에 복사하며 Reviewed는 자동 체크하지 않습니다.', key='liquidity_source_assist_confirm')
        if st.button('READY Assist → Liquidity Overlay 입력 보조', disabled=not _liq_assist_confirm, key='liquidity_source_assist_apply'):
            _liq_overlay_applied, _liq_apply_count = apply_liquidity_assist_to_overlay(liquidity_editor, saved_liq_assist)
            if _liq_apply_count <= 0:
                st.info('반영할 READY Liquidity Source Assist가 없습니다.')
            else:
                verified_save_feedback(_liq_overlay_applied, 'liquidity_operational_overlays.csv', f'READY Liquidity Assist {_liq_apply_count}건을 Overlay 입력 보조에 반영했습니다. Reviewed는 자동 체크하지 않았습니다.', rerun=True)
    liquidity_overlays = normalize_liquidity_overlays(load_csv('liquidity_operational_overlays.csv'))
    liquidity_editor = liquidity_overlay_editor_rows(portfolio, liquidity_overlays, legacy_overlays=legacy_risk_overlays)
    edited_liquidity = st.data_editor(liquidity_editor, width='stretch', hide_index=True, disabled=['name', 'ticker', 'updated_at'], column_config={'liquidity_days_to_exit': st.column_config.NumberColumn('Liquidity Days-to-Exit', min_value=0.0, step=0.01, format='%.2f', help='정상시장 가정의 청산일수. Source Assist proxy를 사용할 경우 ADV/참여율 가정을 직접 검토하세요.'), 'reviewed': st.column_config.CheckboxColumn('Reviewed', help='Days-to-Exit와 Source를 직접 검토했을 때만 체크'), 'source': st.column_config.TextColumn('Source', help='거래대금/거래량/ETF 유동성/운용사 자료 또는 Source Assist 근거')}, key='portfolio_liquidity_overlay_editor')
    if st.button('Liquidity Operational Overlay 저장', type='primary', key='portfolio_liquidity_overlay_save'):
        _saved_liquidity = liquidity_overlay_save_rows(edited_liquidity)
        verified_save_feedback(_saved_liquidity, 'liquidity_operational_overlays.csv', 'Liquidity Operational Overlay를 저장했습니다.', rerun=True)
    liquidity_status = liquidity_status_table(portfolio, edited_liquidity, total_assets, liquidity_days_limit=liquidity_days_limit)
    liquidity_state = liquidity_overlay_summary(liquidity_status, min_review_coverage=float(settings.get('liquidity_overlay_min_review_coverage', settings.get('risk_overlay_min_review_coverage', 0.8))))
    l1, l2, l3, l4, l5 = st.columns(5)
    l1.metric('Liquidity Decision Coverage', pct(liquidity_state['review_coverage']))
    l2.metric('Liquidity Data Gate', liquidity_state['data_gate'])
    l3.metric('Liquidity Risk State', liquidity_state['risk_state'])
    l4.metric('Tight Liquidity Weight', pct(liquidity_state['tight_liquidity_weight']))
    l5.metric('Max Days-to-Exit', '-' if liquidity_state['max_days_to_exit'] is None else f"{liquidity_state['max_days_to_exit']:.2f}일")
    if liquidity_state['data_gate'] != 'PASS':
        st.warning('Liquidity Overlay가 아직 Decision-use 기준을 충족하지 못합니다. 비현금 자산의 Days-to-Exit / Source / Human Review를 채우세요.')
    elif liquidity_state['risk_state'] == 'TIGHT':
        st.warning('검토 완료된 자산 중 Liquidity Days-to-Exit Limit을 초과한 포지션이 있습니다. 이는 운영 Risk Flag이며 자동 매도 명령이 아닙니다.')
    else:
        st.success('Liquidity Overlay의 기본 Data Gate가 PASS이고 TIGHT 포지션이 없습니다.')
    if not liquidity_status.empty:
        liquidity_cols = ['name', 'ticker', 'weight', 'liquidity_days_to_exit', 'liquidity_status', 'reviewed', 'source', 'status', 'issues']
        st.dataframe(liquidity_status[[c for c in liquidity_cols if c in liquidity_status.columns]], width='stretch', hide_index=True)
    st.caption(f"Policy: Liquidity Days-to-Exit Limit {liquidity_days_limit:.1f}일 · Liquidity Minimum Review Coverage {float(settings.get('liquidity_overlay_min_review_coverage', settings.get('risk_overlay_min_review_coverage', 0.8))):.1%}. Source Assist는 정상시장 거래량 proxy이며, FX 관련 판단은 5A/5B에서만 수행합니다.")
    st.subheader('5A. Asset / Wrapper Economic FX Overlay')
    st.caption('자산/ETF wrapper의 Trading Currency와 Underlying Economic FX를 분리합니다. KRW 상장 해외 ETF는 Direct Currency가 KRW여도 Economic Currency는 USD 등 외화일 수 있습니다. 국내 단일기업의 영업/매출 FX 민감도는 아래 Business FX Sensitivity에서 별도로 관리합니다.')
    econ_fx_overlays = normalize_economic_fx_overlays(load_csv('economic_fx_overlays.csv'))
    econ_fx_editor = economic_fx_editor_rows(portfolio, econ_fx_overlays)
    edited_econ_fx = st.data_editor(econ_fx_editor, width='stretch', hide_index=True, disabled=['name', 'ticker', 'direct_currency', 'updated_at'], column_config={'economic_currency': st.column_config.TextColumn('Economic Currency', help='예: USD. 외화 경제노출이 없다고 검토한 경우 비워둘 수 있습니다.'), 'economic_fx_exposure_ratio': st.column_config.NumberColumn('Economic FX Exposure Ratio', min_value=0.0, max_value=1.0, step=0.05, format='%.2f', help='자산가치 중 외화 경제노출 비율. 0=없음, 1=100% 외화노출.'), 'economic_fx_hedge_ratio': st.column_config.NumberColumn('Economic FX Hedge Ratio', min_value=0.0, max_value=1.0, step=0.05, format='%.2f', help='Economic FX exposure의 실제 환헤지 비율. 0=무헤지, 1=완전헤지.'), 'reviewed': st.column_config.CheckboxColumn('Reviewed', help='Underlying exposure / hedge / source를 직접 확인했을 때만 체크')}, key='portfolio_economic_fx_overlay_editor')
    if st.button('Economic FX Overlay 저장', type='primary', key='portfolio_economic_fx_overlay_save'):
        _saved_econ_fx = economic_fx_overlay_save_rows(edited_econ_fx)
        verified_save_feedback(_saved_econ_fx, 'economic_fx_overlays.csv', 'Economic FX Overlay를 저장했습니다.', rerun=True)
    econ_fx_status = economic_fx_status_table(portfolio, edited_econ_fx, total_assets)
    econ_fx_summary_state = economic_fx_summary(econ_fx_status, min_review_coverage=float(settings.get('economic_fx_min_review_coverage', 0.8)), unhedged_cap=fx_unhedged_cap)
    ef1, ef2, ef3, ef4, ef5, ef6 = st.columns(6)
    ef1.metric('Economic FX Review Coverage', pct(econ_fx_summary_state['review_coverage']))
    ef2.metric('Gross Economic FX', pct(econ_fx_summary_state['gross_economic_fx_weight']))
    ef3.metric('Hidden FX via KRW Wrappers', pct(econ_fx_summary_state['hidden_fx_weight']))
    ef4.metric('Known Unhedged Economic FX', pct(econ_fx_summary_state['known_unhedged_economic_fx_weight']))
    ef5.metric('Unknown Hedge Weight', pct(econ_fx_summary_state['unknown_unhedged_weight']))
    ef6.metric('Economic FX Gate', econ_fx_summary_state['status'])
    if not econ_fx_status.empty:
        econ_cols = ['name', 'ticker', 'scope', 'direct_currency', 'economic_currency', 'weight', 'economic_fx_exposure_ratio', 'economic_fx_hedge_ratio', 'gross_economic_fx_weight', 'hidden_fx_weight', 'known_unhedged_economic_fx_weight', 'reviewed', 'status', 'issues']
        st.dataframe(econ_fx_status[[c for c in econ_cols if c in econ_fx_status.columns]], width='stretch', hide_index=True)
    if econ_fx_summary_state['status'] != 'PASS':
        st.warning('Economic FX Overlay = ' + econ_fx_summary_state['status'] + ' · ' + econ_fx_summary_state['reason'] + '. KRW wrapper의 underlying currency와 hedge를 Source로 확인하세요.')
    elif econ_fx_summary_state['hidden_fx_weight'] > 0:
        st.info('KRW 거래통화 뒤에 숨은 외화 경제노출이 확인되었습니다. Direct Currency만으로 FX risk를 판단하지 마세요.')
    st.subheader('5B. Business FX Sensitivity Overlay')
    st.caption('단일기업의 FX 민감도는 자산의 거래통화와 다릅니다. 해외매출, 외화원가, 환율 방향성에 대한 운영 민감도를 별도 Human Review로 관리합니다. ETF/fund는 이 표의 대상이 아니며 5A Asset / Wrapper FX에서 관리합니다.')
    st.markdown('**5B-1. Business FX Evidence Assist**')
    st.caption('최근 분기/반기의 관찰된 FX 효과와 장기 정상화 FX 민감도를 분리합니다. 최근 관찰값은 Source-backed Evidence일 뿐 Long-run KRW Weakness Effect를 자동 승인하지 않습니다.')
    business_fx_evidence = normalize_business_fx_evidence(load_csv('business_fx_evidence.csv'))
    _business_fx_new_period_key = 'business_fx_new_period_mode'
    _business_fx_new_period_mode = bool(st.session_state.get(_business_fx_new_period_key, False))
    bxm1, bxm2 = st.columns([1, 3])
    if bxm1.button('새 기간 Evidence 작성', key='business_fx_new_period_start', disabled=_business_fx_new_period_mode):
        st.session_state[_business_fx_new_period_key] = True
        st.session_state.pop('portfolio_business_fx_evidence_editor', None)
        st.rerun()
    if _business_fx_new_period_mode:
        bxm2.info('NEW PERIOD DRAFT · 기존 Evidence를 덮어쓰지 않습니다. Observed Period와 Source를 새 기간 기준으로 모두 확인한 뒤 저장하세요. Long-run 패턴용 두 번째 Evidence는 기존 READY 기간과 겹치지 않는 기간(Q1 다음에는 Q2 등)을 권장합니다.')
        business_fx_evidence_editor = business_fx_evidence_editor_rows(portfolio, pd.DataFrame())
    else:
        bxm2.caption('현재는 각 종목의 최신 저장 Evidence를 편집합니다. 새 FY/Q/H1 Evidence를 추가하려면 `새 기간 Evidence 작성`을 누르세요.')
        business_fx_evidence_editor = business_fx_evidence_editor_rows(portfolio, business_fx_evidence)
    if business_fx_evidence_editor.empty:
        st.info('현재 Portfolio에 Business FX Evidence 대상 단일기업 주식이 없습니다.')
        edited_business_fx_evidence = business_fx_evidence_editor
    else:
        edited_business_fx_evidence = st.data_editor(business_fx_evidence_editor, width='stretch', hide_index=True, disabled=['name', 'ticker', 'updated_at'], column_config={'period': st.column_config.TextColumn('Observed Period', help='예: 2026 Q1, 2026 H1'), 'observed_currencies': st.column_config.TextColumn('Observed Currencies', help='공식 Source에서 확인한 주요 통화. 예: USD, EUR, JPY'), 'observed_effect': st.column_config.SelectboxColumn('Observed FX Effect', options=['', 'KRW_WEAK_POSITIVE', 'KRW_WEAK_NEGATIVE', 'MIXED', 'NEUTRAL', 'UNDETERMINED'], help='해당 기간에 관찰된 방향성. 장기 정상화 Effect와 동일하다고 자동 가정하지 않습니다.'), 'observed_impact_krw': st.column_config.NumberColumn('Observed P&L Impact (KRW)', step=100000000000.0, format='%.0f', help='공식 발표에 금액이 있을 때만 입력. 없으면 비워둡니다.'), 'reviewed': st.column_config.CheckboxColumn('Evidence Reviewed', help='Period / Currencies / Effect / Source를 직접 검토했을 때만 체크')}, key='portfolio_business_fx_evidence_editor')
        if st.button('Business FX Evidence 저장', type='primary', key='portfolio_business_fx_evidence_save'):
            _saved_business_fx_evidence_rows = business_fx_evidence_save_rows(edited_business_fx_evidence)
            _updated_business_fx_evidence = upsert_business_fx_evidence(business_fx_evidence, _saved_business_fx_evidence_rows)
            st.session_state[_business_fx_new_period_key] = False
            st.session_state.pop('portfolio_business_fx_evidence_editor', None)
            verified_save_feedback(_updated_business_fx_evidence, 'business_fx_evidence.csv', 'Business FX Evidence를 기간별 History에 저장했습니다.', rerun=True)
    business_fx_evidence_status = business_fx_evidence_status_table(edited_business_fx_evidence)
    business_fx_evidence_summary_state = business_fx_evidence_summary(business_fx_evidence_status)
    be1, be2, be3 = st.columns(3)
    be1.metric('Evidence READY', business_fx_evidence_summary_state['ready'])
    be2.metric('Evidence REVIEW', business_fx_evidence_summary_state['review'])
    be3.metric('Evidence Gate', business_fx_evidence_summary_state['status'])
    if not business_fx_evidence_status.empty:
        evidence_cols = ['name', 'ticker', 'period', 'observed_currencies', 'observed_effect', 'observed_impact_krw', 'source_title', 'reviewed', 'status', 'issues']
        st.dataframe(business_fx_evidence_status[[c for c in evidence_cols if c in business_fx_evidence_status.columns]], width='stretch', hide_index=True)
    st.markdown('**5B-2. Multi-period Business FX Evidence Review**')
    st.caption('2025 FY · 2026 Q1 · 2026 H1처럼 여러 기간의 Source-backed 관찰을 모아 장기 KRW Weakness Effect를 검토합니다. 이 표는 장기 효과를 자동 확정하지 않습니다.')
    _business_fx_focus_names = edited_business_fx_evidence['name'].fillna('').astype(str).str.strip().replace('', pd.NA).dropna().unique().tolist() if edited_business_fx_evidence is not None and (not edited_business_fx_evidence.empty) else []
    _business_fx_focus = st.selectbox('Multi-period Review 종목', _business_fx_focus_names, key='business_fx_multiperiod_company') if _business_fx_focus_names else ''
    business_fx_history_status = business_fx_evidence_history_table(business_fx_evidence, _business_fx_focus)
    min_business_fx_periods = int(settings.get('business_fx_min_ready_periods', 2))
    business_fx_multiperiod_state = business_fx_multiperiod_summary(business_fx_history_status, min_ready_periods=min_business_fx_periods)
    mh1, mh2, mh3, mh4, mh5, mh6, mh7, mh8 = st.columns(8)
    mh1.metric('READY Periods', business_fx_multiperiod_state['ready_periods'])
    mh2.metric('REVIEW Periods', business_fx_multiperiod_state['review_periods'])
    mh3.metric('Positive Obs', business_fx_multiperiod_state['positive_periods'])
    mh4.metric('Negative Obs', business_fx_multiperiod_state['negative_periods'])
    mh5.metric('Evidence Pattern', business_fx_multiperiod_state['pattern'])
    mh6.metric('Overlap Pairs', business_fx_multiperiod_state['overlap_count'])
    mh7.metric('Source Integrity', business_fx_multiperiod_state['source_integrity_status'])
    mh8.metric('Long-run Review Gate', business_fx_multiperiod_state['status'])
    hc1, hc2, hc3 = st.columns(3)
    hc1.metric('Candidate', business_fx_multiperiod_state['candidate'] or '-')
    hc2.metric('Impact Rows', business_fx_multiperiod_state['impact_rows'])
    hc3.metric('Known |Impact| Sum', krw(business_fx_multiperiod_state['known_abs_impact_krw']))
    if business_fx_history_status.empty:
        st.info('저장된 Business FX Evidence History가 없습니다.')
    else:
        history_cols = ['period', 'observed_currencies', 'observed_effect', 'observed_impact_krw', 'source_title', 'reviewed', 'status', 'issues', 'updated_at']
        st.dataframe(business_fx_history_status[[c for c in history_cols if c in business_fx_history_status.columns]], width='stretch', hide_index=True)
    if business_fx_multiperiod_state['source_integrity_status'] != 'PASS':
        _source_issue_parts = []
        if business_fx_multiperiod_state['duplicate_primary_pairs']:
            _source_issue_parts.append('동일 Primary URL: ' + ', '.join(business_fx_multiperiod_state['duplicate_primary_pairs']))
        if business_fx_multiperiod_state['duplicate_fingerprint_pairs']:
            _source_issue_parts.append('동일 Source/Effect/Impact: ' + ', '.join(business_fx_multiperiod_state['duplicate_fingerprint_pairs']))
        if business_fx_multiperiod_state['period_title_mismatches']:
            _source_issue_parts.append('Period/Source Title 불일치')
        st.error('Business FX Source Integrity REVIEW · ' + ' / '.join(_source_issue_parts) + '. 각 기간 Evidence는 해당 기간의 독립 Primary Source로 다시 확인하세요.')
    if business_fx_multiperiod_state['overlap_count'] > 0:
        st.error('겹치는 READY 기간이 있습니다: ' + ' / '.join(business_fx_multiperiod_state['overlap_pairs']) + '. Q1 + H1처럼 겹치는 기간을 독립된 2개 Evidence로 계산하지 않습니다. 두 번째 독립 관찰은 Q2처럼 비중복 기간을 사용하세요.')
    if business_fx_multiperiod_state['status'] != 'PASS':
        st.warning('Long-run Evidence Gate = REVIEW · ' + business_fx_multiperiod_state['reason'] + f'. 최소 READY 기간 {min_business_fx_periods}개가 필요하며 UNDETERMINED 기간이 있으면 장기 Candidate를 확정하지 않습니다.')
    else:
        st.success('Multi-period Evidence가 Long-run Human Review를 시작할 준비가 됐습니다. Candidate는 관찰 패턴 요약일 뿐 장기 가정의 자동 승인값이 아닙니다.')
    business_fx_overlays = normalize_business_fx_overlays(load_csv('business_fx_overlays.csv'))
    if business_fx_multiperiod_state['status'] == 'PASS' and business_fx_multiperiod_state['candidate'] and (not business_fx_overlays.empty) and _business_fx_focus:
        _candidate_confirm = st.checkbox('다기간 Business FX Evidence와 Candidate를 직접 검토했습니다. Candidate를 Long-run Effect 입력 보조로 복사하되 Reviewed는 자동 체크하지 않습니다.', key='business_fx_long_run_candidate_confirm')
        if st.button('Multi-period Candidate → Long-run Effect 입력 보조', disabled=not _candidate_confirm, key='business_fx_long_run_candidate_apply'):
            _candidate_overlay, _candidate_count = apply_business_fx_long_run_candidate(business_fx_overlays, _business_fx_focus, business_fx_multiperiod_state['candidate'], evidence_pattern=business_fx_multiperiod_state['pattern'], ready_periods=business_fx_multiperiod_state['ready_periods'])
            if _candidate_count <= 0:
                st.info('Candidate를 반영할 Business FX Overlay 행이 없습니다.')
            else:
                verified_save_feedback(_candidate_overlay, 'business_fx_overlays.csv', 'Multi-period Candidate를 Long-run Effect 입력 보조에 반영했습니다. Reviewed는 자동 체크하지 않았습니다.', rerun=True)
    if business_fx_evidence_summary_state['ready'] > 0 and (not business_fx_overlays.empty):
        if st.button('Reviewed Evidence → Business FX Currencies / Source 반영', key='business_fx_evidence_to_overlay'):
            _bridged_business_fx, _bridged_count = apply_business_fx_evidence_to_overlay(business_fx_overlays, business_fx_evidence_status)
            if _bridged_count <= 0:
                st.info('반영할 READY Business FX Evidence가 없습니다.')
            else:
                verified_save_feedback(_bridged_business_fx, 'business_fx_overlays.csv', f'READY Business FX Evidence {_bridged_count}건의 Currencies / Source를 Overlay에 반영했습니다. Long-run KRW Weakness Effect와 Reviewed는 자동 변경하지 않았습니다.', rerun=True)
    st.caption('Evidence Assist는 Currencies / Source까지만 연결합니다. Recent Observed Effect는 Long-run KRW Weakness Effect와 분리하며, Foreign Revenue/Cost Ratio도 자동 채우지 않습니다.')
    business_fx_overlays = normalize_business_fx_overlays(load_csv('business_fx_overlays.csv'))
    business_fx_editor = business_fx_editor_rows(portfolio, business_fx_overlays)
    if business_fx_editor.empty:
        st.info('현재 Portfolio에 Business FX Sensitivity 대상 단일기업 주식이 없습니다.')
        edited_business_fx = business_fx_editor
    else:
        edited_business_fx = st.data_editor(business_fx_editor, width='stretch', hide_index=True, disabled=['name', 'ticker', 'updated_at'], column_config={'business_fx_currencies': st.column_config.TextColumn('Business FX Currencies', help='예: USD, EUR. 매출/원가/이익에 중요한 통화를 Source로 확인해 입력.'), 'foreign_revenue_ratio': st.column_config.NumberColumn('Foreign Revenue Ratio', min_value=0.0, max_value=1.0, step=0.05, format='%.2f', help='확인 가능한 경우 해외/외화 매출 비중 proxy. 모르면 비워둘 수 있습니다.'), 'foreign_cost_ratio': st.column_config.NumberColumn('Foreign Cost Ratio', min_value=0.0, max_value=1.0, step=0.05, format='%.2f', help='확인 가능한 경우 외화 원가 비중 proxy. 모르면 비워둘 수 있습니다.'), 'krw_weakness_effect': st.column_config.SelectboxColumn('KRW Weakness Effect', options=['', 'KRW_WEAK_POSITIVE', 'KRW_WEAK_NEGATIVE', 'MIXED', 'NEUTRAL'], help='원화 약세가 사업 이익/현금흐름에 미치는 방향성. 단순 매출통화가 아니라 매출·원가·헤지까지 검토.'), 'reviewed': st.column_config.CheckboxColumn('Reviewed', help='Business FX Currencies / 방향성 / Source를 직접 검토했을 때만 체크')}, key='portfolio_business_fx_overlay_editor')
        if st.button('Business FX Sensitivity 저장', type='primary', key='portfolio_business_fx_overlay_save'):
            _saved_business_fx = business_fx_overlay_save_rows(edited_business_fx)
            verified_save_feedback(_saved_business_fx, 'business_fx_overlays.csv', 'Business FX Sensitivity Overlay를 저장했습니다.', rerun=True)
    business_fx_status = business_fx_status_table(portfolio, edited_business_fx, total_assets)
    business_fx_summary_state = business_fx_summary(business_fx_status, min_review_coverage=float(settings.get('business_fx_min_review_coverage', 0.8)))
    bf1, bf2, bf3, bf4, bf5, bf6 = st.columns(6)
    bf1.metric('Business FX Review Coverage', pct(business_fx_summary_state['review_coverage']))
    bf2.metric('KRW Weakness Positive Weight', pct(business_fx_summary_state['positive_weight']))
    bf3.metric('KRW Weakness Negative Weight', pct(business_fx_summary_state['negative_weight']))
    bf4.metric('Mixed FX Sensitivity Weight', pct(business_fx_summary_state['mixed_weight']))
    bf5.metric('FX Quantification Coverage', pct(business_fx_summary_state['quantification_coverage']))
    bf6.metric('Business FX Gate', business_fx_summary_state['status'])
    if not business_fx_status.empty:
        bf_cols = ['name', 'ticker', 'weight', 'business_fx_currencies', 'foreign_revenue_ratio', 'foreign_cost_ratio', 'krw_weakness_effect', 'quantified', 'reviewed', 'status', 'issues']
        st.dataframe(business_fx_status[[c for c in bf_cols if c in business_fx_status.columns]], width='stretch', hide_index=True)
    st.caption('Business FX는 monetary FX position이 아니라 Revenue/Margin/FCF 전달경로입니다. 따라서 Asset FX와 합산·상계하지 않으며, 별도 Sensitivity Review로 사용합니다.')
    st.subheader('6. Portfolio Risk Decision-use Gate')
    portfolio_risk_gate = portfolio_risk_decision_gate(car_budget_status=budget_state['status'], concentration_status=concentration_state['status'], stress_reliability_status_value=stress_reliability['status'], currency_lookthrough_status=currency_diag['status'], liquidity_overlay_status=liquidity_state['data_gate'], economic_fx_status=econ_fx_summary_state['status'], business_fx_status=business_fx_summary_state['status'], business_fx_evidence_history_status=business_fx_multiperiod_state['status'])
    dg1, dg2 = st.columns([1, 3])
    dg1.metric('Decision-use Gate', portfolio_risk_gate['status'])
    if portfolio_risk_gate['status'] == 'PASS':
        dg2.success('Portfolio Risk 입력의 기본 Decision-use Gate가 PASS입니다. 이는 매수/매도 추천이 아니라 Risk 데이터 준비상태입니다.')
    else:
        dg2.warning('Decision-use Gate REVIEW · ' + ' | '.join(portfolio_risk_gate['issues']))
    st.subheader('7. Next Review')
    pr_issues = []
    if budget_state['status'] != 'PASS':
        pr_issues.append('Portfolio CAR Budget')
    if concentration_state['status'] != 'PASS':
        pr_issues.append('Top CAR Concentration')
    if stress_reliability['status'] != 'PASS':
        pr_issues.append('Historical Correlation')
    if currency_diag['status'] != 'PASS':
        pr_issues.append('Holdings Currency Coverage')
    if econ_fx_summary_state['status'] != 'PASS':
        pr_issues.append('Asset / Wrapper Economic FX')
    if business_fx_multiperiod_state['status'] != 'PASS':
        pr_issues.append('Business FX Multi-period Evidence')
    if business_fx_summary_state['status'] != 'PASS':
        pr_issues.append('Business FX Sensitivity')
    if liquidity_state['data_gate'] != 'PASS':
        pr_issues.append('Liquidity Overlay Coverage')
    if liquidity_state['risk_state'] == 'TIGHT':
        pr_issues.append('Liquidity Risk Tight')
    if not pr_factor.empty and pr_factor['breach_status'].fillna('').astype(str).eq('PRE-EXISTING BREACH').any():
        pr_issues.append('Factor Risk Repair')
    if pr_issues:
        st.warning('다음 검토: ' + ' / '.join(pr_issues))
    else:
        st.success('현재 Portfolio Risk 2.0 기본 Review 항목에 미해결 Flag가 없습니다.')
