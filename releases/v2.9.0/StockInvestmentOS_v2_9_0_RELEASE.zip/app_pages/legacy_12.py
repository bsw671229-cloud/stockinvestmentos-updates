from __future__ import annotations
if True:
    st.title('Daily Briefing')
    st.caption('한 번의 점검으로 가격 Preview, Lifecycle, Risk Alerts, Proof Clock, 최근 DART 공시를 모읍니다. 자동 주문은 하지 않습니다.')
    days = st.number_input('최근 DART 공시 조회일수', min_value=1, max_value=30, value=int(settings.get('dart_disclosure_days', 7)), step=1)
    if st.button('Daily Check 실행', type='primary'):
        with st.spinner('가격·상태·공시를 점검하는 중...'):
            updated_watch, price_log = refresh_watchlist_prices(watchlist)
            state_preview = add_states(updated_watch, portfolio, total_assets, loss_budget, single_cap)
            alert_preview = build_alerts(portfolio, state_preview, proof, total_assets, loss_budget, single_cap, float(settings.get('factor_cap', 0.1)))
            disclosures = pd.DataFrame()
            key = st.session_state.get('dart_api_key', os.getenv('DART_API_KEY', ''))
            corp_cache = ROOT / 'data' / 'dart_corp_codes.csv'
            if key and corp_cache.exists():
                try:
                    corp_codes = pd.read_csv(corp_cache, dtype=str)
                    end = date.today()
                    begin = end - timedelta(days=int(days))
                    disclosures = recent_disclosures_for_watchlist(key, updated_watch, corp_codes, begin.strftime('%Y%m%d'), end.strftime('%Y%m%d'), 20)
                    if not disclosures.empty and 'rcept_no' in disclosures.columns:
                        disclosures['dart_url'] = disclosures['rcept_no'].fillna('').astype(str).apply(lambda x: f'https://dart.fss.or.kr/dsaf001/main.do?rcpNo={x}' if x else '')
                except Exception as e:
                    disclosures = pd.DataFrame([{'status': 'ERROR', 'message': str(e)}])
            else:
                reason = 'DART_API_KEY missing' if not key else 'dart_corp_codes.csv missing — OpenDART Auto에서 고유번호 목록을 먼저 동기화하세요.'
                disclosures = pd.DataFrame([{'status': 'SKIP', 'message': reason}])
            st.session_state['daily_watch_preview'] = updated_watch
            st.session_state['daily_price_log'] = price_log
            st.session_state['daily_states'] = state_preview
            st.session_state['daily_alerts'] = alert_preview
            st.session_state['daily_disclosures'] = disclosures
    if 'daily_alerts' in st.session_state:
        alerts = st.session_state['daily_alerts']
        price_log = st.session_state['daily_price_log']
        states = st.session_state['daily_states']
        disclosures = st.session_state['daily_disclosures']
        clock = enrich_proof_clock(proof)
        _daily_cp_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
        _daily_cp_context = build_capital_productivity_health_context(portfolio, watchlist, load_csv('capital_productivity_inputs.csv'), total_assets, _daily_cp_states, audit_evidence, load_csv('fundamental_snapshots.csv'), load_csv('scenario_refresh_reviews.csv'), load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'), today=date.today())
        _daily_cp_queue = build_assumption_review_queue(_daily_cp_context['health'], today=date.today(), expiry_warning_days=int(settings.get('capital_productivity_expiry_warning_days', 30)))
        _daily_cp_qs = assumption_review_queue_summary(_daily_cp_queue)
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric('Price OK', int((price_log.get('status', pd.Series(dtype=str)) == 'OK').sum()) if not price_log.empty else 0)
        c2.metric('Critical Alerts', int((alerts.get('severity', pd.Series(dtype=str)) == 'CRITICAL').sum()) if not alerts.empty else 0)
        c3.metric('Proof Due/Overdue', int(clock['clock_status'].isin(['DUE SOON', 'OVERDUE']).sum()) if not clock.empty else 0)
        c4.metric('Assumption NOW', _daily_cp_qs['attention_now'])
        c5.metric('Recent DART', int((disclosures.get('status', pd.Series(dtype=str)) == 'OK').sum()) if not disclosures.empty else 0)
        st.subheader('1) Risk / Evidence Alerts')
        if alerts.empty:
            st.success('현재 규칙 기반 Alert가 없습니다.')
        else:
            st.dataframe(alerts, width='stretch', hide_index=True)
        st.subheader('2) Lifecycle Preview')
        cols = [c for c in ['name', 'price', 'lifecycle_state', 'state_reason', 'evidence_status', 'thesis_status'] if c in states.columns]
        st.dataframe(states[cols], width='stretch', hide_index=True)
        st.subheader('3) Price Update Preview')
        st.dataframe(price_log, width='stretch', hide_index=True)
        st.caption('Daily Briefing의 가격 갱신은 Preview입니다. 저장하려면 주가·평가액 갱신 메뉴에서 적용하세요.')
        st.subheader('4) Proof Clock')
        if clock.empty:
            st.info('Proof Clock이 비어 있습니다.')
        else:
            urgent = clock[clock['clock_status'].isin(['OVERDUE', 'DUE SOON'])]
            st.dataframe(urgent if not urgent.empty else clock.head(10), width='stretch', hide_index=True)
        st.subheader('4A) Capital Productivity Assumption Clock')
        if _daily_cp_queue.empty:
            st.success('현재 Capital Productivity Assumption Review Queue가 비어 있습니다.')
        else:
            dq1, dq2, dq3, dq4 = st.columns(4)
            dq1.metric('P1 Drift/Integrity', _daily_cp_qs['p1'])
            dq2.metric('P2 Expiry', _daily_cp_qs['p2'])
            dq3.metric('P3 Holding Review', _daily_cp_qs['p3'])
            dq4.metric('P4 Watchlist Review', _daily_cp_qs['p4'])
            _daily_queue_cols = ['priority', 'bucket', 'due_date', 'category', 'subject', 'status', 'issue', 'next_action']
            st.dataframe(_daily_cp_queue[[c for c in _daily_queue_cols if c in _daily_cp_queue.columns]].head(12), width='stretch', hide_index=True)
            st.caption('P1은 Reference Drift / Hash / Input mismatch, P2는 Expiry Clock, P3는 보유자산 미검토, P4는 Watchlist 미검토입니다.')
        st.subheader('5) Recent DART Disclosures')
        st.dataframe(disclosures, width='stretch', hide_index=True)
        if st.button('현재 저장 데이터로 Snapshot 만들기'):
            path = save_snapshot(ROOT, portfolio, watchlist, proof, total_assets, alerts)
            st.success(f'Snapshot 저장: {path.name}')
