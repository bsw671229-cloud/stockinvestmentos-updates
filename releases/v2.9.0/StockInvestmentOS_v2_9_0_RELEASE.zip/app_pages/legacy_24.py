from __future__ import annotations
if True:
    st.title('Quant Screener')
    st.caption('2단계 구조입니다. ① OpenDART 다중회사 주요계정으로 최대 100개 발행사를 한 번에 빠르게 압축하고 ② 그 결과만 개별 전체 재무제표로 CFO·FCF·현금·차입금을 상세검증합니다. 주문은 전송하지 않습니다.')
    universe = ensure_universe_cols(load_csv('market_universe.csv'))
    fast_cache = normalize_fast_cache(load_csv('quant_fast_cache.csv'))
    detail_cache = normalize_quant_cache(load_csv('quant_screen_cache.csv'))
    corp_cache_path = ROOT / 'data' / 'dart_corp_codes.csv'
    dart_key = st.session_state.get('dart_api_key', os.getenv('DART_API_KEY', ''))
    st.info('재무제표는 발행사 단위입니다. 따라서 1·2차 재무 스크리닝은 보통주 대표코드 중심으로 수행합니다. 우선주는 Market Universe에 그대로 유지하고, 발행사 후보가 통과한 뒤 가격·유동성·보통주 대비 괴리율을 별도로 비교합니다.')
    default_year, default_report = default_quant_period(date.today())
    report_options = ['11011', '11013', '11012', '11014']
    report_fmt = {'11011': '사업보고서(FY)', '11013': '1분기(Q1)', '11012': '반기(H1)', '11014': '3분기(Q3)'}
    p1, p2, p3, p4 = st.columns(4)
    business_year = int(p1.number_input('사업연도', min_value=2015, max_value=date.today().year, value=int(default_year), step=1))
    report_code = p2.selectbox('보고서', report_options, index=report_options.index(default_report) if default_report in report_options else 0, format_func=lambda x: report_fmt[x])
    markets = p3.multiselect('시장', ['KOSPI', 'KOSDAQ'], default=['KOSPI', 'KOSDAQ'])
    scope_keyword = p4.text_input('수집범위 검색', placeholder='종목명 / 코드 / 업종')
    if universe.empty:
        st.warning('Market Universe가 비어 있습니다. 먼저 Market Universe에서 전체 종목코드를 동기화하세요.')
    if not dart_key:
        st.warning('DART API Key가 없습니다. OpenDART Auto에서 API Key를 입력하거나 .env에 저장하세요.')
    if not corp_cache_path.exists():
        st.warning('DART 고유번호 캐시가 없습니다. OpenDART Auto → 고유번호 목록 동기화를 먼저 실행하세요.')
    scope = pd.DataFrame()
    if not universe.empty:
        scope = universe.copy()
        if markets:
            scope = scope[scope['market'].isin(markets)]
        scope = scope[scope['security_group'].fillna('').astype(str) == '보통주']
        kw = str(scope_keyword or '').strip().lower()
        if kw:
            search = (scope['name'].fillna('').astype(str) + ' ' + scope['code'].astype(str) + ' ' + scope['industry'].fillna('').astype(str)).str.lower()
            scope = scope[search.str.contains(kw, regex=False, na=False)]
        scope = scope.reset_index(drop=True)
    fast_period = fast_cache[(pd.to_numeric(fast_cache['business_year'], errors='coerce') == int(business_year)) & (fast_cache['report_code'].astype(str) == str(report_code))].copy() if not fast_cache.empty else pd.DataFrame()
    pending_fast = pending_fast_scope(universe, fast_cache, business_year, report_code, markets=markets, keyword=scope_keyword) if not universe.empty else pd.DataFrame()
    st.subheader('1단계 · FAST Universe Scan')
    st.caption("OpenDART '다중회사 주요계정'을 사용합니다. 한 요청에 최대 100개 회사를 묶어 매출·영업이익·자산·부채·자본을 먼저 확인합니다. 이 단계의 부채는 '부채총계'이지 이자부담 차입금이 아닙니다.")
    f1, f2, f3, f4, f5 = st.columns(5)
    f1.metric('보통주 수집대상', f'{len(scope):,}')
    f2.metric('FAST 캐시', f'{len(fast_period):,}')
    f3.metric('FAST OK', f"{(int((fast_period.get('scan_status', pd.Series(dtype=str)) == 'OK').sum()) if not fast_period.empty else 0):,}")
    f4.metric('FAST 오류/누락', f"{(int((fast_period.get('scan_status', pd.Series(dtype=str)) != 'OK').sum()) if not fast_period.empty else 0):,}")
    f5.metric('남은 대상', f'{len(pending_fast):,}')
    fb1, fb2, fb3 = st.columns([2, 2, 1])
    with fb1:
        run_fast_scan = st.button(f'다음 {(min(100, len(pending_fast)) if len(pending_fast) else 100)}개 FAST 수집', type='primary', disabled=universe.empty or not dart_key or (not corp_cache_path.exists()) or pending_fast.empty)
    with fb2:
        fast_error_count = int((fast_period.get('scan_status', pd.Series(dtype=str)) != 'OK').sum()) if not fast_period.empty else 0
        retry_fast = st.button(f'FAST 오류/누락 최대 100개 재시도', disabled=fast_error_count == 0 or not dart_key or (not corp_cache_path.exists()))
    with fb3:
        st.download_button('FAST 캐시 CSV', data=fast_cache.to_csv(index=False).encode('utf-8-sig'), file_name='quant_fast_cache.csv', mime='text/csv', disabled=fast_cache.empty)
    if run_fast_scan:
        try:
            corp_codes = pd.read_csv(corp_cache_path, dtype=str)
            corp_map = build_corp_map(corp_codes)
            batch = pending_fast.head(100).copy()
            with st.spinner(f'{len(batch):,}개 발행사의 주요계정을 한 번의 OpenDART 배치로 수집하는 중입니다...'):
                rows = scan_fast_batch(dart_key, batch, corp_map, business_year, report_code)
                fast_cache = upsert_fast_cache(fast_cache, rows)
                save_csv(fast_cache, 'quant_fast_cache.csv', backup=False)
            st.success(f'FAST 배치 저장 완료: {len(rows):,}개')
            st.rerun()
        except Exception as e:
            st.error(f'FAST 수집 실패: {e}')
            st.info('기존 FAST 캐시는 유지했습니다. OpenDART 요청 제한 또는 네트워크 상태를 확인하세요.')
    if retry_fast:
        try:
            err_codes = set(fast_period.loc[fast_period['scan_status'].astype(str) != 'OK', 'code'].astype(str).head(100))
            retry_scope = scope[scope['code'].astype(str).isin(err_codes)].head(100).copy()
            corp_codes = pd.read_csv(corp_cache_path, dtype=str)
            corp_map = build_corp_map(corp_codes)
            with st.spinner(f'FAST 오류 {len(retry_scope):,}개를 재시도하는 중입니다...'):
                rows = scan_fast_batch(dart_key, retry_scope, corp_map, business_year, report_code)
                fast_cache = upsert_fast_cache(fast_cache, rows)
                save_csv(fast_cache, 'quant_fast_cache.csv', backup=False)
            st.success('FAST 오류 재시도가 끝났습니다.')
            st.rerun()
        except Exception as e:
            st.error(f'FAST 재시도 실패: {e}')
    st.markdown('#### FAST 필터')
    q1, q2, q3, q4 = st.columns(4)
    fast_require_op = q1.checkbox('영업이익 > 0', value=True, key='fast_require_op')
    fast_require_equity = q2.checkbox('자본총계 > 0', value=True, key='fast_require_equity')
    fast_exclude_special = q3.checkbox('금융업 등 특수계정 제외', value=True)
    fast_min_complete = q4.number_input('FAST 데이터 완성도 %', min_value=0, max_value=100, value=67, step=5)
    q5, q6, q7, q8 = st.columns(4)
    fast_use_growth = q5.checkbox('매출성장률 하한', value=True, key='fast_use_growth')
    fast_growth_pct = q6.number_input('최소 매출성장률 %', value=0.0, step=1.0, disabled=not fast_use_growth, key='fast_growth')
    fast_use_margin = q7.checkbox('영업이익률 하한', value=True, key='fast_use_margin')
    fast_margin_pct = q8.number_input('최소 영업이익률 %', value=5.0, step=1.0, disabled=not fast_use_margin, key='fast_margin')
    q9, q10, q11 = st.columns(3)
    fast_use_leverage = q9.checkbox('부채총계/자본총계 상한', value=False)
    fast_leverage = q10.number_input('최대 부채/자본 배수', min_value=0.0, value=2.0, step=0.25, disabled=not fast_use_leverage)
    fast_result_keyword = q11.text_input('FAST 결과 내 검색')
    fast_results = filter_fast_results(fast_cache, business_year, report_code, markets=markets, keyword=fast_result_keyword, min_completeness=float(fast_min_complete) / 100.0, require_op_positive=fast_require_op, require_equity_positive=fast_require_equity, min_revenue_growth=float(fast_growth_pct) / 100.0 if fast_use_growth else None, min_operating_margin=float(fast_margin_pct) / 100.0 if fast_use_margin else None, max_liabilities_to_equity=float(fast_leverage) if fast_use_leverage else None, exclude_special_sector=fast_exclude_special)
    st.write(f'FAST 필터 통과: **{len(fast_results):,}개**')
    if not fast_results.empty:
        fast_display = fast_results.copy()
        for src, dst_col in [('revenue_growth', '매출성장%'), ('operating_margin', '영업이익률%'), ('data_completeness', '완성도%')]:
            fast_display[dst_col] = pd.to_numeric(fast_display[src], errors='coerce') * 100.0
        fast_cols = [c for c in ['code', 'name', 'market', 'industry', 'fast_gate', 'fs_div', '매출성장%', '영업이익률%', 'liabilities_to_equity', '완성도%'] if c in fast_display.columns]
        st.dataframe(fast_display[fast_cols].head(500), width='stretch', hide_index=True, height=380)
    st.divider()
    st.subheader('2단계 · DETAIL Cash Flow / Debt Scan')
    st.caption('FAST 필터를 통과한 종목만 개별 전체 재무제표(CFS 우선, 없으면 OFS)로 상세수집합니다. CFO·유형자산 취득·FCF proxy·현금·이자부담 Debt proxy를 여기서 확인합니다.')
    detail_period = detail_cache[(pd.to_numeric(detail_cache['business_year'], errors='coerce') == int(business_year)) & (detail_cache['report_code'].astype(str) == str(report_code))].copy() if not detail_cache.empty else pd.DataFrame()
    detail_pending = pending_detail_from_fast(fast_results, detail_cache, business_year, report_code)
    d1, d2, d3, d4 = st.columns(4)
    detail_batch_size = int(d1.number_input('상세 1회 수집 수', min_value=5, max_value=50, value=10, step=5))
    d2.metric('FAST 통과', f'{len(fast_results):,}')
    d3.metric('상세 캐시(현재 기간)', f'{len(detail_period):,}')
    d4.metric('현재 FAST 기준 상세 미수집', f'{len(detail_pending):,}')
    db1, db2 = st.columns([3, 1])
    with db1:
        run_detail = st.button(f'FAST 통과종목 다음 {(min(detail_batch_size, len(detail_pending)) if len(detail_pending) else detail_batch_size)}개 상세수집', disabled=detail_pending.empty or not dart_key or (not corp_cache_path.exists()))
    with db2:
        st.download_button('DETAIL 캐시 CSV', data=detail_cache.to_csv(index=False).encode('utf-8-sig'), file_name='quant_screen_cache.csv', mime='text/csv', disabled=detail_cache.empty)
    if run_detail:
        corp_codes = pd.read_csv(corp_cache_path, dtype=str)
        corp_map = build_corp_map(corp_codes)
        batch = detail_pending.head(detail_batch_size).copy()
        working = detail_cache.copy()
        progress = st.progress(0.0)
        status_box = st.empty()
        api_limit_hit = False
        for i, (_, urow) in enumerate(batch.iterrows(), start=1):
            code = str(urow.get('code', '') or '').zfill(6)
            name = str(urow.get('name', '') or '')
            status_box.write(f'{i}/{len(batch)} · {name} ({code})')
            corp = corp_map.get(code, '')
            if not corp:
                rec = error_record(urow, '', business_year, report_code, 'NO_CORP_CODE', 'DART corp_code mapping not found for this stock code')
            else:
                rec = scan_one(dart_key, corp, urow, business_year, report_code)
            working = upsert_quant_cache(working, [rec])
            save_csv(working, 'quant_screen_cache.csv', backup=False)
            err = str(rec.get('error', ''))
            progress.progress(min(1.0, i / max(len(batch), 1)))
            if 'DART error 020' in err or '요청 제한' in err:
                api_limit_hit = True
                break
        status_box.empty()
        progress.empty()
        if api_limit_hit:
            st.error('OpenDART 요청 제한(020)이 감지되어 상세수집을 중단했습니다. 이미 수집된 행은 저장되어 있습니다.')
        else:
            st.success('상세수집 배치가 끝났습니다.')
        st.rerun()
    st.markdown('#### DETAIL 필터')
    z1, z2, z3, z4 = st.columns(4)
    detail_require_op = z1.checkbox('영업이익 > 0', value=True, key='detail_op')
    detail_require_cfo = z2.checkbox('CFO > 0', value=True)
    detail_require_fcf = z3.checkbox('FCF proxy > 0', value=True)
    detail_require_net_cash = z4.checkbox('Net Cash >= 0', value=False)
    z5, z6, z7, z8 = st.columns(4)
    detail_use_growth = z5.checkbox('매출성장률 하한 사용', value=False, key='detail_growth_on')
    detail_growth_pct = z6.number_input('상세 최소 매출성장률 %', value=0.0, step=1.0, disabled=not detail_use_growth)
    detail_use_margin = z7.checkbox('영업이익률 하한 사용', value=True, key='detail_margin_on')
    detail_margin_pct = z8.number_input('상세 최소 영업이익률 %', value=5.0, step=1.0, disabled=not detail_use_margin)
    z9, z10, z11 = st.columns(3)
    detail_complete = z9.number_input('상세 데이터 완성도 %', min_value=0, max_value=100, value=60, step=5)
    detail_keyword = z10.text_input('DETAIL 결과 내 검색')
    detail_show_limit = int(z11.number_input('DETAIL 표시 최대 행', min_value=20, max_value=1000, value=200, step=20))
    detail_results = filter_quant_results(detail_cache, business_year, report_code, markets=markets, keyword=detail_keyword, only_ok=True, min_completeness=float(detail_complete) / 100.0, require_op_positive=detail_require_op, require_cfo_positive=detail_require_cfo, require_fcf_positive=detail_require_fcf, require_net_cash=detail_require_net_cash, min_revenue_growth=float(detail_growth_pct) / 100.0 if detail_use_growth else None, min_operating_margin=float(detail_margin_pct) / 100.0 if detail_use_margin else None)
    if not fast_results.empty and (not detail_results.empty):
        allowed_codes = set(fast_results['code'].astype(str))
        detail_results = detail_results[detail_results['code'].astype(str).isin(allowed_codes)].reset_index(drop=True)
    elif fast_results.empty:
        detail_results = detail_results.iloc[0:0].copy()
    st.write(f'현재 DETAIL 필터 통과: **{len(detail_results):,}개**')
    if not detail_results.empty:
        display = detail_results.copy()
        for src, dst_col in [('revenue_growth', '매출성장%'), ('operating_margin', '영업이익률%'), ('cfo_margin', 'CFO마진%'), ('fcf_margin', 'FCF마진%'), ('data_completeness', '데이터완성도%')]:
            display[dst_col] = pd.to_numeric(display[src], errors='coerce') * 100.0
        display_cols = [c for c in ['code', 'name', 'market', 'industry', 'screen_gate', 'fs_div', '매출성장%', '영업이익률%', 'CFO마진%', 'FCF마진%', 'net_cash_proxy', 'cash_to_debt_proxy', '데이터완성도%', 'scan_timestamp'] if c in display.columns]
        st.dataframe(display[display_cols].head(detail_show_limit), width='stretch', hide_index=True, height=470)
        st.download_button('현재 DETAIL 결과 CSV', data=detail_results.to_csv(index=False).encode('utf-8-sig'), file_name=f'quant_detail_{business_year}_{REPORT_LABELS.get(report_code, report_code)}.csv', mime='text/csv')
        st.divider()
        st.subheader('3단계 · Quality Ranker / Shortlist')
        st.caption('현재 DETAIL 통과 종목을 성장·영업수익성·CFO·FCF·순현금/매출·데이터 품질의 교차분포(percentile)로 정렬합니다. 극단치는 5~95% 구간으로 완화합니다. 이 점수는 밸류에이션·ROIC·Moat를 포함하지 않으므로 매수 점수가 아니라 정밀분석 우선순위입니다.')
        r1, r2, r3 = st.columns(3)
        shortlist_target = int(r1.number_input('Shortlist 목표 종목 수', min_value=10, max_value=100, value=30, step=5, key='quality_shortlist_target'))
        diversify_industry = r2.checkbox('업종 쏠림 완화', value=True, key='quality_diversify')
        industry_cap = int(r3.number_input('업종별 최대 종목 수', min_value=1, max_value=20, value=5, step=1, disabled=not diversify_industry, key='quality_industry_cap'))
        with st.expander('Quality Ranker 가중치 (합계가 100일 필요는 없습니다)'):
            w1, w2, w3 = st.columns(3)
            q_w_growth = w1.number_input('매출성장', min_value=0.0, max_value=100.0, value=20.0, step=5.0)
            q_w_op = w2.number_input('영업이익률', min_value=0.0, max_value=100.0, value=20.0, step=5.0)
            q_w_cfo = w3.number_input('CFO 마진', min_value=0.0, max_value=100.0, value=15.0, step=5.0)
            w4, w5, w6 = st.columns(3)
            q_w_fcf = w4.number_input('FCF 마진', min_value=0.0, max_value=100.0, value=25.0, step=5.0)
            q_w_balance = w5.number_input('순현금/매출', min_value=0.0, max_value=100.0, value=15.0, step=5.0)
            q_w_data = w6.number_input('데이터 품질', min_value=0.0, max_value=100.0, value=5.0, step=5.0)
        q_weights = {'revenue_growth': q_w_growth, 'operating_margin': q_w_op, 'cfo_margin': q_w_cfo, 'fcf_margin': q_w_fcf, 'net_cash_to_revenue': q_w_balance, 'data_completeness': q_w_data}
        ranked_quality = rank_quality_candidates(detail_results, target_count=shortlist_target, weights=q_weights, max_per_industry=industry_cap if diversify_industry else None)
        shortlist = shortlist_view(ranked_quality)
        qr1, qr2, qr3, qr4 = st.columns(4)
        qr1.metric('DETAIL 통과', f'{len(detail_results):,}')
        qr2.metric('Shortlist', f'{len(shortlist):,}')
        qr3.metric('업종 수', f"{(shortlist['industry'].nunique() if not shortlist.empty else 0):,}")
        flagged_count = int(shortlist['quality_flags'].fillna('').astype(str).str.len().gt(0).sum()) if not shortlist.empty else 0
        qr4.metric('Flagged', f'{flagged_count:,}')
        if not shortlist.empty:
            qdisp = shortlist.copy()
            for src, dst in [('quality_score', 'Quality Score'), ('revenue_growth', '매출성장%'), ('operating_margin', '영업이익률%'), ('cfo_margin', 'CFO마진%'), ('fcf_margin', 'FCF마진%'), ('net_cash_to_revenue', '순현금/매출%'), ('data_completeness', '완성도%')]:
                if src in qdisp.columns:
                    if src == 'quality_score':
                        qdisp[dst] = pd.to_numeric(qdisp[src], errors='coerce').round(1)
                    else:
                        qdisp[dst] = (pd.to_numeric(qdisp[src], errors='coerce') * 100.0).round(1)
            qcols = [c for c in ['shortlist_rank', 'quality_rank', 'code', 'name', 'market', 'industry', 'Quality Score', '매출성장%', '영업이익률%', 'CFO마진%', 'FCF마진%', '순현금/매출%', 'cfo_to_op', 'cash_to_debt_proxy', '완성도%', 'quality_flags'] if c in qdisp.columns]
            st.dataframe(qdisp[qcols], width='stretch', hide_index=True, height=520)
            st.download_button('Quality Shortlist CSV', data=shortlist.to_csv(index=False).encode('utf-8-sig'), file_name=f'quality_shortlist_{business_year}_{REPORT_LABELS.get(report_code, report_code)}.csv', mime='text/csv')
            st.markdown('#### Shortlist → Candidate Queue')
            shortlist_pick = shortlist.copy()
            shortlist_pick.insert(0, 'select', False)
            shortlist_pick_cols = [c for c in ['select', 'shortlist_rank', 'quality_rank', 'code', 'name', 'market', 'industry', 'quality_score', 'revenue_growth', 'operating_margin', 'cfo_margin', 'fcf_margin', 'net_cash_to_revenue', 'cfo_to_op', 'cash_to_debt_proxy', 'quality_flags'] if c in shortlist_pick.columns]
            shortlist_editor = st.data_editor(shortlist_pick[shortlist_pick_cols], num_rows='fixed', width='stretch', hide_index=True, disabled=[c for c in shortlist_pick_cols if c != 'select'], column_config={'select': st.column_config.CheckboxColumn('선택', default=False)}, key='quality_shortlist_picker_v14')
            if st.button('체크한 Quality Shortlist → Candidate Queue 추가', type='primary'):
                chosen = shortlist_editor[shortlist_editor['select'] == True].copy()
                if chosen.empty:
                    st.warning('먼저 Shortlist 종목을 체크해주세요.')
                else:
                    codes = set(chosen['code'].astype(str))
                    picked_universe = universe[universe['code'].astype(str).isin(codes)].copy()
                    candidates = ensure_candidate_cols(load_csv('market_candidates.csv'))
                    updated = add_candidates(candidates, picked_universe)
                    metric_map = ranked_quality[ranked_quality['code'].astype(str).isin(codes)].set_index('code')
                    if 'note' not in updated.columns:
                        updated['note'] = ''
                    for i, row in updated.iterrows():
                        code = str(row.get('code', ''))
                        if code not in metric_map.index:
                            continue
                        r = metric_map.loc[code]
                        if isinstance(r, pd.DataFrame):
                            r = r.iloc[-1]
                        score = pd.to_numeric(pd.Series([r.get('quality_score')]), errors='coerce').iloc[0]
                        srank = r.get('shortlist_rank', '')
                        flags = str(r.get('quality_flags', '') or '')
                        note_parts = [f'Quality Shortlist {business_year} {REPORT_LABELS.get(report_code, report_code)}', f'shortlist_rank={srank}']
                        if pd.notna(score):
                            note_parts.append(f'quality_score={score:.1f}')
                        if flags:
                            note_parts.append(f'flags={flags}')
                        note_parts.append('NOT valuation/buy signal')
                        updated.at[i, 'note'] = '; '.join(note_parts)
                    save_csv(updated, 'market_candidates.csv')
                    st.success('Candidate Queue에 저장했습니다. 다음 단계는 원공시 확인 → Data Quality → ROIC/iROIC → Reverse DCF → Bear downside 검증입니다.')
                    st.rerun()
        else:
            st.info('현재 DETAIL 결과에서 Quality Shortlist를 만들 수 없습니다.')
        st.subheader('원본 DETAIL 결과 → Candidate Queue (수동)')
        pick_df = detail_results.head(detail_show_limit).copy()
        pick_df.insert(0, 'select', False)
        pick_cols = [c for c in ['select', 'code', 'name', 'market', 'industry', 'screen_gate', 'revenue_growth', 'operating_margin', 'cfo_margin', 'fcf_margin', 'net_cash_proxy'] if c in pick_df.columns]
        pick_editor = st.data_editor(pick_df[pick_cols], num_rows='fixed', width='stretch', hide_index=True, disabled=[c for c in pick_cols if c != 'select'], column_config={'select': st.column_config.CheckboxColumn('선택', default=False)}, key='quant_candidate_picker_v13')
        if st.button('체크한 DETAIL 후보 → Candidate Queue 추가'):
            chosen = pick_editor[pick_editor['select'] == True].copy()
            if chosen.empty:
                st.warning('먼저 종목을 체크해주세요.')
            else:
                codes = set(chosen['code'].astype(str))
                picked_universe = universe[universe['code'].astype(str).isin(codes)].copy()
                candidates = ensure_candidate_cols(load_csv('market_candidates.csv'))
                updated = add_candidates(candidates, picked_universe)
                metric_map = detail_results[detail_results['code'].astype(str).isin(codes)].set_index('code')
                if 'note' not in updated.columns:
                    updated['note'] = ''
                for i, row in updated.iterrows():
                    code = str(row.get('code', ''))
                    if code not in metric_map.index:
                        continue
                    r = metric_map.loc[code]
                    if isinstance(r, pd.DataFrame):
                        r = r.iloc[-1]
                    rg = pd.to_numeric(pd.Series([r.get('revenue_growth')]), errors='coerce').iloc[0]
                    om = pd.to_numeric(pd.Series([r.get('operating_margin')]), errors='coerce').iloc[0]
                    cm = pd.to_numeric(pd.Series([r.get('cfo_margin')]), errors='coerce').iloc[0]
                    fm = pd.to_numeric(pd.Series([r.get('fcf_margin')]), errors='coerce').iloc[0]
                    note_parts = [f'Quant DETAIL {business_year} {REPORT_LABELS.get(report_code, report_code)}', f"gate={r.get('screen_gate', '')}"]
                    if pd.notna(rg):
                        note_parts.append(f'rev_g={rg * 100:.1f}%')
                    if pd.notna(om):
                        note_parts.append(f'op_m={om * 100:.1f}%')
                    if pd.notna(cm):
                        note_parts.append(f'cfo_m={cm * 100:.1f}%')
                    if pd.notna(fm):
                        note_parts.append(f'fcf_m={fm * 100:.1f}%')
                    updated.at[i, 'note'] = '; '.join(note_parts)
                save_csv(updated, 'market_candidates.csv')
                st.success('Candidate Queue에 저장했습니다. 다음 단계는 개별 원공시 확인 → Data Quality → Reverse DCF → Bear downside 검증입니다.')
                st.rerun()
    elif fast_results.empty:
        st.info('먼저 FAST 수집과 FAST 필터를 진행하세요.')
    elif detail_period.empty:
        st.info('FAST 통과 종목의 DETAIL 수집을 작은 배치부터 실행하세요.')
    else:
        st.info('현재 DETAIL 조건을 통과한 종목이 없습니다. 필터 또는 상세수집 범위를 확인하세요.')
    with st.expander('수집 오류 / 데이터 누락'):
        e1, e2 = st.columns(2)
        fast_errors = fast_period[fast_period['scan_status'].astype(str) != 'OK'].copy() if not fast_period.empty else pd.DataFrame()
        detail_errors = detail_period[detail_period['scan_status'].astype(str) != 'OK'].copy() if not detail_period.empty else pd.DataFrame()
        with e1:
            st.write(f'FAST 오류/누락: {len(fast_errors):,}')
            if not fast_errors.empty:
                cols = [c for c in ['code', 'name', 'scan_status', 'error', 'scan_timestamp'] if c in fast_errors.columns]
                st.dataframe(fast_errors[cols].head(200), width='stretch', hide_index=True)
        with e2:
            st.write(f'DETAIL 오류/누락: {len(detail_errors):,}')
            if not detail_errors.empty:
                cols = [c for c in ['code', 'name', 'scan_status', 'error', 'scan_timestamp'] if c in detail_errors.columns]
                st.dataframe(detail_errors[cols].head(200), width='stretch', hide_index=True)
    st.warning('FAST_PASS / PASS_1ST는 투자 승인이나 매수 추천이 아닙니다. 금융업 등 특수업종은 별도 모델이 필요하고, DETAIL 통과 후에도 Debt maturity·covenant·Evidence·Reverse DCF·Bear downside·Portfolio Fit을 확인해야 합니다.')
