from __future__ import annotations
if True:
    st.title('Market Universe')
    st.caption('KOSPI·KOSDAQ의 주식 종목코드(보통주·우선주 등)를 넓게 보고 → Candidate Queue → Watchlist → Data Quality / OpenDART / Reverse DCF 순서로 좁힙니다. 이 화면은 주문을 전송하지 않습니다.')
    universe = ensure_universe_cols(load_csv('market_universe.csv'))
    candidates = ensure_candidate_cols(load_csv('market_candidates.csv'))
    c_sync, c_clear = st.columns([3, 1])
    with c_sync:
        if st.button('KOSPI + KOSDAQ 주식 종목코드 동기화', type='primary'):
            with st.spinner('KOSPI·KOSDAQ 종목코드 목록을 불러오는 중입니다...'):
                try:
                    fresh, source_mode = fetch_market_universe(timeout=25)
                    fresh = ensure_universe_cols(fresh)
                    if fresh.empty:
                        st.error('조회 결과가 비어 있습니다. 기존 캐시는 유지했습니다.')
                    else:
                        save_csv(fresh, 'market_universe.csv')
                        st.session_state['universe_source_mode'] = source_mode
                        st.success(f'{len(fresh):,}개 종목코드를 저장했습니다. Coverage: {source_mode}')
                        st.rerun()
                except Exception as e:
                    st.error(f'전체 종목 동기화 실패: {e}')
                    st.info('기존 market_universe.csv 캐시가 있으면 그대로 사용할 수 있습니다.')
    with c_clear:
        if not universe.empty:
            st.download_button('Universe CSV 저장', data=universe.to_csv(index=False).encode('utf-8-sig'), file_name='market_universe.csv', mime='text/csv')
    if universe.empty:
        st.info("아직 전체 종목 캐시가 없습니다. 위의 'KOSPI + KOSDAQ 주식 종목코드 동기화'를 한 번 눌러주세요.")
    else:
        source_mode = st.session_state.get('universe_source_mode', '')
        sources = ', '.join(sorted(set(universe['source'].fillna('').astype(str)))[:3])
        latest_sync = universe['source_timestamp'].fillna('').astype(str).max()
        codes_now = set(universe['code'].fillna('').astype(str).str.replace('\\.0$', '', regex=True).str.zfill(6))
        samsung_pref_ok = '005935' in codes_now
        pref_count = int((universe['security_group'].fillna('').astype(str) == '우선주').sum())
        a, b, c, d, e = st.columns(5)
        a.metric('전체 종목코드', f'{len(universe):,}')
        b.metric('KOSPI', f"{int((universe['market'] == 'KOSPI').sum()):,}")
        c.metric('KOSDAQ', f"{int((universe['market'] == 'KOSDAQ').sum()):,}")
        d.metric('우선주(식별)', f'{pref_count:,}')
        e.metric('Candidate Queue', f'{len(candidates):,}')
        st.caption(f"Source: {sources or source_mode or '-'} / 마지막 동기화: {latest_sync or '-'}")
        source_text = ' '.join(universe['source'].fillna('').astype(str).unique()).upper()
        if 'KRX DATA MARKETPLACE' in source_text:
            st.success('Coverage: SECURITY-LEVEL FULL · KRX 종목단위 원본을 사용 중입니다.')
        elif 'NAVER FINANCE' in source_text:
            st.info('Coverage: SECURITY-LEVEL FALLBACK · KRX 직접 연결 대신 종목코드 단위 fallback을 사용 중입니다. 보통주·우선주는 별도 코드로 유지되며, 일부 상세 회사정보는 비어 있을 수 있습니다.')
        elif 'KIND' in source_text:
            st.warning('Coverage: COMPANY-LEVEL FALLBACK · 현재 데이터는 상장법인 단위입니다. 우선주 등 별도 증권종목이 누락될 수 있으므로 종목코드 동기화를 다시 시도하세요.')
        if samsung_pref_ok:
            st.success('종목단위 검증 PASS: 삼성전자우(005935)가 Universe에 포함되어 있습니다.')
        else:
            st.warning("종목단위 검증 CHECK: 삼성전자우(005935)가 없습니다. 현재 Universe를 '모든 주식 종목코드'로 간주하지 마세요.")
        st.subheader('1) 전체 종목 검색 / 1차 압축')
        f1, f2, f3, f4 = st.columns(4)
        market_opts = ['KOSPI', 'KOSDAQ']
        markets = f1.multiselect('시장', market_opts, default=market_opts)
        keyword = f2.text_input('종목명 / 코드 / 업종 / 주요제품 검색')
        industries = ['전체'] + sorted([x for x in universe['industry'].fillna('').astype(str).unique() if x])[:1000]
        industry = f3.selectbox('업종', industries)
        groups = ['전체'] + sorted([x for x in universe['security_group'].fillna('').astype(str).unique() if x])
        security_group = f4.selectbox('증권구분', groups)
        r1, r2 = st.columns(2)
        regions = ['전체'] + sorted([x for x in universe['region'].fillna('').astype(str).unique() if x])
        region = r1.selectbox('지역', regions)
        display_limit = int(r2.number_input('화면 표시 최대 행', min_value=50, max_value=5000, value=500, step=50))
        filtered = filter_universe(universe, markets=markets, keyword=keyword, industry=industry, region=region, security_group=security_group)
        st.write(f'현재 필터 결과: **{len(filtered):,}개**')
        view_cols = [c for c in ['code', 'name', 'market', 'security_group', 'department', 'industry', 'listing_date', 'shares_listed', 'major_products', 'region'] if c in filtered.columns]
        st.dataframe(filtered[view_cols].head(display_limit), width='stretch', hide_index=True, height=470)
        st.download_button('현재 필터 결과 CSV', data=filtered.to_csv(index=False).encode('utf-8-sig'), file_name='market_universe_filtered.csv', mime='text/csv', disabled=filtered.empty)
        st.subheader('2) Candidate Queue에 담기')
        st.caption('필터된 종목 중 분석하고 싶은 종목만 체크하세요. Candidate Queue에 넣는 것만으로 매수 후보가 확정되거나 Data Quality가 PASS 되는 것은 아닙니다.')
        selectable = filtered.head(display_limit).copy()
        if selectable.empty:
            st.info('현재 필터에 해당하는 종목이 없습니다.')
        else:
            selectable.insert(0, 'select', False)
            select_cols = [c for c in ['select', 'code', 'name', 'market', 'security_group', 'industry', 'listing_date', 'region'] if c in selectable.columns]
            selected_editor = st.data_editor(selectable[select_cols], num_rows='fixed', width='stretch', hide_index=True, disabled=[c for c in select_cols if c != 'select'], column_config={'select': st.column_config.CheckboxColumn('선택', default=False)}, key='market_universe_select_editor')
            if st.button('체크한 종목 → Candidate Queue 추가'):
                picks = selected_editor[selected_editor['select'] == True].drop(columns=['select'], errors='ignore')
                if picks.empty:
                    st.warning('먼저 종목을 체크해주세요.')
                else:
                    codes = set(picks['code'].astype(str))
                    picked_full = universe[universe['code'].astype(str).isin(codes)]
                    new_candidates = add_candidates(candidates, picked_full)
                    added = max(0, len(new_candidates) - len(candidates))
                    save_csv(new_candidates, 'market_candidates.csv')
                    st.success(f'Candidate Queue 저장 완료: 신규 {added:,}개')
                    st.rerun()
    st.divider()
    st.subheader('3) Candidate Queue → Watchlist')
    candidates = ensure_candidate_cols(load_csv('market_candidates.csv'))
    if candidates.empty:
        st.info('Candidate Queue가 비어 있습니다. 위 전체 종목에서 먼저 후보를 체크해 추가하세요.')
    else:
        q = candidates.copy()
        q.insert(0, 'to_watchlist', False)
        q.insert(1, 'remove', False)
        q_cols = [c for c in ['to_watchlist', 'remove', 'code', 'name', 'market', 'industry', 'security_group', 'listing_date', 'status', 'added_at', 'note'] if c in q.columns]
        q_editor = st.data_editor(q[q_cols], num_rows='fixed', width='stretch', hide_index=True, disabled=[c for c in q_cols if c not in {'to_watchlist', 'remove', 'note'}], column_config={'to_watchlist': st.column_config.CheckboxColumn('Watchlist', default=False), 'remove': st.column_config.CheckboxColumn('삭제', default=False)}, key='candidate_queue_editor')
        b1, b2 = st.columns(2)
        with b1:
            if st.button('체크한 후보 → Watchlist 추가', type='primary'):
                picks = q_editor[q_editor['to_watchlist'] == True].copy()
                if picks.empty:
                    st.warning('Watchlist로 보낼 후보를 체크해주세요.')
                else:
                    add_rows = candidate_to_watchlist_rows(picks, settings)
                    new_watch, added = append_watchlist(watchlist, add_rows, WATCH_COLS)
                    save_csv(ensure_cols(new_watch, WATCH_COLS), 'watchlist.csv')
                    picked_codes = set(picks['code'].astype(str))
                    updated_candidates = candidates.copy()
                    updated_candidates.loc[updated_candidates['code'].astype(str).isin(picked_codes), 'status'] = 'WATCHLIST'
                    if 'note' in q_editor.columns:
                        note_map = q_editor.set_index('code')['note'].to_dict()
                        updated_candidates['note'] = updated_candidates.apply(lambda r: note_map.get(r['code'], r.get('note', '')), axis=1)
                    save_csv(updated_candidates, 'market_candidates.csv')
                    st.success(f'Watchlist 신규 추가 {added:,}개. 다음 순서: 주가·평가액 갱신 → 전자공시 자동 수집 → 데이터 품질.')
                    st.rerun()
        with b2:
            if st.button('삭제 체크한 후보 제거'):
                drops = set(q_editor.loc[q_editor['remove'] == True, 'code'].astype(str))
                if not drops:
                    st.warning('삭제할 후보를 체크해주세요.')
                else:
                    kept = candidates[~candidates['code'].astype(str).isin(drops)].reset_index(drop=True)
                    save_csv(kept, 'market_candidates.csv')
                    st.success(f'{len(drops):,}개 후보를 Candidate Queue에서 제거했습니다.')
                    st.rerun()
        st.info('Watchlist에 새로 보낸 종목은 price / bear_downside / refinancing / Evidence가 미확인이라 처음에는 Data Quality BLOCKED/REVIEW가 정상입니다. 자동으로 PASS 처리하지 않습니다.')
