from __future__ import annotations
if True:
    st.title('Execution Checklist')
    st.caption('Strict 시나리오가 실제 계좌에 반영된 뒤에만 다음 Recipient 검토 티켓을 엽니다. 이 화면은 주문을 전송하지 않습니다.')
    portfolio_names = portfolio['name'].dropna().astype(str).tolist()
    if not portfolio_names:
        portfolio_names = ['']
    donor_default = portfolio_names.index('삼성전자') if '삼성전자' in portfolio_names else 0
    donor_name = st.selectbox('Donor / Risk Repair Position', portfolio_names, index=donor_default, key='exec_donor')
    recipient_names = watchlist['name'].dropna().astype(str).tolist()
    if not recipient_names:
        recipient_names = ['']
    rec_default = recipient_names.index('NICE평가정보') if 'NICE평가정보' in recipient_names else 0
    recipient_name = st.selectbox('Recipient Candidate', recipient_names, index=rec_default, key='exec_recipient')
    a, b, c = st.columns(3)
    strict_target_qty = a.number_input('Strict actual target shares', min_value=0, step=1, value=int(settings.get('default_strict_target_qty', 0)), key='exec_strict_qty')
    minimum_cash_weight = b.number_input('Minimum Cash Weight', min_value=0.0, max_value=1.0, value=float(settings.get('minimum_cash_weight', 0.2)), format='%.2f', key='exec_min_cash')
    reconciliation_tolerance = c.number_input('Reconciliation tolerance KRW', min_value=0.0, value=float(settings.get('reconciliation_tolerance_krw', 1000)), step=1000.0, key='exec_recon_tol')
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    audit_df = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    try:
        checklist, ticket = build_strict_execution_checklist(portfolio, watchlist, state_df, audit_df, proof, total_assets, donor_name, recipient_name, int(strict_target_qty), loss_budget, single_cap, minimum_cash_weight, reconciliation_tolerance, bool(settings.get('execution_requires_proof_clock', True)))
    except Exception as e:
        checklist = pd.DataFrame()
        ticket = {'ticket_status': 'BLOCKED'}
        st.error(str(e))
    if not checklist.empty:
        pass_n = int(checklist['status'].eq('PASS').sum())
        block_n = int(checklist['status'].eq('BLOCK').sum())
        review_n = int(checklist['status'].eq('REVIEW').sum())
        m1, m2, m3, m4 = st.columns(4)
        m1.metric('Ticket Status', ticket.get('ticket_status', '-'))
        m2.metric('PASS', pass_n)
        m3.metric('BLOCK', block_n)
        m4.metric('REVIEW', review_n)
        st.subheader('Strict Execution Gates')
        st.dataframe(checklist, width='stretch', hide_index=True)
        blockers = checklist.loc[checklist['hard_gate'] & ~checklist['status'].eq('PASS')]
        if ticket.get('ticket_status') != 'READY_FOR_FINAL_REVIEW':
            st.error('Final Review Ticket은 아직 잠겨 있습니다.')
            if not blockers.empty:
                st.write('먼저 해결할 Hard Gate:')
                st.dataframe(blockers[['gate', 'status', 'detail', 'next_action']], width='stretch', hide_index=True)
        else:
            st.success('모든 Hard Gate가 통과했습니다. 아래 티켓은 최종 검토용이며 주문을 전송하지 않습니다.')
            st.subheader('Final Review Ticket')
            ticket_df = pd.DataFrame([ticket])
            st.dataframe(ticket_df, width='stretch', hide_index=True)
            st.download_button('Final Review Ticket CSV 받기', ticket_df.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'final_review_ticket.csv', 'text/csv')
        if st.button('현재 Checklist Snapshot 저장'):
            log = load_csv('execution_checklist_log.csv')
            row = {'generated_at': ticket.get('generated_at', ''), 'donor': donor_name, 'strict_target_qty': int(strict_target_qty), 'recipient': recipient_name, 'ticket_status': ticket.get('ticket_status', 'BLOCKED'), 'recipient_state': ticket.get('recipient_state', ''), 'recipient_price_reference': ticket.get('recipient_price_reference', 0), 'recipient_price_ceiling': ticket.get('recipient_price_ceiling', 0), 'recipient_bear_downside': ticket.get('recipient_bear_downside', 0), 'recipient_review_add_qty': ticket.get('recipient_review_add_qty', 0), 'recipient_review_amount_krw': ticket.get('recipient_review_amount_krw', 0), 'recipient_post_weight_proxy': ticket.get('recipient_post_weight_proxy', 0), 'recipient_post_bear_car_proxy': ticket.get('recipient_post_bear_car_proxy', 0), 'explicit_cash_krw': ticket.get('explicit_cash_krw', 0), 'minimum_cash_value_krw': ticket.get('minimum_cash_value_krw', 0), 'post_review_cash_proxy_krw': ticket.get('post_review_cash_proxy_krw', 0), 'instruction': ticket.get('instruction', '')}
            save_csv(pd.concat([log, pd.DataFrame([row])], ignore_index=True), 'execution_checklist_log.csv')
            st.success('data/execution_checklist_log.csv에 저장했습니다.')
        st.caption('중요: Strict target은 실제 Portfolio 수량과 일치해야 통과합니다. 매도대금은 실제 계좌의 현금으로 반영하고 Reconciliation을 다시 맞춘 뒤 다음 Gate가 열립니다.')
