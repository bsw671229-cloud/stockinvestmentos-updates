from __future__ import annotations
if True:
    st.title('Trade Planner')
    st.caption('REVIEW ONLY. 주문은 전송하지 않습니다. 가격·Evidence·유동성을 다시 확인한 뒤 사용자가 증권사에서 최종 결정합니다.')
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    evidence_df = audit_evidence.copy()
    audit = data_quality_report(watchlist, evidence_df, int(settings.get('audit_price_freshness_days', 3)))
    pilot = st.number_input('Initial Pilot Fraction of Risk Max', 0.05, 1.0, float(settings.get('trade_plan_pilot_fraction', 0.5)), format='%.2f')
    plan = generate_trade_plan(state_df, portfolio, total_assets, loss_budget, single_cap, pilot)
    if bool(settings.get('planner_requires_audit_ready', True)):
        plan = apply_audit_gate(plan, audit)
    if plan.empty:
        st.info('계획을 만들 데이터가 없습니다.')
    else:
        priority = {'EXIT': 0, 'TRIM': 1, 'MAX': 2, 'CORE': 3, 'INITIAL': 4, 'ADD FREEZE': 5, 'OBSERVE': 6}
        plan['_rank'] = plan['state'].map(priority).fillna(9)
        plan = plan.sort_values(['_rank', 'name']).drop(columns=['_rank'])
        st.dataframe(plan, width='stretch', hide_index=True)
        sells = plan[plan['side'] == 'SELL']['estimated_amount_krw'].sum()
        buys = plan[plan['side'] == 'BUY']['estimated_amount_krw'].sum()
        c1, c2, c3 = st.columns(3)
        c1.metric('Estimated Sells', krw(sells))
        c2.metric('Estimated Buys', krw(buys))
        c3.metric('Net Cash Change', krw(sells - buys))
        st.download_button('Trade Plan CSV 받기', plan.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'trade_plan_review.csv', 'text/csv')
        st.warning('소액계좌에서는 1주 단위 때문에 Risk Max를 정확히 맞출 수 없습니다. SELL 수량은 target shares 기준이며, 실행 전 실제 보유수량·가격을 확인하세요.')
