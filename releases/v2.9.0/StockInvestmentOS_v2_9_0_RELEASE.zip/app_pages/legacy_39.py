from __future__ import annotations
if True:
    st.title('Stress Lab')
    st.caption('상관관계는 과거 데이터의 요약이며 위기 때 급변할 수 있습니다. Worst-case와 함께 보세요.')
    pnorm = normalize_portfolio(portfolio, total_assets if total_assets > 0 else None)
    holdings = ensure_cols(load_csv('etf_holdings.csv'), ETF_HOLDING_COLS)
    lt = portfolio_lookthrough(portfolio, holdings)
    fxexp = exposure_summary(lt, 'factor', total_assets if total_assets > 0 else None) if not lt.empty else factor_exposure(pnorm)
    tab1, tab2 = st.tabs(['Factor Stress', 'Historical Correlation'])
    with tab1:
        shocks = load_csv('factor_stress.csv')
        if shocks.empty:
            shocks = pd.DataFrame(columns=['factor', 'shock'])
        edited = st.data_editor(shocks, num_rows='dynamic', width='stretch', key='factor_stress_editor')
        if st.button('Factor Stress 저장'):
            if verified_save_feedback(edited, 'factor_stress.csv', 'Factor Stress를 저장했습니다.', rerun=False):
                shocks = edited
        if not fxexp.empty:
            if 'factor' not in fxexp.columns:
                fxexp = fxexp.rename(columns={fxexp.columns[0]: 'factor'})
            stressed = apply_factor_shocks(fxexp[['factor', 'value_krw', 'portfolio_weight']], edited)
            c1, c2 = st.columns(2)
            c1.metric('Factor Stress Loss', pct(stressed['portfolio_loss'].sum() if not stressed.empty else 0))
            direct_worst = float((pnorm['weight'] * pnorm['bear_downside']).sum()) if not pnorm.empty else 0
            c2.metric('Direct Bear Worst-case', pct(direct_worst))
            st.dataframe(stressed, width='stretch', hide_index=True)
        else:
            st.info('Factor exposure가 없습니다.')
    with tab2:
        hist_period = st.selectbox('Historical period', ['6mo', '1y', '2y'], index=1)
        p = portfolio.copy()
        p['ticker'] = p.get('ticker', '').fillna('').astype(str).str.strip()
        usable = p[p['ticker'] != ''].copy()
        _stress_saved_records = normalize_historical_correlation_records(load_csv('historical_correlation.csv'))
        _stress_saved_corr = historical_correlation_matrix_from_records(_stress_saved_records)
        if 'stress_corr' not in st.session_state or not isinstance(st.session_state.get('stress_corr'), pd.DataFrame) or st.session_state.get('stress_corr').empty:
            if not _stress_saved_corr.empty:
                st.session_state['stress_corr'] = _stress_saved_corr
        if len(usable) < 2:
            st.info('Ticker가 입력된 보유자산이 2개 이상 있어야 historical correlation을 계산할 수 있습니다.')
        elif st.button('Correlation 계산 / 저장', type='primary'):
            try:
                with st.spinner('가격 이력을 다운로드하는 중...'):
                    prices = multi_price_matrix(usable['ticker'].drop_duplicates().tolist(), hist_period)
                corr = returns_correlation(prices)
                _stress_records = historical_correlation_records_from_matrix(corr, prices, period=hist_period, source='connectors.market.multi_price_matrix')
                save_csv(_stress_records, 'historical_correlation.csv')
                st.session_state['stress_corr'] = historical_correlation_matrix_from_records(_stress_records)
                st.success('Historical Correlation Source를 저장했습니다.')
            except Exception as e:
                st.error(str(e))
        if 'stress_corr' in st.session_state:
            corr = st.session_state['stress_corr']
            st.dataframe(corr.style.format('{:.2f}'), width='stretch')
            rows = []
            for _, r in usable.iterrows():
                t = str(r['ticker'])
                rows.append({'ticker': t, 'weight': float(pd.to_numeric(pd.Series([r.get('current_value_krw')]), errors='coerce').fillna(0).iloc[0]) / (total_assets or 1), 'bear_downside': float(pd.to_numeric(pd.Series([r.get('bear_downside')]), errors='coerce').fillna(0).iloc[0])})
            rd = pd.DataFrame(rows).groupby('ticker', as_index=True).agg({'weight': 'sum', 'bear_downside': 'max'})
            res = correlated_bear_loss(rd['weight'], rd['bear_downside'], corr)
            c1, c2 = st.columns(2)
            c1.metric('Worst-case Bear Sum', pct(res['worst_case_loss']))
            c2.metric('Correlation-adjusted Proxy', pct(res['correlated_loss_proxy']))
            st.caption('Correlation-adjusted 값은 분산-공분산 형태의 proxy입니다. 위기에서는 상관이 1에 가까워질 수 있으므로 sizing에는 Worst-case도 함께 사용하세요.')
