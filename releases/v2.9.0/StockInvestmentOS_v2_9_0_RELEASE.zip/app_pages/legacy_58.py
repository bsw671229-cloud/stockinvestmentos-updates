from __future__ import annotations
if True:
    st.title('Market Data')
    ticker = st.text_input('Ticker / Code', value='005930')
    market = st.selectbox('Market', ['KOSPI', 'KOSDAQ', 'US/Other'])
    c1, c2 = st.columns(2)
    if c1.button('가격 조회'):
        try:
            p = latest_price(ticker, market)
            st.success(f"{p.ticker}: {p.price:,.2f} {p.currency or ''} / {p.timestamp}")
            hist = price_history(ticker, market, '6mo')
            idx = 'Date' if 'Date' in hist.columns else 'Datetime' if 'Datetime' in hist.columns else None
            st.line_chart(hist.set_index(idx)['Close'] if idx else hist['Close'])
        except Exception as e:
            st.error(str(e))
    if c2.button('USD/KRW 조회'):
        try:
            fx = latest_fx('USD', 'KRW')
            st.success(f'USD/KRW: {fx.price:,.2f} / {fx.timestamp}')
        except Exception as e:
            st.error(str(e))
