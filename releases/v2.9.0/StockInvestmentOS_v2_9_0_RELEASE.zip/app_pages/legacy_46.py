from __future__ import annotations
if True:
    st.title('Post-Trade Audit')
    st.caption('이미 로컬 Portfolio에 반영된 실제 체결을 사후 감사합니다. 주문 전송 기능은 없으며, 결과가 좋아도 의사결정이 좋았다는 뜻은 아닙니다.')
    fills = ensure_cols(load_csv('execution_fills.csv'), FILL_COLS)
    if fills.empty:
        st.info('감사할 실제 체결내역이 없습니다. Fill Reconciliation에서 이미 체결된 거래를 기록한 뒤 사용하세요.')
    else:
        fills = fills.copy()
        fills['_sort_ts'] = pd.to_datetime(fills['fill_timestamp'], errors='coerce')
        fills = fills.sort_values('_sort_ts', ascending=False, na_position='last').drop(columns=['_sort_ts'])
        labels = [f"{row.get('fill_id', '')} / {row.get('name', '')} / {row.get('side', '')} {row.get('quantity', '')}주 @ {row.get('fill_price', '')}" for _, row in fills.iterrows()]
        selected_label = st.selectbox('감사할 Fill 선택', labels)
        selected_pos = labels.index(selected_label)
        fill = fills.iloc[selected_pos].to_dict()
        st.subheader('0. Pre-Trade Packet Lineage')
        _post_fill_lineage_history = load_csv('pretrade_fill_lineage.csv')
        _post_fill_lineage = None
        if not _post_fill_lineage_history.empty and 'fill_id' in _post_fill_lineage_history.columns:
            _fill_id_text = str(fill.get('fill_id', '') or '').strip()
            _lhit = _post_fill_lineage_history.loc[_post_fill_lineage_history['fill_id'].fillna('').astype(str).str.strip().eq(_fill_id_text)].copy()
            if not _lhit.empty:
                if 'created_at' in _lhit.columns:
                    _lhit['_ts'] = pd.to_datetime(_lhit['created_at'], errors='coerce', utc=True)
                    _lhit = _lhit.sort_values('_ts', ascending=False, na_position='last')
                _post_fill_lineage = _lhit.iloc[0].to_dict()
        if _post_fill_lineage is None:
            st.info('이 Fill에는 연결된 Pre-Trade Packet Lineage가 없습니다. 기존 Fill도 Post-Trade Audit은 계속 수행할 수 있습니다.')
        else:
            _post_fill_lineage_integrity = pretrade_fill_lineage_integrity(_post_fill_lineage)
            pl1, pl2, pl3, pl4 = st.columns(4)
            pl1.metric('Packet ID', str(_post_fill_lineage.get('packet_id', '') or '-'))
            pl2.metric('Fill Lineage', str(_post_fill_lineage.get('lineage_status', '') or '-'))
            pl3.metric('Lineage Integrity', _post_fill_lineage_integrity['status'])
            pl4.metric('Execution Authorization', 'NONE')
            pl5, pl6, pl7, pl8 = st.columns(4)
            pl5.metric('Planned Qty', str(_post_fill_lineage.get('planned_quantity', '') or '-'))
            pl6.metric('Actual Qty', str(_post_fill_lineage.get('actual_quantity', '') or '-'))
            pl7.metric('Locked Quote', krw(_post_fill_lineage.get('locked_quote_price_krw', 0)))
            pl8.metric('Actual Fill', krw(_post_fill_lineage.get('actual_fill_price_krw', 0)))
            st.caption('Pre-Trade Packet → 실제 Fill → Post-Trade Audit의 lineage를 추적합니다. MATCH는 체결 terms가 locked plan과 일치했다는 뜻이며 주문승인 의미가 아닙니다.')
            _lineage_issues = str(_post_fill_lineage.get('issues', '') or '').strip()
            if _lineage_issues:
                st.warning('Pre-Trade ↔ Fill Lineage 사유 · ' + _lineage_issues)
        threshold = st.number_input('Price slippage REVIEW threshold', min_value=0.0, max_value=0.2, value=float(settings.get('post_trade_slippage_review_threshold', 0.02)), step=0.005, format='%.3f')
        state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
        audit_df = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
        execution_log = load_csv('execution_checklist_log.csv')
        checks, summary = build_post_trade_audit(fill, portfolio, watchlist, state_df, audit_df, execution_log, total_assets, loss_budget, single_cap, float(settings.get('minimum_cash_weight', 0.2)), float(settings.get('reconciliation_tolerance_krw', 1000)), float(threshold))
        a, b, c, d = st.columns(4)
        a.metric('Audit Status', summary.get('audit_status', '-'))
        b.metric('Hard Blocks', int(summary.get('hard_blocks', 0)))
        c.metric('Reviews', int(summary.get('reviews', 0)))
        cqty = summary.get('current_quantity', 0)
        d.metric('Current Qty', int(cqty))
        a, b, c, d = st.columns(4)
        a.metric('Current Weight', pct(summary.get('current_weight', 0)))
        b.metric('Risk Max', pct(summary.get('risk_max', 0)))
        c.metric('Bear CAR', pct(summary.get('bear_car', 0)))
        d.metric('Cash Weight', pct(summary.get('cash_weight', 0)))
        st.subheader('Audit Checks')
        st.dataframe(checks, width='stretch', hide_index=True)
        if summary.get('audit_status') == 'PASS':
            st.success('현재 Hard Check 기준 PASS입니다. REVIEW 항목이 있으면 사후 기록/학습 대상으로 남기세요.')
        else:
            st.error('Hard Check 위반이 있습니다. 원인 확인 후 Portfolio/Evidence/Risk 기록을 정정하세요.')
        st.subheader('Audit Summary')
        summary_df = pd.DataFrame([summary])
        st.dataframe(summary_df, width='stretch', hide_index=True)
        c1, c2 = st.columns(2)
        if c1.button('Post-Trade Audit 저장', type='primary'):
            log = ensure_cols(load_csv('post_trade_audit_log.csv'), POST_TRADE_AUDIT_COLS)
            save_csv(pd.concat([log, summary_df], ignore_index=True), 'post_trade_audit_log.csv')
            if _post_fill_lineage is not None:
                _post_lineage_row = build_pretrade_posttrade_lineage_record(_post_fill_lineage, summary, note='Linked automatically when Post-Trade Audit was saved.')
                _post_lineage_hist = load_csv('pretrade_posttrade_lineage.csv')
                for _col in PRETRADE_POSTTRADE_LINEAGE_COLS:
                    if _col not in _post_lineage_hist.columns:
                        _post_lineage_hist[_col] = ''
                _post_lineage_hist = pd.concat([_post_lineage_hist[PRETRADE_POSTTRADE_LINEAGE_COLS], pd.DataFrame([_post_lineage_row])], ignore_index=True)
                save_csv(_post_lineage_hist, 'pretrade_posttrade_lineage.csv')
            st.success('data/post_trade_audit_log.csv에 저장했습니다. 연결된 Pre-Trade Fill Lineage가 있으면 pretrade_posttrade_lineage.csv에도 연결 기록을 저장했습니다.')
        if c2.button('Decision Journal DRAFT 만들기'):
            journal = ensure_cols(load_csv('decision_journal.csv'), JOURNAL_COLS)
            expected = f"Post-trade monitoring: lifecycle={(state_df.loc[state_df['name'].astype(str) == str(summary.get('name', '')), 'lifecycle_state'].iloc[0] if not state_df.loc[state_df['name'].astype(str) == str(summary.get('name', ''))].empty else 'UNKNOWN')}, risk_max={summary.get('risk_max', 0):.2%}, bear_car={summary.get('bear_car', 0):.2%}."
            entry = new_entry(company=summary.get('name', ''), decision_type='Post-Trade Audit', lifecycle_state='', action=f"{summary.get('side', '')} fill audited", reason=f"Audit status {summary.get('audit_status', '')}; fill_id {summary.get('fill_id', '')}", evidence_url='', proof_date='', expected_outcome=expected, notes='DRAFT created from Post-Trade Audit; classify forecast error later if needed.')
            save_csv(pd.concat([journal, entry], ignore_index=True), 'decision_journal.csv')
            st.success('Decision Journal에 DRAFT 기록을 만들었습니다.')
        st.download_button('현재 Audit CSV 받기', summary_df.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'post_trade_audit.csv', 'text/csv')
        st.subheader('Saved Post-Trade Audit Log')
        saved = ensure_cols(load_csv('post_trade_audit_log.csv'), POST_TRADE_AUDIT_COLS)
        if saved.empty:
            st.info('저장된 Post-Trade Audit이 없습니다.')
        else:
            st.dataframe(saved.sort_values('audit_timestamp', ascending=False), width='stretch', hide_index=True)
        _post_lineage_saved = load_csv('pretrade_posttrade_lineage.csv')
        if not _post_lineage_saved.empty:
            st.subheader('Pre-Trade → Fill → Post-Trade Lineage Log')
            st.dataframe(_post_lineage_saved.tail(30), width='stretch', hide_index=True)
