from __future__ import annotations
if True:
    st.title('Start Here')
    st.caption('초보자용 전체 상태 점검입니다. CHECK 항목부터 순서대로 확인하면 됩니다.')
    evidence = audit_evidence.copy()
    audit = data_quality_report(watchlist, evidence, int(settings.get('audit_price_freshness_days', 3)))
    aq = audit_summary(audit)
    recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    dart_key_ok = bool(os.getenv('DART_API_KEY', '') or st.session_state.get('dart_api_key', ''))
    corp_cache_ok = (ROOT / 'data' / 'dart_corp_codes.csv').exists()
    clock = enrich_proof_clock(proof)
    overdue = int((clock['clock_status'] == 'OVERDUE').sum()) if not clock.empty else 0
    rows = [['1. Portfolio Reconciliation', recon['status'], f"Gap {krw(recon['gap_krw'])}", 'Reconciliation'], ['2. Data Quality', 'PASS' if aq['blocked'] == 0 and aq['review'] == 0 and (aq['ready'] == aq['total']) else 'CHECK', f"READY {aq['ready']} / REVIEW {aq['review']} / BLOCKED {aq['blocked']}", 'Data Quality'], ['3. DART Key', 'PASS' if dart_key_ok else 'CHECK', 'API key detected' if dart_key_ok else 'DART API key missing', 'OpenDART Auto'], ['4. DART Corp Codes', 'PASS' if corp_cache_ok else 'CHECK', 'corp code cache ready' if corp_cache_ok else '고유번호 목록 동기화 필요', 'OpenDART Auto'], ['5. Proof Clock', 'PASS' if overdue == 0 else 'CHECK', f'OVERDUE {overdue}', 'Proof Clock']]
    integration_df, integration_summary = build_global_integration_audit(watchlist, portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    rows.append(['6. System Integration', 'PASS' if integration_summary['status'] == 'PASS' else 'CHECK', f"PASS {integration_summary['pass']} / REVIEW {integration_summary['review']} / BLOCKED {integration_summary['blocked']}", 'System Integration'])
    rows.append(['7. Decision Summary', 'PASS' if not watchlist.empty else 'CHECK', 'Watchlist 종목의 현재 행동을 한 화면에서 확인' if not watchlist.empty else 'Watchlist 종목 필요', 'Decision Summary'])
    save_health = verify_user_data_health()
    save_fail = int((save_health['status'] == 'FAIL').sum()) if not save_health.empty else 0
    rows.append(['8. Save Health', 'PASS' if save_fail == 0 else 'CHECK', f'CSV 오류 {save_fail}개 / 파일 {len(save_health)}개', 'Save Center'])
    start_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    start_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    start_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    start_thesis = build_thesis_monitor(watchlist, start_states, start_plans, start_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
    start_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=start_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=start_kpis, state_df=start_states, thesis_monitor=start_thesis, audit_df=audit, reconciliation=recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)))
    start_qs = review_queue_summary(start_queue)
    rows.append(['9. Monitoring & Review Queue', 'CHECK' if start_qs['attention_now'] > 0 else 'PASS', f"OVERDUE {start_qs['overdue']} / TODAY+NOW {start_qs['today'] + start_qs['now']} / NEXT 7D {start_qs['next_7_days']}", 'Review Queue'])
    rows.append(['10. Integrated Action Planner', 'PASS' if not watchlist.empty else 'CHECK', '오늘 허용되는 행동 / 금지되는 행동 / 다음 원본 화면을 한 곳에서 확인' if not watchlist.empty else 'Watchlist 종목 필요', 'Action Planner'])
    rows.append(['11. Stability / E2E Audit', 'PASS', '기술 무결성과 투자 Gate 상태를 분리해 전체 연결 점검', 'Stability Audit'])
    health = pd.DataFrame(rows, columns=['Check', 'Status', 'Detail', 'Go To'])
    st.dataframe(health, width='stretch', hide_index=True)
    if recon['status'] != 'PASS':
        st.error('먼저 Reconciliation에서 총자산과 보유자산 합계를 맞추세요.')
    elif aq['blocked'] > 0:
        st.warning('다음은 Data Quality에서 BLOCKED 종목의 누락 데이터부터 확인하세요.')
    elif not dart_key_ok or not corp_cache_ok:
        st.info('다음은 OpenDART Auto에서 DART 연결을 확인하세요.')
    elif overdue > 0:
        st.warning('Proof Clock의 OVERDUE 항목을 먼저 확인하세요.')
    else:
        st.success('기본 운영 Gate가 통과했습니다. Daily Briefing → Alerts → Rebalance Planner 순서로 점검하면 됩니다.')
    st.subheader('오늘의 기본 순서')
    st.markdown('1. **Daily Briefing** 실행\n2. **Reconciliation** 확인\n3. **Data Quality / Alerts** 확인\n4. **Proof Clock / DART 공시** 확인\n5. 필요할 때만 **Rebalance Planner** 확인\n6. 결정이 있으면 **Decision Journal**에 기록')
