from __future__ import annotations
if True:
    st.title('Save Center')
    st.caption('저장이 실제로 완료됐는지 확인하고, 사용자 데이터를 한 번에 백업하는 화면입니다.')
    st.info(f'{VERSION} · CSV 저장은 `백업 → 임시파일 저장 → 원본 교체 → 즉시 재읽기 검증`을 거칩니다. 정상이라면 저장 버튼을 여러 번 누를 필요가 없습니다.')
    save_health = verify_user_data_health()
    fail_count = int((save_health['status'] == 'FAIL').sum()) if not save_health.empty else 0
    pass_count = int((save_health['status'] == 'PASS').sum()) if not save_health.empty else 0
    st.subheader('1. 현재 저장 상태')
    s1, s2, s3 = st.columns(3)
    s1.metric('CSV PASS', pass_count)
    s2.metric('CSV FAIL', fail_count)
    s3.metric('검사 파일', len(save_health))
    if fail_count == 0:
        st.success('현재 읽을 수 없는 CSV 파일이 없습니다.')
    else:
        st.error('읽기 실패한 CSV가 있습니다. 아래 Error 열을 확인하세요.')
    if save_health.empty:
        st.info('data 폴더에 CSV 파일이 없습니다.')
    else:
        st.dataframe(save_health, width='stretch', hide_index=True)
    _sc_learning_release = build_learning_cycle_release_gate(load_csv('decision_learning_lineage.csv'), load_csv('learning_feedback_proposals.csv'), load_csv('learning_feedback_revalidation_drafts.csv'), load_csv('learning_feedback_change_lineage.csv'), load_csv('capital_productivity_inputs.csv'), load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'), today=date.today())
    st.subheader('1A. v1.22 Learning Release Data Gate')
    sd1, sd2, sd3, sd4 = st.columns(4)
    sd1.metric('CSV Data Gate', 'PASS' if fail_count == 0 else 'FAIL')
    sd2.metric('Learning Release Gate', _sc_learning_release['release_gate'])
    sd3.metric('Learning Orphans', _sc_learning_release['orphan_count'])
    sd4.metric('Execution Authorization', 'NONE')
    st.caption('여기서는 저장 가능성 + Learning Cycle 데이터 무결성을 같이 봅니다. Open cycle은 허용하지만 CSV FAIL / Hash mismatch / orphan은 Release 전에 해결합니다.')
    _sc_forecast_release = build_forecast_calibration_release_gate(load_csv('forecast_change_registry.csv'), load_csv('forecast_change_implementation_events.csv'), load_csv('forecast_change_effect_reviews.csv'), load_csv('decision_learning_lineage.csv'), today=date.today())
    st.subheader('1B. v1.23 Forecast Calibration Release Data Gate')
    fd1, fd2, fd3, fd4 = st.columns(4)
    fd1.metric('CSV Data Gate', 'PASS' if fail_count == 0 else 'FAIL')
    fd2.metric('Forecast Release Gate', _sc_forecast_release['release_gate'])
    fd3.metric('Parent Link Issues', _sc_forecast_release['parent_link_issues'])
    fd4.metric('Execution Authorization', 'NONE')
    st.caption('Forecast Change Plan / Implementation Event / Effect Review의 저장 무결성과 Parent Lineage를 확인합니다. Open Proof Review는 허용하지만 CSV FAIL / Hash mismatch / missing parent는 Release 전에 해결합니다.')
    _sc_v123_crosscheck = build_v123_data_crosscheck(csv_fail_count=fail_count, learning_release_gate=_sc_learning_release['release_gate'], forecast_release_gate=_sc_forecast_release['release_gate'])
    st.subheader('1C. v1.23 Closed-loop Release Data Cross-check')
    scc1, scc2, scc3 = st.columns(3)
    scc1.metric('Data Cross-check', _sc_v123_crosscheck['status'])
    scc2.metric('Blocking Gates', _sc_v123_crosscheck['blocking_count'])
    scc3.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v123_crosscheck['checks'], width='stretch', hide_index=True)
    if _sc_v123_crosscheck['status'] == 'PASS':
        st.success('v1.23 Release Data Cross-check PASS · CSV / Learning / Forecast 데이터 무결성 blocking gate가 없습니다.')
    else:
        st.error('v1.23 Release Data Cross-check BLOCKED · CSV 또는 Learning/Forecast data gate를 확인하세요.')
    _sc_latest_backup = latest_user_backup()
    _sc_save_events = get_save_events(50)
    _sc_recovery = build_recovery_readiness(csv_pass=pass_count, csv_fail=fail_count, current_csv_files=len(save_health), backup_info=_sc_latest_backup, save_events=_sc_save_events, max_backup_age_days=7, recent_event_window=20, now=datetime.now().astimezone())
    st.subheader('1D. Recovery Readiness / Backup Freshness Guard')
    rr1, rr2, rr3, rr4, rr5 = st.columns(5)
    rr1.metric('Recovery Readiness', _sc_recovery['recovery_status'])
    rr2.metric('Backup Exists', 'YES' if _sc_recovery['backup_exists'] else 'NO')
    rr3.metric('Backup Age', '-' if _sc_recovery['backup_age_days'] is None else f"{max(0.0, _sc_recovery['backup_age_days']):.1f}d")
    rr4.metric('Recent Save FAIL', _sc_recovery['recent_save_failures'])
    rr5.metric('Restore Authorization', 'NONE')
    st.dataframe(_sc_recovery['checks'], width='stretch', hide_index=True)
    if _sc_recovery['recovery_status'] == 'BLOCKED':
        st.error('Recovery Readiness BLOCKED · 현재 읽기 실패 CSV가 있어 백업보다 원본 데이터 복구가 우선입니다.')
    elif _sc_recovery['recovery_status'] == 'REVIEW':
        st.warning('Recovery Readiness REVIEW · Backup 존재/신선도/coverage 또는 최근 저장 실패를 확인하세요.')
    else:
        st.success('Recovery Readiness PASS · 현재 CSV Health와 최근 전체 백업의 기본 복구 준비 상태가 정상입니다.')
    st.caption('Backup Coverage Proxy는 `최근 백업 파일 수 ≥ 현재 CSV 파일 수`를 보는 보수적 점검입니다. 실제 Restore를 수행하거나 원본 파일을 덮어쓰지 않습니다. Restore Authorization = NONE.')
    _sc_recovery_note = st.text_input('Recovery Readiness Snapshot 메모', value='', key='save_center_recovery_snapshot_note', placeholder='예: weekly backup readiness review / no restore performed')
    if st.button('Recovery Readiness Snapshot 저장', key='save_center_recovery_snapshot_save'):
        _rr_row = build_recovery_snapshot(_sc_recovery, note=_sc_recovery_note)
        _rr_hist = load_csv('recovery_readiness_snapshots.csv')
        for _col in RECOVERY_SNAPSHOT_COLS:
            if _col not in _rr_hist.columns:
                _rr_hist[_col] = ''
        _rr_hist = pd.concat([_rr_hist[RECOVERY_SNAPSHOT_COLS], pd.DataFrame([_rr_row])], ignore_index=True)
        verified_save_feedback(_rr_hist, 'recovery_readiness_snapshots.csv', f"Recovery Readiness Snapshot 저장 · {_rr_row['recovery_status']} · Restore Authorization = NONE.", rerun=False)
    _sc_backup_discovery = discover_latest_backup_folder(Path.cwd(), _sc_latest_backup)
    _sc_manifest_verify = verify_backup_manifest(_sc_backup_discovery)
    _sc_restore_dryrun = restore_dry_run(_sc_manifest_verify)
    _sc_recovery_locks = load_csv('recovery_point_locks.csv')
    _sc_matching_lock = latest_matching_recovery_point(_sc_recovery_locks, _sc_manifest_verify.get('manifest_sha256', ''))
    st.subheader('1E. Backup Manifest Verification / Restore Dry-run / Recovery Point Lock')
    bm1, bm2, bm3, bm4, bm5 = st.columns(5)
    bm1.metric('Backup Discovery', _sc_backup_discovery['status'])
    bm2.metric('Manifest', _sc_manifest_verify['manifest_status'])
    bm3.metric('Restore Dry-run', _sc_restore_dryrun['dryrun_status'])
    bm4.metric('Hash Mismatch', _sc_manifest_verify['hash_mismatch'])
    bm5.metric('Restore Authorization', 'NONE')
    st.caption(f"Backup Folder · {_sc_backup_discovery.get('folder_name', '-')} · Discovery {_sc_backup_discovery.get('discovery_source', 'NONE')} · Manifest Entries {_sc_manifest_verify.get('manifest_entries', 0)} · Verified Files {_sc_manifest_verify.get('files_ok', 0)} · Missing {_sc_manifest_verify.get('missing_files', 0)}")
    if _sc_manifest_verify['manifest_status'] == 'PASS':
        st.success('Manifest Verification PASS · manifest.json의 SHA-256과 백업 파일이 일치합니다.')
    elif _sc_manifest_verify['manifest_status'] == 'REVIEW':
        st.warning('Manifest Verification REVIEW · 최신 백업 폴더/manifest.json 탐지가 필요합니다.')
    else:
        st.error('Manifest Verification BLOCKED · Missing file 또는 SHA-256 mismatch를 확인하세요.')
    if _sc_restore_dryrun['dryrun_status'] == 'PASS':
        st.success('Restore Dry-run PASS · CSV/JSON을 읽기 전용으로 검사했으며 실제 파일 복원/덮어쓰기는 수행하지 않았습니다.')
    else:
        st.warning('Restore Dry-run이 아직 PASS가 아닙니다. Manifest 문제 또는 parse 실패를 먼저 확인하세요.')
    dr1, dr2, dr3, dr4 = st.columns(4)
    dr1.metric('Dry-run Files', _sc_restore_dryrun['files_checked'])
    dr2.metric('CSV Readable', _sc_restore_dryrun['csv_ok'])
    dr3.metric('JSON Readable', _sc_restore_dryrun['json_ok'])
    dr4.metric('Parse FAIL', _sc_restore_dryrun['parse_fail'])
    with st.expander('Manifest Verification 상세', expanded=False):
        _mv_rows = _sc_manifest_verify.get('entry_rows')
        if isinstance(_mv_rows, pd.DataFrame) and (not _mv_rows.empty):
            st.dataframe(_mv_rows[['manifest_path', 'status']], width='stretch', hide_index=True)
        else:
            st.info('표시할 Manifest entry가 없습니다.')
    with st.expander('Restore Dry-run 상세', expanded=False):
        _dr_rows = _sc_restore_dryrun.get('rows')
        if isinstance(_dr_rows, pd.DataFrame) and (not _dr_rows.empty):
            st.dataframe(_dr_rows, width='stretch', hide_index=True)
        else:
            st.info('표시할 Dry-run 결과가 없습니다.')
    if _sc_matching_lock:
        _sc_lock_integrity = recovery_point_lock_integrity(_sc_matching_lock)
        st.info(f"현재 Manifest와 일치하는 Recovery Point Lock · {_sc_matching_lock.get('recovery_point_id', '')} · Integrity {_sc_lock_integrity['status']} · Restore Authorization NONE")
    else:
        _sc_lock_integrity = {'status': 'NONE'}
    _rpl_c1, _rpl_c2 = st.columns(2)
    _rpl_manifest_confirm = _rpl_c1.checkbox('Manifest entry 수, Missing 수, Hash Mismatch 수를 직접 확인했습니다.', value=False, key='recovery_point_manifest_confirm')
    _rpl_dryrun_confirm = _rpl_c2.checkbox('Restore Dry-run이 읽기 전용 검사이며 원본/백업 파일을 수정하지 않았음을 확인했습니다.', value=False, key='recovery_point_dryrun_confirm')
    _rpl_c3, _rpl_c4 = st.columns(2)
    _rpl_no_restore = _rpl_c3.checkbox('Recovery Point Lock은 실제 Restore Authorization을 생성하지 않음을 확인했습니다.', value=False, key='recovery_point_no_restore_confirm')
    _rpl_human = _rpl_c4.checkbox('현재 Recovery Point를 최종 Human Review했습니다.', value=False, key='recovery_point_human_confirm')
    _rpl_note = st.text_input('Recovery Point Lock 메모', value='', key='recovery_point_lock_note', placeholder='예: verified full backup / dry-run only / no restore authorization')
    _rpl_validation = validate_recovery_point_lock(_sc_manifest_verify, _sc_restore_dryrun, manifest_confirmed=_rpl_manifest_confirm, dryrun_no_write_confirmed=_rpl_dryrun_confirm, no_restore_authorization_confirmed=_rpl_no_restore, human_review_confirmed=_rpl_human)
    lg1, lg2, lg3 = st.columns(3)
    lg1.metric('Recovery Point Gate', _rpl_validation['lock_gate'])
    lg2.metric('Lock Status', _rpl_validation['lock_status'])
    lg3.metric('Restore Authorization', 'NONE')
    if _rpl_validation['issues']:
        st.caption('Lock 저장 전 확인 · ' + ' | '.join(_rpl_validation['issues']))
    if st.button('Recovery Point Lock 저장', disabled=_rpl_validation['lock_gate'] != 'PASS', key='recovery_point_lock_save'):
        _rpl_row = build_recovery_point_lock_record(_sc_backup_discovery, _sc_manifest_verify, _sc_restore_dryrun, _rpl_validation, backup_modified=_sc_latest_backup.get('modified', ''), manifest_confirmed=_rpl_manifest_confirm, dryrun_no_write_confirmed=_rpl_dryrun_confirm, no_restore_authorization_confirmed=_rpl_no_restore, human_review_confirmed=_rpl_human, note=_rpl_note)
        _rpl_hist = load_csv('recovery_point_locks.csv')
        for _col in RECOVERY_POINT_LOCK_COLS:
            if _col not in _rpl_hist.columns:
                _rpl_hist[_col] = ''
        _rpl_hist = pd.concat([_rpl_hist[RECOVERY_POINT_LOCK_COLS], pd.DataFrame([_rpl_row])], ignore_index=True)
        verified_save_feedback(_rpl_hist, 'recovery_point_locks.csv', f"Recovery Point Lock 저장 · {_rpl_row['lock_status']} · Manifest {_rpl_row['manifest_sha256'][:8]} · Restore Authorization = NONE.", rerun=False)
    st.caption('Recovery Point Lock은 검증된 백업의 Manifest Hash와 Dry-run 결과를 append-only로 고정합니다. 실제 Restore 실행, 파일 복사, 원본 덮어쓰기는 하지 않습니다.')
    _sc_drift = build_recovery_point_drift(_sc_manifest_verify, _sc_restore_dryrun, _sc_recovery_locks)
    _sc_rotation = build_backup_rotation_plan(_sc_recovery_locks, current_manifest_sha256=_sc_manifest_verify.get('manifest_sha256', ''), keep_latest=3)
    _sc_simulation = build_restore_simulation_plan(_sc_manifest_verify, _sc_restore_dryrun, _sc_drift)
    st.subheader('1F. Recovery Point Drift / Backup Rotation / Restore Simulation Plan')
    rs1, rs2, rs3, rs4, rs5 = st.columns(5)
    rs1.metric('Recovery Point Drift', _sc_drift['drift_status'])
    rs2.metric('Locked Points', _sc_rotation['locked_points'])
    rs3.metric('Rotation', _sc_rotation['rotation_status'])
    rs4.metric('Restore Simulation', _sc_simulation['simulation_status'])
    rs5.metric('Restore Authorization', 'NONE')
    st.caption(f"Current Manifest · {_sc_drift.get('current_manifest_sha256', '')[:12]} · Matching Lock · {_sc_drift.get('matching_recovery_point_id', '-')} · Lock Integrity {_sc_drift.get('matching_lock_integrity', 'NONE')} · Keep Latest {_sc_rotation.get('keep_latest', 3)} · Archive Candidates {_sc_rotation.get('archive_candidates', 0)}")
    if _sc_drift['drift_status'] == 'CURRENT':
        st.success('Recovery Point CURRENT · 최신 검증 Backup Manifest가 현재 Recovery Point Lock과 일치합니다.')
    elif _sc_drift['drift_status'] == 'DRIFTED':
        st.warning('Recovery Point DRIFTED · 새 전체 백업이 생성됐지만 현재 Manifest에 대한 Recovery Point Lock이 아직 없습니다.')
    elif _sc_drift['drift_status'] == 'UNLOCKED':
        st.warning('Recovery Point UNLOCKED · 검증된 Backup은 있으나 Recovery Point Lock 기록이 없습니다.')
    else:
        st.error('Recovery Point Integrity Review가 필요합니다. Manifest / Dry-run / Lock Hash를 먼저 확인하세요.')
    if _sc_rotation['rotation_status'] == 'REVIEW':
        st.warning('Backup Rotation REVIEW · 오래된 Recovery Point가 archive 후보입니다. 자동 삭제/파일 삭제는 수행하지 않습니다.')
    elif _sc_rotation['rotation_status'] == 'INTEGRITY_REVIEW':
        st.error('Backup Rotation Integrity Review · Lock Hash 문제를 먼저 해결하세요.')
    elif _sc_rotation['rotation_status'] == 'PASS':
        st.success('Backup Rotation PASS · 현재 보존 기준에서 archive 후보가 없습니다.')
    else:
        st.info('Backup Rotation · 아직 Recovery Point Lock이 없습니다.')
    if _sc_simulation['simulation_status'] == 'READY':
        st.success('Restore Simulation READY · 복구 절차 계획을 검토할 수 있습니다. 실제 Restore는 여전히 승인되지 않았습니다.')
    else:
        st.warning('Restore Simulation BLOCKED · CURRENT Recovery Point, Manifest PASS, Dry-run PASS가 필요합니다.')
    with st.expander('Backup Rotation Plan 상세', expanded=False):
        _rotation_view = _sc_rotation.get('rotation_view')
        if isinstance(_rotation_view, pd.DataFrame) and (not _rotation_view.empty):
            st.dataframe(_rotation_view, width='stretch', hide_index=True)
        else:
            st.info('표시할 Recovery Point Rotation 항목이 없습니다.')
    with st.expander('Restore Simulation Plan 상세', expanded=False):
        _sim_steps = _sc_simulation.get('steps')
        if isinstance(_sim_steps, pd.DataFrame) and (not _sim_steps.empty):
            st.dataframe(_sim_steps, width='stretch', hide_index=True)
        else:
            st.info('표시할 Restore Simulation step이 없습니다.')
    _rs_note = st.text_input('Recovery Resilience Snapshot 메모', value='', key='recovery_resilience_snapshot_note', placeholder='예: current lock verified / rotation reviewed / simulation plan only')
    if st.button('Recovery Resilience Snapshot 저장', key='recovery_resilience_snapshot_save'):
        _rs_row = build_recovery_resilience_snapshot(_sc_drift, _sc_rotation, _sc_simulation, note=_rs_note)
        _rs_hist = load_csv('recovery_resilience_snapshots.csv')
        for _col in RECOVERY_RESILIENCE_SNAPSHOT_COLS:
            if _col not in _rs_hist.columns:
                _rs_hist[_col] = ''
        _rs_hist = pd.concat([_rs_hist[RECOVERY_RESILIENCE_SNAPSHOT_COLS], pd.DataFrame([_rs_row])], ignore_index=True)
        verified_save_feedback(_rs_hist, 'recovery_resilience_snapshots.csv', f"Recovery Resilience Snapshot 저장 · Drift {_rs_row['drift_status']} · Simulation {_rs_row['restore_simulation_status']} · Restore Authorization = NONE.", rerun=False)
    st.caption('Rotation은 metadata review plan일 뿐 backup folder/file을 삭제하지 않습니다. Restore Simulation은 절차 계획만 생성하며 실제 파일 복원/복사/덮어쓰기를 수행하지 않습니다.')
    _sc_recovery_release = build_recovery_release_gate(_sc_recovery, _sc_manifest_verify, _sc_restore_dryrun, _sc_drift, _sc_rotation, _sc_simulation)
    _sc_runbook_locks = load_csv('disaster_recovery_runbook_locks.csv')
    _sc_current_runbook = latest_matching_runbook_lock(_sc_runbook_locks, _sc_manifest_verify.get('manifest_sha256', ''))
    st.subheader('1G. Recovery Release Gate / Audit Closure / Disaster Recovery Runbook Lock')
    rg1, rg2, rg3, rg4, rg5 = st.columns(5)
    rg1.metric('Recovery Release Gate', _sc_recovery_release['release_gate'])
    rg2.metric('Technical PASS', _sc_recovery_release['technical_pass'])
    rg3.metric('Technical FAIL', _sc_recovery_release['technical_fail'])
    rg4.metric('Operating', _sc_recovery_release['operating_status'])
    rg5.metric('Restore Authorization', 'NONE')
    st.dataframe(_sc_recovery_release['checks'], width='stretch', hide_index=True)
    if _sc_recovery_release['release_gate'] == 'PASS':
        st.success('Recovery Release Gate PASS · Recovery Readiness / Manifest / Dry-run / Current Lock / Simulation 기술 무결성이 정상입니다.')
    else:
        st.error('Recovery Release Gate BLOCKED · Technical FAIL 항목을 먼저 해결하세요.')
    st.caption('Backup Rotation archive 후보는 Operating Review이며 그 자체로 Technical Release를 차단하지 않습니다. 실제 Restore와 자동 삭제는 계속 금지됩니다.')
    if _sc_current_runbook:
        _sc_runbook_integrity = dr_runbook_lock_integrity(_sc_current_runbook)
        st.info(f"현재 Manifest와 일치하는 DR Runbook Lock · {_sc_current_runbook.get('runbook_lock_id', '')} · Audit {_sc_current_runbook.get('audit_closure_status', '')} · Integrity {_sc_runbook_integrity['status']} · Restore Authorization NONE")
    else:
        _sc_runbook_integrity = {'status': 'NONE'}
    rb1, rb2 = st.columns(2)
    _rb_release_confirm = rb1.checkbox('Recovery Release Gate의 8개 Technical Check와 현재 Recovery Point를 직접 확인했습니다.', value=False, key='dr_runbook_release_confirm')
    _rb_emergency_confirm = rb2.checkbox('향후 실제 복구 전 현재 데이터 Emergency Copy를 먼저 만든다는 Runbook 원칙을 확인했습니다.', value=False, key='dr_runbook_emergency_copy_confirm')
    rb3, rb4 = st.columns(2)
    _rb_staging_confirm = rb3.checkbox('향후 복구는 격리된 임시 Staging에서 검증 후 Overwrite Scope를 비교한다는 절차를 확인했습니다.', value=False, key='dr_runbook_staging_confirm')
    _rb_no_auto_confirm = rb4.checkbox('이 Runbook Lock은 자동 Backup 삭제나 실제 Restore Authorization을 생성하지 않음을 확인했습니다.', value=False, key='dr_runbook_no_auto_confirm')
    _rb_human_confirm = st.checkbox('현재 Disaster Recovery Runbook / Recovery Audit Closure를 최종 Human Review했습니다.', value=False, key='dr_runbook_human_confirm')
    _rb_note = st.text_input('DR Runbook Lock 메모', value='', key='dr_runbook_lock_note', placeholder='예: recovery gate reviewed / simulation plan locked / no restore authorization')
    _rb_validation = validate_dr_runbook_lock(_sc_recovery_release, _sc_drift, _sc_simulation, _sc_current_runbook, release_evidence_confirmed=_rb_release_confirm, emergency_copy_plan_confirmed=_rb_emergency_confirm, isolated_staging_confirmed=_rb_staging_confirm, no_auto_delete_restore_confirmed=_rb_no_auto_confirm, human_review_confirmed=_rb_human_confirm)
    rbg1, rbg2, rbg3 = st.columns(3)
    rbg1.metric('Runbook Gate', _rb_validation['runbook_gate'])
    rbg2.metric('Audit Closure', _rb_validation['audit_closure_status'])
    rbg3.metric('Restore Authorization', 'NONE')
    if _rb_validation['issues']:
        st.caption('Runbook Lock 저장 전 확인 · ' + ' | '.join(_rb_validation['issues']))
    if st.button('Disaster Recovery Runbook Lock 저장', disabled=_rb_validation['runbook_gate'] != 'PASS', key='dr_runbook_lock_save'):
        _rb_row = build_dr_runbook_lock_record(_sc_recovery_release, _sc_drift, _sc_rotation, _sc_simulation, _rb_validation, current_manifest_sha256=_sc_manifest_verify.get('manifest_sha256', ''), release_evidence_confirmed=_rb_release_confirm, emergency_copy_plan_confirmed=_rb_emergency_confirm, isolated_staging_confirmed=_rb_staging_confirm, no_auto_delete_restore_confirmed=_rb_no_auto_confirm, human_review_confirmed=_rb_human_confirm, note=_rb_note)
        _rb_hist = load_csv('disaster_recovery_runbook_locks.csv')
        for _col in DR_RUNBOOK_LOCK_COLS:
            if _col not in _rb_hist.columns:
                _rb_hist[_col] = ''
        _rb_hist = pd.concat([_rb_hist[DR_RUNBOOK_LOCK_COLS], pd.DataFrame([_rb_row])], ignore_index=True)
        verified_save_feedback(_rb_hist, 'disaster_recovery_runbook_locks.csv', f"DR Runbook Lock 저장 · {_rb_row['audit_closure_status']} · {_rb_row['runbook_version']} · Restore Authorization = NONE.", rerun=False)
    st.caption('Disaster Recovery Runbook Lock은 현재 Recovery Point, 8-step Simulation Plan, Release Gate를 append-only로 고정합니다. 실제 Restore 실행/파일 복사/원본 덮어쓰기/자동 삭제는 수행하지 않습니다.')
    _sc_recovery_integration_status = 'REVIEW'
    if _sc_current_runbook:
        if _sc_runbook_integrity['status'] != 'OK':
            _sc_recovery_integration_status = 'BLOCKED'
        elif str(_sc_current_runbook.get('audit_closure_status', '') or '').upper() == 'RECOVERY_AUDIT_CLOSED':
            _sc_recovery_integration_status = 'PASS'
    _sc_v124_crosscheck = build_v124_data_crosscheck(csv_fail_count=fail_count, recovery_release_gate=_sc_recovery_release['release_gate'], recovery_integration_status=_sc_recovery_integration_status)
    st.subheader('1H. v1.24 Recovery Release Data Cross-check')
    rdc1, rdc2, rdc3, rdc4 = st.columns(4)
    rdc1.metric('Recovery Data Gate', _sc_v124_crosscheck['status'])
    rdc2.metric('Blocking Gates', _sc_v124_crosscheck['blocking_count'])
    rdc3.metric('Audit Closure', _sc_recovery_integration_status)
    rdc4.metric('Restore Authorization', 'NONE')
    st.dataframe(_sc_v124_crosscheck['checks'], width='stretch', hide_index=True)
    if _sc_v124_crosscheck['status'] == 'PASS':
        st.success('v1.24 Recovery Release Data Cross-check PASS · CSV / Recovery Release / Audit Closure blocking gate가 없습니다.')
    else:
        st.warning('v1.24 Recovery Release Data Cross-check 아직 BLOCKED · 현재 Runbook Audit Closure 또는 Recovery gate를 확인하세요.')
    _sc_schema_scan = inspect_csv_schemas(ROOT / 'data')
    _sc_schema_summary = schema_scan_summary(_sc_schema_scan)
    _sc_schema_baselines = load_csv('schema_baseline_locks.csv')
    _sc_schema_baseline = latest_schema_baseline(_sc_schema_baselines)
    _sc_schema_compare = compare_schema_to_baseline(_sc_schema_scan, _sc_schema_baseline)
    _sc_schema_dryrun = build_schema_migration_dry_run(_sc_schema_compare)
    st.subheader('1I. Data Schema Evolution Guard / Migration Dry-run / Baseline Lock')
    sg1, sg2, sg3, sg4, sg5 = st.columns(5)
    sg1.metric('Schema Status', _sc_schema_compare['schema_status'])
    sg2.metric('CSV Schemas', _sc_schema_summary['file_count'])
    sg3.metric('Changed Files', _sc_schema_compare['changed_files'])
    sg4.metric('Blocking Changes', _sc_schema_compare['blocking_changes'])
    sg5.metric('Migration Authorization', 'NONE')
    st.caption(f"Parse FAIL {_sc_schema_summary['parse_fail']} · Duplicate-column files {_sc_schema_summary['duplicate_schema_files']} · Added files {_sc_schema_compare['added_files']} · Missing files {_sc_schema_compare['missing_files']} · Review changes {_sc_schema_compare['review_changes']}")
    if _sc_schema_compare['schema_status'] == 'NO_BASELINE':
        st.info('아직 Schema Baseline Lock이 없습니다. 현재 CSV header가 정상인지 확인한 뒤 첫 Baseline을 Human Review로 잠급니다.')
    elif _sc_schema_compare['schema_status'] == 'CURRENT':
        st.success('Schema CURRENT · 현재 CSV file/column 구조가 잠긴 Baseline과 일치합니다.')
    elif _sc_schema_compare['schema_status'] == 'REVIEW':
        st.warning('Schema REVIEW · Additive file/column 또는 column order 변화가 있습니다. 자동 Migration은 수행하지 않습니다.')
    else:
        st.error('Schema BLOCKED · Missing file/column, breaking change 또는 Baseline/CSV integrity 문제를 먼저 해결하세요.')
    with st.expander('CSV Schema Scan 상세', expanded=False):
        if _sc_schema_scan.empty:
            st.info('표시할 CSV schema가 없습니다.')
        else:
            st.dataframe(_sc_schema_scan[['file', 'parse_status', 'column_count', 'duplicate_columns', 'schema_hash']], width='stretch', hide_index=True)
    with st.expander('Schema Diff 상세', expanded=False):
        _schema_diff = _sc_schema_compare.get('diff')
        if isinstance(_schema_diff, pd.DataFrame) and (not _schema_diff.empty):
            st.dataframe(_schema_diff, width='stretch', hide_index=True)
        else:
            st.info('현재 표시할 Schema Diff가 없습니다.')
    with st.expander('Migration Dry-run Plan 상세', expanded=False):
        if _sc_schema_dryrun.empty:
            st.info('Migration Dry-run 대상이 없습니다.')
        else:
            st.dataframe(_sc_schema_dryrun, width='stretch', hide_index=True)
    if _sc_schema_baseline:
        _sc_baseline_integrity = schema_baseline_integrity(_sc_schema_baseline)
        st.info(f"Latest Schema Baseline · {_sc_schema_baseline.get('schema_baseline_id', '')} · Files {_sc_schema_baseline.get('file_count', '')} · Integrity {_sc_baseline_integrity['status']} · Migration Authorization NONE")
    else:
        _sc_baseline_integrity = {'status': 'NONE'}
    sb1, sb2 = st.columns(2)
    _sb_schema_confirm = sb1.checkbox('현재 CSV file 목록과 각 header/column 구조를 직접 확인했습니다.', value=False, key='schema_baseline_schema_confirm')
    _sb_no_auto_confirm = sb2.checkbox('Schema Baseline Lock은 CSV를 자동 Migration하거나 column을 변경하지 않음을 확인했습니다.', value=False, key='schema_baseline_no_auto_confirm')
    sb3, sb4 = st.columns(2)
    _sb_no_destructive = sb3.checkbox('Missing column/file 또는 breaking schema는 자동 보정하지 않고 별도 Migration Review가 필요함을 확인했습니다.', value=False, key='schema_baseline_no_destructive_confirm')
    _sb_human = sb4.checkbox('현재 Data Schema Baseline을 최종 Human Review했습니다.', value=False, key='schema_baseline_human_confirm')
    _sb_note = st.text_input('Schema Baseline Lock 메모', value='', key='schema_baseline_note', placeholder='예: v1.25 initial schema baseline / no auto migration')
    _sb_validation = validate_schema_baseline_lock(_sc_schema_scan, _sc_schema_compare, _sc_schema_baseline, schema_review_confirmed=_sb_schema_confirm, no_auto_migration_confirmed=_sb_no_auto_confirm, no_destructive_change_confirmed=_sb_no_destructive, human_review_confirmed=_sb_human)
    sbg1, sbg2, sbg3 = st.columns(3)
    sbg1.metric('Baseline Gate', _sb_validation['baseline_gate'])
    sbg2.metric('Baseline Status', _sb_validation['baseline_status'])
    sbg3.metric('Migration Authorization', 'NONE')
    if _sb_validation['issues']:
        st.caption('Baseline 저장 전 확인 · ' + ' | '.join(_sb_validation['issues']))
    if st.button('Data Schema Baseline Lock 저장', disabled=_sb_validation['baseline_gate'] != 'PASS', key='schema_baseline_lock_save'):
        _sb_row = build_schema_baseline_lock_record(_sc_schema_scan, _sb_validation, schema_review_confirmed=_sb_schema_confirm, no_auto_migration_confirmed=_sb_no_auto_confirm, no_destructive_change_confirmed=_sb_no_destructive, human_review_confirmed=_sb_human, note=_sb_note)
        _sb_hist = load_csv('schema_baseline_locks.csv')
        for _col in SCHEMA_BASELINE_LOCK_COLS:
            if _col not in _sb_hist.columns:
                _sb_hist[_col] = ''
        _sb_hist = pd.concat([_sb_hist[SCHEMA_BASELINE_LOCK_COLS], pd.DataFrame([_sb_row])], ignore_index=True)
        verified_save_feedback(_sb_hist, 'schema_baseline_locks.csv', f"Data Schema Baseline Lock 저장 · {_sb_row['baseline_status']} · Files {_sb_row['file_count']} · Migration Authorization = NONE.", rerun=False)
    st.caption('Schema Evolution Guard는 header 구조를 감시하고 Migration Dry-run 계획만 생성합니다. CSV column 추가/삭제/rename/파일 삭제를 자동 수행하지 않습니다.')
    _sc_schema_compat = build_schema_compatibility_matrix(_sc_schema_compare)
    _sc_migration_summary = migration_proposal_summary(_sc_schema_compare, _sc_schema_compat)
    _sc_schema_contracts = load_csv('schema_contract_locks.csv')
    _sc_schema_contract = latest_schema_contract(_sc_schema_contracts)
    _sc_contract_assessment = assess_schema_contract(_sc_schema_contract, _sc_schema_baseline, _sc_schema_compare)
    st.subheader('1J. Schema Migration Proposal / Compatibility Matrix / Reader-Writer Contract Lock')
    cm1, cm2, cm3, cm4, cm5 = st.columns(5)
    cm1.metric('Compatibility', _sc_schema_compat['compatibility_status'])
    cm2.metric('Migration Proposal', _sc_migration_summary['proposal_status'])
    cm3.metric('Contract', _sc_contract_assessment['contract_status'])
    cm4.metric('Changed Files', _sc_schema_compare['changed_files'])
    cm5.metric('Migration Authorization', 'NONE')
    st.caption(f"Compatible files {_sc_schema_compat['pass_files']} · Review files {_sc_schema_compat['review_files']} · Blocked files {_sc_schema_compat['blocked_files']} · Contract Integrity {_sc_contract_assessment['contract_integrity']}")
    with st.expander('Reader / Writer Compatibility Matrix', expanded=False):
        _compat_matrix = _sc_schema_compat.get('matrix')
        if isinstance(_compat_matrix, pd.DataFrame) and (not _compat_matrix.empty):
            st.dataframe(_compat_matrix, width='stretch', hide_index=True)
        else:
            st.info('표시할 Compatibility Matrix가 없습니다.')
    if _sc_schema_compare['changed_files'] == 0:
        st.success('현재 Schema 변경이 없어 Migration Proposal이 필요하지 않습니다.')
    else:
        _proposal_diff = _sc_schema_compare.get('diff')
        if isinstance(_proposal_diff, pd.DataFrame) and (not _proposal_diff.empty):
            _proposal_candidates = _proposal_diff.loc[_proposal_diff['migration_type'].ne('CURRENT')].copy()
            if not _proposal_candidates.empty:
                _proposal_indices = list(_proposal_candidates.index)

                def _proposal_label(_idx):
                    _r = _proposal_candidates.loc[_idx]
                    return f"{_r.get('file', '')} | {_r.get('migration_type', '')} | {_r.get('status', '')}"
                _proposal_idx = st.selectbox('Migration Proposal 대상 Schema Change', options=_proposal_indices, format_func=_proposal_label, key='schema_migration_proposal_target')
                _proposal_source = _proposal_candidates.loc[_proposal_idx].to_dict()
                _compat_rows = _sc_schema_compat['matrix']
                _compat_hit = _compat_rows.loc[_compat_rows['file'].astype(str).eq(str(_proposal_source.get('file', '')))]
                _proposal_compat = _compat_hit.iloc[0].to_dict() if not _compat_hit.empty else {}
                pc1, pc2, pc3 = st.columns(3)
                pc1.metric('Migration Type', _proposal_source.get('migration_type', ''))
                pc2.metric('Risk', _proposal_compat.get('risk_level', ''))
                pc3.metric('Authorization', 'NONE')
                _proposal_reason = st.text_area('Migration Reason', key='schema_migration_reason', placeholder='왜 schema 변경이 필요한지, 어떤 원본 기능/데이터 요구가 있는지 기록')
                _proposal_transform = st.text_area('Proposed Transform', key='schema_migration_transform', placeholder='어떤 file/column 변환을 검토할지 기록. 이 화면에서는 적용하지 않음.')
                _proposal_rollback = st.text_area('Rollback Plan', key='schema_migration_rollback', placeholder='문제가 생기면 어떤 Baseline/Backup으로 되돌릴지 기록')
                _proposal_proof = st.text_area('Proof / Compatibility Test Plan', key='schema_migration_proof', placeholder='Reader/Writer 호환성과 저장/재읽기 무결성을 어떻게 검증할지 기록')
                mp1, mp2 = st.columns(2)
                _mp_source_confirm = mp1.checkbox('선택한 Schema Diff와 Compatibility Matrix를 직접 확인했습니다.', key='schema_migration_source_confirm')
                _mp_no_auto = mp2.checkbox('Migration Proposal 저장은 실제 CSV/column 변경을 자동 적용하지 않음을 확인했습니다.', key='schema_migration_no_auto_confirm')
                mp3, mp4 = st.columns(2)
                _mp_no_destructive = mp3.checkbox('명시적 검토 없이 file/column 삭제·rename·destructive write를 수행하지 않음을 확인했습니다.', key='schema_migration_no_destructive_confirm')
                _mp_human = mp4.checkbox('현재 Migration Proposal을 최종 Human Review했습니다.', key='schema_migration_human_confirm')
                _mp_note = st.text_input('Migration Proposal 메모', key='schema_migration_proposal_note')
                _mp_validation = validate_schema_migration_proposal(_proposal_source, _proposal_compat, migration_reason=_proposal_reason, proposed_transform=_proposal_transform, rollback_plan=_proposal_rollback, proof_plan=_proposal_proof, source_diff_confirmed=_mp_source_confirm, no_auto_apply_confirmed=_mp_no_auto, no_destructive_write_confirmed=_mp_no_destructive, human_review_confirmed=_mp_human)
                mpg1, mpg2, mpg3 = st.columns(3)
                mpg1.metric('Proposal Gate', _mp_validation['proposal_gate'])
                mpg2.metric('Proposal Status', _mp_validation['proposal_status'])
                mpg3.metric('Migration Authorization', 'NONE')
                if st.button('Schema Migration Proposal 저장', disabled=_mp_validation['proposal_gate'] != 'PASS', key='schema_migration_proposal_save'):
                    _current_snapshot_hash = build_schema_snapshot(_sc_schema_scan)['snapshot_hash']
                    _mp_row = build_schema_migration_proposal_record(_proposal_source, _proposal_compat, _mp_validation, baseline_schema_hash=_sc_schema_baseline.get('schema_snapshot_hash', ''), current_schema_hash=_current_snapshot_hash, migration_reason=_proposal_reason, proposed_transform=_proposal_transform, rollback_plan=_proposal_rollback, proof_plan=_proposal_proof, source_diff_confirmed=_mp_source_confirm, no_auto_apply_confirmed=_mp_no_auto, no_destructive_write_confirmed=_mp_no_destructive, human_review_confirmed=_mp_human, note=_mp_note)
                    _mp_hist = load_csv('schema_migration_proposals.csv')
                    for _col in SCHEMA_MIGRATION_PROPOSAL_COLS:
                        if _col not in _mp_hist.columns:
                            _mp_hist[_col] = ''
                    _mp_hist = pd.concat([_mp_hist[SCHEMA_MIGRATION_PROPOSAL_COLS], pd.DataFrame([_mp_row])], ignore_index=True)
                    verified_save_feedback(_mp_hist, 'schema_migration_proposals.csv', f"Schema Migration Proposal 저장 · {_mp_row['proposal_status']} · {_mp_row['migration_type']} · Migration Authorization = NONE.", rerun=False)
    if _sc_schema_contract:
        _contract_integrity = schema_contract_integrity(_sc_schema_contract)
        st.info(f"Latest Reader-Writer Contract · {_sc_schema_contract.get('schema_contract_id', '')} · Status {_sc_contract_assessment['contract_status']} · Integrity {_contract_integrity['status']} · Migration Authorization NONE")
    else:
        _contract_integrity = {'status': 'NONE'}
    cc1, cc2 = st.columns(2)
    _cc_baseline_confirm = cc1.checkbox('현재 Schema Baseline Integrity와 Compatibility Matrix를 직접 확인했습니다.', key='schema_contract_baseline_confirm')
    _cc_additive_confirm = cc2.checkbox('추가 file/column도 자동 호환으로 가정하지 않고 Reader/Writer 영향을 별도 검토한다는 Contract 원칙을 확인했습니다.', key='schema_contract_additive_confirm')
    cc3, cc4 = st.columns(2)
    _cc_writer_confirm = cc3.checkbox('Writer는 잠긴 필수 file/column을 명시적 Migration 없이 삭제·rename하지 않는다는 보존 원칙을 확인했습니다.', key='schema_contract_writer_confirm')
    _cc_no_auto = cc4.checkbox('이 Contract Lock은 실제 Migration을 자동 실행하지 않음을 확인했습니다.', key='schema_contract_no_auto_confirm')
    _cc_human = st.checkbox('현재 Reader-Writer Schema Contract를 최종 Human Review했습니다.', key='schema_contract_human_confirm')
    _cc_note = st.text_input('Reader-Writer Contract Lock 메모', key='schema_contract_note', placeholder='예: v1.25 schema contract v1 / current baseline / no auto migration')
    _cc_validation = validate_schema_contract_lock(_sc_schema_baseline, _sc_schema_compare, _sc_schema_compat, _sc_schema_contract, baseline_review_confirmed=_cc_baseline_confirm, additive_change_review_confirmed=_cc_additive_confirm, writer_preservation_confirmed=_cc_writer_confirm, no_auto_migration_confirmed=_cc_no_auto, human_review_confirmed=_cc_human)
    ccg1, ccg2, ccg3 = st.columns(3)
    ccg1.metric('Contract Gate', _cc_validation['contract_gate'])
    ccg2.metric('Contract Status', _cc_validation['contract_status'])
    ccg3.metric('Migration Authorization', 'NONE')
    if _cc_validation['issues']:
        st.caption('Contract 저장 전 확인 · ' + ' | '.join(_cc_validation['issues']))
    if st.button('Reader-Writer Schema Contract Lock 저장', disabled=_cc_validation['contract_gate'] != 'PASS', key='schema_contract_lock_save'):
        _cc_row = build_schema_contract_lock_record(_sc_schema_scan, _sc_schema_baseline, _sc_schema_compat, _cc_validation, baseline_review_confirmed=_cc_baseline_confirm, additive_change_review_confirmed=_cc_additive_confirm, writer_preservation_confirmed=_cc_writer_confirm, no_auto_migration_confirmed=_cc_no_auto, human_review_confirmed=_cc_human, note=_cc_note)
        _cc_hist = load_csv('schema_contract_locks.csv')
        for _col in SCHEMA_CONTRACT_LOCK_COLS:
            if _col not in _cc_hist.columns:
                _cc_hist[_col] = ''
        _cc_hist = pd.concat([_cc_hist[SCHEMA_CONTRACT_LOCK_COLS], pd.DataFrame([_cc_row])], ignore_index=True)
        verified_save_feedback(_cc_hist, 'schema_contract_locks.csv', f"Reader-Writer Schema Contract Lock 저장 · {_cc_row['contract_status']} · {_cc_row['contract_version']} · Migration Authorization = NONE.", rerun=False)
    st.caption('Compatibility Matrix는 schema 차이의 위험을 분류하는 Governance 도구입니다. 실제 모든 Reader/Writer code path의 호환성을 자동 증명하지 않으며, Migration은 별도 Human Review가 필요합니다.')
    _sc_schema_contract_drift = build_schema_contract_drift(_sc_schema_contract, _sc_schema_baseline, _sc_schema_compare, _sc_schema_compat)
    _sc_schema_proposals = load_csv('schema_migration_proposals.csv')
    _sc_schema_proofs = load_csv('schema_migration_proof_reviews.csv')
    _sc_compat_closure = build_compatibility_closure(_sc_schema_compare, _sc_schema_contract_drift, _sc_schema_proposals, _sc_schema_proofs, _sc_schema_scan)
    st.subheader('1K. Schema Contract Drift / Migration Proof / Compatibility Closure')
    sp1, sp2, sp3, sp4, sp5 = st.columns(5)
    sp1.metric('Contract Drift', _sc_schema_contract_drift['contract_drift_status'])
    sp2.metric('Compatibility Closure', _sc_compat_closure['closure_status'])
    sp3.metric('Changed Files', _sc_compat_closure['changed_files'])
    sp4.metric('Proof Accepted', _sc_compat_closure['proof_accepted'])
    sp5.metric('Migration Authorization', 'NONE')
    st.caption(f"Proposal Missing {_sc_compat_closure['proposal_missing']} · Proof Pending {_sc_compat_closure['proof_pending']} · Integrity Issues {_sc_compat_closure['integrity_issues']} · Current Schema {_sc_compat_closure['current_schema_hash'][:12]}")
    if _sc_schema_contract_drift['contract_drift_status'] == 'CURRENT':
        st.success('Schema Contract CURRENT · 현재 Schema / Baseline / Reader-Writer Contract가 일치합니다.')
    elif _sc_schema_contract_drift['contract_drift_status'] == 'DRIFTED':
        st.warning('Schema Contract DRIFTED · Migration Proposal / Proof / Baseline Refresh 검토가 필요합니다.')
    else:
        st.error('Schema Contract Drift가 BLOCKED/NO_CONTRACT 상태입니다. Baseline/Contract integrity부터 확인하세요.')
    if _sc_compat_closure['closure_status'] == 'NO_CHANGE':
        st.success('Compatibility Closure = NO_CHANGE · 현재 Migration Proposal / Proof Review가 필요하지 않습니다.')
    elif _sc_compat_closure['closure_status'] == 'READY_FOR_BASELINE_REFRESH':
        st.info('Changed files의 Migration Proof가 모두 ACCEPTED되었습니다. 새 Baseline/Contract refresh는 아직 자동 수행하지 않습니다.')
    with st.expander('Compatibility Closure 상세', expanded=False):
        _closure_details = _sc_compat_closure.get('details')
        if isinstance(_closure_details, pd.DataFrame) and (not _closure_details.empty):
            st.dataframe(_closure_details, width='stretch', hide_index=True)
        else:
            st.info('현재 Compatibility Closure 대상 Schema Change가 없습니다.')
    st.caption('Migration Proof는 실제 Schema change가 있을 때만 사용합니다. CSV/column 자동 변경, Baseline 자동 refresh, Migration 자동 승인은 하지 않습니다.')
    _sc_refresh_approvals = load_csv('schema_refresh_approvals.csv')
    _sc_target_schema_hash = _sc_compat_closure['current_schema_hash']
    _sc_refresh_approval = latest_schema_refresh_approval(_sc_refresh_approvals, _sc_target_schema_hash)
    _sc_refresh_closure = build_schema_refresh_closure(_sc_schema_scan, _sc_compat_closure, _sc_refresh_approvals, _sc_schema_baselines, _sc_schema_contracts)
    st.subheader('1L. Controlled Baseline Refresh / Contract Re-lock / Migration Closure')
    sr1, sr2, sr3, sr4, sr5 = st.columns(5)
    sr1.metric('Refresh Status', _sc_refresh_closure['refresh_status'])
    sr2.metric('Approval', _sc_refresh_approval.get('approval_status', 'NONE') if _sc_refresh_approval else 'NONE')
    sr3.metric('New Baseline', _sc_refresh_closure['refreshed_baseline_id'] or 'NONE')
    sr4.metric('Contract Re-lock', _sc_refresh_closure['relocked_contract_id'] or 'NONE')
    sr5.metric('Migration Authorization', 'NONE')
    st.caption(f"Target Schema {_sc_refresh_closure['target_schema_snapshot_hash'][:12]} · Approval Integrity {_sc_refresh_closure['approval_integrity']} · Baseline Integrity {_sc_refresh_closure['refreshed_baseline_integrity']} · Contract Integrity {_sc_refresh_closure['relocked_contract_integrity']}")
    if _sc_refresh_closure['refresh_status'] == 'NOT_REQUIRED':
        st.success('현재 Schema Migration이 없어 Baseline Refresh / Contract Re-lock이 필요하지 않습니다.')
    elif _sc_refresh_closure['refresh_status'] == 'MIGRATION_CLOSED':
        st.success('Schema Migration Closure 완료 · Accepted Proof → Refresh Approval → New Baseline → Contract Re-lock lineage가 닫혔습니다.')
    elif _sc_refresh_closure['refresh_status'] == 'BASELINE_REFRESH_PENDING':
        st.warning('Refresh Approval 완료 · Save Center 1I에서 현재 target schema를 새 Baseline으로 Human Review 후 Lock하세요.')
    elif _sc_refresh_closure['refresh_status'] == 'CONTRACT_RELOCK_PENDING':
        st.warning('New Baseline 완료 · Save Center 1J에서 새 Baseline 기준 Reader-Writer Contract Re-lock이 필요합니다.')
    elif _sc_refresh_closure['refresh_status'] == 'INTEGRITY_REVIEW':
        st.error('Schema Refresh lineage integrity 문제가 있습니다. Approval/Baseline/Contract Hash를 먼저 확인하세요.')
    else:
        st.info('Schema Refresh는 Migration Proof가 READY_FOR_BASELINE_REFRESH가 된 뒤 별도 Human Review로 진행합니다.')
    if _sc_compat_closure['closure_status'] == 'READY_FOR_BASELINE_REFRESH':
        ra1, ra2 = st.columns(2)
        _ra_proof_confirm = ra1.checkbox('Changed files 전체의 MIGRATION_PROOF_ACCEPTED coverage와 Proof lineage를 직접 확인했습니다.', key='schema_refresh_proof_confirm')
        _ra_target_confirm = ra2.checkbox('현재 CSV Schema Snapshot이 승인하려는 Target Schema와 일치함을 확인했습니다.', key='schema_refresh_target_confirm')
        ra3, ra4 = st.columns(2)
        _ra_no_auto = ra3.checkbox('Refresh Approval은 새 Baseline/Contract를 자동 생성하거나 Migration을 자동 적용하지 않음을 확인했습니다.', key='schema_refresh_no_auto_confirm')
        _ra_no_destructive = ra4.checkbox('새 Baseline/Contract Re-lock은 별도 Human Review이며 destructive migration을 자동 수행하지 않음을 확인했습니다.', key='schema_refresh_no_destructive_confirm')
        _ra_human = st.checkbox('현재 Schema Baseline Refresh Approval을 최종 Human Review했습니다.', key='schema_refresh_human_confirm')
        _ra_reason = st.text_area('Refresh Reason', key='schema_refresh_reason', placeholder='Accepted migration proof를 근거로 왜 새 baseline이 필요한지 기록')
        _ra_scope = st.text_area('Refresh Scope', key='schema_refresh_scope', placeholder='새 baseline에 포함할 file/column 변경 범위를 기록')
        _ra_rollback = st.text_input('Rollback Reference', key='schema_refresh_rollback', placeholder='예: verified backup / prior baseline ID / recovery point')
        _ra_note = st.text_input('Schema Refresh Approval 메모', key='schema_refresh_note')
        _ra_validation = validate_schema_refresh_approval(_sc_schema_scan, _sc_schema_baseline, _sc_schema_contract, _sc_compat_closure, _sc_schema_proofs, _sc_refresh_approval, refresh_reason=_ra_reason, refresh_scope=_ra_scope, rollback_reference=_ra_rollback, proof_coverage_confirmed=_ra_proof_confirm, target_schema_confirmed=_ra_target_confirm, no_auto_refresh_confirmed=_ra_no_auto, no_destructive_migration_confirmed=_ra_no_destructive, human_review_confirmed=_ra_human)
        rag1, rag2, rag3 = st.columns(3)
        rag1.metric('Refresh Approval Gate', _ra_validation['approval_gate'])
        rag2.metric('Approval Status', _ra_validation['approval_status'])
        rag3.metric('Migration Authorization', 'NONE')
        if _ra_validation['issues']:
            st.caption('Refresh Approval 저장 전 확인 · ' + ' | '.join(_ra_validation['issues']))
        if st.button('Schema Baseline Refresh Approval 저장', disabled=_ra_validation['approval_gate'] != 'PASS', key='schema_refresh_approval_save'):
            _ra_row = build_schema_refresh_approval_record(_sc_schema_scan, _sc_schema_baseline, _sc_schema_contract, _sc_compat_closure, _ra_validation, refresh_reason=_ra_reason, refresh_scope=_ra_scope, rollback_reference=_ra_rollback, proof_coverage_confirmed=_ra_proof_confirm, target_schema_confirmed=_ra_target_confirm, no_auto_refresh_confirmed=_ra_no_auto, no_destructive_migration_confirmed=_ra_no_destructive, human_review_confirmed=_ra_human, note=_ra_note)
            _ra_hist = load_csv('schema_refresh_approvals.csv')
            for _col in SCHEMA_REFRESH_APPROVAL_COLS:
                if _col not in _ra_hist.columns:
                    _ra_hist[_col] = ''
            _ra_hist = pd.concat([_ra_hist[SCHEMA_REFRESH_APPROVAL_COLS], pd.DataFrame([_ra_row])], ignore_index=True)
            verified_save_feedback(_ra_hist, 'schema_refresh_approvals.csv', f"Schema Baseline Refresh Approval 저장 · {_ra_row['approval_status']} · Changed Files {_ra_row['changed_files']} · Migration Authorization = NONE.", rerun=False)
    st.caption('Controlled Refresh는 accepted proof가 있는 schema change에 대해서만 승인 metadata를 남깁니다. 새 Baseline은 1I, Contract Re-lock은 1J에서 각각 별도 Human Review로 저장하며 자동 갱신하지 않습니다.')
    _sc_schema_release_context = build_schema_governance_context(data_dir=ROOT / 'data', baselines=_sc_schema_baselines, contracts=_sc_schema_contracts, proposals=_sc_schema_proposals, proofs=_sc_schema_proofs, approvals=_sc_refresh_approvals)
    _sc_schema_release = build_schema_governance_release_gate(_sc_schema_release_context)
    _sc_v125_data = build_v125_data_crosscheck(csv_fail_count=fail_count, schema_release_gate=_sc_schema_release['release_gate'], baseline_integrity=_sc_schema_release_context['baseline_integrity'], contract_integrity=_sc_schema_release_context['contract_integrity'])
    st.subheader('1M. v1.25 Schema Governance Release Data Cross-check')
    sdc1, sdc2, sdc3, sdc4 = st.columns(4)
    sdc1.metric('Schema Data Gate', _sc_v125_data['status'])
    sdc2.metric('Blocking Gates', _sc_v125_data['blocking_count'])
    sdc3.metric('Schema Release', _sc_schema_release['release_gate'])
    sdc4.metric('Migration Authorization', 'NONE')
    st.dataframe(_sc_v125_data['checks'], width='stretch', hide_index=True)
    if _sc_v125_data['status'] == 'PASS':
        st.success('v1.25 Schema Governance Release Data Cross-check PASS · CSV / Baseline / Contract / Schema Release blocking gate가 없습니다.')
    else:
        st.warning('v1.25 Schema Governance Release Data Cross-check BLOCKED · CSV 또는 Schema Baseline/Contract/Release Gate를 확인하세요.')
    _sc_operations_release = build_operations_session_release_gate(load_csv('operations_sessions.csv'))
    _sc_v126_data = build_v126_data_crosscheck(csv_fail_count=fail_count, operations_release_gate=_sc_operations_release['release_gate'], latest_close_integrity=_sc_operations_release['latest_close_integrity'])
    st.subheader('1N. v1.26 Operations Session Release Data Cross-check')
    odc1, odc2, odc3, odc4 = st.columns(4)
    odc1.metric('Operations Data Gate', _sc_v126_data['status'])
    odc2.metric('Blocking Gates', _sc_v126_data['blocking_count'])
    odc3.metric('Latest Close Integrity', _sc_operations_release['latest_close_integrity'])
    odc4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v126_data['checks'], width='stretch', hide_index=True)
    if _sc_v126_data['status'] == 'PASS':
        st.success('v1.26 Operations Session Release Data Cross-check PASS · CSV / Session Release / Latest Close Integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.26 Operations Session Release Data Cross-check BLOCKED · CSV 또는 Session record integrity를 확인하세요.')
    _sc_v127_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    _sc_v127_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    _sc_v127_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    _sc_v127_thesis = build_thesis_monitor(watchlist, _sc_v127_states, _sc_v127_plans, _sc_v127_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=date.today())
    _sc_v127_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    _sc_v127_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _sc_v127_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=_sc_v127_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=_sc_v127_kpis, state_df=_sc_v127_states, thesis_monitor=_sc_v127_thesis, audit_df=_sc_v127_audit, reconciliation=_sc_v127_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=date.today())
    _sc_v127_context = build_v127_operating_context(review_queue=_sc_v127_queue, sessions=load_csv('operations_sessions.csv'), overrides=load_csv('operations_capacity_overrides.csv'), sla_snapshots=load_csv('operations_sla_closure_snapshots.csv'), today=date.today(), session_capacity=5)
    _sc_v127_gate = build_v127_technical_release_gate(_sc_v127_context)
    _sc_v127_data = build_v127_data_crosscheck(csv_fail_count=fail_count, sla_release_gate=_sc_v127_gate['release_gate'], snapshot_integrity=_sc_v127_gate['latest_snapshot_integrity'])
    st.subheader('1O. v1.27 Carry-forward / SLA Release Data Cross-check')
    sdc1, sdc2, sdc3, sdc4 = st.columns(4)
    sdc1.metric('SLA Data Gate', _sc_v127_data['status'])
    sdc2.metric('Blocking Gates', _sc_v127_data['blocking_count'])
    sdc3.metric('Latest SLA Snapshot', _sc_v127_gate['latest_snapshot_integrity'])
    sdc4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v127_data['checks'], width='stretch', hide_index=True)
    if _sc_v127_data['status'] == 'PASS':
        st.success('v1.27 Carry-forward / SLA Release Data Cross-check PASS · CSV / SLA Release / Snapshot Integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.27 Carry-forward / SLA Release Data Cross-check BLOCKED · CSV 또는 SLA snapshot/technical gate를 확인하세요.')
    _sc_v128_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    _sc_v128_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    _sc_v128_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    _sc_v128_thesis = build_thesis_monitor(watchlist, _sc_v128_states, _sc_v128_plans, _sc_v128_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=date.today())
    _sc_v128_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    _sc_v128_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _sc_v128_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=_sc_v128_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=_sc_v128_kpis, state_df=_sc_v128_states, thesis_monitor=_sc_v128_thesis, audit_df=_sc_v128_audit, reconciliation=_sc_v128_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=date.today())
    _sc_v128_context = build_v128_flow_context(review_queue=_sc_v128_queue, sessions=load_csv('operations_sessions.csv'), flow_snapshots=load_csv('operations_flow_snapshots.csv'), trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), calibration_snapshots=load_csv('operations_flow_calibration_snapshots.csv'), today=date.today(), capacity=5)
    _sc_v128_gate = build_v128_flow_release_gate(_sc_v128_context)
    _sc_v128_data = build_v128_data_crosscheck(csv_fail_count=fail_count, flow_release_gate=_sc_v128_gate['release_gate'], latest_calibration_integrity=_sc_v128_gate['latest_calibration_integrity'])
    st.subheader('1P. v1.28 Flow Release Data Cross-check')
    fdc1, fdc2, fdc3, fdc4 = st.columns(4)
    fdc1.metric('Flow Data Gate', _sc_v128_data['status'])
    fdc2.metric('Blocking Gates', _sc_v128_data['blocking_count'])
    fdc3.metric('Latest Calibration', _sc_v128_gate['latest_calibration_integrity'])
    fdc4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v128_data['checks'], width='stretch', hide_index=True)
    if _sc_v128_data['status'] == 'PASS':
        st.success('v1.28 Flow Release Data Cross-check PASS · CSV / Flow Release / Calibration Snapshot Integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.28 Flow Release Data Cross-check BLOCKED · CSV 또는 Flow/Calibration integrity를 확인하세요.')
    _sc_v129_context = build_v129_projection_context(flow_context=_sc_v128_context, trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), calibration_snapshots=load_csv('operations_flow_calibration_snapshots.csv'), projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), outcome_snapshots=load_csv('operations_flow_projection_outcome_snapshots.csv'), scorecard_snapshots=load_csv('operations_flow_projection_scorecard_snapshots.csv'))
    _sc_v129_gate = build_v129_projection_technical_release_gate(_sc_v129_context)
    _sc_v129_lineage = build_v129_projection_lineage_gate(_sc_v129_context)
    _sc_v129_data = build_v129_data_crosscheck(csv_fail_count=fail_count, projection_release_gate=_sc_v129_gate['release_gate'], lineage_release_gate=_sc_v129_lineage['release_gate'], latest_projection_integrity=_sc_v129_gate['latest_projection_integrity'], latest_outcome_integrity=_sc_v129_gate['latest_outcome_integrity'], latest_scorecard_integrity=_sc_v129_gate['latest_scorecard_integrity'])
    st.subheader('1Q. v1.29 Projection Governance Release Data Cross-check')
    pgd1, pgd2, pgd3, pgd4 = st.columns(4)
    pgd1.metric('Projection Data Gate', _sc_v129_data['status'])
    pgd2.metric('Blocking Gates', _sc_v129_data['blocking_count'])
    pgd3.metric('Lineage Gate', _sc_v129_lineage['release_gate'])
    pgd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v129_data['checks'], width='stretch', hide_index=True)
    if _sc_v129_data['status'] == 'PASS':
        st.success('v1.29 Projection Governance Release Data Cross-check PASS · CSV / Projection Technical / Lineage / latest snapshot integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.29 Projection Governance Release Data Cross-check BLOCKED · CSV 또는 Projection governance integrity/lineage를 확인하세요.')
    _sc_v130_context = build_v130_evidence_context(flow_context=_sc_v128_context, sessions=load_csv('operations_sessions.csv'), trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), evidence_snapshots=load_csv('operations_flow_evidence_snapshots.csv'))
    _sc_v130_gate = build_v130_evidence_technical_release_gate(_sc_v130_context)
    _sc_v130_lineage = build_v130_evidence_lineage_gate(_sc_v130_context)
    _sc_v130_data = build_v130_data_crosscheck(csv_fail_count=fail_count, evidence_release_gate=_sc_v130_gate['release_gate'], evidence_lineage_gate=_sc_v130_lineage['release_gate'], latest_evidence_integrity=_sc_v130_gate['latest_evidence_integrity'])
    st.subheader('1R. v1.30 Flow Evidence Qualification Release Data Cross-check')
    fed1, fed2, fed3, fed4 = st.columns(4)
    fed1.metric('Evidence Data Gate', _sc_v130_data['status'])
    fed2.metric('Blocking Gates', _sc_v130_data['blocking_count'])
    fed3.metric('Lineage Gate', _sc_v130_lineage['release_gate'])
    fed4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v130_data['checks'], width='stretch', hide_index=True)
    if _sc_v130_data['status'] == 'PASS':
        st.success('v1.30 Flow Evidence Qualification Release Data Cross-check PASS · CSV / Evidence Technical / Lineage / latest Evidence Snapshot integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.30 Flow Evidence Qualification Release Data Cross-check BLOCKED · CSV 또는 Evidence qualification integrity/lineage를 확인하세요.')
    _sc_v131_context = build_v131_promotion_context(flow_context=_sc_v128_context, promotion_snapshots=load_csv('operations_flow_calibration_promotion_snapshots.csv'))
    _sc_v131_gate = build_v131_promotion_technical_release_gate(_sc_v131_context)
    _sc_v131_audit = build_v131_promotion_audit_gate(_sc_v131_context)
    _sc_v131_data = build_v131_data_crosscheck(csv_fail_count=fail_count, promotion_release_gate=_sc_v131_gate['release_gate'], promotion_audit_gate=_sc_v131_audit['release_gate'], latest_promotion_integrity=_sc_v131_gate['latest_promotion_integrity'])
    st.subheader('1S. v1.31 Calibration Promotion Release Data Cross-check')
    cpd1, cpd2, cpd3, cpd4 = st.columns(4)
    cpd1.metric('Promotion Data Gate', _sc_v131_data['status'])
    cpd2.metric('Blocking Gates', _sc_v131_data['blocking_count'])
    cpd3.metric('Audit Gate', _sc_v131_audit['release_gate'])
    cpd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v131_data['checks'], width='stretch', hide_index=True)
    if _sc_v131_data['status'] == 'PASS':
        st.success('v1.31 Calibration Promotion Release Data Cross-check PASS · CSV / Promotion Technical / Audit / latest Promotion Snapshot integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.31 Calibration Promotion Release Data Cross-check BLOCKED · CSV 또는 Promotion governance integrity를 확인하세요.')
    _sc_v132_context = build_v132_admission_context(flow_context=_sc_v128_context, calibration_snapshots=load_csv('operations_flow_calibration_snapshots.csv'), promotion_snapshots=load_csv('operations_flow_calibration_promotion_snapshots.csv'), admission_snapshots=load_csv('operations_flow_projection_admission_snapshots.csv'))
    _sc_v132_gate = build_v132_admission_technical_release_gate(_sc_v132_context)
    _sc_v132_audit = build_v132_admission_audit_gate(_sc_v132_context)
    _sc_v132_data = build_v132_data_crosscheck(csv_fail_count=fail_count, admission_release_gate=_sc_v132_gate['release_gate'], admission_audit_gate=_sc_v132_audit['release_gate'], latest_admission_integrity=_sc_v132_gate['latest_admission_integrity'])
    st.subheader('1T. v1.32 Projection Admission Release Data Cross-check')
    padt1, padt2, padt3, padt4 = st.columns(4)
    padt1.metric('Admission Data Gate', _sc_v132_data['status'])
    padt2.metric('Blocking Gates', _sc_v132_data['blocking_count'])
    padt3.metric('Audit Gate', _sc_v132_audit['release_gate'])
    padt4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v132_data['checks'], width='stretch', hide_index=True)
    if _sc_v132_data['status'] == 'PASS':
        st.success('v1.32 Projection Admission Release Data Cross-check PASS · CSV / Admission Technical / Audit / latest Admission Snapshot integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.32 Projection Admission Release Data Cross-check BLOCKED · CSV 또는 Admission governance integrity를 확인하세요.')
    _sc_v133_context = build_v133_review_context(projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), review_snapshots=load_csv('operations_flow_projection_review_snapshots.csv'))
    _sc_v133_gate = build_v133_review_technical_release_gate(_sc_v133_context)
    _sc_v133_audit = build_v133_review_audit_gate(_sc_v133_context)
    _sc_v133_data = build_v133_data_crosscheck(csv_fail_count=fail_count, review_release_gate=_sc_v133_gate['release_gate'], review_audit_gate=_sc_v133_audit['release_gate'], latest_review_integrity=_sc_v133_gate['latest_review_integrity'])
    st.subheader('1U. v1.33 Projection Human Review Release Data Cross-check')
    prd1, prd2, prd3, prd4 = st.columns(4)
    prd1.metric('Review Data Gate', _sc_v133_data['status'])
    prd2.metric('Blocking Gates', _sc_v133_data['blocking_count'])
    prd3.metric('Audit Gate', _sc_v133_audit['release_gate'])
    prd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v133_data['checks'], width='stretch', hide_index=True)
    if _sc_v133_data['status'] == 'PASS':
        st.success('v1.33 Projection Human Review Release Data Cross-check PASS · CSV / Review Technical / Audit / latest Review audit integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.33 Projection Human Review Release Data Cross-check BLOCKED · CSV 또는 Review audit/source integrity를 확인하세요.')
    _sc_v134_context = build_v134_outcome_evidence_context(projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), review_snapshots=load_csv('operations_flow_projection_review_snapshots.csv'), trend_snapshots=load_csv('operations_flow_trend_snapshots.csv'), sessions=load_csv('operations_sessions.csv'), outcome_evidence_snapshots=load_csv('operations_flow_projection_outcome_evidence_snapshots.csv'))
    _sc_v134_gate = build_v134_outcome_evidence_technical_release_gate(_sc_v134_context)
    _sc_v134_audit = build_v134_outcome_evidence_audit_gate(_sc_v134_context)
    _sc_v134_data = build_v134_data_crosscheck(csv_fail_count=fail_count, outcome_evidence_release_gate=_sc_v134_gate['release_gate'], outcome_evidence_audit_gate=_sc_v134_audit['release_gate'], latest_outcome_evidence_integrity=_sc_v134_gate['latest_audit_integrity'])
    st.subheader('1V. v1.34 Projection Outcome Evidence Release Data Cross-check')
    oed1, oed2, oed3, oed4 = st.columns(4)
    oed1.metric('Outcome Evidence Data Gate', _sc_v134_data['status'])
    oed2.metric('Blocking Gates', _sc_v134_data['blocking_count'])
    oed3.metric('Audit Gate', _sc_v134_audit['release_gate'])
    oed4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v134_data['checks'], width='stretch', hide_index=True)
    if _sc_v134_data['status'] == 'PASS':
        st.success('v1.34 Projection Outcome Evidence Release Data Cross-check PASS · CSV / Outcome Evidence Technical / Audit / latest audit integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.34 Projection Outcome Evidence Release Data Cross-check BLOCKED · CSV 또는 Outcome Evidence audit/source lineage를 확인하세요.')
    _sc_v135_context = build_v135_scorecard_input_context(outcome_snapshots=load_csv('operations_flow_projection_outcome_snapshots.csv'), outcome_evidence_snapshots=load_csv('operations_flow_projection_outcome_evidence_snapshots.csv'), review_snapshots=load_csv('operations_flow_projection_review_snapshots.csv'), projection_snapshots=load_csv('operations_flow_projection_snapshots.csv'), scorecard_input_snapshots=load_csv('operations_flow_scorecard_input_snapshots.csv'))
    _sc_v135_gate = build_v135_scorecard_input_technical_release_gate(_sc_v135_context)
    _sc_v135_audit = build_v135_scorecard_input_audit_gate(_sc_v135_context)
    _sc_v135_data = build_v135_data_crosscheck(csv_fail_count=fail_count, scorecard_input_release_gate=_sc_v135_gate['release_gate'], scorecard_input_audit_gate=_sc_v135_audit['release_gate'], latest_scorecard_input_integrity=_sc_v135_gate['latest_scorecard_input_integrity'])
    st.subheader('1W. v1.35 Scorecard Input Qualification Release Data Cross-check')
    sid1, sid2, sid3, sid4 = st.columns(4)
    sid1.metric('Scorecard Input Data Gate', _sc_v135_data['status'])
    sid2.metric('Blocking Gates', _sc_v135_data['blocking_count'])
    sid3.metric('Audit Gate', _sc_v135_audit['release_gate'])
    sid4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v135_data['checks'], width='stretch', hide_index=True)
    if _sc_v135_data['status'] == 'PASS':
        st.success('v1.35 Scorecard Input Qualification Release Data Cross-check PASS · CSV / Scorecard Input Technical / Audit / latest audit integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.35 Scorecard Input Qualification Release Data Cross-check BLOCKED · CSV 또는 Scorecard Input audit/integrity를 확인하세요.')
    _sc_v136_context = build_v136_recalibration_context(v135_context=_sc_v135_context, scorecard_snapshots=load_csv('operations_flow_projection_scorecard_snapshots.csv'), recalibration_review_snapshots=load_csv('operations_flow_recalibration_review_snapshots.csv'))
    _sc_v136_gate = build_v136_recalibration_technical_release_gate(_sc_v136_context)
    _sc_v136_audit = build_v136_recalibration_audit_gate(_sc_v136_context)
    _sc_v136_data = build_v136_data_crosscheck(csv_fail_count=fail_count, recalibration_release_gate=_sc_v136_gate['release_gate'], recalibration_audit_gate=_sc_v136_audit['release_gate'], latest_recalibration_review_integrity=_sc_v136_gate['latest_recalibration_review_integrity'])
    st.subheader('1X. v1.36 Recalibration Human Review Release Data Cross-check')
    srr1, srr2, srr3, srr4 = st.columns(4)
    srr1.metric('Recalibration Data Gate', _sc_v136_data['status'])
    srr2.metric('Blocking Gates', _sc_v136_data['blocking_count'])
    srr3.metric('Audit Gate', _sc_v136_audit['release_gate'])
    srr4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v136_data['checks'], width='stretch', hide_index=True)
    if _sc_v136_data['status'] == 'PASS':
        st.success('v1.36 Recalibration Human Review Release Data Cross-check PASS · CSV / Recalibration Technical / Audit / latest contract integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.36 Recalibration Human Review Release Data Cross-check BLOCKED · CSV 또는 Recalibration Contract audit/integrity를 확인하세요.')
    _sc_v137_context = build_v137_proposal_context(v136_context=_sc_v136_context, recalibration_proposal_snapshots=load_csv('operations_flow_recalibration_proposal_snapshots.csv'))
    _sc_v137_gate = build_v137_proposal_technical_release_gate(_sc_v137_context)
    _sc_v137_audit = build_v137_proposal_audit_gate(_sc_v137_context)
    _sc_v137_data = build_v137_data_crosscheck(csv_fail_count=fail_count, proposal_release_gate=_sc_v137_gate['release_gate'], proposal_audit_gate=_sc_v137_audit['release_gate'], latest_proposal_integrity=_sc_v137_gate['latest_recalibration_proposal_integrity'])
    st.subheader('1Y. v1.37 Recalibration Proposal Release Data Cross-check')
    srp1, srp2, srp3, srp4 = st.columns(4)
    srp1.metric('Proposal Data Gate', _sc_v137_data['status'])
    srp2.metric('Blocking Gates', _sc_v137_data['blocking_count'])
    srp3.metric('Audit Gate', _sc_v137_audit['release_gate'])
    srp4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v137_data['checks'], width='stretch', hide_index=True)
    if _sc_v137_data['status'] == 'PASS':
        st.success('v1.37 Recalibration Proposal Release Data Cross-check PASS · CSV / Proposal Technical / Audit / latest Proposal integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.37 Recalibration Proposal Release Data Cross-check BLOCKED · CSV 또는 Proposal audit/integrity를 확인하세요.')
    _sc_v138_context = build_v138_shadow_validation_context(v137_context=_sc_v137_context, shadow_validation_plan_snapshots=load_csv('operations_flow_shadow_validation_plan_snapshots.csv'))
    _sc_v138_gate = build_v138_shadow_validation_technical_release_gate(_sc_v138_context)
    _sc_v138_audit = build_v138_shadow_validation_audit_gate(_sc_v138_context)
    _sc_v138_data = build_v138_data_crosscheck(csv_fail_count=fail_count, shadow_validation_release_gate=_sc_v138_gate['release_gate'], shadow_validation_audit_gate=_sc_v138_audit['release_gate'], latest_plan_integrity=_sc_v138_gate['latest_shadow_validation_plan_integrity'])
    st.subheader('1Z. v1.38 Shadow Validation Preregistration Release Data Cross-check')
    svd1, svd2, svd3, svd4 = st.columns(4)
    svd1.metric('Validation Data Gate', _sc_v138_data['status'])
    svd2.metric('Blocking Gates', _sc_v138_data['blocking_count'])
    svd3.metric('Audit Gate', _sc_v138_audit['release_gate'])
    svd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v138_data['checks'], width='stretch', hide_index=True)
    if _sc_v138_data['status'] == 'PASS':
        st.success('v1.38 Shadow Validation Preregistration Release Data Cross-check PASS · CSV / Validation Technical / Audit / latest Plan integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.38 Shadow Validation Preregistration Release Data Cross-check BLOCKED · CSV 또는 Validation Plan audit/integrity를 확인하세요.')
    _sc_v139_context = build_v139_shadow_evaluation_context(v138_context=_sc_v138_context, scorecard_snapshots=load_csv('operations_flow_projection_scorecard_snapshots.csv'), qualified_outcomes=_sc_v135_context['qualification'].get('qualified_outcome_history', pd.DataFrame()), shadow_validation_outcome_snapshots=load_csv('operations_flow_shadow_validation_outcome_snapshots.csv'))
    _sc_v139_gate = build_v139_shadow_evaluation_technical_release_gate(_sc_v139_context)
    _sc_v139_audit = build_v139_shadow_evaluation_audit_gate(_sc_v139_context)
    _sc_v139_data = build_v139_data_crosscheck(csv_fail_count=fail_count, shadow_evaluation_release_gate=_sc_v139_gate['release_gate'], shadow_evaluation_audit_gate=_sc_v139_audit['release_gate'], latest_shadow_evaluation_integrity=_sc_v139_gate['latest_shadow_validation_outcome_integrity'])
    st.subheader('1AA. v1.39 Shadow Validation Outcome Release Data Cross-check')
    sod1, sod2, sod3, sod4 = st.columns(4)
    sod1.metric('Shadow Evaluation Data Gate', _sc_v139_data['status'])
    sod2.metric('Blocking Gates', _sc_v139_data['blocking_count'])
    sod3.metric('Audit Gate', _sc_v139_audit['release_gate'])
    sod4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v139_data['checks'], width='stretch', hide_index=True)
    if _sc_v139_data['status'] == 'PASS':
        st.success('v1.39 Shadow Validation Outcome Release Data Cross-check PASS · CSV / Shadow Evaluation Technical / Audit / latest Outcome integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.39 Shadow Validation Outcome Release Data Cross-check BLOCKED · CSV 또는 Shadow Evaluation audit/integrity를 확인하세요.')
    _sc_v140_context = build_v140_adoption_context(v139_context=_sc_v139_context, shadow_validation_outcome_snapshots=load_csv('operations_flow_shadow_validation_outcome_snapshots.csv'), shadow_adoption_review_snapshots=load_csv('operations_flow_shadow_adoption_review_snapshots.csv'))
    _sc_v140_gate = build_v140_adoption_technical_release_gate(_sc_v140_context)
    _sc_v140_audit = build_v140_adoption_audit_gate(_sc_v140_context)
    _sc_v140_data = build_v140_data_crosscheck(csv_fail_count=fail_count, adoption_release_gate=_sc_v140_gate['release_gate'], adoption_audit_gate=_sc_v140_audit['release_gate'], latest_adoption_integrity=_sc_v140_gate['latest_shadow_adoption_integrity'])
    st.subheader('1AB. v1.40 Shadow Adoption Human Decision Release Data Cross-check')
    sad1, sad2, sad3, sad4 = st.columns(4)
    sad1.metric('Adoption Data Gate', _sc_v140_data['status'])
    sad2.metric('Blocking Gates', _sc_v140_data['blocking_count'])
    sad3.metric('Audit Gate', _sc_v140_audit['release_gate'])
    sad4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v140_data['checks'], width='stretch', hide_index=True)
    if _sc_v140_data['status'] == 'PASS':
        st.success('v1.40 Shadow Adoption Release Data Cross-check PASS · CSV / Adoption Technical / Audit / latest Human decision integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.40 Shadow Adoption Release Data Cross-check BLOCKED · CSV 또는 Adoption audit/integrity를 확인하세요.')
    _sc_v141_context = build_v141_trial_design_context(v140_context=_sc_v140_context, controlled_trial_design_snapshots=load_csv('operations_flow_controlled_trial_design_snapshots.csv'))
    _sc_v141_gate = build_v141_trial_design_technical_release_gate(_sc_v141_context)
    _sc_v141_audit = build_v141_trial_design_audit_gate(_sc_v141_context)
    _sc_v141_data = build_v141_data_crosscheck(csv_fail_count=fail_count, trial_design_release_gate=_sc_v141_gate['release_gate'], trial_design_audit_gate=_sc_v141_audit['release_gate'], latest_trial_design_integrity=_sc_v141_gate['latest_trial_design_integrity'])
    st.subheader('1AC. v1.41 Controlled Trial Design Release Data Cross-check')
    ctdc1, ctdc2, ctdc3, ctdc4 = st.columns(4)
    ctdc1.metric('Trial Design Data Gate', _sc_v141_data['status'])
    ctdc2.metric('Blocking Gates', _sc_v141_data['blocking_count'])
    ctdc3.metric('Audit Gate', _sc_v141_audit['release_gate'])
    ctdc4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v141_data['checks'], width='stretch', hide_index=True)
    if _sc_v141_data['status'] == 'PASS':
        st.success('v1.41 Controlled Trial Design Release Data Cross-check PASS · CSV / Trial Design Technical / Audit / latest Design integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.41 Controlled Trial Design Release Data Cross-check BLOCKED · CSV 또는 Trial Design audit/integrity를 확인하세요.')
    _sc_v142_context = build_v142_trial_start_context(v141_context=_sc_v141_context, controlled_trial_start_snapshots=load_csv('operations_flow_controlled_trial_start_snapshots.csv'))
    _sc_v142_gate = build_v142_trial_start_technical_release_gate(_sc_v142_context)
    _sc_v142_audit = build_v142_trial_start_audit_gate(_sc_v142_context)
    _sc_v142_data = build_v142_data_crosscheck(csv_fail_count=fail_count, trial_start_release_gate=_sc_v142_gate['release_gate'], trial_start_audit_gate=_sc_v142_audit['release_gate'], latest_trial_start_integrity=_sc_v142_gate['latest_trial_start_integrity'])
    st.subheader('1AD. v1.42 Controlled Trial Start Release Data Cross-check')
    ctsd1, ctsd2, ctsd3, ctsd4 = st.columns(4)
    ctsd1.metric('Trial Start Data Gate', _sc_v142_data['status'])
    ctsd2.metric('Blocking Gates', _sc_v142_data['blocking_count'])
    ctsd3.metric('Audit Gate', _sc_v142_audit['release_gate'])
    ctsd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v142_data['checks'], width='stretch', hide_index=True)
    if _sc_v142_data['status'] == 'PASS':
        st.success('v1.42 Controlled Trial Start Release Data Cross-check PASS · CSV / Trial Start Technical / Audit / latest Start integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.42 Controlled Trial Start Release Data Cross-check BLOCKED · CSV 또는 Trial Start audit/integrity를 확인하세요.')
    _sc_v143_context = build_v143_trial_runtime_context(v142_context=_sc_v142_context, controlled_trial_runtime_snapshots=load_csv('operations_flow_controlled_trial_runtime_snapshots.csv'))
    _sc_v143_gate = build_v143_trial_runtime_technical_release_gate(_sc_v143_context)
    _sc_v143_audit = build_v143_trial_runtime_audit_gate(_sc_v143_context)
    _sc_v143_data = build_v143_data_crosscheck(csv_fail_count=fail_count, trial_runtime_release_gate=_sc_v143_gate['release_gate'], trial_runtime_audit_gate=_sc_v143_audit['release_gate'], latest_trial_runtime_integrity=_sc_v143_gate['latest_trial_runtime_integrity'])
    st.subheader('1AE. v1.43 Controlled Trial Runtime Release Data Cross-check')
    ctrd1, ctrd2, ctrd3, ctrd4 = st.columns(4)
    ctrd1.metric('Trial Runtime Data Gate', _sc_v143_data['status'])
    ctrd2.metric('Blocking Gates', _sc_v143_data['blocking_count'])
    ctrd3.metric('Audit Gate', _sc_v143_audit['release_gate'])
    ctrd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v143_data['checks'], width='stretch', hide_index=True)
    if _sc_v143_data['status'] == 'PASS':
        st.success('v1.43 Controlled Trial Runtime Release Data Cross-check PASS · CSV / Runtime Technical / Audit / latest Runtime integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.43 Controlled Trial Runtime Release Data Cross-check BLOCKED · CSV 또는 Runtime audit/integrity를 확인하세요.')
    _sc_v144_context = build_v144_trial_outcome_context(v143_context=_sc_v143_context, recalibration_proposal_snapshots=_sc_v137_context['recalibration_proposal_snapshots'], qualified_outcomes=_sc_v135_context['qualification'].get('qualified_outcome_history', pd.DataFrame()), controlled_trial_outcome_snapshots=load_csv('operations_flow_controlled_trial_outcome_snapshots.csv'))
    _sc_v144_gate = build_v144_trial_outcome_technical_release_gate(_sc_v144_context)
    _sc_v144_audit = build_v144_trial_outcome_audit_gate(_sc_v144_context)
    _sc_v144_data = build_v144_data_crosscheck(csv_fail_count=fail_count, trial_outcome_release_gate=_sc_v144_gate['release_gate'], trial_outcome_audit_gate=_sc_v144_audit['release_gate'], latest_trial_outcome_integrity=_sc_v144_gate['latest_trial_outcome_integrity'])
    st.subheader('1AF. v1.44 Controlled Trial Outcome Release Data Cross-check')
    ctod1, ctod2, ctod3, ctod4 = st.columns(4)
    ctod1.metric('Trial Outcome Data Gate', _sc_v144_data['status'])
    ctod2.metric('Blocking Gates', _sc_v144_data['blocking_count'])
    ctod3.metric('Audit Gate', _sc_v144_audit['release_gate'])
    ctod4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v144_data['checks'], width='stretch', hide_index=True)
    if _sc_v144_data['status'] == 'PASS':
        st.success('v1.44 Controlled Trial Outcome Release Data Cross-check PASS · CSV / Trial Outcome Technical / Audit / latest Outcome integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.44 Controlled Trial Outcome Release Data Cross-check BLOCKED · CSV 또는 Trial Outcome audit/integrity를 확인하세요.')
    _sc_v145_context = build_v145_trial_closure_context(v144_context=_sc_v144_context, controlled_trial_closure_snapshots=load_csv('operations_flow_controlled_trial_closure_snapshots.csv'))
    _sc_v145_gate = build_v145_trial_closure_technical_release_gate(_sc_v145_context)
    _sc_v145_audit = build_v145_trial_closure_audit_gate(_sc_v145_context)
    _sc_v145_data = build_v145_data_crosscheck(csv_fail_count=fail_count, trial_closure_release_gate=_sc_v145_gate['release_gate'], trial_closure_audit_gate=_sc_v145_audit['release_gate'], latest_trial_closure_integrity=_sc_v145_gate['latest_trial_closure_integrity'])
    st.subheader('1AG. v1.45 Controlled Trial Closure Release Data Cross-check')
    ctcd1, ctcd2, ctcd3, ctcd4 = st.columns(4)
    ctcd1.metric('Trial Closure Data Gate', _sc_v145_data['status'])
    ctcd2.metric('Blocking Gates', _sc_v145_data['blocking_count'])
    ctcd3.metric('Audit Gate', _sc_v145_audit['release_gate'])
    ctcd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v145_data['checks'], width='stretch', hide_index=True)
    if _sc_v145_data['status'] == 'PASS':
        st.success('v1.45 Controlled Trial Closure Release Data Cross-check PASS · CSV / Trial Closure Technical / Audit / latest Closure integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.45 Controlled Trial Closure Release Data Cross-check BLOCKED · CSV 또는 Trial Closure audit/integrity를 확인하세요.')
    _sc_v146_context = build_v146_live_change_design_context(v145_context=_sc_v145_context, recalibration_proposal_snapshots=load_csv('operations_flow_recalibration_proposal_snapshots.csv'), live_change_design_snapshots=load_csv('operations_flow_live_change_design_snapshots.csv'))
    _sc_v146_gate = build_v146_live_change_design_technical_release_gate(_sc_v146_context)
    _sc_v146_audit = build_v146_live_change_design_audit_gate(_sc_v146_context)
    _sc_v146_data = build_v146_data_crosscheck(csv_fail_count=fail_count, live_change_design_release_gate=_sc_v146_gate['release_gate'], live_change_design_audit_gate=_sc_v146_audit['release_gate'], latest_live_change_design_integrity=_sc_v146_gate['latest_live_change_design_integrity'])
    st.subheader('1AH. v1.46 Live Change Design Release Data Cross-check')
    lcdd1, lcdd2, lcdd3, lcdd4 = st.columns(4)
    lcdd1.metric('Live Change Design Data Gate', _sc_v146_data['status'])
    lcdd2.metric('Blocking Gates', _sc_v146_data['blocking_count'])
    lcdd3.metric('Audit Gate', _sc_v146_audit['release_gate'])
    lcdd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v146_data['checks'], width='stretch', hide_index=True)
    if _sc_v146_data['status'] == 'PASS':
        st.success('v1.46 Live Change Design Release Data Cross-check PASS · CSV / Design Technical / Audit / latest Design integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.46 Live Change Design Release Data Cross-check BLOCKED · CSV 또는 Live Change Design audit/integrity를 확인하세요.')
    _sc_v147_context = build_v147_live_change_apply_context(v146_context=_sc_v146_context, live_change_apply_snapshots=load_csv('operations_flow_live_change_apply_snapshots.csv'))
    _sc_v147_gate = build_v147_live_change_apply_technical_release_gate(_sc_v147_context)
    _sc_v147_audit = build_v147_live_change_apply_audit_gate(_sc_v147_context)
    _sc_v147_data = build_v147_data_crosscheck(csv_fail_count=fail_count, live_change_apply_release_gate=_sc_v147_gate['release_gate'], live_change_apply_audit_gate=_sc_v147_audit['release_gate'], latest_live_change_apply_integrity=_sc_v147_gate['latest_live_change_apply_integrity'])
    st.subheader('1AI. v1.47 Live Change Apply Release Data Cross-check')
    lcad1, lcad2, lcad3, lcad4 = st.columns(4)
    lcad1.metric('Live Change Apply Data Gate', _sc_v147_data['status'])
    lcad2.metric('Blocking Gates', _sc_v147_data['blocking_count'])
    lcad3.metric('Audit Gate', _sc_v147_audit['release_gate'])
    lcad4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v147_data['checks'], width='stretch', hide_index=True)
    if _sc_v147_data['status'] == 'PASS':
        st.success('v1.47 Live Change Apply Release Data Cross-check PASS · CSV / Apply Technical / Audit / latest Apply integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.47 Live Change Apply Release Data Cross-check BLOCKED · CSV 또는 Live Change Apply audit/integrity를 확인하세요.')
    _sc_v148_context = build_v148_live_change_runtime_context(v147_context=_sc_v147_context, live_change_runtime_snapshots=load_csv('operations_flow_live_change_runtime_snapshots.csv'))
    _sc_v148_gate = build_v148_live_change_runtime_technical_release_gate(_sc_v148_context)
    _sc_v148_audit = build_v148_live_change_runtime_audit_gate(_sc_v148_context)
    _sc_v148_data = build_v148_data_crosscheck(csv_fail_count=fail_count, live_change_runtime_release_gate=_sc_v148_gate['release_gate'], live_change_runtime_audit_gate=_sc_v148_audit['release_gate'], latest_live_change_runtime_integrity=_sc_v148_gate['latest_live_change_runtime_integrity'])
    st.subheader('1AJ. v1.48 Live Change Runtime Release Data Cross-check')
    lcrd1, lcrd2, lcrd3, lcrd4 = st.columns(4)
    lcrd1.metric('Live Change Runtime Data Gate', _sc_v148_data['status'])
    lcrd2.metric('Blocking Gates', _sc_v148_data['blocking_count'])
    lcrd3.metric('Audit Gate', _sc_v148_audit['release_gate'])
    lcrd4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v148_data['checks'], width='stretch', hide_index=True)
    if _sc_v148_data['status'] == 'PASS':
        st.success('v1.48 Live Change Runtime Release Data Cross-check PASS · CSV / Runtime Technical / Audit / latest Runtime integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.48 Live Change Runtime Release Data Cross-check BLOCKED · CSV 또는 Live Change Runtime audit/integrity를 확인하세요.')
    _sc_v149_context = build_v149_live_change_outcome_context(v148_context=_sc_v148_context, qualified_outcomes=_sc_v135_context['qualification'].get('qualified_outcome_history', pd.DataFrame()), live_change_outcome_snapshots=load_csv('operations_flow_live_change_outcome_snapshots.csv'))
    _sc_v149_gate = build_v149_live_change_outcome_technical_release_gate(_sc_v149_context)
    _sc_v149_audit = build_v149_live_change_outcome_audit_gate(_sc_v149_context)
    _sc_v149_data = build_v149_data_crosscheck(csv_fail_count=fail_count, live_change_outcome_release_gate=_sc_v149_gate['release_gate'], live_change_outcome_audit_gate=_sc_v149_audit['release_gate'], latest_live_change_outcome_integrity=_sc_v149_gate['latest_live_change_outcome_integrity'])
    st.subheader('1AK. v1.49 Live Change Outcome Release Data Cross-check')
    lcod1, lcod2, lcod3, lcod4 = st.columns(4)
    lcod1.metric('Live Change Outcome Data Gate', _sc_v149_data['status'])
    lcod2.metric('Blocking Gates', _sc_v149_data['blocking_count'])
    lcod3.metric('Audit Gate', _sc_v149_audit['release_gate'])
    lcod4.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v149_data['checks'], width='stretch', hide_index=True)
    if _sc_v149_data['status'] == 'PASS':
        st.success('v1.49 Live Change Outcome Release Data Cross-check PASS · CSV / Outcome Technical / Audit / latest Outcome integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.49 Live Change Outcome Release Data Cross-check BLOCKED · CSV 또는 Live Change Outcome audit/integrity를 확인하세요.')
    _sc_v150_context = build_v150_live_change_closure_context(v149_context=_sc_v149_context, live_change_closure_snapshots=load_csv('operations_flow_live_change_outcome_closure_snapshots.csv'))
    _sc_v150_gate = build_v150_live_change_closure_technical_release_gate(_sc_v150_context)
    _sc_v150_audit = build_v150_live_change_closure_audit_gate(_sc_v150_context)
    _sc_v150_rm_status = release_manager_status_report(ROOT, include_candidates=False)
    _sc_v150_migration_verify = work_ready_verify_migration(Path(_WORK_READY_LAYOUT['home_root'])) if _WORK_READY_LAYOUT.get('active') else {'status': 'LEGACY', 'checks': {}}
    _sc_v150_work_context = build_v150_work_ready_context(code_root=ROOT, layout=_WORK_READY_LAYOUT, release_manager_status=_sc_v150_rm_status, migration_verify=_sc_v150_migration_verify)
    _sc_v150_work_gate = build_v150_work_ready_release_gate(_sc_v150_work_context)
    _sc_v150_data = build_v150_data_crosscheck(csv_fail_count=fail_count, closure_release_gate=_sc_v150_gate['release_gate'], closure_audit_gate=_sc_v150_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_closure_integrity=_sc_v150_gate['latest_live_change_closure_integrity'])
    st.subheader('1AL. v1.50 Work-ready Human Closure Release Data Cross-check')
    scv1501, scv1502, scv1503, scv1504 = st.columns(4)
    scv1501.metric('v1.50 Data Gate', _sc_v150_data['status'])
    scv1502.metric('Blocking Gates', _sc_v150_data['blocking_count'])
    scv1503.metric('Work-ready Gate', _sc_v150_work_gate['release_gate'])
    scv1504.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v150_data['checks'], width='stretch', hide_index=True)
    if _sc_v150_data['status'] == 'PASS':
        st.success('v1.50 Release Data Cross-check PASS · CSV / Human Closure / Work-ready / latest Closure integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.50 Release Data Cross-check BLOCKED · CSV 또는 Human Closure/Work-ready audit/integrity를 확인하세요.')
    _sc_v151_context = build_v151_permanent_change_design_context(v150_context=_sc_v150_context, permanent_change_design_snapshots=load_csv('operations_flow_permanent_change_design_snapshots.csv'))
    _sc_v151_gate = build_v151_permanent_change_design_technical_release_gate(_sc_v151_context)
    _sc_v151_audit = build_v151_permanent_change_design_audit_gate(_sc_v151_context)
    _sc_v151_data = build_v151_data_crosscheck(csv_fail_count=fail_count, design_release_gate=_sc_v151_gate['release_gate'], design_audit_gate=_sc_v151_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_design_integrity=_sc_v151_gate['latest_permanent_change_design_integrity'])
    st.subheader('1AM. v1.51 Permanent Change Design Release Data Cross-check')
    scv1511, scv1512, scv1513, scv1514 = st.columns(4)
    scv1511.metric('v1.51 Data Gate', _sc_v151_data['status'])
    scv1512.metric('Blocking Gates', _sc_v151_data['blocking_count'])
    scv1513.metric('Work-ready Gate', _sc_v150_work_gate['release_gate'])
    scv1514.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v151_data['checks'], width='stretch', hide_index=True)
    if _sc_v151_data['status'] == 'PASS':
        st.success('v1.51 Release Data Cross-check PASS · CSV / Permanent Design / Work-ready / latest Design integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.51 Release Data Cross-check BLOCKED · CSV 또는 Permanent Design/Work-ready audit/integrity를 확인하세요.')
    _sc_v152_context = build_v152_permanent_change_apply_context(v151_context=_sc_v151_context, permanent_change_apply_snapshots=load_csv('operations_flow_permanent_change_apply_snapshots.csv'))
    _sc_v152_gate = build_v152_permanent_change_apply_technical_release_gate(_sc_v152_context)
    _sc_v152_audit = build_v152_permanent_change_apply_audit_gate(_sc_v152_context)
    _sc_v152_data = build_v152_data_crosscheck(csv_fail_count=fail_count, apply_release_gate=_sc_v152_gate['release_gate'], apply_audit_gate=_sc_v152_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_apply_integrity=_sc_v152_gate['latest_permanent_change_apply_integrity'])
    st.subheader('1AN. v1.52 Permanent Change Apply Release Data Cross-check')
    scv1521, scv1522, scv1523, scv1524 = st.columns(4)
    scv1521.metric('v1.52 Data Gate', _sc_v152_data['status'])
    scv1522.metric('Blocking Gates', _sc_v152_data['blocking_count'])
    scv1523.metric('Work-ready Gate', _sc_v150_work_gate['release_gate'])
    scv1524.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v152_data['checks'], width='stretch', hide_index=True)
    if _sc_v152_data['status'] == 'PASS':
        st.success('v1.52 Release Data Cross-check PASS · CSV / Permanent Apply / Work-ready / latest Apply integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.52 Release Data Cross-check BLOCKED · CSV 또는 Permanent Apply/Work-ready audit/integrity를 확인하세요.')
    _sc_v153_context = build_v153_permanent_change_runtime_context(v152_context=_sc_v152_context, permanent_change_runtime_events=load_csv('operations_flow_permanent_change_runtime_events.csv'))
    _sc_v153_gate = build_v153_permanent_change_runtime_technical_release_gate(_sc_v153_context)
    _sc_v153_audit = build_v153_permanent_change_runtime_audit_gate(_sc_v153_context)
    _sc_v153_data = build_v153_data_crosscheck(csv_fail_count=fail_count, runtime_release_gate=_sc_v153_gate['release_gate'], runtime_audit_gate=_sc_v153_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'], latest_runtime_integrity=_sc_v153_gate['latest_permanent_change_runtime_integrity'])
    st.subheader('1AO. v1.53 Permanent Change Runtime Release Data Cross-check')
    scv1531, scv1532, scv1533, scv1534 = st.columns(4)
    scv1531.metric('v1.53 Data Gate', _sc_v153_data['status'])
    scv1532.metric('Blocking Gates', _sc_v153_data['blocking_count'])
    scv1533.metric('Work-ready Gate', _sc_v150_work_gate['release_gate'])
    scv1534.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v153_data['checks'], width='stretch', hide_index=True)
    if _sc_v153_data['status'] == 'PASS':
        st.success('v1.53 Release Data Cross-check PASS · CSV / Permanent Runtime / Work-ready / latest Runtime integrity blocking gate가 없습니다.')
    else:
        st.warning('v1.53 Release Data Cross-check BLOCKED · CSV 또는 Permanent Runtime/Work-ready audit/integrity를 확인하세요.')
    _sc_v154_context = build_v154_updater2_context(ROOT)
    _sc_v154_gate = build_v154_updater2_technical_release_gate(_sc_v154_context)
    _sc_v154_audit = build_v154_updater2_audit_gate(_sc_v154_context)
    _sc_v154_data = build_v154_data_crosscheck(csv_fail_count=fail_count, updater2_release_gate=_sc_v154_gate['release_gate'], updater2_audit_gate=_sc_v154_audit['release_gate'], work_ready_release_gate=_sc_v150_work_gate['release_gate'])
    st.subheader('1AP. v1.54 Updater2 Release Data Cross-check')
    scv1541, scv1542, scv1543, scv1544 = st.columns(4)
    scv1541.metric('v1.54 Data Gate', _sc_v154_data['status'])
    scv1542.metric('Blocking Gates', _sc_v154_data['blocking_count'])
    scv1543.metric('Work-ready Gate', _sc_v150_work_gate['release_gate'])
    scv1544.metric('Execution Authorization', 'NONE')
    st.dataframe(_sc_v154_data['checks'], width='stretch', hide_index=True)
    if _sc_v154_data['status'] == 'PASS':
        st.success('v1.54 Release Data Cross-check PASS · CSV / Updater2 / Work-ready blocking gate가 없습니다.')
    else:
        st.warning('v1.54 Release Data Cross-check BLOCKED · CSV 또는 Updater2/Work-ready audit/integrity를 확인하세요.')
    st.subheader('2. 전체 사용자 데이터 백업')
    latest_backup = latest_user_backup()
    if latest_backup.get('exists'):
        st.caption(f"최근 전체 백업: {latest_backup['modified']} · {latest_backup['files']}개 파일")
    else:
        st.caption('아직 전체 사용자 데이터 백업이 없습니다.')
    if st.button('사용자 데이터 전체 백업', type='primary', key='save_center_full_backup'):
        try:
            folder = backup_user_data()
            st.session_state['_save_flash'] = ('success', f'전체 사용자 데이터 백업 완료 · {folder.name}')
            st.rerun()
        except Exception as e:
            st.error(f'전체 백업 실패: {e}')
    st.caption('전체 백업에는 data/*.csv와 settings.json이 포함되며, 각 파일 SHA-256이 manifest.json에 기록됩니다. .env가 있으면 로컬 백업 폴더에만 복사하며 앱 화면에는 표시하지 않습니다.')
    st.subheader('3. 최근 저장 기록')
    events = get_save_events(50)
    if events.empty:
        st.info('아직 저장 기록이 없습니다. 다음 저장부터 기록됩니다.')
    else:
        st.dataframe(events.iloc[::-1].reset_index(drop=True), width='stretch', hide_index=True)
        failed_events = events.loc[events['status'].astype(str).eq('FAIL')]
        if not failed_events.empty:
            st.warning('최근 저장 실패 기록이 있습니다. 원인 해결 후 해당 화면에서 다시 한 번 저장하세요.')
    st.subheader('4. 저장이 안 될 때')
    st.write('- CSV를 Excel에서 열어 둔 경우 닫아 주세요.\n- OneDrive/백신이 잠시 파일을 잠그면 앱이 자동으로 여러 번 재시도합니다.\n- 저장 성공 메시지에 `저장 검증 PASS`가 보이면 다시 누르지 않아도 됩니다.\n- 저장 실패 시 버튼을 연속으로 누르기보다 표시된 오류 내용을 먼저 확인하세요.')
    if st.button('저장 상태 다시 검사', key='save_center_recheck'):
        st.rerun()
    st.caption('Save Center는 주문 기능과 무관하며 사용자 데이터의 저장/백업 상태만 점검합니다.')
