from __future__ import annotations
if True:
    st.title('Integrated Action Planner / Final Decision Gate')
    st.caption('Scenario · Canonical · Thesis · Lifecycle · Price · Portfolio Fit · Factor Risk · Execution · Review Queue를 한 화면에서 합쳐 `오늘 무엇을 할 수 있고 무엇은 아직 금지되는가`를 정리합니다.')
    st.info('Final Gate의 PASS/EXECUTION REVIEW는 매수 추천이 아닙니다. 이 화면은 기존 원본 Gate를 요약할 뿐, 어떤 Gate도 우회하거나 증권사 주문을 전송하지 않습니다.')
    if watchlist.empty:
        st.warning('Watchlist가 비어 있습니다.')
    else:
        ap_names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        handed = str(st.session_state.get('action_planner_company', '') or '').strip()
        ap_default = ap_names.index(handed) if handed in ap_names else 0
        ap_company = st.selectbox('Action Planner 종목', ap_names, index=ap_default, key='action_planner_company_select')
        st.session_state['action_planner_company'] = ap_company
        ap_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
        ap_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
        ap_summary = build_one_page_decision_summary(company=ap_company, watchlist=watchlist, portfolio=portfolio, proof=proof, thesis_plans=ap_plans, kpis=ap_kpis, total_assets=total_assets, loss_budget=loss_budget, single_name_cap=single_cap, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), pilot_fraction=float(settings.get('trade_plan_pilot_fraction', 0.5)), reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), stale_days=int(settings.get('kpi_stale_days', 120)), factor_loadings=factor_loadings)
        ap_scenario_history = load_csv('scenario_refresh_reviews.csv')
        ap_latest_scenario = latest_approved_refresh(ap_scenario_history, ap_company)
        if ap_latest_scenario:
            ap_scenario_recon = reconciliation_status_for_scenario(load_csv('scenario_reconciliation_reviews.csv'), company=ap_company, scenario_row=ap_latest_scenario)
        else:
            ap_scenario_recon = {'status': 'NO APPROVED REFRESH'}
        ap_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
        ap_thesis = build_thesis_monitor(watchlist, ap_states, ap_plans, ap_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)))
        ap_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
        ap_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
        ap_queue_all = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=ap_plans, scenario_refreshes=ap_scenario_history, scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=ap_kpis, state_df=ap_states, thesis_monitor=ap_thesis, audit_df=ap_audit, reconciliation=ap_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)))
        if ap_queue_all.empty:
            ap_company_queue = pd.DataFrame()
        else:
            ap_subject = ap_queue_all['subject'].fillna('').astype(str).str.strip()
            ap_category = ap_queue_all['category'].fillna('').astype(str).str.strip()
            ap_factor = str(ap_summary.get('factor', '') or '').strip()
            ap_mask = ap_subject.eq(ap_company)
            if ap_factor:
                ap_mask |= ap_subject.eq(ap_factor)
            ap_mask |= ap_category.eq('Reconciliation')
            ap_company_queue = ap_queue_all.loc[ap_mask].copy()
        ap_plan = build_integrated_action_plan(summary=ap_summary, latest_scenario=ap_latest_scenario or None, scenario_reconciliation=ap_scenario_recon, company_queue=ap_company_queue)
        st.subheader('1. 오늘의 최종 행동 Gate')
        a1, a2, a3, a4, a5 = st.columns(5)
        a1.metric('현재 행동', ap_plan['action_ko'])
        a2.metric('Final Gate', ap_plan['final_gate'])
        a3.metric('신규 Risk Gate', ap_plan['new_risk_gate'])
        a4.metric('최종 실행 검토 수량', f"{ap_plan['final_executable_shares']:,}주")
        a5.metric('기존 Risk', ap_plan['existing_risk_action'])
        if ap_plan['final_gate'] == 'BLOCKED':
            st.error(f"**{ap_plan['action_ko']}** · 신규 위험 확대는 현재 BLOCKED입니다.")
        elif ap_plan['final_gate'] == 'REVIEW':
            st.warning(f"**{ap_plan['action_ko']}** · 원본 Gate의 REVIEW를 먼저 해결합니다.")
        else:
            st.success('**EXECUTION REVIEW** · 시스템 Gate는 주문계획 검토를 허용하지만 자동매수나 수익보장을 의미하지 않습니다.')
        st.subheader('2. 위험상한 ≠ 실행수량')
        n1, n2, n3, n4 = st.columns(4)
        n1.metric('Risk Ceiling', f"{ap_plan['risk_ceiling_shares']:,}주")
        n2.metric('Lifecycle / Price Executable', f"{ap_plan['executable_shares']:,}주")
        n3.metric('Portfolio 최대 추가', f"{ap_plan['portfolio_max_add_shares']:,}주")
        n4.metric('Final 실행 검토 상한', f"{ap_plan['final_executable_shares']:,}주")
        st.caption('Final 실행 검토 상한은 여러 Gate 중 더 작은 값으로 제한됩니다. 0주이면 Risk Ceiling이 양수여도 현재 주문 가능 수량은 0주입니다.')
        st.subheader('3. Final Gate Matrix')
        st.dataframe(ap_plan['gate_rows'], width='stretch', hide_index=True)
        st.subheader('4. 오늘 할 수 있는 것 / 하면 안 되는 것')
        c1, c2 = st.columns(2)
        with c1:
            st.markdown('**오늘 할 수 있는 것**')
            for item in ap_plan['allowed_actions']:
                st.write(f'- {item}')
        with c2:
            st.markdown('**현재 금지 / 우회 금지**')
            for item in ap_plan['prohibited_actions']:
                st.write(f'- {item}')
        st.subheader('5. 왜 막혀 있는가?')
        if ap_plan['blocking_reasons']:
            for reason in ap_plan['blocking_reasons']:
                st.write(f'- {reason}')
        else:
            st.success('현재 신규 Risk Gate를 막는 원본 Gate가 없습니다. 그래도 주문 전 Execution Checklist를 별도로 확인합니다.')
        st.subheader('6. Scenario / Canonical / Portfolio Context')
        x1, x2, x3, x4 = st.columns(4)
        x1.metric('Scenario', ap_plan['scenario_status'])
        x2.metric('Scenario Reconciliation', ap_plan['scenario_reconciliation_status'])
        x3.metric('Portfolio Fit', ap_plan['portfolio_fit'])
        x4.metric('Factor Risk', ap_plan['factor_breach_status'])
        if ap_latest_scenario:
            st.caption(f"Latest APPROVED Scenario Event: {ap_latest_scenario.get('event_date', '-')} · Modeled Bear Downside {pct(ap_latest_scenario.get('modeled_bear_downside', 0.0))}")
        st.subheader('7. 오늘 / 임박 Review Queue')
        q1, q2, q3 = st.columns(3)
        q1.metric('OVERDUE', ap_plan['queue_overdue'])
        q2.metric('TODAY + NOW', ap_plan['queue_now'])
        q3.metric('NEXT 7 DAYS', ap_plan['queue_next_7_days'])
        if ap_company_queue.empty:
            st.info('이 종목/Factor에 연결된 Review Queue 항목이 없습니다.')
        else:
            qshow = ap_company_queue.loc[ap_company_queue['bucket'].isin(['OVERDUE', 'TODAY', 'NOW', 'NEXT 7 DAYS'])].copy()
            if qshow.empty:
                st.info('오늘/7일 내 Queue는 없습니다. FUTURE 일정은 Review Queue에서 확인할 수 있습니다.')
            else:
                st.dataframe(qshow[['bucket', 'due_date', 'category', 'subject', 'status', 'issue', 'go_to']], width='stretch', hide_index=True)
        st.subheader('8. 다음 원본 화면')
        st.write(f"**우선 다음 행동:** {ap_plan['primary_next_action']}")
        st.button(f"{ap_plan['primary_next_page']}로 이동", type='primary', on_click=_navigate, args=(ap_plan['primary_next_page'],), key='action_planner_primary_go')
        nav1, nav2, nav3, nav4 = st.columns(4)
        nav1.button('Decision Summary', on_click=_navigate, args=('Decision Summary', {'decision_summary_company': ap_company}), key='ap_to_decision')
        nav2.button('Review Queue', on_click=_navigate, args=('Review Queue',), key='ap_to_queue')
        nav3.button('Factor Risk Repair', on_click=_navigate, args=('Factor Risk Repair', {'factor_repair_factor': ap_plan.get('factor', '')}), key='ap_to_factor_repair', disabled=not bool(ap_plan.get('factor')))
        nav4.button('Scenario Refresh', on_click=_navigate, args=('Scenario Refresh', {'scenario_refresh_company': ap_company}), key='ap_to_scenario')
        st.subheader('9. Action Planner 감사기록')
        ap_note = st.text_input('검토 메모', value='', key=f'action_planner_note::{ap_company}', placeholder='예: 신규 Add 금지 유지, 다음 실적 후 재검토')
        if st.button('현재 Action Plan 검토기록 저장', key=f'save_action_plan::{ap_company}'):
            row = action_plan_review_row(ap_plan, note=ap_note)
            ap_history = load_csv('action_plan_reviews.csv')
            for col in ACTION_PLAN_REVIEW_COLS:
                if col not in ap_history.columns:
                    ap_history[col] = ''
            ap_history = pd.concat([ap_history[ACTION_PLAN_REVIEW_COLS], pd.DataFrame([row])], ignore_index=True)
            verified_save_feedback(ap_history, 'action_plan_reviews.csv', 'Integrated Action Plan 검토기록을 저장했습니다.', rerun=True)
        ap_history = load_csv('action_plan_reviews.csv')
        if not ap_history.empty and 'company' in ap_history.columns:
            company_history = ap_history.loc[ap_history['company'].fillna('').astype(str).eq(ap_company)].copy()
            if not company_history.empty:
                ap_history_cols = ['timestamp', 'final_gate', 'current_action', 'new_risk_gate', 'existing_risk_action', 'executable_shares', 'portfolio_max_add_shares', 'scenario_reconciliation_status', 'queue_overdue', 'queue_now', 'next_check_date', 'note']
                ap_history_cols = [c for c in ap_history_cols if c in company_history.columns]
                st.dataframe(company_history[ap_history_cols].tail(20), width='stretch', hide_index=True)
        st.caption(f"Action Planner Engine {ap_plan['version']} · Good company ≠ good stock ≠ good price. Final Gate는 투자판단 보조이며 증권사 주문을 전송하지 않습니다.")
