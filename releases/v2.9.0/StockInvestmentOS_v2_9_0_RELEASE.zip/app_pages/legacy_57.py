from __future__ import annotations
if True:
    st.title('OpenDART Auto')
    st.caption('고유번호 동기화 후 종목코드만 입력하면 최근 사용 가능한 재무제표를 탐색하고 주요 계정을 best-effort로 추출합니다.')
    env_dart_key = str(os.getenv('DART_API_KEY', '') or '').strip()
    session_dart_key = str(st.session_state.get('dart_api_key', env_dart_key) or '').strip()
    key = st.text_input('DART API Key', value=session_dart_key, type='password', key='dart_api_key_input', help='한 번 저장하면 프로젝트의 .env에 로컬 저장되어 다음 실행부터 자동으로 불러옵니다.')
    key = str(key or '').strip()
    st.session_state['dart_api_key'] = key
    k1, k2, k3 = st.columns([1, 1, 3])
    if k1.button('API Key 로컬 저장', type='primary'):
        if not key:
            st.error('저장할 DART API Key를 먼저 입력하세요.')
        else:
            try:
                ENV_PATH.touch(exist_ok=True)
                set_key(str(ENV_PATH), 'DART_API_KEY', key, quote_mode='always')
                os.environ['DART_API_KEY'] = key
                st.session_state['dart_api_key'] = key
                st.session_state['_save_flash'] = ('success', 'DART API Key를 이 PC의 프로젝트 .env에 저장했습니다. 다음 실행부터 자동으로 불러옵니다.')
                st.rerun()
            except Exception as e:
                st.error(f'DART API Key 저장 실패: {e}')
    if k2.button('저장된 Key 삭제'):
        try:
            if ENV_PATH.exists():
                unset_key(str(ENV_PATH), 'DART_API_KEY')
            os.environ.pop('DART_API_KEY', None)
            st.session_state.pop('dart_api_key', None)
            st.session_state.pop('dart_api_key_input', None)
            st.session_state['_save_flash'] = ('success', '프로젝트 .env의 DART API Key를 삭제했습니다.')
            st.rerun()
        except Exception as e:
            st.error(f'DART API Key 삭제 실패: {e}')
    persisted_now = str(os.getenv('DART_API_KEY', '') or '').strip()
    if persisted_now:
        k3.success('DART API Key 로컬 저장됨 · 재시작 후 자동 로드')
    else:
        k3.info('아직 로컬 저장되지 않았습니다. Key 입력 후 `API Key 로컬 저장`을 한 번 누르세요.')
    cache = ROOT / 'data' / 'dart_corp_codes.csv'
    c1, c2 = st.columns(2)
    if c1.button('고유번호 목록 동기화'):
        try:
            codes = download_corp_codes(key, cache)
            st.success(f'{len(codes):,}개 기업 저장')
        except Exception as e:
            st.error(str(e))
    code = c2.text_input('종목코드(6자리)', value='005930')
    fsdiv = st.selectbox('재무제표', ['CFS', 'OFS'], format_func=lambda x: '연결' if x == 'CFS' else '별도')
    if st.button('최근 재무 자동수집', type='primary'):
        try:
            if not cache.exists():
                raise RuntimeError('먼저 고유번호 목록을 동기화하세요.')
            codes = pd.read_csv(cache, dtype=str)
            corp = find_corp_code(code, codes)
            if not corp:
                raise RuntimeError('DART 고유번호를 찾지 못했습니다.')
            raw, meta = latest_available_financials(key, corp, fsdiv)
            summary = summarize_financials(raw)
            st.session_state['dart_raw'] = raw
            st.session_state['dart_meta'] = meta
            st.session_state['dart_summary'] = summary
            st.session_state['dart_stock_code'] = code
            st.session_state['dart_corp_code'] = corp
        except Exception as e:
            st.error(str(e))
    if 'dart_summary' in st.session_state:
        summary = st.session_state['dart_summary']
        meta = st.session_state['dart_meta']
        raw = st.session_state['dart_raw']
        corp = st.session_state['dart_corp_code']
        saved_code = st.session_state['dart_stock_code']
        st.success(f"{meta['business_year']} {meta['period']} / {meta['fs_div']} / corp_code {corp}")
        m1, m2, m3, m4 = st.columns(4)
        m1.metric('Cash', krw(summary['cash']))
        m2.metric('Debt proxy', krw(summary['interest_bearing_debt_proxy']))
        m3.metric('Operating Profit', krw(summary['operating_profit']))
        m4.metric('FCF proxy', krw(summary['fcf_proxy']))
        n1, n2, n3, n4 = st.columns(4)
        n1.metric('Net Cash proxy', krw(summary.get('net_cash_proxy')))
        ratio = summary.get('cash_to_debt_proxy')
        n2.metric('Cash / Debt proxy', '-' if ratio is None else f'{float(ratio):,.2f}x')
        interest = summary.get('interest_expense_proxy')
        interest_quality = str(summary.get('interest_expense_proxy_quality', '') or '').upper()
        if interest_quality == 'BROAD_FINANCE_COST_PROXY':
            interest_label = 'Financial expense proxy'
        elif interest_quality == 'INTEREST_LINE':
            interest_label = 'Interest expense'
        else:
            interest_label = 'Interest / finance cost proxy'
        n3.metric(interest_label, krw(interest) if interest is not None else 'Not found')
        extraction_integrity = str(summary.get('extraction_integrity_status', 'LEGACY') or 'LEGACY').upper()
        n4.metric('Extraction Integrity', extraction_integrity)
        if extraction_integrity == 'PASS':
            st.success('재무 자동추출 무결성 PASS · BS/IS·CIS/CF 구분과 선택 계정의 statement scope가 일치합니다.')
        elif extraction_integrity == 'REVIEW':
            st.warning('재무 자동추출 무결성 REVIEW · 아래 JSON의 source statement / value column을 확인하세요.')
        else:
            st.info('Extraction Integrity 메타데이터가 없습니다. 최신 connectors/dart.py가 적용되었는지 확인하세요.')
        source_bits = []
        op_stmt = str(summary.get('operating_profit_source_statement', '') or '')
        op_col = str(summary.get('operating_profit_value_column', '') or '')
        cfo_stmt = str(summary.get('cfo_source_statement', '') or '')
        cfo_col = str(summary.get('cfo_value_column', '') or '')
        capex_stmt = str(summary.get('capex_source_statement', '') or '')
        capex_col = str(summary.get('capex_value_column', '') or '')
        int_stmt = str(summary.get('interest_expense_source_statement', '') or '')
        int_col = str(summary.get('interest_expense_value_column', '') or '')
        if op_stmt or op_col:
            source_bits.append(f"Operating Profit: {op_stmt or '-'} / {op_col or '-'}")
        if cfo_stmt or cfo_col:
            source_bits.append(f"CFO: {cfo_stmt or '-'} / {cfo_col or '-'}")
        if capex_stmt or capex_col:
            source_bits.append(f"CAPEX: {capex_stmt or '-'} / {capex_col or '-'}")
        if int_stmt or int_col:
            source_bits.append(f"Interest/Finance Cost: {int_stmt or '-'} / {int_col or '-'}")
        if source_bits:
            st.caption(' · '.join(source_bits))
        debt_components = pd.DataFrame([{'component': '단기차입금', 'amount': summary.get('short_term_borrowings_proxy')}, {'component': '유동성장기부채/차입금', 'amount': summary.get('current_portion_longterm_proxy')}, {'component': '유동성사채', 'amount': summary.get('current_bonds_proxy')}, {'component': '장기차입금', 'amount': summary.get('long_term_borrowings_proxy')}, {'component': '사채', 'amount': summary.get('bonds_proxy')}, {'component': '유동리스부채', 'amount': summary.get('current_lease_liabilities_proxy')}, {'component': '리스부채', 'amount': summary.get('lease_liabilities_proxy')}])
        debt_components['amount'] = pd.to_numeric(debt_components['amount'], errors='coerce')
        st.subheader('Debt Proxy Breakdown')
        st.dataframe(debt_components, width='stretch', hide_index=True)
        if summary.get('current_portion_longterm_proxy') is not None:
            st.success('유동성장기부채/차입금이 Debt proxy에 포함되었습니다.')
        else:
            st.info('유동성장기부채/차입금 계정을 찾지 못했습니다. 원 공시에서 별도 확인하세요.')
        if interest is None:
            st.warning('이자비용/금융비용을 자동으로 찾지 못했습니다. Refinancing Gate는 PASS-PROXY/REVIEW 상태를 유지하고 주석에서 별도 확인하세요.')
        st.caption('Debt proxy는 자동 계정매칭값입니다. 만기·covenant·리스부채·이자비용은 원 공시 주석 확인 전 확정 PASS로 사용하지 않습니다.')
        st.json(summary)
        with st.expander('원 재무제표'):
            st.dataframe(raw, width='stretch', hide_index=True)
        if st.button('DART Snapshot 저장'):
            snapshot = pd.DataFrame([{**{'stock_code': saved_code, 'corp_code': corp, **meta}, **summary}])
            existing = load_csv('dart_snapshots.csv')
            save_csv(pd.concat([existing, snapshot], ignore_index=True), 'dart_snapshots.csv')
            st.success('data/dart_snapshots.csv에 저장했습니다.')
    st.warning('자동 계정추출은 발행사별 계정명 차이 때문에 추정입니다. 차입금 만기·covenant·CAPEX는 반드시 원 공시 주석을 확인하세요.')
