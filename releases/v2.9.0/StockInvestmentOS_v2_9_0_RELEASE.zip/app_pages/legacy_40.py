from __future__ import annotations
if True:
    st.title('Portfolio Stress / Marginal Risk')
    st.caption('현재 Portfolio의 Bear Capital-at-Risk와 Stress MRC를 보고, 현금에서 특정 종목으로 추가 자본을 옮길 때 위험이 얼마나 늘어나는지 검토합니다.')
    st.info('이 화면은 **Risk-only 검토**입니다. PASS는 매수 추천이 아니며 Lifecycle / Add Freeze / Evidence / Price / Action Planner Gate를 우회하지 않습니다.')
    corr_for_mr = st.session_state.get('stress_corr', pd.DataFrame())
    if not isinstance(corr_for_mr, pd.DataFrame):
        corr_for_mr = pd.DataFrame()
    if corr_for_mr.empty:
        _mr_saved_corr = historical_correlation_matrix_from_records(normalize_historical_correlation_records(load_csv('historical_correlation.csv')))
        if not _mr_saved_corr.empty:
            corr_for_mr = _mr_saved_corr
            st.session_state['stress_corr'] = corr_for_mr
    mr_snapshot = portfolio_stress_snapshot(portfolio, total_assets, corr_for_mr)
    st.subheader('1. Portfolio Risk Snapshot')
    m1, m2, m3, m4, m5, m6 = st.columns(6)
    m1.metric('Direct Bear Loss', pct(mr_snapshot['direct_bear_loss']))
    m2.metric('Stress Proxy', pct(mr_snapshot['stress_proxy']))
    m3.metric('Cash Weight', pct(mr_snapshot['cash_weight']))
    m4.metric('Corr Coverage', pct(mr_snapshot['corr_covered_weight']))
    m5.metric('Risk HHI', f"{mr_snapshot['hhi']:.4f}")
    m6.metric('Top CAR Share', pct(mr_snapshot['top_car_share']))
    if corr_for_mr.empty:
        st.warning('Historical Correlation이 아직 없습니다. Stress MRC는 Direct CAR fallback을 사용합니다. 필요하면 Stress Lab → Historical Correlation에서 먼저 계산하세요.')
        st.button('Stress Lab로 이동', on_click=_navigate, args=('Stress Lab',), key='marginal_to_stress_lab')
    else:
        st.caption('Stress Proxy/MRC는 과거 상관관계 기반 proxy입니다. 위기에서는 상관이 급상승할 수 있으므로 Direct Bear Loss를 함께 봅니다.')
    st.subheader('2. Asset Risk Contribution / Stress MRC')
    mr_contrib = mr_snapshot['asset_contributions'].copy()
    if mr_contrib.empty:
        st.info('위험기여도를 계산할 보유자산이 없습니다.')
    else:
        show_cols = ['name', 'ticker', 'current_value_krw', 'weight', 'bear_downside', 'capital_at_risk', 'direct_car_share', 'stress_mrc', 'stress_component', 'stress_component_share', 'stress_method']
        st.dataframe(mr_contrib[[c for c in show_cols if c in mr_contrib.columns]], width='stretch', hide_index=True)
        st.caption("Stress MRC는 '다음 1원의 위험기여'를 보기 위한 민감도 proxy입니다. 절대적인 손실예측치가 아닙니다.")
    st.subheader('3. Look-through Factor Risk')
    mr_factors = all_factor_exposures(portfolio, total_assets, factor_loadings, factor_cap=float(settings.get('factor_cap', 0.1)))
    if mr_factors.empty:
        st.info('Factor exposure가 없습니다.')
    else:
        factor_cols = ['factor', 'lookthrough_exposure', 'policy_cap', 'excess_exposure', 'breach_status', 'new_risk_headroom', 'approved_assets', 'conservative_assets', 'stale_assets']
        st.dataframe(mr_factors[[c for c in factor_cols if c in mr_factors.columns]], width='stretch', hide_index=True)
    st.subheader('4. Marginal Capital Test · Cash → Recipient')
    mr_options = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist())) if not watchlist.empty else []
    if not mr_options:
        st.warning('Watchlist 종목이 없습니다.')
    else:
        recipient = st.selectbox('Recipient 종목', mr_options, key='marginal_risk_recipient')
        rwh = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(str(recipient))]
        rwr = rwh.iloc[0].to_dict() if not rwh.empty else {}
        r_ticker = str(rwr.get('ticker', '') or '').strip()
        shared_risk = resolve_shared_risk_assumptions(watchlist, recipient, r_ticker, default_downside=0.0, default_price=0.0)
        r_downside = float(shared_risk.get('plausible_downside', 0.0) or 0.0)
        r_factor = str(rwr.get('factor', '') or '').strip()
        r_sector = str(rwr.get('sector', '') or '').strip()
        cash_available = float(mr_snapshot.get('cash_krw', 0.0) or 0.0)
        default_test = min(50000.0, max(0.0, cash_available))
        test_add = st.number_input('현금에서 이동해 볼 금액(KRW)', min_value=0.0, value=float(default_test), step=10000.0, key=f'marginal_test_add::{recipient}', help='실제 주문이 아니라 Risk simulation 금액입니다.')
        mr_review = marginal_add_review(portfolio=portfolio, total_assets=total_assets, candidate_name=recipient, candidate_ticker=r_ticker, candidate_factor=r_factor, candidate_sector=r_sector, candidate_downside=r_downside, add_krw=test_add, loss_budget=loss_budget, single_name_cap=single_cap, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), factor_loadings=factor_loadings, corr=corr_for_mr)
        try:
            mr_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
            mr_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
            mr_summary = build_one_page_decision_summary(company=recipient, watchlist=watchlist, portfolio=portfolio, proof=proof, thesis_plans=mr_plans, kpis=mr_kpis, total_assets=total_assets, loss_budget=loss_budget, single_name_cap=single_cap, factor_cap=float(settings.get('factor_cap', 0.1)), sector_cap=float(settings.get('sector_cap', 0.25)), pilot_fraction=float(settings.get('trade_plan_pilot_fraction', 0.5)), reconciliation_tolerance_krw=float(settings.get('reconciliation_tolerance_krw', 1000)), stale_days=int(settings.get('kpi_stale_days', 120)), factor_loadings=factor_loadings)
            mr_lifecycle = str(mr_summary.get('lifecycle', 'OBSERVE') or 'OBSERVE').upper()
            mr_freeze = str(mr_summary.get('add_freeze', 'REVIEW') or 'REVIEW').upper()
            mr_fit = str(mr_summary.get('portfolio_fit', 'REVIEW') or 'REVIEW').upper()
            mr_price_gate = str(mr_summary.get('price_gate', 'REVIEW') or 'REVIEW').upper()
            mr_exec = int(mr_summary.get('executable_shares', 0) or 0)
            operating_pass = mr_lifecycle in {'INITIAL', 'CORE', 'MAX'} and mr_freeze == 'OFF' and (mr_fit == 'PASS') and (mr_price_gate == 'PASS') and (mr_exec > 0)
            operating_gate = 'PASS' if operating_pass else 'BLOCKED'
        except Exception:
            mr_lifecycle = 'REVIEW'
            mr_freeze = 'REVIEW'
            mr_fit = 'REVIEW'
            mr_price_gate = 'REVIEW'
            mr_exec = 0
            operating_gate = 'REVIEW'
        if mr_review['risk_gate'] == 'PASS' and operating_gate == 'PASS':
            qualified_gate = 'PASS'
        elif mr_review['risk_gate'] == 'BLOCKED' or operating_gate == 'BLOCKED':
            qualified_gate = 'BLOCKED'
        else:
            qualified_gate = 'REVIEW'
        q1, q2, q3, q4, q5, q6 = st.columns(6)
        q1.metric('Risk Gate', mr_review['risk_gate'])
        q2.metric('Operating Gate', operating_gate)
        q3.metric('Qualified Recipient', qualified_gate)
        q4.metric('Incremental CAR', pct(mr_review['incremental_car']))
        q5.metric('Stress Δ', pct(mr_review['stress_proxy_delta']))
        q6.metric('Cash After Test', krw(max(0.0, mr_review['cash_available_krw'] - mr_review['test_add_krw'])))
        gate_table = pd.DataFrame([['Cash', mr_review['cash_gate']], ['Single-name', mr_review['name_gate']], ['Factor', mr_review['factor_gate']], ['Sector', mr_review['sector_gate']], ['Lifecycle', mr_lifecycle], ['Add Freeze', mr_freeze], ['Portfolio Fit', mr_fit], ['Price / No-Chase', mr_price_gate], ['Executable Shares', mr_exec]], columns=['Gate', 'Status'])
        st.dataframe(gate_table, width='stretch', hide_index=True)
        b1, b2, b3, b4 = st.columns(4)
        b1.metric('Current Weight', pct(mr_review['current_weight']))
        b2.metric('Post Weight', pct(mr_review['post_weight']))
        b3.metric('Name Risk Cap', pct(mr_review['name_risk_cap']))
        b4.metric('Cash Available', krw(mr_review['cash_available_krw']))
        if mr_review['factor_blockers']:
            st.warning('Factor Review: ' + ' / '.join(mr_review['factor_blockers']))
        factor_impact = mr_review['factor_impact_table']
        if isinstance(factor_impact, pd.DataFrame) and (not factor_impact.empty):
            st.caption('추가자본 투입 전후 Factor 영향')
            st.dataframe(factor_impact, width='stretch', hide_index=True)
        if qualified_gate == 'PASS':
            st.success('현재 입력값 기준 Risk + Operating Gate가 모두 PASS입니다. 이는 주문 또는 매수 추천이 아니라 추가 검토가 가능한 상태라는 뜻입니다.')
        else:
            st.warning(f'Qualified Recipient = {qualified_gate}. 위험 또는 운영 Gate를 우회해 신규 위험을 늘리지 않습니다.')
        st.subheader('5. Review 저장')
        mr_note = st.text_input('Review Note', value='', key=f'marginal_note::{recipient}')
        if st.button('Marginal Risk Review 저장', key=f'save_marginal_risk::{recipient}'):
            row = marginal_risk_review_row(mr_review, operating_gate=operating_gate, qualified_recipient_gate=qualified_gate, note=mr_note)
            history = load_csv('marginal_risk_reviews.csv')
            history = ensure_cols(history, MARGINAL_RISK_REVIEW_COLS)
            updated = pd.concat([history[MARGINAL_RISK_REVIEW_COLS], pd.DataFrame([row])], ignore_index=True)
            verified_save_feedback(updated, 'marginal_risk_reviews.csv', 'Marginal Risk Review를 저장했습니다.', rerun=True)
        history = ensure_cols(load_csv('marginal_risk_reviews.csv'), MARGINAL_RISK_REVIEW_COLS)
        company_history = history.loc[history['company'].fillna('').astype(str).eq(str(recipient))].copy()
        if not company_history.empty:
            st.caption('최근 저장 Review')
            st.dataframe(company_history.tail(20), width='stretch', hide_index=True)
    st.caption('Capital-at-Risk = Weight × Plausible Downside. Stress MRC는 과거 상관관계 기반 보조지표이며 Crisis 손실의 상한을 보장하지 않습니다.')
