from __future__ import annotations
if True:
    st.title('Monitoring Center 2.0 / Daily Review Plan')
    st.caption('모든 Review Clock을 Master Queue 하나로 통합하고, 오늘 먼저 확인할 작업과 종목별 Monitoring Coverage를 자동 계산합니다.')
    st.info('이 화면은 검토 작업을 자동 정렬할 뿐 투자판단을 자동 변경하지 않습니다. Queue 항목은 원본 Evidence/Clock을 갱신하면 자동으로 사라지거나 이동합니다.')
    mc_today = date.today()
    mc_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    mc_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    mc_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    mc_thesis = build_thesis_monitor(watchlist, mc_states, mc_plans, mc_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=mc_today)
    mc_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    mc_recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    mc_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=mc_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=mc_kpis, state_df=mc_states, thesis_monitor=mc_thesis, audit_df=mc_audit, reconciliation=mc_recon, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=mc_today)
    mc_coverage = monitoring_coverage(watchlist=watchlist, thesis_plans=mc_plans, proof=proof, evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), factor_loadings=factor_loadings, source_candidates=load_csv('source_candidates.csv'), today=mc_today)
    mc_summary = monitoring_summary(mc_queue, mc_coverage)
    st.subheader('1. Monitoring Pulse')
    p1, p2, p3, p4, p5, p6, p7 = st.columns(7)
    p1.metric('OVERDUE', mc_summary['overdue'])
    p2.metric('TODAY + NOW', mc_summary['today'] + mc_summary['now'])
    p3.metric('NEXT 7 DAYS', mc_summary['next_7_days'])
    p4.metric('Coverage PASS', mc_summary['coverage_pass'])
    p5.metric('Coverage REVIEW', mc_summary['coverage_review'])
    p6.metric('Coverage GAP', mc_summary['coverage_gap'])
    p7.metric('Open Source', mc_summary['open_source_candidates'])
    if mc_summary['overdue'] > 0:
        st.error('OVERDUE Review가 있습니다. 가격보다 먼저 Primary Source와 Review Clock을 확인하세요.')
    elif mc_summary['today'] + mc_summary['now'] > 0:
        st.warning('오늘/즉시 확인할 Review가 있습니다. 이는 자동 매수/매도 신호가 아닙니다.')
    else:
        st.success('현재 OVERDUE / TODAY / NOW Review가 없습니다.')
    st.subheader('2. Daily Review Plan')
    max_plan_items = st.slider('오늘 표시할 최대 Review 수', min_value=5, max_value=30, value=12, step=1, key='monitoring_plan_max_items')
    mc_plan = daily_review_plan(mc_queue, max_items=max_plan_items)
    plan_cols = ['bucket', 'due_date', 'category', 'subject', 'status', 'issue', 'next_action', 'go_to']
    if mc_plan.empty:
        st.success('현재 Daily Review Plan이 비어 있습니다.')
    else:
        st.dataframe(mc_plan[[c for c in plan_cols if c in mc_plan.columns]], width='stretch', hide_index=True)
        selector = mc_plan.copy()
        selector['_label'] = selector['bucket'].astype(str) + ' · ' + selector['category'].astype(str) + ' · ' + selector['subject'].astype(str)
        chosen = st.selectbox('바로 검토할 항목', selector['_label'].tolist(), key='monitoring_center_selected_review')
        selected = selector.loc[selector['_label'].eq(chosen)].iloc[0].to_dict()
        target = str(selected.get('go_to', '') or '').strip()
        if target:
            st.button(f'{target}로 이동', type='primary', on_click=_navigate, args=(target,), key='monitoring_center_go_to')
    st.subheader('3. Monitoring Coverage')
    st.caption('Coverage는 종목의 투자매력 점수가 아니라 Thesis / Proof / Evidence / Impact / Decision / Factor Loading이 운영 가능한 상태인지 확인하는 완전성 점검입니다.')
    if mc_coverage.empty:
        st.info('Coverage를 계산할 Watchlist 종목이 없습니다.')
    else:
        st.dataframe(mc_coverage, width='stretch', hide_index=True)
        gaps = mc_coverage.loc[~mc_coverage['coverage_status'].fillna('').astype(str).str.upper().eq('PASS')]
        if gaps.empty:
            st.success('Watchlist 전체 Monitoring Coverage가 PASS입니다.')
        else:
            st.warning(f'Coverage REVIEW/GAP 종목 {len(gaps)}개가 있습니다.')
    st.subheader('4. Monitoring Snapshot')
    monitoring_runs = ensure_cols(load_csv('monitoring_runs.csv'), MONITORING_RUN_COLS)
    if st.button('현재 Monitoring Snapshot 저장', key='save_monitoring_snapshot'):
        try:
            run_row = build_monitoring_run_row(queue=mc_queue, coverage=mc_coverage, technical_attention=0, today=mc_today)
            updated = pd.concat([monitoring_runs[MONITORING_RUN_COLS], pd.DataFrame([run_row])], ignore_index=True)
            verified_save_feedback(updated, 'monitoring_runs.csv', 'Monitoring Snapshot을 저장했습니다.', rerun=True)
        except Exception as e:
            st.error(f'Monitoring Snapshot 저장 실패: {e}')
    if monitoring_runs.empty:
        st.info('저장된 Monitoring Snapshot이 없습니다.')
    else:
        st.dataframe(monitoring_runs.tail(30), width='stretch', hide_index=True)
    st.subheader('5. 원본 Master Review Queue')
    if mc_queue.empty:
        st.success('현재 Master Review Queue가 비어 있습니다.')
    else:
        mc_cols = ['bucket', 'due_date', 'days_to_due', 'category', 'subject', 'status', 'issue', 'next_action', 'go_to']
        st.dataframe(mc_queue[[c for c in mc_cols if c in mc_queue.columns]], width='stretch', hide_index=True)
    nav1, nav2, nav3 = st.columns(3)
    nav1.button('Review Queue', on_click=_navigate, args=('Review Queue',), key='monitoring_to_review_queue')
    nav2.button('Primary Source Monitor', on_click=_navigate, args=('Primary Source Monitor',), key='monitoring_to_source_monitor')
    nav3.button('Stability Audit', on_click=_navigate, args=('Stability Audit',), key='monitoring_to_stability')
    st.caption('Monitoring Center는 앱을 열거나 데이터가 변경될 때 계산됩니다. 백그라운드에서 자동 주문하거나 투자 상태를 임의 변경하지 않습니다.')
