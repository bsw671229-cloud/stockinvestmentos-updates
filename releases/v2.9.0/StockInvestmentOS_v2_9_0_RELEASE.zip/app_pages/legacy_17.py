from __future__ import annotations
if True:
    st.title('Alerts')
    st.caption('Survival / Concentration / Capital-at-Risk / Lifecycle / Evidence / Proof Clock 순으로 위험 신호를 모읍니다.')
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    alerts = build_alerts(portfolio, state_df, proof, total_assets, loss_budget, single_cap, float(settings.get('factor_cap', 0.1)))
    if alerts.empty:
        st.success('현재 규칙 기반 Alert가 없습니다.')
    else:
        severity = st.multiselect('Severity', ['CRITICAL', 'WARNING', 'INFO'], default=['CRITICAL', 'WARNING', 'INFO'])
        view = alerts[alerts['severity'].isin(severity)] if severity else alerts.iloc[0:0]
        st.dataframe(view, width='stretch', hide_index=True)
        st.download_button('Alerts CSV 받기', view.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'alerts.csv', 'text/csv')
