from __future__ import annotations
if True:
    st.title('Evidence Impact Review / Decision Bridge')
    st.caption('Latest APPROVED Evidence를 Thesis · Valuation · Add Freeze · Lifecycle · Scenario · Portfolio Risk와 명시적으로 연결해서 검토합니다.')
    st.info('이 화면은 행동 후보를 구조화하는 감사기록입니다. APPROVED를 눌러도 Watchlist, Lifecycle, Add Freeze, Scenario, Canonical Assumption, Portfolio를 자동 변경하지 않습니다. 실제 변경은 각 원본 화면에서 별도 검토합니다.')
    impact_evidence_packets = normalize_evidence_packets(load_csv('evidence_packets.csv'))
    impact_reviews = normalize_impact_reviews(load_csv('evidence_impact_reviews.csv'))
    if watchlist.empty:
        st.warning('Watchlist가 비어 있습니다.')
    else:
        impact_names = list(dict.fromkeys(watchlist['name'].fillna('').astype(str).tolist()))
        handed_company = str(st.session_state.get('evidence_impact_company', '') or '').strip()
        impact_default = impact_names.index(handed_company) if handed_company in impact_names else 0
        impact_company = st.selectbox('Impact Review 종목', impact_names, index=impact_default, key='evidence_impact_company_select')
        st.session_state['evidence_impact_company'] = impact_company
        source_packet = latest_approved_packet(impact_evidence_packets, impact_company)
        current_impact_status = evidence_impact_status(impact_evidence_packets, impact_reviews, impact_company)
        st.subheader('1. Latest APPROVED Evidence Snapshot')
        if not source_packet:
            st.info('APPROVED Evidence Packet이 없습니다. 먼저 Evidence Intake에서 Primary Source를 검토하세요.')
            st.button('Evidence Intake로 이동', on_click=_navigate, args=('Evidence Intake', {'evidence_intake_company': impact_company}), key=f'impact_to_intake_empty::{impact_company}')
        else:
            s1, s2, s3, s4, s5 = st.columns(5)
            s1.metric('Event', str(source_packet.get('event_date', '') or '-'))
            s2.metric('Signal', str(source_packet.get('evidence_signal', '') or '-'))
            s3.metric('Source Tier', str(source_packet.get('source_tier', '') or '-'))
            s4.metric('Freshness', str(source_packet.get('freshness_status', '') or '-'))
            s5.metric('Hash', str(source_packet.get('hash_status', '') or '-'))
            st.write(f"**Source:** {source_packet.get('source_title', '')}")
            fact_text = str(source_packet.get('fact_summary', '') or '').strip()
            if fact_text:
                st.write(f'**Fact:** {fact_text}')
            interpretation_text = str(source_packet.get('investment_interpretation', '') or '').strip()
            if interpretation_text:
                st.write(f'**Evidence Interpretation:** {interpretation_text}')
            contrary_text = str(source_packet.get('contrary_evidence', '') or '').strip()
            if contrary_text:
                st.write(f'**Existing Contrary Evidence:** {contrary_text}')
            if str(source_packet.get('hash_status', '')).upper() != 'OK':
                st.error('원 Evidence Packet의 Hash Integrity가 OK가 아닙니다. Impact Review 저장보다 Evidence Intake 무결성 확인을 먼저 하세요.')
            st.subheader('1-1. Previous APPROVED 대비 변화')
            previous_packet = previous_approved_packet(impact_evidence_packets, impact_company, str(source_packet.get('evidence_id', '') or ''))
            if not previous_packet:
                st.info('이전 APPROVED Evidence가 없습니다. 현재 Packet이 Impact Review의 첫 Baseline입니다.')
            else:
                impact_diff = build_evidence_diff(previous_packet, source_packet)
                pd1, pd2, pd3 = st.columns(3)
                pd1.metric('Previous APPROVED', str(previous_packet.get('event_date', '') or '-'))
                pd2.metric('Changed Text Fields', impact_diff['changed_fields'])
                pd3.metric('Current Signal', str(source_packet.get('evidence_signal', '') or '-'))
                st.dataframe(impact_diff['metadata'], width='stretch', hide_index=True)
                st.dataframe(impact_diff['summary'], width='stretch', hide_index=True)
                st.caption('이 Diff는 문자 변화의 감사 보조도구입니다. Thesis 강화/약화, Valuation 수정, Add Freeze, Lifecycle, Portfolio Action은 아래에서 사람이 별도로 판단합니다.')
            st.subheader('2. 현재 Impact Review 상태')
            impact_state = current_impact_status.get('status', '-')
            c1, c2, c3, c4 = st.columns(4)
            c1.metric('Impact Status', impact_state)
            c2.metric('Thesis', current_impact_status.get('thesis_impact', '') or '-')
            c3.metric('Valuation', current_impact_status.get('valuation_action', '') or '-')
            c4.metric('Scenario', current_impact_status.get('scenario_action', '') or '-')
            if impact_state == 'REVIEWED':
                st.success('Latest APPROVED Evidence에 대한 Impact Review가 완료되어 있습니다.')
            elif impact_state == 'REVIEW REQUIRED':
                st.warning('Latest APPROVED Evidence의 투자영향 검토가 아직 완료되지 않았습니다.')
            else:
                st.error(f'Impact 상태 = {impact_state}. Hash/Source Link를 먼저 확인하세요.')
            st.subheader('3. 새 Evidence Impact Review')
            r1, r2 = st.columns(2)
            thesis_impact = r1.selectbox('Thesis Impact', THESIS_IMPACTS, index=THESIS_IMPACTS.index('UNCHANGED'), key=f'impact_thesis::{impact_company}', help='Evidence Signal과 동일할 필요는 없습니다. Fact가 장기 Thesis에 미치는 영향을 별도로 판단합니다.')
            valuation_action = r2.selectbox('Valuation Action', VALUATION_ACTIONS, index=VALUATION_ACTIONS.index('NO CHANGE'), key=f'impact_valuation::{impact_company}')
            r3, r4 = st.columns(2)
            add_freeze_action = r3.selectbox('Add Freeze Review', ADD_FREEZE_ACTIONS, index=ADD_FREEZE_ACTIONS.index('KEEP CURRENT'), key=f'impact_add_freeze::{impact_company}')
            lifecycle_action = r4.selectbox('Lifecycle Review', LIFECYCLE_ACTIONS, index=LIFECYCLE_ACTIONS.index('KEEP CURRENT'), key=f'impact_lifecycle::{impact_company}')
            r5, r6 = st.columns(2)
            scenario_action = r5.selectbox('Scenario Action', SCENARIO_ACTIONS, index=SCENARIO_ACTIONS.index('NO REFRESH'), key=f'impact_scenario::{impact_company}')
            portfolio_action = r6.selectbox('Portfolio Risk Action', PORTFOLIO_ACTIONS, index=PORTFOLIO_ACTIONS.index('NO CHANGE'), key=f'impact_portfolio::{impact_company}')
            strongest_counter_case = st.text_area('Strongest Counter Case', value='', key=f'impact_counter::{impact_company}', placeholder='이번 Evidence가 긍정적/부정적으로 보이더라도 현재 해석이 틀릴 수 있는 가장 강한 반대 가설을 독립적으로 적습니다.')
            rationale = st.text_area('Rationale', value='', key=f'impact_rationale::{impact_company}', placeholder='왜 Thesis / Valuation / Risk 행동을 이렇게 분류했는지 Fact와 해석을 구분해서 적습니다.')
            next_action = st.text_area('Next Action', value='', key=f'impact_next_action::{impact_company}', placeholder='예: Add Freeze 유지. 3분기 CFO/FCF 확인 후 Scenario Refresh 재검토.')
            preview_review = {'evidence_id': source_packet.get('evidence_id', ''), 'evidence_content_hash_snapshot': source_packet.get('content_hash', ''), 'company': impact_company, 'ticker': source_packet.get('ticker', ''), 'evidence_event_date': source_packet.get('event_date', ''), 'evidence_signal': source_packet.get('evidence_signal', ''), 'thesis_impact': thesis_impact, 'valuation_action': valuation_action, 'add_freeze_action': add_freeze_action, 'lifecycle_action': lifecycle_action, 'scenario_action': scenario_action, 'portfolio_action': portfolio_action, 'strongest_counter_case': strongest_counter_case, 'rationale': rationale, 'next_action': next_action}
            draft_validation = validate_impact_review(preview_review, for_approval=False)
            approval_validation = validate_impact_review(preview_review, for_approval=True)
            st.subheader('4. Approval Gate')
            g1, g2, g3 = st.columns(3)
            g1.metric('Draft Gate', 'PASS' if draft_validation['valid'] else 'REVIEW')
            g2.metric('Approval Gate', 'PASS' if approval_validation['valid'] else 'REVIEW')
            g3.metric('Source Link', 'PASS' if str(source_packet.get('hash_status', '')).upper() == 'OK' else 'REVIEW')
            if not approval_validation['valid']:
                st.warning('APPROVED 전 확인: ' + ' / '.join(approval_validation['issues']))
            reviewed = st.checkbox('Evidence Snapshot과 Thesis / Valuation / Risk 영향, Strongest Counter Case, Next Action을 직접 검토했습니다.', value=False, key=f'impact_reviewed::{impact_company}')
            target_status = 'APPROVED' if reviewed else 'DRAFT'
            st.write(f'저장 상태: **{target_status}** · 이 저장은 원본 투자 상태를 자동 변경하지 않습니다.')
            if st.button('새 Evidence Impact Review 저장', type='primary', key=f'save_evidence_impact::{impact_company}'):
                if str(source_packet.get('hash_status', '')).upper() != 'OK':
                    st.error('원 Evidence Packet의 Hash Integrity가 OK가 아니므로 Impact Review 저장을 중단했습니다.')
                else:
                    try:
                        review_row = build_evidence_impact_review(evidence_packet=source_packet, thesis_impact=thesis_impact, valuation_action=valuation_action, add_freeze_action=add_freeze_action, lifecycle_action=lifecycle_action, scenario_action=scenario_action, portfolio_action=portfolio_action, strongest_counter_case=strongest_counter_case, rationale=rationale, next_action=next_action, review_status=target_status)
                        updated_reviews = pd.concat([impact_reviews[IMPACT_REVIEW_COLS], pd.DataFrame([review_row])], ignore_index=True)
                        _impact_saved = verified_save_feedback(updated_reviews, 'evidence_impact_reviews.csv', f'Evidence Impact Review를 {target_status} 상태로 저장했습니다.', rerun=False)
                        if _impact_saved:
                            if target_status == 'APPROVED':
                                _bridge = st.session_state.get('_evidence_impact_bridge', {})
                                if isinstance(_bridge, dict) and str(_bridge.get('company', '') or '').strip() == impact_company and (str(_bridge.get('evidence_id', '') or '').strip() == str(source_packet.get('evidence_id', '') or '').strip()):
                                    st.session_state.pop('_evidence_impact_bridge', None)
                            st.rerun()
                    except Exception as e:
                        st.error(f'Evidence Impact Review 저장 실패: {e}')
            st.subheader('5. Impact Review History')
            impact_history = enrich_impact_reviews(impact_reviews, impact_evidence_packets)
            if impact_history.empty:
                st.info('아직 Impact Review 기록이 없습니다.')
            else:
                company_history = impact_history.loc[impact_history['company'].fillna('').astype(str).eq(impact_company)].copy()
                if company_history.empty:
                    st.info('이 종목의 Impact Review 기록이 없습니다.')
                else:
                    history_cols = ['created_at', 'review_status', 'evidence_event_date', 'evidence_signal', 'thesis_impact', 'valuation_action', 'add_freeze_action', 'lifecycle_action', 'scenario_action', 'portfolio_action', 'hash_status', 'link_status', 'next_action']
                    st.dataframe(company_history[[c for c in history_cols if c in company_history.columns]].tail(50), width='stretch', hide_index=True)
            st.subheader('6. 원본 실행 화면')
            b1, b2, b3 = st.columns(3)
            b1.button('Thesis Monitor', on_click=_navigate, args=('Thesis Monitor',), key=f'impact_to_thesis::{impact_company}')
            b2.button('Scenario Refresh', on_click=_navigate, args=('Scenario Refresh',), key=f'impact_to_scenario::{impact_company}')
            b3.button('Decision Summary', on_click=_navigate, args=('Decision Summary',), key=f'impact_to_decision::{impact_company}')
    st.caption('Evidence Impact Review는 Evidence와 행동 사이의 Human Review Layer입니다. 좋은 Evidence ≠ 자동 매수, 나쁜 Evidence ≠ 자동 매도입니다.')
