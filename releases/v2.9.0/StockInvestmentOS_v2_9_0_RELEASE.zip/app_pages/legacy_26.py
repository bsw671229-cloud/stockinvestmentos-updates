from __future__ import annotations
if True:
    st.title('ETF Look-through')
    st.caption('ETF의 기초자산을 직접 입력하거나 지원되는 ETF는 yfinance에서 Top Holdings를 가져옵니다. 부분 보유목록은 Unmapped로 남겨 과도한 정밀도를 피합니다.')
    holdings = ensure_cols(load_csv('etf_holdings.csv'), ETF_HOLDING_COLS)
    tab1, tab2, tab3 = st.tabs(['Holdings 관리', 'Look-through Exposure', 'ETF Overlap'])
    with tab1:
        edited = st.data_editor(holdings, num_rows='dynamic', width='stretch', key='etf_holdings_editor')
        c1, c2, c3 = st.columns(3)
        if c1.button('ETF Holdings 저장', type='primary'):
            save_csv(normalize_holdings(edited), 'etf_holdings.csv')
            st.success('저장했습니다.')
            st.rerun()
        etf_ticker = c2.text_input('yfinance ETF Ticker', value='', placeholder='예: SPY, QQQ')
        etf_name = c3.text_input('ETF 이름', value='')
        if st.button('Top Holdings 자동 가져오기'):
            try:
                fetched = yfinance_top_holdings(etf_ticker)
                fetched['etf_name'] = etf_name or etf_ticker
                fetched['etf_ticker'] = etf_ticker
                fetched['sector'] = ''
                fetched['country'] = ''
                fetched['currency'] = ''
                fetched['factor'] = ''
                fetched['source'] = 'yfinance funds_data'
                fetched['as_of'] = str(date.today())
                fetched = ensure_cols(fetched, ETF_HOLDING_COLS)
                merged = pd.concat([holdings, fetched], ignore_index=True)
                save_csv(normalize_holdings(merged), 'etf_holdings.csv')
                st.success(f'{len(fetched)}개 Top Holdings를 추가했습니다.')
                st.rerun()
            except Exception as e:
                st.error(str(e))
        uploaded = st.file_uploader('ETF holdings CSV 가져오기', type=['csv'], key='etf_csv')
        if uploaded is not None:
            imp = pd.read_csv(uploaded)
            st.dataframe(imp, width='stretch')
            if st.button('업로드 Holdings 추가'):
                merged = pd.concat([holdings, ensure_cols(imp, ETF_HOLDING_COLS)], ignore_index=True)
                save_csv(normalize_holdings(merged), 'etf_holdings.csv')
                st.success('추가했습니다.')
                st.rerun()
    with tab2:
        lt = portfolio_lookthrough(portfolio, holdings)
        if lt.empty:
            st.info('Portfolio 또는 ETF Holdings가 비어 있습니다.')
        else:
            st.subheader('Top Underlying Concentration')
            uc = underlying_concentration(lt, total_assets if total_assets > 0 else None)
            st.dataframe(uc.head(30), width='stretch', hide_index=True)
            dims = st.tabs(['Sector', 'Country', 'Currency', 'Factor'])
            for tab, dim in zip(dims, ['sector', 'country', 'currency', 'factor']):
                with tab:
                    ex = exposure_summary(lt, dim, total_assets if total_assets > 0 else None)
                    st.dataframe(ex, width='stretch', hide_index=True)
                    if not ex.empty:
                        st.bar_chart(ex.set_index(dim)['portfolio_weight'])
            with st.expander('전체 Look-through rows'):
                st.dataframe(lt, width='stretch', hide_index=True)
    with tab3:
        ov = pairwise_etf_overlap(holdings)
        if ov.empty:
            st.info('비교할 ETF Holdings가 2개 이상 필요합니다.')
        else:
            st.dataframe(ov, width='stretch', hide_index=True)
            st.caption('Overlap = 동일 기초자산의 min(weight_A, weight_B) 합계입니다.')
