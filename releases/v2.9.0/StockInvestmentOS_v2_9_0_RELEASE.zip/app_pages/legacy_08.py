from __future__ import annotations
if True:
    st.title('Factor Exposure / Breach Monitor')
    st.caption('기존에 이미 초과된 Factor 위험과 새로 추가하는 위험을 분리합니다. PRE-EXISTING BREACH는 즉시 강제매도를 뜻하지 않지만, 같은 Factor의 신규 위험 Headroom은 0%입니다.')
    factor_cap_policy = float(settings.get('factor_cap', 0.1))
    st.subheader('1. Factor Breach Monitor')
    exposures = all_factor_exposures(portfolio, total_assets, factor_loadings, factor_cap=factor_cap_policy)
    if exposures.empty:
        st.info('표시할 Factor가 없습니다.')
    else:
        monitor = exposures.copy()
        for col in ['lookthrough_exposure', 'policy_cap', 'excess_exposure', 'new_risk_headroom']:
            monitor[col] = pd.to_numeric(monitor[col], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.2%}')
        st.dataframe(monitor[['factor', 'lookthrough_exposure', 'policy_cap', 'excess_exposure', 'breach_status', 'new_risk_headroom', 'approved_assets', 'conservative_assets', 'stale_assets']], width='stretch', hide_index=True)
        breaches = exposures.loc[exposures['breach_status'].astype(str).eq('PRE-EXISTING BREACH')]
        if not breaches.empty:
            st.warning(f'PRE-EXISTING BREACH {len(breaches)}개 · 기존 초과분은 Risk Repair 대상으로 관리하고, 같은 Factor 신규 위험은 차단합니다.')
        else:
            st.success('현재 PRE-EXISTING BREACH Factor가 없습니다.')
    st.subheader('2. 자산별 Factor Loading')
    st.info('승인 Loading이 없거나 검토기한이 지난(STALE) Loading은 Primary Factor 100%로 보수 귀속합니다. Loading은 Factor Cap을 통과시키기 위한 숫자가 아니라 위험 귀속 근거입니다.')
    asset_names = []
    if not portfolio.empty and 'name' in portfolio.columns:
        asset_names += [x for x in portfolio['name'].fillna('').astype(str).tolist() if str(x).strip()]
    if not watchlist.empty and 'name' in watchlist.columns:
        asset_names += [x for x in watchlist['name'].fillna('').astype(str).tolist() if str(x).strip()]
    asset_names = list(dict.fromkeys(asset_names))
    if not asset_names:
        st.info('Portfolio 또는 Watchlist에 자산이 없습니다.')
    else:
        asset = st.selectbox('자산 선택', asset_names, key='factor_exposure_asset')
        ticker = ''
        primary_factor = ''
        wh = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(str(asset))] if not watchlist.empty and 'name' in watchlist.columns else pd.DataFrame()
        ph = portfolio.loc[portfolio['name'].fillna('').astype(str).eq(str(asset))] if not portfolio.empty and 'name' in portfolio.columns else pd.DataFrame()
        if not wh.empty:
            wr = wh.iloc[0]
            ticker = str(wr.get('ticker', '') or '').strip()
            primary_factor = str(wr.get('factor', '') or '').strip()
        elif not ph.empty:
            pr = ph.iloc[0]
            ticker = str(pr.get('ticker', '') or '').strip()
            primary_factor = str(pr.get('factor', '') or '').strip()
        all_rows = loading_status_table(factor_loadings)
        if not all_rows.empty:
            asset_rows = all_rows.loc[all_rows['ticker'].fillna('').astype(str).str.strip().eq(ticker)] if ticker else pd.DataFrame()
            if asset_rows.empty:
                asset_rows = all_rows.loc[all_rows['name'].fillna('').astype(str).eq(str(asset))]
        else:
            asset_rows = pd.DataFrame()
        if asset_rows.empty:
            st.warning(f"등록된 Loading이 없습니다. 현재 `{primary_factor or '미분류'}` Factor에 100% 보수 귀속됩니다.")
        else:
            display_rows = asset_rows.copy()
            display_rows['loading'] = pd.to_numeric(display_rows['loading'], errors='coerce').map(lambda x: '' if pd.isna(x) else f'{x:.1%}')
            st.dataframe(display_rows[[c for c in ['factor', 'loading', 'approved', 'loading_status', 'source', 'review_due_date', 'updated_at', 'note'] if c in display_rows.columns]], width='stretch', hide_index=True)
            stale_count = int(display_rows['loading_status'].astype(str).eq('STALE').sum())
            if stale_count:
                st.error(f'STALE Loading {stale_count}개 · 검토기한이 지나 Primary Factor 100% 보수 귀속으로 돌아갔습니다.')
        with st.form(f'factor_loading_form::{asset}'):
            f1, f2 = st.columns(2)
            factor_name = f1.text_input('Factor', value=primary_factor)
            loading_value = f2.number_input('Loading', min_value=0.001, max_value=1.0, value=1.0, format='%.3f', help='50%면 0.50. 승인 Loading 합계는 자산별 100% 이하여야 합니다.')
            source_text = st.text_input('근거 / Source', placeholder='사업부 비중, ETF holdings, 민감도 추정 근거')
            review_due = st.text_input('Review Due Date', value='', placeholder='YYYY-MM-DD', help='이 날짜가 지나면 STALE 처리되고 100% 보수 귀속으로 돌아갑니다.')
            note_text = st.text_area('Note', placeholder='Loading을 이렇게 잡은 이유와 한계', height=80)
            approve_loading = st.checkbox('이 Loading을 직접 검토했고 Factor Look-through에 사용합니다.', value=False)
            save_loading = st.form_submit_button('Factor Loading 저장', type='primary')
        if save_loading:
            try:
                updated = upsert_factor_loading(factor_loadings, name=asset, ticker=ticker, factor=factor_name, loading=loading_value, approved=approve_loading, source=source_text, note=note_text, review_due_date=review_due)
                verified_save_feedback(updated, 'factor_loadings.csv', f'{asset} Factor Loading을 저장했습니다.')
            except Exception as e:
                st.error(f'저장 실패: {e}')
        if not asset_rows.empty:
            delete_factor = st.selectbox('삭제할 Factor', ['선택 안 함'] + asset_rows['factor'].fillna('').astype(str).tolist(), key=f'factor_delete::{asset}')
            if delete_factor != '선택 안 함':
                if st.button('선택 Factor Loading 삭제', key=f'delete_factor_loading::{asset}'):
                    try:
                        updated = delete_factor_loading(factor_loadings, name=asset, ticker=ticker, factor=delete_factor)
                        verified_save_feedback(updated, 'factor_loadings.csv', f'{asset} · {delete_factor} Loading을 삭제했습니다.')
                    except Exception as e:
                        st.error(f'삭제 실패: {e}')
        st.subheader('3. 선택 자산의 Primary Factor 영향')
        if primary_factor:
            current = portfolio_factor_exposure(portfolio, total_assets, primary_factor, factor_loadings)
            e1, e2, e3 = st.columns(3)
            e1.metric(f'{primary_factor} Look-through 노출', pct(current['exposure']))
            e2.metric('100% 보수 적용 자산 수', current['conservative_assets'])
            e3.metric('STALE 자산 수', current.get('stale_assets', 0))
        else:
            st.info('Primary Factor가 없어 현재 노출을 표시할 수 없습니다.')
    st.caption('PRE-EXISTING BREACH는 기존 집중위험을 뜻합니다. 신규 동일 Factor 위험은 차단하지만, 기존 포지션 축소 여부는 TRIM/Capital Migration에서 별도 판단합니다.')
