from __future__ import annotations
if True:
    st.title('Rebalance Planner')
    st.caption('Trade Planner 위에 Portfolio-level cash reserve와 Reconciliation Gate를 추가합니다. 주문은 전송하지 않습니다.')
    recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    state_df = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    pilot = st.number_input('Initial Pilot Fraction of Risk Max', 0.05, 1.0, float(settings.get('trade_plan_pilot_fraction', 0.5)), format='%.2f', key='rebalance_pilot')
    min_cash = st.number_input('Minimum Cash Weight', 0.0, 1.0, float(settings.get('minimum_cash_weight', 0.2)), format='%.2f')
    raw_plan = generate_trade_plan(state_df, portfolio, total_assets, loss_budget, single_cap, pilot)
    evidence_df = audit_evidence.copy()
    audit = data_quality_report(watchlist, evidence_df, int(settings.get('audit_price_freshness_days', 3)))
    if bool(settings.get('planner_requires_audit_ready', True)):
        raw_plan = apply_audit_gate(raw_plan, audit)
    funded_plan, summary = build_rebalance_summary(raw_plan, portfolio, total_assets, min_cash, recon['status'])
    c1, c2, c3, c4 = st.columns(4)
    c1.metric('Reconciliation', recon['status'])
    c2.metric('Current Cash', krw(summary.get('cash_value', 0)))
    c3.metric('Minimum Cash', krw(summary.get('minimum_cash_value', 0)))
    c4.metric('Funding Status', summary.get('status', '-'))
    c5, c6, c7 = st.columns(3)
    c5.metric('Estimated Sells', krw(summary.get('estimated_sells', 0)))
    c6.metric('Final Estimated Buys', krw(summary.get('final_estimated_buys', 0)))
    c7.metric('Post-plan Cash Proxy', krw(summary.get('post_plan_cash_proxy', 0)))
    if recon['status'] != 'PASS':
        st.error('Reconciliation mismatch 때문에 신규 BUY가 차단되어 있습니다.')
    elif summary.get('status') == 'CASH_RESERVE_BLOCK':
        st.warning('제안된 BUY가 Minimum Cash Weight를 침해하므로 신규 BUY가 차단되었습니다.')
    else:
        st.info('Funding layer를 통과해도 실제 주문 전 가격·Evidence·유동성을 다시 확인해야 합니다.')
    st.dataframe(funded_plan, width='stretch', hide_index=True)
    st.download_button('Rebalance Review CSV 받기', funded_plan.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'rebalance_review.csv', 'text/csv')
