from __future__ import annotations
if True:
    st.title('Data Quality')
    st.caption('새로운 위험을 늘리기 전에 가격·하방·재무생존·Evidence가 충분한지 점검합니다. PASS-PROXY는 확정 PASS가 아니므로 REVIEW로 유지합니다.')
    evidence = audit_evidence.copy()
    legacy_url_rows = 0
    packet_url_rows = 0
    if not evidence.empty and 'audit_evidence_source' in evidence.columns:
        _audit_src = evidence['audit_evidence_source'].fillna('').astype(str)
        legacy_url_rows = int(_audit_src.eq('LEGACY_EVIDENCE_REGISTER').sum())
        packet_url_rows = int(_audit_src.eq('APPROVED_EVIDENCE_PACKET').sum())
    st.caption(f'Evidence Source Bridge · Legacy Register {legacy_url_rows}행 + APPROVED Evidence Packet {packet_url_rows}행. APPROVED Packet은 source URL 요건에 사용할 수 있지만 Watchlist evidence_status는 자동으로 PASS/STRONG으로 바꾸지 않습니다.')
    freshness = st.number_input('Price freshness days', min_value=0, max_value=30, value=int(settings.get('audit_price_freshness_days', 3)), step=1)
    audit = data_quality_report(watchlist, evidence, int(freshness))
    aq = audit_summary(audit)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric('Total', aq['total'])
    c2.metric('READY', aq['ready'])
    c3.metric('REVIEW', aq['review'])
    c4.metric('BLOCKED', aq['blocked'])
    if aq['blocked'] > 0:
        st.error('BLOCKED 종목은 신규 위험 확대를 막습니다.')
    elif aq['review'] > 0:
        st.warning('REVIEW 종목은 가격/공시/Evidence 갱신이 필요합니다.')
    else:
        st.success('Watchlist의 핵심 Data Quality Gate가 READY입니다.')
    st.dataframe(audit, width='stretch', hide_index=True)
    st.download_button('Data Quality CSV 받기', audit.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig'), 'data_quality_audit.csv', 'text/csv')
