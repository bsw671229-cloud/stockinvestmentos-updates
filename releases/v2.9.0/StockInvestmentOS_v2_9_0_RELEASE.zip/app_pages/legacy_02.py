from __future__ import annotations
if True:
    st.title('Operations Control Tower')
    st.caption('많은 메뉴를 돌지 않고 오늘 무엇을 먼저 확인할지 압축합니다. 기술/데이터 무결성 → 기한/Review → 의사결정 상태 순으로 정리합니다.')
    st.info('이 화면의 READY/PASS는 투자 승인이나 매수/매도 신호가 아닙니다. 운영 우선순위와 안전한 다음 원본 화면만 안내합니다. Execution Authorization = NONE.')
    _ct_save_health = verify_user_data_health()
    _ct_csv_fail = int(_ct_save_health['status'].fillna('').astype(str).str.upper().eq('FAIL').sum()) if not _ct_save_health.empty else 0
    _ct_integration, _ct_integration_summary = build_global_integration_audit(watchlist, portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _ct_reconciliation = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    _ct_data_quality = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    _ct_dq_summary = audit_summary(_ct_data_quality)
    _ct_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
    _ct_kpis = normalize_kpis(load_csv('thesis_kpis.csv'))
    _ct_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    _ct_thesis = build_thesis_monitor(watchlist, _ct_states, _ct_plans, _ct_kpis, proof, stale_days=int(settings.get('kpi_stale_days', 120)), today=date.today())
    _ct_master_queue = build_master_review_queue(watchlist=watchlist, portfolio=portfolio, proof=proof, factor_loadings=factor_loadings, thesis_plans=_ct_plans, scenario_refreshes=load_csv('scenario_refresh_reviews.csv'), scenario_reconciliations=load_csv('scenario_reconciliation_reviews.csv'), evidence_packets=load_csv('evidence_packets.csv'), evidence_impact_reviews=load_csv('evidence_impact_reviews.csv'), decision_records=load_csv('decision_records.csv'), decision_outcome_reviews=load_csv('decision_outcome_reviews.csv'), source_candidates=load_csv('source_candidates.csv'), kpis=_ct_kpis, state_df=_ct_states, thesis_monitor=_ct_thesis, audit_df=_ct_data_quality, reconciliation=_ct_reconciliation, total_assets=total_assets, factor_cap=float(settings.get('factor_cap', 0.1)), kpi_stale_days=int(settings.get('kpi_stale_days', 120)), assumption_review_days=int(settings.get('assumption_review_days', 120)), today=date.today())
    _ct_queue_summary = review_queue_summary(_ct_master_queue)
    _ct_review_compression = compress_review_queue(_ct_master_queue)
    _ct_session_worklist = build_session_worklist(_ct_review_compression, max_groups=5)
    _ct_learning = build_learning_cycle_release_gate(load_csv('decision_learning_lineage.csv'), load_csv('learning_feedback_proposals.csv'), load_csv('learning_feedback_revalidation_drafts.csv'), load_csv('learning_feedback_change_lineage.csv'), load_csv('capital_productivity_inputs.csv'), load_csv('capital_productivity_calibration_drafts.csv'), load_csv('capital_productivity_revalidations.csv'), today=date.today())
    _ct_forecast = build_forecast_calibration_release_gate(load_csv('forecast_change_registry.csv'), load_csv('forecast_change_implementation_events.csv'), load_csv('forecast_change_effect_reviews.csv'), load_csv('decision_learning_lineage.csv'), today=date.today())
    _ct_recovery = build_recovery_integration_context(project_root=Path.cwd(), latest_backup=latest_user_backup(), save_health=_ct_save_health, save_events=get_save_events(50), recovery_point_locks=load_csv('recovery_point_locks.csv'), runbook_locks=load_csv('disaster_recovery_runbook_locks.csv'), now=datetime.now().astimezone(), keep_latest=3)
    _ct_schema_context = build_schema_governance_context(data_dir=ROOT / 'data', baselines=load_csv('schema_baseline_locks.csv'), contracts=load_csv('schema_contract_locks.csv'), proposals=load_csv('schema_migration_proposals.csv'), proofs=load_csv('schema_migration_proof_reviews.csv'), approvals=load_csv('schema_refresh_approvals.csv'))
    _ct_schema_release = build_schema_governance_release_gate(_ct_schema_context)
    _ct_tower = build_operations_control_tower(reconciliation_status=_ct_reconciliation['status'], integration_status=_ct_integration_summary['status'], csv_fail_count=_ct_csv_fail, data_quality_blocked=_ct_dq_summary['blocked'], data_quality_review=_ct_dq_summary['review'], review_overdue=_ct_queue_summary['overdue'], review_attention_now=_ct_queue_summary['attention_now'], learning_release_gate=_ct_learning['release_gate'], forecast_release_gate=_ct_forecast['release_gate'], recovery_release_gate=_ct_recovery['recovery_release']['release_gate'], recovery_integration_status=_ct_recovery['recovery_integration_status'], schema_release_gate=_ct_schema_release['release_gate'], schema_contract_drift_status=_ct_schema_release['contract_drift_status'], watchlist_count=len(watchlist))
    ct1, ct2, ct3, ct4, ct5 = st.columns(5)
    ct1.metric('Operations State', _ct_tower['system_state'])
    ct2.metric('Blocking', _ct_tower['blocking_count'])
    ct3.metric('Review', _ct_tower['review_count'])
    ct4.metric('Top Priority', _ct_tower['top_priority'] or '-')
    ct5.metric('Execution Authorization', 'NONE')
    if _ct_tower['system_state'] == 'BLOCKED':
        st.error(f"운영 BLOCKED · 먼저 {_ct_tower['top_domain']}에서 {_ct_tower['top_issue']}를 확인하세요.")
    elif _ct_tower['system_state'] == 'REVIEW':
        st.warning(f"운영 REVIEW · 첫 확인은 {_ct_tower['top_domain']} · {_ct_tower['top_issue']}입니다.")
    else:
        st.success('운영 READY · 현재 기술/데이터 차단과 즉시 Review 항목이 없습니다.')
    st.subheader('1. 오늘의 우선순위 압축')
    _ct_top = top_actions(_ct_tower, limit=5)
    st.dataframe(_ct_top, width='stretch', hide_index=True)
    if not _ct_top.empty:
        _ct_route_options = list(_ct_top.index)

        def _ct_route_label(_idx):
            _r = _ct_top.loc[_idx]
            return f"[{_r.get('priority', '')}] {_r.get('domain', '')} · {_r.get('issue', '')}"
        _ct_route_idx = st.selectbox('원본 화면으로 이동할 항목', options=_ct_route_options, format_func=_ct_route_label, key='operations_control_tower_route')
        _ct_selected = _ct_top.loc[_ct_route_idx].to_dict()
        _ct_go_to = str(_ct_selected.get('go_to', '') or '')
        if _ct_go_to:
            st.button(f'{_ct_go_to}로 이동', type='primary', on_click=_navigate, args=(_ct_go_to,), key='operations_control_tower_go_to')
    st.subheader('1A. Review Queue Action Groups')
    cta1, cta2, cta3, cta4 = st.columns(4)
    cta1.metric('Raw Review Items', _ct_review_compression['raw_items'])
    cta2.metric('Action Groups', _ct_review_compression['action_groups'])
    cta3.metric('Attention Groups', _ct_review_compression['attention_groups'])
    cta4.metric('Compression', f"{_ct_review_compression['compression_ratio']:.1f}x" if _ct_review_compression['action_groups'] > 0 else '-')
    if _ct_session_worklist.empty:
        st.success('현재 Session Worklist로 압축할 Review 항목이 없습니다.')
    else:
        st.dataframe(_ct_session_worklist[['session_rank', 'priority', 'phase', 'category', 'item_count', 'subject_count', 'sample_subjects', 'sample_issues', 'go_to']], width='stretch', hide_index=True)
        st.caption('Raw item 수가 많아도 같은 Category / Route / Status의 반복 항목을 Action Group으로 묶습니다. 원본 개별 항목은 Review Queue에서 그대로 확인할 수 있습니다.')
    _ct_core_gates = {'learning': _ct_learning['release_gate'], 'forecast': _ct_forecast['release_gate'], 'recovery': _ct_recovery['recovery_release']['release_gate'], 'recovery_audit': _ct_recovery['recovery_integration_status'], 'schema': _ct_schema_release['release_gate'], 'schema_drift': _ct_schema_release['contract_drift_status'], 'integration': _ct_integration_summary['status'], 'csv_fail': str(_ct_csv_fail)}
    _ct_session_history = load_csv('operations_sessions.csv')
    _ct_open_session = current_open_session(_ct_session_history)
    _ct_last_closed = latest_closed_session(_ct_session_history)
    st.subheader('1B. Daily Operations Session / Handoff / Operating Close')
    os1, os2, os3, os4 = st.columns(4)
    os1.metric('Session', 'OPEN' if _ct_open_session else 'NO_OPEN_SESSION')
    os2.metric('Current State', _ct_tower['system_state'])
    os3.metric('Attention Groups', _ct_review_compression['attention_groups'])
    os4.metric('Execution Authorization', 'NONE')
    if _ct_last_closed:
        _ct_last_integrity = operations_session_integrity(_ct_last_closed)
        st.caption(f"Last Close · {_ct_last_closed.get('session_id', '')} · {_ct_last_closed.get('event_status', '')} · Carry-forward {_ct_last_closed.get('carry_forward_groups', 0)} groups · Integrity {_ct_last_integrity['status']}")
    if not _ct_open_session:
        _ct_open_note = st.text_input('Session Open 메모', value='', key='operations_session_open_note', placeholder='예: start of day / compressed review queue loaded')
        if st.button('Daily Operations Session 시작', key='operations_session_open'):
            _ct_open_row = build_open_session_record(_ct_tower, _ct_review_compression, _ct_session_worklist, _ct_core_gates, note=_ct_open_note)
            _ct_session_hist = load_csv('operations_sessions.csv')
            for _col in OPERATIONS_SESSION_COLS:
                if _col not in _ct_session_hist.columns:
                    _ct_session_hist[_col] = ''
            _ct_session_hist = pd.concat([_ct_session_hist[OPERATIONS_SESSION_COLS], pd.DataFrame([_ct_open_row])], ignore_index=True)
            verified_save_feedback(_ct_session_hist, 'operations_sessions.csv', f"Daily Operations Session 시작 · {_ct_open_row['session_id']} · State {_ct_open_row['system_state']} · Execution Authorization = NONE.", rerun=False)
    else:
        _ct_open_integrity = operations_session_integrity(_ct_open_session)
        st.info(f"Open Session · {_ct_open_session.get('session_id', '')} · Opened {_ct_open_session.get('created_at', '')} · Integrity {_ct_open_integrity['status']}")
        _ct_close_evidence_readiness = build_flow_evidence_capture_readiness(load_csv('operations_flow_trend_snapshots.csv'), load_csv('operations_sessions.csv'))
        ecr1, ecr2, ecr3 = st.columns(3)
        ecr1.metric('Flow Evidence Capture', _ct_close_evidence_readiness['capture_state'])
        ecr2.metric('In-session Trend', _ct_close_evidence_readiness['eligible_trend_snapshots'])
        ecr3.metric('Execution Authorization', 'NONE')
        _ecr_state = _ct_close_evidence_readiness['capture_state']
        if _ecr_state == 'READY_FOR_EVIDENCE_CLOSE':
            st.success('현재 OPEN Session window 안에 유효한 Flow Trend Snapshot이 있습니다. Session을 CLOSE하면 CLOSE 이전 최신 Snapshot 1개가 Evidence endpoint 후보가 됩니다.')
        elif _ecr_state == 'TREND_SNAPSHOT_REQUIRED_BEFORE_CLOSE':
            st.warning('현재 OPEN Session 안에 Flow Trend Snapshot이 없습니다. Session CLOSE 자체는 가능하지만 이번 Session은 Calibration evidence로 인정되지 않습니다. 실제 Queue 상태를 검토한 뒤 1G에서 Trend Snapshot을 저장하고 CLOSE하는 순서를 권장합니다.')
        elif _ecr_state == 'OPEN_SESSION_INTEGRITY_REVIEW':
            st.error('현재 OPEN Session integrity를 확인할 수 없어 Flow Evidence Capture를 보류합니다.')
        oc1, oc2 = st.columns(2)
        _oc_tower = oc1.checkbox('현재 Control Tower 상태와 Core Gate Snapshot을 직접 확인했습니다.', key='operations_close_tower_confirm')
        _oc_worklist = oc2.checkbox('이번 Session Worklist를 검토했고 미해결 항목은 Carry-forward됨을 확인했습니다.', key='operations_close_worklist_confirm')
        oc3, oc4 = st.columns(2)
        _oc_no_auto = oc3.checkbox('Session Close가 원본 Review 항목을 자동 완료/해결 처리하지 않음을 확인했습니다.', key='operations_close_no_auto_confirm')
        _oc_no_exec = oc4.checkbox('Session Close는 Execution Authorization을 생성하지 않음을 확인했습니다.', key='operations_close_no_exec_confirm')
        _oc_human = st.checkbox('현재 Daily Operations Session을 최종 Human Review했습니다.', key='operations_close_human_confirm')
        _oc_note = st.text_input('Operating Close / Handoff 메모', value='', key='operations_session_close_note', placeholder='예: unresolved groups carried forward / no execution authorization')
        _oc_validation = validate_close_session(_ct_open_session, _ct_tower, control_tower_review_confirmed=_oc_tower, worklist_review_confirmed=_oc_worklist, no_source_auto_resolution_confirmed=_oc_no_auto, no_execution_authorization_confirmed=_oc_no_exec, human_review_confirmed=_oc_human)
        ocg1, ocg2, ocg3 = st.columns(3)
        ocg1.metric('Close Gate', _oc_validation['close_gate'])
        ocg2.metric('Close Status', _oc_validation['close_status'])
        ocg3.metric('Execution Authorization', 'NONE')
        if _oc_validation['issues']:
            st.caption('Session Close 전 확인 · ' + ' | '.join(_oc_validation['issues']))
        if st.button('Daily Operations Session Close / Handoff 저장', disabled=_oc_validation['close_gate'] != 'PASS', key='operations_session_close'):
            _ct_close_row = build_close_session_record(_ct_open_session, _ct_tower, _ct_review_compression, _ct_session_worklist, _ct_core_gates, _oc_validation, control_tower_review_confirmed=_oc_tower, worklist_review_confirmed=_oc_worklist, no_source_auto_resolution_confirmed=_oc_no_auto, no_execution_authorization_confirmed=_oc_no_exec, human_review_confirmed=_oc_human, note=_oc_note)
            _ct_session_hist = load_csv('operations_sessions.csv')
            for _col in OPERATIONS_SESSION_COLS:
                if _col not in _ct_session_hist.columns:
                    _ct_session_hist[_col] = ''
            _ct_session_hist = pd.concat([_ct_session_hist[OPERATIONS_SESSION_COLS], pd.DataFrame([_ct_close_row])], ignore_index=True)
            verified_save_feedback(_ct_session_hist, 'operations_sessions.csv', f"Daily Operations Session Close · {_ct_close_row['event_status']} · Carry-forward {_ct_close_row['carry_forward_groups']} groups · Execution Authorization = NONE.", rerun=False)
    st.caption('Session Open/Close는 운영 스냅샷과 Carry-forward를 기록할 뿐, 원본 Review를 자동 완료하거나 투자행동을 승인하지 않습니다.')
    _ct_carry_forward = build_carry_forward_aging(_ct_review_compression['groups'], load_csv('operations_sessions.csv'), today=date.today())
    _ct_capacity = build_review_capacity_plan(_ct_review_compression, _ct_carry_forward, session_capacity=5)
    _ct_carry_queue = build_carry_forward_queue(_ct_carry_forward, _ct_capacity)
    st.subheader('1C. Carry-forward Aging / Review Capacity / Operating SLA')
    cf1, cf2, cf3, cf4, cf5 = st.columns(5)
    cf1.metric('Capacity Status', _ct_capacity['capacity_status'])
    cf2.metric('Session Capacity', _ct_capacity['session_capacity'])
    cf3.metric('Overflow Groups', _ct_capacity['overflow_groups'])
    cf4.metric('Aging / Stale', f"{_ct_carry_forward['aging_groups']} / {_ct_carry_forward['stale_groups']}")
    cf5.metric('Execution Authorization', 'NONE')
    cfa1, cfa2, cfa3 = st.columns(3)
    cfa1.metric('SLA Breaches', _ct_carry_forward['sla_breaches'])
    cfa2.metric('Oldest Age', f"{_ct_carry_forward['oldest_age_days']}d")
    cfa3.metric('Attention Overflow', _ct_capacity['attention_overflow'])
    if _ct_carry_forward['sla_breaches'] > 0:
        st.warning('Operating SLA Review · 같은 Action Group이 여러 Session에 걸쳐 미해결로 남아 있습니다. 가격 변동보다 원본 Review 사유와 Evidence/Integrity를 먼저 확인하세요.')
    elif _ct_capacity['attention_overflow'] > 0:
        st.info('Attention Group이 Session Capacity 5개를 초과합니다. 상위 Worklist를 먼저 검토하고 나머지는 자동 완료 없이 Carry-forward합니다.')
    else:
        st.success('현재 Carry-forward Aging / Review Capacity가 설정 범위 안에 있습니다.')
    with st.expander('Carry-forward Aging 상세', expanded=False):
        _ct_cf_table = _ct_carry_forward['table']
        if _ct_cf_table.empty:
            st.info('현재 Action Group이 없습니다.')
        else:
            st.dataframe(_ct_cf_table, width='stretch', hide_index=True)
    _ct_cf_note = st.text_input('Carry-forward Snapshot 메모', value='', key='operations_carry_forward_snapshot_note', placeholder='예: weekly capacity review / no auto resolution')
    if st.button('Operations Carry-forward Snapshot 저장', key='operations_carry_forward_snapshot_save'):
        _ct_cf_row = build_carry_forward_snapshot(_ct_carry_forward, _ct_capacity, note=_ct_cf_note)
        _ct_cf_hist = load_csv('operations_carry_forward_snapshots.csv')
        for _col in CARRY_FORWARD_SNAPSHOT_COLS:
            if _col not in _ct_cf_hist.columns:
                _ct_cf_hist[_col] = ''
        _ct_cf_hist = pd.concat([_ct_cf_hist[CARRY_FORWARD_SNAPSHOT_COLS], pd.DataFrame([_ct_cf_row])], ignore_index=True)
        verified_save_feedback(_ct_cf_hist, 'operations_carry_forward_snapshots.csv', f"Operations Carry-forward Snapshot 저장 · Aging {_ct_cf_row['aging_groups']} · SLA Breach {_ct_cf_row['sla_breaches']} · Execution Authorization = NONE.", rerun=False)
    st.caption('Operating SLA는 내부 운영 우선순위 기준입니다. 매수/매도 신호나 투자 승인 기준이 아니며, Action Group을 자동 완료하지 않습니다.')
    _ct_recurrence = build_recurrence_diagnostics(_ct_carry_forward['table'])
    _ct_rebalance = build_capacity_rebalance_plan(_ct_recurrence, session_capacity=5)
    _ct_recurrence_queue = build_recurrence_queue(_ct_recurrence, _ct_rebalance)
    st.subheader('1D. Carry-forward Root Cause / Recurrence / Capacity Rebalancing')
    rr1, rr2, rr3, rr4, rr5 = st.columns(5)
    rr1.metric('Recurring Groups', _ct_recurrence['recurring_groups'])
    rr2.metric('Persistent / Chronic', f"{_ct_recurrence['persistent_groups']} / {_ct_recurrence['chronic_groups']}")
    rr3.metric('SLA Breach Groups', _ct_recurrence['sla_breach_groups'])
    rr4.metric('Selected / Deferred', f"{_ct_rebalance['selected_groups']} / {_ct_rebalance['deferred_groups']}")
    rr5.metric('Execution Authorization', 'NONE')
    if _ct_recurrence['top_root_cause']:
        st.caption(f"Top Root Cause · {_ct_recurrence['top_root_cause']} · Session Capacity {_ct_rebalance['session_capacity']}")
    with st.expander('Root Cause Summary', expanded=False):
        _rr_summary = _ct_recurrence['root_cause_summary']
        if _rr_summary.empty:
            st.info('현재 Root Cause Summary가 없습니다.')
        else:
            st.dataframe(_rr_summary, width='stretch', hide_index=True)
    st.markdown('**이번 Session Capacity Rebalanced Worklist**')
    _rr_worklist = _ct_rebalance['worklist']
    if _rr_worklist.empty:
        st.success('현재 Rebalanced Worklist가 없습니다.')
    else:
        st.dataframe(_rr_worklist, width='stretch', hide_index=True)
    _rr_note = st.text_input('Recurrence / Capacity Snapshot 메모', value='', key='operations_recurrence_snapshot_note', placeholder='예: recurrence reviewed / capacity 5 / no auto resolution')
    if st.button('Operations Recurrence Snapshot 저장', key='operations_recurrence_snapshot_save'):
        _rr_row = build_recurrence_snapshot(_ct_recurrence, _ct_rebalance, note=_rr_note)
        _rr_hist = load_csv('operations_recurrence_snapshots.csv')
        for _col in RECURRENCE_SNAPSHOT_COLS:
            if _col not in _rr_hist.columns:
                _rr_hist[_col] = ''
        _rr_hist = pd.concat([_rr_hist[RECURRENCE_SNAPSHOT_COLS], pd.DataFrame([_rr_row])], ignore_index=True)
        verified_save_feedback(_rr_hist, 'operations_recurrence_snapshots.csv', f"Operations Recurrence Snapshot 저장 · Persistent {_rr_row['persistent_groups']} · Chronic {_rr_row['chronic_groups']} · Execution Authorization = NONE.", rerun=False)
    st.caption('Capacity Rebalancing은 이번 Session에 먼저 볼 그룹의 순서만 조정합니다. 원본 Review를 삭제·완료하거나 투자행동을 승인하지 않습니다.')
    _ct_overrides = load_csv('operations_capacity_overrides.csv')
    _ct_active_override = latest_active_override(_ct_overrides, today=date.today())
    _ct_effective_capacity = effective_capacity(5, _ct_active_override)
    _ct_sla_gate = build_sla_release_gate(_ct_recurrence, _ct_rebalance, _ct_active_override, _ct_effective_capacity)
    _ct_sla_queue = build_sla_queue(_ct_sla_gate, _ct_active_override)
    st.subheader('1E. Operating SLA Closure / Capacity Override Governance')
    sg1, sg2, sg3, sg4, sg5 = st.columns(5)
    sg1.metric('SLA Technical Gate', _ct_sla_gate['release_gate'])
    sg2.metric('SLA State', _ct_sla_gate['sla_state'])
    sg3.metric('Base / Effective Capacity', f"5 / {_ct_effective_capacity['effective_capacity']}")
    sg4.metric('Active Override', _ct_active_override.get('override_id', 'NONE') if _ct_active_override else 'NONE')
    sg5.metric('Execution Authorization', 'NONE')
    st.dataframe(_ct_sla_gate['checks'], width='stretch', hide_index=True)
    if _ct_sla_gate['release_gate'] == 'PASS':
        st.success('Operating SLA Technical Gate PASS · Recurrence / Rebalance / Override 기술 무결성이 정상입니다.')
    else:
        st.error('Operating SLA Technical Gate BLOCKED · Diagnostics / Override integrity를 먼저 확인하세요.')
    if _ct_sla_gate['operating_status'] == 'REVIEW':
        st.warning('Operating Review는 정상적인 미해결 운영 상태입니다. Capacity Override는 예외적 운영 도구이며 자동 적용되지 않습니다.')
    with st.expander('Capacity Override Proposal', expanded=False):
        _ov_base = 5
        _ov_requested = st.number_input('Requested Session Capacity', min_value=6, max_value=10, value=6, step=1, key='operations_capacity_override_requested')
        _ov_days = st.number_input('Override Duration (days)', min_value=1, max_value=14, value=3, step=1, key='operations_capacity_override_days')
        _ov_reason = st.text_area('Override Reason', key='operations_capacity_override_reason', placeholder='예: repeated SLA breach / exceptional evidence backlog')
        _ov_evidence = st.text_area('Override Evidence', key='operations_capacity_override_evidence', placeholder='예: SLA breach groups, recurrence, staffing/capacity evidence')
        ov1, ov2 = st.columns(2)
        _ov_human = ov1.checkbox('Capacity Override의 사유·기간·상한을 직접 Human Review했습니다.', key='operations_capacity_override_human')
        _ov_no_auto = ov2.checkbox('Override 저장은 Session Capacity를 자동 적용하지 않음을 확인했습니다.', key='operations_capacity_override_no_auto')
        _ov_no_exec = st.checkbox('Capacity Override는 Execution Authorization을 생성하지 않음을 확인했습니다.', key='operations_capacity_override_no_exec')
        _ov_note = st.text_input('Capacity Override 메모', key='operations_capacity_override_note')
        _ov_validation = validate_capacity_override(_ct_recurrence, _ct_rebalance, base_capacity=_ov_base, requested_capacity=_ov_requested, reason=_ov_reason, evidence=_ov_evidence, duration_days=_ov_days, human_review_confirmed=_ov_human, no_auto_apply_confirmed=_ov_no_auto, no_execution_authorization_confirmed=_ov_no_exec)
        ovg1, ovg2, ovg3 = st.columns(3)
        ovg1.metric('Override Gate', _ov_validation['override_gate'])
        ovg2.metric('Override Status', _ov_validation['override_status'])
        ovg3.metric('Execution Authorization', 'NONE')
        if st.button('Capacity Override Governance Record 저장', disabled=_ov_validation['override_gate'] != 'PASS', key='operations_capacity_override_save'):
            _ov_row = build_capacity_override_record(_ct_recurrence, _ct_rebalance, _ov_validation, reason=_ov_reason, evidence=_ov_evidence, human_review_confirmed=_ov_human, no_auto_apply_confirmed=_ov_no_auto, no_execution_authorization_confirmed=_ov_no_exec, note=_ov_note)
            _ov_hist = load_csv('operations_capacity_overrides.csv')
            for _col in CAPACITY_OVERRIDE_COLS:
                if _col not in _ov_hist.columns:
                    _ov_hist[_col] = ''
            _ov_hist = pd.concat([_ov_hist[CAPACITY_OVERRIDE_COLS], pd.DataFrame([_ov_row])], ignore_index=True)
            verified_save_feedback(_ov_hist, 'operations_capacity_overrides.csv', f"Capacity Override Governance 저장 · {_ov_row['override_status']} · {_ov_row['base_capacity']}→{_ov_row['requested_capacity']} · Execution Authorization = NONE.", rerun=False)
    _sla_note = st.text_input('Operating SLA Closure Snapshot 메모', key='operations_sla_closure_note', placeholder='예: SLA reviewed / no auto resolution')
    if st.button('Operating SLA Closure Snapshot 저장', key='operations_sla_closure_snapshot_save'):
        _sla_row = build_sla_closure_snapshot(_ct_recurrence, _ct_rebalance, _ct_sla_gate, _ct_active_override, _ct_effective_capacity, base_capacity=5, note=_sla_note)
        _sla_hist = load_csv('operations_sla_closure_snapshots.csv')
        for _col in SLA_CLOSURE_SNAPSHOT_COLS:
            if _col not in _sla_hist.columns:
                _sla_hist[_col] = ''
        _sla_hist = pd.concat([_sla_hist[SLA_CLOSURE_SNAPSHOT_COLS], pd.DataFrame([_sla_row])], ignore_index=True)
        verified_save_feedback(_sla_hist, 'operations_sla_closure_snapshots.csv', f"Operating SLA Closure Snapshot 저장 · {_sla_row['sla_state']} · Technical {_sla_row['technical_gate']} · Execution Authorization = NONE.", rerun=False)
    st.caption('Capacity Override는 일시적 운영 검토 기록이며 자동 Capacity 변경, 원본 Review 완료, 투자 실행을 하지 않습니다.')
    _ct_flow_history = load_csv('operations_flow_snapshots.csv')
    _ct_previous_flow = latest_flow_snapshot(_ct_flow_history)
    _ct_flow = build_flow_diagnostics(_ct_recurrence['table'], _ct_previous_flow, capacity=5)
    _ct_flow_queue = build_flow_queue(_ct_flow)
    st.subheader('1F. Review Flow / Backlog Burn-down / Queue Throughput')
    fl1, fl2, fl3, fl4, fl5 = st.columns(5)
    fl1.metric('Burn-down', _ct_flow['burn_down_status'])
    fl2.metric('Current / Attention', f"{_ct_flow['current_group_count']} / {_ct_flow['current_attention_count']}")
    fl3.metric('New / Persist / Exit', f"{_ct_flow['new_groups']} / {_ct_flow['persisting_groups']} / {_ct_flow['exited_groups']}")
    fl4.metric('Capacity Pressure', f"{_ct_flow['capacity_pressure']:.2f}x")
    fl5.metric('Execution Authorization', 'NONE')
    fld1, fld2, fld3 = st.columns(3)
    fld1.metric('Backlog Δ', _ct_flow['backlog_delta'])
    fld2.metric('Attention Δ', _ct_flow['attention_delta'])
    fld3.metric('Queue Exit Rate', f"{_ct_flow['queue_exit_rate']:.1%}")
    if _ct_flow['burn_down_status'] == 'FIRST_SNAPSHOT':
        st.info('첫 Review Flow Snapshot 전 상태입니다. 현재 Queue를 Baseline으로 저장하면 다음부터 New/Persist/Exit를 비교합니다.')
    elif _ct_flow['burn_down_status'] == 'IMPROVING':
        st.success('Backlog Burn-down IMPROVING · Queue Exit가 신규 유입보다 많고 전체 그룹 수가 감소했습니다.')
    elif _ct_flow['burn_down_status'] == 'GROWING':
        st.warning('Backlog GROWING · 신규 유입이 Queue Exit보다 많습니다. Root Cause와 RQ0/RQ1 유입을 먼저 확인하세요.')
    elif _ct_flow['burn_down_status'] == 'STALLED':
        st.warning('Backlog STALLED · Queue 구성 변화가 없습니다. 반복 그룹의 원본 Review를 우선 확인하세요.')
    else:
        st.info('Backlog MIXED · 신규/지속/Exit가 함께 발생했습니다.')
    with st.expander('Review Flow 상세', expanded=False):
        st.dataframe(_ct_flow['details'], width='stretch', hide_index=True)
    _flow_note = st.text_input('Review Flow Snapshot 메모', value='', key='operations_flow_snapshot_note', placeholder='예: baseline flow snapshot / no auto resolution')
    if st.button('Operations Review Flow Snapshot 저장', key='operations_flow_snapshot_save'):
        _flow_row = build_flow_snapshot(_ct_flow, note=_flow_note)
        _flow_hist = load_csv('operations_flow_snapshots.csv')
        for _col in FLOW_SNAPSHOT_COLS:
            if _col not in _flow_hist.columns:
                _flow_hist[_col] = ''
        _flow_hist = pd.concat([_flow_hist[FLOW_SNAPSHOT_COLS], pd.DataFrame([_flow_row])], ignore_index=True)
        verified_save_feedback(_flow_hist, 'operations_flow_snapshots.csv', f"Operations Review Flow Snapshot 저장 · {_flow_row['burn_down_status']} · Groups {_flow_row['current_group_count']} · Attention {_flow_row['current_attention_count']} · Execution Authorization = NONE.", rerun=False)
    st.caption("Queue Exit는 '현재 Queue에서 사라짐'을 뜻하는 운영 Proxy이며 실제 투자 가설 해결/증명을 자동 의미하지 않습니다. 원본 Review 완료 여부는 해당 원본 화면에서 별도로 확인해야 합니다.")
    _ct_flow_trend_history = load_csv('operations_flow_trend_snapshots.csv')
    _ct_flow_trend = build_flow_trend(_ct_recurrence['table'], _ct_flow_trend_history, capacity=5, forecast_min_snapshots=3, history_window=5)
    _ct_flow_trend_queue = build_flow_trend_queue(_ct_flow_trend)
    st.subheader('1G. Flow Trend / Root-cause Arrival-Exit / Throughput Projection')
    ft1, ft2, ft3, ft4, ft5 = st.columns(5)
    ft1.metric('Trend State', _ct_flow_trend['trend_state'])
    ft2.metric('History Snapshots', _ct_flow_trend['history_snapshots'])
    ft3.metric('Arrival / Exit', f"{_ct_flow_trend['arrivals']} / {_ct_flow_trend['exits']}")
    ft4.metric('Forecast State', _ct_flow_trend['forecast_state'])
    ft5.metric('Execution Authorization', 'NONE')
    ftt1, ftt2, ftt3 = st.columns(3)
    ftt1.metric('Persisting', _ct_flow_trend['persisting'])
    ftt2.metric('Avg Arrival / Exit per Interval', f"{_ct_flow_trend['avg_arrivals_per_interval']:.2f} / {_ct_flow_trend['avg_exits_per_interval']:.2f}")
    ftt3.metric('Projected Clearance Intervals', '-' if _ct_flow_trend['estimated_clearance_intervals'] is None else f"{_ct_flow_trend['estimated_clearance_intervals']:.0f}")
    if _ct_flow_trend['trend_state'] == 'BASELINE_REQUIRED':
        st.info('Root-cause Arrival/Exit 비교용 Trend Baseline이 없습니다. 현재 Group→Root Cause mapping을 첫 Trend Snapshot으로 저장하면 다음부터 정확한 Arrival/Exit 비교가 시작됩니다.')
    elif _ct_flow_trend['trend_state'] == 'IMPROVING':
        st.success('Flow Trend IMPROVING · Exit가 Arrival보다 많고 Group backlog가 감소했습니다.')
    elif _ct_flow_trend['trend_state'] == 'GROWING':
        st.warning('Flow Trend GROWING · Arrival이 Exit보다 많습니다. Root Cause별 신규 유입을 먼저 확인하세요.')
    elif _ct_flow_trend['trend_state'] == 'STALLED':
        st.warning('Flow Trend STALLED · Group 구성 변화가 없습니다.')
    else:
        st.info('Flow Trend MIXED · Arrival / Exit / Persisting이 함께 발생했습니다.')
    if _ct_flow_trend['forecast_state'] == 'INSUFFICIENT_HISTORY':
        st.caption('Throughput Projection은 저장된 Trend Snapshot이 3개 이상일 때만 계산합니다. 초기 구간에서는 숫자를 억지로 예측하지 않습니다.')
    elif _ct_flow_trend['forecast_state'] == 'PROJECTED_BURN_DOWN':
        st.caption('Projected Clearance Intervals는 최근 Snapshot 구간당 평균 Exit-Arrival 속도를 단순 연장한 운영 Projection입니다. 보장이나 투자 판단 기준이 아닙니다.')
    elif _ct_flow_trend['forecast_state'] == 'NO_CLEARING_TREND':
        st.caption('최근 관측에서 Exit가 Arrival을 초과하지 않아 Clearance Projection을 만들지 않습니다.')
    with st.expander('Root-cause Arrival / Exit 상세', expanded=False):
        _ft_root = _ct_flow_trend['root_cause_flow']
        if _ft_root.empty:
            st.info('비교 가능한 Root-cause Flow가 아직 없습니다.')
        else:
            st.dataframe(_ft_root, width='stretch', hide_index=True)
    with st.expander('Throughput History 상세', expanded=False):
        _ft_history = _ct_flow_trend['history_table']
        if _ft_history.empty:
            st.info('저장된 Trend history가 아직 없습니다.')
        else:
            st.dataframe(_ft_history, width='stretch', hide_index=True)
    _ft_note = st.text_input('Flow Trend Snapshot 메모', value='', key='operations_flow_trend_snapshot_note', placeholder='예: root-cause trend baseline / no auto resolution')
    if st.button('Operations Flow Trend Snapshot 저장', key='operations_flow_trend_snapshot_save'):
        _ft_row = build_flow_trend_snapshot(_ct_recurrence['table'], capacity=5, note=_ft_note)
        _ft_hist = load_csv('operations_flow_trend_snapshots.csv')
        for _col in FLOW_TREND_SNAPSHOT_COLS:
            if _col not in _ft_hist.columns:
                _ft_hist[_col] = ''
        _ft_hist = pd.concat([_ft_hist[FLOW_TREND_SNAPSHOT_COLS], pd.DataFrame([_ft_row])], ignore_index=True)
        verified_save_feedback(_ft_hist, 'operations_flow_trend_snapshots.csv', f"Operations Flow Trend Snapshot 저장 · Groups {_ft_row['current_group_count']} · Attention {_ft_row['attention_group_count']} · Execution Authorization = NONE.", rerun=False)
    st.caption('Arrival/Exit는 동일 Group ID의 Queue 유입/이탈을 추적합니다. Exit는 원본 Review 해결을 자동 증명하지 않으며 원본 화면 확인이 필요합니다.')
    _ct_flow_calibration = build_flow_calibration(_ct_flow_trend, _ct_recurrence['table'], _ct_flow_trend_history, capacity=5, min_saved_snapshots=3)
    _ct_flow_evidence = build_flow_evidence_quality(_ct_flow_trend_history, load_csv('operations_sessions.csv'), min_qualified_endpoints=3)
    _ct_flow_qualified_trend = build_flow_trend(_ct_recurrence['table'], _ct_flow_evidence['qualified_trend_history'], capacity=5, forecast_min_snapshots=3, history_window=5)
    _ct_flow_calibration = build_flow_calibration(_ct_flow_qualified_trend, _ct_recurrence['table'], _ct_flow_evidence['qualified_trend_history'], capacity=5, min_saved_snapshots=3)
    _ct_flow_qualified_trend = build_closed_session_calibration_trend(_ct_flow_qualified_trend, _ct_flow_evidence)
    _ct_flow_calibration = build_flow_calibration(_ct_flow_qualified_trend, _ct_recurrence['table'], _ct_flow_evidence['qualified_trend_history'], capacity=5, min_saved_snapshots=3, min_observed_intervals=2)
    _ct_flow_calibration = apply_flow_evidence_guard(_ct_flow_calibration, _ct_flow_evidence)
    _ct_flow_calibration_promotion = build_flow_calibration_promotion(_ct_flow_calibration, _ct_flow_evidence, min_promotion_intervals=3, min_positive_burn_ratio=2 / 3, max_negative_intervals=0)
    _ct_flow_calibration = apply_flow_calibration_promotion_guard(_ct_flow_calibration, _ct_flow_calibration_promotion)
    _ct_flow_calibration_promotion_queue = build_flow_calibration_promotion_queue(_ct_flow_calibration_promotion)
    _ct_flow_calibration_queue = build_flow_calibration_queue(_ct_flow_calibration)
    _ct_flow_calibration_history = load_csv('operations_flow_calibration_snapshots.csv')
    _ct_latest_flow_calibration = latest_flow_calibration_snapshot(_ct_flow_calibration_history)
    _ct_flow_evidence_history = load_csv('operations_flow_evidence_snapshots.csv')
    _ct_latest_flow_evidence = latest_flow_evidence_snapshot(_ct_flow_evidence_history)
    _ct_flow_evidence_queue = build_flow_evidence_queue(_ct_flow_evidence)
    st.subheader('1H-Q. Flow Evidence Qualification / Closed-Session Sampling Guard')
    fe1, fe2, fe3, fe4, fe5, fe6 = st.columns(6)
    fe1.metric('Evidence State', _ct_flow_evidence['evidence_state'])
    fe2.metric('Qualified Endpoints', f"{_ct_flow_evidence['qualified_endpoints']}/{_ct_flow_evidence['min_qualified_endpoints']}")
    fe3.metric('Qualified Intervals', _ct_flow_evidence['qualified_intervals'])
    fe4.metric('Closed Session Dates', _ct_flow_evidence['closed_session_dates'])
    fe5.metric('History Guard', _ct_flow_evidence['calibration_history_guard'])
    fe6.metric('Execution Authorization', 'NONE')
    fee1, fee2, fee3, fee4 = st.columns(4)
    fee1.metric('Raw / Valid Trend', f"{_ct_flow_evidence['raw_trend_snapshots']} / {_ct_flow_evidence['valid_trend_snapshots']}")
    fee2.metric('Same-day Superseded', _ct_flow_evidence['same_day_superseded'])
    fee3.metric('Closed Dates w/o Trend', _ct_flow_evidence['closed_dates_without_trend'])
    fee4.metric('Closed-date Coverage', f"{_ct_flow_evidence['coverage_ratio']:.1%}")
    _fe_boundary_counts = _ct_flow_evidence.get('boundary_status_counts', {})
    feb1, feb2, feb3, feb4 = st.columns(4)
    feb1.metric('Session Pair Issues', _ct_flow_evidence.get('invalid_session_pairs', 0))
    feb2.metric('Post-close Trend Only', _fe_boundary_counts.get('POST_CLOSE_TREND_ONLY', 0))
    feb3.metric('Pre-open Trend Only', _fe_boundary_counts.get('PRE_OPEN_TREND_ONLY', 0))
    feb4.metric('No Same-day Trend', _fe_boundary_counts.get('NO_SAME_DAY_TREND', 0))
    few1, few2, few3, few4, few5 = st.columns(5)
    few1.metric('Lifetime Qualified', _ct_flow_evidence.get('lifetime_qualified_endpoints', _ct_flow_evidence['qualified_endpoints']))
    few2.metric('Consecutive Window', _ct_flow_evidence.get('recent_consecutive_endpoints', _ct_flow_evidence['qualified_endpoints']))
    few3.metric('Capacity Regime', f"{_ct_flow_evidence.get('capacity_regime_endpoints', _ct_flow_evidence['qualified_endpoints'])} @ {_ct_flow_evidence.get('latest_capacity', 0)}")
    few4.metric('Window State', _ct_flow_evidence.get('evidence_window_state', 'LEGACY'))
    few5.metric('Latest Boundary', _ct_flow_evidence.get('latest_boundary_status', 'NONE'))
    _fe_boundary_table = _ct_flow_evidence.get('boundary_table', pd.DataFrame())
    if isinstance(_fe_boundary_table, pd.DataFrame) and (not _fe_boundary_table.empty):
        with st.expander('Closed-Session Boundary Diagnostics', expanded=False):
            st.dataframe(_fe_boundary_table, width='stretch', hide_index=True)
    _fe_state = _ct_flow_evidence['evidence_state']
    if _fe_state == 'INTEGRITY_REVIEW':
        st.error('Flow Evidence integrity 오류가 있어 Calibration history 사용을 차단했습니다.')
    elif _fe_state == 'CLOSED_SESSION_EVIDENCE_REQUIRED':
        st.info('Calibration evidence는 Daily Operations Session CLOSE와 연결된 Trend endpoint부터 계산합니다. 같은 날 Snapshot을 반복 저장해 History를 늘리지 않습니다.')
    elif _fe_state == 'EVIDENCE_MATURING':
        st.info('Qualified Flow evidence가 축적 중입니다. 각 closed-session 날짜의 CLOSE 이전 최신 Trend Snapshot만 1개 endpoint로 계산합니다.')
    else:
        st.success('Flow Evidence READY · closed-session qualified history를 Calibration 입력으로 사용합니다.')
    _fe_window_state = _ct_flow_evidence.get('evidence_window_state', '')
    if _fe_window_state == 'RECENT_SESSION_GAP':
        st.warning('최근 CLOSED Session에 qualified Trend endpoint가 없어 Calibration evidence window를 과거 endpoint로 이어 붙이지 않습니다. 다음 실제 Session에서 새 연속 window를 시작하세요.')
    elif _fe_window_state == 'CAPACITY_REGIME_MATURING':
        st.warning('최근 closed-session evidence는 연속이지만 Capacity regime이 변경되었습니다. 이전 Capacity endpoint는 audit history로만 보존하고 새 Capacity regime에서 Calibration clock을 다시 축적합니다.')
    if _fe_boundary_counts.get('POST_CLOSE_TREND_ONLY', 0) > 0:
        st.warning('현재 closed-session 중 CLOSE 이후에만 Trend Snapshot이 존재하는 구간이 있습니다. 과거 CLOSE 뒤 Snapshot을 소급 evidence로 사용하지 않습니다. 다음 실제 Session에서는 OPEN → Trend Snapshot → CLOSE 순서를 사용하세요.')
    if _fe_boundary_counts.get('PRE_OPEN_TREND_ONLY', 0) > 0:
        st.warning('현재 closed-session 중 OPEN 이전 Snapshot만 존재하는 구간이 있습니다. 해당 Session의 Evidence는 OPEN 이후 저장된 Snapshot부터 인정합니다.')
    if not _ct_flow_evidence['endpoint_table'].empty:
        with st.expander('Qualified Flow Evidence Endpoints', expanded=False):
            st.dataframe(_ct_flow_evidence['endpoint_table'], width='stretch', hide_index=True)
    if not _ct_flow_evidence_queue.empty:
        with st.expander('Flow Evidence Qualification Queue', expanded=False):
            st.dataframe(_ct_flow_evidence_queue, width='stretch', hide_index=True)
    if _ct_latest_flow_evidence:
        _fe_latest_integrity = flow_evidence_snapshot_integrity(_ct_latest_flow_evidence)
        st.caption(f"Latest Evidence Snapshot · {_ct_latest_flow_evidence.get('evidence_snapshot_id', '')} · {_ct_latest_flow_evidence.get('evidence_state', '')} · Integrity {_fe_latest_integrity['status']}")
    _fe_note = st.text_input('Flow Evidence Qualification Snapshot 메모', value='', key='operations_flow_evidence_snapshot_note', placeholder='예: closed-session evidence review / no snapshot spam')
    if st.button('Operations Flow Evidence Qualification Snapshot 저장', key='operations_flow_evidence_snapshot_save'):
        _fe_row = build_flow_evidence_snapshot(_ct_flow_evidence, note=_fe_note)
        _fe_hist = load_csv('operations_flow_evidence_snapshots.csv')
        for _col in FLOW_EVIDENCE_SNAPSHOT_COLS:
            if _col not in _fe_hist.columns:
                _fe_hist[_col] = ''
        _fe_hist = pd.concat([_fe_hist[FLOW_EVIDENCE_SNAPSHOT_COLS], pd.DataFrame([_fe_row])], ignore_index=True)
        verified_save_feedback(_fe_hist, 'operations_flow_evidence_snapshots.csv', f"Flow Evidence Snapshot 저장 · {_fe_row['evidence_state']} · Qualified {_fe_row['qualified_endpoints']} · Execution Authorization = NONE.", rerun=False)
    st.caption('Calibration History는 raw Snapshot 개수가 아니라 closed Daily Operations Session과 연결된 qualified Trend endpoint를 사용합니다. 같은 날 여러 번 저장한 Snapshot은 History를 부풀리지 않습니다.')
    st.caption(f"Closed-session Calibration Interval Guard · Endpoints {_ct_flow_calibration.get('saved_trend_snapshots', 0)} · Closed intervals {_ct_flow_calibration.get('observed_intervals', 0)} · Expected {_ct_flow_evidence.get('qualified_intervals', 0)} · Alignment {_ct_flow_calibration.get('interval_alignment_status', '')} · LIVE interval은 Calibration 평균/Positive Burn Ratio에서 제외됩니다.")
    st.subheader('1H. Flow Trend Calibration / Capacity Efficiency / Projection Guard')
    fc1, fc2, fc3, fc4, fc5 = st.columns(5)
    fc1.metric('Calibration State', _ct_flow_calibration['calibration_state'])
    fc2.metric('Saved Snapshots / Intervals', f"{_ct_flow_calibration['saved_trend_snapshots']} / {_ct_flow_calibration['observed_intervals']}")
    fc3.metric('Positive Burn Ratio', f"{_ct_flow_calibration['positive_burn_ratio']:.1%}")
    fc4.metric('Projection Guard', _ct_flow_calibration['projection_guard'])
    fc5.metric('Execution Authorization', 'NONE')
    fce1, fce2, fce3, fce4 = st.columns(4)
    fce1.metric('Avg Arrival / Exit', f"{_ct_flow_calibration['avg_arrivals_per_interval']:.2f} / {_ct_flow_calibration['avg_exits_per_interval']:.2f}")
    fce2.metric('Exit / Capacity', f"{_ct_flow_calibration['exit_per_capacity']:.2f}x")
    fce3.metric('Attention / Backlog Pressure', f"{_ct_flow_calibration['attention_pressure']:.2f}x / {_ct_flow_calibration['backlog_pressure']:.2f}x")
    fce4.metric('Top Root Cause Share', '-' if not _ct_flow_calibration['top_root_cause'] else f"{_ct_flow_calibration['root_cause_concentration']:.1%}")
    if _ct_flow_calibration['calibration_state'] == 'INSUFFICIENT_HISTORY':
        st.info('Flow Calibration은 아직 History가 부족합니다. 실제 Queue 변화가 생길 때 Trend Snapshot을 추가해 최소 3개의 저장 관측치를 확보하세요.')
    elif _ct_flow_calibration['calibration_state'] == 'INTEGRITY_REVIEW':
        st.error('Trend Snapshot integrity 문제로 Calibration을 사용할 수 없습니다.')
    elif _ct_flow_calibration['projection_guard'] == 'ALLOW_PROJECTION_REVIEW':
        st.success('Projection Guard = ALLOW_PROJECTION_REVIEW · 관측된 Exit-Arrival 흐름이 최소 History/일관성 기준을 통과했습니다. 여전히 운영 Projection일 뿐 보장이 아닙니다.')
    else:
        st.warning(f"Projection Guard = {_ct_flow_calibration['projection_guard']} · 현재 관측으로는 Burn-down Projection을 신뢰하기에 충분하지 않습니다.")
    if _ct_flow_calibration['top_root_cause']:
        st.caption(f"Top Root Cause · {_ct_flow_calibration['top_root_cause']} · Group share {_ct_flow_calibration['root_cause_concentration']:.1%}")
    with st.expander('Calibration Interval 상세', expanded=False):
        _fc_intervals = _ct_flow_calibration['intervals']
        if _fc_intervals.empty:
            st.info('Calibration interval history가 아직 없습니다.')
        else:
            st.dataframe(_fc_intervals, width='stretch', hide_index=True)
    with st.expander('Root Cause Capacity Burden', expanded=False):
        _fc_root = _ct_flow_calibration['root_cause_burden']
        if _fc_root.empty:
            st.info('Root Cause burden 데이터가 없습니다.')
        else:
            st.dataframe(_fc_root, width='stretch', hide_index=True)
    if _ct_latest_flow_calibration:
        _fc_latest_integrity = flow_calibration_snapshot_integrity(_ct_latest_flow_calibration)
        st.caption(f"Latest Calibration Snapshot · {_ct_latest_flow_calibration.get('calibration_snapshot_id', '')} · {_ct_latest_flow_calibration.get('calibration_state', '')} · Integrity {_fc_latest_integrity['status']}")
    _fc_note = st.text_input('Flow Calibration Snapshot 메모', value='', key='operations_flow_calibration_snapshot_note', placeholder='예: history calibration review / no auto projection')
    if st.button('Operations Flow Calibration Snapshot 저장', key='operations_flow_calibration_snapshot_save'):
        _fc_row = build_flow_calibration_snapshot(_ct_flow_calibration, note=_fc_note)
        _fc_hist = load_csv('operations_flow_calibration_snapshots.csv')
        for _col in FLOW_CALIBRATION_SNAPSHOT_COLS:
            if _col not in _fc_hist.columns:
                _fc_hist[_col] = ''
        _fc_hist = pd.concat([_fc_hist[FLOW_CALIBRATION_SNAPSHOT_COLS], pd.DataFrame([_fc_row])], ignore_index=True)
        verified_save_feedback(_fc_hist, 'operations_flow_calibration_snapshots.csv', f"Operations Flow Calibration Snapshot 저장 · {_fc_row['calibration_state']} · Projection {_fc_row['projection_guard']} · Execution Authorization = NONE.", rerun=False)
    st.caption('Calibration은 관측된 운영 Queue 흐름을 검증하는 도구입니다. Projection Guard가 허용되어도 투자 결과나 Review 완료 시점을 보장하지 않습니다.')
    _ct_flow_calibration_promotion_history = load_csv('operations_flow_calibration_promotion_snapshots.csv')
    _ct_latest_flow_calibration_promotion = latest_flow_calibration_promotion_snapshot(_ct_flow_calibration_promotion_history)
    st.subheader('1H-P. Calibration Promotion / Burn Stability / Projection Admission Gate')
    cp1, cp2, cp3, cp4, cp5, cp6 = st.columns(6)
    cp1.metric('Promotion State', _ct_flow_calibration_promotion['promotion_state'])
    cp2.metric('Promotion Intervals', f"{_ct_flow_calibration_promotion['observed_intervals']}/{_ct_flow_calibration_promotion['target_intervals']}")
    cp3.metric('Positive Burn Ratio', f"{_ct_flow_calibration_promotion['positive_burn_ratio']:.1%}")
    cp4.metric('Negative Intervals', _ct_flow_calibration_promotion['negative_burn_intervals'])
    cp5.metric('Effective Guard', _ct_flow_calibration['projection_guard'])
    cp6.metric('Execution Authorization', 'NONE')
    cpd1, cpd2, cpd3, cpd4 = st.columns(4)
    cpd1.metric('Raw Calibration Guard', _ct_flow_calibration_promotion['raw_projection_guard'])
    cpd2.metric('Avg Net Burn', f"{_ct_flow_calibration_promotion['avg_net_burn_per_interval']:.2f}")
    cpd3.metric('Latest Net Burn', f"{_ct_flow_calibration_promotion['latest_net_burn']:.2f}")
    cpd4.metric('Projection Authorization', 'NONE')
    _cp_state = _ct_flow_calibration_promotion['promotion_state']
    if _cp_state == 'PROMOTION_INTEGRITY_REVIEW':
        st.error('Calibration Promotion integrity/alignment 문제가 있어 Projection Admission을 차단했습니다.')
    elif _cp_state == 'PROMOTION_EVIDENCE_MATURING':
        st.info('Calibration Promotion evidence가 아직 충분하지 않습니다. 기본 기준은 같은 Capacity regime의 completed closed-session interval 3개입니다.')
    elif _cp_state == 'PROMOTION_NO_CLEARING':
        st.warning('Promotion window의 평균 Net Burn이 양수가 아니므로 Projection Admission을 열지 않습니다.')
    elif _cp_state in {'PROMOTION_ADVERSE_INTERVAL_REVIEW', 'PROMOTION_MIXED_BURN'}:
        st.warning('평균 Calibration이 양수여도 Promotion window의 adverse/mixed burn 때문에 Projection Admission을 보류합니다.')
    else:
        st.success('Calibration Promotion READY · 최소 closed-session burn stability 기준을 통과했습니다. 이는 Projection Review admission일 뿐 실행 승인이 아닙니다.')
    if not _ct_flow_calibration_promotion_queue.empty:
        with st.expander('Calibration Promotion Review Queue', expanded=False):
            st.dataframe(_ct_flow_calibration_promotion_queue, width='stretch', hide_index=True)
    if _ct_latest_flow_calibration_promotion:
        _cp_latest_integrity = flow_calibration_promotion_snapshot_integrity(_ct_latest_flow_calibration_promotion)
        st.caption(f"Latest Promotion Snapshot · {_ct_latest_flow_calibration_promotion.get('promotion_snapshot_id', '')} · {_ct_latest_flow_calibration_promotion.get('promotion_state', '')} · Integrity {_cp_latest_integrity['status']}")
    _cp_note = st.text_input('Flow Calibration Promotion Snapshot 메모', value='', key='operations_flow_calibration_promotion_snapshot_note', placeholder='예: closed-interval promotion proof / no auto projection')
    if st.button('Operations Flow Calibration Promotion Snapshot 저장', key='operations_flow_calibration_promotion_snapshot_save'):
        _cp_row = build_flow_calibration_promotion_snapshot(_ct_flow_calibration_promotion, note=_cp_note)
        _cp_hist = load_csv('operations_flow_calibration_promotion_snapshots.csv')
        for _col in FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS:
            if _col not in _cp_hist.columns:
                _cp_hist[_col] = ''
        _cp_hist = pd.concat([_cp_hist[FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS], pd.DataFrame([_cp_row])], ignore_index=True)
        verified_save_feedback(_cp_hist, 'operations_flow_calibration_promotion_snapshots.csv', f"Calibration Promotion Snapshot 저장 · {_cp_row['promotion_state']} · Guard {_cp_row['effective_projection_guard']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('v1.31 Promotion Gate는 raw Calibration이 ALLOW여도 closed-session interval proof가 충분하지 않거나 adverse interval이 있으면 Projection을 추가로 HOLD합니다.')
    _ct_flow_projection_admission = build_flow_projection_admission(_ct_flow_calibration, _ct_flow_calibration_promotion, _ct_latest_flow_calibration, _ct_latest_flow_calibration_promotion)
    _ct_flow_projection_admission_queue = build_flow_projection_admission_queue(_ct_flow_projection_admission)
    _ct_flow_projection_admission_history = load_csv('operations_flow_projection_admission_snapshots.csv')
    _ct_latest_projection_admission = latest_flow_projection_admission_snapshot(_ct_flow_projection_admission_history)
    st.subheader('1H-A. Projection Admission Source Lock / Promotion Freshness Guard')
    pa1, pa2, pa3, pa4, pa5, pa6 = st.columns(6)
    pa1.metric('Admission State', _ct_flow_projection_admission['admission_state'])
    pa2.metric('Calibration Source', _ct_flow_projection_admission['calibration_source_freshness'])
    pa3.metric('Promotion Source', _ct_flow_projection_admission['promotion_source_freshness'])
    pa4.metric('Source Order', _ct_flow_projection_admission['source_order_state'])
    pa5.metric('Effective Guard', _ct_flow_projection_admission['effective_projection_guard'])
    pa6.metric('Execution Authorization', 'NONE')
    _pa_state = _ct_flow_projection_admission['admission_state']
    if _pa_state == 'ADMISSION_UPSTREAM_HOLD':
        st.info('Projection Admission은 현재 upstream Promotion/Calibration HOLD를 그대로 유지합니다. 현재 단계에서는 Snapshot을 억지로 저장해 Admission을 열 필요가 없습니다.')
    elif _pa_state == 'ADMISSION_CALIBRATION_SOURCE_REQUIRED':
        st.warning('PROMOTION_READY 이후에는 CURRENT Calibration Snapshot이 필요합니다. 1H에서 Calibration Snapshot을 먼저 저장하세요.')
    elif _pa_state == 'ADMISSION_PROMOTION_SOURCE_REQUIRED':
        st.warning('Calibration Snapshot CURRENT 확인 후 PROMOTION_READY 상태를 Promotion Audit Snapshot으로 저장하세요.')
    elif _pa_state in {'ADMISSION_CALIBRATION_SOURCE_INTEGRITY_REVIEW', 'ADMISSION_CALIBRATION_SOURCE_DRIFT_REVIEW', 'ADMISSION_PROMOTION_SOURCE_INTEGRITY_REVIEW', 'ADMISSION_PROMOTION_SOURCE_DRIFT_REVIEW', 'ADMISSION_PROMOTION_AFTER_CALIBRATION_REQUIRED', 'ADMISSION_SOURCE_TIME_INTEGRITY_REVIEW'}:
        st.warning(f'{_pa_state} · Calibration Snapshot → Promotion Audit Snapshot 순서와 CURRENT/integrity를 확인하세요.')
    else:
        st.success('Projection Admission READY · CURRENT Calibration + CURRENT Promotion Audit + source order가 일치합니다. 이는 Projection Review admission이며 실행 승인이 아닙니다.')
    if not _ct_flow_projection_admission_queue.empty:
        with st.expander('Projection Admission Review Queue', expanded=False):
            st.dataframe(_ct_flow_projection_admission_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_admission:
        _pa_latest_integrity = flow_projection_admission_snapshot_integrity(_ct_latest_projection_admission)
        st.caption(f"Latest Admission Snapshot · {_ct_latest_projection_admission.get('admission_snapshot_id', '')} · {_ct_latest_projection_admission.get('admission_state', '')} · Integrity {_pa_latest_integrity['status']}")
    _pa_note = st.text_input('Flow Projection Admission Snapshot 메모', value='', key='operations_flow_projection_admission_snapshot_note', placeholder='예: calibration + promotion source lock / no auto projection')
    if st.button('Operations Flow Projection Admission Snapshot 저장', key='operations_flow_projection_admission_snapshot_save'):
        _pa_row = build_flow_projection_admission_snapshot(_ct_flow_projection_admission, note=_pa_note)
        _pa_hist = load_csv('operations_flow_projection_admission_snapshots.csv')
        for _col in FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS:
            if _col not in _pa_hist.columns:
                _pa_hist[_col] = ''
        _pa_hist = pd.concat([_pa_hist[FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS], pd.DataFrame([_pa_row])], ignore_index=True)
        verified_save_feedback(_pa_hist, 'operations_flow_projection_admission_snapshots.csv', f"Projection Admission Snapshot 저장 · {_pa_row['admission_state']} · Guard {_pa_row['effective_projection_guard']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('PROMOTION_READY 이후에는 Calibration Snapshot과 Promotion Audit Snapshot이 모두 CURRENT여야 Projection Review admission이 열립니다. 이전 Promotion proof를 새 Calibration에 재사용하지 않습니다.')
    _ct_flow_projection = build_flow_projection(_ct_flow_calibration, _ct_latest_flow_calibration, admission=_ct_flow_projection_admission)
    _ct_flow_projection_queue = build_flow_projection_queue(_ct_flow_projection)
    _ct_flow_projection_history = load_csv('operations_flow_projection_snapshots.csv')
    _ct_latest_flow_projection = latest_flow_projection_snapshot(_ct_flow_projection_history)
    st.subheader('1I. Flow Projection Review / Clearance Scenario / Freshness Guard')
    fp1, fp2, fp3, fp4, fp5 = st.columns(5)
    fp1.metric('Projection State', _ct_flow_projection['projection_state'])
    fp2.metric('Source Freshness', _ct_flow_projection['source_freshness'])
    fp3.metric('Base Clearance', '-' if _ct_flow_projection['base_clearance_intervals'] is None else f"{_ct_flow_projection['base_clearance_intervals']} intervals")
    fp4.metric('Stress Clearance', '-' if _ct_flow_projection['stress_clearance_intervals'] is None else f"{_ct_flow_projection['stress_clearance_intervals']} intervals")
    fp5.metric('Execution Authorization', 'NONE')
    fpd1, fpd2, fpd3, fpd4 = st.columns(4)
    fpd1.metric('Projection Guard', _ct_flow_projection['projection_guard'])
    fpd2.metric('Observed Intervals', _ct_flow_projection['observed_intervals'])
    fpd3.metric('Positive Burn Ratio', f"{_ct_flow_projection['positive_burn_ratio']:.1%}")
    fpd4.metric('Projection Authorization', 'NONE')
    _fp_state = _ct_flow_projection['projection_state']
    if _fp_state == 'SOURCE_CALIBRATION_REQUIRED':
        st.info('Flow Projection은 검증된 Calibration Snapshot을 source로 사용합니다. 1H에서 현재 Calibration Snapshot을 먼저 저장하세요.')
    elif _fp_state == 'SOURCE_CALIBRATION_INTEGRITY_REVIEW':
        st.error('저장된 Calibration Snapshot integrity가 일치하지 않아 Projection을 차단했습니다.')
    elif _fp_state == 'SOURCE_CALIBRATION_DRIFT_REVIEW':
        st.warning('현재 Calibration과 최신 저장 Snapshot이 달라 Projection을 차단했습니다. 현재 상태를 검토한 뒤 새 Calibration Snapshot을 저장하세요.')
        _fp_mismatches = _ct_flow_projection.get('source_mismatches', [])
        if _fp_mismatches:
            st.caption('Drift fields · ' + ', '.join((str(x) for x in _fp_mismatches)))
    elif _fp_state == 'READY_FOR_REVIEW':
        st.success('Projection READY_FOR_REVIEW · 검증된 Calibration source와 현재 상태가 일치합니다. 아래 값은 운영 민감도 시나리오이며 Review 완료 시점이나 투자 결과를 보장하지 않습니다.')
        st.dataframe(_ct_flow_projection['scenario_table'], width='stretch', hide_index=True)
    else:
        st.info(f'Projection {_fp_state} · 현재 Projection Guard를 유지합니다. History/Calibration 조건을 억지로 변경하지 않습니다.')
    if _ct_latest_flow_projection:
        _fp_latest_integrity = flow_projection_snapshot_integrity(_ct_latest_flow_projection)
        st.caption(f"Latest Projection Snapshot · {_ct_latest_flow_projection.get('projection_snapshot_id', '')} · {_ct_latest_flow_projection.get('projection_state', '')} · Integrity {_fp_latest_integrity['status']}")
    _fp_note = st.text_input('Flow Projection Snapshot 메모', value='', key='operations_flow_projection_snapshot_note', placeholder='예: guarded clearance scenario review / no auto capacity action')
    if st.button('Operations Flow Projection Snapshot 저장', key='operations_flow_projection_snapshot_save'):
        if not _ct_flow_projection['snapshot_eligible']:
            st.warning('Projection Snapshot 저장 보류 · CURRENT + integrity OK인 Calibration source가 필요합니다.')
        else:
            _fp_row = build_flow_projection_snapshot(_ct_flow_projection, note=_fp_note)
            _fp_hist = load_csv('operations_flow_projection_snapshots.csv')
            for _col in FLOW_PROJECTION_SNAPSHOT_COLS:
                if _col not in _fp_hist.columns:
                    _fp_hist[_col] = ''
            _fp_hist = pd.concat([_fp_hist[FLOW_PROJECTION_SNAPSHOT_COLS], pd.DataFrame([_fp_row])], ignore_index=True)
            verified_save_feedback(_fp_hist, 'operations_flow_projection_snapshots.csv', f"Operations Flow Projection Snapshot 저장 · {_fp_row['projection_state']} · Source {_fp_row['source_freshness']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Stress/Base/Zero-arrival 값은 운영 민감도 시나리오입니다. 자동 Capacity 확대/축소, Review 완료, 투자 주문 또는 투자 실행 승인을 생성하지 않습니다.')
    _ct_ready_projection_source = latest_ready_flow_projection_snapshot(_ct_flow_projection_history)
    _ct_projection_review_history = load_csv('operations_flow_projection_review_snapshots.csv')
    _ct_projection_review = build_flow_projection_review_context(_ct_flow_projection_history, _ct_projection_review_history)
    _ct_projection_review_queue = build_flow_projection_review_queue(_ct_projection_review)
    st.subheader('1I-R. Projection Human Review Contract / Scenario Lock')
    pr1, pr2, pr3, pr4, pr5, pr6 = st.columns(6)
    pr1.metric('Review State', _ct_projection_review['review_state'])
    pr2.metric('Source Integrity', _ct_projection_review['source_projection_integrity'])
    pr3.metric('Source Current', 'YES' if _ct_projection_review['source_current'] else 'NO')
    pr4.metric('Review Lock', 'LOCKED' if _ct_projection_review['review_locked'] else 'OPEN')
    pr5.metric('Projection Authorization', 'NONE')
    pr6.metric('Execution Authorization', 'NONE')
    _pr_state = _ct_projection_review['review_state']
    if _pr_state == 'PROJECTION_REVIEW_SOURCE_REQUIRED':
        st.info('Human Review Contract는 READY_FOR_REVIEW Projection Snapshot이 생긴 뒤 시작합니다. 현재 HOLD_HISTORY 상태에서는 Review Lock을 만들 필요가 없습니다.')
    elif _pr_state == 'PROJECTION_REVIEW_REQUIRED':
        st.warning('READY Projection source가 있습니다. Scenario semantics와 source lineage를 직접 확인한 뒤 Human Review Lock을 저장해야 Outcome tracking이 시작됩니다.')
    elif _pr_state == 'PROJECTION_REVIEW_SOURCE_SUPERSEDED':
        st.warning('새 READY Projection이 저장되어 기존 Review Lock이 stale 상태가 되었습니다. 새 source를 다시 검토해야 Outcome tracking을 재개할 수 있습니다.')
    elif _pr_state == 'PROJECTION_REVIEW_LOCKED':
        st.success('Projection Human Review LOCKED · 최신 READY Projection과 Review Contract가 일치합니다. 이 Lock은 Outcome tracking의 시작 조건일 뿐 Projection/Capacity/투자 실행 승인이 아닙니다.')
    else:
        st.error(f'{_pr_state} · Projection Review audit/source integrity를 먼저 복구하세요.')
    if not _ct_projection_review_queue.empty:
        with st.expander('Projection Human Review Queue', expanded=False):
            st.dataframe(_ct_projection_review_queue, width='stretch', hide_index=True)
    _pr_can_lock = _pr_state in {'PROJECTION_REVIEW_REQUIRED', 'PROJECTION_REVIEW_SOURCE_SUPERSEDED'}
    if _pr_can_lock:
        _pr_source_confirm = st.checkbox('READY Projection source의 ID/hash lineage와 CURRENT source를 확인했습니다.', key='projection_review_source_lineage_confirm')
        _pr_scenario_confirm = st.checkbox('Stress/Base/Zero-arrival 시나리오가 예측 보장이 아닌 운영 민감도임을 확인했습니다.', key='projection_review_scenario_semantics_confirm')
        _pr_capacity_confirm = st.checkbox('Projection Review Lock이 자동 Capacity 확대/축소를 승인하지 않음을 확인했습니다.', key='projection_review_no_auto_capacity_confirm')
        _pr_execution_confirm = st.checkbox('Projection Review Lock이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='projection_review_no_execution_authorization_confirm')
        _pr_human_confirm = st.checkbox('현재 Projection Scenario를 최종 Human Review했습니다.', key='projection_review_human_confirm')
        _pr_note = st.text_input('Projection Human Review Lock 메모', value='', key='projection_human_review_lock_note', placeholder='예: scenario semantics + source lineage reviewed')
        if st.button('Projection Human Review Lock 저장', key='projection_human_review_lock_save'):
            try:
                _pr_row = build_flow_projection_review_lock(_ct_ready_projection_source, source_lineage_confirmed=_pr_source_confirm, scenario_semantics_confirmed=_pr_scenario_confirm, no_auto_capacity_confirmed=_pr_capacity_confirm, no_execution_authorization_confirmed=_pr_execution_confirm, human_review_confirmed=_pr_human_confirm, note=_pr_note)
                _pr_hist = load_csv('operations_flow_projection_review_snapshots.csv')
                for _col in FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS:
                    if _col not in _pr_hist.columns:
                        _pr_hist[_col] = ''
                _pr_hist = pd.concat([_pr_hist[FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS], pd.DataFrame([_pr_row])], ignore_index=True)
                verified_save_feedback(_pr_hist, 'operations_flow_projection_review_snapshots.csv', f"Projection Human Review Lock 저장 · {_pr_row['source_projection_snapshot_id']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except Exception as _pr_exc:
                st.warning(f'Projection Human Review Lock 저장 보류 · {_pr_exc}')
    if _ct_projection_review.get('latest_review_snapshot_id'):
        st.caption(f"Latest Review Lock · {_ct_projection_review.get('latest_review_snapshot_id', '')} · Integrity {_ct_projection_review.get('latest_review_integrity', '')}")
    st.caption('Outcome tracking은 Human Review Lock이 걸린 최신 READY Projection부터 시작합니다. 새 READY Projection이 저장되면 기존 Lock은 자동으로 superseded되어 재검토가 필요합니다.')
    _ct_ready_projection_source = latest_reviewed_projection_source(_ct_flow_projection_history, _ct_projection_review_history)
    _ct_projection_outcome = build_flow_projection_outcome(_ct_ready_projection_source, _ct_flow_trend_history, min_evaluation_intervals=2, max_evaluation_intervals=20, relative_error_threshold=0.5)
    _ct_guarded_projection_outcome = build_guarded_flow_projection_outcome(_ct_flow_projection_history, _ct_projection_review_history, _ct_flow_trend_history, load_csv('operations_sessions.csv'), min_evaluation_endpoints=2, max_evaluation_endpoints=20, relative_error_threshold=0.5)
    _ct_projection_outcome_evidence = _ct_guarded_projection_outcome['window']
    _ct_projection_outcome = _ct_guarded_projection_outcome['outcome']
    _ct_projection_outcome_evidence_queue = build_flow_projection_outcome_evidence_queue(_ct_projection_outcome_evidence)
    _ct_projection_outcome_evidence_history = load_csv('operations_flow_projection_outcome_evidence_snapshots.csv')
    _ct_latest_projection_outcome_evidence = latest_flow_projection_outcome_evidence_snapshot(_ct_projection_outcome_evidence_history)
    _ct_projection_outcome_queue = build_flow_projection_outcome_queue(_ct_projection_outcome)
    _ct_projection_outcome_history = load_csv('operations_flow_projection_outcome_snapshots.csv')
    _ct_latest_projection_outcome = latest_flow_projection_outcome_snapshot(_ct_projection_outcome_history)
    st.subheader('1I-E. Projection Outcome Evidence / Anti-Hindsight / Closed-Session Guard')
    oe1, oe2, oe3, oe4, oe5, oe6 = st.columns(6)
    oe1.metric('Outcome Evidence', _ct_projection_outcome_evidence['window_state'])
    oe2.metric('Tracking Guard', _ct_projection_outcome_evidence['tracking_guard'])
    oe3.metric('Eligible Endpoints', _ct_projection_outcome_evidence['eligible_endpoints'])
    oe4.metric('Closed Sessions', _ct_projection_outcome_evidence['post_lock_closed_sessions'])
    oe5.metric('Anti-Hindsight', _ct_projection_outcome_evidence['prelock_contamination_count'])
    oe6.metric('Execution Authorization', 'NONE')
    oeg1, oeg2, oeg3, oeg4 = st.columns(4)
    oeg1.metric('Evidence Gaps', _ct_projection_outcome_evidence['closed_session_gap_count'])
    oeg2.metric('Capacity Drift', _ct_projection_outcome_evidence['capacity_drift_endpoints'])
    oeg3.metric('Review Lock', 'LOCKED' if _ct_projection_outcome_evidence['review_state'] == 'PROJECTION_REVIEW_LOCKED' else 'OPEN')
    oeg4.metric('Projection Authorization', 'NONE')
    _oe_state = _ct_projection_outcome_evidence['window_state']
    if _oe_state == 'OUTCOME_REVIEW_SOURCE_REQUIRED':
        st.info('Outcome Evidence는 Human Review LOCKED READY Projection이 생긴 뒤 시작합니다. 현재 HOLD_HISTORY에서는 정상이며 별도 조작이 필요하지 않습니다.')
    elif _oe_state in {'OUTCOME_REVIEW_LOCK_REQUIRED', 'OUTCOME_REVIEW_SOURCE_SUPERSEDED'}:
        st.warning(f'{_oe_state} · 최신 READY Projection에 대한 Human Review Lock이 필요합니다.')
    elif _oe_state in {'OUTCOME_REVIEW_INTEGRITY_REVIEW', 'OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW', 'OUTCOME_EVIDENCE_INTEGRITY_REVIEW'}:
        st.error(f'{_oe_state} · Review/Trend evidence integrity를 먼저 복구해야 합니다.')
    elif _oe_state == 'OUTCOME_ANTI_HINDSIGHT_REVIEW':
        st.error('Projection 생성 후 Human Review Lock 전에 Trend Snapshot이 이미 관측되었습니다. 사후정보가 섞일 수 있으므로 이 Projection의 Outcome 평가를 차단합니다. 새 Projection을 만든 뒤 미래 evidence 전에 Review Lock을 완료하세요.')
    elif _oe_state == 'OUTCOME_EVIDENCE_GAP_REVIEW':
        st.warning('Review Lock 이후 closed-session evidence gap이 있습니다. 누락 구간을 건너뛰어 Model Error를 계산하지 않으며 새 Projection/Review cycle로 rebase해야 합니다.')
    elif _oe_state == 'OUTCOME_WAIT_CLOSED_SESSION':
        st.info('Review Lock 이후 정상 closed-session evidence를 기다리고 있습니다. Session OPEN → Trend Snapshot → CLOSE 순서로 실제 evidence를 축적하세요.')
    elif _oe_state == 'OUTCOME_EVIDENCE_MATURING':
        st.info('Outcome closed-session evidence가 축적 중입니다. 같은 Session Snapshot 반복 저장은 evidence count를 늘리지 않습니다.')
    else:
        st.success('Outcome Evidence READY · Review Lock 이후 연속 closed-session endpoint만 Outcome 평가에 사용합니다.')
    if not _ct_projection_outcome_evidence['endpoint_table'].empty:
        with st.expander('Outcome Eligible Closed-Session Endpoints', expanded=False):
            st.dataframe(_ct_projection_outcome_evidence['endpoint_table'], width='stretch', hide_index=True)
    if not _ct_projection_outcome_evidence_queue.empty:
        with st.expander('Projection Outcome Evidence Queue', expanded=False):
            st.dataframe(_ct_projection_outcome_evidence_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_outcome_evidence:
        _oe_latest_integrity = flow_projection_outcome_evidence_snapshot_integrity(_ct_latest_projection_outcome_evidence)
        st.caption(f"Latest Outcome Evidence Snapshot · {_ct_latest_projection_outcome_evidence.get('outcome_evidence_snapshot_id', '')} · {_ct_latest_projection_outcome_evidence.get('window_state', '')} · Integrity {_oe_latest_integrity['status']}")
    _oe_note = st.text_input('Projection Outcome Evidence Snapshot 메모', value='', key='operations_flow_projection_outcome_evidence_snapshot_note', placeholder='예: post-review closed-session window / no hindsight')
    if st.button('Operations Flow Projection Outcome Evidence Snapshot 저장', key='operations_flow_projection_outcome_evidence_snapshot_save'):
        _oe_row = build_flow_projection_outcome_evidence_snapshot(_ct_projection_outcome_evidence, note=_oe_note)
        _oe_hist = load_csv('operations_flow_projection_outcome_evidence_snapshots.csv')
        for _col in FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS:
            if _col not in _oe_hist.columns:
                _oe_hist[_col] = ''
        _oe_hist = pd.concat([_oe_hist[FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS], pd.DataFrame([_oe_row])], ignore_index=True)
        verified_save_feedback(_oe_hist, 'operations_flow_projection_outcome_evidence_snapshots.csv', f"Projection Outcome Evidence Snapshot 저장 · {_oe_row['window_state']} · Eligible {_oe_row['eligible_endpoints']} · Projection Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Outcome 평가는 Human Review Lock 이후의 closed-session Trend endpoint만 사용합니다. Review 전에 이미 관측된 Trend, session gap, 무결성 오류를 건너뛰어 모델 성능을 계산하지 않습니다.')
    st.subheader('1J. Projection Outcome / Error Attribution / Capacity Decision Governance')
    fo1, fo2, fo3, fo4, fo5, fo6 = st.columns(6)
    fo1.metric('Outcome State', _ct_projection_outcome['evaluation_state'])
    fo2.metric('Evidence Intervals', _ct_projection_outcome['evidence_intervals'])
    _fo_realized = _ct_projection_outcome['realized_avg_net_burn']
    fo3.metric('Realized Burn', '-' if _fo_realized is None else f'{_fo_realized:.2f}/interval')
    fo4.metric('Base Burn', '-' if not _ct_ready_projection_source else f"{_ct_projection_outcome['base_burn_rate']:.2f}/interval")
    _fo_error = _ct_projection_outcome['base_abs_pct_error']
    fo5.metric('Base Abs Error', '-' if _fo_error is None else f'{_fo_error:.1%}')
    fo6.metric('Execution Authorization', 'NONE')
    fod1, fod2, fod3, fod4, fod5 = st.columns(5)
    fod1.metric('Clearance', _ct_projection_outcome['clearance_state'])
    fod2.metric('Recalibration', _ct_projection_outcome['recalibration_state'])
    fod3.metric('Capacity Decision', _ct_projection_outcome['capacity_decision_state'])
    fod4.metric('Capacity Authorization', 'NONE')
    fod5.metric('Projection Authorization', 'NONE')
    _fo_state = _ct_projection_outcome['evaluation_state']
    if _fo_state == 'PROJECTION_SOURCE_REQUIRED':
        st.info('Projection Outcome은 READY_FOR_REVIEW 상태로 저장된 Projection Snapshot부터 추적합니다. 현재 Guard가 HOLD_HISTORY라면 정상이며, History를 인위적으로 만들거나 Guard를 강제로 열지 않습니다.')
    elif _fo_state == 'SOURCE_PROJECTION_INTEGRITY_REVIEW':
        st.error('Outcome source Projection Snapshot integrity가 일치하지 않아 평가를 차단했습니다.')
    elif _fo_state == 'EVIDENCE_INTEGRITY_REVIEW':
        st.error('Projection 이후 Trend evidence 중 integrity 오류가 있어 Outcome 평가를 차단했습니다.')
    elif _fo_state in {'WAIT_EVIDENCE', 'EVIDENCE_MATURING'}:
        st.info('Projection 이후 실제 Flow evidence가 아직 충분하지 않습니다. Queue 변화가 발생할 때 정상 Trend Snapshot을 추가 축적하세요.')
    elif _fo_state == 'ASSUMPTION_DRIFT_REVIEW':
        st.warning('Projection 이후 Capacity assumption이 변경되었습니다. 이를 Model Error로 단정하지 않고 새 Calibration/Projection으로 rebase해야 합니다.')
    elif _fo_state in {'BASE_CLEARANCE_MISS_REVIEW', 'MODEL_BREAK_REVIEW', 'MODEL_ERROR_REVIEW'}:
        st.warning(f'{_fo_state} · 예상 대비 실제 Flow 차이가 커졌습니다. Capacity를 자동 변경하지 말고 먼저 Recalibration과 원인 분해를 수행하세요.')
    elif _fo_state in {'WITHIN_REVIEW_BAND', 'CLEARED_REVIEW'}:
        st.success(f'{_fo_state} · 현재 evidence는 설정된 broad review band 안에 있습니다. 이는 미래 성능 보장이나 Capacity 변경 승인이 아닙니다.')
    _fo_table = _ct_projection_outcome['evidence_table']
    if not _fo_table.empty:
        st.dataframe(_fo_table, width='stretch', hide_index=True)
    if not _ct_projection_outcome_queue.empty:
        with st.expander('Projection Outcome Review Queue', expanded=False):
            st.dataframe(_ct_projection_outcome_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_outcome:
        _fo_latest_integrity = flow_projection_outcome_snapshot_integrity(_ct_latest_projection_outcome)
        st.caption(f"Latest Outcome Snapshot · {_ct_latest_projection_outcome.get('outcome_snapshot_id', '')} · {_ct_latest_projection_outcome.get('evaluation_state', '')} · Integrity {_fo_latest_integrity['status']}")
    _fo_note = st.text_input('Flow Projection Outcome Snapshot 메모', value='', key='operations_flow_projection_outcome_snapshot_note', placeholder='예: post-projection evidence review / no auto capacity action')
    if st.button('Operations Flow Projection Outcome Snapshot 저장', key='operations_flow_projection_outcome_snapshot_save'):
        if not _ct_projection_outcome['snapshot_eligible']:
            st.warning('Outcome Snapshot 저장 보류 · integrity OK인 READY Projection과 1개 이상의 유효 post-projection Trend evidence가 필요합니다.')
        else:
            _fo_row = build_flow_projection_outcome_snapshot(_ct_projection_outcome, note=_fo_note)
            _fo_hist = load_csv('operations_flow_projection_outcome_snapshots.csv')
            for _col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
                if _col not in _fo_hist.columns:
                    _fo_hist[_col] = ''
            _fo_hist = pd.concat([_fo_hist[FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_fo_row])], ignore_index=True)
            verified_save_feedback(_fo_hist, 'operations_flow_projection_outcome_snapshots.csv', f"Projection Outcome Snapshot 저장 · {_fo_row['evaluation_state']} · Evidence {_fo_row['evidence_intervals']} · Capacity Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Outcome Error는 저장 Projection 이후 실제 Trend evidence와의 차이입니다. 오차가 커도 자동 Capacity 변경, 자동 Recalibration, Review 완료, 투자 주문을 생성하지 않습니다.')
    _ct_projection_outcome_history_for_scorecard = load_csv('operations_flow_projection_outcome_snapshots.csv')
    _ct_scorecard_input = build_flow_scorecard_input_qualification(_ct_projection_outcome_history_for_scorecard, load_csv('operations_flow_projection_outcome_evidence_snapshots.csv'), load_csv('operations_flow_projection_review_snapshots.csv'), load_csv('operations_flow_projection_snapshots.csv'))
    _ct_scorecard_input_queue = build_flow_scorecard_input_queue(_ct_scorecard_input)
    _ct_scorecard_input_history = load_csv('operations_flow_scorecard_input_snapshots.csv')
    _ct_latest_scorecard_input = latest_flow_scorecard_input_snapshot(_ct_scorecard_input_history)
    st.subheader('1J-Q. Scorecard Input Qualification / Outcome Evidence Lineage Guard')
    sci1, sci2, sci3, sci4, sci5, sci6 = st.columns(6)
    sci1.metric('Input State', _ct_scorecard_input['qualification_state'])
    sci2.metric('Outcome Records', _ct_scorecard_input['outcome_records_total'])
    sci3.metric('Qualified Outcomes', _ct_scorecard_input['qualified_outcomes'])
    sci4.metric('Unqualified', _ct_scorecard_input['unqualified_outcomes'])
    sci5.metric('Scorecard Guard', _ct_scorecard_input['scorecard_guard'])
    sci6.metric('Execution Authorization', 'NONE')
    scii1, scii2, scii3, scii4 = st.columns(4)
    scii1.metric('Ready Evidence Audits', _ct_scorecard_input['ready_evidence_audits'])
    scii2.metric('Invalid Outcomes', _ct_scorecard_input['invalid_outcome_records'])
    scii3.metric('Lineage Mismatch', _ct_scorecard_input['lineage_mismatch_count'])
    scii4.metric('Duplicate Outcomes', _ct_scorecard_input['duplicate_outcomes'])
    _sci_state = _ct_scorecard_input['qualification_state']
    if _sci_state == 'SCORECARD_INPUT_HISTORY_REQUIRED':
        st.info('Scorecard Proof Clock은 audited Projection Outcome Snapshot부터 시작합니다. 현재 Outcome history가 없으면 정상이며, Outcome Snapshot을 인위적으로 만들지 않습니다.')
    elif _sci_state == 'SCORECARD_INPUT_EVIDENCE_AUDIT_REQUIRED':
        st.warning('Outcome Snapshot은 있으나 matching OUTCOME_EVIDENCE_READY audit이 없습니다. 1I-E Outcome Evidence Audit을 먼저 저장한 뒤 1J Outcome Snapshot을 생성하세요.')
    elif _sci_state in {'SCORECARD_INPUT_INTEGRITY_REVIEW', 'SCORECARD_INPUT_LINEAGE_REVIEW', 'SCORECARD_INPUT_TIME_ORDER_REVIEW', 'SCORECARD_INPUT_UNQUALIFIED_REVIEW'}:
        st.warning(f'{_sci_state} · Scorecard / Proof Clock input을 HOLD합니다. Outcome → Evidence Audit → Review Lock → Projection lineage와 저장 순서를 확인하세요.')
    else:
        st.success('Scorecard Input READY · anti-hindsight / closed-session evidence audit과 lineage가 확인된 Outcome Snapshot만 Proof Clock 입력으로 사용합니다.')
    st.dataframe(_ct_scorecard_input_queue, width='stretch', hide_index=True)
    if _ct_latest_scorecard_input:
        _sci_latest_integrity = flow_scorecard_input_snapshot_integrity(_ct_latest_scorecard_input)
        st.caption(f"Latest Scorecard Input Snapshot · {_ct_latest_scorecard_input.get('scorecard_input_snapshot_id', '')} · {_ct_latest_scorecard_input.get('qualification_state', '')} · Integrity {_sci_latest_integrity['status']}")
    _sci_note = st.text_input('Scorecard Input Qualification Snapshot 메모', value='', key='operations_flow_scorecard_input_snapshot_note', placeholder='예: audited outcome lineage / no proof-clock inflation')
    if st.button('Operations Flow Scorecard Input Qualification Snapshot 저장', key='operations_flow_scorecard_input_snapshot_save'):
        _sci_row = build_flow_scorecard_input_snapshot(_ct_scorecard_input, note=_sci_note)
        _sci_hist = load_csv('operations_flow_scorecard_input_snapshots.csv')
        for _col in FLOW_SCORECARD_INPUT_SNAPSHOT_COLS:
            if _col not in _sci_hist.columns:
                _sci_hist[_col] = ''
        _sci_hist = pd.concat([_sci_hist[FLOW_SCORECARD_INPUT_SNAPSHOT_COLS], pd.DataFrame([_sci_row])], ignore_index=True)
        verified_save_feedback(_sci_hist, 'operations_flow_scorecard_input_snapshots.csv', f"Scorecard Input Snapshot 저장 · {_sci_row['qualification_state']} · Qualified {_sci_row['qualified_outcomes']} · Capacity Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Scorecard는 Outcome Snapshot 개수가 아니라, 저장된 OUTCOME_EVIDENCE_READY audit 이후 생성되고 Review/Projection/Trend lineage가 확인된 Outcome만 사용합니다. legacy/unqualified Outcome은 Proof Clock을 늘리지 않습니다.')
    _ct_projection_outcome_history_for_scorecard = _ct_scorecard_input['qualified_outcome_history']
    _ct_projection_scorecard = build_flow_projection_scorecard(_ct_projection_outcome_history_for_scorecard, min_outcome_evidence_intervals=2, proof_clock_target=3, broad_error_threshold=0.5, override_review_ttl_intervals=2)
    _ct_projection_scorecard_queue = build_flow_projection_scorecard_queue(_ct_projection_scorecard)
    _ct_projection_scorecard_history = load_csv('operations_flow_projection_scorecard_snapshots.csv')
    _ct_latest_projection_scorecard = latest_flow_projection_scorecard_snapshot(_ct_projection_scorecard_history)
    st.subheader('1K. Projection Scorecard / Recalibration Proof Clock / Capacity Override Gate')
    fs1, fs2, fs3, fs4, fs5, fs6 = st.columns(6)
    fs1.metric('Scorecard State', _ct_projection_scorecard['scorecard_state'])
    fs2.metric('Error Regime', _ct_projection_scorecard['error_regime'])
    fs3.metric('Proof Clock', f"{_ct_projection_scorecard['proof_clock_count']}/{_ct_projection_scorecard['proof_clock_target']}")
    fs4.metric('Override Review Gate', _ct_projection_scorecard['capacity_override_review_gate'])
    fs5.metric('Override Approval', _ct_projection_scorecard['override_review_approval_state'])
    fs6.metric('Execution Authorization', 'NONE')
    fss1, fss2, fss3, fss4, fss5 = st.columns(5)
    fss1.metric('Unique Evidence', _ct_projection_scorecard['unique_evidence_endpoints'])
    _fsc_avg_err = _ct_projection_scorecard['avg_abs_pct_error']
    fss2.metric('Avg Abs Error', '-' if _fsc_avg_err is None else f'{_fsc_avg_err:.1%}')
    _fsc_latest_err = _ct_projection_scorecard['latest_abs_pct_error']
    fss3.metric('Latest Abs Error', '-' if _fsc_latest_err is None else f'{_fsc_latest_err:.1%}')
    fss4.metric('Capacity Override Authorization', 'NONE')
    fss5.metric('Projection Authorization', 'NONE')
    _fsc_state = _ct_projection_scorecard['scorecard_state']
    _fsc_gate = _ct_projection_scorecard['capacity_override_review_gate']
    if _fsc_state == 'SCORECARD_HISTORY_REQUIRED':
        st.info('Scorecard는 저장된 Projection Outcome Snapshot부터 시작합니다. 현재 HOLD_HISTORY / Projection source 없음 상태라면 정상입니다. 중복 저장이나 임의 History 생성으로 Proof Clock을 늘리지 않습니다.')
    elif _fsc_state == 'OUTCOME_INTEGRITY_REVIEW':
        st.error('Outcome Snapshot integrity 오류가 있어 Scorecard / Override 검토를 차단했습니다.')
    elif _fsc_state == 'SCORECARD_EVIDENCE_MATURING':
        st.info('Scorecard evidence가 아직 성숙하지 않았습니다. 새로운 실제 evidence endpoint가 생성될 때만 Proof Clock을 평가합니다.')
    elif _fsc_state == 'REBASE_REQUIRED':
        st.warning('Capacity assumption drift가 확인되어 기존 Projection의 Model Error로 단정할 수 없습니다. 새 Calibration/Projection으로 rebase한 뒤 Proof Clock을 다시 시작합니다.')
    elif _fsc_state == 'RECALIBRATION_PROOF_MATURING':
        st.warning('Recalibration 반대가설을 검토할 Evidence가 축적 중입니다. Proof Clock은 고유 evidence endpoint만 계산합니다.')
    elif _fsc_state == 'RECALIBRATION_PROOF_MET':
        st.warning('Recalibration Proof Clock이 기준에 도달했습니다. 이는 Capacity 변경 승인이 아니라 Model/Parameter/Execution/Exogenous 원인 분해를 시작할 조건입니다.')
    else:
        st.success('현재 Scorecard는 Monitor 상태입니다. 추가 evidence를 축적하며 자동 Capacity 변경은 하지 않습니다.')
    if _fsc_gate == 'OPEN_FOR_HUMAN_REVIEW':
        st.warning(f"Capacity Override Review Gate가 Human Review에 열렸습니다. 승인 필요 · evidence {_ct_projection_scorecard['override_review_expires_after_evidence']} 이후에는 재검토가 필요합니다. Capacity Override Authorization은 여전히 NONE입니다.")
    _fsc_table = _ct_projection_scorecard['scorecard_table']
    if not _fsc_table.empty:
        with st.expander('Projection Scorecard Evidence', expanded=False):
            st.dataframe(_fsc_table, width='stretch', hide_index=True)
    if not _ct_projection_scorecard_queue.empty:
        with st.expander('Projection Scorecard / Override Review Queue', expanded=False):
            st.dataframe(_ct_projection_scorecard_queue, width='stretch', hide_index=True)
    if _ct_latest_projection_scorecard:
        _fsc_latest_integrity = flow_projection_scorecard_snapshot_integrity(_ct_latest_projection_scorecard)
        st.caption(f"Latest Scorecard Snapshot · {_ct_latest_projection_scorecard.get('scorecard_snapshot_id', '')} · {_ct_latest_projection_scorecard.get('scorecard_state', '')} · Integrity {_fsc_latest_integrity['status']}")
    _fsc_note = st.text_input('Flow Projection Scorecard Snapshot 메모', value='', key='operations_flow_projection_scorecard_snapshot_note', placeholder='예: proof clock review / no capacity override authorization')
    if st.button('Operations Flow Projection Scorecard Snapshot 저장', key='operations_flow_projection_scorecard_snapshot_save'):
        if not _ct_projection_scorecard['snapshot_eligible']:
            st.warning('Scorecard Snapshot 저장 보류 · integrity OK인 Outcome Snapshot history가 필요합니다.')
        else:
            _fsc_row = build_flow_projection_scorecard_snapshot(_ct_projection_scorecard, note=_fsc_note)
            _fsc_hist = load_csv('operations_flow_projection_scorecard_snapshots.csv')
            for _col in FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS:
                if _col not in _fsc_hist.columns:
                    _fsc_hist[_col] = ''
            _fsc_hist = pd.concat([_fsc_hist[FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS], pd.DataFrame([_fsc_row])], ignore_index=True)
            verified_save_feedback(_fsc_hist, 'operations_flow_projection_scorecard_snapshots.csv', f"Projection Scorecard Snapshot 저장 · {_fsc_row['scorecard_state']} · Proof {_fsc_row['proof_clock_count']}/{_fsc_row['proof_clock_target']} · Capacity Override Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Proof Clock은 같은 evidence endpoint를 중복 저장해도 증가하지 않습니다. Override Review Gate가 열려도 Human approval/expiry/recalibration 검토가 필요하며 Capacity Override Authorization과 투자 실행 승인은 자동 생성되지 않습니다.')
    _ct_recalibration_review_history = load_csv('operations_flow_recalibration_review_snapshots.csv')
    _ct_recalibration_review = build_flow_recalibration_review(_ct_projection_scorecard, _ct_latest_projection_scorecard, _ct_recalibration_review_history)
    _ct_recalibration_review_queue = build_flow_recalibration_review_queue(_ct_recalibration_review)
    st.subheader('1K-R. Recalibration Error Attribution / Human Review Contract')
    rr1, rr2, rr3, rr4, rr5, rr6 = st.columns(6)
    rr1.metric('Recalibration State', _ct_recalibration_review['review_state'])
    rr2.metric('Scorecard Source', _ct_recalibration_review['source_scorecard_freshness'])
    rr3.metric('Error Regime', _ct_recalibration_review['error_regime'] or '-')
    rr4.metric('Proof Clock', f"{_ct_recalibration_review['proof_clock_count']}/{_ct_recalibration_review['proof_clock_target']}")
    rr5.metric('Review Guard', _ct_recalibration_review['review_guard'])
    rr6.metric('Execution Authorization', 'NONE')
    _rr_state = _ct_recalibration_review['review_state']
    if _rr_state == 'RECALIBRATION_UPSTREAM_WAIT':
        st.info('Recalibration Review는 qualified Outcome과 Proof Clock이 충분히 쌓인 뒤 시작합니다. 현재 단계에서는 Scorecard Snapshot이나 attribution contract를 억지로 만들 필요가 없습니다.')
    elif _rr_state == 'RECALIBRATION_NOT_REQUIRED':
        st.success('현재 Scorecard는 MONITOR 상태입니다. 자동 Recalibration 없이 추가 evidence를 관찰합니다.')
    elif _rr_state == 'RECALIBRATION_REBASE_FIRST':
        st.warning('Capacity assumption drift가 먼저 확인되었습니다. Model Error로 단정하지 말고 새 Calibration/Projection으로 rebase한 뒤 새 evidence clock을 시작하세요.')
    elif _rr_state == 'RECALIBRATION_PROOF_MATURING':
        st.info('Recalibration Proof Clock이 아직 성숙 중입니다. 같은 endpoint의 중복 저장으로 Clock을 늘리지 않습니다.')
    elif _rr_state == 'RECALIBRATION_SCORECARD_SOURCE_REQUIRED':
        st.warning('Proof Clock이 기준에 도달했습니다. 원인 분해 전 1K에서 현재 Scorecard Snapshot을 저장하세요.')
    elif _rr_state in {'RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW', 'RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW', 'RECALIBRATION_CONTRACT_INTEGRITY_REVIEW'}:
        st.error(f'{_rr_state} · Scorecard / Recalibration Review audit source를 먼저 복구해야 합니다.')
    elif _rr_state == 'RECALIBRATION_CONTRACT_SUPERSEDED':
        st.warning('새 Scorecard source가 생성되어 이전 Recalibration Contract가 superseded되었습니다. 새 Scorecard 기준으로 원인 분해를 다시 검토하세요.')
    elif _rr_state == 'RECALIBRATION_CONTRACT_LOCKED':
        _rr_contract = _ct_recalibration_review.get('latest_contract') or {}
        st.success(f"Recalibration Contract LOCKED · Primary {_rr_contract.get('primary_attribution', '')} · 자동 parameter 변경/Capacity 변경/투자 실행 승인은 생성되지 않았습니다.")
    else:
        st.warning('Recalibration Proof가 기준에 도달했습니다. Model / Parameter / Execution / Exogenous 원인을 독립적으로 검토한 뒤 Human Contract를 저장하세요.')
    if not _ct_recalibration_review_queue.empty:
        with st.expander('Recalibration Review Queue', expanded=False):
            st.dataframe(_ct_recalibration_review_queue, width='stretch', hide_index=True)
    if _rr_state == 'RECALIBRATION_ATTRIBUTION_REQUIRED':
        _rr_primary = st.selectbox('Primary Error Attribution', ['MODEL', 'PARAMETER', 'EXECUTION', 'EXOGENOUS'], key='flow_recalibration_primary_attribution')
        _rr_secondary = st.selectbox('Secondary Error Attribution (선택)', ['', 'MODEL', 'PARAMETER', 'EXECUTION', 'EXOGENOUS'], key='flow_recalibration_secondary_attribution')
        _rr_detail = st.text_area('Attribution 근거', value='', key='flow_recalibration_attribution_detail', placeholder='예: persistent optimistic bias가 parameter misspecification인지 execution effect인지 구분한 근거')
        rrc1, rrc2 = st.columns(2)
        with rrc1:
            _rr_source_confirm = st.checkbox('현재 Scorecard source ID/hash/CURRENT를 직접 확인했습니다.', key='flow_recalibration_source_confirmed')
            _rr_alt_confirm = st.checkbox('Model / Parameter / Execution / Exogenous 반대 원인을 모두 검토했습니다.', key='flow_recalibration_alternatives_reviewed')
            _rr_no_auto_recal = st.checkbox('이 Contract가 자동 Recalibration이나 parameter 변경을 승인하지 않음을 확인했습니다.', key='flow_recalibration_no_auto_recalibration')
        with rrc2:
            _rr_no_capacity = st.checkbox('원인 attribution만으로 Capacity를 자동 확대/축소하지 않음을 확인했습니다.', key='flow_recalibration_no_auto_capacity')
            _rr_no_exec = st.checkbox('투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='flow_recalibration_no_execution')
            _rr_human = st.checkbox('현재 Recalibration 원인 분해를 최종 Human Review했습니다.', key='flow_recalibration_human_review')
        _rr_note = st.text_input('Recalibration Review 메모', value='', key='flow_recalibration_review_note', placeholder='예: root-cause attribution locked / no automatic model change')
        if st.button('Recalibration Human Review Contract 저장', key='flow_recalibration_review_save'):
            try:
                _rr_row = build_flow_recalibration_review_lock(_ct_recalibration_review, primary_attribution=_rr_primary, secondary_attribution=_rr_secondary, attribution_detail=_rr_detail, source_review_confirmed=_rr_source_confirm, alternatives_reviewed=_rr_alt_confirm, no_auto_recalibration_confirmed=_rr_no_auto_recal, no_auto_capacity_confirmed=_rr_no_capacity, no_execution_authorization_confirmed=_rr_no_exec, human_review_confirmed=_rr_human, note=_rr_note)
                _rr_hist = load_csv('operations_flow_recalibration_review_snapshots.csv')
                for _col in FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS:
                    if _col not in _rr_hist.columns:
                        _rr_hist[_col] = ''
                _rr_hist = pd.concat([_rr_hist[FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS], pd.DataFrame([_rr_row])], ignore_index=True)
                verified_save_feedback(_rr_hist, 'operations_flow_recalibration_review_snapshots.csv', f"Recalibration Contract 저장 · {_rr_row['primary_attribution']} · Recalibration Authorization = NONE · Capacity Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Forecast Error는 Model / Parameter / Execution / Exogenous로 분해합니다. Contract는 원인 attribution을 잠글 뿐 자동 model change, Capacity change, 투자 실행을 승인하지 않습니다.')
    _ct_recalibration_proposal_history = load_csv('operations_flow_recalibration_proposal_snapshots.csv')
    _ct_recalibration_proposal = build_flow_recalibration_proposal(_ct_recalibration_review, _ct_latest_projection_scorecard, _ct_recalibration_proposal_history, max_parameter_delta_pct=0.5)
    _ct_recalibration_proposal_queue = build_flow_recalibration_proposal_queue(_ct_recalibration_proposal)
    _ct_latest_recalibration_proposal = latest_recalibration_proposal_snapshot(_ct_recalibration_proposal_history)
    st.subheader('1K-P. Recalibration Proposal / Change Scope / No-Apply Guard')
    rp1, rp2, rp3, rp4, rp5, rp6 = st.columns(6)
    rp1.metric('Proposal State', _ct_recalibration_proposal['proposal_state'])
    rp2.metric('Primary Attribution', _ct_recalibration_proposal['primary_attribution'] or '-')
    rp3.metric('Proposal Scope', _ct_recalibration_proposal['proposal_scope'] or '-')
    rp4.metric('Proposal Guard', _ct_recalibration_proposal['proposal_guard'])
    rp5.metric('Recalibration Authorization', 'NONE')
    rp6.metric('Execution Authorization', 'NONE')
    _rp_state = _ct_recalibration_proposal['proposal_state']
    if _rp_state == 'RECALIBRATION_PROPOSAL_UPSTREAM_WAIT':
        st.info('Recalibration Proposal은 Proof Clock과 Human Attribution Contract가 잠긴 뒤 시작합니다. 현재 단계에서는 Proposal을 억지로 만들 필요가 없습니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_NOT_REQUIRED':
        st.success('현재 Recalibration Proposal이 필요하지 않습니다. live model/parameter를 변경하지 않고 evidence를 계속 관찰합니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_REBASE_FIRST':
        st.warning('Capacity assumption drift가 우선입니다. Model/Parameter proposal보다 새 Calibration/Projection rebase가 먼저입니다.')
    elif _rp_state == 'RECALIBRATION_EXECUTION_REMEDIATION_ONLY':
        st.warning('Primary attribution이 EXECUTION입니다. Model/Parameter 변경 제안 대신 execution process remediation을 검토하세요.')
    elif _rp_state == 'RECALIBRATION_EXOGENOUS_OBSERVE_ONLY':
        st.info('Primary attribution이 EXOGENOUS입니다. Model/Parameter 변경보다 regime normalization과 추가 evidence를 관찰합니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW':
        st.error('Recalibration Contract / Scorecard / Proposal audit integrity가 일치하지 않아 Proposal을 차단했습니다.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_SUPERSEDED':
        st.warning('새 Recalibration Contract가 생성되어 이전 Proposal이 superseded되었습니다. 현재 Contract 기준으로 다시 검토하세요.')
    elif _rp_state == 'RECALIBRATION_PROPOSAL_LOCKED':
        _rp_locked = _ct_recalibration_proposal.get('latest_proposal') or {}
        st.success(f"Shadow-only Recalibration Proposal LOCKED · {_rp_locked.get('proposal_scope', '')} · live model/parameter change, Capacity change, 투자 실행 승인은 생성되지 않았습니다.")
    elif _rp_state == 'RECALIBRATION_PARAMETER_DELTA_REQUIRED':
        st.warning(f"PARAMETER attribution · 현재 BASE_BURN_RATE {_ct_recalibration_proposal['current_value']:.4f}. live 값을 바꾸지 않는 bounded shadow proposal만 허용됩니다.")
    else:
        st.warning('MODEL attribution · live model을 직접 변경하지 않고 shadow model specification proposal을 먼저 잠급니다.')
    if not _ct_recalibration_proposal_queue.empty:
        with st.expander('Recalibration Proposal Queue', expanded=False):
            st.dataframe(_ct_recalibration_proposal_queue, width='stretch', hide_index=True)
    if _ct_latest_recalibration_proposal:
        _rp_latest_integrity = recalibration_proposal_snapshot_integrity(_ct_latest_recalibration_proposal)
        st.caption(f"Latest Proposal · {_ct_latest_recalibration_proposal.get('recalibration_proposal_id', '')} · {_ct_latest_recalibration_proposal.get('proposal_scope', '')} · Integrity {_rp_latest_integrity['status']}")
    if _rp_state in {'RECALIBRATION_PARAMETER_DELTA_REQUIRED', 'RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED'}:
        if _rp_state == 'RECALIBRATION_PARAMETER_DELTA_REQUIRED':
            _rp_proposed_value = st.number_input('Shadow Proposed BASE_BURN_RATE', min_value=0.0001, value=max(0.0001, float(_ct_recalibration_proposal['current_value'])), step=0.01, key='flow_recalibration_proposal_value')
        else:
            _rp_proposed_value = None
        _rp_detail = st.text_area('Recalibration Proposal 근거', value='', key='flow_recalibration_proposal_detail', placeholder='예: shadow-only parameter/model specification proposal · live parameter에는 적용하지 않고 다음 validation 단계에서만 검증')
        rpc1, rpc2 = st.columns(2)
        with rpc1:
            _rp_shadow = st.checkbox('이 Proposal은 shadow-only이며 live model에 적용되지 않음을 확인했습니다.', key='flow_recalibration_proposal_shadow_only')
            _rp_no_live = st.checkbox('이 Proposal이 live model/parameter를 자동 변경하지 않음을 확인했습니다.', key='flow_recalibration_proposal_no_live_change')
            _rp_no_capacity = st.checkbox('이 Proposal만으로 Capacity를 자동 확대/축소하지 않음을 확인했습니다.', key='flow_recalibration_proposal_no_capacity')
        with rpc2:
            _rp_no_exec = st.checkbox('투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='flow_recalibration_proposal_no_execution')
            _rp_human = st.checkbox('현재 Proposal scope/value/rationale을 최종 Human Review했습니다.', key='flow_recalibration_proposal_human_review')
        _rp_note = st.text_input('Recalibration Proposal 메모', value='', key='flow_recalibration_proposal_note', placeholder='예: shadow proposal locked / no live apply')
        if st.button('Recalibration Shadow Proposal 저장', key='flow_recalibration_proposal_save'):
            try:
                _rp_row = build_flow_recalibration_proposal_lock(_ct_recalibration_proposal, proposed_value=_rp_proposed_value, proposal_detail=_rp_detail, shadow_only_confirmed=_rp_shadow, no_live_parameter_change_confirmed=_rp_no_live, no_auto_capacity_confirmed=_rp_no_capacity, no_execution_authorization_confirmed=_rp_no_exec, human_review_confirmed=_rp_human, note=_rp_note)
                _rp_hist = load_csv('operations_flow_recalibration_proposal_snapshots.csv')
                for _col in FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS:
                    if _col not in _rp_hist.columns:
                        _rp_hist[_col] = ''
                _rp_hist = pd.concat([_rp_hist[FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS], pd.DataFrame([_rp_row])], ignore_index=True)
                verified_save_feedback(_rp_hist, 'operations_flow_recalibration_proposal_snapshots.csv', f"Recalibration Shadow Proposal 저장 · {_rp_row['proposal_scope']} · Proposal Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Recalibration Proposal은 attribution을 실제 변경안으로 바로 적용하지 않습니다. MODEL/PARAMETER는 shadow-only proposal로 잠그고, EXECUTION/EXOGENOUS는 model change를 허용하지 않습니다.')
    _ct_shadow_validation_plan_history = load_csv('operations_flow_shadow_validation_plan_snapshots.csv')
    _ct_shadow_validation_plan = build_flow_shadow_validation_plan(_ct_recalibration_proposal, _ct_shadow_validation_plan_history, default_min_future_outcomes=3, default_min_future_closed_intervals=2, default_min_relative_error_improvement_pct=0.15, default_max_relative_error_degradation_pct=0.1)
    _ct_shadow_validation_plan_queue = build_flow_shadow_validation_plan_queue(_ct_shadow_validation_plan)
    _ct_latest_shadow_validation_plan = latest_shadow_validation_plan_snapshot(_ct_shadow_validation_plan_history)
    st.subheader('1K-S. Shadow Validation Preregistration / Out-of-Sample No-Apply Guard')
    sv1, sv2, sv3, sv4, sv5, sv6 = st.columns(6)
    sv1.metric('Validation State', _ct_shadow_validation_plan['plan_state'])
    sv2.metric('Proposal Scope', _ct_shadow_validation_plan['proposal_scope'] or '-')
    sv3.metric('Evaluation Metric', _ct_shadow_validation_plan['evaluation_metric'] or '-')
    sv4.metric('Future Outcomes', _ct_shadow_validation_plan['min_future_outcomes'])
    sv5.metric('Plan Guard', _ct_shadow_validation_plan['plan_guard'])
    sv6.metric('Execution Authorization', 'NONE')
    _sv_state = _ct_shadow_validation_plan['plan_state']
    if _sv_state == 'SHADOW_VALIDATION_UPSTREAM_WAIT':
        st.info('Shadow Validation Plan은 LOCKED Recalibration Proposal이 생긴 뒤 시작합니다. 현재 단계에서는 Plan을 억지로 만들 필요가 없습니다.')
    elif _sv_state == 'SHADOW_VALIDATION_NOT_REQUIRED':
        st.success('현재 attribution은 shadow model/parameter validation이 필요하지 않습니다. live model/parameter는 변경하지 않고 evidence를 계속 관찰합니다.')
    elif _sv_state == 'SHADOW_VALIDATION_PROPOSAL_REQUIRED':
        st.info('MODEL/PARAMETER Proposal이 아직 LOCKED되지 않았습니다. Validation criteria를 정하기 전에 shadow-only Proposal Human Review를 완료하세요.')
    elif _sv_state == 'SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW':
        st.error('Recalibration Proposal 또는 Shadow Validation Plan audit integrity가 일치하지 않아 validation을 차단했습니다.')
    elif _sv_state == 'SHADOW_VALIDATION_PLAN_SUPERSEDED':
        st.warning('새 Recalibration Proposal이 생성되어 기존 Validation Plan이 superseded되었습니다. 현재 Proposal 기준으로 success/failure 기준을 다시 사전등록하세요.')
    elif _sv_state == 'SHADOW_VALIDATION_PLAN_LOCKED':
        _sv_locked = _ct_shadow_validation_plan.get('latest_plan') or {}
        st.success(f"Shadow Validation Plan LOCKED · future outcomes {_sv_locked.get('min_future_outcomes', 0)} · min improvement {float(_sv_locked.get('min_relative_error_improvement_pct', 0)):.0%} · live apply 없음.")
    else:
        st.warning('Shadow Validation Plan이 필요합니다. 미래 evidence가 생기기 전에 success/failure 기준을 먼저 잠그세요.')
    st.dataframe(_ct_shadow_validation_plan_queue, width='stretch', hide_index=True)
    if _ct_latest_shadow_validation_plan:
        _sv_latest_integrity = shadow_validation_plan_snapshot_integrity(_ct_latest_shadow_validation_plan)
        st.caption(f"Latest Shadow Validation Plan · {_ct_latest_shadow_validation_plan.get('shadow_validation_plan_id', '')} · {_ct_latest_shadow_validation_plan.get('plan_state', '')} · Integrity {_sv_latest_integrity['status']}")
    if _sv_state == 'SHADOW_VALIDATION_PLAN_REQUIRED':
        _sv_min_outcomes = st.number_input('Shadow Validation 최소 미래 qualified Outcome', min_value=3, max_value=20, value=3, step=1, key='shadow_validation_min_future_outcomes')
        _sv_min_intervals = st.number_input('Shadow Validation 최소 미래 closed-session interval', min_value=2, max_value=20, value=2, step=1, key='shadow_validation_min_future_intervals')
        _sv_min_improvement = st.number_input('최소 상대 Error 개선율', min_value=0.0, max_value=0.5, value=0.15, step=0.05, format='%.2f', key='shadow_validation_min_improvement')
        _sv_max_degradation = st.number_input('허용 상대 Error 악화율', min_value=0.0, max_value=0.25, value=0.1, step=0.05, format='%.2f', key='shadow_validation_max_degradation')
        _sv_detail = st.text_area('Shadow Validation Plan detail', value='', key='shadow_validation_plan_detail', placeholder='예: future closed-session qualified Outcome만 사용하고 baseline 대비 error reduction을 out-of-sample로 검증')
        _sv_c1 = st.checkbox('미래 evidence를 보기 전에 success/failure 기준을 사전등록했음을 확인', key='shadow_validation_preregistration_confirmed')
        _sv_c2 = st.checkbox('이 Plan은 shadow-only이며 live model/parameter에 적용하지 않음을 확인', key='shadow_validation_shadow_only_confirmed')
        _sv_c3 = st.checkbox('Validation 결과가 나와도 자동 live apply가 없음을 확인', key='shadow_validation_no_live_apply_confirmed')
        _sv_c4 = st.checkbox('이 Plan이 자동 Capacity 변경을 승인하지 않음을 확인', key='shadow_validation_no_capacity_confirmed')
        _sv_c5 = st.checkbox('이 Plan이 투자 실행/주문 권한을 생성하지 않음을 확인', key='shadow_validation_no_execution_confirmed')
        _sv_c6 = st.checkbox('현재 Validation Plan을 최종 Human Review했음을 확인', key='shadow_validation_human_review_confirmed')
        _sv_note = st.text_input('Shadow Validation Plan Snapshot 메모', value='', key='shadow_validation_plan_note', placeholder='예: preregistered OOS validation / no live apply')
        if st.button('Operations Flow Shadow Validation Plan 저장', key='shadow_validation_plan_save'):
            try:
                _sv_row = build_flow_shadow_validation_plan_lock(_ct_shadow_validation_plan, plan_detail=_sv_detail, min_future_outcomes=int(_sv_min_outcomes), min_future_closed_intervals=int(_sv_min_intervals), min_relative_error_improvement_pct=float(_sv_min_improvement), max_relative_error_degradation_pct=float(_sv_max_degradation), require_same_capacity=True, require_no_assumption_drift=True, preregistration_confirmed=_sv_c1, shadow_only_confirmed=_sv_c2, no_live_apply_confirmed=_sv_c3, no_auto_capacity_confirmed=_sv_c4, no_execution_authorization_confirmed=_sv_c5, human_review_confirmed=_sv_c6, note=_sv_note)
                _sv_hist = load_csv('operations_flow_shadow_validation_plan_snapshots.csv')
                for _col in FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS:
                    if _col not in _sv_hist.columns:
                        _sv_hist[_col] = ''
                _sv_hist = pd.concat([_sv_hist[FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS], pd.DataFrame([_sv_row])], ignore_index=True)
                verified_save_feedback(_sv_hist, 'operations_flow_shadow_validation_plan_snapshots.csv', f"Shadow Validation Plan 저장 · {_sv_row['proposal_scope']} · future outcomes {_sv_row['min_future_outcomes']} · Plan Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Shadow Validation Plan은 Proposal이 LOCKED된 뒤 미래 evidence를 보기 전에 success/failure 기준을 사전등록합니다. Plan LOCKED는 live model/parameter apply 승인이 아닙니다.')
    _ct_shadow_validation_outcome = build_flow_shadow_validation_outcome(_ct_shadow_validation_plan, _ct_recalibration_proposal, _ct_projection_scorecard_history, _ct_scorecard_input['qualified_outcome_history'])
    _ct_shadow_validation_outcome_queue = build_flow_shadow_validation_outcome_queue(_ct_shadow_validation_outcome)
    _ct_shadow_validation_outcome_history = load_csv('operations_flow_shadow_validation_outcome_snapshots.csv')
    _ct_latest_shadow_validation_outcome = latest_shadow_validation_outcome_snapshot(_ct_shadow_validation_outcome_history)
    st.subheader('1K-V. Shadow Validation Outcome / Out-of-Sample Evidence / No-Promotion Guard')
    svo1, svo2, svo3, svo4, svo5, svo6 = st.columns(6)
    svo1.metric('Evaluation State', _ct_shadow_validation_outcome['validation_state'])
    svo2.metric('Scope', _ct_shadow_validation_outcome['proposal_scope'] or '-')
    svo3.metric('Eligible Outcomes', f"{_ct_shadow_validation_outcome['eligible_outcomes']}/{_ct_shadow_validation_outcome['required_future_outcomes']}")
    svo4.metric('Baseline Abs Error', '-' if _ct_shadow_validation_outcome['eligible_outcomes'] == 0 else f"{_ct_shadow_validation_outcome['baseline_mean_abs_error']:.4f}")
    svo5.metric('Shadow Abs Error', '-' if _ct_shadow_validation_outcome['eligible_outcomes'] == 0 else f"{_ct_shadow_validation_outcome['shadow_mean_abs_error']:.4f}")
    svo6.metric('Execution Authorization', 'NONE')
    svoa1, svoa2, svoa3, svoa4, svoa5 = st.columns(5)
    svoa1.metric('Relative Improvement', '-' if _ct_shadow_validation_outcome['eligible_outcomes'] < _ct_shadow_validation_outcome['required_future_outcomes'] else f"{_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}")
    svoa2.metric('Assumption Drift', _ct_shadow_validation_outcome['assumption_drift_outcomes'])
    svoa3.metric('Baseline Drift', _ct_shadow_validation_outcome['baseline_drift_outcomes'])
    svoa4.metric('Duplicates', _ct_shadow_validation_outcome['duplicate_outcomes'])
    svoa5.metric('Validation Guard', _ct_shadow_validation_outcome['validation_guard'])
    _svo_state = _ct_shadow_validation_outcome['validation_state']
    if _svo_state == 'SHADOW_EVAL_UPSTREAM_WAIT':
        st.info('Shadow OOS Evaluation은 LOCKED Validation Plan이 생긴 뒤 시작합니다. 현재 단계에서는 Outcome을 억지로 만들 필요가 없습니다.')
    elif _svo_state == 'SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED':
        st.warning('MODEL_SHADOW은 현재 text specification만 존재하므로 정량 counterfactual을 계산하지 않습니다. 실행 가능한 shadow evaluator가 별도로 정의되기 전 성능 결론을 내리지 않습니다.')
    elif _svo_state in {'SHADOW_EVAL_WAIT_FUTURE_OUTCOMES', 'SHADOW_EVAL_EVIDENCE_MATURING'}:
        st.info('사전등록된 Plan 이후의 새 Projection/Review/closed-session qualified Outcome만 out-of-sample evidence로 축적합니다.')
    elif _svo_state in {'SHADOW_EVAL_PLAN_INTEGRITY_REVIEW', 'SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW', 'SHADOW_EVAL_SCORECARD_SOURCE_REVIEW', 'SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW'}:
        st.error('Shadow Validation source/evidence integrity가 일치하지 않아 평가를 차단했습니다.')
    elif _svo_state in {'SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW', 'SHADOW_EVAL_BASELINE_DRIFT_REVIEW'}:
        st.warning('사전등록된 comparison 조건이 깨졌습니다. Capacity/baseline drift를 건너뛰어 결과를 합치지 않습니다.')
    elif _svo_state == 'SHADOW_EVAL_PASS':
        st.success(f"Shadow Validation PASS · relative error improvement {_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}. PASS는 live apply/Recalibration 승인이 아니며 별도 adoption gate가 필요합니다.")
    elif _svo_state == 'SHADOW_EVAL_FAIL':
        st.warning(f"Shadow Validation FAIL · relative error improvement {_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}. live apply 없이 Proposal을 폐기/재검토합니다.")
    elif _svo_state == 'SHADOW_EVAL_INCONCLUSIVE':
        st.info(f"Shadow Validation INCONCLUSIVE · relative error improvement {_ct_shadow_validation_outcome['relative_error_improvement_pct']:.1%}. 결과를 본 뒤 기준을 바꾸지 않습니다.")
    else:
        st.info('현재 Proposal scope에는 정량 Shadow Evaluation이 필요하지 않습니다.')
    st.dataframe(_ct_shadow_validation_outcome_queue, width='stretch', hide_index=True)
    if not _ct_shadow_validation_outcome['evidence_table'].empty:
        with st.expander('Shadow Validation Out-of-Sample Evidence', expanded=False):
            st.dataframe(_ct_shadow_validation_outcome['evidence_table'], width='stretch', hide_index=True)
    if _ct_latest_shadow_validation_outcome:
        _svo_latest_integrity = shadow_validation_outcome_snapshot_integrity(_ct_latest_shadow_validation_outcome)
        st.caption(f"Latest Shadow Validation Outcome · {_ct_latest_shadow_validation_outcome.get('shadow_validation_outcome_id', '')} · {_ct_latest_shadow_validation_outcome.get('validation_state', '')} · Integrity {_svo_latest_integrity['status']}")
    _svo_note = st.text_input('Shadow Validation Outcome Snapshot 메모', value='', key='shadow_validation_outcome_note', placeholder='예: prospective OOS validation / no live promotion')
    if st.button('Operations Flow Shadow Validation Outcome Snapshot 저장', key='shadow_validation_outcome_save'):
        _svo_row = build_flow_shadow_validation_outcome_snapshot(_ct_shadow_validation_outcome, note=_svo_note)
        _svo_hist = load_csv('operations_flow_shadow_validation_outcome_snapshots.csv')
        for _col in FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS:
            if _col not in _svo_hist.columns:
                _svo_hist[_col] = ''
        _svo_hist = pd.concat([_svo_hist[FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_svo_row])], ignore_index=True)
        verified_save_feedback(_svo_hist, 'operations_flow_shadow_validation_outcome_snapshots.csv', f"Shadow Validation Outcome 저장 · {_svo_row['validation_state']} · Eligible {_svo_row['eligible_outcomes']} · Validation Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Shadow Validation은 Validation Plan 이후 생성된 미래 Projection의 audited Outcome만 사용합니다. PASS도 live model/parameter apply, Recalibration, Capacity 변경, 투자 실행을 승인하지 않습니다.')
    _ct_shadow_adoption_review_history = load_csv('operations_flow_shadow_adoption_review_snapshots.csv')
    _ct_shadow_adoption_review = build_flow_shadow_adoption_review(_ct_shadow_validation_outcome, _ct_shadow_validation_outcome_history, _ct_shadow_adoption_review_history)
    _ct_shadow_adoption_queue = build_flow_shadow_adoption_queue(_ct_shadow_adoption_review)
    _ct_latest_shadow_adoption_review = latest_shadow_adoption_review_snapshot(_ct_shadow_adoption_review_history)
    st.subheader('1K-W. Shadow Validation Adoption / Human Decision / No-Live-Apply Guard')
    sar1, sar2, sar3, sar4, sar5, sar6 = st.columns(6)
    sar1.metric('Adoption State', _ct_shadow_adoption_review['adoption_state'])
    sar2.metric('Validation Source', _ct_shadow_adoption_review['source_validation_outcome_integrity'] if _ct_shadow_adoption_review['source_validation_outcome_id'] else 'NOT_REQUIRED')
    sar3.metric('Decision', _ct_shadow_adoption_review['decision'] or '-')
    sar4.metric('Improvement', '-' if _ct_shadow_adoption_review['eligible_outcomes'] == 0 else f"{_ct_shadow_adoption_review['relative_error_improvement_pct']:.1%}")
    sar5.metric('Adoption Guard', _ct_shadow_adoption_review['adoption_guard'])
    sar6.metric('Execution Authorization', 'NONE')
    _sar_state = _ct_shadow_adoption_review['adoption_state']
    if _sar_state == 'ADOPTION_UPSTREAM_WAIT':
        st.info('Human Adoption Review는 immutable SHADOW_EVAL_PASS audit이 생긴 뒤 시작합니다. 현재 단계에서는 adoption decision을 억지로 만들 필요가 없습니다.')
    elif _sar_state == 'ADOPTION_VALIDATION_FAILED':
        st.warning('Shadow Validation FAIL · live apply 없이 Proposal을 폐기하거나 새 Proposal/Plan cycle을 검토합니다.')
    elif _sar_state == 'ADOPTION_VALIDATION_INCONCLUSIVE':
        st.info('Shadow Validation INCONCLUSIVE · 결과를 본 뒤 preregistered 기준을 변경하지 않습니다.')
    elif _sar_state == 'ADOPTION_VALIDATION_AUDIT_REQUIRED':
        st.warning('live Shadow PASS는 있으나 immutable Validation Outcome audit이 없습니다. Adoption Review 전에 Shadow Validation Outcome Snapshot을 먼저 저장하세요.')
    elif _sar_state in {'ADOPTION_VALIDATION_INTEGRITY_REVIEW', 'ADOPTION_SOURCE_SUPERSEDED'}:
        st.warning('Shadow Validation / Adoption source가 stale 또는 integrity review 상태입니다. 현재 immutable PASS audit 기준으로 다시 검토하세요.')
    elif _sar_state == 'ADOPTION_REVIEW_REQUIRED':
        st.warning('Shadow Validation PASS는 자동 promotion이 아닙니다. ACCEPT_FOR_CONTROLLED_TRIAL / REJECT / DEFER 중 하나를 Human Review로 결정하세요.')
    elif _sar_state == 'ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL':
        st.success('Human Adoption Decision = ACCEPT_FOR_CONTROLLED_TRIAL · 이는 controlled trial 설계를 검토할 수 있다는 뜻일 뿐 live apply/Recalibration 승인이 아닙니다.')
    elif _sar_state == 'ADOPTION_REJECTED':
        st.info('Human Adoption Decision = REJECT · live model/parameter에는 어떤 변경도 적용되지 않습니다.')
    else:
        st.info('Human Adoption Decision = DEFER · 새 evidence 또는 새 Proposal cycle까지 live apply 없이 대기합니다.')
    st.dataframe(_ct_shadow_adoption_queue, width='stretch', hide_index=True)
    if _ct_latest_shadow_adoption_review:
        _sar_latest_integrity = shadow_adoption_review_snapshot_integrity(_ct_latest_shadow_adoption_review)
        st.caption(f"Latest Shadow Adoption Review · {_ct_latest_shadow_adoption_review.get('shadow_adoption_review_id', '')} · {_ct_latest_shadow_adoption_review.get('adoption_state', '')} · Integrity {_sar_latest_integrity['status']}")
    if _sar_state == 'ADOPTION_REVIEW_REQUIRED':
        _sar_decision = st.selectbox('Shadow Adoption Human Decision', ['ACCEPT_FOR_CONTROLLED_TRIAL', 'REJECT', 'DEFER'], key='shadow_adoption_decision')
        _sar_detail = st.text_area('Shadow Adoption Decision rationale', value='', key='shadow_adoption_decision_detail', placeholder='예: prospective OOS PASS evidence와 reversal risk를 검토했고, live apply 없이 controlled trial design만 다음 단계에서 검토')
        _sar_c1 = st.checkbox('SHADOW_EVAL_PASS의 prospective evidence / Plan 기준 / source lineage를 검토했음을 확인', key='shadow_adoption_validation_evidence_reviewed')
        _sar_c2 = st.checkbox('PASS가 재현되지 않을 경우의 reversal/rollback 조건을 검토했음을 확인', key='shadow_adoption_risk_reversal_reviewed')
        _sar_c3 = st.checkbox('ACCEPT 시에도 다음 단계는 controlled-trial-only임을 확인', key='shadow_adoption_trial_only_confirmed')
        _sar_c4 = st.checkbox('이 decision이 live model/parameter apply를 승인하지 않음을 확인', key='shadow_adoption_no_live_apply_confirmed')
        _sar_c5 = st.checkbox('이 decision이 자동 Recalibration을 승인하지 않음을 확인', key='shadow_adoption_no_recalibration_confirmed')
        _sar_c6 = st.checkbox('이 decision이 자동 Capacity 변경을 승인하지 않음을 확인', key='shadow_adoption_no_capacity_confirmed')
        _sar_c7 = st.checkbox('이 decision이 투자 실행/주문 권한을 생성하지 않음을 확인', key='shadow_adoption_no_execution_confirmed')
        _sar_c8 = st.checkbox('현재 Shadow Adoption Decision을 최종 Human Review했음을 확인', key='shadow_adoption_human_review_confirmed')
        _sar_note = st.text_input('Shadow Adoption Review Snapshot 메모', value='', key='shadow_adoption_review_note', placeholder='예: OOS PASS human adoption decision / no live apply')
        if st.button('Operations Flow Shadow Adoption Review 저장', key='shadow_adoption_review_save'):
            try:
                _sar_row = build_flow_shadow_adoption_review_lock(_ct_shadow_adoption_review, decision=_sar_decision, decision_detail=_sar_detail, validation_evidence_reviewed=_sar_c1, risk_reversal_reviewed=_sar_c2, controlled_trial_only_confirmed=_sar_c3, no_live_apply_confirmed=_sar_c4, no_auto_recalibration_confirmed=_sar_c5, no_auto_capacity_confirmed=_sar_c6, no_execution_authorization_confirmed=_sar_c7, human_review_confirmed=_sar_c8, note=_sar_note)
                _sar_hist = load_csv('operations_flow_shadow_adoption_review_snapshots.csv')
                for _col in FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS:
                    if _col not in _sar_hist.columns:
                        _sar_hist[_col] = ''
                _sar_hist = pd.concat([_sar_hist[FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS], pd.DataFrame([_sar_row])], ignore_index=True)
                verified_save_feedback(_sar_hist, 'operations_flow_shadow_adoption_review_snapshots.csv', f"Shadow Adoption Review 저장 · {_sar_row['decision']} · {_sar_row['adoption_state']} · Adoption Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('SHADOW_EVAL_PASS는 Human Adoption Review의 입력일 뿐입니다. ACCEPT 결정도 controlled trial 설계 검토만 허용하며 live apply/Recalibration/Capacity/투자 실행 승인을 만들지 않습니다.')
    _ct_controlled_trial_design_history = load_csv('operations_flow_controlled_trial_design_snapshots.csv')
    _ct_controlled_trial_design = build_flow_controlled_trial_design(_ct_shadow_adoption_review, _ct_controlled_trial_design_history, default_max_trial_scope_pct=0.1, default_max_trial_sessions=3, default_min_trial_outcomes=3, default_max_relative_error_degradation_pct=0.1)
    _ct_controlled_trial_design_queue = build_flow_controlled_trial_design_queue(_ct_controlled_trial_design)
    _ct_latest_controlled_trial_design = latest_controlled_trial_design_snapshot(_ct_controlled_trial_design_history)
    st.subheader('1K-X. Controlled Trial Design / Canary Scope / Rollback Contract')
    ctd1, ctd2, ctd3, ctd4, ctd5, ctd6 = st.columns(6)
    ctd1.metric('Trial Design State', _ct_controlled_trial_design['design_state'])
    ctd2.metric('Mode', _ct_controlled_trial_design['trial_mode'] or '-')
    ctd3.metric('Max Scope', f"{_ct_controlled_trial_design['max_trial_scope_pct']:.0%}")
    ctd4.metric('Session Cap', _ct_controlled_trial_design['max_trial_sessions'])
    ctd5.metric('Design Guard', _ct_controlled_trial_design['design_guard'])
    ctd6.metric('Execution Authorization', 'NONE')
    _ctd_state = _ct_controlled_trial_design['design_state']
    if _ctd_state == 'TRIAL_DESIGN_UPSTREAM_WAIT':
        st.info('Controlled Trial Design은 Human Adoption Decision이 ACCEPT_FOR_CONTROLLED_TRIAL로 LOCKED된 뒤 시작합니다. 현재 단계에서는 Trial Design을 억지로 만들 필요가 없습니다.')
    elif _ctd_state == 'TRIAL_DESIGN_NOT_REQUIRED':
        st.success('현재 Adoption decision에서는 Controlled Trial이 필요하지 않습니다. live apply 없이 새 evidence/Proposal cycle을 관찰합니다.')
    elif _ctd_state == 'TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED':
        st.warning('ACCEPT 상태지만 immutable Human Adoption Review source가 없습니다. Trial Design 전에 Adoption Review audit을 먼저 확인하세요.')
    elif _ctd_state == 'TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW':
        st.error('Adoption source 또는 Controlled Trial Design audit integrity가 일치하지 않아 Trial Design을 차단했습니다.')
    elif _ctd_state == 'TRIAL_DESIGN_SUPERSEDED':
        st.warning('새 Human Adoption source가 생성되어 기존 Trial Design이 superseded되었습니다. 현재 ACCEPT source 기준으로 scope/rollback contract를 다시 검토하세요.')
    elif _ctd_state == 'TRIAL_DESIGN_LOCKED':
        _ctd_locked = _ct_controlled_trial_design.get('latest_design') or {}
        st.success(f"Controlled Trial Design LOCKED · scope <= {float(_ctd_locked.get('max_trial_scope_pct', 0)):.0%} · sessions <= {int(float(_ctd_locked.get('max_trial_sessions', 0) or 0))} · Trial Start Authorization = NONE.")
    else:
        st.warning('Controlled Trial Design이 필요합니다. Canary scope와 rollback contract를 Human Review 후 잠그세요.')
    st.dataframe(_ct_controlled_trial_design_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_design:
        _ctd_latest_integrity = controlled_trial_design_snapshot_integrity(_ct_latest_controlled_trial_design)
        st.caption(f"Latest Controlled Trial Design · {_ct_latest_controlled_trial_design.get('controlled_trial_design_id', '')} · {_ct_latest_controlled_trial_design.get('design_state', '')} · Integrity {_ctd_latest_integrity['status']}")
    if _ctd_state == 'TRIAL_DESIGN_REQUIRED':
        _ctd_scope = st.number_input('Controlled Trial 최대 scope', min_value=0.01, max_value=0.1, value=0.05, step=0.01, format='%.2f', key='controlled_trial_max_scope_pct')
        _ctd_sessions = st.number_input('Controlled Trial 최대 session 수', min_value=1, max_value=5, value=3, step=1, key='controlled_trial_max_sessions')
        _ctd_outcomes = st.number_input('Controlled Trial 최소 qualified Outcome', min_value=3, max_value=20, value=3, step=1, key='controlled_trial_min_outcomes')
        _ctd_degradation = st.number_input('Rollback 상대 error 악화 한도', min_value=0.0, max_value=0.1, value=0.05, step=0.01, format='%.2f', key='controlled_trial_max_error_degradation')
        _ctd_rollback_detail = st.text_area('Controlled Trial Rollback Contract', value='', key='controlled_trial_rollback_detail', placeholder='예: error degradation / assumption drift / integrity fail / source supersession 중 하나라도 발생하면 즉시 baseline-only 상태로 되돌리고 trial을 중단')
        _ctd_c1 = st.checkbox('ACCEPT_FOR_CONTROLLED_TRIAL source audit과 prospective PASS evidence를 검토했음을 확인', key='controlled_trial_source_review_confirmed')
        _ctd_c2 = st.checkbox('Trial scope가 기존 운영 의사결정과 분리된 SHADOW_CANARY_ONLY임을 확인', key='controlled_trial_isolation_confirmed')
        _ctd_c3 = st.checkbox('Trial은 별도 수동 Start Gate 없이는 시작되지 않음을 확인', key='controlled_trial_manual_start_required_confirmed')
        _ctd_c4 = st.checkbox('Error degradation / assumption drift / integrity failure / source supersession rollback 경로를 확인', key='controlled_trial_rollback_path_confirmed')
        _ctd_c5 = st.checkbox('Design LOCKED가 live model/parameter apply를 승인하지 않음을 확인', key='controlled_trial_no_live_apply_confirmed')
        _ctd_c6 = st.checkbox('Design LOCKED가 자동 Capacity 변경을 승인하지 않음을 확인', key='controlled_trial_no_capacity_confirmed')
        _ctd_c7 = st.checkbox('Design LOCKED가 투자 실행/주문 권한을 생성하지 않음을 확인', key='controlled_trial_no_execution_confirmed')
        _ctd_c8 = st.checkbox('현재 Controlled Trial Design을 최종 Human Review했음을 확인', key='controlled_trial_human_review_confirmed')
        _ctd_note = st.text_input('Controlled Trial Design Snapshot 메모', value='', key='controlled_trial_design_note', placeholder='예: shadow canary scope + rollback contract / no start authorization')
        if st.button('Operations Flow Controlled Trial Design 저장', key='controlled_trial_design_save'):
            try:
                _ctd_row = build_flow_controlled_trial_design_lock(_ct_controlled_trial_design, max_trial_scope_pct=float(_ctd_scope), max_trial_sessions=int(_ctd_sessions), min_trial_outcomes=int(_ctd_outcomes), max_relative_error_degradation_pct=float(_ctd_degradation), rollback_detail=_ctd_rollback_detail, rollback_on_error_degradation=True, rollback_on_assumption_drift=True, rollback_on_integrity_failure=True, rollback_on_source_supersession=True, source_review_confirmed=_ctd_c1, isolation_confirmed=_ctd_c2, manual_start_required_confirmed=_ctd_c3, rollback_path_confirmed=_ctd_c4, no_live_apply_confirmed=_ctd_c5, no_auto_capacity_confirmed=_ctd_c6, no_execution_authorization_confirmed=_ctd_c7, human_review_confirmed=_ctd_c8, note=_ctd_note)
                _ctd_hist = load_csv('operations_flow_controlled_trial_design_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS:
                    if _col not in _ctd_hist.columns:
                        _ctd_hist[_col] = ''
                _ctd_hist = pd.concat([_ctd_hist[FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS], pd.DataFrame([_ctd_row])], ignore_index=True)
                verified_save_feedback(_ctd_hist, 'operations_flow_controlled_trial_design_snapshots.csv', f"Controlled Trial Design 저장 · scope {_ctd_row['max_trial_scope_pct']:.0%} · sessions {_ctd_row['max_trial_sessions']} · Trial Start Authorization = NONE · Recalibration Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Controlled Trial Design LOCKED는 trial 시작 승인이 아닙니다. SHADOW_CANARY_ONLY scope/rollback contract만 사전등록하며 별도 Trial Start Gate가 필요합니다.')
    _ct_controlled_trial_start_history = load_csv('operations_flow_controlled_trial_start_snapshots.csv')
    _ct_controlled_trial_start = build_flow_controlled_trial_start(_ct_controlled_trial_design, _ct_controlled_trial_start_history)
    _ct_controlled_trial_start_queue = build_flow_controlled_trial_start_queue(_ct_controlled_trial_start)
    _ct_latest_controlled_trial_start = latest_controlled_trial_start_snapshot(_ct_controlled_trial_start_history)
    st.subheader('1K-Y. Controlled Trial Start / Shadow Permit / Kill-Switch Gate')
    cts1, cts2, cts3, cts4, cts5, cts6 = st.columns(6)
    cts1.metric('Trial Start State', _ct_controlled_trial_start['start_state'])
    cts2.metric('Mode', _ct_controlled_trial_start['trial_mode'] or '-')
    cts3.metric('Permit Scope', '-' if _ct_controlled_trial_start['permit_scope_pct'] <= 0 else f"{_ct_controlled_trial_start['permit_scope_pct']:.0%}")
    cts4.metric('Session Budget', '-' if _ct_controlled_trial_start['permit_session_budget'] <= 0 else _ct_controlled_trial_start['permit_session_budget'])
    cts5.metric('Start Guard', _ct_controlled_trial_start['start_guard'])
    cts6.metric('Execution Authorization', 'NONE')
    _cts_state = _ct_controlled_trial_start['start_state']
    if _cts_state == 'TRIAL_START_UPSTREAM_WAIT':
        st.info('Controlled Trial Start Review는 TRIAL_DESIGN_LOCKED 이후에 시작합니다. 현재 단계에서는 Trial Start decision을 억지로 만들 필요가 없습니다.')
    elif _cts_state == 'TRIAL_START_NOT_REQUIRED':
        st.success('현재 Trial Design source에서는 Trial Start가 필요하지 않습니다.')
    elif _cts_state == 'TRIAL_START_DESIGN_SOURCE_REQUIRED':
        st.warning('TRIAL_DESIGN_LOCKED 상태지만 immutable Design source가 없습니다. Trial Start 전에 Controlled Trial Design audit을 확인하세요.')
    elif _cts_state == 'TRIAL_START_SOURCE_INTEGRITY_REVIEW':
        st.error('Controlled Trial Design 또는 Trial Start audit integrity가 일치하지 않아 Start Gate를 차단했습니다.')
    elif _cts_state == 'TRIAL_START_SOURCE_SUPERSEDED':
        st.warning('새 Controlled Trial Design이 생성되어 기존 Start decision이 superseded되었습니다. 현재 Design 기준으로 kill-switch/rollback readiness를 다시 확인하세요.')
    elif _cts_state == 'TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY':
        st.success(f"Shadow Trial Permit ISSUED · scope {_ct_controlled_trial_start['permit_scope_pct']:.0%} · sessions {_ct_controlled_trial_start['permit_session_budget']} · Execution Authorization = NONE.")
    elif _cts_state == 'TRIAL_START_REJECTED':
        st.info('Human Trial Start Decision = REJECT · Trial은 시작되지 않습니다.')
    elif _cts_state == 'TRIAL_START_DEFERRED':
        st.info('Human Trial Start Decision = DEFER · 새 evidence/운영 조건 확인 후 재검토합니다.')
    else:
        st.warning('Controlled Trial Start Human Review가 필요합니다. kill switch / rollback readiness / isolation을 다시 확인하세요.')
    st.dataframe(_ct_controlled_trial_start_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_start:
        _cts_latest_integrity = controlled_trial_start_snapshot_integrity(_ct_latest_controlled_trial_start)
        st.caption(f"Latest Controlled Trial Start · {_ct_latest_controlled_trial_start.get('controlled_trial_start_id', '')} · {_ct_latest_controlled_trial_start.get('start_state', '')} · Integrity {_cts_latest_integrity['status']}")
    if _cts_state == 'TRIAL_START_REVIEW_REQUIRED':
        _cts_decision = st.selectbox('Controlled Trial Start Human Decision', ['ISSUE_SHADOW_TRIAL_PERMIT', 'REJECT', 'DEFER'], key='controlled_trial_start_decision')
        _cts_scope = st.number_input('Shadow Trial Permit Scope', min_value=0.01, max_value=float(min(0.1, _ct_controlled_trial_start['design_max_scope_pct'])), value=float(min(0.05, _ct_controlled_trial_start['design_max_scope_pct'])), step=0.01, format='%.2f', key='controlled_trial_start_scope_pct')
        _cts_sessions = st.number_input('Shadow Trial Session Budget', min_value=1, max_value=max(1, int(_ct_controlled_trial_start['design_session_cap'])), value=max(1, min(2, int(_ct_controlled_trial_start['design_session_cap']))), step=1, key='controlled_trial_start_session_budget')
        _cts_detail = st.text_area('Controlled Trial Start rationale', value='', key='controlled_trial_start_detail', placeholder='예: immutable Trial Design source, isolation, kill switch, rollback readiness를 확인했고 SHADOW_CANARY_ONLY permit만 발급하며 live apply는 금지')
        _cts_c1 = st.checkbox('현재 TRIAL_DESIGN_LOCKED source id/hash 및 rollback contract를 검토했음을 확인', key='controlled_trial_start_design_source_reviewed')
        _cts_c2 = st.checkbox('Trial isolation이 SHADOW_CANARY_ONLY로 유지됨을 재확인', key='controlled_trial_start_isolation_rechecked')
        _cts_c3 = st.checkbox('즉시 중단 가능한 kill switch가 준비되었음을 확인', key='controlled_trial_start_kill_switch_ready')
        _cts_c4 = st.checkbox('Rollback path가 실제로 실행 가능한 상태임을 확인', key='controlled_trial_start_rollback_ready')
        _cts_c5 = st.checkbox('이 decision은 자동 시작이 아닌 수동 Human Start decision임을 확인', key='controlled_trial_start_manual_confirmed')
        _cts_c6 = st.checkbox('Shadow Trial Permit이 live model/parameter apply를 승인하지 않음을 확인', key='controlled_trial_start_no_live_apply')
        _cts_c7 = st.checkbox('Shadow Trial Permit이 자동 Recalibration을 승인하지 않음을 확인', key='controlled_trial_start_no_recalibration')
        _cts_c8 = st.checkbox('Shadow Trial Permit이 자동 Capacity 변경을 승인하지 않음을 확인', key='controlled_trial_start_no_capacity')
        _cts_c9 = st.checkbox('Shadow Trial Permit이 투자 실행/주문 권한을 생성하지 않음을 확인', key='controlled_trial_start_no_execution')
        _cts_c10 = st.checkbox('현재 Controlled Trial Start decision을 최종 Human Review했음을 확인', key='controlled_trial_start_human_review')
        _cts_note = st.text_input('Controlled Trial Start Snapshot 메모', value='', key='controlled_trial_start_note', placeholder='예: shadow trial permit / kill-switch ready / no live apply')
        if st.button('Operations Flow Controlled Trial Start Review 저장', key='controlled_trial_start_save'):
            try:
                _cts_row = build_flow_controlled_trial_start_lock(_ct_controlled_trial_start, start_decision=_cts_decision, start_detail=_cts_detail, permit_scope_pct=float(_cts_scope), permit_session_budget=int(_cts_sessions), design_source_reviewed=_cts_c1, isolation_rechecked=_cts_c2, kill_switch_ready_confirmed=_cts_c3, rollback_ready_confirmed=_cts_c4, manual_start_confirmed=_cts_c5, no_live_apply_confirmed=_cts_c6, no_auto_recalibration_confirmed=_cts_c7, no_auto_capacity_confirmed=_cts_c8, no_execution_authorization_confirmed=_cts_c9, human_review_confirmed=_cts_c10, note=_cts_note)
                _cts_hist = load_csv('operations_flow_controlled_trial_start_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS:
                    if _col not in _cts_hist.columns:
                        _cts_hist[_col] = ''
                _cts_hist = pd.concat([_cts_hist[FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS], pd.DataFrame([_cts_row])], ignore_index=True)
                verified_save_feedback(_cts_hist, 'operations_flow_controlled_trial_start_snapshots.csv', f"Controlled Trial Start Review 저장 · {_cts_row['start_decision']} · {_cts_row['start_state']} · Shadow Permission {_cts_row['shadow_trial_permission']} · Trial Start Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('ISSUE_SHADOW_TRIAL_PERMIT은 bounded shadow runtime을 위한 Human permit 기록일 뿐입니다. Trial Start Authorization/Execution Authorization은 NONE이며 live model/parameter/Capacity/투자 실행 권한을 만들지 않습니다.')
    _ct_controlled_trial_runtime_history = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
    _ct_controlled_trial_runtime = build_flow_controlled_trial_runtime(_ct_controlled_trial_start, _ct_controlled_trial_runtime_history)
    _ct_controlled_trial_runtime_queue = build_flow_controlled_trial_runtime_queue(_ct_controlled_trial_runtime)
    _ct_latest_controlled_trial_runtime = latest_controlled_trial_runtime_snapshot(_ct_controlled_trial_runtime_history)
    st.subheader('1K-Z. Controlled Trial Runtime / Shadow Session / Kill-Switch Enforcement')
    ctr1, ctr2, ctr3, ctr4, ctr5, ctr6 = st.columns(6)
    ctr1.metric('Runtime State', _ct_controlled_trial_runtime['runtime_state'])
    ctr2.metric('Permission', _ct_controlled_trial_runtime['shadow_trial_permission'])
    ctr3.metric('Sessions', f"{_ct_controlled_trial_runtime['sessions_used']}/{_ct_controlled_trial_runtime['permit_session_budget']}" if _ct_controlled_trial_runtime['permit_session_budget'] > 0 else '-')
    ctr4.metric('Active Session', _ct_controlled_trial_runtime['active_session_id'] or '-')
    ctr5.metric('Kill Switch', 'LATCHED' if _ct_controlled_trial_runtime['kill_switch_latched'] else 'ARMED')
    ctr6.metric('Execution Authorization', 'NONE')
    _ctr_state = _ct_controlled_trial_runtime['runtime_state']
    if _ctr_state == 'TRIAL_RUNTIME_UPSTREAM_WAIT':
        st.info('Controlled Trial Runtime은 SHADOW_CANARY_ONLY Start Permit이 발급된 뒤 시작합니다. 현재 단계에서는 Runtime Session을 억지로 열 필요가 없습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_NOT_REQUIRED':
        st.success('현재 Trial Start decision에서는 Shadow Runtime이 필요하지 않습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_DEFERRED':
        st.info('Trial Start가 DEFER되어 Shadow Runtime도 대기합니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED':
        st.warning('Start Permit 상태는 있으나 immutable source audit을 확인할 수 없습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW':
        st.error('Start Permit 또는 Runtime event audit integrity가 일치하지 않아 Runtime을 차단했습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_SOURCE_SUPERSEDED':
        st.warning('새 Start Permit으로 기존 Runtime source가 superseded되었습니다. 기존 Runtime을 재사용하지 않습니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_KILL_SWITCHED':
        st.error(f"Kill Switch LATCHED · trigger {_ct_controlled_trial_runtime['kill_switch_trigger']} · Rollback required. Runtime 재개는 금지됩니다.")
    elif _ctr_state == 'TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED':
        st.success('Shadow Runtime session budget을 모두 사용했습니다. 추가 OPEN은 금지되며 별도 Trial Outcome Review가 필요합니다.')
    elif _ctr_state == 'TRIAL_RUNTIME_ACTIVE':
        st.warning('Shadow Runtime Session ACTIVE · live apply/Execution 권한은 없습니다. Kill switch와 rollback readiness를 유지하면서 CLOSE 또는 KILL_SWITCH를 결정하세요.')
    else:
        st.info('Shadow Runtime READY · Human Review 후 bounded observation Session을 열 수 있습니다.')
    st.dataframe(_ct_controlled_trial_runtime_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_runtime:
        _ctr_latest_integrity = controlled_trial_runtime_snapshot_integrity(_ct_latest_controlled_trial_runtime)
        st.caption(f"Latest Controlled Trial Runtime · {_ct_latest_controlled_trial_runtime.get('controlled_trial_runtime_event_id', '')} · {_ct_latest_controlled_trial_runtime.get('event_type', '')} · Integrity {_ctr_latest_integrity['status']}")
    if _ctr_state == 'TRIAL_RUNTIME_READY':
        _ctr_open_detail = st.text_area('Shadow Runtime OPEN rationale', value='', key='controlled_trial_runtime_open_detail', placeholder='예: current immutable permit source, isolation, kill switch, rollback path를 재확인했고 bounded shadow observation session만 연다')
        _ctr_o1 = st.checkbox('현재 Shadow Trial Permit source id/hash를 직접 검토했습니다.', key='controlled_trial_runtime_open_source_reviewed')
        _ctr_o2 = st.checkbox('Runtime은 SHADOW_CANARY_ONLY isolation을 유지합니다.', key='controlled_trial_runtime_open_isolation')
        _ctr_o3 = st.checkbox('Kill switch 경로가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_open_kill_path')
        _ctr_o4 = st.checkbox('Rollback path가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_open_rollback_path')
        _ctr_o5 = st.checkbox('Runtime OPEN이 live model/parameter apply를 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_live')
        _ctr_o6 = st.checkbox('Runtime OPEN이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_recal')
        _ctr_o7 = st.checkbox('Runtime OPEN이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_capacity')
        _ctr_o8 = st.checkbox('Runtime OPEN이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='controlled_trial_runtime_open_no_exec')
        _ctr_o9 = st.checkbox('현재 Shadow Runtime OPEN을 최종 Human Review했습니다.', key='controlled_trial_runtime_open_human')
        _ctr_open_note = st.text_input('Shadow Runtime OPEN 메모', value='', key='controlled_trial_runtime_open_note', placeholder='예: bounded shadow session / kill-switch armed / no live execution')
        if st.button('Controlled Trial Runtime Session OPEN 저장', key='controlled_trial_runtime_open_save'):
            try:
                _ctr_row = build_flow_controlled_trial_runtime_open(_ct_controlled_trial_runtime, runtime_detail=_ctr_open_detail, permit_source_reviewed=_ctr_o1, shadow_isolation_confirmed=_ctr_o2, kill_switch_path_confirmed=_ctr_o3, rollback_path_confirmed=_ctr_o4, no_live_apply_confirmed=_ctr_o5, no_auto_recalibration_confirmed=_ctr_o6, no_auto_capacity_confirmed=_ctr_o7, no_execution_authorization_confirmed=_ctr_o8, human_review_confirmed=_ctr_o9, note=_ctr_open_note)
                _ctr_hist = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _ctr_hist.columns:
                        _ctr_hist[_col] = ''
                _ctr_hist = pd.concat([_ctr_hist[FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_ctr_row])], ignore_index=True)
                verified_save_feedback(_ctr_hist, 'operations_flow_controlled_trial_runtime_snapshots.csv', f"Shadow Runtime OPEN · {_ctr_row['runtime_session_id']} · session {_ctr_row['session_index']} · Trial Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    elif _ctr_state == 'TRIAL_RUNTIME_ACTIVE':
        _ctr_active_detail = st.text_area('Active Runtime CLOSE / Kill-Switch rationale', value='', key='controlled_trial_runtime_active_detail', placeholder='예: session observation complete with no breach, or kill-switch trigger and rollback rationale')
        _ctr_a1 = st.checkbox('현재 Permit source를 다시 확인했습니다.', key='controlled_trial_runtime_active_source_reviewed')
        _ctr_a2 = st.checkbox('Shadow isolation이 유지되고 있음을 확인했습니다.', key='controlled_trial_runtime_active_isolation')
        _ctr_a3 = st.checkbox('Kill switch path가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_active_kill_path')
        _ctr_a4 = st.checkbox('Rollback path가 즉시 사용 가능한 상태임을 확인했습니다.', key='controlled_trial_runtime_active_rollback_path')
        _ctr_a5 = st.checkbox('CLOSE/KILL decision이 live model/parameter apply를 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_live')
        _ctr_a6 = st.checkbox('CLOSE/KILL decision이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_recal')
        _ctr_a7 = st.checkbox('CLOSE/KILL decision이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_capacity')
        _ctr_a8 = st.checkbox('CLOSE/KILL decision이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='controlled_trial_runtime_active_no_exec')
        _ctr_a9 = st.checkbox('현재 Runtime decision을 최종 Human Review했습니다.', key='controlled_trial_runtime_active_human')
        _ctr_active_note = st.text_input('Active Runtime event 메모', value='', key='controlled_trial_runtime_active_note', placeholder='예: normal close / risk stop / rollback required')
        _ctr_col_close, _ctr_col_kill = st.columns(2)
        if _ctr_col_close.button('Shadow Runtime Session CLOSE 저장', key='controlled_trial_runtime_close_save'):
            try:
                _ctr_row = build_flow_controlled_trial_runtime_close(_ct_controlled_trial_runtime, runtime_detail=_ctr_active_detail, permit_source_reviewed=_ctr_a1, shadow_isolation_confirmed=_ctr_a2, kill_switch_path_confirmed=_ctr_a3, rollback_path_confirmed=_ctr_a4, no_live_apply_confirmed=_ctr_a5, no_auto_recalibration_confirmed=_ctr_a6, no_auto_capacity_confirmed=_ctr_a7, no_execution_authorization_confirmed=_ctr_a8, human_review_confirmed=_ctr_a9, note=_ctr_active_note)
                _ctr_hist = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _ctr_hist.columns:
                        _ctr_hist[_col] = ''
                _ctr_hist = pd.concat([_ctr_hist[FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_ctr_row])], ignore_index=True)
                verified_save_feedback(_ctr_hist, 'operations_flow_controlled_trial_runtime_snapshots.csv', f"Shadow Runtime CLOSE · {_ctr_row['runtime_session_id']} · {_ctr_row['runtime_state']} · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
        _ctr_kill_trigger = st.selectbox('Kill Switch Trigger', sorted(KILL_SWITCH_TRIGGERS), key='controlled_trial_runtime_kill_trigger')
        if _ctr_col_kill.button('KILL SWITCH LATCH 저장', key='controlled_trial_runtime_kill_save'):
            try:
                _ctr_row = build_flow_controlled_trial_runtime_kill_switch(_ct_controlled_trial_runtime, kill_switch_trigger=_ctr_kill_trigger, runtime_detail=_ctr_active_detail, permit_source_reviewed=_ctr_a1, shadow_isolation_confirmed=_ctr_a2, kill_switch_path_confirmed=_ctr_a3, rollback_path_confirmed=_ctr_a4, no_live_apply_confirmed=_ctr_a5, no_auto_recalibration_confirmed=_ctr_a6, no_auto_capacity_confirmed=_ctr_a7, no_execution_authorization_confirmed=_ctr_a8, human_review_confirmed=_ctr_a9, note=_ctr_active_note)
                _ctr_hist = load_csv('operations_flow_controlled_trial_runtime_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _ctr_hist.columns:
                        _ctr_hist[_col] = ''
                _ctr_hist = pd.concat([_ctr_hist[FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_ctr_row])], ignore_index=True)
                verified_save_feedback(_ctr_hist, 'operations_flow_controlled_trial_runtime_snapshots.csv', f"Kill Switch LATCHED · {_ctr_row['kill_switch_trigger']} · Rollback Required = TRUE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Controlled Trial Runtime은 bounded SHADOW_CANARY_ONLY observation session registry입니다. Runtime ACTIVE도 live model/parameter/Capacity/투자 실행 권한을 만들지 않으며 Kill Switch가 latch되면 재개하지 않습니다.')
    _ct_controlled_trial_outcome_history = load_csv('operations_flow_controlled_trial_outcome_snapshots.csv')
    _ct_controlled_trial_outcome = build_flow_controlled_trial_outcome(_ct_controlled_trial_runtime, _ct_controlled_trial_runtime_history, _ct_recalibration_proposal_history, _ct_scorecard_input['qualified_outcome_history'])
    _ct_controlled_trial_outcome_queue = build_flow_controlled_trial_outcome_queue(_ct_controlled_trial_outcome)
    _ct_latest_controlled_trial_outcome = latest_controlled_trial_outcome_snapshot(_ct_controlled_trial_outcome_history)
    st.subheader('1K-AA. Controlled Trial Outcome / Canary Evidence / Rollback Guard')
    cto1, cto2, cto3, cto4, cto5, cto6 = st.columns(6)
    cto1.metric('Trial Outcome State', _ct_controlled_trial_outcome['outcome_state'])
    cto2.metric('Runtime State', _ct_controlled_trial_outcome['source_runtime_state'] or '-')
    cto3.metric('Eligible Outcomes', f"{_ct_controlled_trial_outcome['eligible_trial_outcomes']}/{_ct_controlled_trial_outcome['required_trial_outcomes']}")
    cto4.metric('Relative Improvement', '-' if _ct_controlled_trial_outcome['eligible_trial_outcomes'] < _ct_controlled_trial_outcome['required_trial_outcomes'] else f"{_ct_controlled_trial_outcome['relative_error_improvement_pct']:.1%}")
    cto5.metric('Rollback Required', 'YES' if _ct_controlled_trial_outcome['rollback_required'] else 'NO')
    cto6.metric('Execution Authorization', 'NONE')
    ctoa1, ctoa2, ctoa3, ctoa4, ctoa5 = st.columns(5)
    ctoa1.metric('Completed Sessions', f"{_ct_controlled_trial_outcome['completed_sessions']}/{_ct_controlled_trial_outcome['permit_session_budget']}" if _ct_controlled_trial_outcome['permit_session_budget'] > 0 else '-')
    ctoa2.metric('Outside Session', _ct_controlled_trial_outcome['outside_session_outcomes'])
    ctoa3.metric('Pre-open Projection', _ct_controlled_trial_outcome['preopen_projection_outcomes'])
    ctoa4.metric('Drift', f"{_ct_controlled_trial_outcome['assumption_drift_outcomes']} / {_ct_controlled_trial_outcome['baseline_drift_outcomes']}")
    ctoa5.metric('Outcome Guard', _ct_controlled_trial_outcome['outcome_guard'])
    _cto_state = _ct_controlled_trial_outcome['outcome_state']
    if _cto_state == 'TRIAL_OUTCOME_UPSTREAM_WAIT':
        st.info('Controlled Trial Outcome Review는 Shadow Runtime evidence가 생긴 뒤 시작합니다. 현재 단계에서는 Outcome을 억지로 만들 필요가 없습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_NOT_REQUIRED':
        st.success('현재 Runtime source에서는 Controlled Trial Outcome Review가 필요하지 않습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT':
        st.warning('Shadow Runtime Session이 ACTIVE입니다. CLOSE 또는 KILL_SWITCH 전에는 Trial Outcome 결론을 내리지 않습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW':
        st.error('Runtime / Proposal / qualified Outcome source integrity가 일치하지 않아 Trial Outcome을 차단했습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED':
        st.warning('MODEL_SHADOW는 실행 가능한 trial counterfactual evaluator가 아직 정의되지 않아 성능 결론을 내리지 않습니다.')
    elif _cto_state == 'TRIAL_OUTCOME_EVIDENCE_MATURING':
        st.info('Trial session budget과 prospective qualified Outcome evidence가 아직 성숙 중입니다. 사후 기준 변경 없이 현재 permit/design 조건을 유지합니다.')
    elif _cto_state in {'TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED'}:
        st.error('Controlled Trial Outcome은 Rollback Required 상태입니다. 새 Runtime/Promotion보다 rollback closure와 post-mortem이 우선입니다.')
    elif _cto_state == 'TRIAL_OUTCOME_PASS_NO_PROMOTION':
        st.success(f"Controlled Trial PASS · relative error improvement {_ct_controlled_trial_outcome['relative_error_improvement_pct']:.1%}. PASS는 live promotion/Recalibration/Capacity/투자 실행 승인이 아닙니다.")
    else:
        st.info('Controlled Trial Outcome = INCONCLUSIVE · 기준을 사후 변경하지 않으며 live promotion은 없습니다.')
    st.dataframe(_ct_controlled_trial_outcome_queue, width='stretch', hide_index=True)
    if not _ct_controlled_trial_outcome['evidence_table'].empty:
        with st.expander('Controlled Trial Canary Evidence', expanded=False):
            st.dataframe(_ct_controlled_trial_outcome['evidence_table'], width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_outcome:
        _cto_latest_integrity = controlled_trial_outcome_snapshot_integrity(_ct_latest_controlled_trial_outcome)
        st.caption(f"Latest Controlled Trial Outcome · {_ct_latest_controlled_trial_outcome.get('controlled_trial_outcome_id', '')} · {_ct_latest_controlled_trial_outcome.get('outcome_state', '')} · Integrity {_cto_latest_integrity['status']}")
    _cto_terminal_states = {'TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_PASS_NO_PROMOTION', 'TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED', 'TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION'}
    if _cto_state in _cto_terminal_states:
        _cto_note = st.text_input('Controlled Trial Outcome Snapshot 메모', value='', key='controlled_trial_outcome_note', placeholder='예: canary outcome review / rollback required or pass-no-promotion')
        if st.button('Operations Flow Controlled Trial Outcome Snapshot 저장', key='controlled_trial_outcome_save'):
            _cto_row = build_flow_controlled_trial_outcome_snapshot(_ct_controlled_trial_outcome, note=_cto_note)
            _cto_hist = load_csv('operations_flow_controlled_trial_outcome_snapshots.csv')
            for _col in FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS:
                if _col not in _cto_hist.columns:
                    _cto_hist[_col] = ''
            _cto_hist = pd.concat([_cto_hist[FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_cto_row])], ignore_index=True)
            verified_save_feedback(_cto_hist, 'operations_flow_controlled_trial_outcome_snapshots.csv', f"Controlled Trial Outcome 저장 · {_cto_row['outcome_state']} · Eligible {_cto_row['eligible_trial_outcomes']} · Rollback {_cto_row['rollback_required']} · Trial Outcome Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Controlled Trial Outcome은 closed Runtime session 안에서 생성된 prospective qualified Outcome만 사용합니다. PASS도 live model/parameter promotion을 승인하지 않으며 Rollback Required 상태에서는 새 Trial보다 rollback closure가 우선입니다.')
    _ct_controlled_trial_closure_history = load_csv('operations_flow_controlled_trial_closure_snapshots.csv')
    _ct_controlled_trial_closure = build_flow_controlled_trial_closure(_ct_controlled_trial_outcome, _ct_controlled_trial_outcome_history, _ct_controlled_trial_closure_history)
    _ct_controlled_trial_closure_queue = build_flow_controlled_trial_closure_queue(_ct_controlled_trial_closure)
    _ct_latest_controlled_trial_closure = latest_controlled_trial_closure_snapshot(_ct_controlled_trial_closure_history)
    st.subheader('1K-AB. Controlled Trial Closure / Human Outcome Decision / Rollback Closure')
    ctc1, ctc2, ctc3, ctc4, ctc5, ctc6 = st.columns(6)
    ctc1.metric('Closure State', _ct_controlled_trial_closure['closure_state'])
    ctc2.metric('Outcome Source', _ct_controlled_trial_closure['source_trial_outcome_integrity'] if _ct_controlled_trial_closure['source_trial_outcome_id'] else 'NOT_REQUIRED')
    ctc3.metric('Decision', _ct_controlled_trial_closure['decision'] or '-')
    ctc4.metric('Rollback', 'REQUIRED' if _ct_controlled_trial_closure['rollback_required'] else 'NO')
    ctc5.metric('Live Change Permission', _ct_controlled_trial_closure['live_change_review_permission'])
    ctc6.metric('Execution Authorization', 'NONE')
    _ctc_state = _ct_controlled_trial_closure['closure_state']
    if _ctc_state == 'TRIAL_CLOSURE_UPSTREAM_WAIT':
        st.info('Controlled Trial Closure는 terminal Trial Outcome과 immutable Outcome audit이 생긴 뒤 시작합니다. 현재 단계에서는 Closure decision을 억지로 만들 필요가 없습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_NOT_REQUIRED':
        st.success('현재 Trial Outcome source에서는 Closure Review가 필요하지 않습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_OUTCOME_AUDIT_REQUIRED':
        st.warning('terminal Trial Outcome은 있으나 immutable Trial Outcome audit이 없습니다. Closure Review 전에 Trial Outcome Snapshot을 먼저 저장하세요.')
    elif _ctc_state == 'TRIAL_CLOSURE_SOURCE_INTEGRITY_REVIEW':
        st.error('Trial Outcome 또는 Closure audit integrity가 일치하지 않아 Closure를 차단했습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_SOURCE_SUPERSEDED':
        st.warning('새 Trial Outcome audit이 생겨 기존 Closure decision이 superseded되었습니다. 현재 Outcome audit 기준으로 다시 Human Review하세요.')
    elif _ctc_state == 'TRIAL_CLOSURE_REVIEW_REQUIRED':
        st.warning('Trial Outcome은 자동 promotion 신호가 아닙니다. PASS는 ACCEPT_FOR_LIVE_CHANGE_REVIEW / REJECT / DEFER, INCONCLUSIVE는 REJECT / DEFER만 Human Review로 결정합니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_ROLLBACK_REQUIRED':
        st.error('Rollback Required · 새 Trial/Live Change보다 rollback 완료, prior baseline 복원, integrity 검증, post-mortem closure가 우선입니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW':
        st.success('Human Closure Decision = ACCEPT_FOR_LIVE_CHANGE_REVIEW · 이는 다음 Live Change Design을 검토할 수 있다는 뜻일 뿐 live apply 승인이 아닙니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_ROLLBACK_CLOSED':
        st.success('Rollback Closure VERIFIED · prior baseline 복원과 closure audit이 확인되었습니다. live apply/Execution 권한은 생성되지 않습니다.')
    elif _ctc_state == 'TRIAL_CLOSURE_REJECTED':
        st.info('Human Closure Decision = REJECT · live model/parameter에는 어떤 변경도 적용되지 않습니다.')
    else:
        st.info('Human Closure Decision = DEFER · 새 evidence 또는 새 trial cycle까지 live apply 없이 대기합니다.')
    st.dataframe(_ct_controlled_trial_closure_queue, width='stretch', hide_index=True)
    if _ct_latest_controlled_trial_closure:
        _ctc_latest_integrity = controlled_trial_closure_snapshot_integrity(_ct_latest_controlled_trial_closure)
        st.caption(f"Latest Controlled Trial Closure · {_ct_latest_controlled_trial_closure.get('controlled_trial_closure_id', '')} · {_ct_latest_controlled_trial_closure.get('closure_state', '')} · Integrity {_ctc_latest_integrity['status']}")
    if _ctc_state in {'TRIAL_CLOSURE_REVIEW_REQUIRED', 'TRIAL_CLOSURE_ROLLBACK_REQUIRED'}:
        _ctc_outcome_state = _ct_controlled_trial_closure['outcome_state']
        if _ctc_state == 'TRIAL_CLOSURE_ROLLBACK_REQUIRED':
            _ctc_options = ['ROLLBACK_CLOSED']
        elif _ctc_outcome_state == 'TRIAL_OUTCOME_PASS_NO_PROMOTION':
            _ctc_options = ['ACCEPT_FOR_LIVE_CHANGE_REVIEW', 'REJECT', 'DEFER']
        else:
            _ctc_options = ['REJECT', 'DEFER']
        _ctc_decision = st.selectbox('Controlled Trial Closure Human Decision', _ctc_options, key='controlled_trial_closure_decision')
        _ctc_detail = st.text_area('Controlled Trial Closure decision rationale', value='', key='controlled_trial_closure_decision_detail', placeholder='예: terminal canary evidence, rollback state, reversal risk를 검토했고 live apply 없이 다음 review-only 단계 또는 closure를 선택')
        _ctc_rollback_detail = st.text_area('Rollback Closure detail', value='', key='controlled_trial_closure_rollback_detail', placeholder='ROLLBACK_CLOSED일 때 prior baseline 복원, integrity 검증, post-mortem 결과를 기록')
        _ctc_c1 = st.checkbox('현재 immutable Trial Outcome source id/hash를 검토했음을 확인', key='controlled_trial_closure_source_reviewed')
        _ctc_c2 = st.checkbox('Trial evidence / canary 결과 / session 조건을 검토했음을 확인', key='controlled_trial_closure_evidence_reviewed')
        _ctc_c3 = st.checkbox('결정이 틀렸을 때의 reversal / downside risk를 검토했음을 확인', key='controlled_trial_closure_reversal_reviewed')
        _ctc_c4 = st.checkbox('ACCEPT 시에도 다음 단계는 Live Change Design REVIEW ONLY임을 확인', key='controlled_trial_closure_live_change_review_only')
        _ctc_c5 = st.checkbox('Rollback이 실제 완료되었음을 확인', key='controlled_trial_closure_rollback_completed')
        _ctc_c6 = st.checkbox('Prior baseline이 복원되었음을 확인', key='controlled_trial_closure_prior_baseline_restored')
        _ctc_c7 = st.checkbox('Rollback 이후 integrity를 검증했음을 확인', key='controlled_trial_closure_rollback_integrity')
        _ctc_c8 = st.checkbox('Rollback 원인과 재발방지 post-mortem을 검토했음을 확인', key='controlled_trial_closure_postmortem')
        _ctc_c9 = st.checkbox('이 decision이 live model/parameter apply를 승인하지 않음을 확인', key='controlled_trial_closure_no_live_apply')
        _ctc_c10 = st.checkbox('이 decision이 자동 Recalibration을 승인하지 않음을 확인', key='controlled_trial_closure_no_recalibration')
        _ctc_c11 = st.checkbox('이 decision이 자동 Capacity 변경을 승인하지 않음을 확인', key='controlled_trial_closure_no_capacity')
        _ctc_c12 = st.checkbox('이 decision이 투자 실행/주문 권한을 생성하지 않음을 확인', key='controlled_trial_closure_no_execution')
        _ctc_c13 = st.checkbox('현재 Controlled Trial Closure decision을 최종 Human Review했음을 확인', key='controlled_trial_closure_human_review')
        _ctc_note = st.text_input('Controlled Trial Closure Snapshot 메모', value='', key='controlled_trial_closure_note', placeholder='예: pass review-only / reject / defer / rollback closure')
        if st.button('Operations Flow Controlled Trial Closure 저장', key='controlled_trial_closure_save'):
            try:
                _ctc_row = build_flow_controlled_trial_closure_lock(_ct_controlled_trial_closure, decision=_ctc_decision, decision_detail=_ctc_detail, rollback_detail=_ctc_rollback_detail, outcome_source_reviewed=_ctc_c1, trial_evidence_reviewed=_ctc_c2, reversal_risk_reviewed=_ctc_c3, live_change_review_only_confirmed=_ctc_c4, rollback_completed_confirmed=_ctc_c5, prior_baseline_restored_confirmed=_ctc_c6, rollback_integrity_verified=_ctc_c7, postmortem_reviewed=_ctc_c8, no_live_apply_confirmed=_ctc_c9, no_auto_recalibration_confirmed=_ctc_c10, no_auto_capacity_confirmed=_ctc_c11, no_execution_authorization_confirmed=_ctc_c12, human_review_confirmed=_ctc_c13, note=_ctc_note)
                _ctc_hist = load_csv('operations_flow_controlled_trial_closure_snapshots.csv')
                for _col in FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS:
                    if _col not in _ctc_hist.columns:
                        _ctc_hist[_col] = ''
                _ctc_hist = pd.concat([_ctc_hist[FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS], pd.DataFrame([_ctc_row])], ignore_index=True)
                verified_save_feedback(_ctc_hist, 'operations_flow_controlled_trial_closure_snapshots.csv', f"Controlled Trial Closure 저장 · {_ctc_row['decision']} · {_ctc_row['closure_state']} · Live Change Permission {_ctc_row['live_change_review_permission']} · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Controlled Trial Closure는 terminal Trial Outcome의 Human decision과 rollback closure를 기록합니다. ACCEPT_FOR_LIVE_CHANGE_REVIEW도 DESIGN_REVIEW_ONLY permission일 뿐 live apply/Recalibration/Capacity/투자 실행 승인을 만들지 않습니다.')
    _ct_live_change_design_history = load_csv('operations_flow_live_change_design_snapshots.csv')
    _ct_live_change_design = build_flow_live_change_design(_ct_controlled_trial_closure, _ct_controlled_trial_closure_history, load_csv('operations_flow_recalibration_proposal_snapshots.csv'), _ct_live_change_design_history)
    _ct_live_change_design_queue = build_flow_live_change_design_queue(_ct_live_change_design)
    _ct_latest_live_change_design = latest_live_change_design_snapshot(_ct_live_change_design_history)
    st.subheader('1K-AC. Live Change Design / Canary Scope / Baseline Lock / Rollback Plan')
    lcd1, lcd2, lcd3, lcd4, lcd5, lcd6 = st.columns(6)
    lcd1.metric('Design State', _ct_live_change_design['design_state'])
    lcd2.metric('Change Mode', _ct_live_change_design['change_mode'] or '-')
    lcd3.metric('Scope Cap', f"{_ct_live_change_design['max_live_scope_pct']:.0%}")
    lcd4.metric('Sessions', _ct_live_change_design['max_live_sessions'])
    lcd5.metric('Design Guard', _ct_live_change_design['design_guard'])
    lcd6.metric('Execution Authorization', 'NONE')
    lcdb1, lcdb2, lcdb3, lcdb4, lcdb5 = st.columns(5)
    lcdb1.metric('Baseline', '-' if not _ct_live_change_design['source_proposal_id'] else f"{_ct_live_change_design['baseline_value']:.4f}")
    lcdb2.metric('Candidate', '-' if not _ct_live_change_design['source_proposal_id'] else f"{_ct_live_change_design['candidate_value']:.4f}")
    lcdb3.metric('Rollback Target', '-' if not _ct_live_change_design['source_proposal_id'] else f"{_ct_live_change_design['rollback_target_value']:.4f}")
    lcdb4.metric('Post-change Outcomes', _ct_live_change_design['min_post_change_outcomes'])
    lcdb5.metric('Design Permission', _ct_live_change_design['live_change_design_permission'])
    _lcd_state = _ct_live_change_design['design_state']
    if _lcd_state == 'LIVE_CHANGE_DESIGN_UPSTREAM_WAIT':
        st.info('Live Change Design은 Human Trial Closure가 ACCEPT_FOR_LIVE_CHANGE_REVIEW로 닫힌 뒤 시작합니다. 현재 단계에서는 Design을 억지로 만들 필요가 없습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_NOT_REQUIRED':
        st.success('현재 Trial Closure decision에서는 Live Change Design이 필요하지 않습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_DEFERRED':
        st.info('Trial Closure가 DEFER되어 Live Change Design도 대기합니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED':
        st.warning('Accepted Closure state는 있으나 immutable Closure audit을 확인할 수 없습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW':
        st.error('Trial Closure 또는 Live Change Design source integrity가 일치하지 않아 Design을 차단했습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW':
        st.error('원본 locked Recalibration Proposal source를 확인할 수 없습니다. Live Change Design 전에 Proposal id/hash/integrity를 복구하세요.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED':
        st.warning('새 Trial Closure 또는 Proposal source가 생겨 기존 Live Change Design이 superseded되었습니다.')
    elif _lcd_state == 'LIVE_CHANGE_DESIGN_LOCKED':
        st.success('Live Change Design LOCKED · baseline/candidate/canary scope/rollback plan이 사전등록되었습니다. 이 상태도 live apply 승인이 아니며 별도 Human Apply Gate가 필요합니다.')
    else:
        st.warning('Live Change Design Human Review가 필요합니다. baseline version lock, canary isolation, rollback plan, manual apply gate를 사전등록하세요.')
    st.dataframe(_ct_live_change_design_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_design:
        _lcd_latest_integrity = live_change_design_snapshot_integrity(_ct_latest_live_change_design)
        st.caption(f"Latest Live Change Design · {_ct_latest_live_change_design.get('live_change_design_id', '')} · {_ct_latest_live_change_design.get('design_state', '')} · Integrity {_lcd_latest_integrity['status']}")
    if _lcd_state == 'LIVE_CHANGE_DESIGN_REQUIRED':
        _lcd_scope = st.number_input('Live Change Canary Scope', min_value=0.01, max_value=0.05, value=0.01, step=0.01, format='%.2f', key='live_change_design_scope')
        _lcd_sessions = st.number_input('Live Change Session Cap', min_value=1, max_value=3, value=1, step=1, key='live_change_design_sessions')
        _lcd_outcomes = st.number_input('Minimum Post-change Qualified Outcomes', min_value=3, max_value=20, value=3, step=1, key='live_change_design_outcomes')
        _lcd_degradation = st.number_input('Maximum Relative Error Degradation', min_value=0.0, max_value=0.05, value=0.03, step=0.01, format='%.2f', key='live_change_design_degradation')
        _lcd_artifact = st.text_input('Versioned Change Artifact Reference', value='', key='live_change_design_artifact_ref', placeholder='PARAMETER_SHADOW는 비워두면 target metric으로 고정됩니다. MODEL_SHADOW는 versioned artifact reference 필수')
        _lcd_detail = st.text_area('Live Change Design detail', value='', key='live_change_design_detail', placeholder='예: prior baseline을 version lock하고 1% canary 범위에서만 candidate를 검증하며 별도 Human Apply Gate 전까지 live apply하지 않는다')
        _lcd_rollback = st.text_area('Rollback Plan detail', value='', key='live_change_design_rollback_detail', placeholder='예: error degradation, assumption drift, integrity failure, source supersession 발생 시 즉시 candidate 중단 후 locked prior baseline으로 복원하고 post-change evidence를 폐기한다')
        _lcd_c1 = st.checkbox('현재 immutable Trial Closure와 원본 locked Proposal source id/hash를 검토했습니다.', key='live_change_design_source_reviewed')
        _lcd_c2 = st.checkbox('현재 prior baseline/version을 rollback target으로 고정했음을 확인했습니다.', key='live_change_design_baseline_locked')
        _lcd_c3 = st.checkbox('Live Change는 작은 canary isolation 범위에서만 검토될 것임을 확인했습니다.', key='live_change_design_canary_isolation')
        _lcd_c4 = st.checkbox('Design LOCK 이후에도 별도 Human Apply Gate 없이는 적용되지 않음을 확인했습니다.', key='live_change_design_manual_apply_gate')
        _lcd_c5 = st.checkbox('Rollback path가 실제 복원 가능한 prior baseline을 가리킴을 확인했습니다.', key='live_change_design_rollback_path')
        _lcd_c6 = st.checkbox('이 Design 저장이 자동 live apply를 승인하지 않음을 확인했습니다.', key='live_change_design_no_auto_apply')
        _lcd_c7 = st.checkbox('이 Design 저장이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='live_change_design_no_recalibration')
        _lcd_c8 = st.checkbox('이 Design 저장이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='live_change_design_no_capacity')
        _lcd_c9 = st.checkbox('이 Design 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_design_no_execution')
        _lcd_c10 = st.checkbox('현재 Live Change Design을 최종 Human Review했습니다.', key='live_change_design_human_review')
        _lcd_note = st.text_input('Live Change Design Snapshot 메모', value='', key='live_change_design_note', placeholder='예: canary design / baseline lock / rollback plan / no live apply')
        if st.button('Operations Flow Live Change Design 저장', key='live_change_design_save'):
            try:
                _lcd_row = build_flow_live_change_design_lock(_ct_live_change_design, max_live_scope_pct=float(_lcd_scope), max_live_sessions=int(_lcd_sessions), min_post_change_outcomes=int(_lcd_outcomes), max_relative_error_degradation_pct=float(_lcd_degradation), artifact_ref=_lcd_artifact, design_detail=_lcd_detail, rollback_detail=_lcd_rollback, source_reviewed=_lcd_c1, baseline_version_locked_confirmed=_lcd_c2, canary_isolation_confirmed=_lcd_c3, manual_apply_gate_required_confirmed=_lcd_c4, rollback_path_confirmed=_lcd_c5, no_auto_apply_confirmed=_lcd_c6, no_auto_recalibration_confirmed=_lcd_c7, no_auto_capacity_confirmed=_lcd_c8, no_execution_authorization_confirmed=_lcd_c9, human_review_confirmed=_lcd_c10, note=_lcd_note)
                _lcd_hist = load_csv('operations_flow_live_change_design_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS:
                    if _col not in _lcd_hist.columns:
                        _lcd_hist[_col] = ''
                _lcd_hist = pd.concat([_lcd_hist[FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS], pd.DataFrame([_lcd_row])], ignore_index=True)
                verified_save_feedback(_lcd_hist, 'operations_flow_live_change_design_snapshots.csv', f"Live Change Design 저장 · {_lcd_row['change_mode']} · scope {_lcd_row['max_live_scope_pct']:.1%} · rollback target {_lcd_row['rollback_target_value']:.4f} · Live Change Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Live Change Design은 DESIGN_REVIEW_ONLY permission으로 baseline/candidate/canary/rollback 조건을 사전등록하는 단계입니다. LIVE_CHANGE_DESIGN_LOCKED도 live apply/Recalibration/Capacity/투자 실행 승인을 만들지 않습니다.')
    _ct_live_change_apply_history = load_csv('operations_flow_live_change_apply_snapshots.csv')
    _ct_live_change_apply = build_flow_live_change_apply(_ct_live_change_design, _ct_live_change_apply_history)
    _ct_live_change_apply_queue = build_flow_live_change_apply_queue(_ct_live_change_apply)
    _ct_latest_live_change_apply = latest_live_change_apply_snapshot(_ct_live_change_apply_history)
    st.subheader('1K-AD. Live Change Apply Preflight / Manual Canary Permit / No-Auto-Apply Guard')
    lca1, lca2, lca3, lca4, lca5, lca6 = st.columns(6)
    lca1.metric('Apply State', _ct_live_change_apply['apply_state'])
    lca2.metric('Decision', _ct_live_change_apply['apply_decision'] or '-')
    lca3.metric('Permit Scope', '-' if _ct_live_change_apply['permit_scope_pct'] <= 0 else f"{_ct_live_change_apply['permit_scope_pct']:.0%}")
    lca4.metric('Session Budget', '-' if _ct_live_change_apply['permit_session_budget'] <= 0 else _ct_live_change_apply['permit_session_budget'])
    lca5.metric('Apply Guard', _ct_live_change_apply['apply_guard'])
    lca6.metric('Execution Authorization', 'NONE')
    lcap1, lcap2, lcap3, lcap4, lcap5 = st.columns(5)
    lcap1.metric('Baseline', '-' if not _ct_live_change_apply['source_live_change_design_id'] else f"{_ct_live_change_apply['baseline_value']:.4f}")
    lcap2.metric('Candidate', '-' if not _ct_live_change_apply['source_live_change_design_id'] else f"{_ct_live_change_apply['candidate_value']:.4f}")
    lcap3.metric('Rollback Target', '-' if not _ct_live_change_apply['source_live_change_design_id'] else f"{_ct_live_change_apply['rollback_target_value']:.4f}")
    lcap4.metric('Apply Permission', _ct_live_change_apply['live_change_apply_permission'])
    lcap5.metric('Apply Authorization', 'NONE')
    _lca_state = _ct_live_change_apply['apply_state']
    if _lca_state == 'LIVE_CHANGE_APPLY_UPSTREAM_WAIT':
        st.info('Live Change Apply Review는 LIVE_CHANGE_DESIGN_LOCKED 이후에 시작합니다. 현재 단계에서는 Apply decision을 억지로 만들 필요가 없습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_NOT_REQUIRED':
        st.success('현재 Live Change Design source에서는 Apply Review가 필요하지 않습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_DEFERRED':
        st.info('Human Live Change Apply decision이 DEFER되어 적용 검토도 대기합니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED':
        st.warning('LIVE_CHANGE_DESIGN_LOCKED 상태지만 immutable Design source가 없습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW':
        st.error('Live Change Design 또는 Apply audit integrity가 일치하지 않아 Apply Gate를 차단했습니다.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED':
        st.warning('새 Live Change Design이 생성되어 기존 Apply decision이 superseded되었습니다. 현재 Design 기준으로 baseline/candidate/rollback readiness를 다시 확인하세요.')
    elif _lca_state == 'LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY':
        st.success(f"Manual Canary Apply Permit ISSUED · scope {_ct_live_change_apply['permit_scope_pct']:.0%} · sessions {_ct_live_change_apply['permit_session_budget']} · Live Change Apply Authorization = NONE · Execution Authorization = NONE.")
    elif _lca_state == 'LIVE_CHANGE_APPLY_REJECTED':
        st.info('Human Live Change Apply Decision = REJECT · live change는 적용되지 않습니다.')
    else:
        st.warning('Live Change Apply Human Review가 필요합니다. baseline freshness, candidate artifact, canary isolation, rollback readiness를 재확인하세요.')
    st.dataframe(_ct_live_change_apply_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_apply:
        _lca_latest_integrity = live_change_apply_snapshot_integrity(_ct_latest_live_change_apply)
        st.caption(f"Latest Live Change Apply Review · {_ct_latest_live_change_apply.get('live_change_apply_id', '')} · {_ct_latest_live_change_apply.get('apply_state', '')} · Integrity {_lca_latest_integrity['status']}")
    if _lca_state == 'LIVE_CHANGE_APPLY_REVIEW_REQUIRED':
        _lca_decision = st.selectbox('Live Change Apply Human Decision', ['ISSUE_MANUAL_CANARY_APPLY_PERMIT', 'REJECT', 'DEFER'], key='live_change_apply_decision')
        _lca_scope = st.number_input('Manual Canary Apply Scope', min_value=0.01, max_value=float(min(0.05, _ct_live_change_apply['design_max_scope_pct'])), value=float(min(0.01, _ct_live_change_apply['design_max_scope_pct'])), step=0.01, format='%.2f', key='live_change_apply_scope')
        _lca_sessions = st.number_input('Manual Canary Apply Session Budget', min_value=1, max_value=max(1, int(_ct_live_change_apply['design_max_sessions'])), value=1, step=1, key='live_change_apply_sessions')
        _lca_detail = st.text_area('Live Change Apply rationale', value='', key='live_change_apply_detail', placeholder='예: immutable Design source, baseline freshness, candidate artifact, canary isolation, rollback readiness를 재확인했고 별도 runtime gate가 소비할 manual canary permit만 발급한다')
        _lca_c1 = st.checkbox('현재 immutable Live Change Design source id/hash를 직접 검토했습니다.', key='live_change_apply_source_reviewed')
        _lca_c2 = st.checkbox('현재 prior baseline이 Design에 잠긴 baseline과 동일함을 재확인했습니다.', key='live_change_apply_baseline_revalidated')
        _lca_c3 = st.checkbox('Candidate parameter/model artifact가 Design source와 일치함을 확인했습니다.', key='live_change_apply_candidate_verified')
        _lca_c4 = st.checkbox('Canary isolation 범위가 locked Design cap 안에 있음을 재확인했습니다.', key='live_change_apply_canary_isolation')
        _lca_c5 = st.checkbox('변경 창(change window)과 관찰 책임자를 검토했습니다.', key='live_change_apply_window_reviewed')
        _lca_c6 = st.checkbox('즉시 prior baseline으로 복원 가능한 rollback path가 준비되었음을 확인했습니다.', key='live_change_apply_rollback_ready')
        _lca_c7 = st.checkbox('이 permit은 사람이 직접 수행하는 manual canary apply 전제조건일 뿐임을 확인했습니다.', key='live_change_apply_manual_only')
        _lca_c8 = st.checkbox('이 permit 저장이 자동 live apply를 실행하지 않음을 확인했습니다.', key='live_change_apply_no_auto_apply')
        _lca_c9 = st.checkbox('이 permit 저장이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='live_change_apply_no_recal')
        _lca_c10 = st.checkbox('이 permit 저장이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='live_change_apply_no_capacity')
        _lca_c11 = st.checkbox('이 permit 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_apply_no_execution')
        _lca_c12 = st.checkbox('현재 Live Change Apply decision을 최종 Human Review했습니다.', key='live_change_apply_human_review')
        _lca_note = st.text_input('Live Change Apply Snapshot 메모', value='', key='live_change_apply_note', placeholder='예: manual canary permit / baseline revalidated / rollback ready / no auto apply')
        if st.button('Operations Flow Live Change Apply Review 저장', key='live_change_apply_save'):
            try:
                _lca_row = build_flow_live_change_apply_lock(_ct_live_change_apply, apply_decision=_lca_decision, permit_scope_pct=float(_lca_scope), permit_session_budget=int(_lca_sessions), apply_detail=_lca_detail, design_source_reviewed=_lca_c1, baseline_revalidated_confirmed=_lca_c2, candidate_artifact_verified=_lca_c3, canary_isolation_rechecked=_lca_c4, change_window_reviewed=_lca_c5, rollback_ready_confirmed=_lca_c6, manual_apply_only_confirmed=_lca_c7, no_auto_apply_confirmed=_lca_c8, no_auto_recalibration_confirmed=_lca_c9, no_auto_capacity_confirmed=_lca_c10, no_execution_authorization_confirmed=_lca_c11, human_review_confirmed=_lca_c12, note=_lca_note)
                _lca_hist = load_csv('operations_flow_live_change_apply_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS:
                    if _col not in _lca_hist.columns:
                        _lca_hist[_col] = ''
                _lca_hist = pd.concat([_lca_hist[FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS], pd.DataFrame([_lca_row])], ignore_index=True)
                verified_save_feedback(_lca_hist, 'operations_flow_live_change_apply_snapshots.csv', f"Live Change Apply Review 저장 · {_lca_row['apply_decision']} · {_lca_row['apply_state']} · Permission {_lca_row['live_change_apply_permission']} · Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('ISSUE_MANUAL_CANARY_APPLY_PERMIT은 자동 적용 명령이 아니라 다음 Live Change Runtime/Activation Gate를 위한 bounded Human permit 기록입니다. Live Change Apply Authorization/Execution Authorization은 NONE입니다.')
    _ct_live_change_runtime_history = load_csv('operations_flow_live_change_runtime_snapshots.csv')
    _ct_live_change_runtime = build_flow_live_change_runtime(_ct_live_change_apply, _ct_live_change_runtime_history)
    _ct_live_change_runtime_queue = build_flow_live_change_runtime_queue(_ct_live_change_runtime)
    _ct_latest_live_change_runtime = latest_live_change_runtime_snapshot(_ct_live_change_runtime_history)
    st.subheader('1K-AE. Live Change Runtime / Manual Activation / Kill-Switch / Rollback Guard')
    lcr1, lcr2, lcr3, lcr4, lcr5, lcr6 = st.columns(6)
    lcr1.metric('Runtime State', _ct_live_change_runtime['runtime_state'])
    lcr2.metric('Permission', _ct_live_change_runtime['live_change_runtime_permission'])
    lcr3.metric('Sessions', f"{_ct_live_change_runtime['sessions_used']}/{_ct_live_change_runtime['permit_session_budget']}" if _ct_live_change_runtime['permit_session_budget'] > 0 else '-')
    lcr4.metric('Active Session', _ct_live_change_runtime['active_session_id'] or '-')
    lcr5.metric('Rollback', 'REQUIRED' if _ct_live_change_runtime['rollback_required'] else 'ARMED')
    lcr6.metric('Execution Authorization', 'NONE')
    lcrb1, lcrb2, lcrb3, lcrb4 = st.columns(4)
    lcrb1.metric('Baseline', '-' if not _ct_live_change_runtime['source_live_change_apply_id'] else f"{_ct_live_change_runtime['baseline_value']:.4f}")
    lcrb2.metric('Candidate', '-' if not _ct_live_change_runtime['source_live_change_apply_id'] else f"{_ct_live_change_runtime['candidate_value']:.4f}")
    lcrb3.metric('Rollback Target', '-' if not _ct_live_change_runtime['source_live_change_apply_id'] else f"{_ct_live_change_runtime['rollback_target_value']:.4f}")
    lcrb4.metric('Runtime Authorization', 'NONE')
    _lcr_state = _ct_live_change_runtime['runtime_state']
    if _lcr_state == 'LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT':
        st.info('Live Change Runtime은 MANUAL_CANARY_APPLY_ONLY Permit이 발급된 뒤 시작합니다. 현재 단계에서는 activation event를 억지로 만들 필요가 없습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_NOT_REQUIRED':
        st.success('현재 Apply decision에서는 Live Change Runtime이 필요하지 않습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_DEFERRED':
        st.info('Apply decision이 DEFER되어 Runtime도 대기합니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED':
        st.warning('Apply Permit state는 있으나 immutable Apply source를 확인할 수 없습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW':
        st.error('Apply Permit 또는 Runtime event audit integrity가 일치하지 않아 Runtime을 차단했습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED':
        st.warning('새 Apply Permit으로 기존 Runtime source가 superseded되었습니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED':
        st.error(f"Kill Switch LATCHED · trigger {_ct_live_change_runtime['kill_switch_trigger']} · Rollback Required. 같은 source cycle에서는 재활성화하지 않습니다.")
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED':
        st.success('Manual canary session budget을 모두 사용했습니다. 추가 activation은 금지되며 이후 post-change Outcome evaluation으로 이동합니다.')
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_ACTIVE_CANARY':
        st.warning('Manual Canary ACTIVE · 이 OS가 자동으로 parameter/model을 바꾼 것이 아닙니다. 외부 수동 activation receipt를 기록한 상태이며 CLOSE 또는 KILL_SWITCH만 허용됩니다.')
    else:
        st.info('Manual Activation READY · 외부에서 실제 canary 변경을 사람이 수행한 뒤 receipt와 observed 값을 검증해 ACTIVATE 기록을 저장할 수 있습니다.')
    st.dataframe(_ct_live_change_runtime_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_runtime:
        _lcr_latest_integrity = live_change_runtime_snapshot_integrity(_ct_latest_live_change_runtime)
        st.caption(f"Latest Live Change Runtime · {_ct_latest_live_change_runtime.get('live_change_runtime_event_id', '')} · {_ct_latest_live_change_runtime.get('event_type', '')} · Integrity {_lcr_latest_integrity['status']}")
    if _lcr_state == 'LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION':
        _lcr_receipt = st.text_input('External Manual Activation Receipt / Change Reference', value='', key='live_change_runtime_activation_receipt', placeholder='예: CHG-20260929-001 / deployment receipt / parameter change ticket')
        _lcr_pre = st.number_input('Observed Value Before Manual Activation', value=float(_ct_live_change_runtime['baseline_value']), format='%.6f', key='live_change_runtime_observed_pre')
        _lcr_post = st.number_input('Observed Value After Manual Activation', value=float(_ct_live_change_runtime['candidate_value']), format='%.6f', key='live_change_runtime_observed_post')
        _lcr_detail = st.text_area('Manual Activation rationale', value='', key='live_change_runtime_activate_detail', placeholder='예: current baseline, candidate artifact, permit scope, change window, rollback path를 확인했고 외부 수동 canary 변경 완료 receipt를 바탕으로 activation event만 기록한다')
        _lcr_a1 = st.checkbox('현재 immutable Manual Canary Apply Permit source id/hash를 검토했습니다.', key='live_change_runtime_activate_permit_reviewed')
        _lcr_a2 = st.checkbox('Activation 직전 baseline이 locked baseline과 동일함을 확인했습니다.', key='live_change_runtime_activate_baseline')
        _lcr_a3 = st.checkbox('Candidate parameter/model artifact가 locked candidate와 일치함을 확인했습니다.', key='live_change_runtime_activate_candidate')
        _lcr_a4 = st.checkbox('Canary isolation이 permit scope 안에서 유지됨을 확인했습니다.', key='live_change_runtime_activate_isolation')
        _lcr_a5 = st.checkbox('현재 change window가 승인된 preflight 조건과 일치함을 확인했습니다.', key='live_change_runtime_activate_window')
        _lcr_a6 = st.checkbox('즉시 prior baseline으로 복원 가능한 rollback path가 준비되어 있음을 확인했습니다.', key='live_change_runtime_activate_rollback')
        _lcr_a7 = st.checkbox('실제 변경은 OS가 자동 실행한 것이 아니라 사람이 외부에서 수동 수행했음을 확인했습니다.', key='live_change_runtime_activate_external_manual')
        _lcr_a8 = st.checkbox('이 Runtime 기록이 추가 자동 apply를 실행하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_auto_apply')
        _lcr_a9 = st.checkbox('이 Runtime 기록이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_recal')
        _lcr_a10 = st.checkbox('이 Runtime 기록이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_capacity')
        _lcr_a11 = st.checkbox('이 Runtime 기록이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_runtime_activate_no_exec')
        _lcr_a12 = st.checkbox('현재 Manual Activation event를 최종 Human Review했습니다.', key='live_change_runtime_activate_human')
        _lcr_note = st.text_input('Live Change Runtime Snapshot 메모', value='', key='live_change_runtime_activate_note', placeholder='예: external manual canary activated / rollback armed / no auto apply')
        if st.button('Live Change Runtime ACTIVATE 기록 저장', key='live_change_runtime_activate_save'):
            try:
                _lcr_row = build_flow_live_change_runtime_activate(_ct_live_change_runtime, activation_receipt_ref=_lcr_receipt, observed_pre_value=float(_lcr_pre), observed_post_value=float(_lcr_post), runtime_detail=_lcr_detail, permit_source_reviewed=_lcr_a1, baseline_freshness_confirmed=_lcr_a2, candidate_artifact_verified=_lcr_a3, canary_isolation_confirmed=_lcr_a4, change_window_confirmed=_lcr_a5, rollback_path_confirmed=_lcr_a6, manual_external_activation_confirmed=_lcr_a7, no_auto_apply_confirmed=_lcr_a8, no_auto_recalibration_confirmed=_lcr_a9, no_auto_capacity_confirmed=_lcr_a10, no_execution_authorization_confirmed=_lcr_a11, human_review_confirmed=_lcr_a12, note=_lcr_note)
                _lcr_hist = load_csv('operations_flow_live_change_runtime_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _lcr_hist.columns:
                        _lcr_hist[_col] = ''
                _lcr_hist = pd.concat([_lcr_hist[FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_lcr_row])], ignore_index=True)
                verified_save_feedback(_lcr_hist, 'operations_flow_live_change_runtime_snapshots.csv', f"Live Change Runtime ACTIVATE recorded · {_lcr_row['runtime_session_id']} · receipt {_lcr_row['activation_receipt_ref']} · Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    elif _lcr_state == 'LIVE_CHANGE_RUNTIME_ACTIVE_CANARY':
        _lcr_active_detail = st.text_area('Active Canary CLOSE / Kill-Switch rationale', value='', key='live_change_runtime_active_detail', placeholder='예: canary observation complete and baseline restored, or risk trigger requiring kill switch')
        _lcr_restored = st.number_input('Observed Value After Baseline Restore', value=float(_ct_live_change_runtime['rollback_target_value']), format='%.6f', key='live_change_runtime_restored_value')
        _lcr_c1 = st.checkbox('현재 immutable Apply Permit source를 다시 확인했습니다.', key='live_change_runtime_active_permit_reviewed')
        _lcr_c2 = st.checkbox('Rollback path가 즉시 사용 가능한 상태임을 확인했습니다.', key='live_change_runtime_active_rollback_path')
        _lcr_c3 = st.checkbox('이 event 저장이 추가 자동 apply를 실행하지 않음을 확인했습니다.', key='live_change_runtime_active_no_auto_apply')
        _lcr_c4 = st.checkbox('이 event 저장이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='live_change_runtime_active_no_recal')
        _lcr_c5 = st.checkbox('이 event 저장이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='live_change_runtime_active_no_capacity')
        _lcr_c6 = st.checkbox('이 event 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_runtime_active_no_exec')
        _lcr_c7 = st.checkbox('현재 CLOSE/KILL decision을 최종 Human Review했습니다.', key='live_change_runtime_active_human')
        _lcr_close_restore = st.checkbox('Normal CLOSE 전에 prior baseline 복원을 완료했습니다.', key='live_change_runtime_close_restore_confirmed')
        _lcr_kill_rollback = st.checkbox('Kill Switch 선택 시 rollback을 즉시 시작했음을 확인합니다.', key='live_change_runtime_kill_rollback_started')
        _lcr_active_note = st.text_input('Active Canary event 메모', value='', key='live_change_runtime_active_note', placeholder='예: normal close / baseline restored / manual risk stop')
        _lcr_col_close, _lcr_col_kill = st.columns(2)
        if _lcr_col_close.button('Live Change Runtime CLOSE 저장', key='live_change_runtime_close_save'):
            try:
                _lcr_row = build_flow_live_change_runtime_close(_ct_live_change_runtime, observed_restored_value=float(_lcr_restored), runtime_detail=_lcr_active_detail, baseline_restore_confirmed=_lcr_close_restore, permit_source_reviewed=_lcr_c1, rollback_path_confirmed=_lcr_c2, no_auto_apply_confirmed=_lcr_c3, no_auto_recalibration_confirmed=_lcr_c4, no_auto_capacity_confirmed=_lcr_c5, no_execution_authorization_confirmed=_lcr_c6, human_review_confirmed=_lcr_c7, note=_lcr_active_note)
                _lcr_hist = load_csv('operations_flow_live_change_runtime_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _lcr_hist.columns:
                        _lcr_hist[_col] = ''
                _lcr_hist = pd.concat([_lcr_hist[FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_lcr_row])], ignore_index=True)
                verified_save_feedback(_lcr_hist, 'operations_flow_live_change_runtime_snapshots.csv', f"Live Change Runtime CLOSE · {_lcr_row['runtime_session_id']} · {_lcr_row['runtime_state']} · baseline restored · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
        _lcr_trigger = st.selectbox('Live Change Kill Switch Trigger', sorted(LIVE_CHANGE_RUNTIME_KILL_TRIGGERS), key='live_change_runtime_kill_trigger')
        if _lcr_col_kill.button('LIVE CHANGE KILL SWITCH LATCH 저장', key='live_change_runtime_kill_save'):
            try:
                _lcr_row = build_flow_live_change_runtime_kill_switch(_ct_live_change_runtime, kill_switch_trigger=_lcr_trigger, observed_restored_value=float(_lcr_restored), runtime_detail=_lcr_active_detail, rollback_initiated_confirmed=_lcr_kill_rollback, permit_source_reviewed=_lcr_c1, rollback_path_confirmed=_lcr_c2, no_auto_apply_confirmed=_lcr_c3, no_auto_recalibration_confirmed=_lcr_c4, no_auto_capacity_confirmed=_lcr_c5, no_execution_authorization_confirmed=_lcr_c6, human_review_confirmed=_lcr_c7, note=_lcr_active_note)
                _lcr_hist = load_csv('operations_flow_live_change_runtime_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
                    if _col not in _lcr_hist.columns:
                        _lcr_hist[_col] = ''
                _lcr_hist = pd.concat([_lcr_hist[FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS], pd.DataFrame([_lcr_row])], ignore_index=True)
                verified_save_feedback(_lcr_hist, 'operations_flow_live_change_runtime_snapshots.csv', f"Live Change Kill Switch LATCHED · {_lcr_row['kill_switch_trigger']} · baseline restored {_lcr_row['baseline_restore_confirmed']} · Rollback Required = TRUE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('v1.48 Runtime은 자동 live mutation 엔진이 아니라 외부 수동 canary activation의 immutable evidence registry입니다. ACTIVATE는 external receipt와 observed baseline/candidate를 검증해 기록할 뿐이며 Runtime/Execution Authorization은 NONE입니다.')
    _ct_live_change_outcome_history = load_csv('operations_flow_live_change_outcome_snapshots.csv')
    _ct_live_change_outcome = build_flow_live_change_outcome(_ct_live_change_runtime, _ct_live_change_runtime_history, _ct_scorecard_input['qualified_outcome_history'])
    _ct_live_change_outcome_queue = build_flow_live_change_outcome_queue(_ct_live_change_outcome)
    _ct_latest_live_change_outcome = latest_live_change_outcome_snapshot(_ct_live_change_outcome_history)
    st.subheader('1K-AF. Live Change Outcome / Post-Change Evidence / Permanent Adoption Guard')
    lco1, lco2, lco3, lco4, lco5, lco6 = st.columns(6)
    lco1.metric('Outcome State', _ct_live_change_outcome['outcome_state'])
    lco2.metric('Runtime State', _ct_live_change_outcome['source_runtime_state'] or '-')
    lco3.metric('Eligible Outcomes', f"{_ct_live_change_outcome['eligible_post_change_outcomes']}/{_ct_live_change_outcome['required_post_change_outcomes']}")
    lco4.metric('Relative Improvement', '-' if _ct_live_change_outcome['eligible_post_change_outcomes'] < _ct_live_change_outcome['required_post_change_outcomes'] else f"{_ct_live_change_outcome['relative_error_improvement_pct']:.1%}")
    lco5.metric('Permanent Adoption', _ct_live_change_outcome['permanent_adoption_permission'])
    lco6.metric('Execution Authorization', 'NONE')
    lcoa1, lcoa2, lcoa3, lcoa4, lcoa5 = st.columns(5)
    lcoa1.metric('Completed Sessions', f"{_ct_live_change_outcome['completed_sessions']}/{_ct_live_change_outcome['permit_session_budget']}" if _ct_live_change_outcome['permit_session_budget'] > 0 else '-')
    lcoa2.metric('Outside Session', _ct_live_change_outcome['outside_session_outcomes'])
    lcoa3.metric('Pre-activation Projection', _ct_live_change_outcome['preactivation_projection_outcomes'])
    lcoa4.metric('Drift', f"{_ct_live_change_outcome['assumption_drift_outcomes']} / {_ct_live_change_outcome['candidate_drift_outcomes']}")
    lcoa5.metric('Rollback Required', 'YES' if _ct_live_change_outcome['rollback_required'] else 'NO')
    _lco_state = _ct_live_change_outcome['outcome_state']
    if _lco_state == 'LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT':
        st.info('Live Change Outcome Review는 Manual Canary Runtime evidence가 생긴 뒤 시작합니다. 현재 단계에서는 Outcome을 억지로 만들 필요가 없습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_NOT_REQUIRED':
        st.success('현재 Runtime source에서는 Live Change Outcome Review가 필요하지 않습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT':
        st.warning('Manual Canary Runtime이 ACTIVE입니다. CLOSE 또는 KILL_SWITCH 전에는 Outcome 결론을 내리지 않습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW':
        st.error('Runtime / qualified Outcome source integrity가 일치하지 않아 Live Change Outcome을 차단했습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED':
        st.warning('MODEL_SHADOW는 실행 가능한 post-change counterfactual evaluator가 아직 정의되지 않아 permanent adoption 결론을 내리지 않습니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING':
        st.info('Post-change evidence와 canary session budget이 아직 성숙 중입니다. 긍정적 중간 결과만으로 조기 permanent adoption을 허용하지 않습니다.')
    elif _lco_state in {'LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED'}:
        st.error('Live Change Outcome은 Rollback Required 상태입니다. 새 activation이나 permanent adoption보다 baseline 유지/복원과 rollback closure가 우선입니다.')
    elif _lco_state == 'LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION':
        st.success(f"Live Change Canary PASS · relative error improvement {_ct_live_change_outcome['relative_error_improvement_pct']:.1%}. PASS는 permanent model/parameter adoption이나 투자 실행 승인이 아닙니다.")
    else:
        st.info('Live Change Outcome = INCONCLUSIVE · 기준을 사후 변경하지 않으며 permanent adoption은 없습니다.')
    st.dataframe(_ct_live_change_outcome_queue, width='stretch', hide_index=True)
    if not _ct_live_change_outcome['evidence_table'].empty:
        with st.expander('Live Change Post-Change Evidence', expanded=False):
            st.dataframe(_ct_live_change_outcome['evidence_table'], width='stretch', hide_index=True)
    if _ct_latest_live_change_outcome:
        _lco_latest_integrity = live_change_outcome_snapshot_integrity(_ct_latest_live_change_outcome)
        st.caption(f"Latest Live Change Outcome · {_ct_latest_live_change_outcome.get('live_change_outcome_id', '')} · {_ct_latest_live_change_outcome.get('outcome_state', '')} · Integrity {_lco_latest_integrity['status']}")
    _lco_terminal_states = {'LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION', 'LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED', 'LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION'}
    if _lco_state in _lco_terminal_states:
        _lco_note = st.text_input('Live Change Outcome Snapshot 메모', value='', key='live_change_outcome_note', placeholder='예: post-change evidence review / pass-no-permanent-adoption / rollback required')
        if st.button('Operations Flow Live Change Outcome Snapshot 저장', key='live_change_outcome_save'):
            _lco_row = build_flow_live_change_outcome_snapshot(_ct_live_change_outcome, note=_lco_note)
            _lco_hist = load_csv('operations_flow_live_change_outcome_snapshots.csv')
            for _col in FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS:
                if _col not in _lco_hist.columns:
                    _lco_hist[_col] = ''
            _lco_hist = pd.concat([_lco_hist[FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS], pd.DataFrame([_lco_row])], ignore_index=True)
            verified_save_feedback(_lco_hist, 'operations_flow_live_change_outcome_snapshots.csv', f"Live Change Outcome 저장 · {_lco_row['outcome_state']} · Eligible {_lco_row['eligible_post_change_outcomes']} · Rollback {_lco_row['rollback_required']} · Permanent Change Authorization = NONE · Execution Authorization = NONE.", rerun=False)
    st.caption('Live Change Outcome은 ACTIVATE→CLOSE 구간 안에서 생성된 prospective qualified Outcome만 사용합니다. PASS도 permanent adoption을 승인하지 않으며 별도 Human Live Change Outcome Closure가 필요합니다.')
    _ct_live_change_closure_history = load_csv('operations_flow_live_change_outcome_closure_snapshots.csv')
    _ct_live_change_closure = build_flow_live_change_outcome_closure(_ct_live_change_outcome, _ct_live_change_outcome_history, _ct_live_change_closure_history)
    _ct_live_change_closure_queue = build_flow_live_change_outcome_closure_queue(_ct_live_change_closure)
    _ct_latest_live_change_closure = latest_live_change_outcome_closure_snapshot(_ct_live_change_closure_history)
    st.subheader('1K-AG. Live Change Outcome Closure / Human Permanent Adoption Review / Rollback Closure')
    lcc1, lcc2, lcc3, lcc4, lcc5, lcc6 = st.columns(6)
    lcc1.metric('Closure State', _ct_live_change_closure['closure_state'])
    lcc2.metric('Outcome Source', _ct_live_change_closure['source_live_change_outcome_integrity'] if _ct_live_change_closure['source_live_change_outcome_id'] else 'NOT_REQUIRED')
    lcc3.metric('Decision', _ct_live_change_closure['decision'] or '-')
    lcc4.metric('Rollback', 'YES' if _ct_live_change_closure['rollback_required'] else 'NO')
    lcc5.metric('Permanent Design Permission', _ct_live_change_closure['permanent_change_design_permission'])
    lcc6.metric('Execution Authorization', 'NONE')
    _lcc_state = _ct_live_change_closure['closure_state']
    if _lcc_state == 'LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT':
        st.info('Permanent Adoption Review는 terminal Live Change Outcome과 immutable Outcome audit이 생긴 뒤 시작합니다. 현재 단계에서는 Closure decision을 억지로 만들 필요가 없습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_NOT_REQUIRED':
        st.success('현재 Live Change Outcome source에서는 Permanent Adoption Review가 필요하지 않습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED':
        st.warning('terminal Live Change Outcome은 있으나 immutable Outcome audit이 아직 없습니다. 먼저 1K-AF에서 Outcome Snapshot을 저장하세요.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW':
        st.error('Live Change Outcome 또는 Closure audit integrity가 일치하지 않아 Permanent Adoption Review를 차단했습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED':
        st.warning('새 Live Change Outcome audit이 생겨 기존 Closure decision이 superseded되었습니다. 현재 Outcome source 기준으로 다시 Human Review하세요.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED':
        st.warning('Human Permanent Adoption Review가 필요합니다. PASS도 바로 permanent adoption하지 않으며 ACCEPT는 다음 Permanent Change Design Review만 엽니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED':
        st.error('Rollback Required Outcome입니다. Permanent adoption 검토보다 baseline 복원, rollback integrity, post-mortem이 우선입니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW':
        st.success('Human Review = ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW · PERMANENT_DESIGN_REVIEW_ONLY permission만 부여됩니다. Permanent Apply Authorization은 NONE입니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_REJECTED':
        st.info('Human Review = REJECT · candidate의 permanent adoption은 없습니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_DEFERRED':
        st.info('Human Review = DEFER · 새 evidence/canary cycle까지 permanent adoption 검토를 보류합니다.')
    elif _lcc_state == 'LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED':
        st.success('Rollback Closure VERIFIED · prior baseline 복원/integrity/post-mortem 확인이 완료되었습니다. 이 상태도 새 permanent change 승인을 생성하지 않습니다.')
    st.dataframe(_ct_live_change_closure_queue, width='stretch', hide_index=True)
    if _ct_latest_live_change_closure:
        _lcc_integrity = live_change_outcome_closure_snapshot_integrity(_ct_latest_live_change_closure)
        st.caption(f"Latest Live Change Closure · {_ct_latest_live_change_closure.get('live_change_outcome_closure_id', '')} · {_ct_latest_live_change_closure.get('decision', '')} · Integrity {_lcc_integrity['status']}")
    if _lcc_state in {'LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED', 'LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED'}:
        _lcc_outcome_state = _ct_live_change_closure['outcome_state']
        if _lcc_state == 'LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED':
            _lcc_options = ['ROLLBACK_CLOSED']
        elif _lcc_outcome_state == 'LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION':
            _lcc_options = ['ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW', 'REJECT', 'DEFER']
        else:
            _lcc_options = ['REJECT', 'DEFER']
        _lcc_decision = st.selectbox('Human Permanent Adoption Decision', _lcc_options, key='live_change_closure_decision')
        _lcc_detail = st.text_area('Permanent Adoption Review rationale', value='', key='live_change_closure_detail', placeholder='예: prospective post-change evidence, canary scope, reversal risk, permanence risk를 검토했으며 ACCEPT는 permanent design review에만 진입시키고 실제 permanent apply는 승인하지 않는다')
        _lcc_rollback_detail = st.text_area('Rollback Closure detail', value='', key='live_change_closure_rollback_detail', placeholder='ROLLBACK_CLOSED 선택 시 baseline 복원, integrity 검증, post-mortem 결과와 재발방지 조치를 기록')
        _lcc_c1 = st.checkbox('현재 immutable Live Change Outcome source id/hash와 integrity를 검토했습니다.', key='live_change_closure_source_reviewed')
        _lcc_c2 = st.checkbox('ACTIVATE→CLOSE prospective post-change evidence와 평가 결과를 검토했습니다.', key='live_change_closure_evidence_reviewed')
        _lcc_c3 = st.checkbox('Canary 성공의 지속가능성, reversal risk, permanence risk를 검토했습니다.', key='live_change_closure_permanence_risk')
        _lcc_c4 = st.checkbox('ACCEPT는 Permanent Change Design Review만 허용하며 실제 permanent apply 승인이 아님을 확인했습니다.', key='live_change_closure_design_review_only')
        _lcc_rb1 = st.checkbox('Rollback이 실제 완료되었음을 확인했습니다.', key='live_change_closure_rollback_completed')
        _lcc_rb2 = st.checkbox('Prior baseline이 복원되었음을 확인했습니다.', key='live_change_closure_baseline_restored')
        _lcc_rb3 = st.checkbox('Rollback integrity를 검증했습니다.', key='live_change_closure_rollback_integrity')
        _lcc_rb4 = st.checkbox('Post-mortem을 검토했습니다.', key='live_change_closure_postmortem')
        _lcc_c5 = st.checkbox('이 Closure 저장이 permanent model/parameter apply를 승인하지 않음을 확인했습니다.', key='live_change_closure_no_permanent_apply')
        _lcc_c6 = st.checkbox('이 Closure 저장이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='live_change_closure_no_recal')
        _lcc_c7 = st.checkbox('이 Closure 저장이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='live_change_closure_no_capacity')
        _lcc_c8 = st.checkbox('이 Closure 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='live_change_closure_no_execution')
        _lcc_c9 = st.checkbox('현재 Permanent Adoption / Rollback Closure decision을 최종 Human Review했습니다.', key='live_change_closure_human_review')
        _lcc_note = st.text_input('Live Change Outcome Closure Snapshot 메모', value='', key='live_change_closure_note', placeholder='예: permanent-design-review-only / reject / defer / rollback closed')
        if st.button('Operations Flow Live Change Outcome Closure 저장', key='live_change_closure_save'):
            try:
                _lcc_row = build_flow_live_change_outcome_closure_lock(_ct_live_change_closure, decision=_lcc_decision, decision_detail=_lcc_detail, rollback_detail=_lcc_rollback_detail, outcome_source_reviewed=_lcc_c1, post_change_evidence_reviewed=_lcc_c2, permanence_risk_reviewed=_lcc_c3, permanent_design_review_only_confirmed=_lcc_c4, rollback_completed_confirmed=_lcc_rb1, prior_baseline_restored_confirmed=_lcc_rb2, rollback_integrity_verified=_lcc_rb3, postmortem_reviewed=_lcc_rb4, no_permanent_apply_confirmed=_lcc_c5, no_auto_recalibration_confirmed=_lcc_c6, no_auto_capacity_confirmed=_lcc_c7, no_execution_authorization_confirmed=_lcc_c8, human_review_confirmed=_lcc_c9, note=_lcc_note)
                _lcc_hist = load_csv('operations_flow_live_change_outcome_closure_snapshots.csv')
                for _col in FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS:
                    if _col not in _lcc_hist.columns:
                        _lcc_hist[_col] = ''
                _lcc_hist = pd.concat([_lcc_hist[FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS], pd.DataFrame([_lcc_row])], ignore_index=True)
                verified_save_feedback(_lcc_hist, 'operations_flow_live_change_outcome_closure_snapshots.csv', f"Live Change Outcome Closure 저장 · {_lcc_row['decision']} · {_lcc_row['closure_state']} · Permission {_lcc_row['permanent_change_design_permission']} · Permanent Change Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Permanent Adoption Review는 PASS를 바로 영구 적용하지 않습니다. ACCEPT는 PERMANENT_DESIGN_REVIEW_ONLY permission만 만들며 실제 permanent change에는 별도 Design/Apply governance가 필요합니다.')
    _ct_permanent_change_design_history = load_csv('operations_flow_permanent_change_design_snapshots.csv')
    _ct_permanent_change_design = build_flow_permanent_change_design(_ct_live_change_closure, _ct_live_change_closure_history, _ct_permanent_change_design_history)
    _ct_permanent_change_design_queue = build_flow_permanent_change_design_queue(_ct_permanent_change_design)
    _ct_latest_permanent_change_design = latest_permanent_change_design_snapshot(_ct_permanent_change_design_history)
    st.subheader('1K-AH. Permanent Change Design / Baseline Lock / Staged Rollout / Rollback Plan')
    pcd1, pcd2, pcd3, pcd4, pcd5, pcd6 = st.columns(6)
    pcd1.metric('Design State', _ct_permanent_change_design['design_state'])
    pcd2.metric('Closure Source', _ct_permanent_change_design['source_live_change_closure_integrity'] if _ct_permanent_change_design['source_live_change_closure_id'] else 'NOT_REQUIRED')
    pcd3.metric('Target Scope', '-' if _ct_permanent_change_design['design_state'] != 'PERMANENT_CHANGE_DESIGN_LOCKED' else f"{_ct_permanent_change_design['target_scope_pct']:.1%}")
    pcd4.metric('Initial Stage', '-' if _ct_permanent_change_design['design_state'] != 'PERMANENT_CHANGE_DESIGN_LOCKED' else f"{_ct_permanent_change_design['initial_stage_scope_pct']:.1%}")
    pcd5.metric('Design Permission', _ct_permanent_change_design['permanent_change_design_permission'])
    pcd6.metric('Execution Authorization', 'NONE')
    pcda1, pcda2, pcda3, pcda4, pcda5 = st.columns(5)
    pcda1.metric('Baseline', '-' if _ct_permanent_change_design['baseline_value'] == 0 else f"{_ct_permanent_change_design['baseline_value']:.4f}")
    pcda2.metric('Candidate', '-' if _ct_permanent_change_design['candidate_value'] == 0 else f"{_ct_permanent_change_design['candidate_value']:.4f}")
    pcda3.metric('Rollback Target', '-' if _ct_permanent_change_design['rollback_target_value'] == 0 else f"{_ct_permanent_change_design['rollback_target_value']:.4f}")
    pcda4.metric('Stages', '-' if _ct_permanent_change_design['design_state'] != 'PERMANENT_CHANGE_DESIGN_LOCKED' else _ct_permanent_change_design['rollout_stage_count'])
    pcda5.metric('Permanent Apply Authorization', 'NONE')
    _pcd_state = _ct_permanent_change_design['design_state']
    if _pcd_state == 'PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT':
        st.info('Permanent Change Design은 Human Permanent Adoption Closure가 ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW로 종료된 뒤 시작합니다. 현재 단계에서는 design을 억지로 만들 필요가 없습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_NOT_REQUIRED':
        st.success('현재 Human Closure source에서는 Permanent Change Design이 필요하지 않습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_DEFERRED':
        st.info('Human Permanent Adoption Review가 DEFER 상태입니다. 새 evidence/canary cycle 전에는 Permanent Change Design을 진행하지 않습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED':
        st.warning('Permanent Design Review permission은 있으나 immutable Closure source가 없습니다. 먼저 1K-AG의 Closure snapshot을 확인하세요.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW':
        st.error('Human Closure 또는 Permanent Design source integrity가 일치하지 않아 Design을 차단했습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED':
        st.warning('새 Human Closure source가 생겨 기존 Permanent Design이 superseded되었습니다. 현재 source 기준으로 다시 설계하세요.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_REQUIRED':
        st.warning('Human Permanent Change Design Review가 필요합니다. 이 단계는 staged rollout/baseline/rollback/monitoring을 설계할 뿐 실제 permanent apply를 승인하지 않습니다.')
    elif _pcd_state == 'PERMANENT_CHANGE_DESIGN_LOCKED':
        st.success('Permanent Change Design LOCKED · PERMANENT_DESIGN_LOCKED_NO_APPLY permission만 부여됩니다. 별도 Permanent Change Apply Preflight 전에는 실제 영구 변경을 적용하지 않습니다.')
    st.dataframe(_ct_permanent_change_design_queue, width='stretch', hide_index=True)
    if _ct_latest_permanent_change_design:
        _pcd_integrity = permanent_change_design_snapshot_integrity(_ct_latest_permanent_change_design)
        st.caption(f"Latest Permanent Change Design · {_ct_latest_permanent_change_design.get('permanent_change_design_id', '')} · {_ct_latest_permanent_change_design.get('design_state', '')} · Integrity {_pcd_integrity['status']}")
    if _pcd_state == 'PERMANENT_CHANGE_DESIGN_REQUIRED':
        _pcd_target_scope = st.number_input('Permanent Target Scope', min_value=0.01, max_value=1.0, value=1.0, step=0.05, format='%.2f', key='permanent_change_target_scope')
        _pcd_stage_scope = st.number_input('Initial Staged Rollout Scope', min_value=0.01, max_value=0.1, value=0.05, step=0.01, format='%.2f', key='permanent_change_initial_stage_scope')
        _pcd_stages = st.number_input('Rollout Stage Count', min_value=2, max_value=10, value=3, step=1, key='permanent_change_rollout_stages')
        _pcd_proof_days = st.number_input('Proof Clock (days)', min_value=7, max_value=365, value=30, step=1, key='permanent_change_proof_clock_days')
        _pcd_min_outcomes = st.number_input('Minimum Post-change Outcomes', min_value=5, max_value=100, value=5, step=1, key='permanent_change_min_outcomes')
        _pcd_degradation = st.number_input('Max Relative Error Degradation', min_value=0.0, max_value=0.1, value=0.03, step=0.01, format='%.2f', key='permanent_change_max_degradation')
        _pcd_rollback_hours = st.number_input('Rollback Observation Window (hours)', min_value=24, max_value=720, value=72, step=24, key='permanent_change_rollback_hours')
        _pcd_design_detail = st.text_area('Permanent Change Design detail', value='', key='permanent_change_design_detail', placeholder='baseline/candidate source, scope, why permanence may be justified, what is explicitly outside this design을 60자 이상 기록')
        _pcd_rollout_detail = st.text_area('Staged Rollout Plan', value='', key='permanent_change_rollout_detail', placeholder='initial stage → evidence check → next stage escalation criteria와 각 단계에서 자동 확대가 금지된다는 내용을 60자 이상 기록')
        _pcd_rollback_detail = st.text_area('Permanent Rollback Plan', value='', key='permanent_change_rollback_detail', placeholder='degradation/drift/integrity failure 발생 시 prior baseline 또는 prior artifact로 복원하는 절차를 60자 이상 기록')
        _pcd_monitoring_detail = st.text_area('Post-change Monitoring Plan', value='', key='permanent_change_monitoring_detail', placeholder='proof clock, post-change outcomes, drift/quality KPI, add-freeze/rollback triggers를 60자 이상 기록')
        _pcd_c1 = st.checkbox('현재 immutable Human Permanent Adoption Closure source id/hash/integrity를 검토했습니다.', key='permanent_change_source_reviewed')
        _pcd_c2 = st.checkbox('Canary의 prospective post-change evidence와 Human Closure rationale을 검토했습니다.', key='permanent_change_evidence_reviewed')
        _pcd_c3 = st.checkbox('Prior baseline/rollback target을 현재 immutable source에 lock했습니다.', key='permanent_change_baseline_locked')
        _pcd_c4 = st.checkbox('Permanent candidate parameter/model artifact identity를 검증했습니다.', key='permanent_change_candidate_verified')
        _pcd_c5 = st.checkbox('Full-scope 전환이 아닌 staged rollout을 사용하며 각 stage는 evidence 후에만 다음 단계로 진행함을 확인했습니다.', key='permanent_change_staged_rollout')
        _pcd_c6 = st.checkbox('각 rollout stage가 reversible하며 irreversible one-way cutover를 금지함을 확인했습니다.', key='permanent_change_reversible')
        _pcd_c7 = st.checkbox('Prior baseline/artifact로의 rollback path와 observation window를 확인했습니다.', key='permanent_change_rollback_path')
        _pcd_c8 = st.checkbox('Proof Clock, post-change outcomes, drift/degradation monitoring plan을 확인했습니다.', key='permanent_change_monitoring_plan')
        _pcd_c9 = st.checkbox('이 Design Lock과 실제 Permanent Apply 사이에 별도 Human Apply Gate가 필요함을 확인했습니다.', key='permanent_change_separate_apply_gate')
        _pcd_c10 = st.checkbox('이 Design 저장이 permanent parameter/model apply를 승인하지 않음을 확인했습니다.', key='permanent_change_no_apply')
        _pcd_c11 = st.checkbox('이 Design 저장이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='permanent_change_no_recal')
        _pcd_c12 = st.checkbox('이 Design 저장이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='permanent_change_no_capacity')
        _pcd_c13 = st.checkbox('이 Design 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='permanent_change_no_execution')
        _pcd_c14 = st.checkbox('현재 Permanent Change Design을 최종 Human Review했습니다.', key='permanent_change_human_review')
        _pcd_note = st.text_input('Permanent Change Design Snapshot 메모', value='', key='permanent_change_design_note', placeholder='예: staged permanent design only / no apply')
        if st.button('Operations Flow Permanent Change Design Lock 저장', key='permanent_change_design_save'):
            try:
                _pcd_row = build_flow_permanent_change_design_lock(_ct_permanent_change_design, target_scope_pct=_pcd_target_scope, initial_stage_scope_pct=_pcd_stage_scope, rollout_stage_count=int(_pcd_stages), proof_clock_days=int(_pcd_proof_days), min_post_change_outcomes=int(_pcd_min_outcomes), max_relative_error_degradation_pct=_pcd_degradation, rollback_observation_hours=int(_pcd_rollback_hours), design_detail=_pcd_design_detail, rollout_detail=_pcd_rollout_detail, rollback_detail=_pcd_rollback_detail, monitoring_detail=_pcd_monitoring_detail, source_reviewed=_pcd_c1, post_change_evidence_reviewed=_pcd_c2, baseline_locked_confirmed=_pcd_c3, candidate_artifact_verified=_pcd_c4, staged_rollout_confirmed=_pcd_c5, reversible_rollout_confirmed=_pcd_c6, rollback_path_confirmed=_pcd_c7, monitoring_plan_confirmed=_pcd_c8, separate_apply_gate_required_confirmed=_pcd_c9, no_permanent_apply_confirmed=_pcd_c10, no_auto_recalibration_confirmed=_pcd_c11, no_auto_capacity_confirmed=_pcd_c12, no_execution_authorization_confirmed=_pcd_c13, human_review_confirmed=_pcd_c14, note=_pcd_note)
                _pcd_hist = load_csv('operations_flow_permanent_change_design_snapshots.csv')
                for _col in FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS:
                    if _col not in _pcd_hist.columns:
                        _pcd_hist[_col] = ''
                _pcd_hist = pd.concat([_pcd_hist[FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS], pd.DataFrame([_pcd_row])], ignore_index=True)
                verified_save_feedback(_pcd_hist, 'operations_flow_permanent_change_design_snapshots.csv', f"Permanent Change Design 저장 · {_pcd_row['design_state']} · Target {_pcd_row['target_scope_pct']:.1%} · Stage1 {_pcd_row['initial_stage_scope_pct']:.1%} · Permission {_pcd_row['permanent_change_design_permission']} · Permanent Change Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Permanent Change Design은 Human Closure ACCEPT 이후 baseline/candidate/rollback/staged rollout을 lock하는 단계입니다. DESIGN_LOCKED는 actual permanent apply가 아니며 별도 Permanent Change Apply Preflight가 필요합니다.')
    _ct_permanent_change_apply_history = load_csv('operations_flow_permanent_change_apply_snapshots.csv')
    _ct_permanent_change_apply = build_flow_permanent_change_apply(_ct_permanent_change_design, _ct_permanent_change_design_history, _ct_permanent_change_apply_history)
    _ct_permanent_change_apply_queue = build_flow_permanent_change_apply_queue(_ct_permanent_change_apply)
    _ct_latest_permanent_change_apply = latest_permanent_change_apply_snapshot(_ct_permanent_change_apply_history)
    st.subheader('1K-AI. Permanent Change Apply Preflight / Human Stage-1 Permit / No-Auto-Apply Guard')
    pca1, pca2, pca3, pca4, pca5, pca6 = st.columns(6)
    pca1.metric('Apply State', _ct_permanent_change_apply['apply_state'])
    pca2.metric('Decision', _ct_permanent_change_apply['apply_decision'] or '-')
    pca3.metric('Permit Stage', '-' if _ct_permanent_change_apply['permit_stage_number'] == 0 else _ct_permanent_change_apply['permit_stage_number'])
    pca4.metric('Permit Scope', '-' if _ct_permanent_change_apply['permit_scope_pct'] == 0 else f"{_ct_permanent_change_apply['permit_scope_pct']:.1%}")
    pca5.metric('Apply Permission', _ct_permanent_change_apply['permanent_change_apply_permission'])
    pca6.metric('Execution Authorization', 'NONE')
    pcaa1, pcaa2, pcaa3, pcaa4, pcaa5 = st.columns(5)
    pcaa1.metric('Baseline', '-' if _ct_permanent_change_apply['baseline_value'] == 0 else f"{_ct_permanent_change_apply['baseline_value']:.4f}")
    pcaa2.metric('Candidate', '-' if _ct_permanent_change_apply['candidate_value'] == 0 else f"{_ct_permanent_change_apply['candidate_value']:.4f}")
    pcaa3.metric('Rollback Target', '-' if _ct_permanent_change_apply['rollback_target_value'] == 0 else f"{_ct_permanent_change_apply['rollback_target_value']:.4f}")
    pcaa4.metric('Activation Window', '-' if _ct_permanent_change_apply['permit_activation_window_hours'] == 0 else f"{_ct_permanent_change_apply['permit_activation_window_hours']}h")
    pcaa5.metric('Permanent Apply Authorization', 'NONE')
    _pca_state = _ct_permanent_change_apply['apply_state']
    if _pca_state == 'PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT':
        st.info('Permanent Change Apply Review는 Permanent Change Design이 LOCKED 된 뒤 시작합니다. 현재 단계에서는 Apply decision을 억지로 만들 필요가 없습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_NOT_REQUIRED':
        st.success('현재 Permanent Design source에서는 Apply Review가 필요하지 않습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_DEFERRED':
        st.info('Human Permanent Change Apply Review = DEFER · 조건/evidence 갱신 전에는 실제 변경을 허용하지 않습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED':
        st.warning('LOCKED Design 상태이나 immutable Design source가 없습니다. 먼저 1K-AH Permanent Change Design snapshot을 확인하세요.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW':
        st.error('Permanent Design 또는 Apply audit integrity가 일치하지 않아 Apply Review를 차단했습니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED':
        st.warning('Human Permanent Change Apply Preflight가 필요합니다. 허용되는 permit은 MANUAL_PERMANENT_STAGE1_APPLY_ONLY뿐이며 자동 stage escalation은 금지됩니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED':
        st.warning('새 Permanent Design이 생겨 기존 Apply decision이 superseded되었습니다. 현재 Design source 기준으로 다시 Human Review하세요.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY':
        st.success('Manual Permanent Stage-1 Apply Permit ISSUED · 이 permit은 외부/수동 Stage-1 activation만 허용합니다. Permanent Apply Authorization/Runtime Authorization/Execution Authorization은 NONE입니다.')
    elif _pca_state == 'PERMANENT_CHANGE_APPLY_REJECTED':
        st.info('Human Permanent Change Apply decision = REJECT · 실제 permanent apply는 없습니다.')
    st.dataframe(_ct_permanent_change_apply_queue, width='stretch', hide_index=True)
    if _ct_latest_permanent_change_apply:
        _pca_integrity = permanent_change_apply_snapshot_integrity(_ct_latest_permanent_change_apply)
        st.caption(f"Latest Permanent Change Apply · {_ct_latest_permanent_change_apply.get('permanent_change_apply_id', '')} · {_ct_latest_permanent_change_apply.get('apply_decision', '')} · Integrity {_pca_integrity['status']}")
    if _pca_state == 'PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED':
        _pca_decision = st.selectbox('Human Permanent Change Apply Decision', ['ISSUE_MANUAL_STAGE1_APPLY_PERMIT', 'REJECT', 'DEFER'], key='permanent_change_apply_decision')
        _pca_scope_max = max(0.01, float(_ct_permanent_change_apply['initial_stage_scope_pct']))
        _pca_scope = st.number_input('Stage-1 Permit Scope', min_value=0.01, max_value=float(min(0.1, _pca_scope_max)), value=float(min(0.05, _pca_scope_max)), step=0.01, format='%.2f', key='permanent_change_apply_scope')
        _pca_window = st.number_input('Manual Activation Window (hours)', min_value=1, max_value=168, value=24, step=1, key='permanent_change_apply_window')
        _pca_detail = st.text_area('Permanent Change Apply Review rationale', value='', key='permanent_change_apply_detail', placeholder='locked design, baseline/candidate/artifact, stage-1 scope, rollback/monitoring readiness, manual external apply only, no auto escalation을 60자 이상 기록')
        _pca_c1 = st.checkbox('현재 immutable Permanent Change Design source id/hash/integrity를 검토했습니다.', key='permanent_apply_design_source_reviewed')
        _pca_c2 = st.checkbox('Permanent Change Design audit integrity와 PERMANENT_DESIGN_LOCKED_NO_APPLY permission을 검증했습니다.', key='permanent_apply_design_integrity')
        _pca_c3 = st.checkbox('Prior baseline/rollback target이 여전히 현재 source와 일치함을 재검증했습니다.', key='permanent_apply_baseline_revalidated')
        _pca_c4 = st.checkbox('Permanent candidate parameter/model artifact identity를 재검증했습니다.', key='permanent_apply_candidate_verified')
        _pca_c5 = st.checkbox('Permit scope가 locked Initial Stage Scope 이하임을 확인했습니다.', key='permanent_apply_stage1_scope')
        _pca_c6 = st.checkbox('Stage-1 rollout이 다른 stage와 격리되며 자동 확대되지 않음을 확인했습니다.', key='permanent_apply_stage_isolation')
        _pca_c7 = st.checkbox('Manual activation window와 변경 가능 시간을 검토했습니다.', key='permanent_apply_change_window')
        _pca_c8 = st.checkbox('Prior baseline/artifact rollback 경로와 rollback observation window가 준비되어 있음을 확인했습니다.', key='permanent_apply_rollback_ready')
        _pca_c9 = st.checkbox('Proof Clock, post-change outcome, drift/degradation monitoring이 준비되어 있음을 확인했습니다.', key='permanent_apply_monitoring_ready')
        _pca_c10 = st.checkbox('실제 Stage-1 적용은 이 OS가 자동 수행하지 않고 외부에서 수동으로 수행함을 확인했습니다.', key='permanent_apply_manual_external')
        _pca_c11 = st.checkbox('Stage-1 성공이 다음 stage로 자동 escalation되지 않음을 확인했습니다.', key='permanent_apply_no_auto_stage')
        _pca_c12 = st.checkbox('이 Permit 저장이 full-scope permanent apply를 자동 승인하지 않음을 확인했습니다.', key='permanent_apply_no_auto_permanent')
        _pca_c13 = st.checkbox('이 Permit 저장이 자동 Recalibration을 승인하지 않음을 확인했습니다.', key='permanent_apply_no_recal')
        _pca_c14 = st.checkbox('이 Permit 저장이 자동 Capacity 변경을 승인하지 않음을 확인했습니다.', key='permanent_apply_no_capacity')
        _pca_c15 = st.checkbox('이 Permit 저장이 투자 실행/주문 권한을 생성하지 않음을 확인했습니다.', key='permanent_apply_no_execution')
        _pca_c16 = st.checkbox('현재 Permanent Change Apply decision을 최종 Human Review했습니다.', key='permanent_apply_human_review')
        _pca_note = st.text_input('Permanent Change Apply Snapshot 메모', value='', key='permanent_change_apply_note', placeholder='예: manual stage1 permit only / reject / defer')
        if st.button('Operations Flow Permanent Change Apply Decision 저장', key='permanent_change_apply_save'):
            try:
                _pca_row = build_flow_permanent_change_apply_lock(_ct_permanent_change_apply, apply_decision=_pca_decision, permit_scope_pct=_pca_scope, permit_activation_window_hours=int(_pca_window), apply_detail=_pca_detail, design_source_reviewed=_pca_c1, design_integrity_verified=_pca_c2, baseline_revalidated_confirmed=_pca_c3, candidate_artifact_verified=_pca_c4, stage1_scope_confirmed=_pca_c5, staged_rollout_isolation_confirmed=_pca_c6, change_window_reviewed=_pca_c7, rollback_ready_confirmed=_pca_c8, monitoring_ready_confirmed=_pca_c9, manual_external_apply_only_confirmed=_pca_c10, no_auto_stage_escalation_confirmed=_pca_c11, no_auto_permanent_apply_confirmed=_pca_c12, no_auto_recalibration_confirmed=_pca_c13, no_auto_capacity_confirmed=_pca_c14, no_execution_authorization_confirmed=_pca_c15, human_review_confirmed=_pca_c16, note=_pca_note)
                _pca_hist = load_csv('operations_flow_permanent_change_apply_snapshots.csv')
                for _col in FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS:
                    if _col not in _pca_hist.columns:
                        _pca_hist[_col] = ''
                _pca_hist = pd.concat([_pca_hist[FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS], pd.DataFrame([_pca_row])], ignore_index=True)
                verified_save_feedback(_pca_hist, 'operations_flow_permanent_change_apply_snapshots.csv', f"Permanent Change Apply 저장 · {_pca_row['apply_decision']} · {_pca_row['apply_state']} · Permission {_pca_row['permanent_change_apply_permission']} · Permanent Change Apply Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('Permanent Change Apply Preflight는 locked Permanent Design에서 Stage-1 manual permit만 검토합니다. ISSUE_MANUAL_STAGE1_APPLY_PERMIT도 actual mutation을 수행하지 않으며 별도 Permanent Runtime/Activation Gate가 필요합니다.')
    _ct_permanent_change_runtime_history = load_csv('operations_flow_permanent_change_runtime_events.csv')
    _ct_permanent_change_runtime = build_flow_permanent_change_runtime(_ct_permanent_change_apply, _ct_permanent_change_apply_history, _ct_permanent_change_runtime_history)
    _ct_permanent_change_runtime_queue = build_flow_permanent_change_runtime_queue(_ct_permanent_change_runtime)
    _ct_latest_permanent_change_runtime = latest_permanent_change_runtime_event(_ct_permanent_change_runtime_history)
    st.subheader('1K-AJ. Permanent Change Runtime / External Manual Stage-1 Activation / Kill-Switch / Rollback Guard')
    pcr1, pcr2, pcr3, pcr4, pcr5, pcr6 = st.columns(6)
    pcr1.metric('Runtime State', _ct_permanent_change_runtime['runtime_state'])
    pcr2.metric('Runtime Event', _ct_permanent_change_runtime['runtime_event'] or '-')
    pcr3.metric('Stage-1 Scope', '-' if _ct_permanent_change_runtime['permit_scope_pct'] == 0 else f"{_ct_permanent_change_runtime['permit_scope_pct']:.1%}")
    pcr4.metric('Activation Receipt', _ct_permanent_change_runtime['activation_receipt_ref'] or '-')
    pcr5.metric('Runtime Permission', _ct_permanent_change_runtime['permanent_change_runtime_permission'])
    pcr6.metric('Execution Authorization', 'NONE')
    pcra1, pcra2, pcra3, pcra4, pcra5 = st.columns(5)
    pcra1.metric('Baseline', '-' if _ct_permanent_change_runtime['baseline_value'] == 0 else f"{_ct_permanent_change_runtime['baseline_value']:.4f}")
    pcra2.metric('Candidate', '-' if _ct_permanent_change_runtime['candidate_value'] == 0 else f"{_ct_permanent_change_runtime['candidate_value']:.4f}")
    pcra3.metric('Observed Pre', '-' if _ct_permanent_change_runtime['observed_pre_value'] == 0 else f"{_ct_permanent_change_runtime['observed_pre_value']:.4f}")
    pcra4.metric('Observed Post/Current', '-' if _ct_permanent_change_runtime['observed_post_value'] == 0 and _ct_permanent_change_runtime['observed_current_value'] == 0 else f"{max(_ct_permanent_change_runtime['observed_post_value'], _ct_permanent_change_runtime['observed_current_value']):.4f}")
    pcra5.metric('Rollback', 'REQUIRED' if _ct_permanent_change_runtime['rollback_required'] else 'CONFIRMED' if _ct_permanent_change_runtime['rollback_confirmed'] else 'ARMED')
    _pcr_state = _ct_permanent_change_runtime['runtime_state']
    if _pcr_state == 'PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT':
        st.info('Permanent Change Runtime은 MANUAL_PERMANENT_STAGE1_APPLY_ONLY Permit이 발급된 뒤 시작합니다. 현재 단계에서는 activation event를 만들 필요가 없습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION':
        st.warning('Stage-1 activation 준비 상태입니다. 실제 변경은 OS가 수행하지 않습니다. 외부에서 수동 activation을 수행한 뒤 receipt와 observed pre/post evidence만 기록합니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1':
        st.warning('Permanent Stage-1 ACTIVE · rollback armed · 자동 Stage-2 escalation 및 full-scope permanent apply는 금지됩니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED':
        st.success('Stage-1 runtime CLOSE · 별도 Outcome Review 전에는 Stage-2로 자동 확대하지 않습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED':
        st.error('Kill-Switch LATCHED · 외부 수동 rollback 후 baseline restoration을 검증해야 합니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED':
        st.success('Rollback CONFIRMED · 새 Permanent Design/Apply Review 없이 재활성화하지 않습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED':
        st.warning('새 Permanent Apply Permit이 생겨 기존 Runtime event가 superseded되었습니다.')
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW':
        st.error('Apply Permit 또는 Runtime event integrity mismatch로 Runtime을 차단했습니다.')
    st.dataframe(_ct_permanent_change_runtime_queue, width='stretch', hide_index=True)
    if _ct_latest_permanent_change_runtime:
        _pcr_integrity = permanent_change_runtime_event_integrity(_ct_latest_permanent_change_runtime)
        st.caption(f"Latest Permanent Runtime · {_ct_latest_permanent_change_runtime.get('permanent_change_runtime_event_id', '')} · {_ct_latest_permanent_change_runtime.get('runtime_event', '')} · Integrity {_pcr_integrity['status']}")
    if _pcr_state == 'PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION':
        _pcr_receipt = st.text_input('External Manual Activation Receipt / Reference', value='', key='permanent_runtime_activation_receipt', placeholder='예: OPS-CHANGE-20261004-001')
        _pcr_pre = st.number_input('Observed Pre-activation Value', value=float(_ct_permanent_change_runtime['baseline_value']), format='%.6f', key='permanent_runtime_observed_pre')
        _pcr_post = st.number_input('Observed Post-activation Value', value=float(_ct_permanent_change_runtime['candidate_value']), format='%.6f', key='permanent_runtime_observed_post')
        _pcr_detail = st.text_area('Stage-1 Activation Evidence / Rationale', value='', key='permanent_runtime_activation_detail', placeholder='external manual activation, source permit, observed baseline/candidate, scope isolation, monitoring/rollback readiness를 60자 이상 기록')
        _pcr_c1 = st.checkbox('실제 Stage-1 변경은 이 OS가 아니라 외부에서 수동으로 수행되었음을 확인했습니다.', key='permanent_runtime_external_manual')
        _pcr_c2 = st.checkbox('현재 immutable Permanent Apply Permit id/hash/integrity를 검토했습니다.', key='permanent_runtime_source_permit')
        _pcr_c3 = st.checkbox('Observed pre-activation value가 locked baseline과 일치함을 확인했습니다.', key='permanent_runtime_baseline_obs')
        _pcr_c4 = st.checkbox('Observed post-activation value/candidate artifact가 locked candidate와 일치함을 확인했습니다.', key='permanent_runtime_candidate_obs')
        _pcr_c5 = st.checkbox('Stage-1 scope가 Permit 범위 안에서 격리되어 있음을 확인했습니다.', key='permanent_runtime_scope_isolation')
        _pcr_c6 = st.checkbox('Stage-1 monitoring과 rollback readiness가 활성화되어 있음을 확인했습니다.', key='permanent_runtime_monitoring')
        _pcr_c7 = st.checkbox('Stage-1 성공이 Stage-2로 자동 escalation되지 않음을 확인했습니다.', key='permanent_runtime_no_auto_stage')
        _pcr_c8 = st.checkbox('이 Runtime event가 full-scope permanent apply를 자동 승인하지 않음을 확인했습니다.', key='permanent_runtime_no_auto_perm')
        _pcr_c9 = st.checkbox('현재 activation evidence를 최종 Human Review했습니다.', key='permanent_runtime_human_review')
        _pcr_note = st.text_input('Permanent Runtime Event 메모', value='', key='permanent_runtime_event_note')
        if st.button('Permanent Stage-1 ACTIVATE Event 저장', key='permanent_runtime_activate'):
            try:
                _pcr_row = build_flow_permanent_change_runtime_event(_ct_permanent_change_runtime, runtime_event='ACTIVATE', activation_receipt_ref=_pcr_receipt, observed_pre_value=_pcr_pre, observed_post_value=_pcr_post, runtime_detail=_pcr_detail, external_manual_activation_confirmed=_pcr_c1, source_permit_reviewed=_pcr_c2, baseline_observation_confirmed=_pcr_c3, candidate_observation_confirmed=_pcr_c4, scope_isolation_confirmed=_pcr_c5, monitoring_active_confirmed=_pcr_c6, no_auto_stage_escalation_confirmed=_pcr_c7, no_auto_permanent_apply_confirmed=_pcr_c8, human_review_confirmed=_pcr_c9, note=_pcr_note)
                _pcr_hist = load_csv('operations_flow_permanent_change_runtime_events.csv')
                for _col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
                    if _col not in _pcr_hist.columns:
                        _pcr_hist[_col] = ''
                _pcr_hist = pd.concat([_pcr_hist[FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS], pd.DataFrame([_pcr_row])], ignore_index=True)
                verified_save_feedback(_pcr_hist, 'operations_flow_permanent_change_runtime_events.csv', f"Permanent Runtime ACTIVATE 저장 · {_pcr_row['runtime_state']} · Stage {_pcr_row['permit_stage_number']} · Scope {_pcr_row['permit_scope_pct']:.1%} · Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1':
        _pcr_action = st.selectbox('Stage-1 Runtime Event', ['CLOSE', 'KILL_SWITCH'], key='permanent_runtime_active_action')
        _pcr_current = st.number_input('Observed Current Value', value=float(_ct_permanent_change_runtime['candidate_value']), format='%.6f', key='permanent_runtime_observed_current')
        _pcr_trigger = st.selectbox('Kill-Switch Trigger', [''] + sorted(PERMANENT_CHANGE_KILL_TRIGGERS), key='permanent_runtime_kill_trigger')
        _pcr_detail = st.text_area('Runtime Close / Kill-Switch Evidence', value='', key='permanent_runtime_active_detail', placeholder='CLOSE면 stage-1 evidence/outcome-review handoff를, KILL_SWITCH면 trigger와 rollback initiation을 60자 이상 기록')
        _pcr_monitor = st.checkbox('현재 monitoring evidence를 검토했습니다.', key='permanent_runtime_active_monitor')
        _pcr_scope = st.checkbox('Stage-1 scope isolation이 유지되었음을 확인했습니다.', key='permanent_runtime_active_scope')
        _pcr_no_stage = st.checkbox('Stage-2 자동 escalation이 없음을 확인했습니다.', key='permanent_runtime_active_no_stage')
        _pcr_no_perm = st.checkbox('Full-scope permanent apply 자동 승인이 없음을 확인했습니다.', key='permanent_runtime_active_no_perm')
        _pcr_rollback_start = st.checkbox('Kill-Switch 선택 시 외부 수동 rollback을 즉시 시작했음을 확인했습니다.', key='permanent_runtime_rollback_start')
        _pcr_human = st.checkbox('현재 Runtime event를 최종 Human Review했습니다.', key='permanent_runtime_active_human')
        if st.button('Permanent Stage-1 Runtime Event 저장', key='permanent_runtime_active_save'):
            try:
                _pcr_row = build_flow_permanent_change_runtime_event(_ct_permanent_change_runtime, runtime_event=_pcr_action, observed_current_value=_pcr_current, kill_switch_trigger=_pcr_trigger, runtime_detail=_pcr_detail, scope_isolation_confirmed=_pcr_scope, monitoring_active_confirmed=_pcr_monitor, no_auto_stage_escalation_confirmed=_pcr_no_stage, no_auto_permanent_apply_confirmed=_pcr_no_perm, rollback_initiated_confirmed=_pcr_rollback_start, human_review_confirmed=_pcr_human)
                _pcr_hist = load_csv('operations_flow_permanent_change_runtime_events.csv')
                for _col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
                    if _col not in _pcr_hist.columns:
                        _pcr_hist[_col] = ''
                _pcr_hist = pd.concat([_pcr_hist[FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS], pd.DataFrame([_pcr_row])], ignore_index=True)
                verified_save_feedback(_pcr_hist, 'operations_flow_permanent_change_runtime_events.csv', f"Permanent Runtime {_pcr_row['runtime_event']} 저장 · {_pcr_row['runtime_state']} · Permanent Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    elif _pcr_state == 'PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED':
        _pcr_restored = st.number_input('Observed Restored Value', value=float(_ct_permanent_change_runtime['rollback_target_value']), format='%.6f', key='permanent_runtime_restored_value')
        _pcr_detail = st.text_area('Rollback Completion / Baseline Restoration Evidence', value='', key='permanent_runtime_rollback_detail', placeholder='external manual rollback completion, restored baseline, integrity/monitoring 상태를 60자 이상 기록')
        _pcr_done = st.checkbox('외부 수동 rollback이 완료되었음을 확인했습니다.', key='permanent_runtime_rollback_done')
        _pcr_baseline = st.checkbox('Observed restored value가 locked rollback target/baseline과 일치함을 확인했습니다.', key='permanent_runtime_rollback_baseline')
        _pcr_no_stage = st.checkbox('Rollback 후 자동 Stage escalation이 없음을 확인했습니다.', key='permanent_runtime_rollback_no_stage')
        _pcr_no_perm = st.checkbox('Rollback 후 자동 permanent apply가 없음을 확인했습니다.', key='permanent_runtime_rollback_no_perm')
        _pcr_human = st.checkbox('Rollback completion evidence를 최종 Human Review했습니다.', key='permanent_runtime_rollback_human')
        if st.button('Permanent Runtime ROLLBACK_CONFIRM 저장', key='permanent_runtime_rollback_confirm'):
            try:
                _pcr_row = build_flow_permanent_change_runtime_event(_ct_permanent_change_runtime, runtime_event='ROLLBACK_CONFIRM', observed_restored_value=_pcr_restored, runtime_detail=_pcr_detail, no_auto_stage_escalation_confirmed=_pcr_no_stage, no_auto_permanent_apply_confirmed=_pcr_no_perm, rollback_completed_confirmed=_pcr_done, baseline_restore_confirmed=_pcr_baseline, human_review_confirmed=_pcr_human)
                _pcr_hist = load_csv('operations_flow_permanent_change_runtime_events.csv')
                for _col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
                    if _col not in _pcr_hist.columns:
                        _pcr_hist[_col] = ''
                _pcr_hist = pd.concat([_pcr_hist[FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS], pd.DataFrame([_pcr_row])], ignore_index=True)
                verified_save_feedback(_pcr_hist, 'operations_flow_permanent_change_runtime_events.csv', f"Permanent Runtime ROLLBACK_CONFIRM 저장 · restored {_pcr_row['observed_restored_value']:.4f} · Runtime Authorization = NONE · Execution Authorization = NONE.", rerun=False)
            except ValueError as exc:
                st.warning(str(exc))
    st.caption('v1.53 Permanent Runtime은 자동 mutation 엔진이 아닙니다. ACTIVATE는 외부 수동 activation receipt/evidence를 기록하고, CLOSE/KILL_SWITCH/ROLLBACK_CONFIRM도 immutable evidence registry만 수행합니다. Permanent Runtime Authorization과 Execution Authorization은 NONE입니다.')
    st.subheader('2. 오늘의 안전한 운영 순서')
    _ct_sequence = build_daily_operating_sequence(_ct_tower)
    st.dataframe(_ct_sequence, width='stretch', hide_index=True)
    st.subheader('3. Core Gate Snapshot')
    cg1, cg2, cg3, cg4 = st.columns(4)
    cg1.metric('Learning', _ct_learning['release_gate'])
    cg2.metric('Forecast', _ct_forecast['release_gate'])
    cg3.metric('Recovery', _ct_recovery['recovery_release']['release_gate'])
    cg4.metric('Schema', _ct_schema_release['release_gate'])
    cg5, cg6, cg7, cg8 = st.columns(4)
    cg5.metric('Integration', _ct_integration_summary['status'])
    cg6.metric('CSV FAIL', _ct_csv_fail)
    cg7.metric('OVERDUE', _ct_queue_summary['overdue'])
    cg8.metric('TODAY / NOW', _ct_queue_summary['attention_now'])
    st.caption('Control Tower는 기존 원본 Gate를 복제해 승인하지 않습니다. 원본 화면의 상태를 압축해 어디를 먼저 볼지 안내하며 주문/매매를 실행하지 않습니다.')
