from __future__ import annotations
if True:
    st.title('Primary Source Monitor / Evidence Candidate Inbox')
    st.caption('Watchlist의 DART 공시를 후보함으로 모읍니다. 자동 분류는 검토 우선순위일 뿐 긍정/부정 투자판단이 아닙니다.')
    st.info('공시 제목만으로 Evidence Signal을 만들지 않습니다. 원문을 직접 확인한 뒤 Evidence Intake에서 Fact · Interpretation · Contrary Evidence를 분리해 기록합니다.')
    source_candidates = normalize_source_candidates(load_csv('source_candidates.csv'))
    source_summary = source_monitor_summary(source_candidates)
    s1, s2, s3, s4, s5, s6 = st.columns(6)
    s1.metric('NEW', source_summary['new'])
    s2.metric('IN REVIEW', source_summary['in_review'])
    s3.metric('HIGH Open', source_summary['high_open'])
    s4.metric('PROMOTED', source_summary['promoted'])
    s5.metric('DISMISSED', source_summary['dismissed'])
    s6.metric('Integrity', source_summary['integrity_issues'])
    st.subheader('1. Watchlist DART Scan')
    sm_key = st.session_state.get('dart_api_key', os.getenv('DART_API_KEY', ''))
    sm_cache = ROOT / 'data' / 'dart_corp_codes.csv'
    c1, c2, c3 = st.columns([1, 1, 2])
    sm_days = c1.number_input('Lookback Days', min_value=1, max_value=90, value=int(settings.get('source_monitor_lookback_days', 14)), step=1, key='source_monitor_lookback_days_ui')
    c2.metric('Corp Code Cache', 'READY' if sm_cache.exists() else 'MISSING')
    c3.caption('새 Candidate는 DART 접수번호 기준으로 중복 제거합니다. 기존 NEW/IN REVIEW/PROMOTED/DISMISSED 상태는 재스캔해도 유지됩니다.')
    if not sm_key:
        st.warning('DART API Key가 없습니다. OpenDART Auto에서 Key를 입력하세요.')
        st.button('OpenDART Auto로 이동', on_click=_navigate, args=('OpenDART Auto',), key='source_monitor_to_dart')
    elif not sm_cache.exists():
        st.warning('dart_corp_codes.csv가 없습니다. OpenDART Auto에서 고유번호 목록을 먼저 동기화하세요.')
        st.button('OpenDART Auto로 이동', on_click=_navigate, args=('OpenDART Auto',), key='source_monitor_to_dart_codes')
    elif st.button('Watchlist DART Scan 실행', type='primary', key='source_monitor_scan'):
        try:
            corp_codes = pd.read_csv(sm_cache, dtype=str)
            sm_end = date.today()
            sm_begin = sm_end - timedelta(days=int(sm_days))
            raw_disclosures = recent_disclosures_for_watchlist(sm_key, watchlist, corp_codes, sm_begin.strftime('%Y%m%d'), sm_end.strftime('%Y%m%d'), 50)
            updated_candidates, scan_stats = ingest_disclosures(raw_disclosures, source_candidates, watchlist=watchlist)
            save_csv(updated_candidates, 'source_candidates.csv')
            source_candidates = updated_candidates
            st.session_state['source_monitor_last_scan'] = scan_stats
            st.success(f"DART Scan 저장 완료 · 신규 {scan_stats['added']}건 / 복구 {scan_stats.get('repaired', 0)}건 / 조회 {scan_stats['seen']}건 / 오류 {scan_stats['errors']}건")
        except Exception as e:
            st.error(f'DART Scan 실패: {e}')
    last_scan = st.session_state.get('source_monitor_last_scan')
    if last_scan:
        st.caption(f"최근 Scan: 신규 {last_scan.get('added', 0)} · 복구 {last_scan.get('repaired', 0)} · 조회 {last_scan.get('seen', 0)} · SKIP {last_scan.get('skipped', 0)} · ERROR {last_scan.get('errors', 0)}")
    dup_summary = duplicate_receipt_summary(source_candidates)
    if dup_summary['duplicate_rows'] > 0:
        st.subheader('1-2. Candidate Integrity Repair')
        st.warning(f"동일 DART 접수번호 중복행 {dup_summary['duplicate_rows']}건 · 중복 접수번호 {dup_summary['duplicate_receipts']}개가 있습니다. 같은 receipt_no만 병합하며 PROMOTED Evidence Link와 검토상태를 보존합니다.")
        dup_groups = dup_summary.get('groups')
        if isinstance(dup_groups, pd.DataFrame) and (not dup_groups.empty):
            st.dataframe(dup_groups.head(100), width='stretch', hide_index=True)
        confirm_dedupe = st.checkbox('동일 receipt_no Candidate만 병합하고 PROMOTED/IN REVIEW 상태를 보존하는 정리를 실행합니다.', value=False, key='source_monitor_dedupe_confirm')
        if st.button('중복 접수번호 안전 정리', disabled=not confirm_dedupe, key='source_monitor_dedupe_apply'):
            try:
                cleaned, cleanup_stats = consolidate_duplicate_receipts(source_candidates)
                save_csv(cleaned, 'source_candidates.csv')
                st.session_state['_save_flash'] = ('success', f"Source Candidate 중복 정리 완료 · {cleanup_stats['before']}건 → {cleanup_stats['after']}건 · {cleanup_stats['merged_rows']}행 병합")
                st.rerun()
            except Exception as e:
                st.error(f'Candidate 중복 정리 실패: {e}')
    st.subheader('2. Candidate Inbox')
    enriched_candidates = enrich_source_candidates(source_candidates)
    status_filter = st.selectbox('상태 Filter', ['OPEN', 'ALL', 'NEW', 'IN REVIEW', 'PROMOTED', 'DISMISSED'], key='source_monitor_filter')
    if enriched_candidates.empty:
        st.info('Candidate가 없습니다. DART Scan을 실행하면 Watchlist 공시 후보가 여기에 쌓입니다.')
    else:
        status_series = enriched_candidates['candidate_status'].fillna('').astype(str).str.upper()
        if status_filter == 'OPEN':
            inbox = enriched_candidates.loc[status_series.isin(['NEW', 'IN REVIEW'])].copy()
        elif status_filter == 'ALL':
            inbox = enriched_candidates.copy()
        else:
            inbox = enriched_candidates.loc[status_series.eq(status_filter)].copy()
        if not inbox.empty:
            inbox['_receipt_sort'] = pd.to_datetime(inbox['receipt_date'], errors='coerce')
            priority_order = {'HIGH': 0, 'MEDIUM': 1, 'ROUTINE': 2}
            inbox['_priority_sort'] = inbox['monitor_priority'].fillna('ROUTINE').astype(str).str.upper().map(priority_order).fillna(9)
            inbox = inbox.sort_values(['_priority_sort', '_receipt_sort'], ascending=[True, False], na_position='last')
        view_cols = ['receipt_date', 'company', 'report_name', 'category', 'monitor_priority', 'candidate_status', 'attention_status', 'source_hash_status', 'days_open']
        if inbox.empty:
            st.info('현재 Filter에 해당하는 Candidate가 없습니다.')
        else:
            st.dataframe(inbox[[col for col in view_cols if col in inbox.columns]], width='stretch', hide_index=True)
    st.subheader('3. Candidate Review')
    if enriched_candidates.empty:
        st.info('검토할 Candidate가 없습니다.')
    else:
        candidate_labels = []
        candidate_lookup = {}
        for _, r in enriched_candidates.sort_values('receipt_date', ascending=False, na_position='last').iterrows():
            label = f"[{r.get('candidate_status', '')}] [{r.get('monitor_priority', '')}] {r.get('receipt_date', '')} · {r.get('company', '')} · {r.get('report_name', '')}"
            candidate_labels.append(label)
            candidate_lookup[label] = r.to_dict()
        selected_label = st.selectbox('검토할 Candidate', candidate_labels, key='source_monitor_selected_candidate')
        selected_candidate = candidate_lookup[selected_label]
        r1, r2, r3, r4 = st.columns(4)
        r1.metric('Status', selected_candidate.get('candidate_status', '-') or '-')
        r2.metric('Priority', selected_candidate.get('monitor_priority', '-') or '-')
        r3.metric('Category', selected_candidate.get('category', '-') or '-')
        r4.metric('Hash', selected_candidate.get('source_hash_status', '-') or '-')
        st.write(f"**Why Review:** {selected_candidate.get('relevance_reason', '')}")
        source_url_selected = str(selected_candidate.get('source_url', '') or '').strip()
        if source_url_selected:
            st.markdown(f'[DART 원문 열기]({source_url_selected})')
        else:
            st.warning('이 Candidate는 DART URL이 없습니다. DART에서 해당 종목·공시일의 실제 공시를 다시 조회한 뒤 직접 선택해 복구합니다.')
            company_name = str(selected_candidate.get('company', '') or '').strip()
            candidate_date_raw = selected_candidate.get('receipt_date', '')
            candidate_date_ts = pd.to_datetime(candidate_date_raw, errors='coerce')
            can_lookup = bool(sm_key and sm_cache.exists() and company_name)
            lookup_key = 'source_monitor_lookup_disclosures::' + str(selected_candidate.get('candidate_id', ''))
            lookup_button_label = '이 날짜 DART 공시 다시 조회' if not pd.isna(candidate_date_ts) else '최근 DART 공시 다시 조회'
            if pd.isna(candidate_date_ts):
                st.caption('Candidate 공시일도 비어 있어 최근 Lookback 기간의 해당 종목 공시를 불러옵니다. 실제 공시를 직접 선택해 주세요.')
            if st.button(lookup_button_label, disabled=not can_lookup, key='source_monitor_lookup_button::' + str(selected_candidate.get('candidate_id', ''))):
                try:
                    repair_watchlist = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(company_name)].copy()
                    if repair_watchlist.empty:
                        raise ValueError('Watchlist에서 Candidate 종목을 찾지 못했습니다.')
                    corp_codes = pd.read_csv(sm_cache, dtype=str)
                    if pd.isna(candidate_date_ts):
                        repair_end = date.today()
                        repair_start = repair_end - timedelta(days=max(int(sm_days), 1))
                        repair_bgn = repair_start.strftime('%Y%m%d')
                        repair_end_text = repair_end.strftime('%Y%m%d')
                    else:
                        repair_bgn = candidate_date_ts.strftime('%Y%m%d')
                        repair_end_text = repair_bgn
                    fresh_disclosures = recent_disclosures_for_watchlist(sm_key, repair_watchlist, corp_codes, repair_bgn, repair_end_text, 100)
                    valid_rows = []
                    if fresh_disclosures is not None and (not fresh_disclosures.empty):
                        for _, raw in fresh_disclosures.iterrows():
                            if str(raw.get('status', 'OK') or 'OK').upper() != 'OK':
                                continue
                            valid_rows.append(raw.to_dict())
                    st.session_state[lookup_key] = valid_rows
                    if not valid_rows:
                        st.warning('선택한 조회 범위에서 복구 가능한 DART 공시를 찾지 못했습니다.')
                    else:
                        st.success(f'DART 공시 {len(valid_rows)}건을 불러왔습니다. 아래에서 실제 공시를 선택하세요.')
                except Exception as e:
                    st.error(f'DART 공시 재조회 실패: {e}')
            lookup_rows = st.session_state.get(lookup_key, [])
            if lookup_rows:
                disclosure_options = []
                disclosure_map = {}
                for raw in lookup_rows:
                    receipt_no = str(raw.get('rcept_no', '') or '').strip()
                    report_name = str(raw.get('report_nm', '') or '').strip()
                    filer = str(raw.get('flr_nm', '') or '').strip()
                    label = f"{report_name or '(제목 없음)'} · {receipt_no or '(접수번호 없음)'} · {filer or company_name}"
                    disclosure_options.append(label)
                    disclosure_map[label] = raw
                selected_disclosure_label = st.selectbox('복구에 사용할 실제 DART 공시', disclosure_options, key='source_monitor_disclosure_choice::' + str(selected_candidate.get('candidate_id', '')))
                selected_raw = disclosure_map[selected_disclosure_label]
                selected_receipt = str(selected_raw.get('rcept_no', '') or '').strip()
                st.caption(f"선택한 공시를 원문과 대조한 뒤 복구하세요. 접수번호: {selected_receipt or '-'}")
                confirm_selected = st.checkbox('회사와 공시 내용을 확인했고 이 DART 공시가 해당 Candidate와 동일한 공시입니다.', value=False, key='source_monitor_repair_confirm::' + str(selected_candidate.get('candidate_id', '')))
                if st.button('선택한 DART 공시로 Candidate 복구', disabled=not confirm_selected, type='primary', key='source_monitor_apply_selected_repair::' + str(selected_candidate.get('candidate_id', ''))):
                    try:
                        repaired_candidate = repair_candidate_with_selected_disclosure(selected_candidate, selected_raw, watchlist=watchlist)
                        candidate_id = str(selected_candidate.get('candidate_id', '') or '')
                        repaired_all = source_candidates.copy()
                        hit_mask = repaired_all['candidate_id'].fillna('').astype(str).eq(candidate_id)
                        if int(hit_mask.sum()) != 1:
                            raise ValueError('Candidate ID가 원장에서 유일하지 않습니다.')
                        for col in SOURCE_CANDIDATE_COLS:
                            repaired_all.loc[hit_mask, col] = repaired_candidate.get(col, '')
                        save_csv(repaired_all, 'source_candidates.csv')
                        st.session_state.pop(lookup_key, None)
                        st.session_state['_save_flash'] = ('success', '선택한 DART 공시로 Candidate 메타데이터를 복구했습니다.')
                        st.rerun()
                    except Exception as e:
                        st.error(f'Candidate 복구 실패: {e}')
        candidate_status = str(selected_candidate.get('candidate_status', '') or '').upper()
        candidate_hash_ok = str(selected_candidate.get('source_hash_status', '') or '').upper() == 'OK'
        if not candidate_hash_ok:
            st.error('Candidate Hash가 OK가 아닙니다. Evidence 이동보다 Source Candidate 무결성을 먼저 확인하세요.')
        elif candidate_status in {'NEW', 'IN REVIEW'}:
            dismiss_reason = st.text_input('Dismiss Reason', value='', key='source_monitor_dismiss_reason::' + str(selected_candidate.get('candidate_id', '')), placeholder='Evidence Packet으로 만들 필요가 없는 구체적 이유')
            a1, a2 = st.columns(2)
            a1.button('Evidence Intake로 검토 이동', type='primary', key='source_monitor_promote::' + str(selected_candidate.get('candidate_id', '')), on_click=_source_candidate_handoff_callback, args=(dict(selected_candidate), source_candidates.copy()))
            if a2.button('Evidence 불필요로 종료', key='source_monitor_dismiss::' + str(selected_candidate.get('candidate_id', ''))):
                try:
                    updated_candidates = mark_candidate_status(source_candidates, str(selected_candidate.get('candidate_id', '')), 'DISMISSED', dismissed_reason=dismiss_reason)
                    verified_save_feedback(updated_candidates, 'source_candidates.csv', 'Source Candidate를 DISMISSED로 저장했습니다.', rerun=True)
                except Exception as e:
                    st.error(f'Candidate 종료 실패: {e}')
        else:
            st.info('이미 종료된 Candidate입니다. PROMOTED는 연결된 Evidence Packet에서 계속 검토합니다.')
    st.caption('Monitoring Priority는 공시가 투자 가설에 미칠 수 있는 검토 긴급도입니다. 매수·매도 방향, Evidence Signal, Valuation 변경을 자동 판단하지 않습니다.')
