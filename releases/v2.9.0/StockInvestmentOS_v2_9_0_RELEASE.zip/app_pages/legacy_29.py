from __future__ import annotations
if True:
    st.title(f'Fundamental Engine / {VERSION}')
    st.caption('CFO → FCF → Owner Earnings → FCF/share → ROIC/iROIC를 감사 가능한 Source Chain으로 연결합니다.')
    st.info('v1.14.0-dev9는 pandas CSV float round-trip에서 발생한 v2 Hash 불일치를 해결한 stable schema v3를 사용하며, BLOCKED Snapshot은 재해시하지 않고 안전 폐기 후 다시 저장합니다. 사람이 Source를 확인하고 체크하기 전에는 계산에 사용하지 않습니다.')
    if watchlist.empty:
        st.warning('Watchlist가 비어 있습니다.')
    else:
        fundamental_names = watchlist['name'].fillna('').astype(str).tolist()
        fundamental_company = st.selectbox('종목', fundamental_names, key='fundamental_company')
        fundamental_row = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(fundamental_company)].iloc[0]
        fundamental_code = str(fundamental_row.get('code', '') or '').strip().zfill(6)
        saved_dart = load_csv('dart_snapshots.csv')
        saved_match = pd.DataFrame()
        if not saved_dart.empty and 'stock_code' in saved_dart.columns:
            saved_codes = saved_dart['stock_code'].fillna('').astype(str).str.replace('\\.0$', '', regex=True).str.zfill(6)
            saved_match = saved_dart.loc[saved_codes.eq(fundamental_code)].copy()
        source_options = []
        session_summary = st.session_state.get('dart_summary')
        session_code = str(st.session_state.get('dart_stock_code', '') or '').strip().zfill(6)
        if isinstance(session_summary, dict) and session_code == fundamental_code:
            source_options.append('현재 OpenDART 세션')
        if not saved_match.empty:
            source_options.append('저장된 최신 DART Snapshot')
        st.subheader('1. Financial Source')
        if not source_options:
            st.warning(f'{fundamental_company}({fundamental_code})의 DART 재무 Snapshot이 없습니다. 먼저 OpenDART Auto에서 최근 재무 자동수집을 실행하세요.')
            st.button('OpenDART Auto로 이동', type='primary', on_click=_navigate, args=('OpenDART Auto',), key=f'fundamental_to_dart::{fundamental_company}')
        else:
            source_choice = st.radio('재무 Source', source_options, horizontal=True, key=f'fundamental_source::{fundamental_company}')
            if source_choice == '현재 OpenDART 세션':
                fundamental_summary = dict(session_summary)
                _meta = st.session_state.get('dart_meta', {}) or {}
                fundamental_meta = {'source_kind': 'OpenDART Session', 'business_year': _meta.get('business_year', ''), 'period': _meta.get('period', ''), 'report_code': _meta.get('report_code', ''), 'fs_div': _meta.get('fs_div', ''), 'corp_code': st.session_state.get('dart_corp_code', '')}
            else:
                saved_source_row = saved_match.iloc[-1].to_dict()
                fundamental_summary = dict(saved_source_row)
                fundamental_meta = {'source_kind': 'Saved DART Snapshot', 'business_year': saved_source_row.get('business_year', ''), 'period': saved_source_row.get('period', ''), 'report_code': saved_source_row.get('report_code', ''), 'fs_div': saved_source_row.get('fs_div', ''), 'corp_code': saved_source_row.get('corp_code', '')}
            s1, s2, s3, s4 = st.columns(4)
            s1.metric('Source Period', f"{fundamental_meta.get('business_year', '-')} {fundamental_meta.get('period', '-')}".strip())
            s2.metric('FS', fundamental_meta.get('fs_div', '-') or '-')
            s3.metric('Extraction Integrity', str(fundamental_summary.get('extraction_integrity_status', '-') or '-'))
            s4.metric('FCF Extraction', str(fundamental_summary.get('fcf_proxy_review_status', '-') or '-'))
            if str(fundamental_summary.get('extraction_integrity_status', '')).upper() != 'PASS':
                st.warning('DART Extraction Integrity가 PASS가 아닙니다. 계산 전에 원 재무제표와 계정 Source를 확인하세요.')
            f1, f2, f3, f4 = st.columns(4)
            f1.metric('Revenue', krw(fundamental_summary.get('revenue')))
            f2.metric('Operating Profit', krw(fundamental_summary.get('operating_profit')))
            f3.metric('CFO', krw(fundamental_summary.get('cfo')))
            f4.metric('FCF proxy', krw(fundamental_summary.get('fcf_proxy')))
            st.caption('FCF proxy = CFO - abs(PPE acquisition CAPEX). H1/Q1/Q3 수치는 해당 누적기간 기준이며 LTM/연환산 값이 아닙니다.')
            st.subheader('2. Source-backed Suggestions')
            st.caption('제안값은 자동 승인값이 아닙니다. `제안 적용`은 입력칸에 숫자만 복사하며, 옆의 Human-confirmed 체크박스는 사용자가 원 Source를 확인한 뒤 직접 선택해야 합니다.')
            share_source_key = f"fundamental_share_source::{fundamental_company}::{fundamental_meta.get('business_year', '')}::{fundamental_meta.get('report_code', '')}"
            share_summary = st.session_state.get(share_source_key, {})
            dart_key_for_fundamental = str(st.session_state.get('dart_api_key', os.getenv('DART_API_KEY', '')) or '').strip()
            source_corp = str(fundamental_meta.get('corp_code', '') or '').strip()
            source_year = str(fundamental_meta.get('business_year', '') or '').strip()
            source_report_code = str(fundamental_meta.get('report_code', '') or '').strip()
            sh1, sh2 = st.columns([1, 3])
            if sh1.button('OpenDART 주식수 Source 불러오기', key=f'load_share_source::{fundamental_company}', disabled=not bool(dart_key_for_fundamental and source_corp and source_year and source_report_code)):
                try:
                    _share_raw = stock_total_status(dart_key_for_fundamental, source_corp, int(float(source_year)), source_report_code)
                    _share_summary = summarize_share_count(_share_raw)
                    st.session_state[share_source_key] = _share_summary
                    st.session_state[f'{share_source_key}::raw'] = _share_raw
                    st.rerun()
                except Exception as e:
                    st.error(f'주식수 Source 조회 실패: {e}')
            if not source_report_code:
                sh2.warning('현재 DART Snapshot에 report_code가 없습니다. OpenDART Auto에서 최근 재무 자동수집을 한 번 다시 실행하세요.')
            elif share_summary:
                sh2.success(f"주식수 Source 로드됨 · {share_summary.get('share_count_status', '-')} · {share_summary.get('share_count_basis', '-')}")
            else:
                sh2.info('주식수는 별도 OpenDART stock total-status Source입니다. 필요할 때만 불러옵니다.')
            suggestions = build_source_backed_suggestions(fundamental_summary, share_summary)
            sg1, sg2, sg3, sg4 = st.columns(4)
            _share_suggestion = suggestions.get('share_count_proxy')
            _tax_suggestion = suggestions.get('effective_tax_rate_proxy')
            _ic_suggestion = suggestions.get('invested_capital_proxy')
            sg1.metric('Share Count proxy', '-' if _share_suggestion is None else f'{_share_suggestion:,.0f}', help='OpenDART distributed shares proxy. Diluted EPS denominator와 동일하다고 가정하지 않습니다.')
            sg2.metric('Effective Tax Rate proxy', '-' if _tax_suggestion is None else f'{_tax_suggestion * 100:.2f}%')
            sg3.metric('Invested Capital proxy', krw(_ic_suggestion), help='Total Equity + Interest-bearing Debt proxy - Cash')
            sg4.metric('Maintenance CAPEX', 'MANUAL', help='구조화 공시만으로 Maintenance/Growth CAPEX를 신뢰성 있게 분리하지 않습니다.')
            st.caption(f"Share: {suggestions.get('share_count_status', 'MISSING')} · Tax: {suggestions.get('effective_tax_rate_status', 'MISSING')} · Invested Capital: {suggestions.get('invested_capital_status', 'MISSING')} · Maintenance CAPEX: NO_STRUCTURED_MAINTENANCE_SPLIT")
            if fundamental_summary.get('pretax_income') is None and fundamental_summary.get('total_equity') is None:
                st.warning('현재 재무 Source에는 v1.14 dev2의 Pretax/Tax/Equity 필드가 없습니다. connectors/dart.py 교체 후 OpenDART Auto에서 이 종목을 한 번 다시 수집하세요.')
            with st.expander('Source-backed Suggestion 근거', expanded=False):
                source_audit = pd.DataFrame([{'input': 'Share Count proxy', 'value': _share_suggestion, 'source': 'OpenDART stockTotqySttus', 'basis': suggestions.get('share_count_basis', ''), 'status': suggestions.get('share_count_status', '')}, {'input': 'Effective Tax Rate proxy', 'value': _tax_suggestion, 'source': f"{fundamental_summary.get('pretax_income_source_account', '') or '-'} / {fundamental_summary.get('income_tax_expense_source_account', '') or '-'}", 'basis': suggestions.get('tax_rate_basis', ''), 'status': suggestions.get('effective_tax_rate_status', '')}, {'input': 'Invested Capital proxy', 'value': _ic_suggestion, 'source': f"Equity={fundamental_summary.get('total_equity_source_account', '') or '-'}; Debt proxy; Cash={fundamental_summary.get('cash_source_account', '') or '-'}", 'basis': suggestions.get('invested_capital_basis', ''), 'status': suggestions.get('invested_capital_status', '')}, {'input': 'Maintenance CAPEX', 'value': None, 'source': 'Human Review', 'basis': 'Maintenance / Growth split not available from structured statement extraction', 'status': 'MANUAL_REQUIRED'}])
                st.dataframe(source_audit, width='stretch', hide_index=True)
                raw_share_df = st.session_state.get(f'{share_source_key}::raw')
                if isinstance(raw_share_df, pd.DataFrame) and (not raw_share_df.empty):
                    st.markdown('**OpenDART Share Source Rows**')
                    st.dataframe(raw_share_df, width='stretch', hide_index=True)
            shares_input_key = f'fundamental_shares::{fundamental_company}'
            tax_input_key = f'fundamental_tax::{fundamental_company}'
            ic_input_key = f'fundamental_ic::{fundamental_company}'

            def _suggestion_is_applied(input_key, suggestion):
                if suggestion is None:
                    return False
                try:
                    current_value = float(st.session_state.get(input_key, 0.0) or 0.0)
                    suggestion_value = float(suggestion)
                except Exception:
                    return False
                scale = max(1.0, abs(current_value), abs(suggestion_value))
                return abs(current_value - suggestion_value) <= scale * 1e-09
            share_applied = _suggestion_is_applied(shares_input_key, _share_suggestion)
            tax_applied = _suggestion_is_applied(tax_input_key, _tax_suggestion)
            ic_applied = _suggestion_is_applied(ic_input_key, _ic_suggestion)
            applied_count = sum([int(share_applied), int(tax_applied), int(ic_applied)])
            st.markdown(f'**Source-backed 제안 적용 상태 · {applied_count}/3**')
            a1, a2, a3, a4 = st.columns(4)
            if a1.button('✓ Share 제안 적용됨' if share_applied else 'Share 제안 적용', type='primary' if share_applied else 'secondary', key=f'apply_share_suggestion::{fundamental_company}', disabled=_share_suggestion is None or share_applied):
                st.session_state[shares_input_key] = float(_share_suggestion)
                st.rerun()
            if share_applied:
                a1.success('적용됨')
            if a2.button('✓ Tax 제안 적용됨' if tax_applied else 'Tax 제안 적용', type='primary' if tax_applied else 'secondary', key=f'apply_tax_suggestion::{fundamental_company}', disabled=_tax_suggestion is None or tax_applied):
                st.session_state[tax_input_key] = float(_tax_suggestion)
                st.rerun()
            if tax_applied:
                a2.success('적용됨')
            if a3.button('✓ Invested Capital 적용됨' if ic_applied else 'Invested Capital 제안 적용', type='primary' if ic_applied else 'secondary', key=f'apply_ic_suggestion::{fundamental_company}', disabled=_ic_suggestion is None or _ic_suggestion <= 0 or ic_applied):
                st.session_state[ic_input_key] = float(_ic_suggestion)
                st.rerun()
            if ic_applied:
                a3.success('적용됨')
            a4.caption('Maintenance CAPEX는 자동 제안하지 않습니다.')
            st.caption('버튼이 ✓ 적용됨으로 바뀌고 초록색 `적용됨` 표시가 나오면 입력칸에 제안값이 반영된 상태입니다. Human-confirmed 체크박스는 별도 검토 단계이므로 자동 선택되지 않습니다.')
            fundamental_history = normalize_fundamental_snapshots(load_csv('fundamental_snapshots.csv'))
            st.subheader('3. Comparable Period Backfill')
            st.caption('첫 Snapshot에서는 Net Share Count Δ와 iROIC의 비교 기준이 없으므로 `-`가 정상입니다. 여기서 이전 연도의 동일 기간(H1↔H1, FY↔FY) OpenDART Source를 불러와 검토한 뒤 Baseline으로 저장할 수 있습니다.')
            hash_report = fundamental_snapshot_hash_report(fundamental_history)
            if not hash_report.empty:
                legacy_hash_rows = hash_report.loc[hash_report['hash_status'].eq('LEGACY_HASH')].copy()
                blocked_hash_rows = hash_report.loc[~hash_report['hash_status'].isin(['OK', 'LEGACY_HASH'])].copy()
                verified_v2_rows = hash_report.loc[hash_report['hash_schema_version'].eq('v2') & hash_report['hash_status'].eq('OK')].copy()
                if legacy_hash_rows.empty and blocked_hash_rows.empty:
                    schemas = ', '.join(sorted(set(hash_report['hash_schema_version'].fillna('').astype(str))))
                    st.success(f'Fundamental Snapshot Hash Integrity PASS · {len(hash_report)}개 Snapshot · schema {schemas}')
                if not blocked_hash_rows.empty:
                    st.error(f'Fundamental Snapshot Hash Integrity BLOCKED · {len(blocked_hash_rows)}개. 값이 바뀐 것으로 단정하지 않고, Hash 검증에 실패한 행을 비교 Baseline에서 제외합니다.')
                    st.dataframe(blocked_hash_rows, width='stretch', hide_index=True)
                    _current_year_for_cleanup = str(fundamental_meta.get('business_year', '') or '').strip()
                    _current_period_for_cleanup = str(fundamental_meta.get('period', '') or '').strip().upper()
                    current_blocked_rows = blocked_hash_rows.loc[blocked_hash_rows['company'].fillna('').astype(str).eq(fundamental_company) & blocked_hash_rows['source_business_year'].fillna('').astype(str).str.replace('\\.0$', '', regex=True).eq(_current_year_for_cleanup) & blocked_hash_rows['source_period'].fillna('').astype(str).str.upper().eq(_current_period_for_cleanup)].copy()
                    if not current_blocked_rows.empty:
                        st.warning('현재 기간에 방금 저장된 BLOCKED Snapshot이 있습니다. 이 행은 자동 재해시하지 않고 삭제 후 v3로 다시 저장하는 방식이 가장 안전합니다.')
                        blocked_cleanup_confirm = st.checkbox(f'{fundamental_company} {_current_year_for_cleanup} {_current_period_for_cleanup}의 HASH_MISMATCH Snapshot만 삭제하고 다시 저장하겠습니다.', key=f'fundamental_blocked_cleanup_confirm::{fundamental_company}')
                        if st.button('현재 기간 BLOCKED Snapshot 안전 폐기', type='primary', disabled=not blocked_cleanup_confirm, key=f'fundamental_blocked_cleanup::{fundamental_company}'):
                            cleaned_history, removed_count = remove_blocked_current_period_snapshots(fundamental_history, company=fundamental_company, business_year=_current_year_for_cleanup, period=_current_period_for_cleanup)
                            if removed_count <= 0:
                                st.info('현재 기간에서 제거할 HASH_MISMATCH Snapshot이 없습니다.')
                            else:
                                verified_save_feedback(cleaned_history, 'fundamental_snapshots.csv', f'현재 기간 BLOCKED Fundamental Snapshot {removed_count}건을 안전 폐기했습니다.', rerun=True)
                    else:
                        st.caption('BLOCKED 행은 현재 선택한 기간의 Snapshot이 아닙니다. 자동 제거하지 않습니다.')
                if not legacy_hash_rows.empty:
                    st.warning(f'Legacy Hash Schema Migration 필요 · {len(legacy_hash_rows)}개.')
                    with st.expander('Legacy Fundamental Snapshot Hash Migration', expanded=False):
                        st.dataframe(legacy_hash_rows, width='stretch', hide_index=True)
                        legacy_confirm = st.checkbox('legacy Snapshot의 값은 유지하고 stable hash schema v3로 마이그레이션합니다.', key=f'fundamental_legacy_v3_confirm::{fundamental_company}')
                        if st.button('Legacy Hash → v3 안전 마이그레이션', disabled=not legacy_confirm, key=f'fundamental_legacy_v3::{fundamental_company}'):
                            migrated_df, migrated_count = repair_fundamental_snapshot_hashes(fundamental_history)
                            if migrated_count <= 0:
                                st.info('마이그레이션할 legacy Snapshot이 없습니다.')
                            else:
                                verified_save_feedback(migrated_df, 'fundamental_snapshots.csv', f'Legacy Snapshot {migrated_count}건을 hash schema v3로 마이그레이션했습니다.', rerun=True)
                if not verified_v2_rows.empty:
                    with st.expander('검증된 v2 Snapshot을 v3로 업그레이드', expanded=False):
                        st.dataframe(verified_v2_rows, width='stretch', hide_index=True)
                        st.caption('v2 Hash가 먼저 OK인 행만 v3로 업그레이드합니다. 재무값·Source·Review Status는 변경하지 않습니다.')
                        v2_upgrade_confirm = st.checkbox('Hash OK인 v2 Snapshot만 v3로 업그레이드합니다.', key=f'fundamental_v2_v3_confirm::{fundamental_company}')
                        if st.button('Verified v2 → v3 업그레이드', disabled=not v2_upgrade_confirm, key=f'fundamental_v2_v3::{fundamental_company}'):
                            upgraded_df, upgraded_count = migrate_verified_v2_to_v3(fundamental_history)
                            if upgraded_count <= 0:
                                st.info('업그레이드할 검증된 v2 Snapshot이 없습니다.')
                            else:
                                verified_save_feedback(upgraded_df, 'fundamental_snapshots.csv', f'검증된 v2 Snapshot {upgraded_count}건을 v3로 업그레이드했습니다.', rerun=True)
            duplicate_report = fundamental_snapshot_duplicate_report(fundamental_history)
            if not duplicate_report.empty:
                exact_remove_count = int(pd.to_numeric(duplicate_report['exact_duplicates_removable'], errors='coerce').fillna(0).sum())
                revision_groups = int(duplicate_report['status'].isin(['MULTIPLE_REVISIONS', 'MIXED_EXACT_AND_REVISIONS']).sum())
                if exact_remove_count > 0:
                    st.warning(f'Fundamental Snapshot Exact Duplicate {exact_remove_count}건 정리 가능.')
                    with st.expander('Fundamental Snapshot Duplicate Integrity', expanded=True):
                        st.dataframe(duplicate_report, width='stretch', hide_index=True)
                        st.caption('안전 정리는 같은 회사·연도·기간·report_code·FS의 Snapshot 중 재무값/수동확인/Source/Note까지 동일한 반복 저장만 제거합니다. 내용이 다른 Revision은 보존합니다.')
                        dedupe_confirm = st.checkbox('정확히 동일한 반복 Snapshot만 제거하고, 내용이 다른 Revision은 모두 보존하는 데 동의합니다.', key=f'fundamental_dedupe_confirm::{fundamental_company}')
                        if st.button('정확 중복 Snapshot 안전 정리', type='primary', disabled=not dedupe_confirm, key=f'fundamental_dedupe::{fundamental_company}'):
                            cleaned_fundamentals, removed_count = consolidate_exact_fundamental_duplicates(fundamental_history)
                            if removed_count <= 0:
                                st.info('제거할 정확 중복 Snapshot이 없습니다.')
                            else:
                                verified_save_feedback(cleaned_fundamentals, 'fundamental_snapshots.csv', f'정확 중복 Fundamental Snapshot {removed_count}건을 안전 정리했습니다.', rerun=True)
                if revision_groups > 0:
                    st.info(f'동일 Source Period에 내용이 다른 Reviewed Revision 그룹 {revision_groups}개가 있습니다. 이는 자동 삭제하지 않습니다.')
            _current_year_text = str(fundamental_meta.get('business_year', '') or '').strip()
            _current_period = str(fundamental_meta.get('period', '') or '').strip().upper()
            _current_report_code = str(fundamental_meta.get('report_code', '') or '').strip()
            _current_fs_div = str(fundamental_meta.get('fs_div', '') or '').strip()
            _current_corp = str(fundamental_meta.get('corp_code', '') or '').strip()
            try:
                _current_year_int = int(float(_current_year_text))
                _prior_year = _current_year_int - 1
            except Exception:
                _prior_year = None
            existing_prior_baseline = reviewed_snapshot_for_period(fundamental_history, fundamental_company, str(_prior_year) if _prior_year else '', _current_period) if _prior_year else {}
            prior_backfill_key = f'fundamental_prior_backfill::{fundamental_company}::{_prior_year}::{_current_report_code}::{_current_fs_div}'
            prior_backfill = st.session_state.get(prior_backfill_key, {})
            pb1, pb2 = st.columns([1, 3])
            if existing_prior_baseline:
                pb1.metric('Prior Baseline', f"{existing_prior_baseline.get('source_business_year', '')} {existing_prior_baseline.get('source_period', '')}")
                pb2.success('이전 동일기간 REVIEWED Snapshot이 이미 존재합니다. 현재 Share Count/Tax/Invested Capital을 Human-confirmed 하면 Net Share Count Δ와 iROIC 비교가 활성화됩니다.')
            else:
                can_load_prior = bool(dart_key_for_fundamental and _prior_year and _current_corp and _current_report_code and _current_fs_div)
                if pb1.button('이전 동일기간 OpenDART 불러오기', type='primary', disabled=not can_load_prior, key=f'load_prior_period::{fundamental_company}'):
                    try:
                        _prior_raw = full_financials(dart_key_for_fundamental, _current_corp, int(_prior_year), _current_report_code, _current_fs_div)
                        if _prior_raw.empty:
                            raise RuntimeError(f'{_prior_year} {_current_period} 재무제표가 비어 있습니다.')
                        _prior_summary = summarize_financials(_prior_raw)
                        _prior_share_raw = stock_total_status(dart_key_for_fundamental, _current_corp, int(_prior_year), _current_report_code)
                        _prior_share_summary = summarize_share_count(_prior_share_raw)
                        st.session_state[prior_backfill_key] = {'summary': _prior_summary, 'share_summary': _prior_share_summary, 'raw': _prior_raw, 'share_raw': _prior_share_raw, 'meta': {'source_kind': 'OpenDART Comparable Backfill', 'business_year': str(_prior_year), 'period': _current_period, 'report_code': _current_report_code, 'fs_div': _current_fs_div, 'corp_code': _current_corp}}
                        st.rerun()
                    except Exception as e:
                        st.error(f'이전 동일기간 Source 조회 실패: {e}')
                pb2.info(f"비교 대상: {_prior_year or '-'} {_current_period or '-'} · 현재 기간과 같은 report_code / FS 기준만 사용합니다.")
            if prior_backfill and (not existing_prior_baseline):
                prior_summary = dict(prior_backfill.get('summary', {}) or {})
                prior_share_summary = dict(prior_backfill.get('share_summary', {}) or {})
                prior_meta = dict(prior_backfill.get('meta', {}) or {})
                prior_suggestions = build_source_backed_suggestions(prior_summary, prior_share_summary)
                pp1, pp2, pp3, pp4 = st.columns(4)
                pp1.metric('Prior Extraction', str(prior_summary.get('extraction_integrity_status', '-') or '-'))
                pp2.metric('Prior Share Count proxy', '-' if prior_suggestions.get('share_count_proxy') is None else f"{prior_suggestions['share_count_proxy']:,.0f}")
                pp3.metric('Prior Tax proxy', '-' if prior_suggestions.get('effective_tax_rate_proxy') is None else f"{prior_suggestions['effective_tax_rate_proxy'] * 100:.2f}%")
                pp4.metric('Prior Invested Capital proxy', krw(prior_suggestions.get('invested_capital_proxy')))
                preview = source_period_growth_preview(fundamental_summary, prior_summary, current_share_count=_share_suggestion, prior_share_count=prior_suggestions.get('share_count_proxy'))
                preview_show = preview.copy()
                if 'change_pct' in preview_show.columns:
                    preview_show['change_pct'] = preview_show['change_pct'].map(lambda x: '' if pd.isna(x) else f'{float(x) * 100:.2f}%')
                st.markdown('**Current vs Prior Source-only Preview**')
                st.dataframe(preview_show, width='stretch', hide_index=True)
                st.caption('이 표는 동일기간 Source의 단순 변화율 Preview입니다. Human-confirmed Snapshot이나 투자판단을 대신하지 않습니다.')
                with st.expander('이전 동일기간 Source Audit', expanded=False):
                    prior_source_audit = pd.DataFrame([{'input': 'Share Count proxy', 'value': prior_suggestions.get('share_count_proxy'), 'basis': prior_suggestions.get('share_count_basis', ''), 'status': prior_suggestions.get('share_count_status', '')}, {'input': 'Effective Tax Rate proxy', 'value': prior_suggestions.get('effective_tax_rate_proxy'), 'basis': prior_suggestions.get('tax_rate_basis', ''), 'status': prior_suggestions.get('effective_tax_rate_status', '')}, {'input': 'Invested Capital proxy', 'value': prior_suggestions.get('invested_capital_proxy'), 'basis': prior_suggestions.get('invested_capital_basis', ''), 'status': prior_suggestions.get('invested_capital_status', '')}])
                    st.dataframe(prior_source_audit, width='stretch', hide_index=True)
                    _prior_share_raw = prior_backfill.get('share_raw')
                    if isinstance(_prior_share_raw, pd.DataFrame) and (not _prior_share_raw.empty):
                        st.markdown('**Prior Share Source Rows**')
                        st.dataframe(_prior_share_raw, width='stretch', hide_index=True)
                prior_reviewed = st.checkbox('이전 동일기간 재무제표·주식수·Tax·Invested Capital proxy의 Source와 정의를 직접 검토했습니다.', key=f'prior_backfill_reviewed::{fundamental_company}::{_prior_year}')
                prior_share = prior_suggestions.get('share_count_proxy')
                prior_tax = prior_suggestions.get('effective_tax_rate_proxy')
                prior_ic = prior_suggestions.get('invested_capital_proxy')
                prior_save_ready = bool(prior_reviewed and str(prior_summary.get('extraction_integrity_status', '')).upper() == 'PASS' and (prior_share is not None) and (prior_share > 0) and (prior_tax is not None) and (0 <= prior_tax <= 1) and (prior_ic is not None) and (prior_ic > 0))
                if not prior_save_ready:
                    st.caption('Baseline 저장 Gate: Extraction Integrity PASS + Share/Tax/Invested Capital Source 존재 + Human Review 확인.')
                if st.button('이전 동일기간 Baseline Snapshot 저장', type='primary', disabled=not prior_save_ready, key=f'save_prior_baseline::{fundamental_company}::{_prior_year}'):
                    prior_metrics = build_fundamental_metrics(prior_summary, diluted_shares=float(prior_share), effective_tax_rate=float(prior_tax), maintenance_capex=None, invested_capital=float(prior_ic), prior_snapshot=None, period=prior_meta.get('period', ''))
                    prior_issued = None
                    try:
                        prior_issued = float(prior_share_summary.get('issued_shares_proxy'))
                    except Exception:
                        prior_issued = None
                    prior_allocation = build_capital_allocation_metrics(prior_summary, current_share_count=float(prior_share), issued_shares_proxy=prior_issued, prior_snapshot=None)
                    prior_record = build_fundamental_snapshot_record(company=fundamental_company, stock_code=fundamental_code, source_meta=prior_meta, dart_summary=prior_summary, metrics=prior_metrics, manual_shares_confirmed=True, manual_tax_confirmed=True, manual_maintenance_capex_confirmed=False, manual_invested_capital_confirmed=True, share_count_basis=prior_suggestions.get('share_count_basis', ''), tax_rate_basis=prior_suggestions.get('tax_rate_basis', ''), invested_capital_basis=prior_suggestions.get('invested_capital_basis', ''), capital_allocation_metrics=prior_allocation, prior_snapshot=None, review_status='REVIEWED', note='Comparable Period Backfill · same-period OpenDART source reviewed by user. Maintenance CAPEX intentionally not estimated.')
                    updated_history = append_fundamental_snapshot(fundamental_history, prior_record)
                    verified_save_feedback(updated_history, 'fundamental_snapshots.csv', f'{_prior_year} {_current_period} Comparable Baseline Snapshot을 저장했습니다.', rerun=True)
            prior_fundamental = latest_comparable_fundamental_snapshot(fundamental_history, fundamental_company, fundamental_meta.get('business_year', ''), fundamental_meta.get('period', ''))
            st.subheader('4. Human-confirmed Inputs')
            if prior_fundamental:
                prior_integrity = snapshot_integrity_status(prior_fundamental)
                st.caption(f"iROIC 비교용 이전 동일기간 Snapshot: {prior_fundamental.get('source_business_year', '')} {prior_fundamental.get('source_period', '')} · Hash {prior_integrity}")
            else:
                st.caption('같은 기간 기준(H1↔H1, FY↔FY)의 이전 REVIEWED Snapshot이 없습니다. 따라서 iROIC가 계산되지 않는 것이 정상입니다.')
            h1, h2 = st.columns(2)
            with h1:
                shares_confirmed = st.checkbox('Share Count proxy의 주식종류/합계 범위를 OpenDART 원문에서 확인했습니다.', key=f'fundamental_shares_confirm::{fundamental_company}')
                share_count_input = st.number_input('Share Count Proxy (shares)', min_value=0.0, value=0.0, step=1000000.0, format='%.0f', key=shares_input_key, help='FCF/share proxy 계산용입니다. OpenDART distributed shares는 weighted-average diluted EPS denominator와 동일하지 않을 수 있습니다.')
                tax_confirmed = st.checkbox('Pretax Income과 Income Tax Expense 원계정을 확인하고 유효세율 proxy를 검토했습니다.', key=f'fundamental_tax_confirm::{fundamental_company}')
                tax_rate_input = st.number_input('Effective Tax Rate', min_value=0.0, max_value=1.0, value=0.0, step=0.01, format='%.4f', key=tax_input_key, help='NOPAT = Operating Profit × (1 - Tax Rate). Source 제안값도 사람이 확인한 뒤 사용합니다.')
            with h2:
                maintenance_confirmed = st.checkbox('Maintenance CAPEX를 원문/사업 특성에 따라 직접 검토했습니다.', key=f'fundamental_maint_confirm::{fundamental_company}')
                maintenance_capex_input = st.number_input('Maintenance CAPEX (KRW)', min_value=0.0, value=0.0, step=1000000000.0, format='%.0f', key=f'fundamental_maint::{fundamental_company}', help='Owner Earnings proxy = CFO - Maintenance CAPEX. 구조화 공시에서 Growth/Maintenance를 분리하지 않으므로 자동 제안하지 않습니다.')
                invested_capital_confirmed = st.checkbox('Invested Capital proxy 정의(Equity + Debt - Cash)와 원계정을 직접 검토했습니다.', key=f'fundamental_ic_confirm::{fundamental_company}')
                invested_capital_input = st.number_input('Invested Capital (KRW)', min_value=0.0, value=0.0, step=1000000000.0, format='%.0f', key=ic_input_key, help='ROIC 분모 proxy입니다. Excess Cash, 비영업자산, 리스/기타부채 정의에 따라 달라질 수 있습니다.')
            metrics = build_fundamental_metrics(fundamental_summary, diluted_shares=share_count_input if shares_confirmed and share_count_input > 0 else None, effective_tax_rate=tax_rate_input if tax_confirmed else None, maintenance_capex=maintenance_capex_input if maintenance_confirmed else None, invested_capital=invested_capital_input if invested_capital_confirmed and invested_capital_input > 0 else None, prior_snapshot=prior_fundamental or None, period=fundamental_meta.get('period', ''))
            st.subheader('5. Fundamental Metrics')
            m1, m2, m3, m4 = st.columns(4)
            m1.metric('FCF / share proxy', '-' if metrics['fcf_per_share'] is None else f"{metrics['fcf_per_share']:,.0f}원")
            m2.metric('Owner Earnings proxy', krw(metrics['owner_earnings_proxy']))
            m3.metric('Period ROIC proxy', pct(metrics['roic']))
            m4.metric('Period iROIC proxy', pct(metrics['iroic']))
            n1, n2, n3, n4 = st.columns(4)
            n1.metric('Operating Margin', pct(metrics['operating_margin']))
            n2.metric('FCF Margin', pct(metrics['fcf_margin']))
            _period_key = str(fundamental_meta.get('period', '') or '').strip().upper()
            _is_full_year = _period_key in {'FY', 'ANNUAL', 'FULL_YEAR', 'YEAR'}
            if _is_full_year:
                n3.metric('Reinvestment Rate proxy', pct(metrics['reinvestment_rate']))
                n4.metric('g identity proxy', pct(metrics['growth_identity_proxy']))
            else:
                n3.metric('Capital Δ / Period NOPAT', pct(metrics['capital_change_to_period_nopat']))
                n4.metric('g identity proxy', '-', help='H1/Q1/Q3에서는 자본의 12개월 변화와 중간기간 NOPAT의 시간축이 달라 g ≈ ROIC × Reinvestment를 표시하지 않습니다.')
            quality_table = pd.DataFrame([{'metric': 'FCF proxy', 'status': metrics['quality']['fcf_proxy'], 'source': 'OpenDART CF extraction'}, {'metric': 'FCF/share proxy', 'status': metrics['quality']['fcf_per_share'], 'source': 'FCF proxy + human-confirmed share count proxy'}, {'metric': 'Owner Earnings proxy', 'status': metrics['quality']['owner_earnings'], 'source': 'CFO + human-confirmed Maintenance CAPEX'}, {'metric': 'Period ROIC proxy', 'status': metrics['quality']['roic'], 'source': 'Period Operating Profit + human-confirmed tax + invested capital'}, {'metric': 'Period iROIC proxy', 'status': metrics['quality']['iroic'], 'source': 'Current vs earlier same-period reviewed Snapshot'}])
            st.dataframe(quality_table, width='stretch', hide_index=True)
            if metrics['delta_invested_capital'] is not None and metrics['delta_invested_capital'] <= 0:
                st.warning('Δ Invested Capital ≤ 0이므로 iROIC를 기계적으로 계산하지 않았습니다. 자본회수·사업매각·운전자본 정상화 등 원인을 사람이 해석해야 합니다.')
            if not _is_full_year:
                st.warning('중간기간에서는 `Capital Δ / Period NOPAT`만 진단값으로 표시합니다. 예: H1의 Δ Invested Capital은 전년 H1말 대비 12개월 Stock 변화인 반면 NOPAT은 6개월 Flow이므로, 이를 표준 Reinvestment Rate나 장기 g로 해석하지 않습니다.')
            with st.expander('Period iROIC Audit Trail', expanded=False):
                iroic_audit = pd.DataFrame([{'metric': 'Prior NOPAT', 'value': prior_fundamental.get('nopat') if prior_fundamental else None, 'basis': f"{prior_fundamental.get('source_business_year', '')} {prior_fundamental.get('source_period', '')}" if prior_fundamental else '-'}, {'metric': 'Current NOPAT', 'value': metrics.get('nopat'), 'basis': f"{fundamental_meta.get('business_year', '')} {fundamental_meta.get('period', '')}"}, {'metric': 'Δ NOPAT', 'value': metrics.get('delta_nopat'), 'basis': 'Current period NOPAT - prior same-period NOPAT'}, {'metric': 'Prior Invested Capital', 'value': prior_fundamental.get('invested_capital') if prior_fundamental else None, 'basis': 'Prior same-period reviewed proxy'}, {'metric': 'Current Invested Capital', 'value': metrics.get('invested_capital'), 'basis': 'Current human-confirmed proxy'}, {'metric': 'Δ Invested Capital', 'value': metrics.get('delta_invested_capital'), 'basis': 'Current - prior same-period'}, {'metric': 'Period iROIC proxy', 'value': metrics.get('iroic'), 'basis': 'Δ NOPAT / Δ Invested Capital'}])
                st.dataframe(iroic_audit, width='stretch', hide_index=True)
                st.caption('iROIC가 매우 높거나 낮으면 우선 분자(경기/일회성 이익)와 분모(현금·부채·자본 정의)의 변화부터 검토합니다.')
            st.caption('Period ROIC/iROIC는 해당 기간의 비교용 proxy이며 LTM/연환산 ROIC와 동일하지 않습니다. FY에서만 Reinvestment Rate와 g identity를 표시합니다.')
            st.subheader('6. Capital Allocation Lens')
            issued_share_suggestion = None
            if share_summary:
                try:
                    issued_share_suggestion = float(share_summary.get('issued_shares_proxy'))
                except Exception:
                    issued_share_suggestion = None
            allocation_metrics = build_capital_allocation_metrics(fundamental_summary, current_share_count=metrics.get('diluted_shares'), issued_shares_proxy=issued_share_suggestion, prior_snapshot=prior_fundamental or None)
            ca1, ca2, ca3, ca4 = st.columns(4)
            ca1.metric('Outstanding Share Count proxy', '-' if allocation_metrics['outstanding_share_count_proxy'] is None else f"{allocation_metrics['outstanding_share_count_proxy']:,.0f}")
            ca2.metric('Treasury Shares proxy', '-' if allocation_metrics['treasury_shares_proxy'] is None else f"{allocation_metrics['treasury_shares_proxy']:,.0f}")
            ca3.metric('Net Share Count Δ', '-' if allocation_metrics['net_share_count_change'] is None else f"{allocation_metrics['net_share_count_change']:+,.0f}")
            ca4.metric('Net Share Count Δ%', pct(allocation_metrics['net_share_count_change_pct']))
            cb1, cb2, cb3, cb4 = st.columns(4)
            cb1.metric('Organic CAPEX proxy', krw(metrics.get('capex_proxy')))
            cb2.metric('Dividends Paid proxy', krw(allocation_metrics['dividends_paid_proxy']))
            cb3.metric('Buyback Cash proxy', krw(allocation_metrics['treasury_share_purchase_proxy']))
            cb4.metric('FCF after Dividend+Buyback', krw(allocation_metrics['fcf_after_dividend_buyback']))
            cc1, cc2, cc3 = st.columns(3)
            cc1.metric('CAPEX / CFO', pct(allocation_metrics['capex_to_cfo']))
            cc2.metric('Dividend / FCF', pct(allocation_metrics['dividend_to_fcf']))
            cc3.metric('Buyback / FCF', pct(allocation_metrics['buyback_to_fcf']))
            allocation_audit = pd.DataFrame([{'allocation': 'Organic reinvestment proxy', 'value': metrics.get('capex_proxy'), 'source': fundamental_summary.get('capex_source_account', '') or 'OpenDART CF', 'status': 'PASS_PROXY' if metrics.get('capex_proxy') is not None else 'MISSING'}, {'allocation': 'Dividend cash use proxy', 'value': allocation_metrics['dividends_paid_proxy'], 'source': fundamental_summary.get('dividends_paid_source_account', '') or '-', 'status': 'PASS_PROXY' if allocation_metrics['dividends_paid_proxy'] is not None else 'MISSING'}, {'allocation': 'Treasury share purchase cash proxy', 'value': allocation_metrics['treasury_share_purchase_proxy'], 'source': fundamental_summary.get('treasury_share_purchase_source_account', '') or '-', 'status': 'PASS_PROXY' if allocation_metrics['treasury_share_purchase_proxy'] is not None else 'MISSING'}, {'allocation': 'Treasury share disposal cash proxy', 'value': allocation_metrics['treasury_share_disposal_proxy'], 'source': fundamental_summary.get('treasury_share_disposal_source_account', '') or '-', 'status': 'PASS_PROXY' if allocation_metrics['treasury_share_disposal_proxy'] is not None else 'MISSING'}])
            st.dataframe(allocation_audit, width='stretch', hide_index=True)
            st.caption('Outstanding Share Count proxy = OpenDART distributed shares. Treasury Shares proxy = issued shares - outstanding proxy. 첫 동일기간 Snapshot에서는 Net Share Count Δ가 비어 있는 것이 정상입니다.')
            st.warning('Buyback Cash 규모는 가치창출 판정이 아닙니다. Repurchase Price와 보수적 Intrinsic Value, Net Share Count 감소를 함께 확인해야 합니다.')
            st.subheader('7. Reviewed Snapshot 저장')
            fundamental_note = st.text_area('Review Note', value='', key=f'fundamental_note::{fundamental_company}', placeholder='예: Share Count의 주식종류 범위, Tax source, Invested Capital 정의, Maintenance CAPEX 판단 근거')
            fundamental_reviewed = st.checkbox('DART 추출값과 수동입력의 근거를 직접 검토했으며, 이 Snapshot이 계산용 기록이지 투자판단 자동승인이 아님을 확인합니다.', key=f'fundamental_reviewed::{fundamental_company}')
            save_ready = bool(fundamental_reviewed and str(fundamental_summary.get('extraction_integrity_status', '')).upper() == 'PASS')
            if not save_ready:
                st.caption('저장 Gate: Extraction Integrity PASS + Human Review 확인이 필요합니다.')

            def _basis_for_input(value, suggested, suggested_basis):
                if value is None:
                    return ''
                if suggested is not None:
                    scale = max(1.0, abs(float(value)), abs(float(suggested)))
                    if abs(float(value) - float(suggested)) <= scale * 1e-09:
                        return suggested_basis or 'SOURCE_BACKED_PROXY'
                return 'HUMAN_REVIEWED_MANUAL'
            share_basis = _basis_for_input(metrics.get('diluted_shares'), _share_suggestion, suggestions.get('share_count_basis', ''))
            tax_basis = _basis_for_input(metrics.get('effective_tax_rate'), _tax_suggestion, suggestions.get('tax_rate_basis', ''))
            ic_basis = _basis_for_input(metrics.get('invested_capital'), _ic_suggestion, suggestions.get('invested_capital_basis', ''))
            if st.button('Fundamental Snapshot 저장', type='primary', disabled=not save_ready, key=f'save_fundamental::{fundamental_company}'):
                snapshot_record = build_fundamental_snapshot_record(company=fundamental_company, stock_code=fundamental_code, source_meta=fundamental_meta, dart_summary=fundamental_summary, metrics=metrics, manual_shares_confirmed=shares_confirmed, manual_tax_confirmed=tax_confirmed, manual_maintenance_capex_confirmed=maintenance_confirmed, manual_invested_capital_confirmed=invested_capital_confirmed, share_count_basis=share_basis, tax_rate_basis=tax_basis, invested_capital_basis=ic_basis, capital_allocation_metrics=allocation_metrics, prior_snapshot=prior_fundamental or None, review_status='REVIEWED', note=fundamental_note)
                updated_fundamentals = append_fundamental_snapshot(fundamental_history, snapshot_record)
                verified_save_feedback(updated_fundamentals, 'fundamental_snapshots.csv', 'Fundamental Snapshot을 저장했습니다.', rerun=True)
            if not fundamental_history.empty:
                st.subheader('8. Snapshot History')
                history_company = fundamental_history.loc[fundamental_history['company'].fillna('').astype(str).eq(fundamental_company)].copy()
                if history_company.empty:
                    st.info('이 종목의 저장된 Fundamental Snapshot이 없습니다.')
                else:
                    history_cols = ['created_at', 'source_business_year', 'source_period', 'fcf_proxy', 'fcf_per_share', 'owner_earnings_proxy', 'roic', 'iroic', 'reinvestment_rate', 'net_share_count_change_pct', 'dividends_paid_proxy', 'treasury_share_purchase_proxy', 'review_status']
                    st.dataframe(history_company[[c for c in history_cols if c in history_company.columns]].tail(20).iloc[::-1], width='stretch', hide_index=True)
            st.warning('Owner Earnings, Invested Capital, ROIC/iROIC는 정의 선택에 민감합니다. 특히 Maintenance CAPEX는 자동화하지 않았습니다. 동일 회사의 기간 비교에서 정의를 일관되게 유지하세요.')
