from __future__ import annotations
if True:
    st.title('Reconciliation')
    st.caption('총자산과 보유자산 합계가 맞는지 먼저 확인합니다. 불일치 상태에서는 Rebalance Planner의 신규 BUY를 차단합니다.')
    tol = st.number_input('허용 오차 (KRW)', min_value=0, value=int(settings.get('reconciliation_tolerance_krw', 1000)), step=1000)
    recon = reconcile_portfolio(portfolio, total_assets, tol)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric('Declared Total', krw(recon['declared_total_assets']))
    c2.metric('Known Portfolio', krw(recon['known_portfolio_value']))
    c3.metric('Gap', krw(recon['gap_krw']))
    c4.metric('Status', recon['status'])
    if recon['status'] == 'PASS':
        st.success('총자산과 보유자산 합계가 허용오차 안에서 일치합니다.')
    else:
        st.error('총자산과 보유자산 합계가 맞지 않습니다. Portfolio 또는 Settings의 총자산을 먼저 수정하세요.')
    rows = portfolio_rows_with_reconciliation(portfolio, total_assets)
    st.dataframe(rows, width='stretch', hide_index=True)
    st.subheader('Cash')
    st.write(f"현금 평가액: **{krw(recon['cash_value_krw'])}** / 현금비중: **{pct(recon['cash_weight'])}**")
    st.caption("현금은 asset_type='cash' 또는 이름이 현금/Cash인 행을 기준으로 계산합니다.")
