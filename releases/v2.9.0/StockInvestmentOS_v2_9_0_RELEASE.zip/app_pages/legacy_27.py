from __future__ import annotations
if True:
    st.title('Screening')
    st.caption('Triage 점수는 후보 압축용입니다. Survival/Bear/Evidence/Valuation 검토를 대체하지 않습니다.')
    edited = st.data_editor(watchlist, num_rows='dynamic', width='stretch', key='watch_editor')
    if st.button('Watchlist 저장'):
        verified_save_feedback(edited, 'watchlist.csv', 'Watchlist를 저장했습니다.')
    if not edited.empty:
        screened = screen_candidates(edited)
        cols = [c for c in ['name', 'survival_pass', 'quality_score', 'risk_penalty', 'triage_score', 'normalized_fcf_yield', 'roic', 'iroic', 'bear_downside'] if c in screened.columns]
        st.dataframe(screened[cols], width='stretch', hide_index=True)
