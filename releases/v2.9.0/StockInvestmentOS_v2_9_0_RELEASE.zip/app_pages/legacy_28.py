from __future__ import annotations
if True:
    st.title('Lifecycle State Machine')
    st.caption("현재 단계와 '다음 단계로 넘어가기 위해 무엇이 더 필요한지'를 분리해서 보여줍니다. 이 화면은 자동매수·자동주문을 하지 않습니다.")
    state_df = add_state_machine_reviews(watchlist, portfolio, total_assets, loss_budget, single_cap)
    st.markdown('**기본 흐름:** `OBSERVE → INITIAL → CORE → MAX → HOLD / MONITOR`')
    st.caption('문제가 생기면 ADD FREEZE · TRIM · EXIT로 이동하며, 가격하락만으로 자동 복구하거나 자동 Add하지 않습니다.')
    if state_df.empty:
        st.info('Watchlist가 비어 있습니다.')
    else:
        st.subheader('초보자용 다음 단계 확인')
        machine_names = state_df['name'].fillna('').astype(str).tolist()
        machine_selected = st.selectbox('Lifecycle 확인 종목', machine_names, key='state_machine_company')
        machine_hit = state_df.loc[state_df['name'].fillna('').astype(str) == str(machine_selected)]
        if not machine_hit.empty:
            mr = machine_hit.iloc[0].to_dict()
            c1, c2, c3, c4 = st.columns(4)
            c1.metric('현재 Lifecycle', str(mr.get('lifecycle_state', '-')))
            c2.metric('다음 단계', str(mr.get('next_lifecycle_stage', '-')))
            c3.metric('전환 상태', str(mr.get('transition_status', '-')))
            c4.metric('현재가격', krw(mr.get('price')))
            threshold_name = str(mr.get('transition_threshold_name', '-') or '-')
            threshold_value = pd.to_numeric(pd.Series([mr.get('transition_threshold')]), errors='coerce').iloc[0]
            if threshold_name != '-' and (not pd.isna(threshold_value)):
                st.caption(f'다음 가격 기준: **{threshold_name} {krw(threshold_value)}**')
            current_weight = 0.0
            if total_assets > 0 and (not portfolio.empty):
                ptmp = portfolio.copy()
                if 'current_value_krw' not in ptmp.columns:
                    ptmp['current_value_krw'] = 0.0
                ptmp['current_value_krw'] = pd.to_numeric(ptmp['current_value_krw'], errors='coerce').fillna(0.0)
                name_mask = ptmp['name'].fillna('').astype(str).str.strip() == str(machine_selected).strip() if 'name' in ptmp.columns else pd.Series(False, index=ptmp.index)
                ticker = str(mr.get('ticker', '') or '').strip()
                ticker_mask = ptmp['ticker'].fillna('').astype(str).str.strip() == ticker if ticker and 'ticker' in ptmp.columns else pd.Series(False, index=ptmp.index)
                phit = ptmp.loc[name_mask | ticker_mask]
                if not phit.empty:
                    current_weight = float(phit['current_value_krw'].sum()) / total_assets
            review = lifecycle_transition_review(mr, current_weight, loss_budget, single_cap)
            gate_rows = pd.DataFrame([{'Gate': '가격', 'Status': review['price_gate'], '초보자 설명': review['price_detail']}, {'Gate': 'Evidence', 'Status': review['evidence_gate'], '초보자 설명': review['evidence_detail']}, {'Gate': 'Thesis', 'Status': review['thesis_gate'], '초보자 설명': review['thesis_detail']}, {'Gate': 'Survival', 'Status': review['survival_gate'], '초보자 설명': review['survival_detail']}, {'Gate': 'Risk Cap', 'Status': review['risk_gate'], '초보자 설명': review['risk_detail']}])
            st.dataframe(gate_rows, width='stretch', hide_index=True)
            status = str(review['transition_status'])
            if status == 'READY':
                st.success(f"{review['current_state']} → {review['next_stage']} 조건이 현재 데이터상 통과했습니다. 자동 전환/자동 매수는 하지 않습니다.")
            elif status == 'HOLD':
                st.info('MAX 단계입니다. 추가 확대보다 Thesis·Evidence·Bear Downside 모니터링이 우선입니다.')
            elif status == 'REVIEW':
                st.warning('일부 조건이 아직 REVIEW입니다. 누락된 기준이나 Evidence를 먼저 확인하세요.')
            else:
                st.error('현재 다음 단계 전환이 BLOCKED입니다.')
            if review['reasons']:
                st.markdown('**막히거나 추가 확인이 필요한 이유**')
                for reason in review['reasons']:
                    st.write(f'- {reason}')
            st.info(f"다음 확인: {review['next_check']}")
        st.subheader('전체 Lifecycle 현황')
        cols = ['name', 'price', 'lifecycle_state', 'next_lifecycle_stage', 'transition_status', 'transition_price_gate', 'transition_evidence_gate', 'transition_thesis_gate', 'transition_survival_gate', 'transition_risk_gate', 'state_reason', 'initial_ceiling', 'core_ceiling', 'strong_add_ceiling', 'no_chase_ceiling', 'bear_downside', 'refinancing_gate', 'evidence_status', 'thesis_status', 'state_engine_version', 'transition_engine_version']
        st.dataframe(state_df[[c for c in cols if c in state_df.columns]], width='stretch', hide_index=True)
    st.divider()
    st.subheader('개별 Investment State 편집')
    st.caption('Ceiling, Evidence, Thesis, Survival 입력값을 수정한 뒤 Lifecycle을 다시 계산합니다.')
    if watchlist.empty:
        st.info('Watchlist가 비어 있습니다.')
    else:
        names = watchlist['name'].fillna('').astype(str).tolist()
        selected_name = st.selectbox('편집할 종목', names, key='state_edit_company')
        row_idx = watchlist.index[watchlist['name'].fillna('').astype(str) == str(selected_name)].tolist()
        if row_idx:
            idx = row_idx[0]
            row = watchlist.loc[idx].copy()

            def _txt(v):
                if pd.isna(v):
                    return ''
                s = str(v).strip()
                if s.lower() in {'nan', 'none'}:
                    return ''
                return s

            def _numtxt(v):
                n = pd.to_numeric(pd.Series([v]), errors='coerce').iloc[0]
                return '' if pd.isna(n) else f'{float(n):g}'

            def _choice(options, current):
                cur = _txt(current).upper()
                if cur and cur not in options:
                    return ([cur] + options, 0)
                return (options, options.index(cur) if cur in options else 0)
            st.info(f"현재 가격: {krw(row.get('price'))}  |  bear_downside는 35%이면 0.35로 입력")
            with st.form('investment_state_edit_form'):
                c1, c2, c3 = st.columns(3)
                ref_opts, ref_idx = _choice(['REVIEW', 'PASS-PROXY', 'PASS', 'FAIL'], row.get('refinancing_gate', 'REVIEW'))
                ev_opts, ev_idx = _choice(['PROVISIONAL', 'PASS', 'STRONG', 'STALE', 'FAIL', 'MISSING'], row.get('evidence_status', 'PROVISIONAL'))
                th_opts, th_idx = _choice(['OK', 'FREEZE', 'ADD FREEZE', 'BREAK', 'EXIT'], row.get('thesis_status', 'OK'))
                refinancing_gate = c1.selectbox('refinancing_gate', ref_opts, index=ref_idx, key='state_form_refi')
                evidence_status = c2.selectbox('evidence_status', ev_opts, index=ev_idx, key='state_form_evidence')
                thesis_status = c3.selectbox('thesis_status', th_opts, index=th_idx, key='state_form_thesis')
                bear_downside_txt = c1.text_input('bear_downside', value=_numtxt(row.get('bear_downside')), key='state_form_bear')
                strong_add_txt = c2.text_input('strong_add_ceiling', value=_numtxt(row.get('strong_add_ceiling')), key='state_form_strong')
                core_txt = c3.text_input('core_ceiling', value=_numtxt(row.get('core_ceiling')), key='state_form_core')
                initial_txt = c2.text_input('initial_ceiling', value=_numtxt(row.get('initial_ceiling')), key='state_form_initial')
                no_chase_txt = c3.text_input('no_chase_ceiling', value=_numtxt(row.get('no_chase_ceiling')), key='state_form_no_chase')
                submitted = st.form_submit_button('선택 종목 상태 저장', type='primary')
            if submitted:

                def _parse_optional_float(label, value):
                    s = str(value).strip().replace(',', '')
                    if s == '':
                        return float('nan')
                    try:
                        return float(s)
                    except Exception:
                        st.error(f'{label} 값이 숫자가 아닙니다: {value}')
                        st.stop()
                updated = watchlist.copy()
                for col in ['refinancing_gate', 'evidence_status', 'thesis_status']:
                    if col not in updated.columns:
                        updated[col] = ''
                    updated[col] = updated[col].astype('object')
                numeric_updates = {'bear_downside': _parse_optional_float('bear_downside', bear_downside_txt), 'strong_add_ceiling': _parse_optional_float('strong_add_ceiling', strong_add_txt), 'core_ceiling': _parse_optional_float('core_ceiling', core_txt), 'initial_ceiling': _parse_optional_float('initial_ceiling', initial_txt), 'no_chase_ceiling': _parse_optional_float('no_chase_ceiling', no_chase_txt)}
                for col in numeric_updates:
                    if col not in updated.columns:
                        updated[col] = float('nan')
                    updated[col] = pd.to_numeric(updated[col], errors='coerce')
                old_bear = pd.to_numeric(pd.Series([updated.at[idx, 'bear_downside']]), errors='coerce').iloc[0] if 'bear_downside' in updated.columns else float('nan')
                old_nc = pd.to_numeric(pd.Series([updated.at[idx, 'no_chase_ceiling']]), errors='coerce').iloc[0] if 'no_chase_ceiling' in updated.columns else float('nan')
                updated.at[idx, 'refinancing_gate'] = refinancing_gate
                updated.at[idx, 'evidence_status'] = evidence_status
                updated.at[idx, 'thesis_status'] = thesis_status
                for col, val in numeric_updates.items():
                    updated.at[idx, col] = val
                new_bear = numeric_updates['bear_downside']
                new_nc = numeric_updates['no_chase_ceiling']
                bear_changed = not (pd.isna(old_bear) and pd.isna(new_bear) or (not pd.isna(old_bear) and (not pd.isna(new_bear)) and (abs(float(old_bear) - float(new_bear)) < 1e-12)))
                nc_changed = not (pd.isna(old_nc) and pd.isna(new_nc) or (not pd.isna(old_nc) and (not pd.isna(new_nc)) and (abs(float(old_nc) - float(new_nc)) < 1e-09)))
                if bear_changed or nc_changed:
                    for acol in ['assumption_status', 'assumption_reviewed_at']:
                        if acol not in updated.columns:
                            updated[acol] = pd.Series([''] * len(updated), index=updated.index, dtype='object')
                        else:
                            updated[acol] = updated[acol].fillna('').astype('object')
                    updated.at[idx, 'assumption_status'] = 'REVIEW'
                    updated.at[idx, 'assumption_reviewed_at'] = ''
                save_csv(updated, 'watchlist.csv')
                st.success(f'{selected_name} 상태를 저장했습니다.')
                st.rerun()
    st.caption('Lifecycle은 규칙 기반 모니터링 상태입니다. READY도 자동매수 신호가 아니며, Evidence 없이 가격만 내려갔다고 Add하지 않습니다.')
    st.info('bear_downside와 No-Chase는 종목 공통가정입니다. 이 화면에서 값을 바꾸면 Assumption Approval은 REVIEW로 돌아가며, System Integration의 Canonical Editor에서 다시 승인합니다.')
