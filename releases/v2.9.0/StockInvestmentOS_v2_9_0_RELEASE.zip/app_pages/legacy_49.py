from __future__ import annotations
if True:
    st.title('Override Registry')
    st.caption('Risk를 늘리는 예외는 더 높은 Evidence, 승인자, 이유, 만료일이 모두 필요합니다. Override는 기록/검증용이며 Planner의 Hard Gate를 자동으로 완화하지 않습니다.')
    overrides = ensure_cols(load_csv('overrides.csv'), OVERRIDE_COLS)
    for c in OVERRIDE_COLS:
        overrides[c] = overrides[c].fillna('').astype(str)
    checked = validate_overrides(overrides)
    active = active_overrides(overrides)
    c1, c2, c3 = st.columns(3)
    c1.metric('Overrides', len(overrides))
    c2.metric('Valid Active', len(active))
    c3.metric('Invalid / Expired', max(0, len(checked) - len(active)))
    st.subheader('Registry')
    st.dataframe(overrides, width='stretch', hide_index=True)
    if overrides.empty:
        st.info('Override가 없습니다. Scenario Compare에서 1-Lot Override DRAFT를 먼저 만들 수 있습니다.')
    else:
        labels = [f"{i + 1}. {row.get('company', '')} / {row.get('override_type', '')} / {row.get('status', '')}" for i, row in overrides.iterrows()]
        selected_label = st.selectbox('수정할 Override 선택', labels)
        selected_idx = labels.index(selected_label)
        current = overrides.iloc[selected_idx].to_dict()

        def txt(v):
            s = '' if v is None else str(v)
            return '' if s.lower() in {'nan', 'none'} else s
        with st.form('override_edit_form'):
            st.markdown('### 선택한 Override 수정')
            a, b = st.columns(2)
            override_id = a.text_input('override_id', value=txt(current.get('override_id')))
            company = b.text_input('company', value=txt(current.get('company')))
            a, b = st.columns(2)
            override_type = a.text_input('override_type', value=txt(current.get('override_type')))
            requested_change = b.text_input('requested_change', value=txt(current.get('requested_change')))
            reason = st.text_area('reason', value=txt(current.get('reason')), height=110)
            a, b, c = st.columns(3)
            evidence_options = ['', 'PRIMARY', 'HIGH', 'MEDIUM', 'LOW']
            current_ev = txt(current.get('evidence_level')).upper()
            ev_index = evidence_options.index(current_ev) if current_ev in evidence_options else 0
            evidence_level = a.selectbox('evidence_level', evidence_options, index=ev_index)
            approved_by = b.text_input('approved_by', value=txt(current.get('approved_by')))
            start_date = c.text_input('start_date', value=txt(current.get('start_date')), placeholder='YYYY-MM-DD')
            a, b = st.columns(2)
            expiry_date = a.text_input('expiry_date', value=txt(current.get('expiry_date')), placeholder='YYYY-MM-DD')
            status_options = ['DRAFT', 'APPROVED', 'REJECTED', 'EXPIRED']
            current_status = txt(current.get('status')).upper() or 'DRAFT'
            st_index = status_options.index(current_status) if current_status in status_options else 0
            status = b.selectbox('status', status_options, index=st_index)
            notes = st.text_area('notes', value=txt(current.get('notes')), height=100)
            save_one = st.form_submit_button('선택한 Override 저장', type='primary')
        if save_one:
            updated = overrides.copy()
            values = {'override_id': override_id, 'company': company, 'override_type': override_type, 'requested_change': requested_change, 'reason': reason, 'evidence_level': evidence_level, 'approved_by': approved_by, 'start_date': start_date, 'expiry_date': expiry_date, 'status': status, 'notes': notes}
            for c, v in values.items():
                updated.at[selected_idx, c] = v
            save_csv(ensure_cols(updated, OVERRIDE_COLS), 'overrides.csv')
            st.success('선택한 Override를 저장했습니다.')
            st.rerun()
    st.subheader('Validation')
    checked = validate_overrides(overrides)
    st.dataframe(checked, width='stretch', hide_index=True)
    st.info('필수: status=APPROVED, approved_by, 충분한 reason, evidence_level=HIGH/PRIMARY, 미래 expiry_date. Planner 자동적용은 기본 OFF입니다.')
