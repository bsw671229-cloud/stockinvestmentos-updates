from __future__ import annotations
if True:
    st.title('Scenario Refresh')
    st.caption('새 실적·공시·수주·현금흐름 Evidence가 나오면 Bull/Base/Bear/Tail 가정을 다시 적고, Value · Bear Downside · Risk Size · Thesis/Lifecycle 영향이 어떻게 바뀌는지 비교합니다.')
    st.info("이 화면은 Canonical Assumption, Lifecycle, Add Freeze를 자동 변경하지 않습니다. APPROVED는 '가정을 직접 검토했다'는 뜻이지 미래 결과가 확정됐다는 뜻이 아닙니다.")
    if watchlist.empty:
        st.warning('Watchlist가 비어 있습니다.')
    else:
        sr_names = watchlist['name'].fillna('').astype(str).tolist()
        handed_company = str(st.session_state.get('scenario_refresh_company', '') or '').strip()
        sr_default = sr_names.index(handed_company) if handed_company in sr_names else 0
        sr_company = st.selectbox('Scenario Refresh 종목', sr_names, index=sr_default, key='scenario_refresh_company_select')
        st.session_state['scenario_refresh_company'] = sr_company
        sr_hit = watchlist.loc[watchlist['name'].fillna('').astype(str).eq(sr_company)]
        sr_row = sr_hit.iloc[0].to_dict()
        sr_ticker = str(sr_row.get('ticker', '') or '').strip()
        sr_history = load_csv('scenario_refresh_reviews.csv')
        latest_approved = latest_approved_refresh(sr_history, sr_company)
        canonical_proxy = canonical_proxy_snapshot(sr_row)
        if latest_approved:
            baseline_options = ['Latest APPROVED Refresh', 'Current Canonical Proxy']
        else:
            baseline_options = ['Current Canonical Proxy']
        sr_company_key = f'{sr_ticker or sr_company}::{sr_company}'
        baseline_choice = st.radio('비교 Baseline', baseline_options, horizontal=True, key=f'scenario_refresh_baseline_source::{sr_company_key}')
        if baseline_choice == 'Latest APPROVED Refresh':
            baseline_snapshot = snapshot_from_approved_record(latest_approved)
            baseline_revision = str(latest_approved.get('timestamp', '') or latest_approved.get('event_date', '') or 'latest')
        else:
            baseline_snapshot = canonical_proxy.copy()
            baseline_revision = 'canonical_proxy'
        sr_input_key = f'{sr_company_key}::{baseline_choice}::{baseline_revision}'
        baseline_valuation = scenario_valuation(baseline_snapshot)
        sr_states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
        sr_state_hit = sr_states.loc[sr_states['name'].fillna('').astype(str).eq(sr_company)] if not sr_states.empty else pd.DataFrame()
        sr_lifecycle = str(sr_state_hit.iloc[0].get('lifecycle_state', 'OBSERVE')) if not sr_state_hit.empty else 'OBSERVE'
        st.subheader('1. 새 Evidence Event')
        e1, e2, e3 = st.columns(3)
        event_date = e1.date_input('Evidence Event Date', value=date.today(), key=f'scenario_refresh_event_date::{sr_company_key}')
        event_type = e2.selectbox('Event Type', ['EARNINGS', 'DISCLOSURE', 'ORDER / CONTRACT', 'CASH FLOW', 'BALANCE SHEET', 'INDUSTRY / REGULATION', 'OTHER'], key=f'scenario_refresh_event_type::{sr_company_key}')
        evidence_signal = e3.selectbox('Evidence Signal', ['NEUTRAL', 'STRENGTHENED', 'WEAKENED', 'INVALIDATION CHECK'], key=f'scenario_refresh_evidence_signal::{sr_company_key}', help='자동판정이 아니라 사용자가 Evidence를 읽고 지정하는 Review Signal입니다.')
        evidence_source = st.text_input('Primary Source / 공시·IR 근거', value='', key=f'scenario_refresh_evidence_source::{sr_company_key}', placeholder='예: DART 공시명, 기업 IR 자료명')
        evidence_note = st.text_area('이번 Evidence에서 실제로 바뀐 것', value='', key=f'scenario_refresh_evidence_note::{sr_company_key}', placeholder='매출/마진/FCF/수주/재무구조 중 무엇이 기존 가정과 달라졌는지 기록')
        sr_plans = normalize_thesis_plans(load_csv('thesis_plans.csv'))
        sr_plan_hit = sr_plans.loc[sr_plans['company'].fillna('').astype(str).eq(sr_company)] if not sr_plans.empty else pd.DataFrame()
        default_next_check = str(sr_plan_hit.iloc[0].get('next_check_date', '') or '') if not sr_plan_hit.empty else ''
        next_check_date = st.text_input('Next Scenario Check Date (YYYY-MM-DD, optional)', value=default_next_check, key=f'scenario_refresh_next_check::{sr_company_key}', help='기존 Thesis Next Check가 있으면 불러옵니다. 임의의 날짜를 자동 생성하지 않습니다.')
        st.subheader('2. Baseline vs Refresh Assumptions')
        st.caption('종목 또는 Baseline을 바꾸면 Refresh 입력값은 해당 종목의 선택 Baseline에서 다시 시작합니다. 다른 종목에서 입력한 값은 자동으로 이어받지 않습니다.')
        baseline_table = pd.DataFrame([['Price', baseline_snapshot.get('price', 0.0)], ['Adjusted normalized FCF/share', baseline_snapshot.get('normalized_fcf_per_share', 0.0)], ['Required Return', baseline_snapshot.get('required_return', 0.0)], ['Terminal Growth', baseline_snapshot.get('terminal_growth', 0.0)], ['Bear 5Y FCF CAGR', baseline_snapshot.get('bear_growth', 0.0)], ['Base 5Y FCF CAGR', baseline_snapshot.get('base_growth', 0.0)], ['Bull 5Y FCF CAGR', baseline_snapshot.get('bull_growth', 0.0)], ['Tail 5Y FCF CAGR', baseline_snapshot.get('tail_growth', 0.0)], ['Bear Probability', baseline_snapshot.get('bear_probability', 0.0)], ['Base Probability', baseline_snapshot.get('base_probability', 0.0)], ['Bull Probability', baseline_snapshot.get('bull_probability', 0.0)], ['Tail Probability', baseline_snapshot.get('tail_probability', 0.0)]], columns=['Baseline Assumption', 'Value'])
        st.dataframe(baseline_table, width='stretch', hide_index=True)
        if baseline_choice == 'Current Canonical Proxy':
            st.caption('첫 Baseline의 Growth/Probability는 Proxy 기본값입니다. APPROVED Refresh를 저장한 뒤부터는 검토된 최신 Refresh를 Baseline으로 선택할 수 있습니다.')
        r1, r2, r3 = st.columns(3)
        refresh_price = r1.number_input('Refresh Price', min_value=0.0, value=float(baseline_snapshot.get('price', 0.0)), step=100.0, key=f'scenario_refresh_price::{sr_input_key}')
        refresh_fcf = r1.number_input('Adjusted normalized FCF/share', min_value=0.0, value=float(baseline_snapshot.get('normalized_fcf_per_share', 0.0)), step=10.0, key=f'scenario_refresh_fcf::{sr_input_key}', help='새 Evidence를 반영한 Normalized FCF/share입니다. 현재가격에서 자동 역산하지 않습니다.')
        refresh_rr = r2.number_input('Required Return / WACC Proxy', min_value=0.001, max_value=0.5, value=float(baseline_snapshot.get('required_return', 0.1)), format='%.3f', key=f'scenario_refresh_rr::{sr_input_key}')
        refresh_tg = r2.number_input('Terminal Growth', min_value=-0.05, max_value=0.1, value=float(baseline_snapshot.get('terminal_growth', 0.02)), format='%.3f', key=f'scenario_refresh_tg::{sr_input_key}')
        st.caption('Scenario 할인율 규칙: Bear = Base +2%p · Bull = Base -1%p(안전제약 적용) · Tail = Base +4%p. 기존 Reverse DCF 계열 규칙과 일관되게 계산합니다.')
        g1, g2, g3, g4 = st.columns(4)
        bear_growth = g1.number_input('Bear 5Y FCF CAGR', min_value=-0.8, max_value=1.0, value=float(baseline_snapshot.get('bear_growth', -0.03)), format='%.3f', key=f'scenario_refresh_bear_growth::{sr_input_key}')
        base_growth = g2.number_input('Base 5Y FCF CAGR', min_value=-0.8, max_value=1.0, value=float(baseline_snapshot.get('base_growth', 0.06)), format='%.3f', key=f'scenario_refresh_base_growth::{sr_input_key}')
        bull_growth = g3.number_input('Bull 5Y FCF CAGR', min_value=-0.8, max_value=1.0, value=float(baseline_snapshot.get('bull_growth', 0.12)), format='%.3f', key=f'scenario_refresh_bull_growth::{sr_input_key}')
        tail_growth = g4.number_input('Tail 5Y FCF CAGR', min_value=-0.95, max_value=1.0, value=float(baseline_snapshot.get('tail_growth', -0.2)), format='%.3f', key=f'scenario_refresh_tail_growth::{sr_input_key}')
        p1, p2, p3, p4 = st.columns(4)
        bear_prob = p1.number_input('Bear Probability', min_value=0.0, max_value=1.0, value=float(baseline_snapshot.get('bear_probability', 0.2)), format='%.3f', key=f'scenario_refresh_bear_prob::{sr_input_key}')
        base_prob = p2.number_input('Base Probability', min_value=0.0, max_value=1.0, value=float(baseline_snapshot.get('base_probability', 0.55)), format='%.3f', key=f'scenario_refresh_base_prob::{sr_input_key}')
        bull_prob = p3.number_input('Bull Probability', min_value=0.0, max_value=1.0, value=float(baseline_snapshot.get('bull_probability', 0.2)), format='%.3f', key=f'scenario_refresh_bull_prob::{sr_input_key}')
        tail_prob = p4.number_input('Tail Probability', min_value=0.0, max_value=1.0, value=float(baseline_snapshot.get('tail_probability', 0.05)), format='%.3f', key=f'scenario_refresh_tail_prob::{sr_input_key}')
        refresh_snapshot = {'price': refresh_price, 'normalized_fcf_per_share': refresh_fcf, 'required_return': refresh_rr, 'terminal_growth': refresh_tg, 'bear_growth': bear_growth, 'base_growth': base_growth, 'bull_growth': bull_growth, 'tail_growth': tail_growth, 'bear_probability': bear_prob, 'base_probability': base_prob, 'bull_probability': bull_prob, 'tail_probability': tail_prob}
        canonical_downside = float(pd.to_numeric(pd.Series([sr_row.get('bear_downside', 0.35)]), errors='coerce').fillna(0.35).iloc[0])
        sr_compare = scenario_refresh_comparison(baseline_snapshot=baseline_snapshot, refresh_snapshot=refresh_snapshot, canonical_bear_downside=canonical_downside, loss_budget=loss_budget, single_name_cap=single_cap, total_assets=total_assets, price=refresh_price, evidence_signal=evidence_signal, current_lifecycle=sr_lifecycle)
        refresh_v = sr_compare.get('refresh', {})
        prob_sum = bear_prob + base_prob + bull_prob + tail_prob
        st.metric('Scenario Probability 합계', pct(prob_sum))
        if abs(prob_sum - 1.0) > 1e-06:
            st.error('Bear/Base/Bull/Tail Probability 합계를 100%로 맞춰야 합니다.')
        if not sr_compare.get('valid', False):
            st.error('Scenario Model REVIEW · ' + str(sr_compare.get('issue', '')))
        else:
            st.subheader('3. Valuation Refresh')
            v1, v2, v3, v4, v5 = st.columns(5)
            implied = refresh_v.get('market_implied_growth')
            v1.metric('Market-implied 5Y FCF CAGR', '-' if implied is None else pct(implied))
            v2.metric('Bear Value', krw(refresh_v.get('bear_value', 0.0)))
            v3.metric('Base Value', krw(refresh_v.get('base_value', 0.0)))
            v4.metric('Bull Value', krw(refresh_v.get('bull_value', 0.0)))
            v5.metric('Tail Value', krw(refresh_v.get('tail_value', 0.0)))
            vv1, vv2, vv3, vv4 = st.columns(4)
            vv1.metric('PW Value', krw(refresh_v.get('pw_value', 0.0)))
            vv2.metric('PW Value Δ vs Baseline', pct(sr_compare.get('pw_value_delta', 0.0)))
            vv3.metric('Bear Value Δ', pct(sr_compare.get('bear_value_delta', 0.0)))
            gap = refresh_v.get('market_expectation_gap')
            vv4.metric('Base - Market-implied Growth', '-' if gap is None else pct(gap))
            st.caption('Value Δ는 선택한 Baseline 대비 모델 변화입니다. 목표주가나 수익 보장이 아닙니다.')
            st.subheader('4. Bear Downside / Loss-budget Risk Size Preview')
            d1, d2, d3, d4 = st.columns(4)
            d1.metric('Canonical Downside', pct(sr_compare.get('canonical_bear_downside', 0.0)))
            d2.metric('Refresh Modeled Downside', pct(sr_compare.get('modeled_bear_downside', 0.0)))
            d3.metric('Downside Δ', ('+' if sr_compare.get('downside_delta', 0.0) > 0 else '') + pct(sr_compare.get('downside_delta', 0.0)))
            d4.metric('Risk Assumption Review', sr_compare.get('risk_assumption_review', 'REVIEW'))
            rs1, rs2, rs3, rs4 = st.columns(4)
            rs1.metric('현재 Loss-budget Max', pct(sr_compare.get('old_risk_max_weight', 0.0)))
            rs2.metric('Refresh Loss-budget Max', pct(sr_compare.get('refresh_risk_max_weight', 0.0)))
            rs3.metric('현재 Risk Ceiling Preview', f"{sr_compare.get('old_risk_ceiling_shares', 0):,}주")
            rs4.metric('Refresh Risk Ceiling Preview', f"{sr_compare.get('refresh_risk_ceiling_shares', 0):,}주")
            st.caption('여기 수량은 Downside와 손실예산만 본 Preview입니다. Factor Cap / Portfolio Fit / Lifecycle / Execution Gate를 우회하지 않습니다.')
            st.subheader('5. Thesis / Lifecycle Impact')
            t1, t2, t3, t4 = st.columns(4)
            t1.metric('Evidence Signal', evidence_signal)
            t2.metric('Model Risk Signal', sr_compare.get('model_risk_signal', 'REVIEW'))
            t3.metric('Add Freeze Review', sr_compare.get('add_freeze_review', 'REVIEW'))
            t4.metric('Current Lifecycle', sr_lifecycle)
            st.write(f"**Combined Signal:** {sr_compare.get('combined_signal', 'REVIEW')}")
            st.write(f"**Scenario Thesis Signal:** {sr_compare.get('thesis_signal', 'REVIEW')}")
            st.write(f"**Lifecycle Impact:** {sr_compare.get('lifecycle_impact', 'REVIEW')}")
            st.caption('Evidence 방향과 Model Risk를 분리해 표시합니다. STRENGTHENED Evidence라도 Bear Downside가 Canonical보다 크게 높아지면 Risk Assumption Review는 유지하며 자동 Add로 연결하지 않습니다. 실제 Lifecycle / Add Freeze 변경은 원본 화면에서 별도 검토합니다.')
            st.subheader('6. Red Team / Invalidation 기록')
            thesis_update_note = st.text_area('Thesis Update', value='', key=f'scenario_refresh_thesis_update::{sr_company_key}', placeholder='이번 Evidence가 기존 투자 가설을 어떻게 강화/약화했는지')
            counter_thesis = st.text_area('가장 강한 반대 가설', value='', key=f'scenario_refresh_counter_thesis::{sr_company_key}', placeholder='현재 Base 가정이 틀렸다면 가장 설득력 있는 반대 설명')
            invalidation_note = st.text_area('Invalidation / 추가 확인 필요', value='', key=f'scenario_refresh_invalidation_note::{sr_company_key}', placeholder='어떤 데이터가 나오면 기존 가정을 틀렸다고 인정할지')
            st.subheader('7. 검토 저장')
            reviewed = st.checkbox('이 Scenario 가정과 Evidence 근거를 직접 검토했습니다.', value=False, key=f'scenario_refresh_reviewed::{sr_input_key}')
            review_status = 'APPROVED' if reviewed else 'DRAFT'
            st.write(f'저장 상태: **{review_status}** · APPROVED는 미래가 확실하다는 뜻이 아닙니다.')
            if st.button('현재 Scenario Refresh 저장', key=f'save_scenario_refresh::{sr_input_key}'):
                record = scenario_refresh_record(company=sr_company, ticker=sr_ticker, review_status=review_status, baseline_source=baseline_snapshot.get('baseline_source', baseline_choice), event_date=event_date.isoformat(), event_type=event_type, evidence_signal=evidence_signal, evidence_source=evidence_source, evidence_note=evidence_note, next_check_date=next_check_date, refresh_snapshot=refresh_snapshot, comparison=sr_compare, thesis_update_note=thesis_update_note, counter_thesis=counter_thesis, invalidation_note=invalidation_note)
                hist = load_csv('scenario_refresh_reviews.csv')
                for col in SCENARIO_REFRESH_COLS:
                    if col not in hist.columns:
                        hist[col] = ''
                hist = pd.concat([hist[SCENARIO_REFRESH_COLS], pd.DataFrame([record])], ignore_index=True)
                verified_save_feedback(hist, 'scenario_refresh_reviews.csv', f'Scenario Refresh를 {review_status} 상태로 저장했습니다.', rerun=True)
            if sr_compare.get('risk_assumption_review') == 'REVIEW':
                st.warning('Modeled Bear Downside가 Canonical 위험가정과 의미 있게 다릅니다. Scenario 저장만으로 Canonical Downside는 바뀌지 않습니다.')
                st.button('System Integration에서 Canonical Assumption 검토', key=f'scenario_refresh_to_integration::{sr_company_key}', on_click=_navigate, args=('System Integration',))
        st.subheader('8. Scenario Refresh History')
        company_history = sr_history.loc[sr_history['company'].fillna('').astype(str).eq(sr_company)].copy() if not sr_history.empty and 'company' in sr_history.columns else pd.DataFrame()
        if company_history.empty:
            st.info('아직 저장된 Scenario Refresh 기록이 없습니다.')
        else:
            hist_cols = ['timestamp', 'review_status', 'event_date', 'event_type', 'evidence_signal', 'pw_value', 'pw_value_delta', 'modeled_bear_downside', 'downside_delta', 'model_risk_signal', 'combined_signal', 'thesis_signal', 'lifecycle_impact', 'next_check_date']
            history_view_cols = list(dict.fromkeys((c for c in hist_cols if c in company_history.columns)))
            st.dataframe(company_history[history_view_cols].tail(30), width='stretch', hide_index=True)
    st.caption('Scenario Refresh는 새 Evidence를 기존 Model과 비교하는 감사/모니터링 계층입니다. 증권사 주문을 전송하지 않으며 Canonical Assumption·Lifecycle을 자동 변경하지 않습니다.')
