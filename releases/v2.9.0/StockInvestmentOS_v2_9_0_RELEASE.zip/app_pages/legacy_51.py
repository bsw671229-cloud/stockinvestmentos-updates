from __future__ import annotations
if True:
    st.title('Reports & Scheduler')
    st.caption('로컬 일일 보고서 생성과 Windows 작업 스케줄러 연결을 관리합니다. 증권사 주문은 절대 전송하지 않습니다.')
    recon = reconcile_portfolio(portfolio, total_assets, float(settings.get('reconciliation_tolerance_krw', 1000)))
    states = add_states(watchlist, portfolio, total_assets, loss_budget, single_cap)
    alerts = build_alerts(portfolio, states, proof, total_assets, loss_budget, single_cap, float(settings.get('factor_cap', 0.1)))
    clock = enrich_proof_clock(proof)
    disclosures = st.session_state.get('daily_disclosures', pd.DataFrame())
    raw_plan = generate_trade_plan(states, portfolio, total_assets, loss_budget, single_cap, float(settings.get('trade_plan_pilot_fraction', 0.5)))
    report_audit = data_quality_report(watchlist, audit_evidence, int(settings.get('audit_price_freshness_days', 3)))
    if bool(settings.get('planner_requires_audit_ready', True)):
        raw_plan = apply_audit_gate(raw_plan, report_audit)
    funded_plan, _ = build_rebalance_summary(raw_plan, portfolio, total_assets, float(settings.get('minimum_cash_weight', 0.2)), recon['status'])
    if st.button('현재 데이터로 Daily Report 생성', type='primary'):
        path = write_daily_report(ROOT, portfolio, watchlist, states, alerts, clock, disclosures, recon, funded_plan)
        st.success(f'생성 완료: {path.name}')
    reports = list_daily_reports(ROOT)
    st.subheader('Daily Reports')
    if reports.empty:
        st.info('아직 Daily Report가 없습니다.')
    else:
        st.dataframe(reports, width='stretch', hide_index=True)
    st.subheader('Windows Scheduler')
    st.write('평일 지정시간에 자동으로 **로컬 보고서만 생성**하도록 작업 스케줄러를 설정할 수 있습니다.')
    st.code(str(ROOT / 'install_daily_task.bat'))
    st.write('작업을 삭제하려면:')
    st.code(str(ROOT / 'remove_daily_task.bat'))
    st.warning('Scheduled price refresh는 Settings에서 기본 OFF입니다. ON으로 바꾸기 전에는 자동 작업이 저장된 가격을 수정하지 않습니다.')
