"""Session-only, explicit KIS inquiries. No order engine or journal dependency."""
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
import json
import streamlit as st
from connectors.kis_broker import US_BALANCE_INQUIRY_ONLY_EXCHANGES
from broker_inquiry_service import resolve_reference, _run, run_inquiry_check, build_check_report
from broker_market_overview import render as render_market_overview

KST = timezone(timedelta(hours=9))
STATE_KEYS = ('_kis_inquiry_context', '_kis_inquiry_results', '_kis_inquiry_basis', '_kis_inquiry_check', '_kis_market_report')


def clear_results():
    for key in STATE_KEYS:
        st.session_state.pop(key, None)


def format_time(value):
    return datetime.fromisoformat(value).astimezone(KST).strftime('%Y-%m-%d %H:%M:%S KST')


def _status(record):
    if record['status'] == 'PASS':
        st.success('조회 성공')
    elif record['status'] == 'SKIPPED':
        st.info(record['message'])
    else:
        st.error(record['message'])
    st.caption(f"확인: {format_time(record['checked_at'])} · {record['elapsed_ms']}ms")
    diagnostic = record.get('diagnostic', {})
    if diagnostic.get('attempts', 1) > 1:
        st.caption('일시 오류 후 조회를 1회 다시 확인했습니다.')
    if record['status'] != 'PASS' or diagnostic.get('first_error'):
        with st.expander('조회 진단'):
            st.write(diagnostic or {'안내': '증권사 요청 전 입력값 점검에서 중단되었습니다.'})
            st.caption('오류 코드와 요청 상태만 표시합니다. 서버 원문·키·계좌번호는 표시하지 않습니다.')


def render(client):
    st.subheader('시세·잔고·주문 가능금액 조회')
    st.caption('현재 연결을 함께 사용합니다. 버튼을 누른 항목만 조회하며 주문 기록을 만들지 않습니다.')
    view = st.radio('조회 범위', ['SINGLE', 'BOTH'],
        format_func=lambda value: '선택 시장' if value == 'SINGLE' else '국내·미국 통합',
        key='kis_ro_range', horizontal=True, on_change=clear_results)
    if view == 'BOTH':
        render_market_overview(client, clear_results)
        return
    market = st.selectbox('조회 시장', ['KR', 'US'], format_func=lambda value: '국내 주식·ETF' if value == 'KR' else '미국 주식·ETF', key='kis_ro_market')
    exchange = st.selectbox('조회 거래소', ['KRX'] if market == 'KR' else ['NASD', 'NYSE', 'AMEX'], key='kis_ro_exchange_' + market)
    symbol = st.text_input('조회 종목코드', value='005930' if market == 'KR' else 'AAPL', key='kis_ro_symbol_' + market).strip().upper()
    currency = 'KRW' if market == 'KR' else 'USD'
    context = (client.credentials.identity, market, exchange, symbol)
    if st.session_state.get('_kis_inquiry_context') != context:
        clear_results()
        st.session_state['_kis_inquiry_context'] = context
    results = st.session_state.setdefault('_kis_inquiry_results', {})
    st.caption('함께 조회는 새 시세로 가능금액을 계산한 뒤 잔고를 확인합니다. 수동 계산가격은 사용하지 않습니다.')
    if st.button('선택 시장 한 번에 조회', key='kis_ro_check', type='primary'):
        results.clear()
        st.session_state.pop('_kis_inquiry_check', None)
        st.session_state['kis_ro_reference'] = 'QUOTE'
        with st.spinner('시세·주문 가능금액·잔고를 확인하고 있습니다…'):
            check = run_inquiry_check(client, market, exchange, symbol)
        results.update(check['results'])
        st.session_state['_kis_inquiry_basis'] = ('QUOTE', results['quote']['checked_at'])
        st.session_state['_kis_inquiry_check'] = build_check_report(check,
            version=Path(__file__).with_name('VERSION').read_text(encoding='utf-8-sig').strip(),
            mode=client.credentials.mode, market=market, exchange=exchange)
    with st.container(border=True):
        st.markdown('**시세**')
        if st.button('시세 새로 조회', key='kis_ro_quote'):
            st.session_state.pop('_kis_inquiry_check', None)
            results['quote'] = _run(client, lambda: client.inquire_quote(market, exchange, symbol))
            if st.session_state.get('kis_ro_reference', 'QUOTE') == 'QUOTE':
                results.pop('power', None)
        quote = results.get('quote')
        if quote:
            _status(quote)
            if quote['status'] == 'PASS':
                st.metric('증권사 조회 가격', f"{Decimal(quote['data']['price']):,f} {currency}")
                st.caption('API 조회시각이며 거래소 체결시각은 아닙니다. 실시간 체결 가격을 보장하지 않습니다.')
    with st.container(border=True):
        st.markdown('**보유 주식 잔고**')
        if market == 'US' and exchange == 'NASD' and client.credentials.mode == 'LIVE':
            st.caption('실전 NASD 잔고 조회는 미국 전체 거래소를 포함합니다.')
        if st.button('잔고 새로 조회', key='kis_ro_positions'):
            st.session_state.pop('_kis_inquiry_check', None)
            results['positions'] = _run(client, lambda: client.positions(market, exchange))
        positions = results.get('positions')
        if positions:
            _status(positions)
            if positions['status'] == 'PASS':
                data = positions['data']
                st.caption(f"조회 범위: {data['scope']} · 연속조회 완료")
                rows = [{'종목': p['symbol'], '거래소': p['exchange'], '보유 수량': p['quantity'],
                    '매도 가능 수량': p['sellable_quantity'], '통화': p['currency']} for p in data['positions']]
                if any(p['exchange'] in US_BALANCE_INQUIRY_ONLY_EXCHANGES for p in data['positions']):
                    for row in rows:
                        row['앱 주문'] = '조회 전용' if row['거래소'] in US_BALANCE_INQUIRY_ONLY_EXCHANGES else '별도 점검 필요'
                    st.info('OTCB 보유 내역은 조회 전용입니다. 이 프로그램에서 해당 거래소 주문은 지원하지 않습니다. 매도 가능 수량은 증권사 응답 값입니다.')
                if rows: st.dataframe(rows, hide_index=True, alt='증권사 보유 주식 수량과 매도 가능 수량')
                else: st.info('조회된 보유 주식이 없습니다.')
    with st.container(border=True):
        st.markdown('**주문 가능금액**')
        method = st.radio('금액 조회 계산가격', ['QUOTE', 'MANUAL'],
            format_func=lambda value: '최근 조회 가격 (60초 이내)' if value == 'QUOTE' else '계산가격 직접 입력',
            key='kis_ro_reference', horizontal=True)
        manual = st.text_input('계산가격 (' + currency + ')', value='0', key='kis_ro_manual_' + market) if method == 'MANUAL' else '0'
        basis = (method, manual if method == 'MANUAL' else results.get('quote', {}).get('checked_at'))
        if st.session_state.get('_kis_inquiry_basis') != basis:
            st.session_state.pop('_kis_inquiry_check', None)
            results.pop('power', None)
            st.session_state['_kis_inquiry_basis'] = basis
        if method == 'MANUAL': st.caption('입력한 가격에 따른 가능금액·수량만 계산합니다. 최신 시세 조회 성공으로 처리하지 않습니다.')
        st.caption('국내: 미수 없는 매수금액 · 미국: 주문 가능 외화금액(USD). 수수료 포함 실제 주문 가능 여부는 전송 전 별도 점검합니다.')
        if st.button('주문 가능금액 조회', key='kis_ro_power'):
            st.session_state.pop('_kis_inquiry_check', None)
            def lookup():
                price, reference = resolve_reference(results.get('quote'), method, manual, currency)
                return {**client.inquire_buying_power(market, exchange, symbol, price), 'basis': reference}
            results['power'] = _run(client, lookup)
        power = results.get('power')
        if power:
            _status(power)
            if power['status'] == 'PASS':
                data = power['data']
                st.metric('주문 가능금액', f"{Decimal(data['cash']):,.2f} {data['currency']}")
                st.write(f"{symbol} 조회 가능수량: {data['quantity']}주")
                st.caption(f"계산 기준: {data['basis']['label']} · {data['reference_price']} {currency}")
                if data['basis'].get('quote_fetched_at'):
                    st.caption('기준 가격 조회: ' + format_time(data['basis']['quote_fetched_at']))
                if data['quantity'] == 0: st.info('조회는 정상이며, 이 종목·계산가격의 가능수량은 0주입니다.')
    report = st.session_state.get('_kis_inquiry_check')
    if report:
        with st.container(border=True):
            st.markdown('**함께 조회 결과**')
            if report['status'] == 'PASS':
                st.success('시세·잔고·주문 가능금액 조회가 모두 성공했습니다.')
            else:
                st.warning('일부 조회를 확인하지 못했습니다. 아래 항목별 결과를 확인하세요.')
            labels = {'quote': '시세', 'positions': '잔고', 'power': '주문 가능금액'}
            statuses = {'PASS': '조회 성공', 'CHECK_REQUIRED': '확인 필요', 'SKIPPED': '건너뜀', 'UNKNOWN': '미확인'}
            st.table([{'항목': label, '결과': statuses[report['checks'][name]['status']]} for name, label in labels.items()],
                alt='함께 조회한 시세, 잔고, 주문 가능금액의 항목별 성공 여부')
            st.caption(f"마지막 함께 조회: {format_time(report['finished_at'])} · 전체 {report['elapsed_ms']}ms")
            st.caption('이 결과는 위 조회시각의 점검 기록이며 주문 허용이나 체결 확인이 아닙니다.')
            st.download_button('점검 결과 저장', data=json.dumps(report, ensure_ascii=False, indent=2),
                file_name='StockInvestmentOS_inquiry_check.json', mime='application/json',
                key='kis_ro_report', on_click='ignore')
            st.caption('저장 파일에는 점검 환경·상태·시각·오류 코드만 포함합니다. 키·계좌·종목·보유 내역·가격·금액은 제외합니다.')
    st.caption('조회 결과는 현재 브라우저 세션에만 보관됩니다. 연결을 끊거나 새로 연결하면 조회 결과를 지웁니다.')
