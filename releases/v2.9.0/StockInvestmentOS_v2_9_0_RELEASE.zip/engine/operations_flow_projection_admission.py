from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_projection import calibration_source_freshness
from engine.operations_flow_calibration_promotion import (
    flow_calibration_promotion_snapshot_integrity,
)


FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS = [
    "admission_snapshot_id",
    "created_at",
    "admission_state",
    "effective_projection_guard",
    "calibration_source_freshness",
    "calibration_source_integrity",
    "calibration_snapshot_id",
    "calibration_snapshot_hash",
    "promotion_source_freshness",
    "promotion_source_integrity",
    "promotion_snapshot_id",
    "promotion_snapshot_hash",
    "promotion_state",
    "promotion_guard",
    "promotion_observed_intervals",
    "promotion_target_intervals",
    "source_order_state",
    "projection_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PROJECTION_ADMISSION_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


_PROMOTION_INT_FIELDS = {
    "qualified_endpoints",
    "observed_intervals",
    "target_intervals",
    "positive_burn_intervals",
    "zero_burn_intervals",
    "negative_burn_intervals",
}

_PROMOTION_FLOAT_FIELDS = {
    "positive_burn_ratio",
    "avg_net_burn_per_interval",
    "latest_net_burn",
    "min_net_burn",
    "max_net_burn",
}

_PROMOTION_TEXT_FIELDS = {
    "calibration_state",
    "raw_projection_guard",
    "evidence_state",
    "evidence_window_state",
    "promotion_state",
    "promotion_guard",
    "effective_projection_guard",
    "projection_authorization",
    "execution_authorization",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def promotion_source_freshness(
    promotion: dict | None,
    source_snapshot: dict | None,
    *,
    float_tolerance: float = 1e-8,
) -> dict:
    current = promotion or {}
    source = source_snapshot or {}

    if not source:
        return {
            "status": "MISSING",
            "source_integrity": "NONE",
            "mismatches": [],
            "mismatch_count": 0,
        }

    integrity = flow_calibration_promotion_snapshot_integrity(source)
    integrity_status = _text(integrity.get("status")).upper()

    if integrity_status != "OK":
        return {
            "status": "INVALID",
            "source_integrity": integrity_status or "INVALID",
            "mismatches": ["snapshot_hash"],
            "mismatch_count": 1,
        }

    mismatches = []

    for field in _PROMOTION_INT_FIELDS:
        if _int(current.get(field)) != _int(source.get(field)):
            mismatches.append(field)

    for field in _PROMOTION_FLOAT_FIELDS:
        if (
            abs(
                _float(current.get(field))
                - _float(source.get(field))
            )
            > float(float_tolerance)
        ):
            mismatches.append(field)

    for field in _PROMOTION_TEXT_FIELDS:
        if _text(current.get(field)) != _text(source.get(field)):
            mismatches.append(field)

    return {
        "status": "CURRENT" if not mismatches else "DRIFTED",
        "source_integrity": "OK",
        "mismatches": mismatches,
        "mismatch_count": len(mismatches),
    }


def _source_order_state(
    calibration_snapshot: dict | None,
    promotion_snapshot: dict | None,
) -> str:
    cal = calibration_snapshot or {}
    promo = promotion_snapshot or {}

    if not cal or not promo:
        return "NOT_APPLICABLE"

    cal_ts = pd.to_datetime(
        cal.get("created_at"),
        errors="coerce",
        utc=True,
    )
    promo_ts = pd.to_datetime(
        promo.get("created_at"),
        errors="coerce",
        utc=True,
    )

    if pd.isna(cal_ts) or pd.isna(promo_ts):
        return "INVALID_TIME"

    if promo_ts >= cal_ts:
        return "PROMOTION_AFTER_CALIBRATION"

    return "PROMOTION_PRECEDES_CALIBRATION"


def build_flow_projection_admission(
    calibration: dict | None,
    promotion: dict | None,
    source_calibration_snapshot: dict | None,
    source_promotion_snapshot: dict | None,
) -> dict:
    cal = calibration or {}
    promo = promotion or {}
    cal_source = source_calibration_snapshot or {}
    promo_source = source_promotion_snapshot or {}

    promotion_state = _text(
        promo.get("promotion_state")
    ).upper()
    promotion_guard = _text(
        promo.get("effective_projection_guard")
    ).upper()
    current_guard = _text(
        cal.get("projection_guard")
    ).upper()

    # Admission is a tightening layer only. When upstream evidence/promotion
    # is still HOLD, no extra Snapshot work is required merely to escape HOLD.
    if (
        promotion_state != "PROMOTION_READY"
        or current_guard != "ALLOW_PROJECTION_REVIEW"
        or promotion_guard != "ALLOW_PROJECTION_REVIEW"
    ):
        return {
            "admission_state": "ADMISSION_UPSTREAM_HOLD",
            "effective_projection_guard":
                current_guard or promotion_guard or "HOLD_CALIBRATION",
            "calibration_source_freshness": "NOT_REQUIRED",
            "calibration_source_integrity": "NOT_REQUIRED",
            "calibration_source_mismatches": [],
            "promotion_source_freshness": "NOT_REQUIRED",
            "promotion_source_integrity": "NOT_REQUIRED",
            "promotion_source_mismatches": [],
            "calibration_snapshot_id": _text(
                cal_source.get("calibration_snapshot_id")
            ),
            "calibration_snapshot_hash": _text(
                cal_source.get("snapshot_hash")
            ),
            "promotion_snapshot_id": _text(
                promo_source.get("promotion_snapshot_id")
            ),
            "promotion_snapshot_hash": _text(
                promo_source.get("snapshot_hash")
            ),
            "promotion_state": promotion_state,
            "promotion_guard": promotion_guard,
            "promotion_observed_intervals": _int(
                promo.get("observed_intervals")
            ),
            "promotion_target_intervals": _int(
                promo.get("target_intervals")
            ),
            "source_order_state": "NOT_REQUIRED",
            "projection_authorization": "NONE",
            "execution_authorization": "NONE",
        }

    cal_fresh = calibration_source_freshness(
        cal,
        cal_source,
    )
    promo_fresh = promotion_source_freshness(
        promo,
        promo_source,
    )
    order_state = _source_order_state(
        cal_source,
        promo_source,
    )

    cal_status = _text(
        cal_fresh.get("status")
    ).upper()
    promo_status = _text(
        promo_fresh.get("status")
    ).upper()

    if cal_status == "MISSING":
        state = "ADMISSION_CALIBRATION_SOURCE_REQUIRED"
        guard = "HOLD_ADMISSION_SOURCE"
    elif cal_status == "INVALID":
        state = "ADMISSION_CALIBRATION_SOURCE_INTEGRITY_REVIEW"
        guard = "HOLD_ADMISSION_SOURCE"
    elif cal_status == "DRIFTED":
        state = "ADMISSION_CALIBRATION_SOURCE_DRIFT_REVIEW"
        guard = "HOLD_ADMISSION_SOURCE"
    elif promo_status == "MISSING":
        state = "ADMISSION_PROMOTION_SOURCE_REQUIRED"
        guard = "HOLD_ADMISSION_SOURCE"
    elif promo_status == "INVALID":
        state = "ADMISSION_PROMOTION_SOURCE_INTEGRITY_REVIEW"
        guard = "HOLD_ADMISSION_SOURCE"
    elif promo_status == "DRIFTED":
        state = "ADMISSION_PROMOTION_SOURCE_DRIFT_REVIEW"
        guard = "HOLD_ADMISSION_SOURCE"
    elif order_state == "INVALID_TIME":
        state = "ADMISSION_SOURCE_TIME_INTEGRITY_REVIEW"
        guard = "HOLD_ADMISSION_SOURCE"
    elif order_state == "PROMOTION_PRECEDES_CALIBRATION":
        state = "ADMISSION_PROMOTION_AFTER_CALIBRATION_REQUIRED"
        guard = "HOLD_ADMISSION_SOURCE"
    else:
        state = "ADMISSION_READY_FOR_REVIEW"
        guard = "ALLOW_PROJECTION_REVIEW"

    return {
        "admission_state": state,
        "effective_projection_guard": guard,
        "calibration_source_freshness": cal_status or "MISSING",
        "calibration_source_integrity": _text(
            cal_fresh.get("source_integrity")
        ).upper(),
        "calibration_source_mismatches": list(
            cal_fresh.get("mismatches", [])
        ),
        "promotion_source_freshness": promo_status or "MISSING",
        "promotion_source_integrity": _text(
            promo_fresh.get("source_integrity")
        ).upper(),
        "promotion_source_mismatches": list(
            promo_fresh.get("mismatches", [])
        ),
        "calibration_snapshot_id": _text(
            cal_source.get("calibration_snapshot_id")
        ),
        "calibration_snapshot_hash": _text(
            cal_source.get("snapshot_hash")
        ),
        "promotion_snapshot_id": _text(
            promo_source.get("promotion_snapshot_id")
        ),
        "promotion_snapshot_hash": _text(
            promo_source.get("snapshot_hash")
        ),
        "promotion_state": promotion_state,
        "promotion_guard": promotion_guard,
        "promotion_observed_intervals": _int(
            promo.get("observed_intervals")
        ),
        "promotion_target_intervals": _int(
            promo.get("target_intervals")
        ),
        "source_order_state": order_state,
        "projection_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def build_flow_projection_admission_queue(
    admission: dict | None,
) -> pd.DataFrame:
    adm = admission or {}
    state = _text(
        adm.get("admission_state")
    ).upper()

    if state == "ADMISSION_UPSTREAM_HOLD":
        rows = [{
            "priority": "PA2",
            "status": "WAIT",
            "issue": "PROJECTION_ADMISSION_UPSTREAM_HOLD",
            "detail": (
                f"promotion {adm.get('promotion_state','')} · "
                f"guard {adm.get('effective_projection_guard','')}"
            ),
            "next_action": (
                "Promotion/Evidence proof가 자연스럽게 성숙할 때까지 기존 Guard 유지"
            ),
            "go_to": "Operations Control Tower",
        }]
    elif state == "ADMISSION_CALIBRATION_SOURCE_REQUIRED":
        rows = [{
            "priority": "PA1",
            "status": "REVIEW",
            "issue": "PROJECTION_ADMISSION_CALIBRATION_SOURCE_REQUIRED",
            "detail": "CURRENT Calibration Snapshot 없음",
            "next_action": "1H에서 현재 Calibration Snapshot 저장",
            "go_to": "Operations Control Tower",
        }]
    elif state in {
        "ADMISSION_CALIBRATION_SOURCE_INTEGRITY_REVIEW",
        "ADMISSION_CALIBRATION_SOURCE_DRIFT_REVIEW",
    }:
        rows = [{
            "priority": "PA0",
            "status": "BLOCKED",
            "issue": "PROJECTION_ADMISSION_CALIBRATION_SOURCE_REVIEW",
            "detail": state,
            "next_action": "Calibration Snapshot integrity/current 상태를 먼저 복구",
            "go_to": "Operations Control Tower",
        }]
    elif state == "ADMISSION_PROMOTION_SOURCE_REQUIRED":
        rows = [{
            "priority": "PA1",
            "status": "REVIEW",
            "issue": "PROJECTION_ADMISSION_PROMOTION_SOURCE_REQUIRED",
            "detail": "CURRENT Promotion Audit Snapshot 없음",
            "next_action": (
                "Calibration Snapshot CURRENT 확인 후 1H-P Promotion Snapshot 저장"
            ),
            "go_to": "Operations Control Tower",
        }]
    elif state in {
        "ADMISSION_PROMOTION_SOURCE_INTEGRITY_REVIEW",
        "ADMISSION_PROMOTION_SOURCE_DRIFT_REVIEW",
        "ADMISSION_PROMOTION_AFTER_CALIBRATION_REQUIRED",
        "ADMISSION_SOURCE_TIME_INTEGRITY_REVIEW",
    }:
        rows = [{
            "priority": "PA0",
            "status": "BLOCKED",
            "issue": "PROJECTION_ADMISSION_PROMOTION_SOURCE_REVIEW",
            "detail": state,
            "next_action": (
                "현재 Calibration Snapshot을 먼저 저장/확인한 뒤 Promotion Audit Snapshot을 다시 저장"
            ),
            "go_to": "Operations Control Tower",
        }]
    elif state == "ADMISSION_READY_FOR_REVIEW":
        rows = [{
            "priority": "PA3",
            "status": "MONITOR",
            "issue": "PROJECTION_ADMISSION_READY",
            "detail": (
                f"calibration {adm.get('calibration_source_freshness','')} · "
                f"promotion {adm.get('promotion_source_freshness','')}"
            ),
            "next_action": (
                "Projection 시나리오를 Human Review. 자동 Projection/Capacity 승인 없음"
            ),
            "go_to": "Operations Control Tower",
        }]
    else:
        rows = [{
            "priority": "PA0",
            "status": "BLOCKED",
            "issue": "PROJECTION_ADMISSION_UNKNOWN_STATE",
            "detail": state or "MISSING",
            "next_action": "Admission state vocabulary 확인",
            "go_to": "Operations Control Tower",
        }]

    order = {
        "PA0": 0,
        "PA1": 1,
        "PA2": 2,
        "PA3": 3,
    }
    out = pd.DataFrame(
        rows,
        columns=PROJECTION_ADMISSION_QUEUE_COLS,
    )
    out["_p"] = out["priority"].map(
        order
    ).fillna(9)

    return (
        out.sort_values(["_p", "issue"])
        .drop(columns=["_p"])
        .reset_index(drop=True)
    )


def _snapshot_payload(row: dict) -> dict:
    payload = {}

    for col in FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS:
        if col in {
            "admission_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in {
            "promotion_observed_intervals",
            "promotion_target_intervals",
        }:
            payload[col] = _int(
                row.get(col)
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def build_flow_projection_admission_snapshot(
    admission: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        col: admission.get(col, "")
        for col in FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS
        if col not in {
            "admission_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }
    }
    base["projection_authorization"] = "NONE"
    base["execution_authorization"] = "NONE"

    snapshot_hash = _hash(
        _snapshot_payload(base)
    )

    return {
        "admission_snapshot_id": (
            "OPA-"
            + pd.Timestamp(now).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_projection_admission_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )
    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _snapshot_payload(item)
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_flow_projection_admission_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )
