from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from engine.recovery_readiness import (
    build_recovery_readiness,
)
from engine.backup_manifest_recovery import (
    discover_latest_backup_folder,
    verify_backup_manifest,
    restore_dry_run,
)
from engine.recovery_resilience import (
    build_recovery_point_drift,
    build_backup_rotation_plan,
    build_restore_simulation_plan,
)
from engine.recovery_release_governance import (
    build_recovery_release_gate,
    latest_matching_runbook_lock,
    dr_runbook_lock_integrity,
)


V124_RELEASE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check":
            check,
        "status":
            (
                "PASS"
                if passed
                else "BLOCKED"
            ),
        "detail":
            detail,
        "blocking":
            (
                "NO"
                if passed
                else "YES"
            ),
    }


def _csv_counts(
    save_health: pd.DataFrame | None,
) -> tuple[int, int, int]:
    if (
        save_health is None
        or save_health.empty
    ):
        return (
            0,
            0,
            0,
        )

    if "status" not in save_health.columns:
        return (
            0,
            0,
            int(
                len(
                    save_health
                )
            ),
        )

    status = (
        save_health[
            "status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
    )

    return (
        int(
            status.eq(
                "PASS"
            ).sum()
        ),
        int(
            status.eq(
                "FAIL"
            ).sum()
        ),
        int(
            len(
                save_health
            )
        ),
    )


def build_recovery_integration_context(
    *,
    project_root: str | Path,
    latest_backup: dict | None,
    save_health: pd.DataFrame | None,
    save_events: pd.DataFrame | None,
    recovery_point_locks: pd.DataFrame | None,
    runbook_locks: pd.DataFrame | None,
    now: datetime | pd.Timestamp | str | None = None,
    keep_latest: int = 3,
) -> dict:
    csv_pass, csv_fail, csv_files = _csv_counts(
        save_health
    )

    readiness = build_recovery_readiness(
        csv_pass=csv_pass,
        csv_fail=csv_fail,
        current_csv_files=csv_files,
        backup_info=latest_backup or {},
        save_events=save_events,
        max_backup_age_days=7,
        recent_event_window=20,
        now=now,
    )

    discovery = discover_latest_backup_folder(
        project_root,
        latest_backup or {},
    )
    verification = verify_backup_manifest(
        discovery
    )
    dry_run = restore_dry_run(
        verification
    )

    drift = build_recovery_point_drift(
        verification,
        dry_run,
        recovery_point_locks,
    )

    rotation = build_backup_rotation_plan(
        recovery_point_locks,
        current_manifest_sha256=_text(
            verification.get(
                "manifest_sha256"
            )
        ),
        keep_latest=keep_latest,
    )

    simulation = build_restore_simulation_plan(
        verification,
        dry_run,
        drift,
    )

    recovery_release = build_recovery_release_gate(
        readiness,
        verification,
        dry_run,
        drift,
        rotation,
        simulation,
    )

    manifest_sha = _text(
        verification.get(
            "manifest_sha256"
        )
    )

    runbook = latest_matching_runbook_lock(
        runbook_locks,
        manifest_sha,
    )

    if runbook:
        runbook_integrity = dr_runbook_lock_integrity(
            runbook
        )[
            "status"
        ]
        runbook_audit = _text(
            runbook.get(
                "audit_closure_status"
            )
        ).upper()
        runbook_restore_auth = _text(
            runbook.get(
                "restore_authorization"
            )
        ).upper()

        if runbook_integrity != "OK":
            integration_status = "BLOCKED"
            integration_issue = "DR_RUNBOOK_LOCK_INTEGRITY_FAILED"
        elif runbook_audit != "RECOVERY_AUDIT_CLOSED":
            integration_status = "REVIEW"
            integration_issue = "RECOVERY_AUDIT_NOT_CLOSED"
        elif runbook_restore_auth != "NONE":
            integration_status = "BLOCKED"
            integration_issue = "RUNBOOK_RESTORE_AUTHORIZATION_MUST_REMAIN_NONE"
        else:
            integration_status = "PASS"
            integration_issue = ""
    else:
        runbook_integrity = "NONE"
        runbook_audit = "OPEN"
        runbook_restore_auth = "NONE"

        if _text(
            recovery_release.get(
                "release_gate"
            )
        ).upper() == "PASS":
            integration_status = "REVIEW"
            integration_issue = "CURRENT_DR_RUNBOOK_LOCK_REQUIRED"
        else:
            integration_status = "BLOCKED"
            integration_issue = "RECOVERY_RELEASE_GATE_BLOCKED"

    if _text(
        recovery_release.get(
            "release_gate"
        )
    ).upper() != "PASS":
        integration_status = "BLOCKED"
        integration_issue = "RECOVERY_RELEASE_GATE_BLOCKED"

    return {
        "csv_pass":
            csv_pass,
        "csv_fail":
            csv_fail,
        "csv_files":
            csv_files,
        "readiness":
            readiness,
        "discovery":
            discovery,
        "verification":
            verification,
        "dry_run":
            dry_run,
        "drift":
            drift,
        "rotation":
            rotation,
        "simulation":
            simulation,
        "recovery_release":
            recovery_release,
        "runbook":
            runbook,
        "runbook_integrity":
            runbook_integrity,
        "runbook_audit_closure":
            runbook_audit,
        "recovery_integration_status":
            integration_status,
        "recovery_integration_issue":
            integration_issue,
        "restore_authorization":
            "NONE",
    }


def build_v124_release_readiness(
    *,
    v123_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    recovery_release_gate: str,
    recovery_integration_status: str,
    restore_authorization: str,
    recovery_operating_status: str = "",
) -> dict:
    v123 = _text(
        v123_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    recovery_release = _text(
        recovery_release_gate
    ).upper()
    recovery_integration = _text(
        recovery_integration_status
    ).upper()
    restore_auth = _text(
        restore_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _row(
            "v1.23 Closed-loop Baseline",
            v123
            == "READY_FOR_RELEASE_REVIEW",
            v123
            or "MISSING",
        ),
        _row(
            "System Integration Consistency",
            integration
            == "PASS",
            integration
            or "MISSING",
        ),
        _row(
            "Save Center CSV Health",
            csv_fail
            == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Recovery Technical Release Gate",
            recovery_release
            == "PASS",
            recovery_release
            or "MISSING",
        ),
        _row(
            "Recovery Audit / DR Runbook Closure",
            recovery_integration
            == "PASS",
            recovery_integration
            or "MISSING",
        ),
        _row(
            "Restore Authorization Invariant",
            restore_auth
            == "NONE",
            restore_auth
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ] != "PASS"
    ]

    recovery_operating = _text(
        recovery_operating_status
    ).upper()

    operating_reviews = []

    if (
        recovery_operating
        and recovery_operating
        != "PASS"
    ):
        operating_reviews.append(
            "RECOVERY_OPERATING_REVIEW"
        )

    return {
        "status":
            (
                "READY_FOR_RELEASE_REVIEW"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "blockers":
            blockers,
        "operating_review_count":
            len(
                operating_reviews
            ),
        "operating_reviews":
            operating_reviews,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V124_RELEASE_CHECK_COLS,
            ),
        "restore_authorization":
            "NONE",
    }


def build_v124_integration_crosscheck(
    *,
    integration_consistency: str,
    recovery_release_gate: str,
    recovery_integration_status: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    recovery_release = _text(
        recovery_release_gate
    ).upper()
    recovery_integration = _text(
        recovery_integration_status
    ).upper()

    checks = [
        _row(
            "System Integration Consistency",
            integration
            == "PASS",
            integration
            or "MISSING",
        ),
        _row(
            "Recovery Technical Release Gate",
            recovery_release
            == "PASS",
            recovery_release
            or "MISSING",
        ),
        _row(
            "Recovery Audit / DR Runbook Closure",
            recovery_integration
            == "PASS",
            recovery_integration
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ] != "PASS"
    ]

    return {
        "status":
            (
                "PASS"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V124_RELEASE_CHECK_COLS,
            ),
        "restore_authorization":
            "NONE",
    }


def build_v124_data_crosscheck(
    *,
    csv_fail_count: int,
    recovery_release_gate: str,
    recovery_integration_status: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    recovery_release = _text(
        recovery_release_gate
    ).upper()
    recovery_integration = _text(
        recovery_integration_status
    ).upper()

    checks = [
        _row(
            "Save Center CSV Health",
            csv_fail
            == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Recovery Release Data Gate",
            recovery_release
            == "PASS",
            recovery_release
            or "MISSING",
        ),
        _row(
            "Recovery Audit Closure",
            recovery_integration
            == "PASS",
            recovery_integration
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ] != "PASS"
    ]

    return {
        "status":
            (
                "PASS"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V124_RELEASE_CHECK_COLS,
            ),
        "restore_authorization":
            "NONE",
    }
