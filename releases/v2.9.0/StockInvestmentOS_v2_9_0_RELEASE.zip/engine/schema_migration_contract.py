from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.schema_evolution_guard import (
    schema_baseline_integrity,
    build_schema_snapshot,
)


COMPATIBILITY_MATRIX_COLS = [
    "file",
    "migration_type",
    "schema_status",
    "reader_compatibility",
    "writer_compatibility",
    "contract_status",
    "risk_level",
    "reason",
]


SCHEMA_MIGRATION_PROPOSAL_COLS = [
    "migration_proposal_id",
    "created_at",
    "file",
    "migration_type",
    "schema_status",
    "baseline_schema_hash",
    "current_schema_hash",
    "source_diff_hash",
    "reader_compatibility",
    "writer_compatibility",
    "risk_level",
    "migration_reason",
    "proposed_transform",
    "rollback_plan",
    "proof_plan",
    "source_diff_confirmed",
    "no_auto_apply_confirmed",
    "no_destructive_write_confirmed",
    "human_review_confirmed",
    "proposal_gate",
    "proposal_status",
    "migration_authorization",
    "issues",
    "note",
    "record_hash",
]


SCHEMA_CONTRACT_LOCK_COLS = [
    "schema_contract_id",
    "created_at",
    "contract_version",
    "schema_baseline_id",
    "schema_baseline_record_hash",
    "schema_snapshot_hash",
    "file_count",
    "total_columns",
    "compatibility_status",
    "contract_policy_hash",
    "baseline_integrity_status",
    "baseline_review_confirmed",
    "additive_change_review_confirmed",
    "writer_preservation_confirmed",
    "no_auto_migration_confirmed",
    "human_review_confirmed",
    "contract_gate",
    "contract_status",
    "migration_authorization",
    "issues",
    "note",
    "record_hash",
]


SCHEMA_CONTRACT_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "file",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _compatibility_for_type(
    migration_type: str,
) -> dict:
    mt = _text(
        migration_type
    ).upper()

    mapping = {
        "CURRENT": {
            "reader_compatibility":
                "COMPATIBLE",
            "writer_compatibility":
                "COMPATIBLE",
            "contract_status":
                "PASS",
            "risk_level":
                "LOW",
            "reason":
                "current schema matches locked baseline",
        },
        "FILE_ADDED": {
            "reader_compatibility":
                "REVIEW_NEW_FILE",
            "writer_compatibility":
                "REVIEW_REGISTRATION",
            "contract_status":
                "REVIEW",
            "risk_level":
                "LOW",
            "reason":
                "new file must be explicitly registered in the schema contract",
        },
        "ADDITIVE_COLUMNS": {
            "reader_compatibility":
                "REVIEW_ADDITIVE_COLUMNS",
            "writer_compatibility":
                "REVIEW_COLUMN_PRESERVATION",
            "contract_status":
                "REVIEW",
            "risk_level":
                "MEDIUM",
            "reason":
                "existing readers/writers must not silently drop new columns",
        },
        "COLUMN_ORDER_CHANGED": {
            "reader_compatibility":
                "REVIEW_NAME_BASED_READER",
            "writer_compatibility":
                "REVIEW_COLUMN_ORDER",
            "contract_status":
                "REVIEW",
            "risk_level":
                "MEDIUM",
            "reason":
                "same names but order changed; positional assumptions require review",
        },
        "FILE_MISSING": {
            "reader_compatibility":
                "INCOMPATIBLE",
            "writer_compatibility":
                "INCOMPATIBLE",
            "contract_status":
                "BLOCKED",
            "risk_level":
                "HIGH",
            "reason":
                "required baseline file is missing",
        },
        "MISSING_COLUMNS": {
            "reader_compatibility":
                "INCOMPATIBLE",
            "writer_compatibility":
                "INCOMPATIBLE",
            "contract_status":
                "BLOCKED",
            "risk_level":
                "HIGH",
            "reason":
                "required baseline columns are missing",
        },
        "BREAKING_SCHEMA": {
            "reader_compatibility":
                "INCOMPATIBLE",
            "writer_compatibility":
                "INCOMPATIBLE",
            "contract_status":
                "BLOCKED",
            "risk_level":
                "HIGH",
            "reason":
                "rename/removal/addition combination requires explicit migration",
        },
    }

    return mapping.get(
        mt,
        {
            "reader_compatibility":
                "REVIEW",
            "writer_compatibility":
                "REVIEW",
            "contract_status":
                "REVIEW",
            "risk_level":
                "MEDIUM",
            "reason":
                "unclassified schema change requires human review",
        },
    )


def build_schema_compatibility_matrix(
    comparison: dict | None,
) -> dict:
    result = comparison or {}
    diff = result.get(
        "diff"
    )

    if (
        not isinstance(
            diff,
            pd.DataFrame,
        )
        or diff.empty
    ):
        schema_status = _text(
            result.get(
                "schema_status"
            )
        ).upper()

        return {
            "compatibility_status":
                (
                    "BLOCKED"
                    if schema_status
                    == "BLOCKED"
                    else (
                        "NO_BASELINE"
                        if schema_status
                        == "NO_BASELINE"
                        else "PASS"
                    )
                ),
            "pass_files":
                0,
            "review_files":
                0,
            "blocked_files":
                0,
            "matrix":
                pd.DataFrame(
                    columns=
                    COMPATIBILITY_MATRIX_COLS
                ),
        }

    rows = []

    for _, row in diff.iterrows():
        migration_type = _text(
            row.get(
                "migration_type"
            )
        )
        policy = _compatibility_for_type(
            migration_type
        )

        rows.append(
            {
                "file":
                    _text(
                        row.get(
                            "file"
                        )
                    ),
                "migration_type":
                    migration_type,
                "schema_status":
                    _text(
                        row.get(
                            "status"
                        )
                    ),
                **policy,
            }
        )

    matrix = pd.DataFrame(
        rows,
        columns=
        COMPATIBILITY_MATRIX_COLS,
    )

    blocked_files = int(
        matrix[
            "contract_status"
        ]
        .eq(
            "BLOCKED"
        )
        .sum()
    )
    review_files = int(
        matrix[
            "contract_status"
        ]
        .eq(
            "REVIEW"
        )
        .sum()
    )
    pass_files = int(
        matrix[
            "contract_status"
        ]
        .eq(
            "PASS"
        )
        .sum()
    )

    if blocked_files > 0:
        compatibility_status = "BLOCKED"
    elif review_files > 0:
        compatibility_status = "REVIEW"
    else:
        compatibility_status = "PASS"

    return {
        "compatibility_status":
            compatibility_status,
        "pass_files":
            pass_files,
        "review_files":
            review_files,
        "blocked_files":
            blocked_files,
        "matrix":
            matrix,
    }


def migration_proposal_summary(
    comparison: dict | None,
    compatibility: dict | None,
) -> dict:
    compare = comparison or {}
    compat = compatibility or {}

    changed_files = _int(
        compare.get(
            "changed_files"
        )
    )
    blocking = _int(
        compare.get(
            "blocking_changes"
        )
    )
    review_changes = _int(
        compare.get(
            "review_changes"
        )
    )

    if blocking > 0:
        status = "PROPOSAL_REQUIRED_BLOCKED"
    elif changed_files > 0:
        status = "PROPOSAL_REVIEW"
    else:
        status = "NO_CHANGE"

    return {
        "proposal_status":
            status,
        "changed_files":
            changed_files,
        "blocking_changes":
            blocking,
        "review_changes":
            review_changes,
        "compatibility_status":
            _text(
                compat.get(
                    "compatibility_status"
                )
            ),
        "migration_authorization":
            "NONE",
    }


def _diff_hash(
    diff_row: dict | None,
) -> str:
    row = diff_row or {}
    payload = {
        "file":
            _text(
                row.get(
                    "file"
                )
            ),
        "migration_type":
            _text(
                row.get(
                    "migration_type"
                )
            ),
        "status":
            _text(
                row.get(
                    "status"
                )
            ),
        "baseline_columns":
            _int(
                row.get(
                    "baseline_columns"
                )
            ),
        "current_columns":
            _int(
                row.get(
                    "current_columns"
                )
            ),
        "added_columns":
            _text(
                row.get(
                    "added_columns"
                )
            ),
        "missing_columns":
            _text(
                row.get(
                    "missing_columns"
                )
            ),
    }

    return _hash(
        payload
    )


def validate_schema_migration_proposal(
    diff_row: dict | None,
    compatibility_row: dict | None,
    *,
    migration_reason: str,
    proposed_transform: str,
    rollback_plan: str,
    proof_plan: str,
    source_diff_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_destructive_write_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    diff = diff_row or {}
    compatibility = compatibility_row or {}
    issues = []

    migration_type = _text(
        diff.get(
            "migration_type"
        )
    ).upper()

    if (
        not migration_type
        or migration_type
        == "CURRENT"
    ):
        issues.append(
            "SCHEMA_CHANGE_REQUIRED"
        )

    required_text = [
        (
            migration_reason,
            "MIGRATION_REASON_REQUIRED",
        ),
        (
            proposed_transform,
            "PROPOSED_TRANSFORM_REQUIRED",
        ),
        (
            rollback_plan,
            "ROLLBACK_PLAN_REQUIRED",
        ),
        (
            proof_plan,
            "PROOF_PLAN_REQUIRED",
        ),
    ]

    for value, issue in required_text:
        if not _text(
            value
        ):
            issues.append(
                issue
            )

    confirmations = [
        (
            source_diff_confirmed,
            "SOURCE_DIFF_CONFIRMATION_REQUIRED",
        ),
        (
            no_auto_apply_confirmed,
            "NO_AUTO_APPLY_CONFIRMATION_REQUIRED",
        ),
        (
            no_destructive_write_confirmed,
            "NO_DESTRUCTIVE_WRITE_CONFIRMATION_REQUIRED",
        ),
        (
            human_review_confirmed,
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED",
        ),
    ]

    for passed, issue in confirmations:
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    return {
        "proposal_gate":
            gate,
        "proposal_status":
            (
                "READY_FOR_IMPLEMENTATION_REVIEW"
                if gate == "PASS"
                else "DRAFT"
            ),
        "reader_compatibility":
            _text(
                compatibility.get(
                    "reader_compatibility"
                )
            ),
        "writer_compatibility":
            _text(
                compatibility.get(
                    "writer_compatibility"
                )
            ),
        "risk_level":
            _text(
                compatibility.get(
                    "risk_level"
                )
            ),
        "migration_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _proposal_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "source_diff_confirmed",
        "no_auto_apply_confirmed",
        "no_destructive_write_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in SCHEMA_MIGRATION_PROPOSAL_COLS:
        if col == "record_hash":
            continue

        if col in bool_fields:
            payload[
                col
            ] = bool(
                _bool(
                    row.get(
                        col
                    )
                )
            )
        else:
            payload[
                col
            ] = _text(
                row.get(
                    col
                )
            )

    return payload


def build_schema_migration_proposal_record(
    diff_row: dict,
    compatibility_row: dict,
    validation: dict,
    *,
    baseline_schema_hash: str,
    current_schema_hash: str,
    migration_reason: str,
    proposed_transform: str,
    rollback_plan: str,
    proof_plan: str,
    source_diff_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_destructive_write_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    source_hash = _diff_hash(
        diff_row
    )

    proposal_id = (
        "SMP-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + source_hash[:8]
    )

    row = {
        "migration_proposal_id":
            proposal_id,
        "created_at":
            now,
        "file":
            _text(
                diff_row.get(
                    "file"
                )
            ),
        "migration_type":
            _text(
                diff_row.get(
                    "migration_type"
                )
            ),
        "schema_status":
            _text(
                diff_row.get(
                    "status"
                )
            ),
        "baseline_schema_hash":
            _text(
                baseline_schema_hash
            ),
        "current_schema_hash":
            _text(
                current_schema_hash
            ),
        "source_diff_hash":
            source_hash,
        "reader_compatibility":
            _text(
                validation.get(
                    "reader_compatibility"
                )
            ),
        "writer_compatibility":
            _text(
                validation.get(
                    "writer_compatibility"
                )
            ),
        "risk_level":
            _text(
                validation.get(
                    "risk_level"
                )
            ),
        "migration_reason":
            _text(
                migration_reason
            ),
        "proposed_transform":
            _text(
                proposed_transform
            ),
        "rollback_plan":
            _text(
                rollback_plan
            ),
        "proof_plan":
            _text(
                proof_plan
            ),
        "source_diff_confirmed":
            bool(
                source_diff_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_destructive_write_confirmed":
            bool(
                no_destructive_write_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "proposal_gate":
            _text(
                validation.get(
                    "proposal_gate"
                )
            ),
        "proposal_status":
            _text(
                validation.get(
                    "proposal_status"
                )
            ),
        "migration_authorization":
            "NONE",
        "issues":
            " | ".join(
                validation.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _proposal_payload(
            row
        )
    )

    return row


def schema_migration_proposal_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status":
                "MISSING",
            "calculated_hash":
                "",
        }

    calculated = _hash(
        _proposal_payload(
            record
        )
    )

    return {
        "status":
            (
                "OK"
                if stored
                == calculated
                else "MISMATCH"
            ),
        "calculated_hash":
            calculated,
    }


def compatibility_policy_hash() -> str:
    payload = {
        migration_type:
            _compatibility_for_type(
                migration_type
            )
        for migration_type in [
            "CURRENT",
            "FILE_ADDED",
            "ADDITIVE_COLUMNS",
            "COLUMN_ORDER_CHANGED",
            "FILE_MISSING",
            "MISSING_COLUMNS",
            "BREAKING_SCHEMA",
        ]
    }

    return _hash(
        payload
    )


def latest_schema_contract(
    contracts: pd.DataFrame | None,
) -> dict:
    if (
        contracts is None
        or contracts.empty
    ):
        return {}

    df = contracts.copy()

    if "created_at" in df.columns:
        df[
            "_ts"
        ] = pd.to_datetime(
            df[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        df = df.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        df.iloc[
            0
        ]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def _contract_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "baseline_review_confirmed",
        "additive_change_review_confirmed",
        "writer_preservation_confirmed",
        "no_auto_migration_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in SCHEMA_CONTRACT_LOCK_COLS:
        if col == "record_hash":
            continue

        if col in bool_fields:
            payload[
                col
            ] = bool(
                _bool(
                    row.get(
                        col
                    )
                )
            )
        else:
            payload[
                col
            ] = _text(
                row.get(
                    col
                )
            )

    return payload


def schema_contract_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status":
                "MISSING",
            "calculated_hash":
                "",
        }

    calculated = _hash(
        _contract_payload(
            record
        )
    )

    return {
        "status":
            (
                "OK"
                if stored
                == calculated
                else "MISMATCH"
            ),
        "calculated_hash":
            calculated,
    }


def assess_schema_contract(
    contract: dict | None,
    baseline: dict | None,
    comparison: dict | None,
) -> dict:
    contract_row = contract or {}
    baseline_row = baseline or {}
    compare = comparison or {}

    if not baseline_row:
        return {
            "contract_status":
                "BLOCKED",
            "contract_integrity":
                "NONE",
            "issues":
                [
                    "SCHEMA_BASELINE_REQUIRED"
                ],
        }

    if not contract_row:
        return {
            "contract_status":
                "MISSING",
            "contract_integrity":
                "NONE",
            "issues":
                [
                    "SCHEMA_CONTRACT_LOCK_REQUIRED"
                ],
        }

    integrity = schema_contract_integrity(
        contract_row
    )[
        "status"
    ]

    if integrity != "OK":
        return {
            "contract_status":
                "INTEGRITY_REVIEW",
            "contract_integrity":
                integrity,
            "issues":
                [
                    "SCHEMA_CONTRACT_HASH_INTEGRITY_FAILED"
                ],
        }

    baseline_integrity = schema_baseline_integrity(
        baseline_row
    )[
        "status"
    ]

    if baseline_integrity != "OK":
        return {
            "contract_status":
                "INTEGRITY_REVIEW",
            "contract_integrity":
                integrity,
            "issues":
                [
                    "SCHEMA_BASELINE_HASH_INTEGRITY_FAILED"
                ],
        }

    if (
        _text(
            contract_row.get(
                "schema_snapshot_hash"
            )
        )
        != _text(
            baseline_row.get(
                "schema_snapshot_hash"
            )
        )
    ):
        return {
            "contract_status":
                "DRIFTED",
            "contract_integrity":
                integrity,
            "issues":
                [
                    "CONTRACT_BASELINE_VERSION_DRIFT"
                ],
        }

    schema_status = _text(
        compare.get(
            "schema_status"
        )
    ).upper()

    if schema_status == "CURRENT":
        return {
            "contract_status":
                "CURRENT",
            "contract_integrity":
                integrity,
            "issues":
                [],
        }

    if schema_status == "BLOCKED":
        return {
            "contract_status":
                "BLOCKED",
            "contract_integrity":
                integrity,
            "issues":
                [
                    "BLOCKING_SCHEMA_DRIFT"
                ],
        }

    return {
        "contract_status":
            "DRIFTED",
        "contract_integrity":
            integrity,
        "issues":
            [
                "SCHEMA_CHANGE_REVIEW_REQUIRED"
            ],
    }


def validate_schema_contract_lock(
    baseline: dict | None,
    comparison: dict | None,
    compatibility: dict | None,
    existing_contract: dict | None,
    *,
    baseline_review_confirmed: bool,
    additive_change_review_confirmed: bool,
    writer_preservation_confirmed: bool,
    no_auto_migration_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    baseline_row = baseline or {}
    compare = comparison or {}
    compat = compatibility or {}
    existing = existing_contract or {}
    issues = []

    if not baseline_row:
        issues.append(
            "SCHEMA_BASELINE_REQUIRED"
        )
    elif schema_baseline_integrity(
        baseline_row
    )[
        "status"
    ] != "OK":
        issues.append(
            "SCHEMA_BASELINE_INTEGRITY_OK_REQUIRED"
        )

    if _text(
        compare.get(
            "schema_status"
        )
    ).upper() != "CURRENT":
        issues.append(
            "CURRENT_SCHEMA_REQUIRED_FOR_CONTRACT_LOCK"
        )

    if _text(
        compat.get(
            "compatibility_status"
        )
    ).upper() != "PASS":
        issues.append(
            "COMPATIBILITY_MATRIX_PASS_REQUIRED"
        )

    if existing:
        assessment = assess_schema_contract(
            existing,
            baseline_row,
            compare,
        )

        if assessment[
            "contract_status"
        ] == "CURRENT":
            issues.append(
                "CURRENT_CONTRACT_ALREADY_LOCKED"
            )

    confirmations = [
        (
            baseline_review_confirmed,
            "BASELINE_REVIEW_CONFIRMATION_REQUIRED",
        ),
        (
            additive_change_review_confirmed,
            "ADDITIVE_CHANGE_REVIEW_CONFIRMATION_REQUIRED",
        ),
        (
            writer_preservation_confirmed,
            "WRITER_PRESERVATION_CONFIRMATION_REQUIRED",
        ),
        (
            no_auto_migration_confirmed,
            "NO_AUTO_MIGRATION_CONFIRMATION_REQUIRED",
        ),
        (
            human_review_confirmed,
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED",
        ),
    ]

    for passed, issue in confirmations:
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    blocking = [
        issue
        for issue in issues
        if issue
        != "CURRENT_CONTRACT_ALREADY_LOCKED"
    ]

    if (
        existing
        and "CURRENT_CONTRACT_ALREADY_LOCKED"
        in issues
        and not blocking
    ):
        gate = "REVIEW"
        status = "ALREADY_LOCKED"
    elif not issues:
        gate = "PASS"
        status = "READER_WRITER_CONTRACT_LOCKED"
    else:
        gate = "REVIEW"
        status = "DRAFT"

    return {
        "contract_gate":
            gate,
        "contract_status":
            status,
        "migration_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def build_schema_contract_lock_record(
    scan: pd.DataFrame,
    baseline: dict,
    compatibility: dict,
    validation: dict,
    *,
    baseline_review_confirmed: bool,
    additive_change_review_confirmed: bool,
    writer_preservation_confirmed: bool,
    no_auto_migration_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    snapshot = build_schema_snapshot(
        scan
    )

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    contract_id = (
        "SCL-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot[
            "snapshot_hash"
        ][
            :8
        ]
    )

    row = {
        "schema_contract_id":
            contract_id,
        "created_at":
            now,
        "contract_version":
            "SCHEMA-CONTRACT-v1",
        "schema_baseline_id":
            _text(
                baseline.get(
                    "schema_baseline_id"
                )
            ),
        "schema_baseline_record_hash":
            _text(
                baseline.get(
                    "record_hash"
                )
            ),
        "schema_snapshot_hash":
            snapshot[
                "snapshot_hash"
            ],
        "file_count":
            _int(
                baseline.get(
                    "file_count"
                )
            ),
        "total_columns":
            _int(
                baseline.get(
                    "total_columns"
                )
            ),
        "compatibility_status":
            _text(
                compatibility.get(
                    "compatibility_status"
                )
            ),
        "contract_policy_hash":
            compatibility_policy_hash(),
        "baseline_integrity_status":
            schema_baseline_integrity(
                baseline
            )[
                "status"
            ],
        "baseline_review_confirmed":
            bool(
                baseline_review_confirmed
            ),
        "additive_change_review_confirmed":
            bool(
                additive_change_review_confirmed
            ),
        "writer_preservation_confirmed":
            bool(
                writer_preservation_confirmed
            ),
        "no_auto_migration_confirmed":
            bool(
                no_auto_migration_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "contract_gate":
            _text(
                validation.get(
                    "contract_gate"
                )
            ),
        "contract_status":
            _text(
                validation.get(
                    "contract_status"
                )
            ),
        "migration_authorization":
            "NONE",
        "issues":
            " | ".join(
                validation.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _contract_payload(
            row
        )
    )

    return row


def build_schema_contract_queue(
    comparison: dict | None,
    compatibility: dict | None,
    baseline: dict | None,
    contract: dict | None,
) -> pd.DataFrame:
    compare = comparison or {}
    compat = compatibility or {}
    baseline_row = baseline or {}
    contract_row = contract or {}
    rows = []

    schema_status = _text(
        compare.get(
            "schema_status"
        )
    ).upper()

    if schema_status == "BLOCKED":
        rows.append(
            {
                "priority":
                    "SC0",
                "status":
                    "BLOCKED",
                "issue":
                    "BLOCKING_SCHEMA_DRIFT",
                "file":
                    "",
                "next_action":
                    "Breaking/missing schema를 먼저 복구하거나 명시적 Migration Proposal로 검토",
                "go_to":
                    "Save Center",
            }
        )

    if baseline_row:
        if schema_baseline_integrity(
            baseline_row
        )[
            "status"
        ] != "OK":
            rows.append(
                {
                    "priority":
                        "SC0",
                    "status":
                        "BLOCKED",
                    "issue":
                        "SCHEMA_BASELINE_INTEGRITY_FAILED",
                    "file":
                        "",
                    "next_action":
                        "Schema Baseline Lock immutable hash 확인",
                    "go_to":
                        "Save Center",
                }
            )
    else:
        rows.append(
            {
                "priority":
                    "SC0",
                "status":
                    "BLOCKED",
                "issue":
                    "SCHEMA_BASELINE_REQUIRED",
                "file":
                    "",
                "next_action":
                    "Save Center 1I에서 Schema Baseline Lock을 먼저 생성",
                "go_to":
                    "Save Center",
            }
        )

    assessment = assess_schema_contract(
        contract_row,
        baseline_row,
        compare,
    )

    if assessment[
        "contract_status"
    ] == "MISSING":
        rows.append(
            {
                "priority":
                    "SC1",
                "status":
                    "REVIEW",
                "issue":
                    "READER_WRITER_CONTRACT_LOCK_REQUIRED",
                "file":
                    "",
                "next_action":
                    "현재 Baseline/Compatibility를 확인하고 Reader-Writer Contract를 Human Review",
                "go_to":
                    "Save Center",
            }
        )
    elif assessment[
        "contract_status"
    ] in {
        "INTEGRITY_REVIEW",
        "BLOCKED",
    }:
        rows.append(
            {
                "priority":
                    "SC0",
                "status":
                    "BLOCKED",
                "issue":
                    (
                        assessment[
                            "issues"
                        ][
                            0
                        ]
                        if assessment[
                            "issues"
                        ]
                        else "SCHEMA_CONTRACT_INTEGRITY_REVIEW"
                    ),
                "file":
                    "",
                "next_action":
                    "Schema Contract / Baseline / Current Schema 무결성 확인",
                "go_to":
                    "Save Center",
            }
        )
    elif assessment[
        "contract_status"
    ] == "DRIFTED":
        rows.append(
            {
                "priority":
                    "SC3",
                "status":
                    "REVIEW",
                "issue":
                    (
                        assessment[
                            "issues"
                        ][
                            0
                        ]
                        if assessment[
                            "issues"
                        ]
                        else "SCHEMA_CONTRACT_DRIFTED"
                    ),
                "file":
                    "",
                "next_action":
                    "Schema 변화에 대한 Migration Proposal/새 Baseline/Contract Review",
                "go_to":
                    "Save Center",
            }
        )

    matrix = compat.get(
        "matrix"
    )

    if (
        isinstance(
            matrix,
            pd.DataFrame,
        )
        and not matrix.empty
    ):
        changed = matrix.loc[
            matrix[
                "migration_type"
            ]
            .ne(
                "CURRENT"
            )
        ]

        for _, row in changed.iterrows():
            blocked = _text(
                row.get(
                    "contract_status"
                )
            ).upper() == "BLOCKED"

            rows.append(
                {
                    "priority":
                        (
                            "SC0"
                            if blocked
                            else "SC2"
                        ),
                    "status":
                        (
                            "BLOCKED"
                            if blocked
                            else "REVIEW"
                        ),
                    "issue":
                        _text(
                            row.get(
                                "migration_type"
                            )
                        ),
                    "file":
                        _text(
                            row.get(
                                "file"
                            )
                        ),
                    "next_action":
                        (
                            "명시적 Migration Proposal과 복구/변환 계획 필요"
                            if blocked
                            else "Compatibility Matrix 확인 후 Migration Proposal 또는 Baseline Refresh 검토"
                        ),
                    "go_to":
                        "Save Center",
                }
            )

    if not rows:
        return pd.DataFrame(
            columns=
            SCHEMA_CONTRACT_QUEUE_COLS
        )

    order = {
        "SC0": 0,
        "SC1": 1,
        "SC2": 2,
        "SC3": 3,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "file",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            SCHEMA_CONTRACT_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )
