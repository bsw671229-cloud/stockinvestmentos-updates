from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    flow_projection_snapshot_integrity,
)


FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS = [
    "review_snapshot_id",
    "created_at",
    "review_state",
    "source_projection_snapshot_id",
    "source_projection_hash",
    "source_projection_created_at",
    "source_projection_integrity",
    "source_projection_state",
    "scenario_count",
    "source_lineage_confirmed",
    "scenario_semantics_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "projection_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PROJECTION_REVIEW_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = _text(value).upper()
    return text in {"TRUE", "1", "YES", "Y", "T"}


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _normalize_projection_history(
    snapshots: pd.DataFrame | None,
) -> pd.DataFrame:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()
    for col in FLOW_PROJECTION_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return df

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    return (
        df.loc[df["_ts"].notna()]
        .sort_values("_ts")
        .reset_index(drop=True)
    )


def _latest_ready_projection(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = _normalize_projection_history(snapshots)
    if df.empty:
        return {}

    ready = df.loc[
        df["projection_state"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("READY_FOR_REVIEW")
    ].copy()

    if ready.empty:
        return {}

    row = ready.iloc[-1].drop(labels=["_ts"]).to_dict()
    return row


def _review_payload(row: dict) -> dict:
    return {
        "review_state": _text(row.get("review_state")),
        "source_projection_snapshot_id": _text(
            row.get("source_projection_snapshot_id")
        ),
        "source_projection_hash": _text(
            row.get("source_projection_hash")
        ),
        "source_projection_created_at": _text(
            row.get("source_projection_created_at")
        ),
        "source_projection_integrity": _text(
            row.get("source_projection_integrity")
        ),
        "source_projection_state": _text(
            row.get("source_projection_state")
        ),
        "scenario_count": _int(row.get("scenario_count")),
        "source_lineage_confirmed": bool(
            _bool(row.get("source_lineage_confirmed"))
        ),
        "scenario_semantics_confirmed": bool(
            _bool(row.get("scenario_semantics_confirmed"))
        ),
        "no_auto_capacity_confirmed": bool(
            _bool(row.get("no_auto_capacity_confirmed"))
        ),
        "no_execution_authorization_confirmed": bool(
            _bool(row.get("no_execution_authorization_confirmed"))
        ),
        "human_review_confirmed": bool(
            _bool(row.get("human_review_confirmed"))
        ),
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def build_flow_projection_review_lock(
    source_projection: dict,
    *,
    source_lineage_confirmed: bool,
    scenario_semantics_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    source = dict(source_projection or {})
    if not source:
        raise ValueError(
            "Projection Review Lock에는 READY_FOR_REVIEW Projection Snapshot이 필요합니다."
        )

    integrity = flow_projection_snapshot_integrity(source)
    if _text(integrity.get("status")).upper() != "OK":
        raise ValueError(
            "Projection Review Lock source Snapshot integrity가 OK가 아닙니다."
        )

    if _text(source.get("projection_state")).upper() != "READY_FOR_REVIEW":
        raise ValueError(
            "Projection Review Lock source는 READY_FOR_REVIEW 상태여야 합니다."
        )

    confirmations = [
        bool(source_lineage_confirmed),
        bool(scenario_semantics_confirmed),
        bool(no_auto_capacity_confirmed),
        bool(no_execution_authorization_confirmed),
        bool(human_review_confirmed),
    ]
    if not all(confirmations):
        raise ValueError(
            "Projection Review Lock 저장 전에 모든 Human Review 확인이 필요합니다."
        )

    now = _text(created_at) or datetime.now().astimezone().isoformat()

    base = {
        "review_state": "PROJECTION_REVIEW_LOCKED",
        "source_projection_snapshot_id": _text(
            source.get("projection_snapshot_id")
        ),
        "source_projection_hash": _text(
            source.get("snapshot_hash")
        ),
        "source_projection_created_at": _text(
            source.get("created_at")
        ),
        "source_projection_integrity": "OK",
        "source_projection_state": "READY_FOR_REVIEW",
        "scenario_count": 3,
        "source_lineage_confirmed": True,
        "scenario_semantics_confirmed": True,
        "no_auto_capacity_confirmed": True,
        "no_execution_authorization_confirmed": True,
        "human_review_confirmed": True,
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }
    snapshot_hash = _hash(_review_payload(base))

    return {
        "review_snapshot_id": (
            "OPR-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_projection_review_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = row.to_dict() if isinstance(row, pd.Series) else dict(row)
    stored = _text(item.get("snapshot_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_review_payload(item))
    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def latest_flow_projection_review_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()

    if df.empty:
        return {}

    for col in FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[df["_ts"].notna()].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def build_flow_projection_review_context(
    projection_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
) -> dict:
    source = _latest_ready_projection(projection_snapshots)

    if not source:
        return {
            "review_state": "PROJECTION_REVIEW_SOURCE_REQUIRED",
            "source_projection_snapshot_id": "",
            "source_projection_hash": "",
            "source_projection_created_at": "",
            "source_projection_integrity": "NONE",
            "latest_review_snapshot_id": "",
            "latest_review_integrity": "NONE",
            "source_current": False,
            "review_locked": False,
            "reviewed_projection_source": {},
            "projection_authorization": "NONE",
            "capacity_authorization": "NONE",
            "execution_authorization": "NONE",
        }

    source_integrity = _text(
        flow_projection_snapshot_integrity(source).get("status")
    ).upper()

    if source_integrity != "OK":
        return {
            "review_state": "PROJECTION_REVIEW_SOURCE_INTEGRITY_REVIEW",
            "source_projection_snapshot_id": _text(
                source.get("projection_snapshot_id")
            ),
            "source_projection_hash": _text(source.get("snapshot_hash")),
            "source_projection_created_at": _text(source.get("created_at")),
            "source_projection_integrity": source_integrity or "MISMATCH",
            "latest_review_snapshot_id": "",
            "latest_review_integrity": "NONE",
            "source_current": False,
            "review_locked": False,
            "reviewed_projection_source": {},
            "projection_authorization": "NONE",
            "capacity_authorization": "NONE",
            "execution_authorization": "NONE",
        }

    latest_review = latest_flow_projection_review_snapshot(
        review_snapshots
    )
    if not latest_review:
        return {
            "review_state": "PROJECTION_REVIEW_REQUIRED",
            "source_projection_snapshot_id": _text(
                source.get("projection_snapshot_id")
            ),
            "source_projection_hash": _text(source.get("snapshot_hash")),
            "source_projection_created_at": _text(source.get("created_at")),
            "source_projection_integrity": "OK",
            "latest_review_snapshot_id": "",
            "latest_review_integrity": "NONE",
            "source_current": True,
            "review_locked": False,
            "reviewed_projection_source": {},
            "projection_authorization": "NONE",
            "capacity_authorization": "NONE",
            "execution_authorization": "NONE",
        }

    review_integrity = _text(
        flow_projection_review_snapshot_integrity(
            latest_review
        ).get("status")
    ).upper()

    if review_integrity != "OK":
        state = "PROJECTION_REVIEW_AUDIT_INTEGRITY_REVIEW"
        locked = False
    elif (
        _text(latest_review.get("source_projection_snapshot_id"))
        != _text(source.get("projection_snapshot_id"))
        or _text(latest_review.get("source_projection_hash"))
        != _text(source.get("snapshot_hash"))
    ):
        state = "PROJECTION_REVIEW_SOURCE_SUPERSEDED"
        locked = False
    elif _text(latest_review.get("review_state")).upper() != "PROJECTION_REVIEW_LOCKED":
        state = "PROJECTION_REVIEW_AUDIT_STATE_REVIEW"
        locked = False
    elif not all(
        [
            _bool(latest_review.get("source_lineage_confirmed")),
            _bool(latest_review.get("scenario_semantics_confirmed")),
            _bool(latest_review.get("no_auto_capacity_confirmed")),
            _bool(latest_review.get("no_execution_authorization_confirmed")),
            _bool(latest_review.get("human_review_confirmed")),
        ]
    ):
        state = "PROJECTION_REVIEW_CONTRACT_INCOMPLETE"
        locked = False
    else:
        state = "PROJECTION_REVIEW_LOCKED"
        locked = True

    return {
        "review_state": state,
        "source_projection_snapshot_id": _text(
            source.get("projection_snapshot_id")
        ),
        "source_projection_hash": _text(source.get("snapshot_hash")),
        "source_projection_created_at": _text(source.get("created_at")),
        "source_projection_integrity": "OK",
        "latest_review_snapshot_id": _text(
            latest_review.get("review_snapshot_id")
        ),
        "latest_review_integrity": review_integrity or "MISSING",
        "source_current": (
            _text(latest_review.get("source_projection_snapshot_id"))
            == _text(source.get("projection_snapshot_id"))
            and _text(latest_review.get("source_projection_hash"))
            == _text(source.get("snapshot_hash"))
        ),
        "review_locked": locked,
        "reviewed_projection_source": source if locked else {},
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def latest_reviewed_projection_source(
    projection_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
) -> dict:
    context = build_flow_projection_review_context(
        projection_snapshots,
        review_snapshots,
    )
    return dict(
        context.get("reviewed_projection_source") or {}
    )


def build_flow_projection_review_queue(
    review_context: dict | None,
) -> pd.DataFrame:
    ctx = review_context or {}
    state = _text(ctx.get("review_state")).upper()

    mapping = {
        "PROJECTION_REVIEW_SOURCE_REQUIRED": (
            "PR2",
            "WAIT",
            "PROJECTION_REVIEW_SOURCE_REQUIRED",
            "READY_FOR_REVIEW Projection Snapshot 없음",
            "Upstream Evidence/Promotion/Admission이 READY가 될 때까지 기다림",
        ),
        "PROJECTION_REVIEW_SOURCE_INTEGRITY_REVIEW": (
            "PR0",
            "BLOCKED",
            "PROJECTION_REVIEW_SOURCE_INTEGRITY",
            "latest READY Projection Snapshot integrity mismatch",
            "Projection Snapshot integrity를 먼저 복구",
        ),
        "PROJECTION_REVIEW_REQUIRED": (
            "PR1",
            "REVIEW",
            "PROJECTION_REVIEW_REQUIRED",
            "READY Projection source가 있으나 Human Review Lock 없음",
            "Scenario semantics/lineage/no-auto-action 확인 후 Review Lock 저장",
        ),
        "PROJECTION_REVIEW_AUDIT_INTEGRITY_REVIEW": (
            "PR0",
            "BLOCKED",
            "PROJECTION_REVIEW_AUDIT_INTEGRITY",
            "Projection Review audit hash mismatch",
            "Review audit integrity를 먼저 복구",
        ),
        "PROJECTION_REVIEW_SOURCE_SUPERSEDED": (
            "PR1",
            "REVIEW",
            "PROJECTION_REVIEW_SOURCE_SUPERSEDED",
            "새로운 READY Projection이 기존 Review Lock을 대체함",
            "새 Projection source를 다시 Human Review하고 Review Lock 저장",
        ),
        "PROJECTION_REVIEW_AUDIT_STATE_REVIEW": (
            "PR0",
            "BLOCKED",
            "PROJECTION_REVIEW_AUDIT_STATE",
            "Review audit state vocabulary mismatch",
            "Review audit state 확인",
        ),
        "PROJECTION_REVIEW_CONTRACT_INCOMPLETE": (
            "PR0",
            "BLOCKED",
            "PROJECTION_REVIEW_CONTRACT_INCOMPLETE",
            "Human Review confirmation contract incomplete",
            "Review Lock contract fields 확인",
        ),
        "PROJECTION_REVIEW_LOCKED": (
            "PR3",
            "MONITOR",
            "PROJECTION_REVIEW_LOCKED",
            "latest READY Projection이 Human Review Lock과 일치",
            "Outcome evidence를 관측하되 자동 Capacity/투자 실행은 금지",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "PR0",
            "BLOCKED",
            "PROJECTION_REVIEW_UNKNOWN_STATE",
            state or "MISSING",
            "Review state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority": priority,
                "status": status,
                "issue": issue,
                "detail": detail,
                "next_action": next_action,
                "go_to": "Operations Control Tower",
            }
        ],
        columns=PROJECTION_REVIEW_QUEUE_COLS,
    )
