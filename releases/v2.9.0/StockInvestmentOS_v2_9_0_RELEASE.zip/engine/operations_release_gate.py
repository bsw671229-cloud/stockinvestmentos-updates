from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_session import (
    OPERATIONS_SESSION_COLS,
    operations_session_integrity,
    current_open_session,
    latest_closed_session,
)


OPERATIONS_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


V126_RELEASE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


VALID_CLOSE_STATUSES = {
    "CLOSED_CLEAR",
    "CLOSED_WITH_CARRY_FORWARD",
    "CLOSED_WITH_BLOCKERS",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check":
            check,
        "status":
            "PASS"
            if passed
            else "BLOCKED",
        "detail":
            detail,
        "blocking":
            "NO"
            if passed
            else "YES",
    }


def _normalize_sessions(
    sessions: pd.DataFrame | None,
) -> pd.DataFrame:
    df = (
        pd.DataFrame()
        if sessions is None
        else sessions.copy()
    )

    for col in OPERATIONS_SESSION_COLS:
        if col not in df.columns:
            df[col] = ""

    return df[
        OPERATIONS_SESSION_COLS
    ].copy()


def _session_maps(
    df: pd.DataFrame,
) -> tuple[dict[str, dict], dict[str, list[dict]]]:
    opens = {}
    closes = {}

    for _, row in df.iterrows():
        record = row.to_dict()
        event_type = _text(
            record.get(
                "event_type"
            )
        ).upper()
        session_id = _text(
            record.get(
                "session_id"
            )
        )

        if not session_id:
            continue

        if event_type == "OPEN":
            # Duplicate open is handled elsewhere; retain first for parent lookup.
            opens.setdefault(
                session_id,
                record,
            )
        elif event_type == "CLOSE":
            closes.setdefault(
                session_id,
                [],
            ).append(
                record
            )

    return opens, closes


def build_operations_session_release_gate(
    sessions: pd.DataFrame | None,
) -> dict:
    df = _normalize_sessions(
        sessions
    )

    checks = []

    def technical(
        check: str,
        passed: bool,
        detail: str,
        action: str,
    ):
        checks.append(
            {
                "layer":
                    "TECHNICAL",
                "check":
                    check,
                "status":
                    "PASS"
                    if passed
                    else "FAIL",
                "detail":
                    detail,
                "action":
                    ""
                    if passed
                    else action,
            }
        )

    # --------------------------------------------------------
    # 1) Immutable record integrity
    # --------------------------------------------------------
    record_total = int(
        len(
            df
        )
    )
    integrity_ok = 0
    integrity_missing = 0
    integrity_mismatch = 0

    for _, row in df.iterrows():
        status = operations_session_integrity(
            row.to_dict()
        )[
            "status"
        ]

        if status == "OK":
            integrity_ok += 1
        elif status == "MISSING":
            integrity_missing += 1
        else:
            integrity_mismatch += 1

    technical(
        "Operations Session Immutable Record Integrity",
        (
            integrity_missing == 0
            and integrity_mismatch == 0
        ),
        (
            f"records {record_total} · "
            f"OK {integrity_ok} · "
            f"MISSING {integrity_missing} · "
            f"MISMATCH {integrity_mismatch}"
        ),
        "operations_sessions.csv record hash 무결성 확인",
    )

    # --------------------------------------------------------
    # 2) Event / status contract
    # --------------------------------------------------------
    event_contract_issues = 0

    for _, row in df.iterrows():
        event_type = _text(
            row.get(
                "event_type"
            )
        ).upper()
        event_status = _text(
            row.get(
                "event_status"
            )
        ).upper()

        if event_type == "OPEN":
            if event_status != "OPENED":
                event_contract_issues += 1
        elif event_type == "CLOSE":
            if event_status not in VALID_CLOSE_STATUSES:
                event_contract_issues += 1
        else:
            event_contract_issues += 1

    technical(
        "Operations Session Event / Status Contract",
        event_contract_issues == 0,
        f"invalid event/status records {event_contract_issues}",
        "OPEN/CLOSE event type과 event_status contract를 확인",
    )

    # --------------------------------------------------------
    # 3) Parent / session lineage
    # --------------------------------------------------------
    opens, closes = _session_maps(
        df
    )

    lineage_issues = 0
    orphan_closes = 0
    parent_hash_mismatch = 0
    close_before_open = 0

    for session_id, close_rows in closes.items():
        open_row = opens.get(
            session_id
        )

        if not open_row:
            orphan_closes += len(
                close_rows
            )
            lineage_issues += len(
                close_rows
            )
            continue

        open_hash = _text(
            open_row.get(
                "record_hash"
            )
        )
        open_ts = pd.to_datetime(
            open_row.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )

        for close_row in close_rows:
            parent_hash = _text(
                close_row.get(
                    "parent_open_record_hash"
                )
            )

            if (
                not parent_hash
                or parent_hash != open_hash
            ):
                parent_hash_mismatch += 1
                lineage_issues += 1

            close_ts = pd.to_datetime(
                close_row.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )

            if (
                pd.notna(
                    open_ts
                )
                and pd.notna(
                    close_ts
                )
                and close_ts < open_ts
            ):
                close_before_open += 1
                lineage_issues += 1

    technical(
        "Operations Session Parent / Close Lineage",
        lineage_issues == 0,
        (
            f"orphan close {orphan_closes} · "
            f"parent hash mismatch {parent_hash_mismatch} · "
            f"close-before-open {close_before_open}"
        ),
        "CLOSE → OPEN parent record hash / timestamp 연결 확인",
    )

    # --------------------------------------------------------
    # 4) Duplicate / concurrent session integrity
    # --------------------------------------------------------
    duplicate_event_ids = 0
    duplicate_open_sessions = 0
    duplicate_close_sessions = 0

    if not df.empty:
        event_ids = (
            df[
                "event_id"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
        )
        nonempty_event_ids = event_ids.loc[
            event_ids.ne("")
        ]
        duplicate_event_ids = int(
            nonempty_event_ids.duplicated(
                keep=False
            ).sum()
        )

        open_df = df.loc[
            df[
                "event_type"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq(
                "OPEN"
            )
        ]

        if not open_df.empty:
            open_counts = (
                open_df[
                    "session_id"
                ]
                .fillna("")
                .astype(str)
                .value_counts()
            )
            duplicate_open_sessions = int(
                (
                    open_counts > 1
                ).sum()
            )

        close_df = df.loc[
            df[
                "event_type"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq(
                "CLOSE"
            )
        ]

        if not close_df.empty:
            close_counts = (
                close_df[
                    "session_id"
                ]
                .fillna("")
                .astype(str)
                .value_counts()
            )
            duplicate_close_sessions = int(
                (
                    close_counts > 1
                ).sum()
            )

    open_session = current_open_session(
        df
    )
    active_open_count = (
        1
        if open_session
        else 0
    )

    duplicate_ok = (
        duplicate_event_ids == 0
        and duplicate_open_sessions == 0
        and duplicate_close_sessions == 0
        and active_open_count <= 1
    )

    technical(
        "Operations Session Duplicate / Concurrent Integrity",
        duplicate_ok,
        (
            f"duplicate event IDs {duplicate_event_ids} · "
            f"duplicate OPEN sessions {duplicate_open_sessions} · "
            f"duplicate CLOSE sessions {duplicate_close_sessions} · "
            f"active OPEN {active_open_count}"
        ),
        "중복 event/session 또는 다중 Open Session 여부 확인",
    )

    # --------------------------------------------------------
    # 5) Snapshot completeness
    # --------------------------------------------------------
    snapshot_missing = 0

    for _, row in df.iterrows():
        required = [
            "worklist_snapshot_hash",
            "core_gate_hash",
        ]

        if any(
            not _text(
                row.get(
                    col
                )
            )
            for col in required
        ):
            snapshot_missing += 1

    technical(
        "Operations Session Snapshot Completeness",
        snapshot_missing == 0,
        f"records missing worklist/core snapshot hash {snapshot_missing}",
        "Session Open/Close snapshot hash 존재 여부 확인",
    )

    # --------------------------------------------------------
    # 6) Execution authorization invariant
    # --------------------------------------------------------
    auth_violations = 0

    if not df.empty:
        auth = (
            df[
                "execution_authorization"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
        )

        auth_violations = int(
            auth.ne(
                "NONE"
            ).sum()
        )

    technical(
        "Operations Execution Authorization Invariant",
        auth_violations == 0,
        (
            "NONE"
            if auth_violations == 0
            else f"non-NONE records {auth_violations}"
        ),
        "Operations Session record의 Execution Authorization을 NONE으로 유지",
    )

    technical_fail = sum(
        1
        for row in checks
        if (
            row[
                "layer"
            ]
            == "TECHNICAL"
            and row[
                "status"
            ]
            == "FAIL"
        )
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    latest_close = latest_closed_session(
        df
    )

    if open_session:
        operating_status = "REVIEW"
        session_state = "OPEN"
    else:
        operating_status = "PASS"
        session_state = "CLOSED"

    checks.append(
        {
            "layer":
                "OPERATING",
            "check":
                "Daily Operations Session State",
            "status":
                operating_status,
            "detail":
                (
                    f"session {session_state} · "
                    f"latest close "
                    f"{_text(latest_close.get('event_status')) or 'NONE'}"
                ),
            "action":
                (
                    ""
                    if operating_status == "PASS"
                    else "현재 Open Session을 정상 운영 후 Close/Handoff"
                ),
        }
    )

    return {
        "release_gate":
            release_gate,
        "technical_pass":
            sum(
                1
                for row in checks
                if (
                    row[
                        "layer"
                    ]
                    == "TECHNICAL"
                    and row[
                        "status"
                    ]
                    == "PASS"
                )
            ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "session_state":
            session_state,
        "record_count":
            record_total,
        "latest_close_status":
            _text(
                latest_close.get(
                    "event_status"
                )
            ),
        "latest_close_integrity":
            (
                operations_session_integrity(
                    latest_close
                )[
                    "status"
                ]
                if latest_close
                else "NONE"
            ),
        "auth_violations":
            auth_violations,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                OPERATIONS_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v126_release_readiness(
    *,
    v125_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    operations_release_gate: str,
    operations_operating_status: str,
    execution_authorization: str,
) -> dict:
    v125 = _text(
        v125_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    operations_gate = _text(
        operations_release_gate
    ).upper()
    operations_operating = _text(
        operations_operating_status
    ).upper()
    execution_auth = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _row(
            "v1.25 Operations Hardening Baseline",
            v125 == "READY_FOR_RELEASE_REVIEW",
            v125 or "MISSING",
        ),
        _row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Operations Session Technical Release Gate",
            operations_gate == "PASS",
            operations_gate or "MISSING",
        ),
        _row(
            "Execution Authorization Invariant",
            execution_auth == "NONE",
            execution_auth or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ] != "PASS"
    ]

    operating_reviews = []

    if (
        operations_operating
        and operations_operating
        != "PASS"
    ):
        operating_reviews.append(
            "OPERATIONS_SESSION_OPEN"
        )

    return {
        "status":
            (
                "READY_FOR_RELEASE_REVIEW"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "blockers":
            blockers,
        "operating_review_count":
            len(
                operating_reviews
            ),
        "operating_reviews":
            operating_reviews,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V126_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v126_integration_crosscheck(
    *,
    integration_consistency: str,
    operations_release_gate: str,
    latest_close_integrity: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    operations_gate = _text(
        operations_release_gate
    ).upper()
    close_integrity = _text(
        latest_close_integrity
    ).upper()

    # No close is allowed only before the feature has ever been used.
    close_ok = close_integrity in {
        "OK",
        "NONE",
    }

    checks = [
        _row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _row(
            "Operations Session Technical Release Gate",
            operations_gate == "PASS",
            operations_gate or "MISSING",
        ),
        _row(
            "Latest Operations Close Integrity",
            close_ok,
            close_integrity or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ] != "PASS"
    ]

    return {
        "status":
            "PASS"
            if not blockers
            else "BLOCKED",
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V126_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v126_data_crosscheck(
    *,
    csv_fail_count: int,
    operations_release_gate: str,
    latest_close_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    operations_gate = _text(
        operations_release_gate
    ).upper()
    close_integrity = _text(
        latest_close_integrity
    ).upper()

    checks = [
        _row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Operations Session Release Data Gate",
            operations_gate == "PASS",
            operations_gate or "MISSING",
        ),
        _row(
            "Latest Operations Close Record Integrity",
            close_integrity in {
                "OK",
                "NONE",
            },
            close_integrity or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ] != "PASS"
    ]

    return {
        "status":
            "PASS"
            if not blockers
            else "BLOCKED",
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V126_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }
