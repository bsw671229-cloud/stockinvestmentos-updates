from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_shadow_adoption_review import (
    shadow_adoption_review_snapshot_integrity,
)


FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS = [
    "controlled_trial_design_id",
    "created_at",
    "design_state",
    "design_guard",
    "source_adoption_review_id",
    "source_adoption_review_hash",
    "source_adoption_review_created_at",
    "source_adoption_review_integrity",
    "source_validation_outcome_id",
    "source_validation_outcome_hash",
    "source_plan_id",
    "source_plan_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "source_scorecard_snapshot_id",
    "source_scorecard_hash",
    "proposal_scope",
    "target_metric",
    "adoption_decision",
    "trial_mode",
    "max_trial_scope_pct",
    "max_trial_sessions",
    "min_trial_outcomes",
    "max_relative_error_degradation_pct",
    "rollback_on_error_degradation",
    "rollback_on_assumption_drift",
    "rollback_on_integrity_failure",
    "rollback_on_source_supersession",
    "rollback_detail",
    "source_review_confirmed",
    "isolation_confirmed",
    "manual_start_required_confirmed",
    "rollback_path_confirmed",
    "no_live_apply_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "trial_design_authorization",
    "trial_start_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


CONTROLLED_TRIAL_DESIGN_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


CONTROLLED_TRIAL_DESIGN_STATES = {
    "TRIAL_DESIGN_UPSTREAM_WAIT",
    "TRIAL_DESIGN_NOT_REQUIRED",
    "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED",
    "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW",
    "TRIAL_DESIGN_REQUIRED",
    "TRIAL_DESIGN_SUPERSEDED",
    "TRIAL_DESIGN_LOCKED",
}


TRIAL_DESIGN_GUARD_BY_STATE = {
    "TRIAL_DESIGN_UPSTREAM_WAIT": "HOLD_ADOPTION_DECISION",
    "TRIAL_DESIGN_NOT_REQUIRED": "NO_CONTROLLED_TRIAL",
    "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED": "HOLD_ADOPTION_SOURCE",
    "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW": "HOLD_TRIAL_DESIGN_INTEGRITY",
    "TRIAL_DESIGN_REQUIRED": "HUMAN_TRIAL_DESIGN_REQUIRED",
    "TRIAL_DESIGN_SUPERSEDED": "HOLD_TRIAL_DESIGN",
    "TRIAL_DESIGN_LOCKED": "TRIAL_DESIGN_LOCKED_NO_START",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _design_payload(row: dict) -> dict:
    int_fields = {
        "max_trial_sessions",
        "min_trial_outcomes",
    }
    float_fields = {
        "max_trial_scope_pct",
        "max_relative_error_degradation_pct",
    }
    bool_fields = {
        "rollback_on_error_degradation",
        "rollback_on_assumption_drift",
        "rollback_on_integrity_failure",
        "rollback_on_source_supersession",
        "source_review_confirmed",
        "isolation_confirmed",
        "manual_start_required_confirmed",
        "rollback_path_confirmed",
        "no_live_apply_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS:
        if col in {
            "controlled_trial_design_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def controlled_trial_design_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _design_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_controlled_trial_design_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _accepted_source(
    adoption: dict | None,
) -> dict:
    row = adoption or {}

    if _text(
        row.get("adoption_state")
    ).upper() != "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL":
        return {}

    latest = row.get("latest_review") or {}

    if not latest:
        return {}

    if _text(
        shadow_adoption_review_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get("decision")
    ).upper() != "ACCEPT_FOR_CONTROLLED_TRIAL":
        return {}

    return latest


def _design_matches_source(
    design: dict | None,
    adoption_source: dict | None,
) -> bool:
    row = design or {}
    source = adoption_source or {}

    if not row or not source:
        return False

    if _text(
        controlled_trial_design_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    if _text(
        shadow_adoption_review_snapshot_integrity(
            source
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            row.get("source_adoption_review_id")
        )
        == _text(
            source.get("shadow_adoption_review_id")
        )
        and _text(
            row.get("source_adoption_review_hash")
        )
        == _text(
            source.get("snapshot_hash")
        )
    )


def build_flow_controlled_trial_design(
    shadow_adoption_review: dict | None,
    design_snapshots: pd.DataFrame | None,
    *,
    default_max_trial_scope_pct: float = 0.10,
    default_max_trial_sessions: int = 3,
    default_min_trial_outcomes: int = 3,
    default_max_relative_error_degradation_pct: float = 0.10,
) -> dict:
    adoption = shadow_adoption_review or {}
    adoption_state = _text(
        adoption.get("adoption_state")
    ).upper()

    base = {
        "source_adoption_review_id": "",
        "source_adoption_review_hash": "",
        "source_adoption_review_created_at": "",
        "source_adoption_review_integrity": "NONE",
        "source_validation_outcome_id": _text(
            adoption.get("source_validation_outcome_id")
        ),
        "source_validation_outcome_hash": _text(
            adoption.get("source_validation_outcome_hash")
        ),
        "source_plan_id": _text(
            adoption.get("source_plan_id")
        ),
        "source_plan_hash": _text(
            adoption.get("source_plan_hash")
        ),
        "source_proposal_id": _text(
            adoption.get("source_proposal_id")
        ),
        "source_proposal_hash": _text(
            adoption.get("source_proposal_hash")
        ),
        "source_scorecard_snapshot_id": _text(
            adoption.get("source_scorecard_snapshot_id")
        ),
        "source_scorecard_hash": _text(
            adoption.get("source_scorecard_hash")
        ),
        "proposal_scope": _text(
            adoption.get("proposal_scope")
        ).upper(),
        "target_metric": _text(
            adoption.get("target_metric")
        ).upper(),
        "adoption_decision": _text(
            adoption.get("decision")
        ).upper(),
        "trial_mode": "SHADOW_CANARY_ONLY",
        "max_trial_scope_pct": max(
            0.01,
            min(
                0.10,
                float(
                    default_max_trial_scope_pct
                ),
            ),
        ),
        "max_trial_sessions": max(
            1,
            min(
                5,
                _int(
                    default_max_trial_sessions
                ),
            ),
        ),
        "min_trial_outcomes": max(
            3,
            _int(
                default_min_trial_outcomes
            ),
        ),
        "max_relative_error_degradation_pct": max(
            0.0,
            min(
                0.10,
                float(
                    default_max_relative_error_degradation_pct
                ),
            ),
        ),
        "rollback_on_error_degradation": True,
        "rollback_on_assumption_drift": True,
        "rollback_on_integrity_failure": True,
        "rollback_on_source_supersession": True,
        "rollback_detail": "",
        "latest_design": {},
        "trial_design_authorization": "NONE",
        "trial_start_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if adoption_state in {
        "",
        "ADOPTION_UPSTREAM_WAIT",
        "ADOPTION_VALIDATION_AUDIT_REQUIRED",
        "ADOPTION_VALIDATION_INTEGRITY_REVIEW",
        "ADOPTION_SOURCE_SUPERSEDED",
        "ADOPTION_REVIEW_REQUIRED",
        "ADOPTION_VALIDATION_INCONCLUSIVE",
    }:
        return {
            **base,
            "design_state": "TRIAL_DESIGN_UPSTREAM_WAIT",
            "design_guard": "HOLD_ADOPTION_DECISION",
        }

    if adoption_state in {
        "ADOPTION_VALIDATION_FAILED",
        "ADOPTION_REJECTED",
        "ADOPTION_DEFERRED",
    }:
        return {
            **base,
            "design_state": "TRIAL_DESIGN_NOT_REQUIRED",
            "design_guard": "NO_CONTROLLED_TRIAL",
        }

    if adoption_state != "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL":
        return {
            **base,
            "design_state": "TRIAL_DESIGN_UPSTREAM_WAIT",
            "design_guard": "HOLD_ADOPTION_DECISION",
        }

    source = _accepted_source(
        adoption
    )

    if not source:
        return {
            **base,
            "design_state": "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED",
            "design_guard": "HOLD_ADOPTION_SOURCE",
        }

    source_integrity = _text(
        shadow_adoption_review_snapshot_integrity(
            source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_adoption_review_id":
                _text(
                    source.get(
                        "shadow_adoption_review_id"
                    )
                ),
            "source_adoption_review_hash":
                _text(
                    source.get(
                        "snapshot_hash"
                    )
                ),
            "source_adoption_review_created_at":
                _text(
                    source.get(
                        "created_at"
                    )
                ),
            "source_adoption_review_integrity":
                source_integrity,
            "source_validation_outcome_id":
                _text(
                    source.get(
                        "source_validation_outcome_id"
                    )
                ),
            "source_validation_outcome_hash":
                _text(
                    source.get(
                        "source_validation_outcome_hash"
                    )
                ),
            "source_plan_id":
                _text(
                    source.get(
                        "source_plan_id"
                    )
                ),
            "source_plan_hash":
                _text(
                    source.get(
                        "source_plan_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    source.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    source.get(
                        "source_proposal_hash"
                    )
                ),
            "source_scorecard_snapshot_id":
                _text(
                    source.get(
                        "source_scorecard_snapshot_id"
                    )
                ),
            "source_scorecard_hash":
                _text(
                    source.get(
                        "source_scorecard_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    source.get(
                        "target_metric"
                    )
                ).upper(),
            "adoption_decision":
                _text(
                    source.get(
                        "decision"
                    )
                ).upper(),
        }
    )

    if source_integrity != "OK":
        return {
            **base,
            "design_state": "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard": "HOLD_TRIAL_DESIGN_INTEGRITY",
        }

    history = (
        pd.DataFrame()
        if design_snapshots is None
        else design_snapshots.copy()
    )

    latest = latest_controlled_trial_design_snapshot(
        history
    )

    if not latest:
        return {
            **base,
            "design_state": "TRIAL_DESIGN_REQUIRED",
            "design_guard": "HUMAN_TRIAL_DESIGN_REQUIRED",
        }

    base["latest_design"] = latest

    latest_integrity = _text(
        controlled_trial_design_snapshot_integrity(
            latest
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "design_state": "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard": "HOLD_TRIAL_DESIGN_INTEGRITY",
        }

    if not _design_matches_source(
        latest,
        source,
    ):
        return {
            **base,
            "design_state": "TRIAL_DESIGN_SUPERSEDED",
            "design_guard": "HOLD_TRIAL_DESIGN",
        }

    return {
        **base,
        "design_state": "TRIAL_DESIGN_LOCKED",
        "design_guard": "TRIAL_DESIGN_LOCKED_NO_START",
        "trial_mode": _text(
            latest.get("trial_mode")
        ),
        "max_trial_scope_pct": _float(
            latest.get("max_trial_scope_pct")
        ),
        "max_trial_sessions": _int(
            latest.get("max_trial_sessions")
        ),
        "min_trial_outcomes": _int(
            latest.get("min_trial_outcomes")
        ),
        "max_relative_error_degradation_pct": _float(
            latest.get(
                "max_relative_error_degradation_pct"
            )
        ),
        "rollback_on_error_degradation": _bool(
            latest.get(
                "rollback_on_error_degradation"
            )
        ),
        "rollback_on_assumption_drift": _bool(
            latest.get(
                "rollback_on_assumption_drift"
            )
        ),
        "rollback_on_integrity_failure": _bool(
            latest.get(
                "rollback_on_integrity_failure"
            )
        ),
        "rollback_on_source_supersession": _bool(
            latest.get(
                "rollback_on_source_supersession"
            )
        ),
        "rollback_detail": _text(
            latest.get("rollback_detail")
        ),
    }


def build_flow_controlled_trial_design_lock(
    design: dict,
    *,
    max_trial_scope_pct: float = 0.10,
    max_trial_sessions: int = 3,
    min_trial_outcomes: int = 3,
    max_relative_error_degradation_pct: float = 0.10,
    rollback_detail: str,
    rollback_on_error_degradation: bool = True,
    rollback_on_assumption_drift: bool = True,
    rollback_on_integrity_failure: bool = True,
    rollback_on_source_supersession: bool = True,
    source_review_confirmed: bool,
    isolation_confirmed: bool,
    manual_start_required_confirmed: bool,
    rollback_path_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = design or {}

    if _text(
        current.get("design_state")
    ).upper() != "TRIAL_DESIGN_REQUIRED":
        raise ValueError(
            "Controlled Trial Design은 TRIAL_DESIGN_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_adoption_review_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Adoption Review integrity가 OK가 아닙니다."
        )

    scope = float(
        max_trial_scope_pct
    )
    sessions = int(
        max_trial_sessions
    )
    outcomes = int(
        min_trial_outcomes
    )
    degradation = float(
        max_relative_error_degradation_pct
    )

    if not (
        0.01
        <= scope
        <= 0.10
    ):
        raise ValueError(
            "Trial scope cap은 1%~10% 범위여야 합니다."
        )

    if not (
        1
        <= sessions
        <= 5
    ):
        raise ValueError(
            "Trial session cap은 1~5 범위여야 합니다."
        )

    if outcomes < 3:
        raise ValueError(
            "Trial outcome 최소 개수는 3개입니다."
        )

    if not (
        0.0
        <= degradation
        <= 0.10
    ):
        raise ValueError(
            "허용 상대 error 악화 한도는 0%~10% 범위여야 합니다."
        )

    rollback = _text(
        rollback_detail
    )

    if len(
        rollback
    ) < 40:
        raise ValueError(
            "Rollback contract를 40자 이상 기록하세요."
        )

    rollback_flags = {
        "rollback_on_error_degradation":
            bool(
                rollback_on_error_degradation
            ),
        "rollback_on_assumption_drift":
            bool(
                rollback_on_assumption_drift
            ),
        "rollback_on_integrity_failure":
            bool(
                rollback_on_integrity_failure
            ),
        "rollback_on_source_supersession":
            bool(
                rollback_on_source_supersession
            ),
    }

    if not all(
        rollback_flags.values()
    ):
        raise ValueError(
            "v1.41-dev1 Controlled Trial Design은 모든 rollback trigger를 요구합니다."
        )

    confirmations = {
        "source_review_confirmed":
            bool(
                source_review_confirmed
            ),
        "isolation_confirmed":
            bool(
                isolation_confirmed
            ),
        "manual_start_required_confirmed":
            bool(
                manual_start_required_confirmed
            ),
        "rollback_path_confirmed":
            bool(
                rollback_path_confirmed
            ),
        "no_live_apply_confirmed":
            bool(
                no_live_apply_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Controlled Trial Design Human Review 확인사항을 모두 검토해야 합니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    source_created = pd.to_datetime(
        current.get(
            "source_adoption_review_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    design_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            source_created
        )
        or pd.isna(
            design_created
        )
        or design_created <= source_created
    ):
        raise ValueError(
            "Controlled Trial Design은 source Adoption Review 이후에 저장되어야 합니다."
        )

    base = {
        "design_state":
            "TRIAL_DESIGN_LOCKED",
        "design_guard":
            "TRIAL_DESIGN_LOCKED_NO_START",
        "source_adoption_review_id":
            _text(
                current.get(
                    "source_adoption_review_id"
                )
            ),
        "source_adoption_review_hash":
            _text(
                current.get(
                    "source_adoption_review_hash"
                )
            ),
        "source_adoption_review_created_at":
            _text(
                current.get(
                    "source_adoption_review_created_at"
                )
            ),
        "source_adoption_review_integrity":
            "OK",
        "source_validation_outcome_id":
            _text(
                current.get(
                    "source_validation_outcome_id"
                )
            ),
        "source_validation_outcome_hash":
            _text(
                current.get(
                    "source_validation_outcome_hash"
                )
            ),
        "source_plan_id":
            _text(
                current.get(
                    "source_plan_id"
                )
            ),
        "source_plan_hash":
            _text(
                current.get(
                    "source_plan_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "source_scorecard_snapshot_id":
            _text(
                current.get(
                    "source_scorecard_snapshot_id"
                )
            ),
        "source_scorecard_hash":
            _text(
                current.get(
                    "source_scorecard_hash"
                )
            ),
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "adoption_decision":
            "ACCEPT_FOR_CONTROLLED_TRIAL",
        "trial_mode":
            "SHADOW_CANARY_ONLY",
        "max_trial_scope_pct":
            scope,
        "max_trial_sessions":
            sessions,
        "min_trial_outcomes":
            outcomes,
        "max_relative_error_degradation_pct":
            degradation,
        **rollback_flags,
        "rollback_detail":
            rollback,
        **confirmations,
        "trial_design_authorization":
            "NONE",
        "trial_start_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _design_payload(
            base
        )
    )

    return {
        "controlled_trial_design_id": (
            "CTD-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_controlled_trial_design_queue(
    design: dict | None,
) -> pd.DataFrame:
    row = design or {}

    state = _text(
        row.get("design_state")
    ).upper()

    mapping = {
        "TRIAL_DESIGN_UPSTREAM_WAIT": (
            "CT2",
            "WAIT",
            "TRIAL_DESIGN_UPSTREAM_WAIT",
            "ACCEPT_FOR_CONTROLLED_TRIAL Human decision이 아직 없음",
            "prospective evidence와 Human Adoption decision이 자연스럽게 성숙할 때까지 대기",
        ),
        "TRIAL_DESIGN_NOT_REQUIRED": (
            "CT3",
            "MONITOR",
            "TRIAL_DESIGN_NOT_REQUIRED",
            "Adoption decision이 REJECT/DEFER 또는 validation fail",
            "live apply 없이 새 evidence/Proposal cycle을 관찰",
        ),
        "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED": (
            "CT1",
            "REVIEW",
            "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED",
            "ACCEPT 상태이나 immutable Adoption Review source가 없음",
            "Human Adoption Review audit을 먼저 확인",
        ),
        "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW": (
            "CT0",
            "BLOCKED",
            "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "Adoption source 또는 Trial Design immutable hash mismatch",
            "source Adoption / Trial Design audit integrity를 먼저 복구",
        ),
        "TRIAL_DESIGN_REQUIRED": (
            "CT1",
            "REVIEW",
            "TRIAL_DESIGN_REQUIRED",
            (
                f"mode SHADOW_CANARY_ONLY · "
                f"scope <= {float(row.get('max_trial_scope_pct',0)):.0%} · "
                f"sessions <= {int(row.get('max_trial_sessions',0))}"
            ),
            "trial scope와 rollback contract를 Human Review 후 사전등록",
        ),
        "TRIAL_DESIGN_SUPERSEDED": (
            "CT0",
            "REVIEW",
            "TRIAL_DESIGN_SUPERSEDED",
            "새 Adoption source로 기존 Trial Design이 stale",
            "현재 ACCEPT source 기준으로 Trial Design 재등록",
        ),
        "TRIAL_DESIGN_LOCKED": (
            "CT3",
            "MONITOR",
            "TRIAL_DESIGN_LOCKED",
            (
                f"scope <= {float(row.get('max_trial_scope_pct',0)):.0%} · "
                f"sessions <= {int(row.get('max_trial_sessions',0))} · "
                f"outcomes >= {int(row.get('min_trial_outcomes',0))}"
            ),
            "Design LOCKED는 trial start 승인이 아님; 별도 Trial Start Gate 필요",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "CT0",
            "BLOCKED",
            "TRIAL_DESIGN_UNKNOWN_STATE",
            state or "MISSING",
            "Controlled Trial Design state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            CONTROLLED_TRIAL_DESIGN_QUEUE_COLS,
    )
