from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_trend import (
    valid_trend_history,
)


FLOW_CALIBRATION_SNAPSHOT_COLS = [
    "calibration_snapshot_id",
    "created_at",
    "saved_trend_snapshots",
    "invalid_trend_snapshots",
    "observed_intervals",
    "current_groups",
    "attention_groups",
    "capacity",
    "avg_arrivals_per_interval",
    "avg_exits_per_interval",
    "avg_net_burn_per_interval",
    "positive_burn_intervals",
    "zero_burn_intervals",
    "negative_burn_intervals",
    "positive_burn_ratio",
    "exit_per_capacity",
    "attention_pressure",
    "backlog_pressure",
    "top_root_cause",
    "root_cause_concentration",
    "calibration_state",
    "projection_guard",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


CALIBRATION_INTERVAL_COLS = [
    "period_end",
    "arrivals",
    "exits",
    "net_burn",
    "current_groups",
    "attention_groups",
    "capacity",
]


ROOT_CAUSE_BURDEN_COLS = [
    "root_cause",
    "group_count",
    "group_share",
    "item_count",
    "subject_count",
]


CALIBRATION_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _snapshot_payload(row: dict) -> dict:
    float_fields = {
        "avg_arrivals_per_interval",
        "avg_exits_per_interval",
        "avg_net_burn_per_interval",
        "positive_burn_ratio",
        "exit_per_capacity",
        "attention_pressure",
        "backlog_pressure",
        "root_cause_concentration",
    }

    int_fields = {
        "saved_trend_snapshots",
        "invalid_trend_snapshots",
        "observed_intervals",
        "current_groups",
        "attention_groups",
        "capacity",
        "positive_burn_intervals",
        "zero_burn_intervals",
        "negative_burn_intervals",
    }

    payload = {}

    for col in FLOW_CALIBRATION_SNAPSHOT_COLS:
        if col in {
            "calibration_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def flow_calibration_snapshot_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "snapshot_hash"
        )
    )

    if not stored:
        return {
            "status":
                "MISSING",
            "calculated_hash":
                "",
        }

    calculated = _hash(
        _snapshot_payload(
            record
        )
    )

    return {
        "status":
            (
                "OK"
                if stored
                == calculated
                else "MISMATCH"
            ),
        "calculated_hash":
            calculated,
    }


def latest_flow_calibration_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    if snapshots is None or snapshots.empty:
        return {}

    df = snapshots.copy()

    if "created_at" in df.columns:
        df[
            "_ts"
        ] = pd.to_datetime(
            df[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        df = df.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        df.iloc[
            0
        ]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def _build_interval_table(
    trend: dict | None,
) -> pd.DataFrame:
    result = trend or {}
    history = result.get(
        "history_table"
    )

    if (
        not isinstance(
            history,
            pd.DataFrame,
        )
        or history.empty
    ):
        return pd.DataFrame(
            columns=
            CALIBRATION_INTERVAL_COLS
        )

    df = history.copy()

    for col in [
        "period_end",
        "arrivals",
        "exits",
        "current_groups",
        "attention_groups",
        "capacity",
    ]:
        if col not in df.columns:
            df[
                col
            ] = ""

    arrivals = pd.to_numeric(
        df[
            "arrivals"
        ],
        errors="coerce",
    ).fillna(
        0
    )
    exits = pd.to_numeric(
        df[
            "exits"
        ],
        errors="coerce",
    ).fillna(
        0
    )

    df[
        "net_burn"
    ] = exits - arrivals

    return df[
        CALIBRATION_INTERVAL_COLS
    ].reset_index(
        drop=True
    )


def _build_root_cause_burden(
    recurrence_table: pd.DataFrame | None,
) -> pd.DataFrame:
    df = (
        pd.DataFrame()
        if recurrence_table is None
        else recurrence_table.copy()
    )

    if df.empty:
        return pd.DataFrame(
            columns=
            ROOT_CAUSE_BURDEN_COLS
        )

    for col in [
        "root_cause",
        "item_count",
        "subject_count",
    ]:
        if col not in df.columns:
            df[
                col
            ] = ""

    total_groups = max(
        1,
        int(
            len(
                df
            )
        ),
    )

    rows = []

    for cause, part in df.groupby(
        "root_cause",
        dropna=False,
    ):
        root = (
            _text(
                cause
            )
            or "UNCLASSIFIED"
        )

        rows.append(
            {
                "root_cause":
                    root,
                "group_count":
                    int(
                        len(
                            part
                        )
                    ),
                "group_share":
                    float(
                        len(
                            part
                        )
                        / total_groups
                    ),
                "item_count":
                    int(
                        pd.to_numeric(
                            part[
                                "item_count"
                            ],
                            errors="coerce",
                        )
                        .fillna(
                            0
                        )
                        .sum()
                    ),
                "subject_count":
                    int(
                        pd.to_numeric(
                            part[
                                "subject_count"
                            ],
                            errors="coerce",
                        )
                        .fillna(
                            0
                        )
                        .sum()
                    ),
            }
        )

    out = pd.DataFrame(
        rows,
        columns=
        ROOT_CAUSE_BURDEN_COLS,
    )

    return out.sort_values(
        [
            "group_count",
            "item_count",
            "root_cause",
        ],
        ascending=[
            False,
            False,
            True,
        ],
    ).reset_index(
        drop=True
    )


def build_flow_calibration(
    trend: dict | None,
    recurrence_table: pd.DataFrame | None,
    trend_snapshots: pd.DataFrame | None,
    *,
    capacity: int = 5,
    min_saved_snapshots: int = 3,
    min_observed_intervals: int | None = None,
    min_positive_burn_ratio: float = 2 / 3,
) -> dict:
    result = trend or {}

    history_info = valid_trend_history(
        trend_snapshots
    )
    valid_history = history_info[
        "valid"
    ]

    saved_snapshots = int(
        len(
            valid_history
        )
    )
    invalid_snapshots = _int(
        history_info.get(
            "invalid_count"
        )
    )

    intervals = _build_interval_table(
        result
    )
    observed_intervals = int(
        len(
            intervals
        )
    )

    if intervals.empty:
        avg_arrivals = 0.0
        avg_exits = 0.0
        avg_net_burn = 0.0
        positive = 0
        zero = 0
        negative = 0
        positive_ratio = 0.0
    else:
        arrivals = pd.to_numeric(
            intervals[
                "arrivals"
            ],
            errors="coerce",
        ).fillna(
            0
        )
        exits = pd.to_numeric(
            intervals[
                "exits"
            ],
            errors="coerce",
        ).fillna(
            0
        )
        net_burn = pd.to_numeric(
            intervals[
                "net_burn"
            ],
            errors="coerce",
        ).fillna(
            0
        )

        avg_arrivals = float(
            arrivals.mean()
        )
        avg_exits = float(
            exits.mean()
        )
        avg_net_burn = float(
            net_burn.mean()
        )
        positive = int(
            net_burn.gt(
                0
            ).sum()
        )
        zero = int(
            net_burn.eq(
                0
            ).sum()
        )
        negative = int(
            net_burn.lt(
                0
            ).sum()
        )
        positive_ratio = (
            float(
                positive
                / observed_intervals
            )
            if observed_intervals
            else 0.0
        )

    cap = max(
        1,
        _int(
            capacity
        ),
    )

    current_groups = _int(
        result.get(
            "current_groups"
        )
    )
    attention_groups = _int(
        result.get(
            "attention_groups"
        )
    )

    root_burden = _build_root_cause_burden(
        recurrence_table
    )

    if root_burden.empty:
        top_root = ""
        root_concentration = 0.0
    else:
        top_root = _text(
            root_burden.iloc[
                0
            ][
                "root_cause"
            ]
        )
        root_concentration = _float(
            root_burden.iloc[
                0
            ][
                "group_share"
            ]
        )

    required_intervals = max(
        1,
        _int(
            min_saved_snapshots
            if min_observed_intervals is None
            else min_observed_intervals
        ),
    )

    if invalid_snapshots > 0:
        calibration_state = "INTEGRITY_REVIEW"
        projection_guard = "HOLD_INTEGRITY"
    elif saved_snapshots < max(
        1,
        _int(
            min_saved_snapshots
        ),
    ):
        calibration_state = "INSUFFICIENT_HISTORY"
        projection_guard = "HOLD_HISTORY"
    elif observed_intervals < required_intervals:
        calibration_state = "INSUFFICIENT_INTERVALS"
        projection_guard = "HOLD_HISTORY"
    elif avg_net_burn <= 0:
        calibration_state = "NO_CLEARING_TREND"
        projection_guard = "HOLD_NO_CLEARING"
    elif positive_ratio >= float(
        min_positive_burn_ratio
    ):
        calibration_state = "POSITIVE_BURN_CALIBRATED"
        projection_guard = "ALLOW_PROJECTION_REVIEW"
    else:
        calibration_state = "MIXED_BURN"
        projection_guard = "HOLD_MIXED"

    return {
        "saved_trend_snapshots":
            saved_snapshots,
        "invalid_trend_snapshots":
            invalid_snapshots,
        "observed_intervals":
            observed_intervals,
        "required_observed_intervals":
            required_intervals,
        "current_groups":
            current_groups,
        "attention_groups":
            attention_groups,
        "capacity":
            cap,
        "avg_arrivals_per_interval":
            avg_arrivals,
        "avg_exits_per_interval":
            avg_exits,
        "avg_net_burn_per_interval":
            avg_net_burn,
        "positive_burn_intervals":
            positive,
        "zero_burn_intervals":
            zero,
        "negative_burn_intervals":
            negative,
        "positive_burn_ratio":
            positive_ratio,
        "exit_per_capacity":
            float(
                avg_exits
                / cap
            ),
        "attention_pressure":
            float(
                attention_groups
                / cap
            ),
        "backlog_pressure":
            float(
                current_groups
                / cap
            ),
        "top_root_cause":
            top_root,
        "root_cause_concentration":
            root_concentration,
        "calibration_state":
            calibration_state,
        "projection_guard":
            projection_guard,
        "intervals":
            intervals,
        "root_cause_burden":
            root_burden,
        "execution_authorization":
            "NONE",
    }


def build_flow_calibration_queue(
    calibration: dict | None,
) -> pd.DataFrame:
    result = calibration or {}
    rows = []

    state = _text(
        result.get(
            "calibration_state"
        )
    ).upper()

    if state == "INTEGRITY_REVIEW":
        rows.append(
            {
                "priority":
                    "FC0",
                "status":
                    "BLOCKED",
                "issue":
                    "FLOW_CALIBRATION_INTEGRITY_REVIEW",
                "detail":
                    (
                        f"invalid trend snapshots "
                        f"{_int(result.get('invalid_trend_snapshots'))}"
                    ),
                "next_action":
                    "Flow Trend Snapshot immutable hash를 먼저 확인",
                "go_to":
                    "Operations Control Tower",
            }
        )
    elif state in {
        "INSUFFICIENT_HISTORY",
        "INSUFFICIENT_INTERVALS",
    }:
        rows.append(
            {
                "priority":
                    "FC1",
                "status":
                    "REVIEW",
                "issue":
                    "FLOW_CALIBRATION_HISTORY_REQUIRED",
                "detail":
                    (
                        f"saved {_int(result.get('saved_trend_snapshots'))} · "
                        f"intervals {_int(result.get('observed_intervals'))}"
                    ),
                "next_action":
                    "실제 운영 변화가 발생할 때 Trend Snapshot을 추가 축적",
                "go_to":
                    "Operations Control Tower",
            }
        )
    elif state == "NO_CLEARING_TREND":
        rows.append(
            {
                "priority":
                    "FC1",
                "status":
                    "REVIEW",
                "issue":
                    "FLOW_NO_CLEARING_TREND",
                "detail":
                    (
                        f"avg net burn "
                        f"{_float(result.get('avg_net_burn_per_interval')):.2f}"
                    ),
                "next_action":
                    "Arrival보다 Exit가 많아지지 않는 Root Cause를 검토",
                "go_to":
                    "Review Queue",
            }
        )
    elif state == "MIXED_BURN":
        rows.append(
            {
                "priority":
                    "FC2",
                "status":
                    "REVIEW",
                "issue":
                    "FLOW_MIXED_BURN_CALIBRATION",
                "detail":
                    (
                        f"positive burn ratio "
                        f"{_float(result.get('positive_burn_ratio')):.1%}"
                    ),
                "next_action":
                    "Burn-down 관측이 일관적인지 Trend history를 추가 확인",
                "go_to":
                    "Operations Control Tower",
            }
        )

    attention_pressure = _float(
        result.get(
            "attention_pressure"
        )
    )

    if attention_pressure > 1.0:
        rows.append(
            {
                "priority":
                    "FC2",
                "status":
                    "REVIEW",
                "issue":
                    "FLOW_ATTENTION_CAPACITY_PRESSURE",
                "detail":
                    f"{attention_pressure:.2f}x",
                "next_action":
                    "RQ0/RQ1 Worklist와 Carry-forward 우선순위를 검토",
                "go_to":
                    "Operations Control Tower",
            }
        )

    root_concentration = _float(
        result.get(
            "root_cause_concentration"
        )
    )
    current_groups = _int(
        result.get(
            "current_groups"
        )
    )

    if (
        current_groups >= 4
        and root_concentration >= 0.50
    ):
        rows.append(
            {
                "priority":
                    "FC2",
                "status":
                    "REVIEW",
                "issue":
                    "FLOW_ROOT_CAUSE_CONCENTRATION",
                "detail":
                    (
                        f"{_text(result.get('top_root_cause'))} · "
                        f"{root_concentration:.1%}"
                    ),
                "next_action":
                    "가장 큰 Root Cause 묶음의 원본 Review 흐름을 우선 확인",
                "go_to":
                    "Review Queue",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            CALIBRATION_QUEUE_COLS
        )

    order = {
        "FC0": 0,
        "FC1": 1,
        "FC2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            CALIBRATION_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )


def build_flow_calibration_snapshot(
    calibration: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    payload = {
        "saved_trend_snapshots":
            _int(
                calibration.get(
                    "saved_trend_snapshots"
                )
            ),
        "invalid_trend_snapshots":
            _int(
                calibration.get(
                    "invalid_trend_snapshots"
                )
            ),
        "observed_intervals":
            _int(
                calibration.get(
                    "observed_intervals"
                )
            ),
        "current_groups":
            _int(
                calibration.get(
                    "current_groups"
                )
            ),
        "attention_groups":
            _int(
                calibration.get(
                    "attention_groups"
                )
            ),
        "capacity":
            _int(
                calibration.get(
                    "capacity"
                )
            ),
        "avg_arrivals_per_interval":
            round(
                _float(
                    calibration.get(
                        "avg_arrivals_per_interval"
                    )
                ),
                10,
            ),
        "avg_exits_per_interval":
            round(
                _float(
                    calibration.get(
                        "avg_exits_per_interval"
                    )
                ),
                10,
            ),
        "avg_net_burn_per_interval":
            round(
                _float(
                    calibration.get(
                        "avg_net_burn_per_interval"
                    )
                ),
                10,
            ),
        "positive_burn_intervals":
            _int(
                calibration.get(
                    "positive_burn_intervals"
                )
            ),
        "zero_burn_intervals":
            _int(
                calibration.get(
                    "zero_burn_intervals"
                )
            ),
        "negative_burn_intervals":
            _int(
                calibration.get(
                    "negative_burn_intervals"
                )
            ),
        "positive_burn_ratio":
            round(
                _float(
                    calibration.get(
                        "positive_burn_ratio"
                    )
                ),
                10,
            ),
        "exit_per_capacity":
            round(
                _float(
                    calibration.get(
                        "exit_per_capacity"
                    )
                ),
                10,
            ),
        "attention_pressure":
            round(
                _float(
                    calibration.get(
                        "attention_pressure"
                    )
                ),
                10,
            ),
        "backlog_pressure":
            round(
                _float(
                    calibration.get(
                        "backlog_pressure"
                    )
                ),
                10,
            ),
        "top_root_cause":
            _text(
                calibration.get(
                    "top_root_cause"
                )
            ),
        "root_cause_concentration":
            round(
                _float(
                    calibration.get(
                        "root_cause_concentration"
                    )
                ),
                10,
            ),
        "calibration_state":
            _text(
                calibration.get(
                    "calibration_state"
                )
            ),
        "projection_guard":
            _text(
                calibration.get(
                    "projection_guard"
                )
            ),
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        payload
    )

    return {
        "calibration_snapshot_id":
            (
                "OFC-"
                + pd.Timestamp(
                    now
                ).strftime(
                    "%Y%m%dT%H%M%S"
                )
                + "-"
                + snapshot_hash[:8]
            ),
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
