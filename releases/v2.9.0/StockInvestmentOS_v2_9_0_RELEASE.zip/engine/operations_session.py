from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


OPERATIONS_SESSION_COLS = [
    "session_id",
    "event_id",
    "created_at",
    "session_date",
    "event_type",
    "event_status",
    "system_state",
    "blocking_count",
    "review_count",
    "raw_review_items",
    "action_groups",
    "attention_items",
    "attention_groups",
    "top_priority",
    "top_domain",
    "top_issue",
    "worklist_group_ids",
    "worklist_snapshot_hash",
    "core_gate_snapshot",
    "core_gate_hash",
    "parent_open_record_hash",
    "carry_forward_groups",
    "carry_forward_summary",
    "control_tower_review_confirmed",
    "worklist_review_confirmed",
    "no_source_auto_resolution_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


SESSION_EVENT_TYPES = [
    "OPEN",
    "CLOSE",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _session_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "control_tower_review_confirmed",
        "worklist_review_confirmed",
        "no_source_auto_resolution_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in OPERATIONS_SESSION_COLS:
        if col == "record_hash":
            continue

        if col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def operations_session_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _session_payload(
            record
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def worklist_snapshot(
    worklist: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if worklist is None
        else worklist.copy()
    )

    if df.empty:
        rows = []
        group_ids = []
    else:
        keep_cols = [
            "session_rank",
            "priority",
            "phase",
            "category",
            "status",
            "item_count",
            "subject_count",
            "sample_subjects",
            "sample_issues",
            "next_action",
            "go_to",
            "group_id",
        ]

        for col in keep_cols:
            if col not in df.columns:
                df[col] = ""

        rows = (
            df[keep_cols]
            .fillna("")
            .to_dict(
                orient="records"
            )
        )

        group_ids = [
            _text(value)
            for value in df[
                "group_id"
            ].tolist()
            if _text(value)
        ]

    return {
        "group_ids": group_ids,
        "group_ids_text": " | ".join(group_ids),
        "snapshot_hash": _hash(
            rows
        ),
        "rows": rows,
    }


def core_gate_snapshot(
    core_gates: dict | None,
) -> dict:
    gates = core_gates or {}

    normalized = {
        key: _text(value).upper()
        for key, value in sorted(
            gates.items(),
            key=lambda item: item[0],
        )
    }

    return {
        "snapshot_json": json.dumps(
            normalized,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        "snapshot_hash": _hash(
            normalized
        ),
        "gates": normalized,
    }


def carry_forward_summary(
    tower: dict | None,
    worklist: pd.DataFrame | None,
) -> dict:
    result = tower or {}
    df = (
        pd.DataFrame()
        if worklist is None
        else worklist.copy()
    )

    if df.empty:
        return {
            "groups": 0,
            "summary": "NONE",
        }

    summaries = []

    for _, row in df.iterrows():
        summaries.append(
            (
                f"[{_text(row.get('priority'))}] "
                f"{_text(row.get('category'))} · "
                f"{_int(row.get('item_count'))} items · "
                f"{_text(row.get('go_to'))}"
            )
        )

    return {
        "groups": int(
            len(df)
        ),
        "summary": " || ".join(
            summaries
        ),
    }


def _latest_rows(
    sessions: pd.DataFrame | None,
) -> pd.DataFrame:
    if sessions is None or sessions.empty:
        return pd.DataFrame(
            columns=
            OPERATIONS_SESSION_COLS
        )

    df = sessions.copy()

    for col in OPERATIONS_SESSION_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    return df.sort_values(
        "_ts",
        ascending=False,
        na_position="last",
    ).reset_index(
        drop=True
    )


def latest_session_event(
    sessions: pd.DataFrame | None,
) -> dict:
    df = _latest_rows(
        sessions
    )

    if df.empty:
        return {}

    return (
        df.iloc[0]
        .drop(
            labels=["_ts"],
            errors="ignore",
        )
        .to_dict()
    )


def latest_closed_session(
    sessions: pd.DataFrame | None,
) -> dict:
    df = _latest_rows(
        sessions
    )

    if df.empty:
        return {}

    hit = df.loc[
        df[
            "event_type"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("CLOSE")
    ]

    if hit.empty:
        return {}

    return (
        hit.iloc[0]
        .drop(
            labels=["_ts"],
            errors="ignore",
        )
        .to_dict()
    )


def current_open_session(
    sessions: pd.DataFrame | None,
) -> dict:
    df = _latest_rows(
        sessions
    )

    if df.empty:
        return {}

    # Iterate newest-to-oldest. Once a CLOSE appears for a session,
    # that session is closed. The newest unmatched OPEN is active.
    closed_ids = set()

    for _, row in df.iterrows():
        event_type = _text(
            row.get(
                "event_type"
            )
        ).upper()
        session_id = _text(
            row.get(
                "session_id"
            )
        )

        if not session_id:
            continue

        if event_type == "CLOSE":
            closed_ids.add(
                session_id
            )
            continue

        if (
            event_type == "OPEN"
            and session_id
            not in closed_ids
        ):
            record = row.drop(
                labels=["_ts"],
                errors="ignore",
            ).to_dict()

            if operations_session_integrity(
                record
            )[
                "status"
            ] == "OK":
                return record

            return {
                **record,
                "_integrity_issue": True,
            }

    return {}


def build_open_session_record(
    tower: dict,
    compression: dict,
    worklist: pd.DataFrame,
    core_gates: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(created_at)
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    work = worklist_snapshot(
        worklist
    )
    core = core_gate_snapshot(
        core_gates
    )

    system_state = _text(
        tower.get(
            "system_state"
        )
    ).upper()

    session_seed = {
        "created_at": now,
        "system_state": system_state,
        "worklist_snapshot_hash":
            work["snapshot_hash"],
        "core_gate_hash":
            core["snapshot_hash"],
    }

    session_id = (
        "OPS-"
        + pd.Timestamp(now).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + _hash(
            session_seed
        )[:8]
    )

    event_id = (
        session_id
        + "-OPEN"
    )

    row = {
        "session_id":
            session_id,
        "event_id":
            event_id,
        "created_at":
            now,
        "session_date":
            pd.Timestamp(now).date().isoformat(),
        "event_type":
            "OPEN",
        "event_status":
            "OPENED",
        "system_state":
            system_state,
        "blocking_count":
            _int(
                tower.get(
                    "blocking_count"
                )
            ),
        "review_count":
            _int(
                tower.get(
                    "review_count"
                )
            ),
        "raw_review_items":
            _int(
                compression.get(
                    "raw_items"
                )
            ),
        "action_groups":
            _int(
                compression.get(
                    "action_groups"
                )
            ),
        "attention_items":
            _int(
                compression.get(
                    "attention_items"
                )
            ),
        "attention_groups":
            _int(
                compression.get(
                    "attention_groups"
                )
            ),
        "top_priority":
            _text(
                tower.get(
                    "top_priority"
                )
            ),
        "top_domain":
            _text(
                tower.get(
                    "top_domain"
                )
            ),
        "top_issue":
            _text(
                tower.get(
                    "top_issue"
                )
            ),
        "worklist_group_ids":
            work[
                "group_ids_text"
            ],
        "worklist_snapshot_hash":
            work[
                "snapshot_hash"
            ],
        "core_gate_snapshot":
            core[
                "snapshot_json"
            ],
        "core_gate_hash":
            core[
                "snapshot_hash"
            ],
        "parent_open_record_hash":
            "",
        "carry_forward_groups":
            0,
        "carry_forward_summary":
            "",
        "control_tower_review_confirmed":
            False,
        "worklist_review_confirmed":
            False,
        "no_source_auto_resolution_confirmed":
            False,
        "no_execution_authorization_confirmed":
            True,
        "human_review_confirmed":
            False,
        "execution_authorization":
            "NONE",
        "issues":
            "",
        "note":
            _text(note),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _session_payload(
            row
        )
    )

    return row


def validate_close_session(
    open_session: dict | None,
    tower: dict | None,
    *,
    control_tower_review_confirmed: bool,
    worklist_review_confirmed: bool,
    no_source_auto_resolution_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    open_row = open_session or {}
    result = tower or {}
    issues = []

    if not open_row:
        issues.append(
            "OPEN_SESSION_REQUIRED"
        )
    else:
        if _text(
            open_row.get(
                "event_type"
            )
        ).upper() != "OPEN":
            issues.append(
                "OPEN_SESSION_EVENT_REQUIRED"
            )

        if operations_session_integrity(
            open_row
        )[
            "status"
        ] != "OK":
            issues.append(
                "OPEN_SESSION_INTEGRITY_FAILED"
            )

    confirmations = [
        (
            control_tower_review_confirmed,
            "CONTROL_TOWER_REVIEW_CONFIRMATION_REQUIRED",
        ),
        (
            worklist_review_confirmed,
            "WORKLIST_REVIEW_CONFIRMATION_REQUIRED",
        ),
        (
            no_source_auto_resolution_confirmed,
            "NO_SOURCE_AUTO_RESOLUTION_CONFIRMATION_REQUIRED",
        ),
        (
            no_execution_authorization_confirmed,
            "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED",
        ),
        (
            human_review_confirmed,
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED",
        ),
    ]

    for passed, issue in confirmations:
        if not _bool(passed):
            issues.append(
                issue
            )

    gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    blocking = _int(
        result.get(
            "blocking_count"
        )
    )
    reviews = _int(
        result.get(
            "review_count"
        )
    )

    if gate != "PASS":
        status = "DRAFT"
    elif blocking > 0:
        status = "CLOSED_WITH_BLOCKERS"
    elif reviews > 0:
        status = "CLOSED_WITH_CARRY_FORWARD"
    else:
        status = "CLOSED_CLEAR"

    return {
        "close_gate": gate,
        "close_status": status,
        "execution_authorization": "NONE",
        "issues": list(
            dict.fromkeys(
                issues
            )
        ),
    }


def build_close_session_record(
    open_session: dict,
    tower: dict,
    compression: dict,
    worklist: pd.DataFrame,
    core_gates: dict,
    validation: dict,
    *,
    control_tower_review_confirmed: bool,
    worklist_review_confirmed: bool,
    no_source_auto_resolution_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    open_row = open_session or {}
    now = (
        _text(created_at)
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    work = worklist_snapshot(
        worklist
    )
    core = core_gate_snapshot(
        core_gates
    )
    carry = carry_forward_summary(
        tower,
        worklist,
    )

    session_id = _text(
        open_row.get(
            "session_id"
        )
    )

    event_id = (
        session_id
        + "-CLOSE-"
        + pd.Timestamp(now).strftime(
            "%H%M%S"
        )
    )

    row = {
        "session_id":
            session_id,
        "event_id":
            event_id,
        "created_at":
            now,
        "session_date":
            pd.Timestamp(now).date().isoformat(),
        "event_type":
            "CLOSE",
        "event_status":
            _text(
                validation.get(
                    "close_status"
                )
            ),
        "system_state":
            _text(
                tower.get(
                    "system_state"
                )
            ).upper(),
        "blocking_count":
            _int(
                tower.get(
                    "blocking_count"
                )
            ),
        "review_count":
            _int(
                tower.get(
                    "review_count"
                )
            ),
        "raw_review_items":
            _int(
                compression.get(
                    "raw_items"
                )
            ),
        "action_groups":
            _int(
                compression.get(
                    "action_groups"
                )
            ),
        "attention_items":
            _int(
                compression.get(
                    "attention_items"
                )
            ),
        "attention_groups":
            _int(
                compression.get(
                    "attention_groups"
                )
            ),
        "top_priority":
            _text(
                tower.get(
                    "top_priority"
                )
            ),
        "top_domain":
            _text(
                tower.get(
                    "top_domain"
                )
            ),
        "top_issue":
            _text(
                tower.get(
                    "top_issue"
                )
            ),
        "worklist_group_ids":
            work[
                "group_ids_text"
            ],
        "worklist_snapshot_hash":
            work[
                "snapshot_hash"
            ],
        "core_gate_snapshot":
            core[
                "snapshot_json"
            ],
        "core_gate_hash":
            core[
                "snapshot_hash"
            ],
        "parent_open_record_hash":
            _text(
                open_row.get(
                    "record_hash"
                )
            ),
        "carry_forward_groups":
            carry[
                "groups"
            ],
        "carry_forward_summary":
            carry[
                "summary"
            ],
        "control_tower_review_confirmed":
            bool(
                control_tower_review_confirmed
            ),
        "worklist_review_confirmed":
            bool(
                worklist_review_confirmed
            ),
        "no_source_auto_resolution_confirmed":
            bool(
                no_source_auto_resolution_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                validation.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(note),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _session_payload(
            row
        )
    )

    return row
