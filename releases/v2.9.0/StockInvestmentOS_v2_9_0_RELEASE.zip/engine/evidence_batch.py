from __future__ import annotations

from typing import Iterable
from difflib import SequenceMatcher

import pandas as pd


BATCH_QUEUE_COLS = [
    "priority",
    "primary_workstream",
    "workstreams",
    "pending_gates",
    "company",
    "ticker",
    "data_quality",
    "refinancing_gate",
    "evidence_status",
    "thesis_status",
    "approved_packet",
    "latest_event_date",
    "evidence_signal",
    "freshness_status",
    "hash_status",
    "latest_source_title",
    "latest_source_url",
    "latest_fact",
    "latest_interpretation",
    "latest_contrary_evidence",
    "latest_next_proof",
    "open_candidates",
    "high_open_candidates",
    "in_review_candidates",
    "next_action",
    "issues",
]


def _clean_text(value) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _upper(value) -> str:
    return _clean_text(value).upper()


def _to_int(value) -> int:
    try:
        return int(float(value or 0))
    except Exception:
        return 0


def _first_existing(columns: Iterable[str], options: Iterable[str]) -> str | None:
    cols = set(columns)
    for name in options:
        if name in cols:
            return name
    return None


def _latest_approved_by_company(evidence_packets: pd.DataFrame) -> pd.DataFrame:
    if evidence_packets is None or evidence_packets.empty:
        return pd.DataFrame()

    df = evidence_packets.copy()
    if "company" not in df.columns or "review_status" not in df.columns:
        return pd.DataFrame()

    approved = df.loc[
        df["review_status"].fillna("").astype(str).str.upper().eq("APPROVED")
    ].copy()
    if approved.empty:
        return pd.DataFrame()

    approved["_event_sort"] = pd.to_datetime(
        approved.get("event_date", pd.Series(index=approved.index, dtype=object)),
        errors="coerce",
    )
    approved["_created_sort"] = pd.to_datetime(
        approved.get("created_at", pd.Series(index=approved.index, dtype=object)),
        errors="coerce",
    )
    approved["_row_order"] = range(len(approved))
    approved = approved.sort_values(
        ["company", "_event_sort", "_created_sort", "_row_order"],
        ascending=[True, True, True, True],
        na_position="first",
    )
    return approved.drop_duplicates("company", keep="last")


def _candidate_rollup(source_candidates: pd.DataFrame) -> pd.DataFrame:
    empty = pd.DataFrame(
        columns=[
            "company",
            "open_candidates",
            "high_open_candidates",
            "in_review_candidates",
        ]
    )
    if source_candidates is None or source_candidates.empty:
        return empty

    df = source_candidates.copy()
    if "company" not in df.columns:
        return empty

    status_col = _first_existing(
        df.columns,
        ["candidate_status", "status", "review_status"],
    )
    priority_col = _first_existing(
        df.columns,
        ["monitor_priority", "priority", "review_priority"],
    )

    status = (
        df[status_col].fillna("").astype(str).str.upper()
        if status_col
        else pd.Series("", index=df.index, dtype=object)
    )
    priority = (
        df[priority_col].fillna("").astype(str).str.upper()
        if priority_col
        else pd.Series("", index=df.index, dtype=object)
    )

    is_open = status.isin(["NEW", "IN REVIEW"])
    is_in_review = status.eq("IN REVIEW")

    tmp = pd.DataFrame(
        {
            "company": df["company"].fillna("").astype(str).str.strip(),
            "open": is_open.astype(int),
            "high_open": (is_open & priority.eq("HIGH")).astype(int),
            "in_review": is_in_review.astype(int),
        }
    )
    tmp = tmp.loc[tmp["company"].ne("")]
    if tmp.empty:
        return empty

    return (
        tmp.groupby("company", as_index=False)
        .agg(
            open_candidates=("open", "sum"),
            high_open_candidates=("high_open", "sum"),
            in_review_candidates=("in_review", "sum"),
        )
    )


def _data_quality_lookup(data_quality: pd.DataFrame) -> pd.DataFrame:
    if data_quality is None or data_quality.empty:
        return pd.DataFrame(columns=["company", "data_quality", "dq_issues"])

    df = data_quality.copy()
    company_col = _first_existing(df.columns, ["name", "company", "asset"])
    status_col = _first_existing(
        df.columns,
        ["status", "audit_status", "data_quality", "gate_status"],
    )
    issues_col = _first_existing(
        df.columns,
        ["issues", "issue", "detail", "reason"],
    )

    if not company_col:
        return pd.DataFrame(columns=["company", "data_quality", "dq_issues"])

    out = pd.DataFrame()
    out["company"] = df[company_col].fillna("").astype(str).str.strip()
    out["data_quality"] = (
        df[status_col].fillna("").astype(str).str.upper()
        if status_col
        else ""
    )
    out["dq_issues"] = (
        df[issues_col].fillna("").astype(str)
        if issues_col
        else ""
    )
    out = out.loc[out["company"].ne("")]
    return out.drop_duplicates("company", keep="last")


def _packet_state(row: dict) -> tuple[str, list[str]]:
    issues: list[str] = []

    if _upper(row.get("approved_packet")) != "YES":
        issues.append("APPROVED Evidence Packet 없음")
        return "MISSING", issues

    hash_status = _upper(row.get("hash_status"))
    freshness = _upper(row.get("freshness_status"))

    if hash_status and hash_status not in {"OK", "PASS"}:
        issues.append(f"Evidence Hash {hash_status}")

    if freshness in {"OVERDUE", "STALE"}:
        issues.append(f"Evidence {freshness}")

    return ("REVIEW" if issues else "READY"), issues


def _workstreams_for_row(row: dict) -> list[str]:
    streams: list[str] = []

    dq = _upper(row.get("data_quality"))
    refi = _upper(row.get("refinancing_gate"))
    evidence = _upper(row.get("evidence_status"))
    approved = _upper(row.get("approved_packet"))
    freshness = _upper(row.get("freshness_status"))
    hash_status = _upper(row.get("hash_status"))
    open_count = _to_int(row.get("open_candidates"))
    high_open = _to_int(row.get("high_open_candidates"))

    if dq == "BLOCKED":
        streams.append("DATA_QUALITY_BLOCKED")
    elif dq == "REVIEW":
        streams.append("DATA_QUALITY_REVIEW")

    if approved != "YES":
        streams.append("MISSING_EVIDENCE_PACKET")
    else:
        if hash_status and hash_status not in {"OK", "PASS"}:
            streams.append("EVIDENCE_HASH")
        if freshness in {"OVERDUE", "STALE"}:
            streams.append("EVIDENCE_FRESHNESS")

    if refi != "PASS":
        streams.append("REFINANCING_REVIEW")

    if evidence not in {"PASS", "STRONG"}:
        streams.append("EVIDENCE_STATUS_REVIEW")

    if high_open > 0:
        streams.append("HIGH_DISCLOSURE")
    elif open_count > 0:
        streams.append("OPEN_DISCLOSURE")

    if not streams:
        streams.append("MONITOR")

    return streams


def _decision_for_row(row: dict) -> tuple[str, str, list[str]]:
    issues: list[str] = []

    dq = _upper(row.get("data_quality"))
    refi = _upper(row.get("refinancing_gate"))
    evidence = _upper(row.get("evidence_status"))
    thesis = _upper(row.get("thesis_status"))
    packet_state, packet_issues = _packet_state(row)
    issues.extend(packet_issues)

    open_count = _to_int(row.get("open_candidates"))
    high_open = _to_int(row.get("high_open_candidates"))

    dq_issues = _clean_text(row.get("dq_issues"))
    if dq_issues:
        issues.append(dq_issues)

    if dq == "BLOCKED":
        return "P0", "Data Quality BLOCKED 원인 확인", issues

    hash_status = _upper(row.get("hash_status"))
    if hash_status not in {"", "OK", "PASS"}:
        return "P0", "Evidence Hash 무결성 확인", issues

    if packet_state == "MISSING":
        return "P1", "Primary Source 확인 → Evidence Packet 생성", issues

    if _upper(row.get("freshness_status")) in {"OVERDUE", "STALE"}:
        return "P1", "Primary Source 재검토 → 새 Evidence Revision", issues

    if high_open > 0:
        return "P1", "HIGH Priority 신규 공시 Candidate 검토", issues

    if refi != "PASS":
        issues.append(f"refinancing_gate {refi or 'MISSING'}")
        return "P2", "Refinancing Gate 근거 검토", issues

    if evidence not in {"PASS", "STRONG"}:
        issues.append(f"evidence_status {evidence or 'MISSING'}")
        return "P2", "Evidence Status 사람 승인 검토", issues

    if thesis not in {"OK", "PASS", "INTACT"}:
        issues.append(f"thesis_status {thesis or 'MISSING'}")
        return "P2", "Thesis 상태 재검토", issues

    if dq == "REVIEW":
        return "P2", "Data Quality REVIEW 항목 확인", issues

    if open_count > 0:
        return "P3", "신규 공시 Candidate 검토", issues

    return "P4", "정기 모니터링", issues


def build_evidence_batch_queue(
    watchlist: pd.DataFrame,
    evidence_packets: pd.DataFrame,
    source_candidates: pd.DataFrame,
    data_quality: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """
    Human-review queue across Watchlist, Evidence Packets and DART candidates.

    Descriptive only:
    - never mutates Watchlist state
    - never approves Evidence
    - never changes Lifecycle / Add Freeze / Scenario / Portfolio
    """
    if watchlist is None or watchlist.empty or "name" not in watchlist.columns:
        return pd.DataFrame(columns=BATCH_QUEUE_COLS)

    base_cols = [
        c
        for c in [
            "name",
            "ticker",
            "refinancing_gate",
            "evidence_status",
            "thesis_status",
        ]
        if c in watchlist.columns
    ]
    base = watchlist[base_cols].copy()
    base["company"] = base["name"].fillna("").astype(str).str.strip()
    base = base.loc[base["company"].ne("")].drop_duplicates("company", keep="last")
    base = base.drop(columns=["name"], errors="ignore")

    for col in ["ticker", "refinancing_gate", "evidence_status", "thesis_status"]:
        if col not in base.columns:
            base[col] = ""

    latest = _latest_approved_by_company(evidence_packets)
    if latest.empty:
        packet_view = pd.DataFrame(columns=["company"])
    else:
        keep = [
            c
            for c in [
                "company",
                "event_date",
                "evidence_signal",
                "freshness_status",
                "hash_status",
                "source_title",
                "source_url",
                "fact",
                "interpretation",
                "contrary_evidence",
                "next_proof",
            ]
            if c in latest.columns
        ]
        packet_view = latest[keep].copy()
        packet_view = packet_view.rename(
            columns={
                "event_date": "latest_event_date",
                "source_title": "latest_source_title",
                "source_url": "latest_source_url",
                "fact": "latest_fact",
                "interpretation": "latest_interpretation",
                "contrary_evidence": "latest_contrary_evidence",
                "next_proof": "latest_next_proof",
            }
        )
        packet_view["approved_packet"] = "YES"

    out = base.merge(packet_view, on="company", how="left")
    out = out.merge(_candidate_rollup(source_candidates), on="company", how="left")
    out = out.merge(_data_quality_lookup(data_quality), on="company", how="left")

    for col in ["open_candidates", "high_open_candidates", "in_review_candidates"]:
        if col not in out.columns:
            out[col] = 0
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0).astype(int)

    text_cols = [
        "data_quality",
        "refinancing_gate",
        "evidence_status",
        "thesis_status",
        "approved_packet",
        "latest_event_date",
        "evidence_signal",
        "freshness_status",
        "hash_status",
        "latest_source_title",
        "latest_source_url",
        "latest_fact",
        "latest_interpretation",
        "latest_contrary_evidence",
        "latest_next_proof",
        "dq_issues",
    ]
    for col in text_cols:
        if col not in out.columns:
            out[col] = ""
        out[col] = out[col].fillna("").astype(str)

    out["approved_packet"] = out["approved_packet"].replace("", "NO")

    decisions = out.apply(lambda r: _decision_for_row(r.to_dict()), axis=1)
    out["priority"] = [x[0] for x in decisions]
    out["next_action"] = [x[1] for x in decisions]
    out["issues"] = [
        " | ".join(dict.fromkeys([i for i in x[2] if _clean_text(i)]))
        for x in decisions
    ]

    stream_lists = out.apply(
        lambda r: _workstreams_for_row(r.to_dict()),
        axis=1,
    )
    out["primary_workstream"] = [x[0] if x else "MONITOR" for x in stream_lists]
    out["workstreams"] = [" | ".join(x) for x in stream_lists]
    out["pending_gates"] = [
        len([s for s in x if s != "MONITOR"])
        for x in stream_lists
    ]

    priority_order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3, "P4": 4}
    out["_priority_sort"] = out["priority"].map(priority_order).fillna(9)
    out = out.sort_values(
        ["_priority_sort", "pending_gates", "high_open_candidates", "open_candidates", "company"],
        ascending=[True, False, False, False, True],
    ).drop(columns=["_priority_sort"], errors="ignore")

    for col in BATCH_QUEUE_COLS:
        if col not in out.columns:
            out[col] = ""

    return out[BATCH_QUEUE_COLS].reset_index(drop=True)


def evidence_batch_summary(queue: pd.DataFrame) -> dict:
    empty = {
        "total": 0,
        "action_needed": 0,
        "approved_missing": 0,
        "overdue_or_stale": 0,
        "open_candidates": 0,
        "high_open_candidates": 0,
        "high_open_companies": 0,
        "refinancing_review": 0,
        "evidence_status_review": 0,
        "data_quality_review": 0,
    }
    if queue is None or queue.empty:
        return empty

    priority = queue["priority"].fillna("").astype(str)
    approved = queue["approved_packet"].fillna("").astype(str).str.upper()
    freshness = queue["freshness_status"].fillna("").astype(str).str.upper()
    refi = queue["refinancing_gate"].fillna("").astype(str).str.upper()
    evidence = queue["evidence_status"].fillna("").astype(str).str.upper()
    dq = queue["data_quality"].fillna("").astype(str).str.upper()
    high = pd.to_numeric(queue["high_open_candidates"], errors="coerce").fillna(0)
    opened = pd.to_numeric(queue["open_candidates"], errors="coerce").fillna(0)

    return {
        "total": int(len(queue)),
        "action_needed": int(priority.isin(["P0", "P1", "P2", "P3"]).sum()),
        "approved_missing": int(approved.ne("YES").sum()),
        "overdue_or_stale": int(freshness.isin(["OVERDUE", "STALE"]).sum()),
        "open_candidates": int(opened.sum()),
        "high_open_candidates": int(high.sum()),
        "high_open_companies": int((high > 0).sum()),
        "refinancing_review": int(refi.ne("PASS").sum()),
        "evidence_status_review": int((~evidence.isin(["PASS", "STRONG"])).sum()),
        "data_quality_review": int(dq.isin(["REVIEW", "BLOCKED"]).sum()),
    }


def filter_evidence_batch_queue(queue: pd.DataFrame, lane: str) -> pd.DataFrame:
    if queue is None or queue.empty:
        return pd.DataFrame(columns=BATCH_QUEUE_COLS)

    q = queue.copy()
    lane = _upper(lane)

    if lane == "MISSING_PACKET":
        mask = q["approved_packet"].fillna("").astype(str).str.upper().ne("YES")
    elif lane == "REFINANCING":
        mask = q["refinancing_gate"].fillna("").astype(str).str.upper().ne("PASS")
    elif lane == "EVIDENCE_STATUS":
        mask = ~q["evidence_status"].fillna("").astype(str).str.upper().isin(["PASS", "STRONG"])
    elif lane == "HIGH_DISCLOSURE":
        mask = pd.to_numeric(q["high_open_candidates"], errors="coerce").fillna(0).gt(0)
    elif lane == "DATA_QUALITY":
        mask = q["data_quality"].fillna("").astype(str).str.upper().isin(["REVIEW", "BLOCKED"])
    elif lane == "ACTION_NEEDED":
        mask = q["priority"].fillna("").astype(str).isin(["P0", "P1", "P2", "P3"])
    else:
        mask = pd.Series(True, index=q.index)

    return q.loc[mask].reset_index(drop=True)


def company_open_candidates(
    source_candidates: pd.DataFrame,
    company: str,
    high_only: bool = False,
) -> pd.DataFrame:
    if source_candidates is None or source_candidates.empty:
        return pd.DataFrame()

    df = source_candidates.copy()
    if "company" not in df.columns:
        return pd.DataFrame()

    status_col = _first_existing(
        df.columns,
        ["candidate_status", "status", "review_status"],
    )
    if not status_col:
        return pd.DataFrame()

    company_mask = (
        df["company"].fillna("").astype(str).str.strip().eq(_clean_text(company))
    )
    status = df[status_col].fillna("").astype(str).str.upper()
    out = df.loc[company_mask & status.isin(["NEW", "IN REVIEW"])].copy()

    priority_col = _first_existing(
        out.columns,
        ["monitor_priority", "priority", "review_priority"],
    )
    if high_only and priority_col and not out.empty:
        out = out.loc[
            out[priority_col].fillna("").astype(str).str.upper().eq("HIGH")
        ].copy()

    date_col = _first_existing(out.columns, ["receipt_date", "event_date", "created_at"])
    if date_col and not out.empty:
        out["_date_sort"] = pd.to_datetime(out[date_col], errors="coerce")
        if priority_col:
            pmap = {"HIGH": 0, "MEDIUM": 1, "ROUTINE": 2}
            out["_priority_sort"] = (
                out[priority_col].fillna("").astype(str).str.upper().map(pmap).fillna(9)
            )
            out = out.sort_values(
                ["_priority_sort", "_date_sort"],
                ascending=[True, False],
                na_position="last",
            )
        else:
            out = out.sort_values("_date_sort", ascending=False, na_position="last")

    return out.drop(
        columns=["_date_sort", "_priority_sort"],
        errors="ignore",
    ).reset_index(drop=True)


def candidate_review_guide(candidate: dict) -> dict:
    """
    Deterministic review prompts from disclosure metadata only.

    Important:
    - This never treats a disclosure title as a Fact.
    - It does not generate investment conclusions.
    - It only suggests what the human reviewer should verify in the source.
    """
    candidate = candidate or {}
    title = _clean_text(candidate.get("report_name"))
    category = _upper(candidate.get("category"))
    title_upper = title.upper()

    periodic_keywords = [
        "사업보고서", "반기보고서", "분기보고서",
        "ANNUAL REPORT", "SEMI-ANNUAL", "QUARTERLY",
    ]
    earnings_keywords = [
        "잠정", "영업(잠정)", "매출액또는손익구조", "실적",
        "EARNINGS", "RESULT",
    ]
    financing_keywords = [
        "유상증자", "무상증자", "전환사채", "신주인수권부사채",
        "교환사채", "사채권", "차입", "증권신고서",
        "CAPITAL INCREASE", "CONVERTIBLE", "BOND",
    ]
    ownership_keywords = [
        "최대주주", "임원ㆍ주요주주", "주식등의대량보유",
        "소유상황", "지분", "OWNERSHIP", "HOLDING",
    ]
    contract_keywords = [
        "단일판매", "공급계약", "수주", "계약체결",
        "SUPPLY CONTRACT", "ORDER",
    ]
    ma_keywords = [
        "합병", "분할", "영업양수", "영업양도", "타법인주식",
        "M&A", "MERGER", "ACQUISITION",
    ]

    def has_any(words):
        return any(w.upper() in title_upper for w in words)

    if has_any(periodic_keywords):
        guide_type = "PERIODIC_FINANCIAL"
        questions = [
            "매출·영업이익의 기간 기준(당기/누적)과 전년동기 변화를 원문에서 확인",
            "CFO와 유형자산 취득(CAPEX)을 확인하고 FCF proxy가 재현되는지 확인",
            "현금·차입금·유동성장기부채·사채·리스부채와 만기 구조를 확인",
            "일회성 손익, 금융비용, 운전자본 변화가 현금흐름을 왜곡하는지 확인",
            "주석에서 covenant·우발채무·CAPEX 계획·주요 고객/사업 리스크를 확인",
        ]
        linked_kpi = "Revenue / Operating Profit / CFO / FCF / Net Cash / Debt / CAPEX"
        next_proof = "다음 분기·반기·사업보고서에서 Revenue/OP/CFO/FCF/CAPEX/Net Debt 재확인"
    elif has_any(earnings_keywords):
        guide_type = "EARNINGS_UPDATE"
        questions = [
            "공시된 매출·영업이익·순이익의 기준기간과 비교기간 확인",
            "가격/물량/믹스/환율 중 실적 변화의 직접 근거가 있는지 확인",
            "잠정치인지 확정치인지, 추후 정정 가능성이 있는지 확인",
            "현금흐름·CAPEX·운전자본 정보가 포함되지 않았다면 별도 Evidence로 분리",
        ]
        linked_kpi = "Revenue / Operating Profit / Margin"
        next_proof = "확정 재무제표에서 실적·CFO·CAPEX와 잠정치 차이 재확인"
    elif has_any(financing_keywords):
        guide_type = "FINANCING"
        questions = [
            "조달금액·발행조건·만기·금리·상환/전환 조건을 원문에서 확인",
            "기존 순현금/순부채와 Refinancing Gap에 미치는 영향을 확인",
            "잠재 희석(Net Share Count)과 자금 사용처를 확인",
            "조달 전후 이자부담·covenant·유동성 여유를 확인",
        ]
        linked_kpi = "Net Debt / Interest Cost / Debt Maturity / Net Share Count"
        next_proof = "납입·발행 완료 및 다음 재무제표에서 현금/부채/희석 효과 확인"
    elif has_any(contract_keywords):
        guide_type = "CONTRACT"
        questions = [
            "계약금액·기간·상대방·매출 대비 규모를 원문에서 확인",
            "해지/변경 조건과 실제 인식 시점을 확인",
            "수익성 또는 현금회수 조건이 공시되어 있는지 확인",
            "단일 계약을 장기 Runway로 과대해석하지 않는지 점검",
        ]
        linked_kpi = "Order / Revenue / Margin / Cash Collection"
        next_proof = "후속 매출 인식·계약 변경·현금회수 공시 또는 다음 실적에서 확인"
    elif has_any(ma_keywords):
        guide_type = "M_AND_A"
        questions = [
            "거래가격·대상 지분·지급수단·완료조건을 원문에서 확인",
            "인수 후 순부채·희석·현금소진 영향을 확인",
            "시너지 주장은 Fact와 분리하고 Break-even 가정을 별도로 기록",
            "No-deal 대안 대비 자본배분의 경제성을 점검",
        ]
        linked_kpi = "Purchase Price / Net Debt / Acquisition iROIC / Synergy"
        next_proof = "거래 종결·연결 반영 후 실제 현금흐름과 인수 iROIC 재검증"
    elif has_any(ownership_keywords):
        guide_type = "OWNERSHIP"
        questions = [
            "변동 주체·변동 주식수·변동 후 지분율과 목적을 원문에서 확인",
            "경영권·오버행·유통주식수에 실제 영향이 있는지 확인",
            "사업/현금흐름 변화와 직접 연결되는 Evidence인지 분리 판단",
        ]
        linked_kpi = "Ownership / Net Share Count"
        next_proof = "추가 지분 변동 또는 다음 주식수/자본변동 공시 확인"
    else:
        guide_type = category or "GENERAL_DISCLOSURE"
        questions = [
            "공시 제목이 아니라 원문에서 확인되는 구체적 사실·수치·날짜를 추출",
            "이번 공시가 Revenue/Margin/FCF/Balance Sheet/Thesis 중 무엇을 실제로 바꾸는지 확인",
            "현재 해석과 반대되는 설명 또는 누락된 조건을 최소 1개 기록",
            "다음에 무엇을 확인해야 이 해석을 검증/반박할 수 있는지 정의",
        ]
        linked_kpi = ""
        next_proof = "다음 Primary Source에서 핵심 Fact와 가설 영향 재확인"

    return {
        "guide_type": guide_type,
        "scope": "REVIEW_PROMPTS_ONLY",
        "source_title": title,
        "category": category,
        "review_questions": questions,
        "linked_kpi_suggestion": linked_kpi,
        "next_proof_suggestion": next_proof,
        "warning": (
            "공시 제목/카테고리만으로 Fact를 생성하지 않습니다. "
            "아래 항목은 원문에서 무엇을 확인할지 안내하는 검토 템플릿입니다."
        ),
    }


def evidence_text_diff(previous, current) -> dict:
    """
    Deterministic text delta only.

    It does not infer whether a change is good/bad or investment-relevant.
    Empty current draft is treated as NOT_STARTED, not as deletion.
    """
    prev = _clean_text(previous)
    curr = _clean_text(current)

    if not curr:
        return {
            "status": "NOT_STARTED",
            "similarity_pct": None,
            "added": "",
            "removed": "",
        }
    if not prev:
        return {
            "status": "NEW",
            "similarity_pct": 0.0,
            "added": curr,
            "removed": "",
        }
    if prev == curr:
        return {
            "status": "UNCHANGED",
            "similarity_pct": 100.0,
            "added": "",
            "removed": "",
        }

    prev_tokens = prev.split()
    curr_tokens = curr.split()
    matcher = SequenceMatcher(None, prev_tokens, curr_tokens)

    added_parts = []
    removed_parts = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag in {"insert", "replace"} and j1 != j2:
            added_parts.append(" ".join(curr_tokens[j1:j2]))
        if tag in {"delete", "replace"} and i1 != i2:
            removed_parts.append(" ".join(prev_tokens[i1:i2]))

    return {
        "status": "CHANGED",
        "similarity_pct": round(matcher.ratio() * 100.0, 1),
        "added": " | ".join([x for x in added_parts if x]),
        "removed": " | ".join([x for x in removed_parts if x]),
    }


def build_evidence_diff(previous_packet: dict | None, current_packet: dict) -> dict:
    """
    Compare a human-reviewed current draft with the latest APPROVED packet.

    This is a descriptive audit helper:
    - no source text is invented
    - no signal is upgraded/downgraded automatically
    - no Watchlist/Portfolio state is changed
    """
    previous = previous_packet or {}
    current = current_packet or {}

    field_map = [
        ("Fact", "fact_summary"),
        ("Interpretation", "investment_interpretation"),
        ("Contrary Evidence", "contrary_evidence"),
        ("Linked KPI", "linked_kpi"),
        ("Next Proof", "next_proof"),
    ]

    rows = []
    details = {}
    for label, key in field_map:
        result = evidence_text_diff(previous.get(key, ""), current.get(key, ""))
        rows.append(
            {
                "field": label,
                "status": result["status"],
                "similarity_pct": result["similarity_pct"],
            }
        )
        details[label] = result

    metadata = []
    for label, key in [
        ("Event Date", "event_date"),
        ("Source Title", "source_title"),
        ("Evidence Signal", "evidence_signal"),
    ]:
        prev = _clean_text(previous.get(key, ""))
        curr = _clean_text(current.get(key, ""))
        if not curr:
            status = "NOT_STARTED"
        elif not prev:
            status = "NEW"
        elif prev == curr:
            status = "UNCHANGED"
        else:
            status = "CHANGED"
        metadata.append(
            {
                "field": label,
                "previous": prev,
                "current": curr,
                "status": status,
            }
        )

    started_rows = [r for r in rows if r["status"] != "NOT_STARTED"]
    changed_rows = [
        r for r in rows if r["status"] in {"NEW", "CHANGED"}
    ]

    return {
        "baseline_available": bool(previous),
        "summary": pd.DataFrame(rows),
        "metadata": pd.DataFrame(metadata),
        "details": details,
        "started_fields": len(started_rows),
        "changed_fields": len(changed_rows),
        "warning": (
            "Diff는 이전 APPROVED Evidence와 현재 사람이 입력한 Draft의 문자 차이만 보여줍니다. "
            "변경의 투자적 의미나 중요도를 자동 판단하지 않습니다."
        ),
    }


def previous_approved_packet(
    evidence_packets: pd.DataFrame,
    company: str,
    latest_evidence_id: str = "",
) -> dict:
    """
    Return the APPROVED packet immediately before the current/latest one.

    Sorting uses event_date, created_at and original row order.
    This helper is descriptive only and never mutates evidence data.
    """
    if evidence_packets is None or evidence_packets.empty:
        return {}
    if "company" not in evidence_packets.columns or "review_status" not in evidence_packets.columns:
        return {}

    df = evidence_packets.copy()
    mask = (
        df["company"].fillna("").astype(str).str.strip().eq(_clean_text(company))
        & df["review_status"].fillna("").astype(str).str.upper().eq("APPROVED")
    )
    df = df.loc[mask].copy()
    if df.empty:
        return {}

    df["_event_sort"] = pd.to_datetime(
        df.get("event_date", pd.Series(index=df.index, dtype=object)),
        errors="coerce",
    )
    df["_created_sort"] = pd.to_datetime(
        df.get("created_at", pd.Series(index=df.index, dtype=object)),
        errors="coerce",
    )
    df["_row_order"] = range(len(df))
    df = df.sort_values(
        ["_event_sort", "_created_sort", "_row_order"],
        ascending=[True, True, True],
        na_position="first",
    )

    latest_id = _clean_text(latest_evidence_id)
    if latest_id and "evidence_id" in df.columns:
        latest_matches = df["evidence_id"].fillna("").astype(str).eq(latest_id)
        if latest_matches.any():
            latest_pos = df.index.get_loc(df.index[latest_matches][-1])
            if latest_pos <= 0:
                return {}
            return df.iloc[latest_pos - 1].drop(
                labels=["_event_sort", "_created_sort", "_row_order"],
                errors="ignore",
            ).to_dict()

    if len(df) < 2:
        return {}

    return df.iloc[-2].drop(
        labels=["_event_sort", "_created_sort", "_row_order"],
        errors="ignore",
    ).to_dict()
