from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN

import pandas as pd


CAPITAL_PRODUCTIVITY_INPUT_COLS = [
    "name",
    "ticker",
    "kind",
    "forward_er",
    "risk_penalty",
    "hurdle_rate",
    "capacity_headroom_krw",
    "reviewed",
    "source",
    "review_due_date",
    "note",
    "updated_at",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE",
        "1",
        "YES",
        "Y",
        "PASS",
    }


def normalize_capital_productivity_inputs(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in CAPITAL_PRODUCTIVITY_INPUT_COLS:
        if col not in out.columns:
            out[col] = ""

    for col in [
        "name",
        "ticker",
        "kind",
        "source",
        "note",
        "updated_at",
    ]:
        out[col] = out[col].map(_text).astype("object")

    # Streamlit DateColumn requires a date/datetime-compatible dtype.
    # Empty CSV columns are otherwise often inferred as float/object.
    out["review_due_date"] = pd.to_datetime(
        out["review_due_date"],
        errors="coerce",
    )

    for col in [
        "forward_er",
        "risk_penalty",
        "hurdle_rate",
        "capacity_headroom_krw",
    ]:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )

    out["reviewed"] = out["reviewed"].map(_bool).astype(bool)

    return out[CAPITAL_PRODUCTIVITY_INPUT_COLS].copy()


def capital_productivity_universe(
    portfolio: pd.DataFrame | None,
    watchlist: pd.DataFrame | None,
    inputs: pd.DataFrame | None,
    total_assets: float,
    *,
    today: date | None = None,
) -> pd.DataFrame:
    """
    Build a unified capital competition universe.

    Holdings take precedence over Watchlist duplicates.
    Cash is always included as a comparison reference.

    READY means the user's forward assumptions are source-backed, reviewed and
    not expired. READY is not an investment recommendation.
    """
    current_date = today or date.today()
    total = max(0.0, float(total_assets or 0.0))
    saved = normalize_capital_productivity_inputs(inputs)

    rows: list[dict] = []

    # Cash reference.
    rows.append(
        {
            "name": "현금 (CASH)",
            "ticker": "",
            "kind": "CASH",
            "current_value_krw": 0.0,
            "portfolio_weight": 0.0,
            "watchlist_required_return": 0.0,
        }
    )

    if portfolio is not None and not portfolio.empty:
        p = portfolio.copy()
        for col in [
            "name",
            "ticker",
            "asset_type",
            "current_value_krw",
        ]:
            if col not in p.columns:
                p[col] = ""

        p["name"] = p["name"].map(_text)
        p["ticker"] = p["ticker"].map(_text)
        p["asset_type"] = (
            p["asset_type"]
            .fillna("")
            .astype(str)
            .str.lower()
        )
        p["current_value_krw"] = pd.to_numeric(
            p["current_value_krw"],
            errors="coerce",
        ).fillna(0.0).clip(lower=0.0)

        for _, row in p.iterrows():
            name = _text(row.get("name"))
            asset_type = _text(row.get("asset_type")).lower()
            if (
                not name
                or asset_type == "cash"
                or name.lower() in {"cash", "현금"}
            ):
                # Fold actual cash into the Cash reference.
                if (
                    asset_type == "cash"
                    or name.lower() in {"cash", "현금"}
                ):
                    rows[0]["current_value_krw"] += float(
                        row.get("current_value_krw", 0.0)
                        or 0.0
                    )
                continue

            value = float(
                row.get("current_value_krw", 0.0)
                or 0.0
            )
            rows.append(
                {
                    "name": name,
                    "ticker": _text(row.get("ticker")),
                    "kind": "HOLDING",
                    "current_value_krw": value,
                    "portfolio_weight": (
                        value / total
                        if total > 0
                        else 0.0
                    ),
                    "watchlist_required_return": None,
                }
            )

    # Watchlist metadata + candidates.
    watch_required = {}
    if watchlist is not None and not watchlist.empty:
        w = watchlist.copy()
        for col in [
            "name",
            "ticker",
            "required_return",
        ]:
            if col not in w.columns:
                w[col] = ""

        w["name"] = w["name"].map(_text)
        w["ticker"] = w["ticker"].map(_text)
        w["required_return"] = pd.to_numeric(
            w["required_return"],
            errors="coerce",
        )

        for _, row in w.iterrows():
            name = _text(row.get("name"))
            if not name:
                continue
            watch_required[name] = _num(
                row.get("required_return")
            )

        existing_names = {
            _text(row["name"])
            for row in rows
        }
        for _, row in w.iterrows():
            name = _text(row.get("name"))
            if not name or name in existing_names:
                continue

            rows.append(
                {
                    "name": name,
                    "ticker": _text(row.get("ticker")),
                    "kind": "WATCHLIST",
                    "current_value_krw": 0.0,
                    "portfolio_weight": 0.0,
                    "watchlist_required_return": _num(
                        row.get("required_return")
                    ),
                }
            )
            existing_names.add(name)

    # Fill holding watchlist hurdle metadata when available.
    for row in rows:
        if row["kind"] == "HOLDING":
            row["watchlist_required_return"] = watch_required.get(
                row["name"]
            )

    universe = pd.DataFrame(rows)

    if universe.empty:
        return universe

    # Merge saved assumptions by name+ticker, falling back to name.
    saved_lookup: dict[tuple[str, str], dict] = {}
    saved_name_lookup: dict[str, dict] = {}

    for _, srow in saved.iterrows():
        sdict = srow.to_dict()
        key = (
            _text(sdict.get("name")),
            _text(sdict.get("ticker")),
        )
        saved_lookup[key] = sdict
        saved_name_lookup[
            _text(sdict.get("name"))
        ] = sdict

    enriched = []
    for _, row in universe.iterrows():
        r = row.to_dict()
        name = _text(r.get("name"))
        ticker = _text(r.get("ticker"))
        saved_row = saved_lookup.get(
            (name, ticker)
        ) or saved_name_lookup.get(name) or {}

        kind = _text(r.get("kind")).upper()

        forward_er = _num(
            saved_row.get("forward_er")
        )
        risk_penalty = _num(
            saved_row.get("risk_penalty")
        )
        hurdle_rate = _num(
            saved_row.get("hurdle_rate")
        )

        if hurdle_rate is None:
            if kind == "CASH":
                hurdle_rate = 0.0
            else:
                hurdle_rate = _num(
                    r.get("watchlist_required_return")
                )

        capacity = _num(
            saved_row.get("capacity_headroom_krw")
        )
        reviewed = _bool(
            saved_row.get("reviewed")
        )
        source = _text(
            saved_row.get("source")
        )
        raw_review_due = saved_row.get(
            "review_due_date"
        )
        parsed_review_due = pd.to_datetime(
            raw_review_due,
            errors="coerce",
        )
        review_due_date = (
            pd.NaT
            if pd.isna(parsed_review_due)
            else parsed_review_due
        )
        note = _text(
            saved_row.get("note")
        )

        issues = []

        if forward_er is None:
            issues.append("FORWARD_ER_REQUIRED")
        if risk_penalty is None:
            issues.append("RISK_PENALTY_REQUIRED")
        if hurdle_rate is None:
            issues.append("HURDLE_RATE_REQUIRED")
        if not source:
            issues.append("SOURCE_REQUIRED")
        if not reviewed:
            issues.append("HUMAN_REVIEW_REQUIRED")

        due = None
        if not pd.isna(
            review_due_date
        ):
            due = pd.Timestamp(
                review_due_date
            ).date()

        if due is None:
            issues.append("REVIEW_DUE_DATE_REQUIRED")
            review_clock = "REVIEW"
        elif due < current_date:
            issues.append("REVIEW_EXPIRED")
            review_clock = "EXPIRED"
        else:
            review_clock = "PASS"

        risk_adjusted_er = (
            forward_er - risk_penalty
            if (
                forward_er is not None
                and risk_penalty is not None
            )
            else None
        )
        hurdle_spread = (
            risk_adjusted_er - hurdle_rate
            if (
                risk_adjusted_er is not None
                and hurdle_rate is not None
            )
            else None
        )

        input_status = (
            "READY"
            if not issues
            else "REVIEW"
        )

        enriched.append(
            {
                **r,
                "forward_er": forward_er,
                "risk_penalty": risk_penalty,
                "hurdle_rate": hurdle_rate,
                "risk_adjusted_er": risk_adjusted_er,
                "hurdle_spread": hurdle_spread,
                "capacity_headroom_krw": capacity,
                "reviewed": reviewed,
                "source": source,
                "review_due_date": review_due_date,
                "review_clock": review_clock,
                "note": note,
                "input_status": input_status,
                "issues": " | ".join(issues),
            }
        )

    return pd.DataFrame(enriched)


def capital_productivity_save_rows(
    edited: pd.DataFrame,
) -> pd.DataFrame:
    out = normalize_capital_productivity_inputs(
        edited
    )
    out["updated_at"] = datetime.now().isoformat()
    return out


def capital_competition_table(
    universe: pd.DataFrame | None,
    donor_name: str,
    comparison_amount_krw: float,
    *,
    tax_cost_rate: float = 0.0,
    trading_cost_rate: float = 0.0,
    minimum_switching_gap: float = 0.0,
) -> pd.DataFrame:
    """
    Pairwise next-capital diagnostic.

    Net Switching Gap =
        Recipient risk-adjusted ER
        - Donor risk-adjusted ER
        - Tax Cost
        - Trading Cost

    Recipient qualification also requires:
    - source-backed READY assumptions
    - positive hurdle spread
    - sufficient capacity headroom (Cash exempt)

    This table does not authorize capital movement.
    """
    if universe is None or universe.empty:
        return pd.DataFrame()

    amount = max(
        0.0,
        float(
            comparison_amount_krw
            or 0.0
        ),
    )
    tax = max(
        0.0,
        float(
            tax_cost_rate
            or 0.0
        ),
    )
    trading = max(
        0.0,
        float(
            trading_cost_rate
            or 0.0
        ),
    )
    min_gap = float(
        minimum_switching_gap
        or 0.0
    )

    df = universe.copy()
    donor_hit = df.loc[
        df["name"]
        .fillna("")
        .astype(str)
        .eq(_text(donor_name))
    ]

    if donor_hit.empty:
        return pd.DataFrame()

    donor = donor_hit.iloc[0].to_dict()
    donor_ready = _text(
        donor.get("input_status")
    ).upper() == "READY"
    donor_ra_er = _num(
        donor.get("risk_adjusted_er")
    )

    rows = []
    for _, row in df.iterrows():
        recipient_name = _text(
            row.get("name")
        )
        if recipient_name == _text(donor_name):
            continue

        recipient_kind = _text(
            row.get("kind")
        ).upper()
        recipient_ready = _text(
            row.get("input_status")
        ).upper() == "READY"
        recipient_ra_er = _num(
            row.get("risk_adjusted_er")
        )
        hurdle_spread = _num(
            row.get("hurdle_spread")
        )
        capacity = _num(
            row.get("capacity_headroom_krw")
        )

        issues = []

        donor_gate = (
            "PASS"
            if donor_ready
            and donor_ra_er is not None
            else "REVIEW"
        )
        if donor_gate != "PASS":
            issues.append("DONOR_INPUT_REVIEW")

        input_gate = (
            "PASS"
            if recipient_ready
            and recipient_ra_er is not None
            else "REVIEW"
        )
        if input_gate != "PASS":
            issues.append("RECIPIENT_INPUT_REVIEW")

        if hurdle_spread is None:
            hurdle_gate = "REVIEW"
            issues.append("RECIPIENT_HURDLE_REVIEW")
        elif hurdle_spread >= 0:
            hurdle_gate = "PASS"
        else:
            hurdle_gate = "BLOCKED"
            issues.append("RECIPIENT_HURDLE_BELOW_ZERO")

        if recipient_kind == "CASH":
            capacity_gate = "PASS"
            effective_capacity = None
        elif capacity is None:
            capacity_gate = "REVIEW"
            effective_capacity = None
            issues.append("RECIPIENT_CAPACITY_REVIEW")
        elif amount <= capacity + 1e-9:
            capacity_gate = "PASS"
            effective_capacity = capacity
        else:
            capacity_gate = "BLOCKED"
            effective_capacity = capacity
            issues.append("RECIPIENT_CAPACITY_INSUFFICIENT")

        net_gap = None
        if (
            donor_ra_er is not None
            and recipient_ra_er is not None
        ):
            net_gap = (
                recipient_ra_er
                - donor_ra_er
                - tax
                - trading
            )

        if net_gap is None:
            switching_gate = "REVIEW"
            issues.append("SWITCHING_GAP_REVIEW")
        elif net_gap >= min_gap:
            switching_gate = "PASS"
        else:
            switching_gate = "BLOCKED"
            issues.append("SWITCHING_GAP_BELOW_HURDLE")

        if (
            donor_gate == "PASS"
            and input_gate == "PASS"
            and hurdle_gate == "PASS"
            and capacity_gate == "PASS"
            and switching_gate == "PASS"
        ):
            comparison_status = "QUALIFIED"
        elif (
            "BLOCKED"
            in {
                hurdle_gate,
                capacity_gate,
                switching_gate,
            }
        ):
            comparison_status = "BLOCKED"
        else:
            comparison_status = "REVIEW"

        rows.append(
            {
                "donor": _text(donor_name),
                "recipient": recipient_name,
                "recipient_kind": recipient_kind,
                "comparison_amount_krw": amount,
                "donor_risk_adjusted_er": donor_ra_er,
                "recipient_forward_er": _num(
                    row.get("forward_er")
                ),
                "recipient_risk_penalty": _num(
                    row.get("risk_penalty")
                ),
                "recipient_risk_adjusted_er": recipient_ra_er,
                "recipient_hurdle_rate": _num(
                    row.get("hurdle_rate")
                ),
                "recipient_hurdle_spread": hurdle_spread,
                "tax_cost_rate": tax,
                "trading_cost_rate": trading,
                "net_switching_gap": net_gap,
                "recipient_capacity_headroom_krw": effective_capacity,
                "donor_gate": donor_gate,
                "input_gate": input_gate,
                "hurdle_gate": hurdle_gate,
                "capacity_gate": capacity_gate,
                "switching_gate": switching_gate,
                "comparison_status": comparison_status,
                "issues": " | ".join(issues),
            }
        )

    out = pd.DataFrame(rows)
    if out.empty:
        return out

    status_order = {
        "QUALIFIED": 0,
        "REVIEW": 1,
        "BLOCKED": 2,
    }
    out["_status_order"] = out[
        "comparison_status"
    ].map(
        status_order
    ).fillna(9)

    out = (
        out.sort_values(
            [
                "_status_order",
                "net_switching_gap",
            ],
            ascending=[
                True,
                False,
            ],
            na_position="last",
        )
        .drop(
            columns=["_status_order"]
        )
        .reset_index(drop=True)
    )

    return out


def capital_competition_summary(
    universe: pd.DataFrame | None,
    competition: pd.DataFrame | None,
) -> dict:
    ready_inputs = 0
    total_inputs = 0

    if universe is not None and not universe.empty:
        total_inputs = int(
            len(universe)
        )
        ready_inputs = int(
            universe["input_status"]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq("READY")
            .sum()
        )

    qualified = 0
    review = 0
    blocked = 0

    if competition is not None and not competition.empty:
        status = (
            competition[
                "comparison_status"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
        )
        qualified = int(
            status.eq("QUALIFIED").sum()
        )
        review = int(
            status.eq("REVIEW").sum()
        )
        blocked = int(
            status.eq("BLOCKED").sum()
        )

    return {
        "ready_inputs": ready_inputs,
        "total_inputs": total_inputs,
        "qualified_recipients": qualified,
        "review_recipients": review,
        "blocked_recipients": blocked,
    }


CAPITAL_PRODUCTIVITY_ASSIST_COLS = [
    "name",
    "ticker",
    "kind",
    "hurdle_reference",
    "hurdle_source",
    "fcf_yield_reference",
    "fundamental_reference",
    "fundamental_review_status",
    "evidence_status",
    "evidence_source_count",
    "latest_evidence_source",
    "lifecycle",
    "add_freeze",
    "capacity_reference_krw",
    "capacity_source",
    "missing_assumptions",
    "assist_status",
    "assist_issues",
]


def _first_existing(
    row: dict,
    candidates: list[str],
) -> Any:
    for key in candidates:
        if key in row:
            value = row.get(key)
            if _text(value) or _num(value) is not None:
                return value
    return None


def capital_productivity_source_assist(
    universe: pd.DataFrame | None,
    watchlist: pd.DataFrame | None,
    state_df: pd.DataFrame | None,
    audit_evidence: pd.DataFrame | None,
    fundamental_snapshots: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Source-backed assist only.

    This function never proposes Forward ER or Risk Penalty.
    It surfaces references already present elsewhere in the system:
    - Hurdle reference from Watchlist required_return
    - FCF yield reference from Watchlist normalized_fcf_yield
    - Fundamental snapshot period / review status
    - Evidence source presence
    - Lifecycle / Add Freeze
    - Capacity reference from existing state output when available

    Assist values are inputs for human review, not automatic assumptions.
    """
    if universe is None or universe.empty:
        return pd.DataFrame(
            columns=CAPITAL_PRODUCTIVITY_ASSIST_COLS
        )

    w = (
        watchlist.copy()
        if watchlist is not None
        else pd.DataFrame()
    )
    s = (
        state_df.copy()
        if state_df is not None
        else pd.DataFrame()
    )
    ev = (
        audit_evidence.copy()
        if audit_evidence is not None
        else pd.DataFrame()
    )
    fs = (
        fundamental_snapshots.copy()
        if fundamental_snapshots is not None
        else pd.DataFrame()
    )

    def _lookup_by_name(
        df: pd.DataFrame,
        name: str,
    ) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame()
        for col in [
            "name",
            "company",
        ]:
            if col in df.columns:
                return df.loc[
                    df[col]
                    .fillna("")
                    .astype(str)
                    .str.strip()
                    .eq(name)
                ].copy()
        return pd.DataFrame()

    rows = []

    for _, urow in universe.iterrows():
        u = urow.to_dict()
        name = _text(u.get("name"))
        ticker = _text(u.get("ticker"))
        kind = _text(u.get("kind")).upper()

        hurdle_reference = None
        hurdle_source = ""
        fcf_yield_reference = None
        fundamental_reference = ""
        fundamental_review_status = ""
        evidence_status = ""
        evidence_source_count = 0
        latest_evidence_source = ""
        lifecycle = ""
        add_freeze = ""
        capacity_reference = None
        capacity_source = ""
        issues = []

        if kind == "CASH":
            hurdle_reference = 0.0
            hurdle_source = "CASH_REFERENCE_0"
            lifecycle = "CASH"
            add_freeze = "OFF"
            evidence_status = "POLICY_EXEMPT"

        wh = _lookup_by_name(
            w,
            name,
        )
        if not wh.empty:
            wr = wh.iloc[-1].to_dict()

            required = _num(
                wr.get("required_return")
            )
            if required is not None:
                hurdle_reference = required
                hurdle_source = "WATCHLIST_REQUIRED_RETURN"

            fcf_yield_reference = _num(
                wr.get("normalized_fcf_yield")
            )

            if not evidence_status:
                evidence_status = _text(
                    wr.get("evidence_status")
                ).upper()

        sh = _lookup_by_name(
            s,
            name,
        )
        if not sh.empty:
            sr = sh.iloc[-1].to_dict()

            lifecycle = _text(
                _first_existing(
                    sr,
                    [
                        "lifecycle_state",
                        "lifecycle",
                    ],
                )
            ).upper()

            add_freeze = _text(
                _first_existing(
                    sr,
                    [
                        "add_freeze",
                        "add_freeze_status",
                    ],
                )
            ).upper()

            max_add_shares = _num(
                _first_existing(
                    sr,
                    [
                        "portfolio_max_add_shares",
                        "executable_shares",
                    ],
                )
            )
            price = _num(
                _first_existing(
                    sr,
                    [
                        "price",
                        "current_price",
                    ],
                )
            )

            if (
                max_add_shares is not None
                and max_add_shares >= 0
                and price is not None
                and price > 0
            ):
                capacity_reference = (
                    max_add_shares
                    * price
                )
                capacity_source = (
                    "STATE_PORTFOLIO_MAX_ADD_SHARES_X_PRICE"
                )

        eh = _lookup_by_name(
            ev,
            name,
        )
        if not eh.empty:
            if "source_url" in eh.columns:
                valid = eh.loc[
                    eh["source_url"]
                    .fillna("")
                    .astype(str)
                    .str.strip()
                    .ne("")
                ].copy()
            else:
                valid = pd.DataFrame()

            evidence_source_count = int(
                len(valid)
            )

            if not valid.empty:
                latest = valid.iloc[-1].to_dict()
                title = _text(
                    latest.get("source_title")
                )
                url = _text(
                    latest.get("source_url")
                )
                latest_evidence_source = (
                    title
                    or url
                )
                if evidence_status in {
                    "",
                    "PROVISIONAL",
                    "REVIEW",
                }:
                    evidence_status = "SOURCE_PRESENT"

        fh = _lookup_by_name(
            fs,
            name,
        )
        if not fh.empty:
            # Prefer reviewed rows if the column exists.
            if "review_status" in fh.columns:
                reviewed_mask = (
                    fh["review_status"]
                    .fillna("")
                    .astype(str)
                    .str.upper()
                    .isin(
                        [
                            "REVIEWED",
                            "APPROVED",
                            "PASS",
                        ]
                    )
                )
                if reviewed_mask.any():
                    fh = fh.loc[
                        reviewed_mask
                    ].copy()

            fr = fh.iloc[-1].to_dict()
            year = _text(
                _first_existing(
                    fr,
                    [
                        "source_business_year",
                        "business_year",
                    ],
                )
            )
            period = _text(
                _first_existing(
                    fr,
                    [
                        "source_period",
                        "period",
                    ],
                )
            )
            fundamental_reference = " ".join(
                [
                    x
                    for x in [
                        year,
                        period,
                    ]
                    if x
                ]
            ).strip()
            fundamental_review_status = _text(
                _first_existing(
                    fr,
                    [
                        "review_status",
                        "hash_status",
                    ],
                )
            ).upper()

        missing = []
        for field, label in [
            (
                u.get("forward_er"),
                "Forward ER",
            ),
            (
                u.get("risk_penalty"),
                "Risk Penalty",
            ),
            (
                u.get("hurdle_rate"),
                "Hurdle",
            ),
        ]:
            if _num(field) is None:
                missing.append(label)

        if (
            kind != "CASH"
            and _num(
                u.get(
                    "capacity_headroom_krw"
                )
            )
            is None
        ):
            missing.append("Capacity")

        if hurdle_reference is None:
            issues.append(
                "HURDLE_REFERENCE_MISSING"
            )
        if (
            kind != "CASH"
            and not latest_evidence_source
        ):
            issues.append(
                "EVIDENCE_SOURCE_MISSING"
            )
        if (
            kind in {
                "HOLDING",
                "WATCHLIST",
            }
            and not lifecycle
        ):
            issues.append(
                "LIFECYCLE_MISSING"
            )

        if kind != "CASH" and capacity_reference is None:
            issues.append(
                "CAPACITY_REFERENCE_MISSING"
            )

        # Source Assist can be useful even when incomplete.
        assist_status = (
            "SOURCE_READY"
            if (
                hurdle_reference is not None
                and (
                    kind == "CASH"
                    or latest_evidence_source
                )
            )
            else "REVIEW"
        )

        rows.append(
            {
                "name": name,
                "ticker": ticker,
                "kind": kind,
                "hurdle_reference": hurdle_reference,
                "hurdle_source": hurdle_source,
                "fcf_yield_reference": fcf_yield_reference,
                "fundamental_reference": fundamental_reference,
                "fundamental_review_status": fundamental_review_status,
                "evidence_status": evidence_status,
                "evidence_source_count": evidence_source_count,
                "latest_evidence_source": latest_evidence_source,
                "lifecycle": lifecycle,
                "add_freeze": add_freeze,
                "capacity_reference_krw": capacity_reference,
                "capacity_source": capacity_source,
                "missing_assumptions": " / ".join(
                    missing
                ),
                "assist_status": assist_status,
                "assist_issues": " | ".join(
                    issues
                ),
            }
        )

    return pd.DataFrame(
        rows,
        columns=CAPITAL_PRODUCTIVITY_ASSIST_COLS,
    )


def apply_capital_productivity_source_assist(
    inputs: pd.DataFrame | None,
    assist: pd.DataFrame | None,
    target_names: list[str],
) -> tuple[pd.DataFrame, int]:
    """
    Copy only source-backed Hurdle / Capacity / Source references.

    NEVER auto-fills:
    - Forward ER
    - Risk Penalty
    - Reviewed
    - Review Due Date

    Existing user values are preserved.
    """
    current = normalize_capital_productivity_inputs(
        inputs
    )

    if assist is None or assist.empty:
        return current, 0

    targets = {
        _text(x)
        for x in target_names
        if _text(x)
    }
    if not targets:
        return current, 0

    # Ensure a row exists for each selected assist target.
    rows = current.to_dict(
        orient="records"
    )
    by_name = {
        _text(row.get("name")): i
        for i, row in enumerate(rows)
    }

    applied = 0

    for _, arow in assist.iterrows():
        a = arow.to_dict()
        name = _text(
            a.get("name")
        )
        if name not in targets:
            continue

        if name in by_name:
            idx = by_name[name]
            row = rows[idx]
        else:
            row = {
                col: ""
                for col in CAPITAL_PRODUCTIVITY_INPUT_COLS
            }
            row["name"] = name
            row["ticker"] = _text(
                a.get("ticker")
            )
            row["kind"] = _text(
                a.get("kind")
            )
            rows.append(row)
            idx = len(rows) - 1
            by_name[name] = idx

        changed = False

        hurdle_ref = _num(
            a.get("hurdle_reference")
        )
        if (
            _num(
                row.get("hurdle_rate")
            )
            is None
            and hurdle_ref is not None
        ):
            row["hurdle_rate"] = hurdle_ref
            changed = True

        capacity_ref = _num(
            a.get(
                "capacity_reference_krw"
            )
        )
        if (
            _num(
                row.get(
                    "capacity_headroom_krw"
                )
            )
            is None
            and capacity_ref is not None
        ):
            row[
                "capacity_headroom_krw"
            ] = capacity_ref
            changed = True

        source_parts = []
        hurdle_source = _text(
            a.get("hurdle_source")
        )
        latest_evidence = _text(
            a.get("latest_evidence_source")
        )
        fundamental_reference = _text(
            a.get("fundamental_reference")
        )
        capacity_source = _text(
            a.get("capacity_source")
        )

        if hurdle_source:
            source_parts.append(
                "Hurdle:"
                + hurdle_source
            )
        if latest_evidence:
            source_parts.append(
                "Evidence:"
                + latest_evidence
            )
        if fundamental_reference:
            source_parts.append(
                "Fundamental:"
                + fundamental_reference
            )
        if capacity_source:
            source_parts.append(
                "Capacity:"
                + capacity_source
            )

        assist_source = " | ".join(
            source_parts
        )
        existing_source = _text(
            row.get("source")
        )
        if assist_source:
            if not existing_source:
                row["source"] = assist_source
                changed = True
            elif assist_source not in existing_source:
                row["source"] = (
                    existing_source
                    + " | "
                    + assist_source
                )
                changed = True

        note_tag = (
            "SOURCE_ASSIST_INPUT_ONLY;"
            " FORWARD_ER_RISK_PENALTY_NOT_AUTO_FILLED"
        )
        existing_note = _text(
            row.get("note")
        )
        if note_tag not in existing_note:
            row["note"] = (
                (
                    existing_note
                    + "; "
                    if existing_note
                    else ""
                )
                + note_tag
            )
            changed = True

        # Human review must remain explicit.
        row["reviewed"] = False

        rows[idx] = row
        if changed:
            applied += 1

    out = normalize_capital_productivity_inputs(
        pd.DataFrame(rows)
    )

    return out, applied


CAPITAL_PRODUCTIVITY_REVIEW_ASSIST_COLS = [
    "name",
    "ticker",
    "kind",
    "hurdle_reference",
    "fcf_yield_reference",
    "canonical_bear_downside",
    "fcf_confidence",
    "evidence_status",
    "refinancing_gate",
    "lifecycle",
    "add_freeze",
    "fundamental_reference",
    "latest_scenario_event",
    "scenario_pw_value_delta",
    "scenario_bear_downside",
    "scenario_thesis_signal",
    "scenario_evidence_signal",
    "scenario_combined_signal",
    "forward_er_input_status",
    "risk_penalty_input_status",
    "risk_reference_flags",
]


def _latest_approved_scenario_for_company(
    scenario_refreshes: pd.DataFrame | None,
    company: str,
) -> dict:
    if (
        scenario_refreshes is None
        or scenario_refreshes.empty
        or not _text(company)
    ):
        return {}

    df = scenario_refreshes.copy()
    if "company" not in df.columns:
        return {}

    hit = df.loc[
        df["company"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(_text(company))
    ].copy()

    if hit.empty:
        return {}

    if "review_status" in hit.columns:
        approved = hit.loc[
            hit["review_status"]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq("APPROVED")
        ].copy()
        if not approved.empty:
            hit = approved

    sort_col = None
    for candidate in [
        "timestamp",
        "event_date",
        "updated_at",
    ]:
        if candidate in hit.columns:
            sort_col = candidate
            break

    if sort_col is not None:
        hit["_sort"] = pd.to_datetime(
            hit[sort_col],
            errors="coerce",
            utc=True,
        )
        hit = hit.sort_values(
            "_sort",
            ascending=False,
            na_position="last",
        )

    return hit.iloc[0].drop(
        labels=["_sort"],
        errors="ignore",
    ).to_dict()


def capital_productivity_forward_risk_assist(
    source_assist: pd.DataFrame | None,
    watchlist: pd.DataFrame | None,
    scenario_refreshes: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Surface references for human Forward ER / Risk Penalty review.

    No numeric Forward ER or Risk Penalty is inferred by this function.
    """
    if source_assist is None or source_assist.empty:
        return pd.DataFrame(
            columns=CAPITAL_PRODUCTIVITY_REVIEW_ASSIST_COLS
        )

    assist = source_assist.copy()
    watch = (
        watchlist.copy()
        if watchlist is not None
        else pd.DataFrame()
    )

    rows = []

    for _, arow in assist.iterrows():
        a = arow.to_dict()
        name = _text(a.get("name"))
        ticker = _text(a.get("ticker"))
        kind = _text(a.get("kind")).upper()

        wh = pd.DataFrame()
        if not watch.empty and "name" in watch.columns:
            wh = watch.loc[
                watch["name"]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(name)
            ].copy()

        wr = (
            wh.iloc[-1].to_dict()
            if not wh.empty
            else {}
        )

        canonical_bear = _num(
            wr.get("bear_downside")
        )
        fcf_confidence = _num(
            wr.get("fcf_confidence")
        )
        evidence_status = (
            _text(
                wr.get("evidence_status")
            ).upper()
            or _text(
                a.get("evidence_status")
            ).upper()
        )
        refinancing_gate = _text(
            wr.get("refinancing_gate")
        ).upper()

        scenario = _latest_approved_scenario_for_company(
            scenario_refreshes,
            name,
        )

        scenario_event = _text(
            scenario.get("event_date")
        )
        scenario_pw_delta = _num(
            scenario.get("pw_value_delta")
        )
        scenario_bear = _num(
            scenario.get("modeled_bear_downside")
        )
        scenario_thesis_signal = _text(
            scenario.get("thesis_signal")
        ).upper()
        scenario_evidence_signal = _text(
            scenario.get("evidence_signal")
        ).upper()
        scenario_combined_signal = _text(
            scenario.get("combined_signal")
        ).upper()

        flags = []

        if kind != "CASH":
            if canonical_bear is None:
                flags.append(
                    "CANONICAL_BEAR_DOWNSIDE_MISSING"
                )
            if evidence_status in {
                "",
                "PROVISIONAL",
                "REVIEW",
                "STALE",
            }:
                flags.append(
                    "EVIDENCE_NOT_STRONG"
                )
            if refinancing_gate in {
                "",
                "REVIEW",
                "PASS-PROXY",
            }:
                flags.append(
                    "REFINANCING_REVIEW"
                )
            if _text(
                a.get("lifecycle")
            ).upper() in {
                "TRIM",
                "EXIT",
                "ADD FREEZE",
                "ADD_FREEZE",
            }:
                flags.append(
                    "LIFECYCLE_RISK_FLAG"
                )
            if _text(
                a.get("add_freeze")
            ).upper() in {
                "ON",
                "REVIEW",
            }:
                flags.append(
                    "ADD_FREEZE_FLAG"
                )
            if not scenario:
                flags.append(
                    "APPROVED_SCENARIO_REFRESH_MISSING"
                )

        rows.append(
            {
                "name": name,
                "ticker": ticker,
                "kind": kind,
                "hurdle_reference": _num(
                    a.get("hurdle_reference")
                ),
                "fcf_yield_reference": _num(
                    a.get("fcf_yield_reference")
                ),
                "canonical_bear_downside": canonical_bear,
                "fcf_confidence": fcf_confidence,
                "evidence_status": evidence_status,
                "refinancing_gate": refinancing_gate,
                "lifecycle": _text(
                    a.get("lifecycle")
                ).upper(),
                "add_freeze": _text(
                    a.get("add_freeze")
                ).upper(),
                "fundamental_reference": _text(
                    a.get("fundamental_reference")
                ),
                "latest_scenario_event": scenario_event,
                "scenario_pw_value_delta": scenario_pw_delta,
                "scenario_bear_downside": scenario_bear,
                "scenario_thesis_signal": scenario_thesis_signal,
                "scenario_evidence_signal": scenario_evidence_signal,
                "scenario_combined_signal": scenario_combined_signal,
                "forward_er_input_status": "HUMAN_REQUIRED",
                "risk_penalty_input_status": "HUMAN_REQUIRED",
                "risk_reference_flags": " | ".join(
                    flags
                ),
            }
        )

    return pd.DataFrame(
        rows,
        columns=CAPITAL_PRODUCTIVITY_REVIEW_ASSIST_COLS,
    )


def validate_capital_productivity_manual_review(
    *,
    forward_er_text: str,
    risk_penalty_text: str,
    review_basis: str,
    review_due_date: date | str | None,
    horizon_confirmed: bool,
    risk_reference_confirmed: bool,
    human_confirmed: bool,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()

    issues = []

    forward_er = _num(
        forward_er_text
    )
    risk_penalty = _num(
        risk_penalty_text
    )

    if forward_er is None:
        issues.append(
            "FORWARD_ER_REQUIRED"
        )
    if risk_penalty is None:
        issues.append(
            "RISK_PENALTY_REQUIRED"
        )
    elif risk_penalty < 0:
        issues.append(
            "RISK_PENALTY_NEGATIVE"
        )

    if not _text(review_basis):
        issues.append(
            "REVIEW_BASIS_REQUIRED"
        )

    due = None
    try:
        if isinstance(
            review_due_date,
            date,
        ):
            due = review_due_date
        else:
            parsed = pd.to_datetime(
                review_due_date,
                errors="coerce",
            )
            if not pd.isna(parsed):
                due = parsed.date()
    except Exception:
        due = None

    if due is None:
        issues.append(
            "REVIEW_DUE_DATE_REQUIRED"
        )
    elif due <= current_date:
        issues.append(
            "REVIEW_DUE_DATE_NOT_FUTURE"
        )

    if not _bool(
        horizon_confirmed
    ):
        issues.append(
            "FORWARD_HORIZON_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        risk_reference_confirmed
    ):
        issues.append(
            "RISK_REFERENCE_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        human_confirmed
    ):
        issues.append(
            "HUMAN_CONFIRMATION_REQUIRED"
        )

    return {
        "status": (
            "PASS"
            if not issues
            else "REVIEW"
        ),
        "forward_er": forward_er,
        "risk_penalty": risk_penalty,
        "review_due_date": (
            due.isoformat()
            if due is not None
            else ""
        ),
        "issues": issues,
    }


def apply_reviewed_capital_productivity_assumption(
    inputs: pd.DataFrame | None,
    reference_row: dict,
    *,
    forward_er: float,
    risk_penalty: float,
    review_basis: str,
    review_due_date: date | str,
) -> pd.DataFrame:
    """
    Persist only a fully human-reviewed assumption.

    Hurdle / Capacity / Source references already in the register are preserved.
    """
    current = normalize_capital_productivity_inputs(
        inputs
    )
    ref = reference_row or {}

    name = _text(
        ref.get("name")
    )
    ticker = _text(
        ref.get("ticker")
    )
    kind = _text(
        ref.get("kind")
    ).upper()

    if not name:
        return current

    rows = current.to_dict(
        orient="records"
    )

    idx = None
    for i, row in enumerate(rows):
        if _text(row.get("name")) == name:
            idx = i
            break

    if idx is None:
        row = {
            col: ""
            for col in CAPITAL_PRODUCTIVITY_INPUT_COLS
        }
        row["name"] = name
        row["ticker"] = ticker
        row["kind"] = kind
        rows.append(row)
        idx = len(rows) - 1

    row = rows[idx]

    row["forward_er"] = float(
        forward_er
    )
    row["risk_penalty"] = float(
        risk_penalty
    )
    row["reviewed"] = True
    row["review_due_date"] = pd.to_datetime(
        review_due_date,
        errors="coerce",
    )

    source_bits = []
    for label, key in [
        (
            "HurdleRef",
            "hurdle_reference",
        ),
        (
            "FCFYieldRef",
            "fcf_yield_reference",
        ),
        (
            "Fundamental",
            "fundamental_reference",
        ),
        (
            "ScenarioEvent",
            "latest_scenario_event",
        ),
        (
            "ScenarioSignal",
            "scenario_thesis_signal",
        ),
        (
            "Evidence",
            "evidence_status",
        ),
        (
            "Lifecycle",
            "lifecycle",
        ),
    ]:
        value = ref.get(key)
        if _text(value) or _num(value) is not None:
            source_bits.append(
                f"{label}:{value}"
            )

    review_source = (
        "Human Reviewed Forward/Risk Assumption"
        + (
            " | "
            + " | ".join(
                source_bits
            )
            if source_bits
            else ""
        )
    )

    existing_source = _text(
        row.get("source")
    )
    if review_source not in existing_source:
        row["source"] = (
            existing_source
            + (
                " | "
                if existing_source
                else ""
            )
            + review_source
        )

    existing_note = _text(
        row.get("note")
    )
    review_note = (
        "FORWARD_RISK_HUMAN_REVIEW;"
        " BASIS="
        + _text(
            review_basis
        )
    )
    row["note"] = (
        existing_note
        + (
            "; "
            if existing_note
            else ""
        )
        + review_note
    )

    rows[idx] = row

    return normalize_capital_productivity_inputs(
        pd.DataFrame(
            rows
        )
    )


CAPITAL_PRODUCTIVITY_CALIBRATION_COLS = [
    "reviewed_at",
    "name",
    "ticker",
    "kind",
    "forward_horizon",
    "er_low",
    "er_base",
    "er_high",
    "risk_low",
    "risk_base",
    "risk_high",
    "hurdle_rate",
    "risk_adjusted_low",
    "risk_adjusted_base",
    "risk_adjusted_high",
    "hurdle_spread_low",
    "hurdle_spread_base",
    "hurdle_spread_high",
    "selected_point",
    "selected_forward_er",
    "selected_risk_penalty",
    "selected_risk_adjusted_er",
    "selected_hurdle_spread",
    "review_basis",
    "review_due_date",
    "reference_snapshot",
    "calibration_status",
    "execution_authorization",
    "note",
]


def validate_forward_risk_calibration(
    *,
    er_low_text: str,
    er_base_text: str,
    er_high_text: str,
    risk_low_text: str,
    risk_base_text: str,
    risk_high_text: str,
    hurdle_rate: float | None,
    forward_horizon: str,
    review_basis: str,
    review_due_date: date | str | None,
    horizon_confirmed: bool,
    reference_confirmed: bool,
    human_confirmed: bool,
    today: date | None = None,
) -> dict:
    """
    Validate a human-entered calibration range.

    No Forward ER or Risk Penalty is inferred by the system.
    """
    current_date = today or date.today()

    er_low = _num(er_low_text)
    er_base = _num(er_base_text)
    er_high = _num(er_high_text)

    risk_low = _num(risk_low_text)
    risk_base = _num(risk_base_text)
    risk_high = _num(risk_high_text)

    hurdle = _num(hurdle_rate)

    issues = []

    values = {
        "ER_LOW_REQUIRED": er_low,
        "ER_BASE_REQUIRED": er_base,
        "ER_HIGH_REQUIRED": er_high,
        "RISK_LOW_REQUIRED": risk_low,
        "RISK_BASE_REQUIRED": risk_base,
        "RISK_HIGH_REQUIRED": risk_high,
        "HURDLE_REQUIRED": hurdle,
    }

    for issue, value in values.items():
        if value is None:
            issues.append(issue)

    if (
        er_low is not None
        and er_base is not None
        and er_high is not None
        and not (
            er_low
            <= er_base
            <= er_high
        )
    ):
        issues.append(
            "FORWARD_ER_RANGE_ORDER_INVALID"
        )

    if (
        risk_low is not None
        and risk_base is not None
        and risk_high is not None
    ):
        if min(
            risk_low,
            risk_base,
            risk_high,
        ) < 0:
            issues.append(
                "RISK_PENALTY_NEGATIVE"
            )
        if not (
            risk_low
            <= risk_base
            <= risk_high
        ):
            issues.append(
                "RISK_PENALTY_RANGE_ORDER_INVALID"
            )

    if not _text(
        forward_horizon
    ):
        issues.append(
            "FORWARD_HORIZON_REQUIRED"
        )

    if not _text(
        review_basis
    ):
        issues.append(
            "CALIBRATION_BASIS_REQUIRED"
        )

    due = None
    try:
        if isinstance(
            review_due_date,
            date,
        ):
            due = review_due_date
        else:
            parsed = pd.to_datetime(
                review_due_date,
                errors="coerce",
            )
            if not pd.isna(parsed):
                due = parsed.date()
    except Exception:
        due = None

    if due is None:
        issues.append(
            "REVIEW_DUE_DATE_REQUIRED"
        )
    elif due <= current_date:
        issues.append(
            "REVIEW_DUE_DATE_NOT_FUTURE"
        )

    if not _bool(
        horizon_confirmed
    ):
        issues.append(
            "FORWARD_HORIZON_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        reference_confirmed
    ):
        issues.append(
            "REFERENCE_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        human_confirmed
    ):
        issues.append(
            "HUMAN_CALIBRATION_CONFIRMATION_REQUIRED"
        )

    risk_adjusted_low = None
    risk_adjusted_base = None
    risk_adjusted_high = None

    hurdle_spread_low = None
    hurdle_spread_base = None
    hurdle_spread_high = None

    if (
        er_low is not None
        and er_base is not None
        and er_high is not None
        and risk_low is not None
        and risk_base is not None
        and risk_high is not None
    ):
        # Conservative pairing = low ER with high risk.
        risk_adjusted_low = (
            er_low
            - risk_high
        )
        risk_adjusted_base = (
            er_base
            - risk_base
        )
        risk_adjusted_high = (
            er_high
            - risk_low
        )

        if hurdle is not None:
            hurdle_spread_low = (
                risk_adjusted_low
                - hurdle
            )
            hurdle_spread_base = (
                risk_adjusted_base
                - hurdle
            )
            hurdle_spread_high = (
                risk_adjusted_high
                - hurdle
            )

    return {
        "status": (
            "PASS"
            if not issues
            else "REVIEW"
        ),
        "er_low": er_low,
        "er_base": er_base,
        "er_high": er_high,
        "risk_low": risk_low,
        "risk_base": risk_base,
        "risk_high": risk_high,
        "hurdle_rate": hurdle,
        "risk_adjusted_low": risk_adjusted_low,
        "risk_adjusted_base": risk_adjusted_base,
        "risk_adjusted_high": risk_adjusted_high,
        "hurdle_spread_low": hurdle_spread_low,
        "hurdle_spread_base": hurdle_spread_base,
        "hurdle_spread_high": hurdle_spread_high,
        "forward_horizon": _text(
            forward_horizon
        ),
        "review_due_date": (
            due.isoformat()
            if due is not None
            else ""
        ),
        "issues": issues,
    }


def calibration_point_values(
    calibration: dict,
    selected_point: str,
) -> dict:
    """
    Map a reviewed range to an explicitly selected point.

    LOW = low ER / high risk
    BASE = base ER / base risk
    HIGH = high ER / low risk
    """
    point = _text(
        selected_point
    ).upper()

    mapping = {
        "LOW_ER_HIGH_RISK": (
            "er_low",
            "risk_high",
            "risk_adjusted_low",
            "hurdle_spread_low",
        ),
        "BASE": (
            "er_base",
            "risk_base",
            "risk_adjusted_base",
            "hurdle_spread_base",
        ),
        "HIGH_ER_LOW_RISK": (
            "er_high",
            "risk_low",
            "risk_adjusted_high",
            "hurdle_spread_high",
        ),
    }

    keys = mapping.get(point)
    if keys is None:
        return {
            "status": "REVIEW",
            "selected_point": point,
            "forward_er": None,
            "risk_penalty": None,
            "risk_adjusted_er": None,
            "hurdle_spread": None,
            "issues": [
                "CALIBRATION_POINT_INVALID"
            ],
        }

    forward_er = _num(
        calibration.get(
            keys[0]
        )
    )
    risk_penalty = _num(
        calibration.get(
            keys[1]
        )
    )
    risk_adjusted_er = _num(
        calibration.get(
            keys[2]
        )
    )
    hurdle_spread = _num(
        calibration.get(
            keys[3]
        )
    )

    issues = []
    if _text(
        calibration.get("status")
    ).upper() != "PASS":
        issues.append(
            "CALIBRATION_NOT_PASS"
        )

    if (
        forward_er is None
        or risk_penalty is None
    ):
        issues.append(
            "CALIBRATION_POINT_VALUES_MISSING"
        )

    return {
        "status": (
            "PASS"
            if not issues
            else "REVIEW"
        ),
        "selected_point": point,
        "forward_er": forward_er,
        "risk_penalty": risk_penalty,
        "risk_adjusted_er": risk_adjusted_er,
        "hurdle_spread": hurdle_spread,
        "issues": issues,
    }


def _reference_snapshot_text(
    reference_row: dict,
) -> str:
    ref = reference_row or {}

    pairs = [
        (
            "HurdleRef",
            ref.get(
                "hurdle_reference"
            ),
        ),
        (
            "FCFYieldRef",
            ref.get(
                "fcf_yield_reference"
            ),
        ),
        (
            "CanonicalBear",
            ref.get(
                "canonical_bear_downside"
            ),
        ),
        (
            "FCFConfidence",
            ref.get(
                "fcf_confidence"
            ),
        ),
        (
            "Evidence",
            ref.get(
                "evidence_status"
            ),
        ),
        (
            "Refinancing",
            ref.get(
                "refinancing_gate"
            ),
        ),
        (
            "Lifecycle",
            ref.get(
                "lifecycle"
            ),
        ),
        (
            "AddFreeze",
            ref.get(
                "add_freeze"
            ),
        ),
        (
            "Fundamental",
            ref.get(
                "fundamental_reference"
            ),
        ),
        (
            "ScenarioEvent",
            ref.get(
                "latest_scenario_event"
            ),
        ),
        (
            "ScenarioPWDelta",
            ref.get(
                "scenario_pw_value_delta"
            ),
        ),
        (
            "ScenarioBear",
            ref.get(
                "scenario_bear_downside"
            ),
        ),
        (
            "ScenarioThesis",
            ref.get(
                "scenario_thesis_signal"
            ),
        ),
        (
            "ScenarioEvidence",
            ref.get(
                "scenario_evidence_signal"
            ),
        ),
    ]

    parts = []
    for label, value in pairs:
        if _text(value) or _num(
            value
        ) is not None:
            parts.append(
                f"{label}:{value}"
            )

    return " | ".join(parts)


def apply_calibrated_capital_productivity_assumption(
    inputs: pd.DataFrame | None,
    reference_row: dict,
    calibration: dict,
    *,
    selected_point: str,
    review_basis: str,
    review_due_date: date | str,
) -> tuple[pd.DataFrame, dict]:
    """
    Apply one explicitly selected calibration point to the Assumption Register.

    The selection is a human choice; the function does not choose a point.
    """
    current = normalize_capital_productivity_inputs(
        inputs
    )

    point = calibration_point_values(
        calibration,
        selected_point,
    )
    if point["status"] != "PASS":
        return current, point

    ref = reference_row or {}
    name = _text(
        ref.get("name")
    )
    ticker = _text(
        ref.get("ticker")
    )
    kind = _text(
        ref.get("kind")
    ).upper()

    if not name:
        return current, {
            **point,
            "status": "REVIEW",
            "issues": point[
                "issues"
            ]
            + [
                "REFERENCE_NAME_REQUIRED"
            ],
        }

    rows = current.to_dict(
        orient="records"
    )

    idx = None
    for i, row in enumerate(
        rows
    ):
        if _text(
            row.get("name")
        ) == name:
            idx = i
            break

    if idx is None:
        row = {
            col: ""
            for col in CAPITAL_PRODUCTIVITY_INPUT_COLS
        }
        row["name"] = name
        row["ticker"] = ticker
        row["kind"] = kind
        rows.append(row)
        idx = len(rows) - 1

    row = rows[idx]

    row["forward_er"] = float(
        point["forward_er"]
    )
    row["risk_penalty"] = float(
        point["risk_penalty"]
    )
    row["reviewed"] = True
    row["review_due_date"] = pd.to_datetime(
        review_due_date,
        errors="coerce",
    )

    hurdle_ref = _num(
        ref.get(
            "hurdle_reference"
        )
    )
    if (
        _num(
            row.get("hurdle_rate")
        )
        is None
        and hurdle_ref is not None
    ):
        row["hurdle_rate"] = hurdle_ref

    reference_snapshot = (
        _reference_snapshot_text(
            ref
        )
    )

    calibration_source = (
        "Human Calibration Range"
        f" | Point:{point['selected_point']}"
        f" | Horizon:{_text(calibration.get('forward_horizon'))}"
        f" | ER:[{calibration.get('er_low')},{calibration.get('er_base')},{calibration.get('er_high')}]"
        f" | Risk:[{calibration.get('risk_low')},{calibration.get('risk_base')},{calibration.get('risk_high')}]"
    )

    if reference_snapshot:
        calibration_source += (
            " | "
            + reference_snapshot
        )

    existing_source = _text(
        row.get("source")
    )
    if calibration_source not in existing_source:
        row["source"] = (
            existing_source
            + (
                " | "
                if existing_source
                else ""
            )
            + calibration_source
        )

    existing_note = _text(
        row.get("note")
    )
    calibration_note = (
        "CALIBRATED_FORWARD_RISK_HUMAN_REVIEW;"
        f" POINT={point['selected_point']};"
        f" BASIS={_text(review_basis)}"
    )
    row["note"] = (
        existing_note
        + (
            "; "
            if existing_note
            else ""
        )
        + calibration_note
    )

    rows[idx] = row

    return (
        normalize_capital_productivity_inputs(
            pd.DataFrame(
                rows
            )
        ),
        point,
    )


def capital_productivity_calibration_record(
    reference_row: dict,
    calibration: dict,
    selected_point: dict,
    *,
    review_basis: str,
    note: str = "",
) -> dict:
    ref = reference_row or {}
    point = selected_point or {}

    return {
        "reviewed_at":
            datetime.now().isoformat(),
        "name":
            _text(
                ref.get("name")
            ),
        "ticker":
            _text(
                ref.get("ticker")
            ),
        "kind":
            _text(
                ref.get("kind")
            ),
        "forward_horizon":
            _text(
                calibration.get(
                    "forward_horizon"
                )
            ),
        "er_low":
            _num(
                calibration.get(
                    "er_low"
                )
            ),
        "er_base":
            _num(
                calibration.get(
                    "er_base"
                )
            ),
        "er_high":
            _num(
                calibration.get(
                    "er_high"
                )
            ),
        "risk_low":
            _num(
                calibration.get(
                    "risk_low"
                )
            ),
        "risk_base":
            _num(
                calibration.get(
                    "risk_base"
                )
            ),
        "risk_high":
            _num(
                calibration.get(
                    "risk_high"
                )
            ),
        "hurdle_rate":
            _num(
                calibration.get(
                    "hurdle_rate"
                )
            ),
        "risk_adjusted_low":
            _num(
                calibration.get(
                    "risk_adjusted_low"
                )
            ),
        "risk_adjusted_base":
            _num(
                calibration.get(
                    "risk_adjusted_base"
                )
            ),
        "risk_adjusted_high":
            _num(
                calibration.get(
                    "risk_adjusted_high"
                )
            ),
        "hurdle_spread_low":
            _num(
                calibration.get(
                    "hurdle_spread_low"
                )
            ),
        "hurdle_spread_base":
            _num(
                calibration.get(
                    "hurdle_spread_base"
                )
            ),
        "hurdle_spread_high":
            _num(
                calibration.get(
                    "hurdle_spread_high"
                )
            ),
        "selected_point":
            _text(
                point.get(
                    "selected_point"
                )
            ),
        "selected_forward_er":
            _num(
                point.get(
                    "forward_er"
                )
            ),
        "selected_risk_penalty":
            _num(
                point.get(
                    "risk_penalty"
                )
            ),
        "selected_risk_adjusted_er":
            _num(
                point.get(
                    "risk_adjusted_er"
                )
            ),
        "selected_hurdle_spread":
            _num(
                point.get(
                    "hurdle_spread"
                )
            ),
        "review_basis":
            _text(
                review_basis
            ),
        "review_due_date":
            _text(
                calibration.get(
                    "review_due_date"
                )
            ),
        "reference_snapshot":
            _reference_snapshot_text(
                ref
            ),
        "calibration_status":
            _text(
                calibration.get(
                    "status"
                )
            ),
        "execution_authorization":
            "NONE",
        "note":
            _text(note),
    }


CAPITAL_PRODUCTIVITY_CALIBRATION_DRAFT_COLS = [
    "calibration_id",
    "created_at",
    "updated_at",
    "approval_status",
    "purpose",
    "name",
    "ticker",
    "kind",
    "forward_horizon",
    "er_low",
    "er_base",
    "er_high",
    "risk_low",
    "risk_base",
    "risk_high",
    "hurdle_rate",
    "risk_adjusted_low",
    "risk_adjusted_base",
    "risk_adjusted_high",
    "hurdle_spread_low",
    "hurdle_spread_base",
    "hurdle_spread_high",
    "selected_point",
    "selected_forward_er",
    "selected_risk_penalty",
    "selected_risk_adjusted_er",
    "selected_hurdle_spread",
    "review_basis",
    "review_due_date",
    "reference_snapshot",
    "reference_hash",
    "calibration_status",
    "hash_schema",
    "content_hash",
    "execution_authorization",
    "note",
    "approved_at",
    "approval_note",
]


def _canonical_hash(payload: dict) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def calibration_reference_hash(
    reference_row: dict | None,
) -> str:
    snapshot = _reference_snapshot_text(
        reference_row or {}
    )
    return _canonical_hash(
        {
            "reference_snapshot": snapshot,
        }
    )


def _stable_decimal_text(
    value: Any,
    places: int = 12,
) -> str | None:
    """
    Stable numeric canonicalization for CSV round-trips.

    pandas CSV serialization can turn 0.06999999999999999 into
    0.0699999999999999. Hashes must represent the economic value, not the
    in-memory IEEE-754 spelling.
    """
    number = _num(value)
    if number is None:
        return None

    try:
        d = Decimal(
            str(number)
        )
        quantum = Decimal(
            "1"
        ).scaleb(
            -int(places)
        )
        q = d.quantize(
            quantum,
            rounding=ROUND_HALF_EVEN,
        )
        return format(
            q,
            "f",
        )
    except (
        InvalidOperation,
        ValueError,
        TypeError,
    ):
        return (
            f"{float(number):.{int(places)}f}"
        )


def _draft_hash_payload(
    row: dict,
    *,
    schema: str = "v2",
) -> dict:
    """
    Immutable calibration content only.

    v2 uses stable decimal strings so pandas CSV float round-trips do not
    create false hash mismatches.
    """
    keys = [
        "purpose",
        "name",
        "ticker",
        "kind",
        "forward_horizon",
        "er_low",
        "er_base",
        "er_high",
        "risk_low",
        "risk_base",
        "risk_high",
        "hurdle_rate",
        "risk_adjusted_low",
        "risk_adjusted_base",
        "risk_adjusted_high",
        "hurdle_spread_low",
        "hurdle_spread_base",
        "hurdle_spread_high",
        "selected_point",
        "selected_forward_er",
        "selected_risk_penalty",
        "selected_risk_adjusted_er",
        "selected_hurdle_spread",
        "review_basis",
        "review_due_date",
        "reference_snapshot",
        "reference_hash",
        "calibration_status",
        "execution_authorization",
        "note",
    ]

    numeric_keys = {
        "er_low",
        "er_base",
        "er_high",
        "risk_low",
        "risk_base",
        "risk_high",
        "hurdle_rate",
        "risk_adjusted_low",
        "risk_adjusted_base",
        "risk_adjusted_high",
        "hurdle_spread_low",
        "hurdle_spread_base",
        "hurdle_spread_high",
        "selected_forward_er",
        "selected_risk_penalty",
        "selected_risk_adjusted_er",
        "selected_hurdle_spread",
    }

    payload = {
        "hash_schema": schema,
    }

    for key in keys:
        value = row.get(
            key
        )

        if key in numeric_keys:
            if schema == "v2":
                payload[key] = (
                    _stable_decimal_text(
                        value
                    )
                )
            else:
                payload[key] = _num(
                    value
                )
        else:
            payload[key] = _text(
                value
            )

    return payload


def calibration_draft_integrity(
    draft_row: dict | None,
) -> str:
    row = draft_row or {}
    stored = _text(
        row.get(
            "content_hash"
        )
    )
    if not stored:
        return "MISSING"

    schema = _text(
        row.get(
            "hash_schema"
        )
    ).lower()

    if schema != "v2":
        # dev6 drafts used raw IEEE-754 floats in the hash payload.
        # CSV round-trip can alter only their textual representation and create
        # false mismatches, so legacy drafts are intentionally non-promotable.
        return "LEGACY_V1_REVIEW"

    expected = _canonical_hash(
        _draft_hash_payload(
            row,
            schema="v2",
        )
    )
    return (
        "OK"
        if stored == expected
        else "MISMATCH"
    )


def normalize_calibration_drafts(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in CAPITAL_PRODUCTIVITY_CALIBRATION_DRAFT_COLS:
        if col not in out.columns:
            out[col] = ""

    text_cols = [
        "calibration_id",
        "created_at",
        "updated_at",
        "approval_status",
        "purpose",
        "name",
        "ticker",
        "kind",
        "forward_horizon",
        "selected_point",
        "review_basis",
        "review_due_date",
        "reference_snapshot",
        "reference_hash",
        "calibration_status",
        "hash_schema",
        "content_hash",
        "execution_authorization",
        "note",
        "approved_at",
        "approval_note",
    ]
    for col in text_cols:
        out[col] = out[col].map(
            _text
        ).astype("object")

    numeric_cols = [
        "er_low",
        "er_base",
        "er_high",
        "risk_low",
        "risk_base",
        "risk_high",
        "hurdle_rate",
        "risk_adjusted_low",
        "risk_adjusted_base",
        "risk_adjusted_high",
        "hurdle_spread_low",
        "hurdle_spread_base",
        "hurdle_spread_high",
        "selected_forward_er",
        "selected_risk_penalty",
        "selected_risk_adjusted_er",
        "selected_hurdle_spread",
    ]
    for col in numeric_cols:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )

    return out[
        CAPITAL_PRODUCTIVITY_CALIBRATION_DRAFT_COLS
    ].copy()


def build_calibration_draft(
    reference_row: dict,
    calibration: dict,
    selected_point: dict,
    *,
    purpose: str,
    review_basis: str,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    """
    Create a DRAFT only. This function never changes operating assumptions.
    """
    ref = reference_row or {}
    point = selected_point or {}

    purpose_value = _text(
        purpose
    ).upper()
    if purpose_value not in {
        "PILOT_TEST",
        "OPERATING_ASSUMPTION",
    }:
        purpose_value = "PILOT_TEST"

    now = (
        _text(created_at)
        or datetime.now().isoformat()
    )

    reference_snapshot = _reference_snapshot_text(
        ref
    )
    reference_hash = calibration_reference_hash(
        ref
    )

    row = {
        "calibration_id": "",
        "created_at": now,
        "updated_at": now,
        "approval_status": "DRAFT",
        "purpose": purpose_value,
        "name": _text(
            ref.get("name")
        ),
        "ticker": _text(
            ref.get("ticker")
        ),
        "kind": _text(
            ref.get("kind")
        ),
        "forward_horizon": _text(
            calibration.get(
                "forward_horizon"
            )
        ),
        "er_low": _num(
            calibration.get("er_low")
        ),
        "er_base": _num(
            calibration.get("er_base")
        ),
        "er_high": _num(
            calibration.get("er_high")
        ),
        "risk_low": _num(
            calibration.get("risk_low")
        ),
        "risk_base": _num(
            calibration.get("risk_base")
        ),
        "risk_high": _num(
            calibration.get("risk_high")
        ),
        "hurdle_rate": _num(
            calibration.get(
                "hurdle_rate"
            )
        ),
        "risk_adjusted_low": _num(
            calibration.get(
                "risk_adjusted_low"
            )
        ),
        "risk_adjusted_base": _num(
            calibration.get(
                "risk_adjusted_base"
            )
        ),
        "risk_adjusted_high": _num(
            calibration.get(
                "risk_adjusted_high"
            )
        ),
        "hurdle_spread_low": _num(
            calibration.get(
                "hurdle_spread_low"
            )
        ),
        "hurdle_spread_base": _num(
            calibration.get(
                "hurdle_spread_base"
            )
        ),
        "hurdle_spread_high": _num(
            calibration.get(
                "hurdle_spread_high"
            )
        ),
        "selected_point": _text(
            point.get(
                "selected_point"
            )
        ),
        "selected_forward_er": _num(
            point.get("forward_er")
        ),
        "selected_risk_penalty": _num(
            point.get("risk_penalty")
        ),
        "selected_risk_adjusted_er": _num(
            point.get(
                "risk_adjusted_er"
            )
        ),
        "selected_hurdle_spread": _num(
            point.get(
                "hurdle_spread"
            )
        ),
        "review_basis": _text(
            review_basis
        ),
        "review_due_date": _text(
            calibration.get(
                "review_due_date"
            )
        ),
        "reference_snapshot": reference_snapshot,
        "reference_hash": reference_hash,
        "calibration_status": _text(
            calibration.get("status")
        ).upper(),
        "hash_schema": "v2",
        "content_hash": "",
        "execution_authorization": "NONE",
        "note": _text(note),
        "approved_at": "",
        "approval_note": "",
    }

    temp_hash = _canonical_hash(
        _draft_hash_payload(
            row,
            schema="v2",
        )
    )
    stamp = (
        pd.to_datetime(
            now,
            errors="coerce",
            utc=True,
        )
    )
    if pd.isna(stamp):
        id_stamp = datetime.now().strftime(
            "%Y%m%dT%H%M%S"
        )
    else:
        id_stamp = pd.Timestamp(
            stamp
        ).strftime(
            "%Y%m%dT%H%M%S"
        )

    safe_name = "".join(
        ch
        for ch in row["name"]
        if ch.isalnum()
    )[:16] or "CAL"
    row["calibration_id"] = (
        f"CP-{id_stamp}-{safe_name}-{temp_hash[:8]}"
    )
    row["content_hash"] = _canonical_hash(
        _draft_hash_payload(
            row,
            schema="v2",
        )
    )

    return row


def calibration_approval_gate(
    draft_row: dict,
    current_reference: dict,
    *,
    draft_reconfirmed: bool,
    reference_reconfirmed: bool,
    operating_use_confirmed: bool,
    human_approval_confirmed: bool,
    approval_note: str,
    today: date | None = None,
) -> dict:
    """
    Approval gate for promotion from DRAFT to operating assumption.

    PILOT_TEST is intentionally not promotable.
    """
    current_date = today or date.today()
    draft = draft_row or {}

    issues = []

    approval_status = _text(
        draft.get(
            "approval_status"
        )
    ).upper()
    purpose = _text(
        draft.get("purpose")
    ).upper()
    calibration_status = _text(
        draft.get(
            "calibration_status"
        )
    ).upper()

    integrity = calibration_draft_integrity(
        draft
    )
    hash_schema = _text(
        draft.get(
            "hash_schema"
        )
    ).lower()

    current_reference_hash = calibration_reference_hash(
        current_reference or {}
    )
    stored_reference_hash = _text(
        draft.get(
            "reference_hash"
        )
    )
    reference_match = (
        bool(
            stored_reference_hash
        )
        and stored_reference_hash
        == current_reference_hash
    )

    if approval_status != "DRAFT":
        issues.append(
            "DRAFT_STATUS_REQUIRED"
        )

    if purpose != "OPERATING_ASSUMPTION":
        issues.append(
            "PILOT_TEST_NOT_PROMOTABLE"
            if purpose == "PILOT_TEST"
            else "OPERATING_PURPOSE_REQUIRED"
        )

    if calibration_status != "PASS":
        issues.append(
            "CALIBRATION_NOT_PASS"
        )

    if hash_schema != "v2":
        issues.append(
            "LEGACY_HASH_SCHEMA_NOT_PROMOTABLE"
        )

    if integrity != "OK":
        issues.append(
            "DRAFT_HASH_INTEGRITY_NOT_OK"
        )

    if not reference_match:
        issues.append(
            "REFERENCE_FINGERPRINT_MISMATCH"
        )

    point = _text(
        draft.get(
            "selected_point"
        )
    ).upper()
    if point not in {
        "LOW_ER_HIGH_RISK",
        "BASE",
        "HIGH_ER_LOW_RISK",
    }:
        issues.append(
            "SELECTED_POINT_INVALID"
        )

    if (
        _num(
            draft.get(
                "selected_forward_er"
            )
        )
        is None
        or _num(
            draft.get(
                "selected_risk_penalty"
            )
        )
        is None
    ):
        issues.append(
            "SELECTED_POINT_VALUES_MISSING"
        )

    due = pd.to_datetime(
        draft.get(
            "review_due_date"
        ),
        errors="coerce",
    )
    if pd.isna(due):
        issues.append(
            "REVIEW_DUE_DATE_REQUIRED"
        )
        review_due_gate = "REVIEW"
    elif due.date() <= current_date:
        issues.append(
            "REVIEW_DUE_DATE_EXPIRED"
        )
        review_due_gate = "EXPIRED"
    else:
        review_due_gate = "PASS"

    if not _text(
        approval_note
    ):
        issues.append(
            "APPROVAL_NOTE_REQUIRED"
        )

    confirmations = {
        "DRAFT_RECONFIRMATION_REQUIRED":
            _bool(
                draft_reconfirmed
            ),
        "REFERENCE_RECONFIRMATION_REQUIRED":
            _bool(
                reference_reconfirmed
            ),
        "OPERATING_USE_CONFIRMATION_REQUIRED":
            _bool(
                operating_use_confirmed
            ),
        "HUMAN_APPROVAL_REQUIRED":
            _bool(
                human_approval_confirmed
            ),
    }
    for issue, passed in confirmations.items():
        if not passed:
            issues.append(issue)

    return {
        "status": (
            "PASS"
            if not issues
            else "REVIEW"
        ),
        "purpose": purpose,
        "integrity": integrity,
        "hash_schema": hash_schema or "legacy-v1",
        "reference_match": (
            "MATCH"
            if reference_match
            else "MISMATCH"
        ),
        "review_due_gate": review_due_gate,
        "execution_authorization": "NONE",
        "issues": issues,
    }


def approve_calibration_draft(
    drafts: pd.DataFrame | None,
    calibration_id: str,
    *,
    approval_note: str,
    approved_at: str | None = None,
) -> tuple[pd.DataFrame, dict]:
    """
    Change governance status only. Immutable content/hash remains untouched.
    """
    df = normalize_calibration_drafts(
        drafts
    )
    cid = _text(
        calibration_id
    )

    hit = df.loc[
        df["calibration_id"].eq(
            cid
        )
    ].copy()
    if hit.empty:
        return df, {
            "status": "REVIEW",
            "issues": [
                "CALIBRATION_ID_NOT_FOUND"
            ],
        }

    idx = hit.index[-1]
    row = df.loc[
        idx
    ].to_dict()

    if _text(
        row.get(
            "approval_status"
        )
    ).upper() != "DRAFT":
        return df, {
            "status": "REVIEW",
            "issues": [
                "DRAFT_STATUS_REQUIRED"
            ],
        }

    if _text(
        row.get(
            "hash_schema"
        )
    ).lower() != "v2":
        return df, {
            "status": "REVIEW",
            "issues": [
                "LEGACY_HASH_SCHEMA_NOT_PROMOTABLE"
            ],
        }

    if calibration_draft_integrity(
        row
    ) != "OK":
        return df, {
            "status": "REVIEW",
            "issues": [
                "DRAFT_HASH_INTEGRITY_NOT_OK"
            ],
        }

    now = (
        _text(approved_at)
        or datetime.now().isoformat()
    )

    df.loc[
        idx,
        "approval_status",
    ] = "APPROVED"
    df.loc[
        idx,
        "approved_at",
    ] = now
    df.loc[
        idx,
        "approval_note",
    ] = _text(
        approval_note
    )
    df.loc[
        idx,
        "updated_at",
    ] = now

    approved = df.loc[
        idx
    ].to_dict()

    return df, {
        "status": "PASS",
        "approved_row": approved,
        "issues": [],
    }


def apply_approved_calibration_draft(
    inputs: pd.DataFrame | None,
    approved_row: dict,
) -> tuple[pd.DataFrame, dict]:
    """
    Only APPROVED + OPERATING_ASSUMPTION + hash-integrity OK can touch
    the operating Assumption Register.
    """
    current = normalize_capital_productivity_inputs(
        inputs
    )
    row = approved_row or {}

    issues = []

    if _text(
        row.get(
            "approval_status"
        )
    ).upper() != "APPROVED":
        issues.append(
            "APPROVED_STATUS_REQUIRED"
        )

    if _text(
        row.get("purpose")
    ).upper() != "OPERATING_ASSUMPTION":
        issues.append(
            "OPERATING_PURPOSE_REQUIRED"
        )

    if _text(
        row.get(
            "hash_schema"
        )
    ).lower() != "v2":
        issues.append(
            "LEGACY_HASH_SCHEMA_NOT_PROMOTABLE"
        )

    if calibration_draft_integrity(
        row
    ) != "OK":
        issues.append(
            "DRAFT_HASH_INTEGRITY_NOT_OK"
        )

    forward_er = _num(
        row.get(
            "selected_forward_er"
        )
    )
    risk_penalty = _num(
        row.get(
            "selected_risk_penalty"
        )
    )
    hurdle_rate = _num(
        row.get("hurdle_rate")
    )

    if forward_er is None:
        issues.append(
            "SELECTED_FORWARD_ER_MISSING"
        )
    if risk_penalty is None:
        issues.append(
            "SELECTED_RISK_PENALTY_MISSING"
        )

    name = _text(
        row.get("name")
    )
    if not name:
        issues.append(
            "NAME_REQUIRED"
        )

    if issues:
        return current, {
            "status": "REVIEW",
            "issues": issues,
        }

    rows = current.to_dict(
        orient="records"
    )

    idx = None
    for i, existing in enumerate(
        rows
    ):
        if _text(
            existing.get(
                "name"
            )
        ) == name:
            idx = i
            break

    if idx is None:
        new_row = {
            col: ""
            for col in CAPITAL_PRODUCTIVITY_INPUT_COLS
        }
        new_row["name"] = name
        new_row["ticker"] = _text(
            row.get("ticker")
        )
        new_row["kind"] = _text(
            row.get("kind")
        )
        rows.append(
            new_row
        )
        idx = len(rows) - 1

    target = rows[idx]
    target["forward_er"] = float(
        forward_er
    )
    target["risk_penalty"] = float(
        risk_penalty
    )
    if (
        _num(
            target.get(
                "hurdle_rate"
            )
        )
        is None
        and hurdle_rate is not None
    ):
        target["hurdle_rate"] = hurdle_rate

    target["reviewed"] = True
    target["review_due_date"] = pd.to_datetime(
        row.get(
            "review_due_date"
        ),
        errors="coerce",
    )

    provenance = (
        "APPROVED Calibration Draft"
        f" | ID:{_text(row.get('calibration_id'))}"
        f" | Point:{_text(row.get('selected_point'))}"
        f" | Purpose:{_text(row.get('purpose'))}"
        f" | RefHash:{_text(row.get('reference_hash'))[:12]}"
        f" | ContentHash:{_text(row.get('content_hash'))[:12]}"
    )
    existing_source = _text(
        target.get("source")
    )
    if provenance not in existing_source:
        target["source"] = (
            existing_source
            + (
                " | "
                if existing_source
                else ""
            )
            + provenance
        )

    existing_note = _text(
        target.get("note")
    )
    approval_note = _text(
        row.get(
            "approval_note"
        )
    )
    note_text = (
        "CALIBRATION_APPROVED_OPERATING_ASSUMPTION;"
        f" DRAFT_ID={_text(row.get('calibration_id'))};"
        f" APPROVAL_NOTE={approval_note}"
    )
    target["note"] = (
        existing_note
        + (
            "; "
            if existing_note
            else ""
        )
        + note_text
    )

    rows[idx] = target

    return (
        normalize_capital_productivity_inputs(
            pd.DataFrame(
                rows
            )
        ),
        {
            "status": "PASS",
            "issues": [],
            "calibration_id": _text(
                row.get(
                    "calibration_id"
                )
            ),
            "execution_authorization": "NONE",
        },
    )


def approved_calibration_audit_record(
    approved_row: dict,
) -> dict:
    """
    Backward-compatible final calibration audit row.
    """
    row = approved_row or {}
    return {
        "reviewed_at":
            _text(
                row.get(
                    "approved_at"
                )
            )
            or datetime.now().isoformat(),
        "name":
            _text(
                row.get("name")
            ),
        "ticker":
            _text(
                row.get("ticker")
            ),
        "kind":
            _text(
                row.get("kind")
            ),
        "forward_horizon":
            _text(
                row.get(
                    "forward_horizon"
                )
            ),
        "er_low":
            _num(
                row.get("er_low")
            ),
        "er_base":
            _num(
                row.get("er_base")
            ),
        "er_high":
            _num(
                row.get("er_high")
            ),
        "risk_low":
            _num(
                row.get("risk_low")
            ),
        "risk_base":
            _num(
                row.get("risk_base")
            ),
        "risk_high":
            _num(
                row.get("risk_high")
            ),
        "hurdle_rate":
            _num(
                row.get(
                    "hurdle_rate"
                )
            ),
        "risk_adjusted_low":
            _num(
                row.get(
                    "risk_adjusted_low"
                )
            ),
        "risk_adjusted_base":
            _num(
                row.get(
                    "risk_adjusted_base"
                )
            ),
        "risk_adjusted_high":
            _num(
                row.get(
                    "risk_adjusted_high"
                )
            ),
        "hurdle_spread_low":
            _num(
                row.get(
                    "hurdle_spread_low"
                )
            ),
        "hurdle_spread_base":
            _num(
                row.get(
                    "hurdle_spread_base"
                )
            ),
        "hurdle_spread_high":
            _num(
                row.get(
                    "hurdle_spread_high"
                )
            ),
        "selected_point":
            _text(
                row.get(
                    "selected_point"
                )
            ),
        "selected_forward_er":
            _num(
                row.get(
                    "selected_forward_er"
                )
            ),
        "selected_risk_penalty":
            _num(
                row.get(
                    "selected_risk_penalty"
                )
            ),
        "selected_risk_adjusted_er":
            _num(
                row.get(
                    "selected_risk_adjusted_er"
                )
            ),
        "selected_hurdle_spread":
            _num(
                row.get(
                    "selected_hurdle_spread"
                )
            ),
        "review_basis":
            _text(
                row.get(
                    "review_basis"
                )
            ),
        "review_due_date":
            _text(
                row.get(
                    "review_due_date"
                )
            ),
        "reference_snapshot":
            _text(
                row.get(
                    "reference_snapshot"
                )
            ),
        "calibration_status":
            _text(
                row.get(
                    "calibration_status"
                )
            ),
        "execution_authorization":
            "NONE",
        "note":
            (
                _text(
                    row.get("note")
                )
                + (
                    "; "
                    if _text(
                        row.get("note")
                    )
                    else ""
                )
                + "APPROVED_DRAFT_ID="
                + _text(
                    row.get(
                        "calibration_id"
                    )
                )
            ),
    }


CAPITAL_HOLD_REVIEW_COLS = [
    "reviewed_at",
    "donor",
    "comparison_amount_krw",
    "hold_eligibility",
    "hold_state",
    "qualified_recipients",
    "review_recipients",
    "blocked_recipients",
    "ready_inputs",
    "total_inputs",
    "donor_lifecycle",
    "donor_add_freeze",
    "existing_donor_action",
    "earliest_assumption_review_due",
    "hold_review_due_date",
    "competition_snapshot_hash",
    "hold_reason",
    "next_evidence_needed",
    "assumption_discipline_confirmed",
    "open_reviews_confirmed",
    "existing_action_confirmed",
    "human_confirmed",
    "governance_gate",
    "final_decision",
    "execution_authorization",
    "note",
]


def _competition_snapshot_payload(
    competition: pd.DataFrame | None,
) -> list[dict]:
    if competition is None or competition.empty:
        return []

    cols = [
        "donor",
        "recipient",
        "recipient_kind",
        "comparison_amount_krw",
        "donor_risk_adjusted_er",
        "recipient_risk_adjusted_er",
        "recipient_hurdle_rate",
        "recipient_hurdle_spread",
        "tax_cost_rate",
        "trading_cost_rate",
        "net_switching_gap",
        "donor_gate",
        "input_gate",
        "hurdle_gate",
        "capacity_gate",
        "switching_gate",
        "comparison_status",
        "issues",
    ]

    view = competition[
        [
            c
            for c in cols
            if c in competition.columns
        ]
    ].copy()

    numeric_cols = {
        "comparison_amount_krw",
        "donor_risk_adjusted_er",
        "recipient_risk_adjusted_er",
        "recipient_hurdle_rate",
        "recipient_hurdle_spread",
        "tax_cost_rate",
        "trading_cost_rate",
        "net_switching_gap",
    }

    rows = []
    for _, row in view.iterrows():
        out = {}
        for col in view.columns:
            value = row.get(col)
            if col in numeric_cols:
                out[col] = _stable_decimal_text(
                    value
                )
            else:
                out[col] = _text(
                    value
                )
        rows.append(out)

    rows = sorted(
        rows,
        key=lambda x: (
            x.get(
                "recipient",
                "",
            ),
            x.get(
                "comparison_status",
                "",
            ),
        ),
    )
    return rows


def capital_hold_context(
    universe: pd.DataFrame | None,
    competition: pd.DataFrame | None,
    donor_name: str,
    comparison_amount_krw: float,
    *,
    donor_lifecycle: str = "",
    donor_add_freeze: str = "",
    today: date | None = None,
) -> dict:
    """
    Context for 'no qualified recipient' governance.

    This does not cancel an existing TRIM / EXIT / Add Freeze action.
    It only governs the next-capital allocation decision.
    """
    current_date = today or date.today()

    summary = capital_competition_summary(
        universe,
        competition,
    )

    qualified = int(
        summary.get(
            "qualified_recipients",
            0,
        )
        or 0
    )
    review = int(
        summary.get(
            "review_recipients",
            0,
        )
        or 0
    )
    blocked = int(
        summary.get(
            "blocked_recipients",
            0,
        )
        or 0
    )

    lifecycle = _text(
        donor_lifecycle
    ).upper()
    add_freeze = _text(
        donor_add_freeze
    ).upper()

    if lifecycle in {
        "TRIM",
        "EXIT",
    }:
        existing_action = lifecycle
    elif add_freeze in {
        "ON",
        "REVIEW",
    }:
        existing_action = (
            "ADD_FREEZE_"
            + add_freeze
        )
    else:
        existing_action = "NONE"

    if qualified > 0:
        hold_eligibility = "NOT_APPLICABLE"
        hold_state = "QUALIFIED_RECIPIENT_EXISTS"
    elif review > 0:
        hold_eligibility = "PASS"
        hold_state = "HOLD_NEW_CAPITAL / REVIEW_OPEN"
    else:
        hold_eligibility = "PASS"
        hold_state = "HOLD_NEW_CAPITAL / NO_QUALIFIED_RECIPIENT"

    earliest_due = None
    if universe is not None and not universe.empty:
        u = universe.copy()

        if "input_status" in u.columns:
            ready_mask = (
                u["input_status"]
                .fillna("")
                .astype(str)
                .str.upper()
                .eq("READY")
            )
            u = u.loc[
                ready_mask
            ].copy()

        if (
            not u.empty
            and "review_due_date"
            in u.columns
        ):
            due = pd.to_datetime(
                u[
                    "review_due_date"
                ],
                errors="coerce",
            ).dropna()

            future_due = due.loc[
                due.dt.date
                >= current_date
            ]
            if not future_due.empty:
                earliest_due = (
                    future_due.min()
                    .date()
                    .isoformat()
                )

    snapshot_payload = (
        _competition_snapshot_payload(
            competition
        )
    )
    snapshot_hash = _canonical_hash(
        {
            "donor": _text(
                donor_name
            ),
            "comparison_amount_krw":
                _stable_decimal_text(
                    comparison_amount_krw,
                    places=2,
                ),
            "rows": snapshot_payload,
        }
    )

    return {
        "donor": _text(
            donor_name
        ),
        "comparison_amount_krw":
            max(
                0.0,
                float(
                    comparison_amount_krw
                    or 0.0
                ),
            ),
        "hold_eligibility":
            hold_eligibility,
        "hold_state":
            hold_state,
        "qualified_recipients":
            qualified,
        "review_recipients":
            review,
        "blocked_recipients":
            blocked,
        "ready_inputs":
            int(
                summary.get(
                    "ready_inputs",
                    0,
                )
                or 0
            ),
        "total_inputs":
            int(
                summary.get(
                    "total_inputs",
                    0,
                )
                or 0
            ),
        "donor_lifecycle":
            lifecycle,
        "donor_add_freeze":
            add_freeze,
        "existing_donor_action":
            existing_action,
        "earliest_assumption_review_due":
            earliest_due
            or "",
        "competition_snapshot_hash":
            snapshot_hash,
        "execution_authorization":
            "NONE",
    }


def capital_hold_governance_gate(
    context: dict,
    *,
    hold_reason: str,
    next_evidence_needed: str,
    hold_review_due_date: date | str | None,
    assumption_discipline_confirmed: bool,
    open_reviews_confirmed: bool,
    existing_action_confirmed: bool,
    human_confirmed: bool,
    today: date | None = None,
) -> dict:
    """
    Human governance for choosing not to reallocate new capital when no
    recipient qualifies.

    PASS means the hold/review state is documented.
    It never authorizes execution and never cancels existing donor risk actions.
    """
    current_date = today or date.today()
    ctx = context or {}

    issues = []

    if _text(
        ctx.get(
            "hold_eligibility"
        )
    ).upper() != "PASS":
        issues.append(
            "NO_QUALIFIED_RECIPIENT_CONDITION_NOT_MET"
        )

    if int(
        ctx.get(
            "qualified_recipients",
            0,
        )
        or 0
    ) > 0:
        issues.append(
            "QUALIFIED_RECIPIENT_EXISTS"
        )

    if not _text(
        hold_reason
    ):
        issues.append(
            "HOLD_REASON_REQUIRED"
        )

    if not _text(
        next_evidence_needed
    ):
        issues.append(
            "NEXT_EVIDENCE_REQUIRED"
        )

    due = None
    try:
        if isinstance(
            hold_review_due_date,
            date,
        ):
            due = hold_review_due_date
        else:
            parsed = pd.to_datetime(
                hold_review_due_date,
                errors="coerce",
            )
            if not pd.isna(
                parsed
            ):
                due = parsed.date()
    except Exception:
        due = None

    if due is None:
        issues.append(
            "HOLD_REVIEW_DUE_DATE_REQUIRED"
        )
        due_gate = "REVIEW"
    elif due <= current_date:
        issues.append(
            "HOLD_REVIEW_DUE_DATE_NOT_FUTURE"
        )
        due_gate = "REVIEW"
    else:
        due_gate = "PASS"

    earliest_assumption_due = pd.to_datetime(
        ctx.get(
            "earliest_assumption_review_due"
        ),
        errors="coerce",
    )
    if (
        due is not None
        and not pd.isna(
            earliest_assumption_due
        )
        and due
        > earliest_assumption_due.date()
    ):
        issues.append(
            "HOLD_REVIEW_AFTER_ASSUMPTION_EXPIRY"
        )
        due_gate = "REVIEW"

    if not _bool(
        assumption_discipline_confirmed
    ):
        issues.append(
            "ASSUMPTION_DISCIPLINE_CONFIRMATION_REQUIRED"
        )

    if (
        int(
            ctx.get(
                "review_recipients",
                0,
            )
            or 0
        )
        > 0
        and not _bool(
            open_reviews_confirmed
        )
    ):
        issues.append(
            "OPEN_RECIPIENT_REVIEWS_CONFIRMATION_REQUIRED"
        )

    if (
        _text(
            ctx.get(
                "existing_donor_action"
            )
        ).upper()
        != "NONE"
        and not _bool(
            existing_action_confirmed
        )
    ):
        issues.append(
            "EXISTING_DONOR_ACTION_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        human_confirmed
    ):
        issues.append(
            "HUMAN_HOLD_CONFIRMATION_REQUIRED"
        )

    gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    if gate == "PASS":
        final_decision = (
            "CAPITAL HOLD REVIEW COMPLETE"
        )
    else:
        final_decision = (
            "HUMAN REVIEW REQUIRED"
        )

    return {
        "governance_gate":
            gate,
        "final_decision":
            final_decision,
        "hold_review_due_date":
            due.isoformat()
            if due is not None
            else "",
        "review_due_gate":
            due_gate,
        "execution_authorization":
            "NONE",
        "issues":
            issues,
    }


def capital_hold_review_row(
    context: dict,
    governance: dict,
    *,
    hold_reason: str,
    next_evidence_needed: str,
    assumption_discipline_confirmed: bool,
    open_reviews_confirmed: bool,
    existing_action_confirmed: bool,
    human_confirmed: bool,
    note: str = "",
) -> dict:
    ctx = context or {}
    gov = governance or {}

    return {
        "reviewed_at":
            datetime.now().isoformat(),
        "donor":
            _text(
                ctx.get("donor")
            ),
        "comparison_amount_krw":
            float(
                _num(
                    ctx.get(
                        "comparison_amount_krw"
                    )
                )
                or 0.0
            ),
        "hold_eligibility":
            _text(
                ctx.get(
                    "hold_eligibility"
                )
            ),
        "hold_state":
            _text(
                ctx.get(
                    "hold_state"
                )
            ),
        "qualified_recipients":
            int(
                ctx.get(
                    "qualified_recipients",
                    0,
                )
                or 0
            ),
        "review_recipients":
            int(
                ctx.get(
                    "review_recipients",
                    0,
                )
                or 0
            ),
        "blocked_recipients":
            int(
                ctx.get(
                    "blocked_recipients",
                    0,
                )
                or 0
            ),
        "ready_inputs":
            int(
                ctx.get(
                    "ready_inputs",
                    0,
                )
                or 0
            ),
        "total_inputs":
            int(
                ctx.get(
                    "total_inputs",
                    0,
                )
                or 0
            ),
        "donor_lifecycle":
            _text(
                ctx.get(
                    "donor_lifecycle"
                )
            ),
        "donor_add_freeze":
            _text(
                ctx.get(
                    "donor_add_freeze"
                )
            ),
        "existing_donor_action":
            _text(
                ctx.get(
                    "existing_donor_action"
                )
            ),
        "earliest_assumption_review_due":
            _text(
                ctx.get(
                    "earliest_assumption_review_due"
                )
            ),
        "hold_review_due_date":
            _text(
                gov.get(
                    "hold_review_due_date"
                )
            ),
        "competition_snapshot_hash":
            _text(
                ctx.get(
                    "competition_snapshot_hash"
                )
            ),
        "hold_reason":
            _text(
                hold_reason
            ),
        "next_evidence_needed":
            _text(
                next_evidence_needed
            ),
        "assumption_discipline_confirmed":
            bool(
                assumption_discipline_confirmed
            ),
        "open_reviews_confirmed":
            bool(
                open_reviews_confirmed
            ),
        "existing_action_confirmed":
            bool(
                existing_action_confirmed
            ),
        "human_confirmed":
            bool(
                human_confirmed
            ),
        "governance_gate":
            _text(
                gov.get(
                    "governance_gate"
                )
            ),
        "final_decision":
            _text(
                gov.get(
                    "final_decision"
                )
            ),
        "execution_authorization":
            "NONE",
        "note":
            _text(
                note
            ),
    }
