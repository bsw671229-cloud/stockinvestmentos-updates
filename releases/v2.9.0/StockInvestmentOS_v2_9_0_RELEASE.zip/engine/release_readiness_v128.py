from __future__ import annotations

from datetime import date
from typing import Any

import pandas as pd

from engine.review_queue_compression import (
    compress_review_queue,
)
from engine.operations_carry_forward import (
    build_carry_forward_aging,
)
from engine.operations_recurrence import (
    build_recurrence_diagnostics,
)
from engine.operations_flow_efficiency import (
    flow_snapshot_integrity,
    latest_flow_snapshot,
)
from engine.operations_flow_trend import (
    flow_trend_snapshot_integrity,
    build_flow_trend,
)
from engine.operations_flow_evidence_quality import (
    build_flow_evidence_quality,
    build_closed_session_calibration_trend,
    apply_flow_evidence_guard,
)
from engine.operations_flow_calibration_promotion import (
    build_flow_calibration_promotion,
    apply_flow_calibration_promotion_guard,
)
from engine.operations_flow_calibration import (
    flow_calibration_snapshot_integrity,
    latest_flow_calibration_snapshot,
    build_flow_calibration,
)


FLOW_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


V128_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = 0
    ok = 0
    missing = 0
    mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def build_v128_flow_context(
    *,
    review_queue: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    flow_snapshots: pd.DataFrame | None,
    trend_snapshots: pd.DataFrame | None,
    calibration_snapshots: pd.DataFrame | None,
    today: date | str | None = None,
    capacity: int = 5,
) -> dict:
    compression = compress_review_queue(
        review_queue
    )

    carry_forward = build_carry_forward_aging(
        compression[
            "groups"
        ],
        sessions,
        today=today,
    )

    recurrence = build_recurrence_diagnostics(
        carry_forward[
            "table"
        ]
    )

    trend = build_flow_trend(
        recurrence[
            "table"
        ],
        trend_snapshots,
        capacity=capacity,
        forecast_min_snapshots=3,
        history_window=5,
    )

    calibration = build_flow_calibration(
        trend,
        recurrence[
            "table"
        ],
        trend_snapshots,
        capacity=capacity,
        min_saved_snapshots=3,
    )

    evidence_quality = build_flow_evidence_quality(
        trend_snapshots,
        sessions,
        min_qualified_endpoints=3,
    )
    qualified_trend_snapshots = evidence_quality[
        "qualified_trend_history"
    ]

    trend = build_flow_trend(
        recurrence["table"],
        qualified_trend_snapshots,
        capacity=capacity,
        forecast_min_snapshots=3,
        history_window=5,
    )

    calibration = build_flow_calibration(
        trend,
        recurrence["table"],
        qualified_trend_snapshots,
        capacity=capacity,
        min_saved_snapshots=3,
    )
    trend = build_closed_session_calibration_trend(
        trend,
        evidence_quality,
    )
    calibration = build_flow_calibration(
        trend,
        recurrence["table"],
        qualified_trend_snapshots,
        capacity=capacity,
        min_saved_snapshots=3,
        min_observed_intervals=2,
    )
    calibration = apply_flow_evidence_guard(
        calibration,
        evidence_quality,
    )
    calibration_promotion = build_flow_calibration_promotion(
        calibration,
        evidence_quality,
        min_promotion_intervals=3,
        min_positive_burn_ratio=2 / 3,
        max_negative_intervals=0,
    )
    calibration = apply_flow_calibration_promotion_guard(
        calibration,
        calibration_promotion,
    )

    latest_flow = latest_flow_snapshot(
        flow_snapshots
    )
    latest_calibration = latest_flow_calibration_snapshot(
        calibration_snapshots
    )

    flow_integrity = _integrity_counts(
        flow_snapshots,
        flow_snapshot_integrity,
    )
    trend_integrity = _integrity_counts(
        trend_snapshots,
        flow_trend_snapshot_integrity,
    )
    calibration_integrity = _integrity_counts(
        calibration_snapshots,
        flow_calibration_snapshot_integrity,
    )

    latest_flow_integrity = (
        flow_snapshot_integrity(
            latest_flow
        )[
            "status"
        ]
        if latest_flow
        else "NONE"
    )

    latest_calibration_integrity = (
        flow_calibration_snapshot_integrity(
            latest_calibration
        )[
            "status"
        ]
        if latest_calibration
        else "NONE"
    )

    return {
        "compression":
            compression,
        "carry_forward":
            carry_forward,
        "recurrence":
            recurrence,
        "trend":
            trend,
        "calibration":
            calibration,
        "calibration_promotion":
            calibration_promotion,
        "evidence_quality":
            evidence_quality,
        "latest_flow":
            latest_flow,
        "latest_flow_integrity":
            latest_flow_integrity,
        "latest_calibration":
            latest_calibration,
        "latest_calibration_integrity":
            latest_calibration_integrity,
        "flow_integrity":
            flow_integrity,
        "trend_integrity":
            trend_integrity,
        "calibration_integrity":
            calibration_integrity,
        "capacity":
            max(
                1,
                _int(
                    capacity
                ),
            ),
        "execution_authorization":
            "NONE",
    }


def _integrity_failure_count(
    counts: dict | None,
) -> int:
    values = counts or {}
    return (
        _int(
            values.get(
                "missing"
            )
        )
        + _int(
            values.get(
                "mismatch"
            )
        )
    )


def build_v128_flow_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    compression = ctx.get("compression") or {}
    recurrence = ctx.get("recurrence") or {}
    trend = ctx.get("trend") or {}
    calibration = ctx.get("calibration") or {}
    flow_counts = ctx.get("flow_integrity") or {}
    trend_counts = ctx.get("trend_integrity") or {}
    calibration_counts = ctx.get("calibration_integrity") or {}
    capacity = max(
        1,
        _int(
            ctx.get(
                "capacity"
            )
        ),
    )

    checks = []

    def technical(
        check: str,
        passed: bool,
        detail: str,
        action: str,
    ):
        checks.append(
            {
                "layer":
                    "TECHNICAL",
                "check":
                    check,
                "status":
                    "PASS"
                    if passed
                    else "FAIL",
                "detail":
                    detail,
                "action":
                    ""
                    if passed
                    else action,
            }
        )

    # 1. Review Flow immutable snapshots.
    flow_fail = _integrity_failure_count(
        flow_counts
    )
    technical(
        "Review Flow Snapshot Integrity",
        flow_fail == 0,
        (
            f"records {_int(flow_counts.get('total'))} · "
            f"OK {_int(flow_counts.get('ok'))} · "
            f"MISSING {_int(flow_counts.get('missing'))} · "
            f"MISMATCH {_int(flow_counts.get('mismatch'))}"
        ),
        "operations_flow_snapshots.csv immutable hash 확인",
    )

    # 2. Trend snapshots.
    trend_fail = _integrity_failure_count(
        trend_counts
    )
    technical(
        "Flow Trend Snapshot Integrity",
        trend_fail == 0,
        (
            f"records {_int(trend_counts.get('total'))} · "
            f"OK {_int(trend_counts.get('ok'))} · "
            f"MISSING {_int(trend_counts.get('missing'))} · "
            f"MISMATCH {_int(trend_counts.get('mismatch'))}"
        ),
        "operations_flow_trend_snapshots.csv immutable hash 확인",
    )

    # 3. Calibration snapshots.
    calibration_fail = _integrity_failure_count(
        calibration_counts
    )
    technical(
        "Flow Calibration Snapshot Integrity",
        calibration_fail == 0,
        (
            f"records {_int(calibration_counts.get('total'))} · "
            f"OK {_int(calibration_counts.get('ok'))} · "
            f"MISSING {_int(calibration_counts.get('missing'))} · "
            f"MISMATCH {_int(calibration_counts.get('mismatch'))}"
        ),
        "operations_flow_calibration_snapshots.csv immutable hash 확인",
    )

    # 4. Current live group-count consistency across the chain.
    action_groups = _int(
        compression.get(
            "action_groups"
        )
    )
    recurrence_table = recurrence.get(
        "table"
    )
    recurrence_groups = (
        int(
            len(
                recurrence_table
            )
        )
        if isinstance(
            recurrence_table,
            pd.DataFrame,
        )
        else -1
    )
    trend_groups = _int(
        trend.get(
            "current_groups"
        )
    )
    calibration_groups = _int(
        calibration.get(
            "current_groups"
        )
    )

    chain_consistent = (
        recurrence_groups
        == action_groups
        == trend_groups
        == calibration_groups
    )

    technical(
        "Review Flow Chain Group-count Consistency",
        chain_consistent,
        (
            f"action {action_groups} · "
            f"recurrence {recurrence_groups} · "
            f"trend {trend_groups} · "
            f"calibration {calibration_groups}"
        ),
        "Compression → Recurrence → Trend → Calibration group count 연결 확인",
    )

    # 5. Projection guard invariant.
    saved = _int(
        calibration.get(
            "saved_trend_snapshots"
        )
    )
    calibration_state = _text(
        calibration.get(
            "calibration_state"
        )
    ).upper()
    projection_guard = _text(
        calibration.get(
            "projection_guard"
        )
    ).upper()

    if saved < 3:
        guard_ok = (
            projection_guard
            == "HOLD_HISTORY"
            and calibration_state
            in {
                "INSUFFICIENT_HISTORY",
                "INSUFFICIENT_INTERVALS",
            }
        )
    elif calibration_state == "POSITIVE_BURN_CALIBRATED":
        promotion_state = _text(
            calibration.get(
                "promotion_state"
            )
        ).upper()
        if promotion_state == "PROMOTION_EVIDENCE_MATURING":
            guard_ok = (
                projection_guard
                == "HOLD_PROMOTION_PROOF"
            )
        elif promotion_state in {
            "PROMOTION_ADVERSE_INTERVAL_REVIEW",
            "PROMOTION_MIXED_BURN",
        }:
            guard_ok = (
                projection_guard
                == "HOLD_PROMOTION_STABILITY"
            )
        elif promotion_state == "PROMOTION_INTEGRITY_REVIEW":
            guard_ok = (
                projection_guard
                == "HOLD_INTEGRITY"
            )
        elif promotion_state == "PROMOTION_READY":
            guard_ok = (
                projection_guard
                == "ALLOW_PROJECTION_REVIEW"
            )
        else:
            # Backward-compatible legacy Calibration without v1.31 promotion.
            guard_ok = (
                projection_guard
                == "ALLOW_PROJECTION_REVIEW"
            )
    elif calibration_state == "NO_CLEARING_TREND":
        guard_ok = (
            projection_guard
            == "HOLD_NO_CLEARING"
        )
    elif calibration_state == "MIXED_BURN":
        guard_ok = (
            projection_guard
            == "HOLD_MIXED"
        )
    elif calibration_state == "INTEGRITY_REVIEW":
        guard_ok = (
            projection_guard
            == "HOLD_INTEGRITY"
        )
    else:
        guard_ok = False

    technical(
        "Flow Projection Guard Invariant",
        guard_ok,
        (
            f"saved {saved} · "
            f"calibration {calibration_state or 'MISSING'} · "
            f"guard {projection_guard or 'MISSING'}"
        ),
        "History / Calibration State와 Projection Guard 연결 확인",
    )

    # 6. Closed-session evidence / Calibration interval alignment.
    evidence_quality = ctx.get(
        "evidence_quality"
    ) or {}
    if evidence_quality:
        expected_intervals = _int(
            evidence_quality.get(
                "qualified_intervals"
            )
        )
        expected_endpoints = _int(
            evidence_quality.get(
                "qualified_endpoints"
            )
        )
        interval_alignment_ok = (
            saved == expected_endpoints
            and _int(
                calibration.get(
                    "observed_intervals"
                )
            )
            == expected_intervals
            and _text(
                calibration.get(
                    "calibration_interval_mode"
                )
            ).upper()
            == "CLOSED_SESSION_ONLY"
            and _text(
                calibration.get(
                    "interval_alignment_status"
                )
            ).upper()
            == "OK"
        )
        interval_detail = (
            f"endpoints {saved}/{expected_endpoints} · "
            f"intervals {_int(calibration.get('observed_intervals'))}/{expected_intervals} · "
            f"mode {_text(calibration.get('calibration_interval_mode')) or 'MISSING'} · "
            f"alignment {_text(calibration.get('interval_alignment_status')) or 'MISSING'}"
        )
    else:
        # Backward-compatible direct unit contexts may not carry v1.30 evidence.
        interval_alignment_ok = True
        interval_detail = "legacy context · evidence_quality unavailable"

    technical(
        "Closed-Session Calibration Interval Alignment",
        interval_alignment_ok,
        interval_detail,
        "Calibration 평균에서 LIVE interval이 제외되고 qualified closed-session interval과 일치하는지 확인",
    )

    # 7. Recent consecutive evidence / Capacity regime invariant.
    if evidence_quality:
        lifetime_endpoints = _int(
            evidence_quality.get(
                "lifetime_qualified_endpoints"
            )
        )
        recent_endpoints = _int(
            evidence_quality.get(
                "recent_consecutive_endpoints"
            )
        )
        regime_endpoints = _int(
            evidence_quality.get(
                "capacity_regime_endpoints"
            )
        )
        capacity_breaks = _int(
            evidence_quality.get(
                "capacity_regime_break_count"
            )
        )
        latest_boundary = _text(
            evidence_quality.get(
                "latest_boundary_status"
            )
        ).upper()
        window_state = _text(
            evidence_quality.get(
                "evidence_window_state"
            )
        ).upper()
        evidence_state = _text(
            evidence_quality.get(
                "evidence_state"
            )
        ).upper()
        min_endpoints = max(
            1,
            _int(
                evidence_quality.get(
                    "min_qualified_endpoints"
                )
            ),
        )

        window_ok = (
            lifetime_endpoints
            >= recent_endpoints
            >= regime_endpoints
            == expected_endpoints
        )

        if evidence_state == "INTEGRITY_REVIEW":
            window_ok = (
                window_ok
                and window_state == "INTEGRITY_REVIEW"
            )
        elif latest_boundary != "QUALIFIED":
            window_ok = (
                window_ok
                and expected_endpoints == 0
                and window_state == "RECENT_SESSION_GAP"
                and evidence_state == "CLOSED_SESSION_EVIDENCE_REQUIRED"
            )
        elif expected_endpoints >= min_endpoints:
            window_ok = (
                window_ok
                and window_state == "WINDOW_READY"
                and evidence_state == "EVIDENCE_READY"
            )
        elif capacity_breaks > 0:
            window_ok = (
                window_ok
                and window_state == "CAPACITY_REGIME_MATURING"
                and evidence_state == "EVIDENCE_MATURING"
            )
        else:
            window_ok = (
                window_ok
                and window_state == "CONSECUTIVE_WINDOW_MATURING"
                and evidence_state == "EVIDENCE_MATURING"
            )

        window_detail = (
            f"lifetime {lifetime_endpoints} · "
            f"consecutive {recent_endpoints} · "
            f"capacity regime {regime_endpoints} · "
            f"active {expected_endpoints} · "
            f"boundary {latest_boundary or 'MISSING'} · "
            f"window {window_state or 'MISSING'}"
        )
    else:
        window_ok = True
        window_detail = "legacy context · evidence_quality unavailable"

    technical(
        "Flow Evidence Window / Capacity Regime Invariant",
        window_ok,
        window_detail,
        (
            "Calibration evidence가 최근 연속 closed-session window와 최신 Capacity regime 안에만 "
            "존재하는지 확인"
        ),
    )

    # 8. Calibration promotion / Projection admission invariant.
    calibration_promotion = ctx.get(
        "calibration_promotion"
    ) or {}
    if calibration_promotion:
        promotion_state = _text(
            calibration_promotion.get(
                "promotion_state"
            )
        ).upper()
        promotion_effective_guard = _text(
            calibration_promotion.get(
                "effective_projection_guard"
            )
        ).upper()
        promotion_intervals = _int(
            calibration_promotion.get(
                "observed_intervals"
            )
        )
        promotion_target = max(
            1,
            _int(
                calibration_promotion.get(
                    "target_intervals"
                )
            ),
        )
        promotion_negative = _int(
            calibration_promotion.get(
                "negative_burn_intervals"
            )
        )

        promotion_ok = (
            promotion_intervals
            == _int(
                calibration.get(
                    "observed_intervals"
                )
            )
            and promotion_effective_guard
            == projection_guard
        )

        if promotion_state == "PROMOTION_READY":
            promotion_ok = (
                promotion_ok
                and promotion_intervals >= promotion_target
                and promotion_negative == 0
                and projection_guard == "ALLOW_PROJECTION_REVIEW"
            )
        elif promotion_state == "PROMOTION_EVIDENCE_MATURING":
            promotion_ok = (
                promotion_ok
                and promotion_intervals < promotion_target
            )
        elif promotion_state == "PROMOTION_INTEGRITY_REVIEW":
            promotion_ok = (
                promotion_ok
                and projection_guard == "HOLD_INTEGRITY"
            )
        elif promotion_state in {
            "PROMOTION_ADVERSE_INTERVAL_REVIEW",
            "PROMOTION_MIXED_BURN",
        }:
            promotion_ok = (
                promotion_ok
                and projection_guard in {
                    "HOLD_PROMOTION_STABILITY",
                    "HOLD_MIXED",
                    "HOLD_NO_CLEARING",
                }
            )
        elif promotion_state == "PROMOTION_NO_CLEARING":
            promotion_ok = (
                promotion_ok
                and projection_guard == "HOLD_NO_CLEARING"
            )
        else:
            promotion_ok = False

        promotion_detail = (
            f"state {promotion_state or 'MISSING'} · "
            f"intervals {promotion_intervals}/{promotion_target} · "
            f"negative {promotion_negative} · "
            f"guard {projection_guard or 'MISSING'}"
        )
    else:
        promotion_ok = True
        promotion_detail = "legacy context · calibration_promotion unavailable"

    technical(
        "Calibration Promotion / Projection Admission Invariant",
        promotion_ok,
        promotion_detail,
        (
            "Raw Calibration ALLOW 이후에도 closed-session promotion proof와 "
            "adverse interval guard가 일치하는지 확인"
        ),
    )

    # 9. Capacity efficiency arithmetic.
    attention = _int(
        calibration.get(
            "attention_groups"
        )
    )
    current_groups = _int(
        calibration.get(
            "current_groups"
        )
    )
    attention_pressure = _float(
        calibration.get(
            "attention_pressure"
        )
    )
    backlog_pressure = _float(
        calibration.get(
            "backlog_pressure"
        )
    )

    expected_attention_pressure = (
        attention
        / capacity
    )
    expected_backlog_pressure = (
        current_groups
        / capacity
    )

    arithmetic_ok = (
        abs(
            attention_pressure
            - expected_attention_pressure
        )
        < 1e-9
        and abs(
            backlog_pressure
            - expected_backlog_pressure
        )
        < 1e-9
    )

    technical(
        "Capacity Efficiency Arithmetic",
        arithmetic_ok,
        (
            f"attention {attention}/{capacity}="
            f"{attention_pressure:.2f}x · "
            f"backlog {current_groups}/{capacity}="
            f"{backlog_pressure:.2f}x"
        ),
        "Attention/Backlog Pressure 산식 확인",
    )

    # 10. Authorization invariant.
    auth_violations = 0

    if _text(
        ctx.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        auth_violations += 1

    for row in [
        ctx.get("latest_flow"),
        ctx.get("latest_calibration"),
    ]:
        if isinstance(
            row,
            dict,
        ) and row:
            if _text(
                row.get(
                    "execution_authorization"
                )
            ).upper() != "NONE":
                auth_violations += 1

    technical(
        "Operations Flow Execution Authorization Invariant",
        auth_violations == 0,
        (
            "NONE"
            if auth_violations == 0
            else f"non-NONE sources {auth_violations}"
        ),
        "Flow governance의 Execution Authorization을 NONE으로 유지",
    )

    technical_fail = sum(
        1
        for row in checks
        if (
            row[
                "layer"
            ]
            == "TECHNICAL"
            and row[
                "status"
            ]
            == "FAIL"
        )
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    # Operating state: history/calibration holds are normal reviews.
    if calibration_state == "POSITIVE_BURN_CALIBRATED":
        operating_status = "PASS"
    else:
        operating_status = "REVIEW"

    checks.append(
        {
            "layer":
                "OPERATING",
            "check":
                "Flow Calibration / Throughput Operating State",
            "status":
                operating_status,
            "detail":
                (
                    f"{calibration_state or 'MISSING'} · "
                    f"guard {projection_guard or 'MISSING'} · "
                    f"trend {_text(trend.get('trend_state')) or 'MISSING'} · "
                    f"groups {current_groups} · attention {attention}"
                ),
            "action":
                (
                    ""
                    if operating_status
                    == "PASS"
                    else (
                        "실제 Queue 변화가 생길 때 Trend Snapshot을 추가 축적하고 "
                        "원본 Review를 계속 검토"
                    )
                ),
        }
    )

    return {
        "release_gate":
            release_gate,
        "technical_pass":
            sum(
                1
                for row in checks
                if (
                    row[
                        "layer"
                    ]
                    == "TECHNICAL"
                    and row[
                        "status"
                    ]
                    == "PASS"
                )
            ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "calibration_state":
            calibration_state,
        "projection_guard":
            projection_guard,
        "latest_calibration_integrity":
            _text(
                ctx.get(
                    "latest_calibration_integrity"
                )
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                FLOW_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check":
            check,
        "status":
            "PASS"
            if passed
            else "BLOCKED",
        "detail":
            detail,
        "blocking":
            "NO"
            if passed
            else "YES",
    }


def build_v128_release_readiness(
    *,
    v127_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    flow_release_gate: str,
    flow_operating_status: str,
    execution_authorization: str,
) -> dict:
    v127 = _text(
        v127_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    flow_gate = _text(
        flow_release_gate
    ).upper()
    flow_operating = _text(
        flow_operating_status
    ).upper()
    execution_auth = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.27 Carry-forward / SLA Baseline",
            v127
            == "READY_FOR_RELEASE_REVIEW",
            v127
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration
            == "PASS",
            integration
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail
            == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Flow Technical Release Gate",
            flow_gate
            == "PASS",
            flow_gate
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution_auth
            == "NONE",
            execution_auth
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ]
        != "PASS"
    ]

    operating_reviews = []
    if (
        flow_operating
        and flow_operating
        != "PASS"
    ):
        operating_reviews.append(
            "FLOW_CALIBRATION_REVIEW"
        )

    return {
        "status":
            (
                "READY_FOR_RELEASE_REVIEW"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "blockers":
            blockers,
        "operating_review_count":
            len(
                operating_reviews
            ),
        "operating_reviews":
            operating_reviews,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V128_CANDIDATE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v128_integration_crosscheck(
    *,
    integration_consistency: str,
    flow_release_gate: str,
    latest_calibration_integrity: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    flow_gate = _text(
        flow_release_gate
    ).upper()
    calibration_integrity = _text(
        latest_calibration_integrity
    ).upper()

    calibration_ok = (
        calibration_integrity
        in {
            "OK",
            "NONE",
        }
    )

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration
            == "PASS",
            integration
            or "MISSING",
        ),
        _candidate_row(
            "Flow Technical Release Gate",
            flow_gate
            == "PASS",
            flow_gate
            or "MISSING",
        ),
        _candidate_row(
            "Latest Flow Calibration Snapshot Integrity",
            calibration_ok,
            calibration_integrity
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ]
        != "PASS"
    ]

    return {
        "status":
            (
                "PASS"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V128_CANDIDATE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v128_data_crosscheck(
    *,
    csv_fail_count: int,
    flow_release_gate: str,
    latest_calibration_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    flow_gate = _text(
        flow_release_gate
    ).upper()
    calibration_integrity = _text(
        latest_calibration_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail
            == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Flow Release Data Gate",
            flow_gate
            == "PASS",
            flow_gate
            or "MISSING",
        ),
        _candidate_row(
            "Latest Flow Calibration Snapshot Integrity",
            calibration_integrity
            in {
                "OK",
                "NONE",
            },
            calibration_integrity
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ]
        != "PASS"
    ]

    return {
        "status":
            (
                "PASS"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V128_CANDIDATE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }
