from __future__ import annotations

from pathlib import Path
import hashlib
import json
from typing import Any
import pandas as pd

from engine.operations_flow_live_change_outcome import (
    FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS,
    live_change_outcome_snapshot_integrity,
)
from engine.operations_flow_live_change_outcome_closure import (
    FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    LIVE_CHANGE_OUTCOME_CLOSURE_STATES,
    LIVE_CHANGE_CLOSURE_GUARD_BY_STATE,
    ROLLBACK_OUTCOME_STATES,
    build_flow_live_change_outcome_closure,
    live_change_outcome_closure_snapshot_integrity,
    latest_live_change_outcome_closure_snapshot,
)


LIVE_CHANGE_CLOSURE_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

LIVE_CHANGE_CLOSURE_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

WORK_READY_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V150_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


V149_RELEASE_ZIP_SHA256 = (
    "3290a31c719ae000dfa151f1d8bda5d79dd3a86e3c71b126f2191f32bd0ede32"
)

V149_RELEASE_MANIFEST_FILE_SHA256 = (
    "129b7af834d831217fb6009c7d4140b2a30af47ec0e5036da68097f25f4d1d73"
)

V149_RELEASE_NOTES_FILE_SHA256 = (
    "ba018eff23e1953f9afb8ec785d719c65e94d49cf4af623f6ba56b2d1e8d9f81"
)

V149_BASELINE_PROVENANCE_REL = "release_baselines/v1_49_0.json"


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def _sha256_path(
    path: Path,
) -> str:
    h = hashlib.sha256()

    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(
                1024 * 1024
            ),
            b"",
        ):
            h.update(chunk)

    return h.hexdigest()


def verify_v149_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(
        code_root
    ).resolve()

    provenance_path = (
        root
        / V149_BASELINE_PROVENANCE_REL
    )

    record_ok = False
    record_detail = ""
    record = {}

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            record_detail = (
                f"{type(exc).__name__}: {exc}"
            )
        else:
            record_ok = (
                _text(
                    record.get(
                        "release_version"
                    )
                )
                == "v1.49.0"
                and _text(
                    record.get(
                        "release_zip_sha256"
                    )
                ).lower()
                == V149_RELEASE_ZIP_SHA256
                and _text(
                    record.get(
                        "manifest_file_sha256"
                    )
                ).lower()
                == V149_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get(
                        "release_notes_file_sha256"
                    )
                ).lower()
                == V149_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get(
                        "provenance_status"
                    )
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )

            record_detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    manifest_path = (
        root
        / "manifest_sha256.json"
    )

    notes_path = (
        root
        / "RELEASE_NOTES_v1_49_0.txt"
    )

    legacy_manifest_ok = (
        manifest_path.is_file()
        and _sha256_path(
            manifest_path
        )
        == V149_RELEASE_MANIFEST_FILE_SHA256
    )

    legacy_notes_ok = (
        notes_path.is_file()
        and _sha256_path(
            notes_path
        )
        == V149_RELEASE_NOTES_FILE_SHA256
    )

    original_artifacts_ok = (
        legacy_manifest_ok
        and legacy_notes_ok
    )

    verified = (
        record_ok
        or original_artifacts_ok
    )

    source = (
        "PROVENANCE_RECORD"
        if record_ok
        else (
            "ORIGINAL_V149_RELEASE_ARTIFACTS"
            if original_artifacts_ok
            else "NONE"
        )
    )

    return {
        "status": (
            "VERIFIED"
            if verified
            else "BLOCKED"
        ),
        "verified": verified,
        "source": source,
        "record_path": str(
            provenance_path
        ),
        "record_detail": record_detail,
        "release_version": "v1.49.0",
        "release_zip_sha256":
            V149_RELEASE_ZIP_SHA256,
        "manifest_file_sha256":
            V149_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256":
            V149_RELEASE_NOTES_FILE_SHA256,
        "original_manifest_match":
            legacy_manifest_ok,
        "original_release_notes_match":
            legacy_notes_ok,
    }


def _safe_resolve(value: Any) -> Path | None:
    text = _text(value)

    if not text:
        return None

    try:
        return Path(text).resolve()
    except Exception:
        try:
            return Path(text).absolute()
        except Exception:
            return None


def _relative_to(
    child: Path | None,
    parent: Path | None,
) -> bool:
    if child is None or parent is None:
        return False

    try:
        child.relative_to(parent)
        return True
    except Exception:
        return False


def build_v150_live_change_closure_context(
    *,
    v149_context: dict | None,
    live_change_closure_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v149_context or {}
    outcome = upstream.get("outcome") or {}

    outcome_df = _ensure_cols(
        upstream.get("live_change_outcome_snapshots"),
        FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS,
    )

    closure_df = _ensure_cols(
        live_change_closure_snapshots,
        FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    )

    closure = build_flow_live_change_outcome_closure(
        outcome,
        outcome_df,
        closure_df,
    )

    latest_closure = latest_live_change_outcome_closure_snapshot(
        closure_df
    )

    latest_integrity = (
        _text(
            live_change_outcome_closure_snapshot_integrity(
                latest_closure
            ).get("status")
        ).upper()
        if latest_closure
        else "NONE"
    )

    return {
        "v149_context": upstream,
        "outcome": outcome,
        "live_change_outcome_snapshots": outcome_df,
        "live_change_closure_snapshots": closure_df,
        "closure": closure,
        "closure_integrity": _integrity_counts(
            closure_df,
            live_change_outcome_closure_snapshot_integrity,
        ),
        "latest_closure": latest_closure,
        "latest_closure_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def build_v150_work_ready_context(
    *,
    code_root: str | Path,
    layout: dict | None,
    release_manager_status: dict | None,
    migration_verify: dict | None,
) -> dict:
    root = _safe_resolve(code_root)
    layout_data = layout or {}
    status = release_manager_status or {}
    migration = migration_verify or {}

    critical = [
        "updater/release_manager.py",
        "updater/update_manager.py",
        "updater/SELF_UPDATE_POLICY.json",
        "updater/WORK_UPDATE_RUNBOOK.md",
        "migration/work_ready_paths.py",
        "migration/work_ready_migrator.py",
        "migration/migrate_work_ready.py",
        "migration/WORK_MIGRATION_RUNBOOK.md",
    ]

    critical_missing = []

    if root is not None:
        for rel in critical:
            if not (root / rel).is_file():
                critical_missing.append(rel)
    else:
        critical_missing = list(critical)

    return {
        "code_root": str(root) if root else "",
        "layout": layout_data,
        "release_manager_status": status,
        "migration_verify": migration,
        "critical_missing": critical_missing,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _closure_routing_ok(
    closure: dict,
    outcome: dict,
) -> bool:
    state = _text(
        closure.get("closure_state")
    ).upper()

    outcome_state = _text(
        outcome.get("outcome_state")
    ).upper()

    if outcome_state == "LIVE_CHANGE_OUTCOME_NOT_REQUIRED":
        return state == "LIVE_CHANGE_CLOSURE_NOT_REQUIRED"

    terminal = {
        "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
        "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
        *ROLLBACK_OUTCOME_STATES,
    }

    if outcome_state not in terminal:
        return state == "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT"

    return state in {
        "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED",
        "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
        "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED",
        "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED",
        "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED",
        "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
        "LIVE_CHANGE_CLOSURE_REJECTED",
        "LIVE_CHANGE_CLOSURE_DEFERRED",
        "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
    }


def _outcome_source_mapping_ok(
    context: dict,
) -> bool:
    closure = context.get("closure") or {}
    state = _text(
        closure.get("closure_state")
    ).upper()

    source_id = _text(
        closure.get("source_live_change_outcome_id")
    )
    source_hash = _text(
        closure.get("source_live_change_outcome_hash")
    )

    if state in {
        "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT",
        "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
    }:
        return not source_id and not source_hash

    if state == "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED":
        return not source_id and not source_hash

    if not source_id or not source_hash:
        return False

    index, duplicates = _index_by_id(
        context.get("live_change_outcome_snapshots"),
        "live_change_outcome_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(source_id)

    if not parent:
        return False

    if _text(
        live_change_outcome_snapshot_integrity(
            parent
        ).get("status")
    ).upper() != "OK":
        return state == "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW"

    return (
        _text(parent.get("snapshot_hash"))
        == source_hash
    )


def _decision_contract_ok(
    closure: dict,
) -> bool:
    state = _text(
        closure.get("closure_state")
    ).upper()

    decision = _text(
        closure.get("decision")
    ).upper()

    permission = _text(
        closure.get("permanent_change_design_permission")
    ).upper() or "NONE"

    outcome_state = _text(
        closure.get("outcome_state")
    ).upper()

    no_decision_states = {
        "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT",
        "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
        "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED",
        "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
        "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED",
        "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED",
        "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED",
    }

    if state in no_decision_states:
        return (
            decision == ""
            and permission == "NONE"
        )

    if state == "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW":
        return (
            decision
            == "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
            and outcome_state
            == "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION"
            and permission
            == "PERMANENT_DESIGN_REVIEW_ONLY"
        )

    if state == "LIVE_CHANGE_CLOSURE_REJECTED":
        return (
            decision == "REJECT"
            and permission == "NONE"
            and outcome_state
            in {
                "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
                "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
            }
        )

    if state == "LIVE_CHANGE_CLOSURE_DEFERRED":
        return (
            decision == "DEFER"
            and permission == "NONE"
            and outcome_state
            in {
                "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
                "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
            }
        )

    if state == "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED":
        return (
            decision == "ROLLBACK_CLOSED"
            and permission == "NONE"
            and outcome_state in ROLLBACK_OUTCOME_STATES
        )

    return False


def _rollback_contract_ok(
    closure: dict,
) -> bool:
    state = _text(
        closure.get("closure_state")
    ).upper()

    outcome_state = _text(
        closure.get("outcome_state")
    ).upper()

    if state == "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED":
        return (
            outcome_state in ROLLBACK_OUTCOME_STATES
            and _bool(
                closure.get("rollback_required")
            )
        )

    if state != "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED":
        return True

    latest = closure.get("latest_closure") or {}

    required = [
        "rollback_completed_confirmed",
        "prior_baseline_restored_confirmed",
        "rollback_integrity_verified",
        "postmortem_reviewed",
        "no_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    return (
        outcome_state in ROLLBACK_OUTCOME_STATES
        and all(
            _bool(
                latest.get(field)
            )
            for field in required
        )
        and len(
            _text(
                latest.get("rollback_detail")
            )
        )
        >= 50
    )


def _time_order_ok(
    closure: dict,
) -> bool:
    latest = closure.get("latest_closure") or {}

    if not latest:
        return True

    source_ts = pd.to_datetime(
        closure.get(
            "source_live_change_outcome_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    closure_ts = pd.to_datetime(
        latest.get("created_at"),
        errors="coerce",
        utc=True,
    )

    return (
        not pd.isna(source_ts)
        and not pd.isna(closure_ts)
        and closure_ts > source_ts
    )


def _no_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("closure") or {},
        context.get("latest_closure") or {},
        context.get("outcome") or {},
    ]:
        for field in [
            "live_change_closure_authorization",
            "permanent_change_review_authorization",
            "permanent_change_authorization",
            "live_change_outcome_authorization",
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "live_change_closure_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "live_change_closure_authorization",
            "permanent_change_review_authorization",
            "permanent_change_authorization",
            "live_change_outcome_authorization",
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    return (
        violations == 0
        and _text(
            context.get("execution_authorization")
        ).upper()
        == "NONE"
    )


def build_v150_live_change_closure_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    closure = ctx.get("closure") or {}
    outcome = ctx.get("outcome") or {}
    counts = ctx.get("closure_integrity") or {}

    state = _text(
        closure.get("closure_state")
    ).upper()

    guard = _text(
        closure.get("closure_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Live Change Closure Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Closure immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Closure State / Guard Vocabulary",
            (
                state in LIVE_CHANGE_OUTCOME_CLOSURE_STATES
                and guard
                == LIVE_CHANGE_CLOSURE_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {LIVE_CHANGE_CLOSURE_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Closure state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Outcome → Closure State Invariant",
            _closure_routing_ok(
                closure,
                outcome,
            ),
            (
                f"outcome {_text(outcome.get('outcome_state')) or 'MISSING'} · "
                f"closure {state or 'MISSING'}"
            ),
            "terminal Outcome과 Closure state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Closure → Immutable Outcome Source Mapping",
            _outcome_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"outcome source {_text(closure.get('source_live_change_outcome_id')) or 'NONE'} · "
                f"integrity {_text(closure.get('source_live_change_outcome_integrity')) or 'NONE'}"
            ),
            "Closure source Outcome id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Human Permanent Adoption Decision Contract",
            _decision_contract_ok(
                closure
            ),
            (
                f"state {state or 'MISSING'} · "
                f"decision {_text(closure.get('decision')) or 'NONE'} · "
                f"permission {_text(closure.get('permanent_change_design_permission')) or 'NONE'}"
            ),
            "PASS/INCONCLUSIVE/rollback 상태별 Human decision 및 design-review-only permission 확인",
        )
    )

    checks.append(
        _technical_row(
            "Rollback Closure Contract",
            _rollback_contract_ok(
                closure
            ),
            (
                f"state {state or 'MISSING'} · "
                f"rollback {_bool(closure.get('rollback_required'))} · "
                f"kill {_text(closure.get('kill_switch_trigger')) or 'NONE'}"
            ),
            "rollback 완료/baseline 복원/integrity/post-mortem 확인",
        )
    )

    checks.append(
        _technical_row(
            "Closure Time-order / Supersession Invariant",
            _time_order_ok(
                closure
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(closure.get('source_live_change_outcome_created_at')) or 'NONE'} · "
                f"latest {_text((ctx.get('latest_closure') or {}).get('created_at')) or 'NONE'}"
            ),
            "Outcome audit 이후 Closure 저장 및 supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "No-Permanent-Apply / No-Execution Authorization Invariant",
            _no_authorization_ok(
                ctx
            ),
            "NONE",
            "Permanent Change/Closure/Outcome/Runtime/Apply/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state in {
            "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
            "LIVE_CHANGE_CLOSURE_REJECTED",
            "LIVE_CHANGE_CLOSURE_DEFERRED",
            "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Closure Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"decision {_text(closure.get('decision')) or 'NONE'} · "
                f"permission {_text(closure.get('permanent_change_design_permission')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream/audit/human-review/accepted 상태는 Technical FAIL로 승격하지 않고 "
                    "Human Closure evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "closure_state": state,
        "outcome_state": _text(
            outcome.get("outcome_state")
        ).upper(),
        "latest_live_change_closure_integrity":
            _text(
                ctx.get("latest_closure_integrity")
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_CLOSURE_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_closure_contract_ok(
    item: dict,
) -> bool:
    state = _text(
        item.get("closure_state")
    ).upper()

    guard = _text(
        item.get("closure_guard")
    ).upper()

    if (
        state not in LIVE_CHANGE_OUTCOME_CLOSURE_STATES
        or guard
        != LIVE_CHANGE_CLOSURE_GUARD_BY_STATE.get(
            state,
            "",
        )
    ):
        return False

    if _text(
        item.get("live_change_closure_authorization")
    ).upper() not in {"", "NONE"}:
        return False

    if _text(
        item.get("permanent_change_review_authorization")
    ).upper() not in {"", "NONE"}:
        return False

    if _text(
        item.get("permanent_change_authorization")
    ).upper() not in {"", "NONE"}:
        return False

    decision = _text(
        item.get("decision")
    ).upper()

    if decision == "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW":
        return (
            state
            == "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
            and _text(
                item.get("outcome_state")
            ).upper()
            == "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION"
            and _text(
                item.get("permanent_change_design_permission")
            ).upper()
            == "PERMANENT_DESIGN_REVIEW_ONLY"
            and _bool(
                item.get("permanent_design_review_only_confirmed")
            )
            and _bool(
                item.get("no_permanent_apply_confirmed")
            )
        )

    if decision in {"REJECT", "DEFER"}:
        return (
            _text(
                item.get("permanent_change_design_permission")
            ).upper()
            in {"", "NONE"}
            and _text(
                item.get("outcome_state")
            ).upper()
            in {
                "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
                "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
            }
        )

    if decision == "ROLLBACK_CLOSED":
        required = [
            "rollback_completed_confirmed",
            "prior_baseline_restored_confirmed",
            "rollback_integrity_verified",
            "postmortem_reviewed",
            "no_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        return (
            state
            == "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED"
            and _text(
                item.get("outcome_state")
            ).upper()
            in ROLLBACK_OUTCOME_STATES
            and all(
                _bool(
                    item.get(field)
                )
                for field in required
            )
            and len(
                _text(
                    item.get("rollback_detail")
                )
            )
            >= 50
        )

    return False


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v150_live_change_closure_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    closure_df = _ensure_cols(
        ctx.get("live_change_closure_snapshots"),
        FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    )

    outcome_df = _ensure_cols(
        ctx.get("live_change_outcome_snapshots"),
        FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        closure_df,
        live_change_outcome_closure_snapshot_integrity,
    )

    outcome_index, outcome_duplicates = _index_by_id(
        outcome_df,
        "live_change_outcome_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in closure_df.iterrows():
        item = row.to_dict()

        closure_id = _text(
            item.get("live_change_outcome_closure_id")
        )

        if closure_id:
            if closure_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(closure_id)

        if not _saved_closure_contract_ok(
            item
        ):
            contract_violations += 1

        source_id = _text(
            item.get("source_live_change_outcome_id")
        )
        source_hash = _text(
            item.get("source_live_change_outcome_hash")
        )

        parent = outcome_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                live_change_outcome_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )

            closure_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(closure_ts)
                or closure_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "live_change_closure_authorization",
            "permanent_change_review_authorization",
            "permanent_change_authorization",
            "live_change_outcome_authorization",
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Live Change Closure Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Closure immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Closure Audit Human Decision / Rollback Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "ACCEPT/REJECT/DEFER/ROLLBACK_CLOSED 확인 contract 검토",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Closure Audit → Outcome Lineage",
            (
                lineage_violations == 0
                and outcome_duplicates == 0
            ),
            (
                f"lineage violations {lineage_violations} · "
                f"outcome duplicate ids {outcome_duplicates}"
            ),
            "Closure source immutable Outcome id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Closure Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate closure ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Closure audit identity uniqueness 및 Outcome audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Closure Audit No-Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else f"non-NONE sources {authorization_violations}"
            ),
            "Permanent Change/Closure/Outcome/Runtime/Apply/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("closure") or {}).get(
            "closure_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state in {
            "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
            "LIVE_CHANGE_CLOSURE_REJECTED",
            "LIVE_CHANGE_CLOSURE_DEFERRED",
            "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Closure Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current closure {current_state or 'MISSING'} · "
                f"saved closures {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 terminal Live Change Outcome audit 이후 Human Closure decision이 생길 때만 "
                    "immutable Closure history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_CLOSURE_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v150_work_ready_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    layout = ctx.get("layout") or {}
    status = ctx.get("release_manager_status") or {}
    migration = ctx.get("migration_verify") or {}

    root = _safe_resolve(
        ctx.get("code_root")
    )

    work_root = _safe_resolve(
        layout.get("work_root")
    )

    code_root = _safe_resolve(
        layout.get("code_root")
    )

    runtime_root = _safe_resolve(
        layout.get("runtime_data_root")
    )

    secrets_root = _safe_resolve(
        layout.get("secrets_root")
    )

    control_root = _safe_resolve(
        layout.get("control_root")
    )

    status_control = _safe_resolve(
        (status.get("paths") or {}).get(
            "control"
        )
    )

    layout_ok = (
        bool(
            layout.get("active")
        )
        and _text(
            layout.get("mode")
        ).upper()
        == "WORK_READY_SEPARATED"
        and root is not None
        and code_root == root
        and work_root is not None
        and _relative_to(
            code_root,
            work_root,
        )
    )

    separation_ok = (
        work_root is not None
        and runtime_root is not None
        and secrets_root is not None
        and not _relative_to(
            runtime_root,
            work_root,
        )
        and not _relative_to(
            secrets_root,
            work_root,
        )
    )

    migration_checks = migration.get(
        "checks"
    ) or {}

    required_migration_checks = [
        "layout_config",
        "migration_transfer_receipt",
        "code_integrity",
        "runtime_data_integrity",
        "secrets_integrity",
        "data_compatibility_link",
        "data_secrets_separation",
        "launcher",
        "migration_receipt",
    ]

    migration_ok = (
        _text(
            migration.get("status")
        ).upper()
        == "READY_FOR_WORK_CUTOVER"
        and all(
            _text(
                migration_checks.get(name)
            ).upper()
            == "PASS"
            for name in required_migration_checks
        )
    )

    managed_clean = bool(
        status.get(
            "managed_code_clean"
        )
    )

    control_routing_ok = (
        control_root is not None
        and status_control is not None
        and control_root == status_control
        and work_root is not None
        and _relative_to(
            control_root,
            work_root,
        )
    )

    critical_missing = ctx.get(
        "critical_missing"
    ) or []

    checks = [
        _technical_row(
            "Work-ready Layout / Canonical Code Root",
            layout_ok,
            (
                f"active {bool(layout.get('active'))} · "
                f"mode {_text(layout.get('mode')) or 'MISSING'} · "
                f"code {_text(layout.get('code_root')) or 'MISSING'}"
            ),
            "WORK_READY_SEPARATED layout 및 canonical code root 확인",
        ),
        _technical_row(
            "Runtime Data / Secrets Physical Separation",
            separation_ok,
            (
                f"work {_text(layout.get('work_root')) or 'MISSING'} · "
                f"runtime {_text(layout.get('runtime_data_root')) or 'MISSING'} · "
                f"secrets {_text(layout.get('secrets_root')) or 'MISSING'}"
            ),
            "runtime-data/secrets를 Work root 밖에 유지",
        ),
        _technical_row(
            "Migration Integrity / Launcher Gate",
            migration_ok,
            (
                f"status {_text(migration.get('status')) or 'MISSING'} · "
                f"checks {len(required_migration_checks)}"
            ),
            "Migration Integrity 및 launcher 재검증",
        ),
        _technical_row(
            "Release Manager Managed Code CLEAN",
            managed_clean,
            (
                f"version {_text(status.get('current_version')) or 'MISSING'} · "
                f"clean {managed_clean} · "
                f"manifest entries {_int(status.get('managed_manifest_entries'))}"
            ),
            "Managed Code drift를 먼저 복구",
        ),
        _technical_row(
            "Release Manager Control Root Routing",
            control_routing_ok,
            (
                f"layout {_text(layout.get('control_root')) or 'MISSING'} · "
                f"status {_text((status.get('paths') or {}).get('control')) or 'MISSING'}"
            ),
            "Release Manager control root를 work/control로 일치",
        ),
        _technical_row(
            "Updater / Migration Critical Files",
            len(critical_missing) == 0,
            (
                "PRESENT"
                if not critical_missing
                else "missing " + ", ".join(
                    critical_missing[:10]
                )
            ),
            "Updater/Migration self-preservation critical files 복구",
        ),
    ]

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    last_state = status.get(
        "last_state"
    ) or {}

    restart_required = bool(
        last_state.get(
            "restart_required"
        )
    )

    approved_eligible = _int(
        status.get(
            "approved_eligible_count"
        )
    )

    operating_status = (
        "PASS"
        if (
            not restart_required
            and approved_eligible == 0
        )
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Work-ready Release Manager Operating State",
            "status": operating_status,
            "detail": (
                f"approved eligible {approved_eligible} · "
                f"restart required {restart_required}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else "승인 대기 release 또는 restart-required 상태를 운영 절차로 처리"
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "managed_code_clean": managed_clean,
        "migration_status": _text(
            migration.get("status")
        ).upper() or "MISSING",
        "checks": pd.DataFrame(
            checks,
            columns=WORK_READY_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v150_release_readiness(
    *,
    v149_release_status: str,
    v149_baseline_provenance: dict | None,
    integration_consistency: str,
    csv_fail_count: int,
    closure_release_gate: str,
    closure_audit_gate: str,
    work_ready_release_gate: str,
    closure_operating_status: str,
    audit_operating_status: str,
    work_ready_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.49 Immutable Release Baseline Provenance",
            bool(
                (
                    v149_baseline_provenance
                    or {}
                ).get(
                    "verified"
                )
            ),
            (
                f"{_text((v149_baseline_provenance or {}).get('status')) or 'MISSING'} · "
                f"source {_text((v149_baseline_provenance or {}).get('source')) or 'NONE'} · "
                f"dynamic-v1.49 {_text(v149_release_status).upper() or 'MISSING'}"
            ),
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(integration_consistency).upper()
            == "PASS",
            _text(integration_consistency).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Human Permanent Adoption Closure Technical Gate",
            _text(closure_release_gate).upper()
            == "PASS",
            _text(closure_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Human Permanent Adoption Closure Audit Gate",
            _text(closure_audit_gate).upper()
            == "PASS",
            _text(closure_audit_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Software Update Safety Gate",
            _text(work_ready_release_gate).upper()
            == "PASS",
            _text(work_ready_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(execution_authorization).upper()
            == "NONE",
            _text(execution_authorization).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            closure_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "LIVE_CHANGE_CLOSURE_REVIEW"
        )

    if _text(
        work_ready_operating_status
    ).upper() != "PASS":
        operating_reviews.append(
            "WORK_READY_RELEASE_MANAGER_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V150_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v150_integration_crosscheck(
    *,
    integration_consistency: str,
    closure_release_gate: str,
    closure_audit_gate: str,
    work_ready_release_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(integration_consistency).upper()
            == "PASS",
            _text(integration_consistency).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Closure Technical Gate",
            _text(closure_release_gate).upper()
            == "PASS",
            _text(closure_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Closure Audit Gate",
            _text(closure_audit_gate).upper()
            == "PASS",
            _text(closure_audit_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(work_ready_release_gate).upper()
            == "PASS",
            _text(work_ready_release_gate).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V150_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v150_data_crosscheck(
    *,
    csv_fail_count: int,
    closure_release_gate: str,
    closure_audit_gate: str,
    work_ready_release_gate: str,
    latest_closure_integrity: str,
) -> dict:
    latest = _text(
        latest_closure_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Closure Technical Gate",
            _text(closure_release_gate).upper()
            == "PASS",
            _text(closure_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Closure Audit Gate",
            _text(closure_audit_gate).upper()
            == "PASS",
            _text(closure_audit_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(work_ready_release_gate).upper()
            == "PASS",
            _text(work_ready_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Live Change Closure Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V150_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
