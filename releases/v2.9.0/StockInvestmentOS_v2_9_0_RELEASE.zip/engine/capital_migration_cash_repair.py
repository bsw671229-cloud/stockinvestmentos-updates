from __future__ import annotations

from datetime import datetime
from typing import Any
import math
import hashlib
import json

import pandas as pd


CASH_REPAIR_REVIEW_COLS = [
    "reviewed_at",
    "donor",
    "recipient",
    "donor_kind",
    "recipient_kind",
    "current_cash_krw",
    "minimum_cash_krw",
    "cash_shortfall_krw",
    "taxable_gain_fraction",
    "capital_gains_tax_rate",
    "sell_transaction_tax_rate",
    "sell_execution_cost_rate",
    "buy_execution_cost_rate",
    "fx_other_cost_rate",
    "step1_sell_friction_rate",
    "step1_required_gross_trim_krw",
    "step1_estimated_cost_krw",
    "step1_net_cash_added_krw",
    "post_step1_cash_krw",
    "step1_cash_repair_gate",
    "donor_available_krw",
    "residual_donor_capacity_krw",
    "recipient_headroom_krw",
    "step2_total_friction_rate",
    "step2_max_gross_donor_krw",
    "step2_max_net_recipient_krw",
    "recipient_hurdle_spread",
    "bridge_mapping_gate",
    "recipient_operational_gate",
    "step2_recipient_gate",
    "two_step_status",
    "execution_authorization",
    "issues",
    "note",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _gate_pass(value: Any) -> bool:
    return _text(value).upper() in {
        "PASS",
        "OFF",
        "CASH",
        "N/A",
    }


def _bounded_rate(value: Any) -> float:
    number = _num(value)
    if number is None:
        return 0.0
    return min(
        1.0,
        max(
            0.0,
            float(number),
        ),
    )


def build_cash_reserve_repair_plan(
    *,
    total_assets: float,
    current_cash_krw: float,
    minimum_cash_weight: float,
    donor_name: str,
    donor_kind: str,
    donor_available_krw: float,
    recipient_name: str,
    recipient_kind: str,
    recipient_headroom_krw: float,
    taxable_gain_fraction: float,
    capital_gains_tax_rate: float,
    sell_transaction_tax_rate: float,
    sell_execution_cost_rate: float,
    buy_execution_cost_rate: float,
    fx_other_cost_rate: float,
    recipient_hurdle_spread: float | None,
    bridge_mapping_gate: str,
    recipient_lifecycle_gate: str,
    recipient_execution_gate: str,
    recipient_add_freeze_gate: str,
    recipient_survival_gate: str,
    recipient_fit_gate: str,
) -> dict:
    """
    Two-step diagnostic:
      Step 1: gross donor trim required to restore minimum KRW cash reserve.
      Step 2: after Step 1, maximum donor gross / recipient net capital that
              could still be reviewed, constrained by donor residual and
              recipient headroom.

    This is a planning lower-bound/upper-bound diagnostic only.
    It does not authorize or recommend an order.
    """
    assets = max(
        0.0,
        float(
            total_assets
            or 0.0
        ),
    )
    current_cash = max(
        0.0,
        float(
            current_cash_krw
            or 0.0
        ),
    )
    min_cash_weight = min(
        1.0,
        max(
            0.0,
            float(
                minimum_cash_weight
                or 0.0
            ),
        ),
    )
    donor_available = max(
        0.0,
        float(
            donor_available_krw
            or 0.0
        ),
    )
    recipient_headroom = max(
        0.0,
        float(
            recipient_headroom_krw
            or 0.0
        ),
    )

    minimum_cash = (
        assets
        * min_cash_weight
    )
    cash_shortfall = max(
        0.0,
        minimum_cash
        - current_cash,
    )

    taxable_fraction = _bounded_rate(
        taxable_gain_fraction
    )
    cap_gains_rate = _bounded_rate(
        capital_gains_tax_rate
    )
    sell_tax_rate = _bounded_rate(
        sell_transaction_tax_rate
    )
    sell_exec_rate = _bounded_rate(
        sell_execution_cost_rate
    )
    buy_exec_rate = _bounded_rate(
        buy_execution_cost_rate
    )
    fx_rate = _bounded_rate(
        fx_other_cost_rate
    )

    # For a donor->KRW cash repair, sell-side tax / execution / FX-other drag
    # reduces the net cash that arrives.
    step1_sell_friction = (
        taxable_fraction
        * cap_gains_rate
        + sell_tax_rate
        + sell_exec_rate
        + fx_rate
    )
    step1_net_factor = (
        1.0
        - step1_sell_friction
    )

    issues = []

    donor_kind_text = _text(
        donor_kind
    ).upper()
    recipient_kind_text = _text(
        recipient_kind
    ).upper()

    if cash_shortfall <= 1e-9:
        required_gross = 0.0
        actual_gross = 0.0
        step1_cost = 0.0
        net_cash_added = 0.0
        post_step1_cash = current_cash
        step1_gate = "ALREADY_PASS"
    elif donor_kind_text == "CASH":
        required_gross = None
        actual_gross = 0.0
        step1_cost = 0.0
        net_cash_added = 0.0
        post_step1_cash = current_cash
        step1_gate = "BLOCKED"
        issues.append(
            "CASH_DONOR_CANNOT_REPAIR_CASH_SHORTFALL"
        )
    elif step1_net_factor <= 0.0:
        required_gross = None
        actual_gross = 0.0
        step1_cost = 0.0
        net_cash_added = 0.0
        post_step1_cash = current_cash
        step1_gate = "BLOCKED"
        issues.append(
            "SELL_FRICTION_RATE_NOT_FEASIBLE"
        )
    else:
        # Ceil to whole KRW so projected net proceeds do not undershoot the
        # required reserve because of fractional KRW arithmetic.
        required_gross = float(
            math.ceil(
                cash_shortfall
                / step1_net_factor
            )
        )
        actual_gross = min(
            donor_available,
            required_gross,
        )
        net_cash_added = (
            actual_gross
            * step1_net_factor
        )
        step1_cost = (
            actual_gross
            - net_cash_added
        )
        post_step1_cash = (
            current_cash
            + net_cash_added
        )

        if (
            donor_available
            + 1e-9
            < required_gross
        ):
            step1_gate = "BLOCKED"
            issues.append(
                "DONOR_CAPACITY_INSUFFICIENT_FOR_CASH_REPAIR"
            )
        elif (
            post_step1_cash
            + 1e-6
            < minimum_cash
        ):
            step1_gate = "REVIEW"
            issues.append(
                "PROJECTED_CASH_REPAIR_BELOW_MINIMUM"
            )
        else:
            step1_gate = "PASS"

    gross_for_residual = (
        0.0
        if required_gross is None
        else min(
            donor_available,
            required_gross,
        )
    )
    residual_donor = max(
        0.0,
        donor_available
        - gross_for_residual,
    )

    # Step 2 is a full donor->recipient switch. Reuse the same cost structure
    # as Migration 2.0 at a rate level.
    step2_total_friction = (
        taxable_fraction
        * cap_gains_rate
        + sell_tax_rate
        + sell_exec_rate
        + buy_exec_rate
        + fx_rate
    )
    step2_net_factor = (
        1.0
        - step2_total_friction
    )

    step2_issues = []

    if recipient_kind_text == "CASH":
        step2_max_gross = 0.0
        step2_max_net = 0.0
        recipient_operational_gate = "N/A"
        step2_gate = "N/A"
        step2_issues.append(
            "RECIPIENT_IS_CASH"
        )
    elif step1_gate not in {
        "PASS",
        "ALREADY_PASS",
    }:
        step2_max_gross = 0.0
        step2_max_net = 0.0
        recipient_operational_gate = "REVIEW"
        step2_gate = "REVIEW"
        step2_issues.append(
            "CASH_REPAIR_NOT_READY"
        )
    elif step2_net_factor <= 0.0:
        step2_max_gross = 0.0
        step2_max_net = 0.0
        recipient_operational_gate = "REVIEW"
        step2_gate = "BLOCKED"
        step2_issues.append(
            "STEP2_FRICTION_RATE_NOT_FEASIBLE"
        )
    else:
        if recipient_headroom <= 0.0:
            gross_for_headroom = 0.0
        else:
            gross_for_headroom = (
                recipient_headroom
                / step2_net_factor
            )

        step2_max_gross = max(
            0.0,
            min(
                residual_donor,
                gross_for_headroom,
            ),
        )
        step2_max_net = (
            step2_max_gross
            * step2_net_factor
        )

        operational_values = [
            recipient_lifecycle_gate,
            recipient_execution_gate,
            recipient_add_freeze_gate,
            recipient_survival_gate,
            recipient_fit_gate,
        ]
        operational_bad = [
            _text(value).upper()
            for value in operational_values
            if not _gate_pass(value)
        ]
        recipient_operational_gate = (
            "PASS"
            if not operational_bad
            else "REVIEW"
        )
        if operational_bad:
            step2_issues.append(
                "RECIPIENT_OPERATIONAL_GATE_NOT_PASS"
            )

        hurdle_spread = _num(
            recipient_hurdle_spread
        )
        if hurdle_spread is None:
            step2_issues.append(
                "RECIPIENT_HURDLE_SPREAD_REQUIRED"
            )
        elif hurdle_spread < 0.0:
            step2_issues.append(
                "RECIPIENT_HURDLE_SPREAD_NEGATIVE"
            )

        if _text(
            bridge_mapping_gate
        ).upper() != "PASS":
            step2_issues.append(
                "ASSUMPTION_BRIDGE_NOT_PASS"
            )

        if step2_max_gross <= 0.0:
            step2_issues.append(
                "NO_RESIDUAL_RECIPIENT_CAPACITY"
            )

        step2_gate = (
            "PASS"
            if not step2_issues
            else "REVIEW"
        )

    if step1_gate == "ALREADY_PASS":
        step1_label = "CASH_RESERVE_ALREADY_PASS"
    elif step1_gate == "PASS":
        step1_label = "CASH_REPAIR_READY"
    else:
        step1_label = "CASH_REPAIR_NOT_READY"

    if step2_gate == "PASS":
        two_step_status = (
            step1_label
            + " / RECIPIENT_PILOT_REVIEW_READY"
        )
    elif step2_gate == "N/A":
        two_step_status = (
            step1_label
            + " / CASH_ONLY"
        )
    else:
        two_step_status = (
            step1_label
            + " / RECIPIENT_REVIEW"
        )

    all_issues = list(
        dict.fromkeys(
            issues
            + step2_issues
        )
    )

    return {
        "donor":
            _text(donor_name),
        "recipient":
            _text(recipient_name),
        "donor_kind":
            donor_kind_text,
        "recipient_kind":
            recipient_kind_text,
        "current_cash_krw":
            current_cash,
        "minimum_cash_krw":
            minimum_cash,
        "cash_shortfall_krw":
            cash_shortfall,
        "taxable_gain_fraction":
            taxable_fraction,
        "capital_gains_tax_rate":
            cap_gains_rate,
        "sell_transaction_tax_rate":
            sell_tax_rate,
        "sell_execution_cost_rate":
            sell_exec_rate,
        "buy_execution_cost_rate":
            buy_exec_rate,
        "fx_other_cost_rate":
            fx_rate,
        "step1_sell_friction_rate":
            step1_sell_friction,
        "step1_required_gross_trim_krw":
            required_gross,
        "step1_estimated_cost_krw":
            step1_cost,
        "step1_net_cash_added_krw":
            net_cash_added,
        "post_step1_cash_krw":
            post_step1_cash,
        "step1_cash_repair_gate":
            step1_gate,
        "donor_available_krw":
            donor_available,
        "residual_donor_capacity_krw":
            residual_donor,
        "recipient_headroom_krw":
            recipient_headroom,
        "step2_total_friction_rate":
            step2_total_friction,
        "step2_max_gross_donor_krw":
            step2_max_gross,
        "step2_max_net_recipient_krw":
            step2_max_net,
        "recipient_hurdle_spread":
            _num(
                recipient_hurdle_spread
            ),
        "bridge_mapping_gate":
            _text(
                bridge_mapping_gate
            ).upper(),
        "recipient_operational_gate":
            recipient_operational_gate,
        "step2_recipient_gate":
            step2_gate,
        "two_step_status":
            two_step_status,
        "execution_authorization":
            "NONE",
        "issues":
            all_issues,
    }


def cash_repair_review_row(
    plan: dict,
    *,
    note: str = "",
) -> dict:
    p = plan or {}

    row = {
        "reviewed_at":
            datetime.now().isoformat(),
    }

    for col in CASH_REPAIR_REVIEW_COLS:
        if col == "reviewed_at":
            continue
        if col == "issues":
            row[col] = " | ".join(
                p.get(
                    "issues",
                    []
                )
            )
        elif col == "note":
            row[col] = _text(note)
        elif col == "execution_authorization":
            row[col] = "NONE"
        else:
            row[col] = p.get(
                col,
                "",
            )

    return row


CASH_REPAIR_QUANTITY_REVIEW_COLS = [
    "reviewed_at",
    "donor",
    "recipient",
    "donor_kind",
    "recipient_kind",
    "quantity_mode",
    "lot_size",
    "current_quantity",
    "unit_value_proxy_krw",
    "mathematical_gross_trim_krw",
    "required_sell_quantity",
    "executable_sell_quantity",
    "executable_gross_trim_krw",
    "estimated_sell_cost_krw",
    "net_cash_added_krw",
    "post_trade_cash_krw",
    "minimum_cash_krw",
    "cash_shortfall_after_trade_krw",
    "cash_over_repair_krw",
    "remaining_quantity",
    "residual_donor_value_krw",
    "quantity_step_gate",
    "recipient_headroom_krw",
    "step2_max_gross_donor_krw",
    "step2_max_net_recipient_krw",
    "step2_recipient_gate",
    "two_step_quantity_status",
    "execution_authorization",
    "issues",
    "note",
]


def build_cash_repair_quantity_step(
    continuous_plan: dict,
    *,
    donor_quantity: float | None,
    unit_value_proxy_krw: float | None,
    lot_size: int = 1,
    integer_tolerance: float = 1e-6,
) -> dict:
    """
    Convert the continuous-KRW Step 1 cash-repair benchmark into whole-quantity
    execution reality.

    No broker fractional-share or lot rule is inferred. This function assumes
    only a user/system supplied whole lot_size, defaulting to 1 share/unit.
    """
    plan = continuous_plan or {}
    issues = []

    donor_kind = _text(
        plan.get("donor_kind")
    ).upper()
    recipient_kind = _text(
        plan.get("recipient_kind")
    ).upper()

    current_quantity = _num(
        donor_quantity
    )
    unit_value = _num(
        unit_value_proxy_krw
    )

    try:
        lot = max(
            1,
            int(lot_size),
        )
    except Exception:
        lot = 1
        issues.append(
            "LOT_SIZE_INVALID"
        )

    tol = max(
        0.0,
        float(
            integer_tolerance
            or 0.0
        ),
    )

    mathematical_gross = _num(
        plan.get(
            "step1_required_gross_trim_krw"
        )
    )
    minimum_cash = max(
        0.0,
        float(
            _num(
                plan.get(
                    "minimum_cash_krw"
                )
            )
            or 0.0
        ),
    )
    current_cash = max(
        0.0,
        float(
            _num(
                plan.get(
                    "current_cash_krw"
                )
            )
            or 0.0
        ),
    )
    donor_available = max(
        0.0,
        float(
            _num(
                plan.get(
                    "donor_available_krw"
                )
            )
            or 0.0
        ),
    )
    sell_friction = min(
        1.0,
        max(
            0.0,
            float(
                _num(
                    plan.get(
                        "step1_sell_friction_rate"
                    )
                )
                or 0.0
            ),
        ),
    )
    sell_net_factor = (
        1.0
        - sell_friction
    )

    quantity_mode = "WHOLE_QUANTITY"

    if donor_kind == "CASH":
        quantity_mode = "N/A"
        issues.append(
            "CASH_DONOR_HAS_NO_SELL_QUANTITY"
        )

    if current_quantity is None or current_quantity <= 0.0:
        quantity_mode = "REVIEW"
        issues.append(
            "DONOR_QUANTITY_REQUIRED"
        )
    elif abs(
        current_quantity
        - round(
            current_quantity
        )
    ) > tol:
        quantity_mode = "REVIEW"
        issues.append(
            "WHOLE_QUANTITY_NOT_CONFIRMED"
        )

    if unit_value is None or unit_value <= 0.0:
        issues.append(
            "UNIT_VALUE_PROXY_REQUIRED"
        )

    required_sell_quantity = None
    executable_sell_quantity = 0.0
    executable_gross = 0.0
    estimated_cost = 0.0
    net_cash_added = 0.0
    post_trade_cash = current_cash
    remaining_quantity = (
        current_quantity
        if current_quantity is not None
        else None
    )
    cash_shortfall_after = max(
        0.0,
        minimum_cash
        - post_trade_cash,
    )
    cash_over_repair = max(
        0.0,
        post_trade_cash
        - minimum_cash,
    )

    continuous_gate = _text(
        plan.get(
            "step1_cash_repair_gate"
        )
    ).upper()

    if continuous_gate == "ALREADY_PASS":
        required_sell_quantity = 0.0
        quantity_gate = "ALREADY_PASS"

    elif (
        donor_kind == "CASH"
        or current_quantity is None
        or current_quantity <= 0.0
        or unit_value is None
        or unit_value <= 0.0
        or quantity_mode != "WHOLE_QUANTITY"
        or mathematical_gross is None
        or mathematical_gross < 0.0
        or sell_net_factor <= 0.0
    ):
        quantity_gate = "REVIEW"

    else:
        raw_required_units = (
            mathematical_gross
            / unit_value
        )

        # Round up to the requested whole lot size.
        required_lots = int(
            math.ceil(
                raw_required_units
                / float(
                    lot
                )
                - 1e-12
            )
        )
        required_sell_quantity = float(
            required_lots
            * lot
        )

        max_executable_quantity = float(
            math.floor(
                current_quantity
                / float(
                    lot
                )
                + 1e-12
            )
            * lot
        )

        executable_sell_quantity = min(
            required_sell_quantity,
            max_executable_quantity,
        )
        executable_gross = (
            executable_sell_quantity
            * unit_value
        )

        # The value proxy is derived from the same live holding value; cap gross
        # to donor value only as a safety check against inconsistent inputs.
        if executable_gross > donor_available + 1e-6:
            executable_gross = donor_available
            issues.append(
                "QUANTITY_VALUE_INCONSISTENT_WITH_DONOR_AVAILABLE"
            )

        estimated_cost = (
            executable_gross
            * sell_friction
        )
        net_cash_added = (
            executable_gross
            - estimated_cost
        )
        post_trade_cash = (
            current_cash
            + net_cash_added
        )
        remaining_quantity = max(
            0.0,
            current_quantity
            - executable_sell_quantity,
        )
        cash_shortfall_after = max(
            0.0,
            minimum_cash
            - post_trade_cash,
        )
        cash_over_repair = max(
            0.0,
            post_trade_cash
            - minimum_cash,
        )

        if (
            required_sell_quantity
            > max_executable_quantity
            + tol
        ):
            quantity_gate = "BLOCKED"
            issues.append(
                "INSUFFICIENT_WHOLE_QUANTITY_FOR_CASH_REPAIR"
            )
        elif (
            post_trade_cash
            + 1e-6
            < minimum_cash
        ):
            quantity_gate = "REVIEW"
            issues.append(
                "QUANTITY_STEP_CASH_STILL_BELOW_MINIMUM"
            )
        else:
            quantity_gate = "PASS"

    residual_donor_value = max(
        0.0,
        donor_available
        - executable_gross,
    )

    recipient_headroom = max(
        0.0,
        float(
            _num(
                plan.get(
                    "recipient_headroom_krw"
                )
            )
            or 0.0
        ),
    )
    step2_friction = min(
        1.0,
        max(
            0.0,
            float(
                _num(
                    plan.get(
                        "step2_total_friction_rate"
                    )
                )
                or 0.0
            ),
        ),
    )
    step2_net_factor = (
        1.0
        - step2_friction
    )

    if (
        quantity_gate
        not in {
            "PASS",
            "ALREADY_PASS",
        }
        or recipient_kind == "CASH"
        or step2_net_factor <= 0.0
    ):
        step2_max_gross = 0.0
        step2_max_net = 0.0
    else:
        gross_for_headroom = (
            0.0
            if recipient_headroom <= 0.0
            else recipient_headroom
            / step2_net_factor
        )
        step2_max_gross = max(
            0.0,
            min(
                residual_donor_value,
                gross_for_headroom,
            ),
        )
        step2_max_net = (
            step2_max_gross
            * step2_net_factor
        )

    step2_issues = []

    if (
        quantity_gate
        not in {
            "PASS",
            "ALREADY_PASS",
        }
    ):
        step2_issues.append(
            "QUANTITY_CASH_REPAIR_NOT_READY"
        )

    if recipient_kind == "CASH":
        step2_gate = "N/A"
    else:
        hurdle_spread = _num(
            plan.get(
                "recipient_hurdle_spread"
            )
        )
        if hurdle_spread is None:
            step2_issues.append(
                "RECIPIENT_HURDLE_SPREAD_REQUIRED"
            )
        elif hurdle_spread < 0.0:
            step2_issues.append(
                "RECIPIENT_HURDLE_SPREAD_NEGATIVE"
            )

        if _text(
            plan.get(
                "bridge_mapping_gate"
            )
        ).upper() != "PASS":
            step2_issues.append(
                "ASSUMPTION_BRIDGE_NOT_PASS"
            )

        if _text(
            plan.get(
                "recipient_operational_gate"
            )
        ).upper() != "PASS":
            step2_issues.append(
                "RECIPIENT_OPERATIONAL_GATE_NOT_PASS"
            )

        if step2_max_gross <= 0.0:
            step2_issues.append(
                "NO_RESIDUAL_RECIPIENT_CAPACITY"
            )

        step2_gate = (
            "PASS"
            if not step2_issues
            else "REVIEW"
        )

    all_issues = list(
        dict.fromkeys(
            issues
            + step2_issues
        )
    )

    if quantity_gate == "PASS":
        step1_label = "QUANTITY_CASH_REPAIR_READY"
    elif quantity_gate == "ALREADY_PASS":
        step1_label = "CASH_RESERVE_ALREADY_PASS"
    else:
        step1_label = "QUANTITY_CASH_REPAIR_NOT_READY"

    if step2_gate == "PASS":
        status = (
            step1_label
            + " / RECIPIENT_PILOT_REVIEW_READY"
        )
    elif step2_gate == "N/A":
        status = (
            step1_label
            + " / CASH_ONLY"
        )
    else:
        status = (
            step1_label
            + " / RECIPIENT_REVIEW"
        )

    return {
        "donor":
            _text(
                plan.get("donor")
            ),
        "recipient":
            _text(
                plan.get("recipient")
            ),
        "donor_kind":
            donor_kind,
        "recipient_kind":
            recipient_kind,
        "quantity_mode":
            quantity_mode,
        "lot_size":
            lot,
        "current_quantity":
            current_quantity,
        "unit_value_proxy_krw":
            unit_value,
        "mathematical_gross_trim_krw":
            mathematical_gross,
        "required_sell_quantity":
            required_sell_quantity,
        "executable_sell_quantity":
            executable_sell_quantity,
        "executable_gross_trim_krw":
            executable_gross,
        "estimated_sell_cost_krw":
            estimated_cost,
        "net_cash_added_krw":
            net_cash_added,
        "post_trade_cash_krw":
            post_trade_cash,
        "minimum_cash_krw":
            minimum_cash,
        "cash_shortfall_after_trade_krw":
            cash_shortfall_after,
        "cash_over_repair_krw":
            cash_over_repair,
        "remaining_quantity":
            remaining_quantity,
        "residual_donor_value_krw":
            residual_donor_value,
        "quantity_step_gate":
            quantity_gate,
        "recipient_headroom_krw":
            recipient_headroom,
        "step2_max_gross_donor_krw":
            step2_max_gross,
        "step2_max_net_recipient_krw":
            step2_max_net,
        "step2_recipient_gate":
            step2_gate,
        "two_step_quantity_status":
            status,
        "execution_authorization":
            "NONE",
        "issues":
            all_issues,
    }


def cash_repair_quantity_review_row(
    quantity_plan: dict,
    *,
    note: str = "",
) -> dict:
    plan = quantity_plan or {}
    row = {
        "reviewed_at":
            datetime.now().isoformat(),
    }

    for col in CASH_REPAIR_QUANTITY_REVIEW_COLS:
        if col == "reviewed_at":
            continue
        if col == "issues":
            row[col] = " | ".join(
                plan.get(
                    "issues",
                    []
                )
            )
        elif col == "note":
            row[col] = _text(
                note
            )
        elif col == "execution_authorization":
            row[col] = "NONE"
        else:
            row[col] = plan.get(
                col,
                "",
            )

    return row


CASH_REPAIR_SENSITIVITY_REVIEW_COLS = [
    "reviewed_at",
    "donor",
    "recipient",
    "reference_unit_value_krw",
    "current_quantity",
    "lot_size",
    "base_required_sell_quantity",
    "max_price_shock_rate",
    "additional_slippage_haircut_rate",
    "sensitivity_steps",
    "break_even_sell_price_krw",
    "price_buffer_rate",
    "quantity_boundary_shock_rate",
    "worst_case_price_shock_rate",
    "worst_case_market_price_krw",
    "worst_case_effective_sell_price_krw",
    "worst_case_required_sell_quantity",
    "worst_case_executable_sell_quantity",
    "worst_case_post_trade_cash_krw",
    "worst_case_cash_shortfall_krw",
    "max_required_sell_quantity",
    "max_quantity_step_up",
    "scenario_count",
    "scenario_hash",
    "robustness_gate",
    "boundary_status",
    "execution_authorization",
    "issues",
    "note",
]


def _sensitivity_hash(rows: list[dict]) -> str:
    payload = []
    for row in rows:
        normalized = {}
        for key, value in row.items():
            if isinstance(value, float):
                normalized[key] = (
                    None
                    if pd.isna(value)
                    else f"{value:.12f}"
                )
            else:
                normalized[key] = value
        payload.append(normalized)

    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def build_cash_repair_price_sensitivity(
    continuous_plan: dict,
    quantity_plan: dict,
    *,
    max_price_shock_rate: float = 0.10,
    additional_slippage_haircut_rate: float = 0.0,
    sensitivity_steps: int = 4,
) -> dict:
    """
    Stress the Step-1 whole-quantity cash repair against lower sell prices.

    Price shock:
      reference unit value -> lower market price

    Additional slippage haircut:
      explicit extra execution-price haircut, separate from the sell execution
      cost already embedded in continuous_plan. Use 0 when sell_execution_cost
      already captures all intended slippage to avoid double counting.

    Robustness:
      PASS    = same base sell quantity repairs cash across the full band
      REVIEW  = cash can still be repaired, but one or more scenarios require
                a higher whole quantity
      BLOCKED = at least one scenario cannot repair cash with available quantity
    """
    cplan = continuous_plan or {}
    qplan = quantity_plan or {}
    issues = []

    reference_unit = _num(
        qplan.get("unit_value_proxy_krw")
    )
    current_quantity = _num(
        qplan.get("current_quantity")
    )
    base_required_quantity = _num(
        qplan.get("required_sell_quantity")
    )

    try:
        lot = max(
            1,
            int(
                qplan.get(
                    "lot_size",
                    1,
                )
                or 1
            ),
        )
    except Exception:
        lot = 1
        issues.append("LOT_SIZE_INVALID")

    max_shock = min(
        0.95,
        max(
            0.0,
            float(
                _num(max_price_shock_rate)
                or 0.0
            ),
        ),
    )
    extra_slippage = min(
        0.95,
        max(
            0.0,
            float(
                _num(additional_slippage_haircut_rate)
                or 0.0
            ),
        ),
    )

    try:
        steps = max(
            1,
            min(
                20,
                int(
                    sensitivity_steps
                ),
            ),
        )
    except Exception:
        steps = 4
        issues.append("SENSITIVITY_STEPS_INVALID")

    current_cash = max(
        0.0,
        float(
            _num(
                cplan.get(
                    "current_cash_krw"
                )
            )
            or 0.0
        ),
    )
    minimum_cash = max(
        0.0,
        float(
            _num(
                cplan.get(
                    "minimum_cash_krw"
                )
            )
            or 0.0
        ),
    )
    cash_shortfall = max(
        0.0,
        minimum_cash
        - current_cash,
    )
    sell_friction = min(
        1.0,
        max(
            0.0,
            float(
                _num(
                    cplan.get(
                        "step1_sell_friction_rate"
                    )
                )
                or 0.0
            ),
        ),
    )
    sell_net_factor = (
        1.0
        - sell_friction
    )

    if reference_unit is None or reference_unit <= 0.0:
        issues.append(
            "REFERENCE_UNIT_VALUE_REQUIRED"
        )
    if current_quantity is None or current_quantity <= 0.0:
        issues.append(
            "CURRENT_QUANTITY_REQUIRED"
        )
    if (
        base_required_quantity is None
        or base_required_quantity < 0.0
    ):
        issues.append(
            "BASE_REQUIRED_QUANTITY_REQUIRED"
        )
    if sell_net_factor <= 0.0:
        issues.append(
            "SELL_NET_FACTOR_NOT_FEASIBLE"
        )
    if extra_slippage >= 1.0:
        issues.append(
            "ADDITIONAL_SLIPPAGE_NOT_FEASIBLE"
        )

    max_executable_quantity = (
        0.0
        if current_quantity is None
        else float(
            math.floor(
                current_quantity
                / float(
                    lot
                )
                + 1e-12
            )
            * lot
        )
    )

    break_even_price = None
    price_buffer = None
    quantity_boundary_shock = None

    if (
        reference_unit is not None
        and reference_unit > 0.0
        and base_required_quantity is not None
        and base_required_quantity > 0.0
        and sell_net_factor > 0.0
        and (1.0 - extra_slippage) > 0.0
    ):
        break_even_price = (
            cash_shortfall
            / (
                base_required_quantity
                * (1.0 - extra_slippage)
                * sell_net_factor
            )
        )
        price_buffer = (
            1.0
            - (
                break_even_price
                / reference_unit
            )
        )
        quantity_boundary_shock = price_buffer

    scenario_rows = []

    if not issues:
        shocks = [
            (
                max_shock
                * i
                / float(
                    steps
                )
            )
            for i in range(
                steps
                + 1
            )
        ]

        # Deduplicate when max_shock = 0.
        unique_shocks = []
        for shock in shocks:
            if not unique_shocks or abs(
                shock
                - unique_shocks[-1]
            ) > 1e-12:
                unique_shocks.append(
                    shock
                )

        for idx, shock in enumerate(
            unique_shocks
        ):
            market_price = (
                reference_unit
                * (
                    1.0
                    - shock
                )
            )
            effective_sell_price = (
                market_price
                * (
                    1.0
                    - extra_slippage
                )
            )
            net_cash_per_unit = (
                effective_sell_price
                * sell_net_factor
            )

            if cash_shortfall <= 1e-9:
                required_qty = 0.0
            elif net_cash_per_unit <= 0.0:
                required_qty = None
            else:
                raw_units = (
                    cash_shortfall
                    / net_cash_per_unit
                )
                required_lots = int(
                    math.ceil(
                        raw_units
                        / float(
                            lot
                        )
                        - 1e-12
                    )
                )
                required_qty = float(
                    required_lots
                    * lot
                )

            if required_qty is None:
                executable_qty = 0.0
            else:
                executable_qty = min(
                    required_qty,
                    max_executable_quantity,
                )

            executable_gross = (
                executable_qty
                * effective_sell_price
            )
            estimated_friction_cost = (
                executable_gross
                * sell_friction
            )
            net_cash_added = (
                executable_gross
                - estimated_friction_cost
            )
            post_trade_cash = (
                current_cash
                + net_cash_added
            )
            shortfall_after = max(
                0.0,
                minimum_cash
                - post_trade_cash,
            )
            over_repair = max(
                0.0,
                post_trade_cash
                - minimum_cash,
            )

            if (
                required_qty is None
                or required_qty
                > max_executable_quantity
                + 1e-9
                or post_trade_cash
                + 1e-6
                < minimum_cash
            ):
                scenario_gate = "BLOCKED"
            else:
                scenario_gate = "PASS"

            step_up = (
                None
                if (
                    required_qty is None
                    or base_required_quantity is None
                )
                else max(
                    0.0,
                    required_qty
                    - base_required_quantity,
                )
            )

            scenario_rows.append(
                {
                    "scenario":
                        (
                            "BASE"
                            if idx == 0
                            else f"SHOCK_{shock:.2%}"
                        ),
                    "price_shock_rate":
                        shock,
                    "market_price_krw":
                        market_price,
                    "additional_slippage_haircut_rate":
                        extra_slippage,
                    "effective_sell_price_krw":
                        effective_sell_price,
                    "sell_friction_rate":
                        sell_friction,
                    "net_cash_per_unit_krw":
                        net_cash_per_unit,
                    "required_sell_quantity":
                        required_qty,
                    "executable_sell_quantity":
                        executable_qty,
                    "executable_gross_trim_krw":
                        executable_gross,
                    "estimated_friction_cost_krw":
                        estimated_friction_cost,
                    "net_cash_added_krw":
                        net_cash_added,
                    "post_trade_cash_krw":
                        post_trade_cash,
                    "cash_shortfall_after_trade_krw":
                        shortfall_after,
                    "cash_over_repair_krw":
                        over_repair,
                    "quantity_step_up":
                        step_up,
                    "scenario_gate":
                        scenario_gate,
                }
            )

    table = pd.DataFrame(
        scenario_rows
    )

    if issues:
        robustness_gate = "REVIEW"
        boundary_status = "INPUT_REVIEW"
        worst = {}
        max_required_qty = None
        max_step_up = None
    elif table.empty:
        robustness_gate = "REVIEW"
        boundary_status = "INPUT_REVIEW"
        worst = {}
        max_required_qty = None
        max_step_up = None
        issues.append(
            "SENSITIVITY_TABLE_EMPTY"
        )
    else:
        blocked_count = int(
            table[
                "scenario_gate"
            ]
            .fillna("")
            .astype(str)
            .eq(
                "BLOCKED"
            )
            .sum()
        )
        max_required_qty = pd.to_numeric(
            table[
                "required_sell_quantity"
            ],
            errors="coerce",
        ).max()
        max_step_up = pd.to_numeric(
            table[
                "quantity_step_up"
            ],
            errors="coerce",
        ).max()

        if blocked_count > 0:
            robustness_gate = "BLOCKED"
            boundary_status = "INSUFFICIENT_QUANTITY_IN_BAND"
        elif (
            max_step_up is not None
            and not pd.isna(
                max_step_up
            )
            and max_step_up
            > 0.0
        ):
            robustness_gate = "REVIEW"
            boundary_status = "QUANTITY_STEP_UP_IN_BAND"
        else:
            robustness_gate = "PASS"
            boundary_status = "SAME_QUANTITY_ROBUST"

        worst = table.sort_values(
            "price_shock_rate",
            ascending=False,
        ).iloc[0].to_dict()

    scenario_hash = (
        _sensitivity_hash(
            scenario_rows
        )
        if scenario_rows
        else ""
    )

    return {
        "donor":
            _text(
                qplan.get("donor")
            ),
        "recipient":
            _text(
                qplan.get("recipient")
            ),
        "reference_unit_value_krw":
            reference_unit,
        "current_quantity":
            current_quantity,
        "lot_size":
            lot,
        "base_required_sell_quantity":
            base_required_quantity,
        "max_price_shock_rate":
            max_shock,
        "additional_slippage_haircut_rate":
            extra_slippage,
        "sensitivity_steps":
            steps,
        "break_even_sell_price_krw":
            break_even_price,
        "price_buffer_rate":
            price_buffer,
        "quantity_boundary_shock_rate":
            quantity_boundary_shock,
        "worst_case_price_shock_rate":
            _num(
                worst.get(
                    "price_shock_rate"
                )
            ),
        "worst_case_market_price_krw":
            _num(
                worst.get(
                    "market_price_krw"
                )
            ),
        "worst_case_effective_sell_price_krw":
            _num(
                worst.get(
                    "effective_sell_price_krw"
                )
            ),
        "worst_case_required_sell_quantity":
            _num(
                worst.get(
                    "required_sell_quantity"
                )
            ),
        "worst_case_executable_sell_quantity":
            _num(
                worst.get(
                    "executable_sell_quantity"
                )
            ),
        "worst_case_post_trade_cash_krw":
            _num(
                worst.get(
                    "post_trade_cash_krw"
                )
            ),
        "worst_case_cash_shortfall_krw":
            _num(
                worst.get(
                    "cash_shortfall_after_trade_krw"
                )
            ),
        "max_required_sell_quantity":
            (
                None
                if max_required_qty is None
                or pd.isna(
                    max_required_qty
                )
                else float(
                    max_required_qty
                )
            ),
        "max_quantity_step_up":
            (
                None
                if max_step_up is None
                or pd.isna(
                    max_step_up
                )
                else float(
                    max_step_up
                )
            ),
        "scenario_count":
            int(
                len(
                    scenario_rows
                )
            ),
        "scenario_hash":
            scenario_hash,
        "robustness_gate":
            robustness_gate,
        "boundary_status":
            boundary_status,
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
        "table":
            table,
    }


def cash_repair_sensitivity_review_row(
    sensitivity: dict,
    *,
    note: str = "",
) -> dict:
    s = sensitivity or {}
    row = {
        "reviewed_at":
            datetime.now().isoformat(),
    }

    for col in CASH_REPAIR_SENSITIVITY_REVIEW_COLS:
        if col == "reviewed_at":
            continue
        if col == "issues":
            row[col] = " | ".join(
                s.get(
                    "issues",
                    []
                )
            )
        elif col == "note":
            row[col] = _text(
                note
            )
        elif col == "execution_authorization":
            row[col] = "NONE"
        else:
            row[col] = s.get(
                col,
                "",
            )

    return row


CASH_REPAIR_QUOTE_VALIDATION_COLS = [
    "reviewed_at",
    "donor",
    "recipient",
    "quote_source",
    "quote_timestamp",
    "quote_age_minutes",
    "max_quote_age_minutes",
    "future_tolerance_minutes",
    "quote_price_krw",
    "additional_slippage_haircut_rate",
    "effective_sell_price_krw",
    "sell_friction_rate",
    "net_cash_per_unit_krw",
    "base_required_sell_quantity",
    "quote_required_sell_quantity",
    "available_sell_quantity",
    "executable_sell_quantity",
    "break_even_quote_price_krw",
    "price_to_boundary_krw",
    "price_buffer_rate",
    "post_trade_cash_krw",
    "minimum_cash_krw",
    "cash_shortfall_after_trade_krw",
    "cash_over_repair_krw",
    "boundary_status",
    "quote_freshness_gate",
    "quote_validation_gate",
    "sensitivity_scenario_hash",
    "quote_snapshot_hash",
    "human_quote_confirmed",
    "execution_authorization",
    "issues",
    "note",
]


def _quote_hash(payload: dict) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def validate_cash_repair_pretrade_quote(
    continuous_plan: dict,
    quantity_plan: dict,
    sensitivity_plan: dict,
    *,
    quote_price_krw: float | None,
    quote_timestamp: str,
    quote_source: str,
    additional_slippage_haircut_rate: float = 0.0,
    human_quote_confirmed: bool = False,
    max_quote_age_minutes: float = 5.0,
    future_tolerance_minutes: float = 2.0,
    now: str | pd.Timestamp | None = None,
) -> dict:
    """
    Validate a user-observed pre-trade quote against the cash-repair boundary.

    This is governance only:
    - no market data is fetched
    - no order is created
    - no quantity is automatically changed
    """
    cplan = continuous_plan or {}
    qplan = quantity_plan or {}
    splan = sensitivity_plan or {}

    issues = []

    quote = _num(
        quote_price_krw
    )
    source = _text(
        quote_source
    )
    ts_text = _text(
        quote_timestamp
    )

    slippage = min(
        0.95,
        max(
            0.0,
            float(
                _num(
                    additional_slippage_haircut_rate
                )
                or 0.0
            ),
        ),
    )
    max_age = max(
        0.0,
        float(
            _num(
                max_quote_age_minutes
            )
            or 0.0
        ),
    )
    future_tol = max(
        0.0,
        float(
            _num(
                future_tolerance_minutes
            )
            or 0.0
        ),
    )

    if quote is None or quote <= 0.0:
        issues.append(
            "QUOTE_PRICE_REQUIRED"
        )

    if not source:
        issues.append(
            "QUOTE_SOURCE_REQUIRED"
        )

    quote_ts = None
    quote_age_minutes = None
    freshness_gate = "REVIEW"

    if not ts_text:
        issues.append(
            "QUOTE_TIMESTAMP_REQUIRED"
        )
    else:
        try:
            quote_ts = pd.Timestamp(
                ts_text
            )
        except Exception:
            quote_ts = None
            issues.append(
                "QUOTE_TIMESTAMP_INVALID"
            )

    if quote_ts is not None:
        if quote_ts.tzinfo is None:
            issues.append(
                "QUOTE_TIMESTAMP_TIMEZONE_REQUIRED"
            )
        else:
            now_ts = (
                pd.Timestamp.now(
                    tz="UTC"
                )
                if now is None
                else pd.Timestamp(
                    now
                )
            )
            if now_ts.tzinfo is None:
                now_ts = now_ts.tz_localize(
                    "UTC"
                )
            else:
                now_ts = now_ts.tz_convert(
                    "UTC"
                )

            quote_utc = quote_ts.tz_convert(
                "UTC"
            )
            quote_age_minutes = (
                (
                    now_ts
                    - quote_utc
                ).total_seconds()
                / 60.0
            )

            if quote_age_minutes < -future_tol:
                issues.append(
                    "QUOTE_TIMESTAMP_IN_FUTURE"
                )
                freshness_gate = "REVIEW"
            elif quote_age_minutes > max_age:
                issues.append(
                    "QUOTE_STALE"
                )
                freshness_gate = "REVIEW"
            else:
                freshness_gate = "PASS"

    if not bool(
        human_quote_confirmed
    ):
        issues.append(
            "HUMAN_QUOTE_CONFIRMATION_REQUIRED"
        )

    current_quantity = _num(
        qplan.get(
            "current_quantity"
        )
    )
    base_required_qty = _num(
        qplan.get(
            "required_sell_quantity"
        )
    )
    try:
        lot = max(
            1,
            int(
                qplan.get(
                    "lot_size",
                    1,
                )
                or 1
            ),
        )
    except Exception:
        lot = 1
        issues.append(
            "LOT_SIZE_INVALID"
        )

    sell_friction = min(
        1.0,
        max(
            0.0,
            float(
                _num(
                    cplan.get(
                        "step1_sell_friction_rate"
                    )
                )
                or 0.0
            ),
        ),
    )
    sell_net_factor = (
        1.0
        - sell_friction
    )
    current_cash = max(
        0.0,
        float(
            _num(
                cplan.get(
                    "current_cash_krw"
                )
            )
            or 0.0
        ),
    )
    minimum_cash = max(
        0.0,
        float(
            _num(
                cplan.get(
                    "minimum_cash_krw"
                )
            )
            or 0.0
        ),
    )
    cash_shortfall = max(
        0.0,
        minimum_cash
        - current_cash,
    )

    if current_quantity is None or current_quantity <= 0.0:
        issues.append(
            "CURRENT_QUANTITY_REQUIRED"
        )
    if base_required_qty is None or base_required_qty < 0.0:
        issues.append(
            "BASE_REQUIRED_QUANTITY_REQUIRED"
        )
    if sell_net_factor <= 0.0:
        issues.append(
            "SELL_NET_FACTOR_NOT_FEASIBLE"
        )

    effective_sell_price = None
    net_cash_per_unit = None
    required_qty = None
    available_qty = None
    executable_qty = 0.0
    post_trade_cash = current_cash
    shortfall_after = max(
        0.0,
        minimum_cash
        - post_trade_cash,
    )
    over_repair = max(
        0.0,
        post_trade_cash
        - minimum_cash,
    )
    break_even_quote = None
    price_to_boundary = None
    price_buffer_rate = None

    if (
        quote is not None
        and quote > 0.0
        and sell_net_factor > 0.0
        and (
            1.0
            - slippage
        ) > 0.0
    ):
        effective_sell_price = (
            quote
            * (
                1.0
                - slippage
            )
        )
        net_cash_per_unit = (
            effective_sell_price
            * sell_net_factor
        )

        if cash_shortfall <= 1e-9:
            required_qty = 0.0
        elif net_cash_per_unit > 0.0:
            raw_units = (
                cash_shortfall
                / net_cash_per_unit
            )
            required_lots = int(
                math.ceil(
                    raw_units
                    / float(
                        lot
                    )
                    - 1e-12
                )
            )
            required_qty = float(
                required_lots
                * lot
            )

        if current_quantity is not None:
            available_qty = float(
                math.floor(
                    current_quantity
                    / float(
                        lot
                    )
                    + 1e-12
                )
                * lot
            )

        if (
            required_qty is not None
            and available_qty is not None
        ):
            executable_qty = min(
                required_qty,
                available_qty,
            )

        net_cash_added = (
            executable_qty
            * (
                net_cash_per_unit
                or 0.0
            )
        )
        post_trade_cash = (
            current_cash
            + net_cash_added
        )
        shortfall_after = max(
            0.0,
            minimum_cash
            - post_trade_cash,
        )
        over_repair = max(
            0.0,
            post_trade_cash
            - minimum_cash,
        )

        if (
            base_required_qty is not None
            and base_required_qty > 0.0
        ):
            break_even_quote = (
                cash_shortfall
                / (
                    base_required_qty
                    * (
                        1.0
                        - slippage
                    )
                    * sell_net_factor
                )
            )
            price_to_boundary = (
                quote
                - break_even_quote
            )
            price_buffer_rate = (
                quote
                / break_even_quote
                - 1.0
                if break_even_quote > 0.0
                else None
            )

    if required_qty is None:
        boundary_status = "QUOTE_NOT_EVALUABLE"
    elif (
        available_qty is not None
        and required_qty
        > available_qty
        + 1e-9
    ):
        boundary_status = "INSUFFICIENT_WHOLE_QUANTITY"
    elif (
        base_required_qty is not None
        and required_qty
        > base_required_qty
        + 1e-9
    ):
        boundary_status = "QUANTITY_STEP_UP_REQUIRED"
    else:
        boundary_status = "BASE_QUANTITY_VALID"

    boundary_issues = []
    if boundary_status == "QUOTE_NOT_EVALUABLE":
        boundary_issues.append(
            "QUOTE_BOUNDARY_NOT_EVALUABLE"
        )
    elif boundary_status == "INSUFFICIENT_WHOLE_QUANTITY":
        boundary_issues.append(
            "INSUFFICIENT_WHOLE_QUANTITY_AT_QUOTE"
        )
    elif boundary_status == "QUANTITY_STEP_UP_REQUIRED":
        boundary_issues.append(
            "QUOTE_REQUIRES_QUANTITY_STEP_UP"
        )

    issues.extend(
        boundary_issues
    )

    if (
        required_qty is not None
        and shortfall_after
        > 1e-6
    ):
        issues.append(
            "QUOTE_PLAN_CASH_STILL_BELOW_MINIMUM"
        )

    hard_block = (
        boundary_status
        == "INSUFFICIENT_WHOLE_QUANTITY"
    )

    review_issue_codes = {
        "QUOTE_PRICE_REQUIRED",
        "QUOTE_SOURCE_REQUIRED",
        "QUOTE_TIMESTAMP_REQUIRED",
        "QUOTE_TIMESTAMP_INVALID",
        "QUOTE_TIMESTAMP_TIMEZONE_REQUIRED",
        "QUOTE_TIMESTAMP_IN_FUTURE",
        "QUOTE_STALE",
        "HUMAN_QUOTE_CONFIRMATION_REQUIRED",
        "QUOTE_BOUNDARY_NOT_EVALUABLE",
        "QUOTE_REQUIRES_QUANTITY_STEP_UP",
        "QUOTE_PLAN_CASH_STILL_BELOW_MINIMUM",
        "CURRENT_QUANTITY_REQUIRED",
        "BASE_REQUIRED_QUANTITY_REQUIRED",
        "SELL_NET_FACTOR_NOT_FEASIBLE",
        "LOT_SIZE_INVALID",
    }

    unique_issues = list(
        dict.fromkeys(
            issues
        )
    )

    if hard_block:
        validation_gate = "BLOCKED"
    elif any(
        issue
        in review_issue_codes
        for issue
        in unique_issues
    ):
        validation_gate = "REVIEW"
    else:
        validation_gate = "PASS"

    snapshot_payload = {
        "donor": _text(
            cplan.get("donor")
        ),
        "recipient": _text(
            cplan.get("recipient")
        ),
        "quote_source":
            source,
        "quote_timestamp":
            ts_text,
        "quote_price_krw":
            None
            if quote is None
            else f"{quote:.6f}",
        "additional_slippage_haircut_rate":
            f"{slippage:.12f}",
        "sell_friction_rate":
            f"{sell_friction:.12f}",
        "base_required_sell_quantity":
            None
            if base_required_qty is None
            else f"{base_required_qty:.6f}",
        "quote_required_sell_quantity":
            None
            if required_qty is None
            else f"{required_qty:.6f}",
        "boundary_status":
            boundary_status,
        "sensitivity_scenario_hash":
            _text(
                splan.get(
                    "scenario_hash"
                )
            ),
    }

    return {
        "donor":
            _text(
                cplan.get("donor")
            ),
        "recipient":
            _text(
                cplan.get("recipient")
            ),
        "quote_source":
            source,
        "quote_timestamp":
            ts_text,
        "quote_age_minutes":
            quote_age_minutes,
        "max_quote_age_minutes":
            max_age,
        "future_tolerance_minutes":
            future_tol,
        "quote_price_krw":
            quote,
        "additional_slippage_haircut_rate":
            slippage,
        "effective_sell_price_krw":
            effective_sell_price,
        "sell_friction_rate":
            sell_friction,
        "net_cash_per_unit_krw":
            net_cash_per_unit,
        "base_required_sell_quantity":
            base_required_qty,
        "quote_required_sell_quantity":
            required_qty,
        "available_sell_quantity":
            available_qty,
        "executable_sell_quantity":
            executable_qty,
        "break_even_quote_price_krw":
            break_even_quote,
        "price_to_boundary_krw":
            price_to_boundary,
        "price_buffer_rate":
            price_buffer_rate,
        "post_trade_cash_krw":
            post_trade_cash,
        "minimum_cash_krw":
            minimum_cash,
        "cash_shortfall_after_trade_krw":
            shortfall_after,
        "cash_over_repair_krw":
            over_repair,
        "boundary_status":
            boundary_status,
        "quote_freshness_gate":
            freshness_gate,
        "quote_validation_gate":
            validation_gate,
        "sensitivity_scenario_hash":
            _text(
                splan.get(
                    "scenario_hash"
                )
            ),
        "quote_snapshot_hash":
            _quote_hash(
                snapshot_payload
            ),
        "human_quote_confirmed":
            bool(
                human_quote_confirmed
            ),
        "execution_authorization":
            "NONE",
        "issues":
            unique_issues,
    }


def cash_repair_quote_validation_review_row(
    validation: dict,
    *,
    note: str = "",
) -> dict:
    v = validation or {}
    row = {
        "reviewed_at":
            datetime.now().isoformat(),
    }

    for col in CASH_REPAIR_QUOTE_VALIDATION_COLS:
        if col == "reviewed_at":
            continue
        if col == "issues":
            row[col] = " | ".join(
                v.get(
                    "issues",
                    []
                )
            )
        elif col == "note":
            row[col] = _text(
                note
            )
        elif col == "execution_authorization":
            row[col] = "NONE"
        else:
            row[col] = v.get(
                col,
                "",
            )

    return row
