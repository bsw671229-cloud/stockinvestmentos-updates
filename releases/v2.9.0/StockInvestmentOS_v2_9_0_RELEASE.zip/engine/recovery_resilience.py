from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.backup_manifest_recovery import (
    recovery_point_lock_integrity,
    latest_matching_recovery_point,
)


RECOVERY_RESILIENCE_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "drift_status",
    "current_manifest_sha256",
    "matching_recovery_point_id",
    "matching_lock_integrity",
    "locked_points",
    "rotation_keep_latest",
    "rotation_candidates",
    "rotation_status",
    "restore_simulation_status",
    "simulation_steps",
    "restore_authorization",
    "issues",
    "note",
    "snapshot_hash",
]


RECOVERY_RESILIENCE_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


ROTATION_VIEW_COLS = [
    "recovery_point_id",
    "created_at",
    "manifest_sha256",
    "lock_status",
    "integrity",
    "rotation_action",
    "reason",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _ensure_lock_cols(
    locks: pd.DataFrame | None,
) -> pd.DataFrame:
    df = (
        pd.DataFrame()
        if locks is None
        else locks.copy()
    )

    for col in [
        "recovery_point_id",
        "created_at",
        "manifest_sha256",
        "lock_status",
        "record_hash",
        "restore_authorization",
    ]:
        if col not in df.columns:
            df[
                col
            ] = ""

    return df


def _valid_locked_points(
    locks: pd.DataFrame | None,
) -> pd.DataFrame:
    df = _ensure_lock_cols(
        locks
    )

    if df.empty:
        return df

    rows = []

    for _, row in df.iterrows():
        record = row.to_dict()
        integrity = recovery_point_lock_integrity(
            record
        )[
            "status"
        ]

        item = record.copy()
        item[
            "_integrity"
        ] = integrity
        rows.append(
            item
        )

    out = pd.DataFrame(
        rows
    )

    if "created_at" in out.columns:
        out[
            "_ts"
        ] = pd.to_datetime(
            out[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        out = out.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )
    else:
        out[
            "_ts"
        ] = pd.NaT

    return out.reset_index(
        drop=True
    )


def build_recovery_point_drift(
    verification: dict | None,
    dry_run: dict | None,
    locks: pd.DataFrame | None,
) -> dict:
    verify = verification or {}
    dry = dry_run or {}
    current_manifest = _text(
        verify.get(
            "manifest_sha256"
        )
    ).lower()

    issues = []

    if _text(
        verify.get(
            "manifest_status"
        )
    ).upper() != "PASS":
        issues.append(
            "CURRENT_MANIFEST_NOT_VERIFIED"
        )

    if _text(
        dry.get(
            "dryrun_status"
        )
    ).upper() != "PASS":
        issues.append(
            "CURRENT_RESTORE_DRYRUN_NOT_PASS"
        )

    points = _valid_locked_points(
        locks
    )

    integrity_issues = 0
    if not points.empty:
        integrity_issues = int(
            points[
                "_integrity"
            ]
            .fillna("")
            .astype(str)
            .ne(
                "OK"
            )
            .sum()
        )

    if integrity_issues > 0:
        issues.append(
            "RECOVERY_POINT_LOCK_INTEGRITY_ISSUE"
        )

    matching = latest_matching_recovery_point(
        locks,
        current_manifest,
    ) if current_manifest else {}

    matching_integrity = (
        recovery_point_lock_integrity(
            matching
        )[
            "status"
        ]
        if matching
        else "NONE"
    )

    if issues:
        drift_status = "INTEGRITY_REVIEW"
    elif not current_manifest:
        drift_status = "REVIEW"
        issues.append(
            "CURRENT_MANIFEST_HASH_MISSING"
        )
    elif matching:
        if matching_integrity == "OK":
            drift_status = "CURRENT"
        else:
            drift_status = "INTEGRITY_REVIEW"
            issues.append(
                "MATCHING_RECOVERY_POINT_HASH_MISMATCH"
            )
    elif points.empty:
        drift_status = "UNLOCKED"
        issues.append(
            "NO_RECOVERY_POINT_LOCK"
        )
    else:
        drift_status = "DRIFTED"
        issues.append(
            "LATEST_BACKUP_NOT_LOCKED"
        )

    return {
        "drift_status":
            drift_status,
        "current_manifest_sha256":
            current_manifest,
        "matching_recovery_point":
            matching,
        "matching_recovery_point_id":
            _text(
                matching.get(
                    "recovery_point_id"
                )
            )
            if matching
            else "",
        "matching_lock_integrity":
            matching_integrity,
        "locked_points":
            int(
                len(
                    points
                )
            ),
        "lock_integrity_issues":
            integrity_issues,
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
        "restore_authorization":
            "NONE",
    }


def build_backup_rotation_plan(
    locks: pd.DataFrame | None,
    *,
    current_manifest_sha256: str = "",
    keep_latest: int = 3,
) -> dict:
    points = _valid_locked_points(
        locks
    )
    keep_n = max(
        1,
        _int(
            keep_latest
        ),
    )
    current_manifest = _text(
        current_manifest_sha256
    ).lower()

    if points.empty:
        return {
            "rotation_status":
                "NO_LOCKS",
            "locked_points":
                0,
            "keep_latest":
                keep_n,
            "keep_count":
                0,
            "archive_candidates":
                0,
            "integrity_review":
                0,
            "rotation_view":
                pd.DataFrame(
                    columns=
                    ROTATION_VIEW_COLS
                ),
            "issues":
                [
                    "NO_RECOVERY_POINT_LOCKS"
                ],
            "deletion_authorization":
                "NONE",
        }

    rows = []
    valid_rank = 0
    integrity_review = 0
    archive_candidates = 0
    keep_count = 0

    for _, row in points.iterrows():
        record = row.to_dict()
        integrity = _text(
            record.get(
                "_integrity"
            )
        )
        manifest = _text(
            record.get(
                "manifest_sha256"
            )
        ).lower()

        if integrity != "OK":
            action = "INTEGRITY_REVIEW"
            reason = "immutable lock hash mismatch/missing"
            integrity_review += 1

        elif (
            current_manifest
            and manifest
            == current_manifest
        ):
            action = "KEEP_CURRENT"
            reason = "matches current verified backup"
            keep_count += 1
            valid_rank += 1

        elif valid_rank < keep_n:
            action = "KEEP"
            reason = f"within latest {keep_n} valid recovery points"
            keep_count += 1
            valid_rank += 1

        else:
            action = "ARCHIVE_CANDIDATE"
            reason = (
                "older verified recovery point; "
                "manual archive review only"
            )
            archive_candidates += 1
            valid_rank += 1

        rows.append(
            {
                "recovery_point_id":
                    _text(
                        record.get(
                            "recovery_point_id"
                        )
                    ),
                "created_at":
                    _text(
                        record.get(
                            "created_at"
                        )
                    ),
                "manifest_sha256":
                    manifest,
                "lock_status":
                    _text(
                        record.get(
                            "lock_status"
                        )
                    ),
                "integrity":
                    integrity,
                "rotation_action":
                    action,
                "reason":
                    reason,
            }
        )

    if integrity_review > 0:
        status = "INTEGRITY_REVIEW"
        issues = [
            "RECOVERY_POINT_LOCK_INTEGRITY_ISSUE"
        ]
    elif archive_candidates > 0:
        status = "REVIEW"
        issues = [
            "OLDER_RECOVERY_POINTS_AVAILABLE_FOR_ARCHIVE_REVIEW"
        ]
    else:
        status = "PASS"
        issues = []

    return {
        "rotation_status":
            status,
        "locked_points":
            int(
                len(
                    points
                )
            ),
        "keep_latest":
            keep_n,
        "keep_count":
            keep_count,
        "archive_candidates":
            archive_candidates,
        "integrity_review":
            integrity_review,
        "rotation_view":
            pd.DataFrame(
                rows,
                columns=
                ROTATION_VIEW_COLS,
            ),
        "issues":
            issues,
        "deletion_authorization":
            "NONE",
    }


def build_restore_simulation_plan(
    verification: dict | None,
    dry_run: dict | None,
    drift: dict | None,
) -> dict:
    verify = verification or {}
    dry = dry_run or {}
    dr = drift or {}
    issues = []

    if _text(
        verify.get(
            "manifest_status"
        )
    ).upper() != "PASS":
        issues.append(
            "MANIFEST_PASS_REQUIRED"
        )

    if _text(
        dry.get(
            "dryrun_status"
        )
    ).upper() != "PASS":
        issues.append(
            "DRYRUN_PASS_REQUIRED"
        )

    if _text(
        dr.get(
            "drift_status"
        )
    ).upper() != "CURRENT":
        issues.append(
            "CURRENT_LOCKED_RECOVERY_POINT_REQUIRED"
        )

    if _text(
        dr.get(
            "matching_lock_integrity"
        )
    ).upper() != "OK":
        issues.append(
            "RECOVERY_POINT_LOCK_INTEGRITY_OK_REQUIRED"
        )

    simulation_status = (
        "READY"
        if not issues
        else "BLOCKED"
    )

    steps = [
        {
            "step":
                1,
            "phase":
                "PRECHECK",
            "action":
                "Stop writes / close app before any future real restore",
            "write_allowed":
                "NO",
        },
        {
            "step":
                2,
            "phase":
                "PRECHECK",
            "action":
                "Create emergency copy of current data before future restore",
            "write_allowed":
                "PLAN_ONLY",
        },
        {
            "step":
                3,
            "phase":
                "VERIFY",
            "action":
                "Re-verify locked manifest SHA-256 and Recovery Point integrity",
            "write_allowed":
                "NO",
        },
        {
            "step":
                4,
            "phase":
                "STAGE",
            "action":
                "Stage backup into isolated temporary directory",
            "write_allowed":
                "PLAN_ONLY",
        },
        {
            "step":
                5,
            "phase":
                "VALIDATE",
            "action":
                "Parse staged CSV/JSON and compare manifest hashes",
            "write_allowed":
                "NO",
        },
        {
            "step":
                6,
            "phase":
                "COMPARE",
            "action":
                "Compare staged file set with current data and identify overwrite scope",
            "write_allowed":
                "NO",
        },
        {
            "step":
                7,
            "phase":
                "HUMAN_GATE",
            "action":
                "Require separate explicit human approval for any future real restore",
            "write_allowed":
                "NO",
        },
        {
            "step":
                8,
            "phase":
                "RESTORE",
            "action":
                "Actual restore is outside this simulation and remains unauthorized",
            "write_allowed":
                "NO",
        },
    ]

    return {
        "simulation_status":
            simulation_status,
        "steps":
            pd.DataFrame(
                steps
            ),
        "step_count":
            len(
                steps
            ),
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
        "restore_authorization":
            "NONE",
    }


def build_recovery_resilience_queue(
    drift: dict | None,
    rotation: dict | None,
    simulation: dict | None,
) -> pd.DataFrame:
    dr = drift or {}
    rot = rotation or {}
    sim = simulation or {}
    rows = []

    drift_status = _text(
        dr.get(
            "drift_status"
        )
    ).upper()

    if drift_status == "INTEGRITY_REVIEW":
        rows.append(
            {
                "priority":
                    "RS0",
                "status":
                    "BLOCKED",
                "issue":
                    "RECOVERY_POINT_DRIFT_INTEGRITY_REVIEW",
                "next_action":
                    "Manifest / Recovery Point Lock Hash 무결성 확인",
                "go_to":
                    "Save Center",
            }
        )
    elif drift_status in {
        "DRIFTED",
        "UNLOCKED",
        "REVIEW",
    }:
        rows.append(
            {
                "priority":
                    "RS1",
                "status":
                    "REVIEW",
                "issue":
                    (
                        "LATEST_BACKUP_NOT_CURRENTLY_LOCKED"
                        if drift_status
                        in {
                            "DRIFTED",
                            "UNLOCKED",
                        }
                        else "RECOVERY_POINT_REVIEW_REQUIRED"
                    ),
                "next_action":
                    "최신 Manifest/Dry-run 확인 후 새 Recovery Point Lock 검토",
                "go_to":
                    "Save Center",
            }
        )

    rotation_status = _text(
        rot.get(
            "rotation_status"
        )
    ).upper()

    if rotation_status == "INTEGRITY_REVIEW":
        rows.append(
            {
                "priority":
                    "RS0",
                "status":
                    "BLOCKED",
                "issue":
                    "BACKUP_ROTATION_LOCK_INTEGRITY_REVIEW",
                "next_action":
                    "Recovery Point Lock Hash 무결성부터 확인",
                "go_to":
                    "Save Center",
            }
        )
    elif rotation_status == "REVIEW":
        rows.append(
            {
                "priority":
                    "RS2",
                "status":
                    "REVIEW",
                "issue":
                    "BACKUP_ROTATION_ARCHIVE_CANDIDATES",
                "next_action":
                    "오래된 Recovery Point를 archive 후보로만 검토; 자동 삭제 금지",
                "go_to":
                    "Save Center",
            }
        )

    if _text(
        sim.get(
            "simulation_status"
        )
    ).upper() != "READY":
        rows.append(
            {
                "priority":
                    "RS1",
                "status":
                    "REVIEW",
                "issue":
                    "RESTORE_SIMULATION_NOT_READY",
                "next_action":
                    "CURRENT Recovery Point / Manifest / Dry-run 상태 확인",
                "go_to":
                    "Save Center",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            RECOVERY_RESILIENCE_QUEUE_COLS
        )

    order = {
        "RS0": 0,
        "RS1": 1,
        "RS2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            RECOVERY_RESILIENCE_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )


def build_recovery_resilience_snapshot(
    drift: dict,
    rotation: dict,
    simulation: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    issues = list(
        dict.fromkeys(
            list(
                drift.get(
                    "issues",
                    [],
                )
            )
            + list(
                rotation.get(
                    "issues",
                    [],
                )
            )
            + list(
                simulation.get(
                    "issues",
                    [],
                )
            )
        )
    )

    payload = {
        "drift_status":
            _text(
                drift.get(
                    "drift_status"
                )
            ),
        "current_manifest_sha256":
            _text(
                drift.get(
                    "current_manifest_sha256"
                )
            ),
        "matching_recovery_point_id":
            _text(
                drift.get(
                    "matching_recovery_point_id"
                )
            ),
        "matching_lock_integrity":
            _text(
                drift.get(
                    "matching_lock_integrity"
                )
            ),
        "locked_points":
            _int(
                rotation.get(
                    "locked_points"
                )
            ),
        "rotation_keep_latest":
            _int(
                rotation.get(
                    "keep_latest"
                )
            ),
        "rotation_candidates":
            _int(
                rotation.get(
                    "archive_candidates"
                )
            ),
        "rotation_status":
            _text(
                rotation.get(
                    "rotation_status"
                )
            ),
        "restore_simulation_status":
            _text(
                simulation.get(
                    "simulation_status"
                )
            ),
        "simulation_steps":
            _int(
                simulation.get(
                    "step_count"
                )
            ),
        "restore_authorization":
            "NONE",
        "issues":
            " | ".join(
                issues
            ),
    }

    snapshot_hash = _hash(
        payload
    )

    snapshot_id = (
        "RRSIM-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot_hash[:8]
    )

    return {
        "snapshot_id":
            snapshot_id,
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
