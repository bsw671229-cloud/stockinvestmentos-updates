from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.decision_learning_lineage import (
    decision_learning_lineage_integrity,
)


FORECAST_ERROR_CLASSES = [
    "MODEL",
    "PARAMETER",
    "EXECUTION",
    "EXOGENOUS",
    "NONE",
    "OTHER",
]


FORECAST_RECURRENCE_COHORT_COLS = [
    "scope",
    "company",
    "forecast_error_class",
    "sample_size",
    "error_count",
    "error_share",
    "process_followed_count",
    "process_other_count",
    "earliest_at",
    "latest_at",
    "recurrence_status",
    "review_lane",
    "issue",
    "next_action",
]


FORECAST_RECURRENCE_QUEUE_COLS = [
    "priority",
    "scope",
    "company",
    "forecast_error_class",
    "status",
    "error_count",
    "sample_size",
    "error_share",
    "issue",
    "next_action",
    "go_to",
]


FORECAST_RECURRENCE_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "audit_status",
    "lookback_days",
    "min_repeat_count",
    "learning_complete_total",
    "valid_learning_records",
    "integrity_issues",
    "recurring_patterns",
    "companies_with_recurrence",
    "process_followed_error_records",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _normalize_error_class(value: Any) -> str:
    raw = _text(
        value
    ).upper()

    if raw in {
        "MODEL",
        "PARAMETER",
        "EXECUTION",
        "EXOGENOUS",
        "NONE",
    }:
        return raw

    if raw in {
        "",
        "N/A",
        "NA",
        "NO_ERROR",
        "NO ERROR",
    }:
        return "NONE"

    return "OTHER"


def _review_lane(error_class: str) -> str:
    error = _normalize_error_class(
        error_class
    )

    mapping = {
        "MODEL":
            "MODEL_REVIEW",
        "PARAMETER":
            "ASSUMPTION_REVALIDATION",
        "EXECUTION":
            "PROCESS_REVIEW",
        "EXOGENOUS":
            "EVIDENCE_REGIME_REVIEW",
        "NONE":
            "OBSERVE",
        "OTHER":
            "CLASSIFICATION_REVIEW",
    }
    return mapping[
        error
    ]


def _next_action(error_class: str) -> str:
    error = _normalize_error_class(
        error_class
    )

    mapping = {
        "MODEL":
            "반복 Model Error의 공통 가정·구조·누락 Driver를 Red Team 검토",
        "PARAMETER":
            "반복 Parameter Error의 Forward ER / Risk / Hurdle calibration 근거를 재검토",
        "EXECUTION":
            "반복 Execution Error의 주문계획·체결·Slippage·Process adherence를 재검토",
        "EXOGENOUS":
            "반복 Exogenous Error가 같은 Regime/Evidence blind spot인지 검토",
        "NONE":
            "현재 분류를 유지하고 새 Proof/Outcome을 축적",
        "OTHER":
            "Forecast Error Classification 기준을 Human Review",
    }
    return mapping[
        error
    ]


def _prepare_learning_records(
    learning_lineages: pd.DataFrame | None,
    *,
    lookback_days: int,
    today: date,
) -> tuple[pd.DataFrame, int, int]:
    if (
        learning_lineages is None
        or learning_lineages.empty
    ):
        return (
            pd.DataFrame(),
            0,
            0,
        )

    df = learning_lineages.copy()

    for col in [
        "learning_status",
        "company",
        "forecast_error_class",
        "process_adherence",
        "created_at",
    ]:
        if col not in df.columns:
            df[
                col
            ] = ""

    completed = df.loc[
        df[
            "learning_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "LEARNING_COMPLETE"
        )
    ].copy()

    total_complete = int(
        len(
            completed
        )
    )

    if completed.empty:
        return (
            completed,
            0,
            0,
        )

    integrity_status = []
    for _, row in completed.iterrows():
        integrity_status.append(
            decision_learning_lineage_integrity(
                row.to_dict()
            )[
                "status"
            ]
        )

    completed[
        "_integrity_status"
    ] = integrity_status

    integrity_issues = int(
        (
            completed[
                "_integrity_status"
            ]
            != "OK"
        ).sum()
    )

    valid = completed.loc[
        completed[
            "_integrity_status"
        ].eq(
            "OK"
        )
    ].copy()

    if valid.empty:
        return (
            valid,
            total_complete,
            integrity_issues,
        )

    valid[
        "_created_at"
    ] = pd.to_datetime(
        valid[
            "created_at"
        ],
        errors="coerce",
        utc=True,
    )

    cutoff = (
        pd.Timestamp(
            today
        )
        .tz_localize(
            "UTC"
        )
        - pd.Timedelta(
            days=max(
                1,
                int(
                    lookback_days
                ),
            )
        )
    )

    valid = valid.loc[
        valid[
            "_created_at"
        ].isna()
        | (
            valid[
                "_created_at"
            ]
            >= cutoff
        )
    ].copy()

    valid[
        "_error_class"
    ] = valid[
        "forecast_error_class"
    ].map(
        _normalize_error_class
    )

    valid[
        "_process_adherence"
    ] = (
        valid[
            "process_adherence"
        ]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
    )

    return (
        valid,
        total_complete,
        integrity_issues,
    )


def _cohort_rows(
    valid: pd.DataFrame,
    *,
    scope: str,
    company: str,
    min_repeat_count: int,
) -> list[dict]:
    if valid.empty:
        return []

    sample_size = int(
        len(
            valid
        )
    )

    rows = []

    grouped = (
        valid.groupby(
            "_error_class",
            dropna=False,
        )
    )

    for error_class, group in grouped:
        error = _normalize_error_class(
            error_class
        )
        count = int(
            len(
                group
            )
        )
        share = (
            float(
                count
            )
            / float(
                sample_size
            )
            if sample_size > 0
            else 0.0
        )

        followed = int(
            group[
                "_process_adherence"
            ].eq(
                "FOLLOWED"
            ).sum()
        )

        process_other = int(
            (
                group[
                    "_process_adherence"
                ].ne(
                    ""
                )
                & group[
                    "_process_adherence"
                ].ne(
                    "FOLLOWED"
                )
            ).sum()
        )

        recurring = (
            error
            not in {
                "NONE"
            }
            and count
            >= max(
                2,
                int(
                    min_repeat_count
                ),
            )
        )

        if recurring:
            recurrence_status = "REVIEW"
            issue = (
                f"{error}가 동일 scope에서 "
                f"{count}회 반복"
            )
        else:
            recurrence_status = "OBSERVE"
            issue = ""

        created = group[
            "_created_at"
        ].dropna()

        rows.append(
            {
                "scope":
                    scope,
                "company":
                    company,
                "forecast_error_class":
                    error,
                "sample_size":
                    sample_size,
                "error_count":
                    count,
                "error_share":
                    share,
                "process_followed_count":
                    followed,
                "process_other_count":
                    process_other,
                "earliest_at":
                    (
                        created.min().isoformat()
                        if not created.empty
                        else ""
                    ),
                "latest_at":
                    (
                        created.max().isoformat()
                        if not created.empty
                        else ""
                    ),
                "recurrence_status":
                    recurrence_status,
                "review_lane":
                    _review_lane(
                        error
                    ),
                "issue":
                    issue,
                "next_action":
                    _next_action(
                        error
                    ),
            }
        )

    return rows


def build_forecast_error_recurrence(
    learning_lineages: pd.DataFrame | None,
    *,
    lookback_days: int = 365,
    min_repeat_count: int = 3,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()

    valid, total_complete, integrity_issues = (
        _prepare_learning_records(
            learning_lineages,
            lookback_days=lookback_days,
            today=current_date,
        )
    )

    rows = []

    if not valid.empty:
        rows += _cohort_rows(
            valid,
            scope="GLOBAL",
            company="ALL",
            min_repeat_count=min_repeat_count,
        )

        companies = (
            valid[
                "company"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .replace(
                "",
                "UNKNOWN",
            )
            .unique()
            .tolist()
        )

        for company in companies:
            company_df = valid.loc[
                valid[
                    "company"
                ]
                .fillna("")
                .astype(str)
                .str.strip()
                .replace(
                    "",
                    "UNKNOWN",
                )
                .eq(
                    company
                )
            ].copy()

            rows += _cohort_rows(
                company_df,
                scope="COMPANY",
                company=company,
                min_repeat_count=min_repeat_count,
            )

    cohort = (
        pd.DataFrame(
            rows,
            columns=
            FORECAST_RECURRENCE_COHORT_COLS,
        )
        if rows
        else pd.DataFrame(
            columns=
            FORECAST_RECURRENCE_COHORT_COLS,
        )
    )

    recurring_patterns = int(
        (
            cohort[
                "recurrence_status"
            ]
            .fillna("")
            .astype(str)
            .eq(
                "REVIEW"
            )
        ).sum()
    ) if not cohort.empty else 0

    companies_with_recurrence = int(
        cohort.loc[
            cohort[
                "scope"
            ]
            .eq(
                "COMPANY"
            )
            & cohort[
                "recurrence_status"
            ]
            .eq(
                "REVIEW"
            ),
            "company",
        ].nunique()
    ) if not cohort.empty else 0

    process_followed_error_records = 0
    if not valid.empty:
        process_followed_error_records = int(
            (
                valid[
                    "_error_class"
                ].ne(
                    "NONE"
                )
                & valid[
                    "_process_adherence"
                ].eq(
                    "FOLLOWED"
                )
            ).sum()
        )

    if integrity_issues > 0:
        audit_status = "INTEGRITY_REVIEW"
    elif len(
        valid
    ) == 0:
        audit_status = "NO_DATA"
    elif recurring_patterns > 0:
        audit_status = "REVIEW"
    else:
        audit_status = "PASS"

    return {
        "audit_status":
            audit_status,
        "lookback_days":
            max(
                1,
                int(
                    lookback_days
                ),
            ),
        "min_repeat_count":
            max(
                2,
                int(
                    min_repeat_count
                ),
            ),
        "learning_complete_total":
            total_complete,
        "valid_learning_records":
            int(
                len(
                    valid
                )
            ),
        "integrity_issues":
            integrity_issues,
        "recurring_patterns":
            recurring_patterns,
        "companies_with_recurrence":
            companies_with_recurrence,
        "process_followed_error_records":
            process_followed_error_records,
        "cohort":
            cohort,
        "execution_authorization":
            "NONE",
    }


def build_forecast_recurrence_queue(
    recurrence_result: dict,
) -> pd.DataFrame:
    result = recurrence_result or {}
    rows = []

    integrity_issues = int(
        result.get(
            "integrity_issues",
            0,
        )
        or 0
    )

    if integrity_issues > 0:
        rows.append(
            {
                "priority": "FR0",
                "scope": "GLOBAL",
                "company": "ALL",
                "forecast_error_class": "",
                "status": "INTEGRITY_REVIEW",
                "error_count": integrity_issues,
                "sample_size": int(
                    result.get(
                        "learning_complete_total",
                        0,
                    )
                    or 0
                ),
                "error_share": 0.0,
                "issue": (
                    f"Learning lineage integrity issue "
                    f"{integrity_issues}건"
                ),
                "next_action":
                    "Decision Journal / Learning Lineage Hash 무결성 확인",
                "go_to":
                    "Decision Journal",
            }
        )

    cohort = result.get(
        "cohort"
    )

    if (
        isinstance(
            cohort,
            pd.DataFrame,
        )
        and not cohort.empty
    ):
        recurring = cohort.loc[
            cohort[
                "recurrence_status"
            ]
            .fillna("")
            .astype(str)
            .eq(
                "REVIEW"
            )
        ].copy()

        for _, row in recurring.iterrows():
            scope = _text(
                row.get(
                    "scope"
                )
            )
            company = _text(
                row.get(
                    "company"
                )
            )
            error_class = _text(
                row.get(
                    "forecast_error_class"
                )
            )

            priority = (
                "FR1"
                if scope == "COMPANY"
                else "FR2"
            )

            rows.append(
                {
                    "priority":
                        priority,
                    "scope":
                        scope,
                    "company":
                        company,
                    "forecast_error_class":
                        error_class,
                    "status":
                        "RECURRENCE_REVIEW",
                    "error_count":
                        int(
                            row.get(
                                "error_count",
                                0,
                            )
                            or 0
                        ),
                    "sample_size":
                        int(
                            row.get(
                                "sample_size",
                                0,
                            )
                            or 0
                        ),
                    "error_share":
                        float(
                            row.get(
                                "error_share",
                                0.0,
                            )
                            or 0.0
                        ),
                    "issue":
                        _text(
                            row.get(
                                "issue"
                            )
                        ),
                    "next_action":
                        _text(
                            row.get(
                                "next_action"
                            )
                        ),
                    "go_to":
                        "Decision Journal",
                }
            )

    if not rows:
        return pd.DataFrame(
            columns=
            FORECAST_RECURRENCE_QUEUE_COLS
        )

    out = pd.DataFrame(
        rows
    )

    priority_order = {
        "FR0": 0,
        "FR1": 1,
        "FR2": 2,
    }

    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        priority_order
    ).fillna(
        9
    )

    out = out.sort_values(
        [
            "_p",
            "scope",
            "company",
            "forecast_error_class",
        ],
        ascending=[
            True,
            True,
            True,
            True,
        ],
    ).drop(
        columns=[
            "_p"
        ]
    )

    return out[
        FORECAST_RECURRENCE_QUEUE_COLS
    ].reset_index(
        drop=True
    )


def build_forecast_recurrence_snapshot(
    recurrence_result: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    result = recurrence_result or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    cohort = result.get(
        "cohort"
    )

    cohort_payload = (
        []
        if not isinstance(
            cohort,
            pd.DataFrame,
        )
        or cohort.empty
        else cohort.fillna(
            ""
        ).to_dict(
            orient="records"
        )
    )

    summary_payload = {
        "audit_status":
            _text(
                result.get(
                    "audit_status"
                )
            ),
        "lookback_days":
            int(
                result.get(
                    "lookback_days",
                    365,
                )
            ),
        "min_repeat_count":
            int(
                result.get(
                    "min_repeat_count",
                    3,
                )
            ),
        "learning_complete_total":
            int(
                result.get(
                    "learning_complete_total",
                    0,
                )
            ),
        "valid_learning_records":
            int(
                result.get(
                    "valid_learning_records",
                    0,
                )
            ),
        "integrity_issues":
            int(
                result.get(
                    "integrity_issues",
                    0,
                )
            ),
        "recurring_patterns":
            int(
                result.get(
                    "recurring_patterns",
                    0,
                )
            ),
        "companies_with_recurrence":
            int(
                result.get(
                    "companies_with_recurrence",
                    0,
                )
            ),
        "process_followed_error_records":
            int(
                result.get(
                    "process_followed_error_records",
                    0,
                )
            ),
    }

    snapshot_hash = _hash(
        {
            "summary":
                summary_payload,
            "cohort":
                cohort_payload,
        }
    )

    snapshot_id = (
        "FCR-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot_hash[:8]
    )

    return {
        "snapshot_id":
            snapshot_id,
        "created_at":
            now,
        **summary_payload,
        "execution_authorization":
            "NONE",
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
