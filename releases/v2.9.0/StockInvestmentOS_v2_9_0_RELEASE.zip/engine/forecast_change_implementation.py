from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.forecast_change_registry import (
    forecast_change_plan_integrity,
)
from engine.decision_learning_lineage import (
    decision_learning_lineage_integrity,
)


FORECAST_IMPLEMENTATION_ACTIONS = [
    "IMPLEMENTED_EXTERNALLY",
    "NO_CHANGE_AFTER_REVIEW",
]


FORECAST_IMPLEMENTATION_COLS = [
    "implementation_id",
    "created_at",
    "change_plan_id",
    "change_plan_record_hash",
    "change_plan_integrity_status",
    "scope",
    "company",
    "forecast_error_class",
    "change_area",
    "change_target",
    "source_cohort_hash",
    "baseline_sample_size",
    "baseline_error_count",
    "baseline_error_share",
    "implementation_action",
    "implementation_date",
    "implementation_reference",
    "implementation_summary",
    "proof_date",
    "baseline_locked_confirmed",
    "source_review_confirmed",
    "no_auto_apply_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "event_gate",
    "implementation_status",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


FORECAST_IMPLEMENTATION_QUEUE_COLS = [
    "priority",
    "company",
    "forecast_error_class",
    "change_area",
    "implementation_status",
    "proof_date",
    "days_to_proof",
    "before_after_status",
    "post_sample_size",
    "baseline_error_share",
    "post_error_share",
    "error_share_delta",
    "comparison",
    "issue",
    "next_action",
    "go_to",
    "change_plan_id",
    "implementation_id",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _stable_num(
    value: Any,
    places: int = 12,
) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _parse_date(
    value: Any,
) -> date | None:
    ts = pd.to_datetime(
        value,
        errors="coerce",
    )
    if pd.isna(ts):
        return None
    return ts.date()


def validate_forecast_implementation_event(
    plan_row: dict | None,
    *,
    implementation_action: str,
    implementation_date: str,
    implementation_reference: str,
    implementation_summary: str,
    baseline_locked_confirmed: bool,
    source_review_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()
    plan = plan_row or {}
    issues = []

    plan_integrity = forecast_change_plan_integrity(
        plan
    )

    if plan_integrity[
        "status"
    ] != "OK":
        issues.append(
            "CHANGE_PLAN_INTEGRITY_FAILED"
        )

    if _text(
        plan.get(
            "plan_status"
        )
    ).upper() != "REGISTERED_FOR_IMPLEMENTATION_REVIEW":
        issues.append(
            "CHANGE_PLAN_NOT_REGISTERED_FOR_IMPLEMENTATION_REVIEW"
        )

    if _text(
        plan.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    action = _text(
        implementation_action
    ).upper()

    if action not in FORECAST_IMPLEMENTATION_ACTIONS:
        issues.append(
            "IMPLEMENTATION_ACTION_REQUIRED"
        )

    event_date = _parse_date(
        implementation_date
    )
    plan_date = _parse_date(
        plan.get(
            "created_at"
        )
    )

    if event_date is None:
        issues.append(
            "IMPLEMENTATION_DATE_REQUIRED"
        )
    else:
        if event_date > current_date:
            issues.append(
                "IMPLEMENTATION_DATE_CANNOT_BE_FUTURE"
            )
        if (
            plan_date is not None
            and event_date < plan_date
        ):
            issues.append(
                "IMPLEMENTATION_DATE_BEFORE_PLAN"
            )

    if not _text(
        implementation_summary
    ):
        issues.append(
            "IMPLEMENTATION_SUMMARY_REQUIRED"
        )

    if (
        action == "IMPLEMENTED_EXTERNALLY"
        and not _text(
            implementation_reference
        )
    ):
        issues.append(
            "IMPLEMENTATION_REFERENCE_REQUIRED"
        )

    confirmations = {
        "BASELINE_LOCK_CONFIRMATION_REQUIRED":
            baseline_locked_confirmed,
        "SOURCE_REVIEW_CONFIRMATION_REQUIRED":
            source_review_confirmed,
        "NO_AUTO_APPLY_CONFIRMATION_REQUIRED":
            no_auto_apply_confirmed,
        "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED":
            no_execution_authorization_confirmed,
        "HUMAN_REVIEW_CONFIRMATION_REQUIRED":
            human_review_confirmed,
    }

    for issue, passed in confirmations.items():
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    event_gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    if event_gate != "PASS":
        implementation_status = "DRAFT"
    elif action == "IMPLEMENTED_EXTERNALLY":
        implementation_status = "IMPLEMENTED_BASELINE_LOCKED"
    else:
        implementation_status = "NO_CHANGE_REVIEWED"

    return {
        "event_gate":
            event_gate,
        "implementation_status":
            implementation_status,
        "plan_integrity_status":
            plan_integrity[
                "status"
            ],
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _record_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "baseline_locked_confirmed",
        "source_review_confirmed",
        "no_auto_apply_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }
    numeric_fields = {
        "baseline_error_share",
    }

    payload = {}
    for field in FORECAST_IMPLEMENTATION_COLS:
        if field == "record_hash":
            continue

        if field in bool_fields:
            payload[field] = bool(
                _bool(
                    row.get(
                        field
                    )
                )
            )
        elif field in numeric_fields:
            payload[field] = _stable_num(
                row.get(
                    field
                )
            )
        else:
            payload[field] = _text(
                row.get(
                    field
                )
            )

    return payload


def build_forecast_implementation_record(
    plan_row: dict,
    validation: dict,
    *,
    implementation_action: str,
    implementation_date: str,
    implementation_reference: str,
    implementation_summary: str,
    baseline_locked_confirmed: bool,
    source_review_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    plan = plan_row or {}
    review = validation or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    plan_id = _text(
        plan.get(
            "change_plan_id"
        )
    )
    plan_hash = _text(
        plan.get(
            "record_hash"
        )
    )

    implementation_id = (
        "FCI-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            (
                plan_id
                + "|"
                + _text(
                    implementation_action
                ).upper()
                + "|"
                + _text(
                    implementation_date
                )
            ).encode(
                "utf-8"
            )
        ).hexdigest()[:8]
    )

    row = {
        "implementation_id":
            implementation_id,
        "created_at":
            now,
        "change_plan_id":
            plan_id,
        "change_plan_record_hash":
            plan_hash,
        "change_plan_integrity_status":
            _text(
                review.get(
                    "plan_integrity_status"
                )
            ),
        "scope":
            _text(
                plan.get(
                    "scope"
                )
            ),
        "company":
            _text(
                plan.get(
                    "company"
                )
            ),
        "forecast_error_class":
            _text(
                plan.get(
                    "forecast_error_class"
                )
            ).upper(),
        "change_area":
            _text(
                plan.get(
                    "change_area"
                )
            ).upper(),
        "change_target":
            _text(
                plan.get(
                    "change_target"
                )
            ),
        "source_cohort_hash":
            _text(
                plan.get(
                    "source_cohort_hash"
                )
            ),
        "baseline_sample_size":
            int(
                _num(
                    plan.get(
                        "source_sample_size"
                    )
                )
                or 0
            ),
        "baseline_error_count":
            int(
                _num(
                    plan.get(
                        "source_error_count"
                    )
                )
                or 0
            ),
        "baseline_error_share":
            float(
                _num(
                    plan.get(
                        "source_error_share"
                    )
                )
                or 0.0
            ),
        "implementation_action":
            _text(
                implementation_action
            ).upper(),
        "implementation_date":
            _text(
                implementation_date
            ),
        "implementation_reference":
            _text(
                implementation_reference
            ),
        "implementation_summary":
            _text(
                implementation_summary
            ),
        "proof_date":
            _text(
                plan.get(
                    "proof_date"
                )
            ),
        "baseline_locked_confirmed":
            bool(
                baseline_locked_confirmed
            ),
        "source_review_confirmed":
            bool(
                source_review_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "event_gate":
            _text(
                review.get(
                    "event_gate"
                )
            ),
        "implementation_status":
            _text(
                review.get(
                    "implementation_status"
                )
            ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                review.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _record_payload(
            row
        )
    )

    return row


def forecast_implementation_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _record_payload(
            record
        )
    )

    return {
        "status":
            "OK"
            if stored
            == calculated
            else "MISMATCH",
        "calculated_hash":
            calculated,
    }


def latest_forecast_implementation(
    events: pd.DataFrame | None,
    change_plan_id: str,
) -> dict:
    if events is None or events.empty:
        return {}

    if "change_plan_id" not in events.columns:
        return {}

    hit = events.loc[
        events[
            "change_plan_id"
        ]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(
                change_plan_id
            )
        )
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit[
            "_ts"
        ] = pd.to_datetime(
            hit[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )

        hit = hit.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        hit.iloc[0]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def build_before_after_cohort(
    plan_row: dict | None,
    implementation_row: dict | None,
    learning_lineages: pd.DataFrame | None,
    *,
    min_post_samples: int = 3,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()
    plan = plan_row or {}
    event = implementation_row or {}

    issues = []

    plan_integrity = forecast_change_plan_integrity(
        plan
    )
    event_integrity = forecast_implementation_integrity(
        event
    )

    if plan_integrity[
        "status"
    ] != "OK":
        issues.append(
            "CHANGE_PLAN_INTEGRITY_FAILED"
        )

    if event_integrity[
        "status"
    ] != "OK":
        issues.append(
            "IMPLEMENTATION_EVENT_INTEGRITY_FAILED"
        )

    if _text(
        event.get(
            "change_plan_id"
        )
    ) != _text(
        plan.get(
            "change_plan_id"
        )
    ):
        issues.append(
            "CHANGE_PLAN_ID_MISMATCH"
        )

    if _text(
        event.get(
            "change_plan_record_hash"
        )
    ) != _text(
        plan.get(
            "record_hash"
        )
    ):
        issues.append(
            "CHANGE_PLAN_HASH_SNAPSHOT_MISMATCH"
        )

    if _text(
        event.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    implementation_status = _text(
        event.get(
            "implementation_status"
        )
    ).upper()

    baseline_sample_size = int(
        _num(
            event.get(
                "baseline_sample_size"
            )
        )
        or 0
    )
    baseline_error_count = int(
        _num(
            event.get(
                "baseline_error_count"
            )
        )
        or 0
    )
    baseline_error_share = float(
        _num(
            event.get(
                "baseline_error_share"
            )
        )
        or 0.0
    )

    if issues:
        return {
            "before_after_status":
                "INVALIDATED",
            "comparison":
                "NOT_EVALUABLE",
            "baseline_sample_size":
                baseline_sample_size,
            "baseline_error_count":
                baseline_error_count,
            "baseline_error_share":
                baseline_error_share,
            "post_sample_size":
                0,
            "post_error_count":
                0,
            "post_error_share":
                None,
            "error_share_delta":
                None,
            "proof_date_reached":
                False,
            "min_post_samples":
                max(
                    1,
                    int(
                        min_post_samples
                    ),
                ),
            "execution_authorization":
                "NONE",
            "issues":
                list(
                    dict.fromkeys(
                        issues
                    )
                ),
        }

    if implementation_status == "NO_CHANGE_REVIEWED":
        return {
            "before_after_status":
                "CLOSED_NO_IMPLEMENTATION",
            "comparison":
                "NO_IMPLEMENTATION",
            "baseline_sample_size":
                baseline_sample_size,
            "baseline_error_count":
                baseline_error_count,
            "baseline_error_share":
                baseline_error_share,
            "post_sample_size":
                0,
            "post_error_count":
                0,
            "post_error_share":
                None,
            "error_share_delta":
                None,
            "proof_date_reached":
                (
                    _parse_date(
                        event.get(
                            "proof_date"
                        )
                    )
                    is not None
                    and current_date
                    >= _parse_date(
                        event.get(
                            "proof_date"
                        )
                    )
                ),
            "min_post_samples":
                max(
                    1,
                    int(
                        min_post_samples
                    ),
                ),
            "execution_authorization":
                "NONE",
            "issues":
                [],
        }

    if implementation_status != "IMPLEMENTED_BASELINE_LOCKED":
        return {
            "before_after_status":
                "IMPLEMENTATION_REVIEW",
            "comparison":
                "NOT_EVALUABLE",
            "baseline_sample_size":
                baseline_sample_size,
            "baseline_error_count":
                baseline_error_count,
            "baseline_error_share":
                baseline_error_share,
            "post_sample_size":
                0,
            "post_error_count":
                0,
            "post_error_share":
                None,
            "error_share_delta":
                None,
            "proof_date_reached":
                False,
            "min_post_samples":
                max(
                    1,
                    int(
                        min_post_samples
                    ),
                ),
            "execution_authorization":
                "NONE",
            "issues":
                [
                    "IMPLEMENTATION_STATUS_NOT_READY"
                ],
        }

    if (
        learning_lineages is None
        or learning_lineages.empty
    ):
        post = pd.DataFrame()
    else:
        post = learning_lineages.copy()

    for col in [
        "learning_status",
        "company",
        "forecast_error_class",
        "created_at",
    ]:
        if col not in post.columns:
            post[
                col
            ] = ""

    post = post.loc[
        post[
            "learning_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "LEARNING_COMPLETE"
        )
    ].copy()

    if not post.empty:
        integrity = []
        for _, row in post.iterrows():
            integrity.append(
                decision_learning_lineage_integrity(
                    row.to_dict()
                )[
                    "status"
                ]
            )
        post[
            "_integrity"
        ] = integrity

        if (
            post[
                "_integrity"
            ]
            .ne(
                "OK"
            )
            .any()
        ):
            issues.append(
                "POST_LEARNING_INTEGRITY_ISSUE"
            )

        post = post.loc[
            post[
                "_integrity"
            ]
            .eq(
                "OK"
            )
        ].copy()

        post[
            "_ts"
        ] = pd.to_datetime(
            post[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )

        implementation_date = _parse_date(
            event.get(
                "implementation_date"
            )
        )

        if implementation_date is None:
            issues.append(
                "IMPLEMENTATION_DATE_REQUIRED"
            )
            post = post.iloc[0:0]
        else:
            cutoff = pd.Timestamp(
                implementation_date
            ).tz_localize(
                "UTC"
            )

            post = post.loc[
                post[
                    "_ts"
                ].notna()
                & (
                    post[
                        "_ts"
                    ]
                    >= cutoff
                )
            ].copy()

        scope = _text(
            event.get(
                "scope"
            )
        ).upper()
        company = _text(
            event.get(
                "company"
            )
        )

        if scope == "COMPANY":
            post = post.loc[
                post[
                    "company"
                ]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(
                    company
                )
            ].copy()

    post_sample_size = int(
        len(
            post
        )
    )

    error_class = _text(
        event.get(
            "forecast_error_class"
        )
    ).upper()

    post_error_count = 0
    if not post.empty:
        post_error_count = int(
            post[
                "forecast_error_class"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq(
                error_class
            )
            .sum()
        )

    post_error_share = (
        float(
            post_error_count
        )
        / float(
            post_sample_size
        )
        if post_sample_size > 0
        else None
    )

    error_share_delta = (
        None
        if post_error_share is None
        else (
            post_error_share
            - baseline_error_share
        )
    )

    if post_error_share is None:
        comparison = "NO_POST_DATA"
    elif abs(
        error_share_delta
    ) <= 1e-12:
        comparison = "SAME_ERROR_SHARE"
    elif error_share_delta < 0:
        comparison = "LOWER_ERROR_SHARE"
    else:
        comparison = "HIGHER_ERROR_SHARE"

    proof_date = _parse_date(
        event.get(
            "proof_date"
        )
    )
    proof_date_reached = (
        proof_date is not None
        and current_date >= proof_date
    )

    min_samples = max(
        1,
        int(
            min_post_samples
        ),
    )

    if issues:
        before_after_status = "INTEGRITY_REVIEW"
    elif post_sample_size == 0:
        before_after_status = "POST_DATA_PENDING"
    elif (
        post_sample_size
        < min_samples
        or not proof_date_reached
    ):
        before_after_status = "EVIDENCE_ACCUMULATING"
    else:
        before_after_status = "PROOF_READY"

    return {
        "before_after_status":
            before_after_status,
        "comparison":
            comparison,
        "baseline_sample_size":
            baseline_sample_size,
        "baseline_error_count":
            baseline_error_count,
        "baseline_error_share":
            baseline_error_share,
        "post_sample_size":
            post_sample_size,
        "post_error_count":
            post_error_count,
        "post_error_share":
            post_error_share,
        "error_share_delta":
            error_share_delta,
        "proof_date_reached":
            proof_date_reached,
        "min_post_samples":
            min_samples,
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def build_forecast_implementation_queue(
    plans: pd.DataFrame | None,
    events: pd.DataFrame | None,
    learning_lineages: pd.DataFrame | None,
    *,
    min_post_samples: int = 3,
    today: date | None = None,
) -> pd.DataFrame:
    current_date = today or date.today()

    if plans is None or plans.empty:
        return pd.DataFrame(
            columns=
            FORECAST_IMPLEMENTATION_QUEUE_COLS
        )

    plan_df = plans.copy()

    for col in [
        "change_plan_id",
        "company",
        "forecast_error_class",
        "change_area",
        "plan_status",
        "proof_date",
        "record_hash",
    ]:
        if col not in plan_df.columns:
            plan_df[
                col
            ] = ""

    event_df = (
        pd.DataFrame()
        if events is None
        else events.copy()
    )

    rows = []

    registered = plan_df.loc[
        plan_df[
            "plan_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "REGISTERED_FOR_IMPLEMENTATION_REVIEW"
        )
    ].copy()

    for _, plan_row in registered.iterrows():
        plan = plan_row.to_dict()
        plan_id = _text(
            plan.get(
                "change_plan_id"
            )
        )

        plan_integrity = forecast_change_plan_integrity(
            plan
        )

        proof_date = _parse_date(
            plan.get(
                "proof_date"
            )
        )
        days_to_proof = (
            None
            if proof_date is None
            else (
                proof_date
                - current_date
            ).days
        )

        if plan_integrity[
            "status"
        ] != "OK":
            rows.append(
                {
                    "priority":"FI0",
                    "company":_text(plan.get("company")),
                    "forecast_error_class":_text(plan.get("forecast_error_class")),
                    "change_area":_text(plan.get("change_area")),
                    "implementation_status":"PLAN_INTEGRITY_REVIEW",
                    "proof_date":_text(plan.get("proof_date")),
                    "days_to_proof":days_to_proof,
                    "before_after_status":"INVALIDATED",
                    "post_sample_size":0,
                    "baseline_error_share":_num(plan.get("source_error_share")),
                    "post_error_share":None,
                    "error_share_delta":None,
                    "comparison":"NOT_EVALUABLE",
                    "issue":"FORECAST_CHANGE_PLAN_HASH_MISMATCH",
                    "next_action":"Forecast Change Plan Hash 무결성 확인",
                    "go_to":"Decision Journal",
                    "change_plan_id":plan_id,
                    "implementation_id":"",
                }
            )
            continue

        event = latest_forecast_implementation(
            event_df,
            plan_id,
        )

        if not event:
            rows.append(
                {
                    "priority":"FI1",
                    "company":_text(plan.get("company")),
                    "forecast_error_class":_text(plan.get("forecast_error_class")),
                    "change_area":_text(plan.get("change_area")),
                    "implementation_status":"IMPLEMENTATION_EVENT_PENDING",
                    "proof_date":_text(plan.get("proof_date")),
                    "days_to_proof":days_to_proof,
                    "before_after_status":"NOT_STARTED",
                    "post_sample_size":0,
                    "baseline_error_share":_num(plan.get("source_error_share")),
                    "post_error_share":None,
                    "error_share_delta":None,
                    "comparison":"NOT_EVALUABLE",
                    "issue":"IMPLEMENTATION_EVENT_NOT_RECORDED",
                    "next_action":"실제 원본 Review 결과를 확인한 뒤 Implementation Event 기록",
                    "go_to":"Decision Journal",
                    "change_plan_id":plan_id,
                    "implementation_id":"",
                }
            )
            continue

        event_integrity = forecast_implementation_integrity(
            event
        )

        if event_integrity[
            "status"
        ] != "OK":
            rows.append(
                {
                    "priority":"FI0",
                    "company":_text(plan.get("company")),
                    "forecast_error_class":_text(plan.get("forecast_error_class")),
                    "change_area":_text(plan.get("change_area")),
                    "implementation_status":"IMPLEMENTATION_INTEGRITY_REVIEW",
                    "proof_date":_text(plan.get("proof_date")),
                    "days_to_proof":days_to_proof,
                    "before_after_status":"INVALIDATED",
                    "post_sample_size":0,
                    "baseline_error_share":_num(event.get("baseline_error_share")),
                    "post_error_share":None,
                    "error_share_delta":None,
                    "comparison":"NOT_EVALUABLE",
                    "issue":"IMPLEMENTATION_EVENT_HASH_MISMATCH",
                    "next_action":"Implementation Event Hash 무결성 확인",
                    "go_to":"Decision Journal",
                    "change_plan_id":plan_id,
                    "implementation_id":_text(event.get("implementation_id")),
                }
            )
            continue

        if _text(
            event.get(
                "implementation_status"
            )
        ).upper() == "NO_CHANGE_REVIEWED":
            # Human review decided not to implement. This is a closed implementation loop,
            # so it is not an active queue item.
            continue

        evaluation = build_before_after_cohort(
            plan,
            event,
            learning_lineages,
            min_post_samples=min_post_samples,
            today=current_date,
        )

        status = _text(
            evaluation.get(
                "before_after_status"
            )
        ).upper()

        if status in {
            "INVALIDATED",
            "INTEGRITY_REVIEW",
            "IMPLEMENTATION_REVIEW",
        }:
            priority = "FI0"
            issue = "BEFORE_AFTER_INTEGRITY_REVIEW"
            next_action = "Plan / Implementation / Learning Lineage 무결성 확인"
        elif status == "POST_DATA_PENDING":
            priority = "FI2"
            issue = "POST_IMPLEMENTATION_LEARNING_DATA_PENDING"
            next_action = "새 Outcome / LEARNING_COMPLETE 기록을 기다림"
        elif status == "EVIDENCE_ACCUMULATING":
            priority = "FI3"
            issue = "POST_IMPLEMENTATION_EVIDENCE_ACCUMULATING"
            next_action = "Proof Date / 최소 post sample까지 evidence 축적"
        elif status == "PROOF_READY":
            priority = "FI4"
            issue = "BEFORE_AFTER_PROOF_READY"
            next_action = "Before/After error share를 Human Review하고 Change 효과를 별도 판정"
        else:
            priority = "FI2"
            issue = "IMPLEMENTATION_STATUS_REVIEW"
            next_action = "Implementation / Before-After 상태 확인"

        rows.append(
            {
                "priority":priority,
                "company":_text(plan.get("company")),
                "forecast_error_class":_text(plan.get("forecast_error_class")),
                "change_area":_text(plan.get("change_area")),
                "implementation_status":_text(event.get("implementation_status")),
                "proof_date":_text(plan.get("proof_date")),
                "days_to_proof":days_to_proof,
                "before_after_status":status,
                "post_sample_size":int(evaluation.get("post_sample_size",0) or 0),
                "baseline_error_share":evaluation.get("baseline_error_share"),
                "post_error_share":evaluation.get("post_error_share"),
                "error_share_delta":evaluation.get("error_share_delta"),
                "comparison":_text(evaluation.get("comparison")),
                "issue":issue,
                "next_action":next_action,
                "go_to":"Decision Journal",
                "change_plan_id":plan_id,
                "implementation_id":_text(event.get("implementation_id")),
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            FORECAST_IMPLEMENTATION_QUEUE_COLS
        )

    out = pd.DataFrame(
        rows
    )

    order = {
        "FI0":0,
        "FI1":1,
        "FI2":2,
        "FI3":3,
        "FI4":4,
    }

    out["_p"] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    out = out.sort_values(
        [
            "_p",
            "days_to_proof",
            "company",
            "forecast_error_class",
        ],
        ascending=[
            True,
            True,
            True,
            True,
        ],
        na_position="last",
    ).drop(
        columns=[
            "_p"
        ]
    )

    return out[
        FORECAST_IMPLEMENTATION_QUEUE_COLS
    ].reset_index(
        drop=True
    )
