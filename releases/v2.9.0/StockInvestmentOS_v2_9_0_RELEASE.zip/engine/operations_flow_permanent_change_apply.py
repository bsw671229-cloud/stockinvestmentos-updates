from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_permanent_change_design import (
    permanent_change_design_snapshot_integrity,
    latest_permanent_change_design_snapshot,
)


FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS = [
    "permanent_change_apply_id",
    "created_at",
    "apply_state",
    "apply_guard",
    "apply_decision",
    "source_permanent_change_design_id",
    "source_permanent_change_design_hash",
    "source_permanent_change_design_created_at",
    "source_permanent_change_design_integrity",
    "source_live_change_closure_id",
    "source_live_change_closure_hash",
    "source_live_change_outcome_id",
    "source_live_change_outcome_hash",
    "source_runtime_event_id",
    "source_runtime_event_hash",
    "source_live_change_apply_id",
    "source_live_change_apply_hash",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "permanent_change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "target_scope_pct",
    "initial_stage_scope_pct",
    "rollout_stage_count",
    "proof_clock_days",
    "design_min_post_change_outcomes",
    "design_max_relative_error_degradation_pct",
    "design_rollback_observation_hours",
    "permit_stage_number",
    "permit_scope_pct",
    "permit_activation_window_hours",
    "permit_min_post_change_outcomes",
    "permit_max_relative_error_degradation_pct",
    "permit_rollback_observation_hours",
    "apply_detail",
    "design_source_reviewed",
    "design_integrity_verified",
    "baseline_revalidated_confirmed",
    "candidate_artifact_verified",
    "stage1_scope_confirmed",
    "staged_rollout_isolation_confirmed",
    "change_window_reviewed",
    "rollback_ready_confirmed",
    "monitoring_ready_confirmed",
    "manual_external_apply_only_confirmed",
    "no_auto_stage_escalation_confirmed",
    "no_auto_permanent_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "permanent_change_apply_permission",
    "permanent_change_design_authorization",
    "permanent_change_apply_authorization",
    "permanent_change_runtime_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PERMANENT_CHANGE_APPLY_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


PERMANENT_CHANGE_APPLY_STATES = {
    "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT",
    "PERMANENT_CHANGE_APPLY_NOT_REQUIRED",
    "PERMANENT_CHANGE_APPLY_DEFERRED",
    "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
    "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
    "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED",
    "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED",
    "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
    "PERMANENT_CHANGE_APPLY_REJECTED",
}


PERMANENT_CHANGE_APPLY_GUARD_BY_STATE = {
    "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT":
        "HOLD_PERMANENT_CHANGE_DESIGN",
    "PERMANENT_CHANGE_APPLY_NOT_REQUIRED":
        "NO_PERMANENT_CHANGE_APPLY",
    "PERMANENT_CHANGE_APPLY_DEFERRED":
        "HOLD_PERMANENT_CHANGE_APPLY",
    "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED":
        "HOLD_PERMANENT_CHANGE_DESIGN_SOURCE",
    "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW":
        "HOLD_PERMANENT_CHANGE_APPLY_INTEGRITY",
    "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED":
        "HUMAN_PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED",
    "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED":
        "HOLD_PERMANENT_CHANGE_APPLY_SOURCE",
    "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY":
        "MANUAL_PERMANENT_STAGE1_APPLY_PERMIT_NO_AUTO_APPLY",
    "PERMANENT_CHANGE_APPLY_REJECTED":
        "PERMANENT_CHANGE_APPLY_REJECTED_NO_APPLY",
}


PERMANENT_CHANGE_APPLY_DECISIONS = {
    "ISSUE_MANUAL_STAGE1_APPLY_PERMIT",
    "REJECT",
    "DEFER",
}


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass

    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )

    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _apply_payload(
    row: dict,
) -> dict:
    int_fields = {
        "rollout_stage_count",
        "proof_clock_days",
        "design_min_post_change_outcomes",
        "design_rollback_observation_hours",
        "permit_stage_number",
        "permit_activation_window_hours",
        "permit_min_post_change_outcomes",
        "permit_rollback_observation_hours",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "target_scope_pct",
        "initial_stage_scope_pct",
        "design_max_relative_error_degradation_pct",
        "permit_scope_pct",
        "permit_max_relative_error_degradation_pct",
    }

    bool_fields = {
        "design_source_reviewed",
        "design_integrity_verified",
        "baseline_revalidated_confirmed",
        "candidate_artifact_verified",
        "stage1_scope_confirmed",
        "staged_rollout_isolation_confirmed",
        "change_window_reviewed",
        "rollback_ready_confirmed",
        "monitoring_ready_confirmed",
        "manual_external_apply_only_confirmed",
        "no_auto_stage_escalation_confirmed",
        "no_auto_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS:
        if col in {
            "permanent_change_apply_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def permanent_change_apply_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(
            row,
            pd.Series,
        )
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _apply_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_permanent_change_apply_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values(
        "_ts"
    )

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _locked_design_source(
    permanent_change_design: dict | None,
) -> dict:
    design = permanent_change_design or {}

    if _text(
        design.get("design_state")
    ).upper() != "PERMANENT_CHANGE_DESIGN_LOCKED":
        return {}

    if _text(
        design.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_LOCKED_NO_APPLY":
        return {}

    latest = design.get(
        "latest_design"
    ) or {}

    if not latest:
        return {}

    if _text(
        permanent_change_design_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_LOCKED_NO_APPLY":
        return {}

    return latest


def _apply_matches_design(
    apply_snapshot: dict,
    design_source: dict,
) -> bool:
    if not apply_snapshot or not design_source:
        return False

    if _text(
        permanent_change_apply_snapshot_integrity(
            apply_snapshot
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            apply_snapshot.get(
                "source_permanent_change_design_id"
            )
        )
        == _text(
            design_source.get(
                "permanent_change_design_id"
            )
        )
        and _text(
            apply_snapshot.get(
                "source_permanent_change_design_hash"
            )
        )
        == _text(
            design_source.get(
                "snapshot_hash"
            )
        )
    )


def build_flow_permanent_change_apply(
    permanent_change_design: dict | None,
    design_snapshots: pd.DataFrame | None,
    apply_snapshots: pd.DataFrame | None,
) -> dict:
    design = permanent_change_design or {}

    design_state = _text(
        design.get("design_state")
    ).upper()

    base = {
        "apply_decision": "",
        "source_permanent_change_design_id": "",
        "source_permanent_change_design_hash": "",
        "source_permanent_change_design_created_at": "",
        "source_permanent_change_design_integrity": "NONE",
        "source_live_change_closure_id": _text(
            design.get(
                "source_live_change_closure_id"
            )
        ),
        "source_live_change_closure_hash": _text(
            design.get(
                "source_live_change_closure_hash"
            )
        ),
        "source_live_change_outcome_id": _text(
            design.get(
                "source_live_change_outcome_id"
            )
        ),
        "source_live_change_outcome_hash": _text(
            design.get(
                "source_live_change_outcome_hash"
            )
        ),
        "source_runtime_event_id": _text(
            design.get(
                "source_runtime_event_id"
            )
        ),
        "source_runtime_event_hash": _text(
            design.get(
                "source_runtime_event_hash"
            )
        ),
        "source_live_change_apply_id": _text(
            design.get(
                "source_live_change_apply_id"
            )
        ),
        "source_live_change_apply_hash": _text(
            design.get(
                "source_live_change_apply_hash"
            )
        ),
        "source_live_change_design_id": _text(
            design.get(
                "source_live_change_design_id"
            )
        ),
        "source_live_change_design_hash": _text(
            design.get(
                "source_live_change_design_hash"
            )
        ),
        "source_proposal_id": _text(
            design.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            design.get(
                "source_proposal_hash"
            )
        ),
        "proposal_scope": _text(
            design.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            design.get(
                "target_metric"
            )
        ).upper(),
        "permanent_change_mode": _text(
            design.get(
                "permanent_change_mode"
            )
        ).upper(),
        "artifact_ref": _text(
            design.get(
                "artifact_ref"
            )
        ),
        "baseline_value": _float(
            design.get(
                "baseline_value"
            )
        ),
        "candidate_value": _float(
            design.get(
                "candidate_value"
            )
        ),
        "rollback_target_value": _float(
            design.get(
                "rollback_target_value"
            )
        ),
        "target_scope_pct": _float(
            design.get(
                "target_scope_pct"
            )
        ),
        "initial_stage_scope_pct": _float(
            design.get(
                "initial_stage_scope_pct"
            )
        ),
        "rollout_stage_count": _int(
            design.get(
                "rollout_stage_count"
            )
        ),
        "proof_clock_days": _int(
            design.get(
                "proof_clock_days"
            )
        ),
        "design_min_post_change_outcomes": _int(
            design.get(
                "min_post_change_outcomes"
            )
        ),
        "design_max_relative_error_degradation_pct": _float(
            design.get(
                "max_relative_error_degradation_pct"
            )
        ),
        "design_rollback_observation_hours": _int(
            design.get(
                "rollback_observation_hours"
            )
        ),
        "permit_stage_number": 0,
        "permit_scope_pct": 0.0,
        "permit_activation_window_hours": 0,
        "permit_min_post_change_outcomes": 0,
        "permit_max_relative_error_degradation_pct": 0.0,
        "permit_rollback_observation_hours": 0,
        "apply_detail": "",
        "latest_apply": {},
        "permanent_change_apply_permission": "NONE",
        "permanent_change_design_authorization": "NONE",
        "permanent_change_apply_authorization": "NONE",
        "permanent_change_runtime_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if design_state == "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_NOT_REQUIRED",
            "apply_guard":
                "NO_PERMANENT_CHANGE_APPLY",
        }

    if design_state == "PERMANENT_CHANGE_DESIGN_DEFERRED":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_DEFERRED",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY",
        }

    if design_state != "PERMANENT_CHANGE_DESIGN_LOCKED":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN",
        }

    design_source = _locked_design_source(
        design
    )

    if not design_source:
        history = (
            pd.DataFrame()
            if design_snapshots is None
            else design_snapshots.copy()
        )

        latest = latest_permanent_change_design_snapshot(
            history
        )

        if not latest:
            return {
                **base,
                "apply_state":
                    "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
                "apply_guard":
                    "HOLD_PERMANENT_CHANGE_DESIGN_SOURCE",
            }

        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY_INTEGRITY",
        }

    source_integrity = _text(
        permanent_change_design_snapshot_integrity(
            design_source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_permanent_change_design_id":
                _text(
                    design_source.get(
                        "permanent_change_design_id"
                    )
                ),
            "source_permanent_change_design_hash":
                _text(
                    design_source.get(
                        "snapshot_hash"
                    )
                ),
            "source_permanent_change_design_created_at":
                _text(
                    design_source.get(
                        "created_at"
                    )
                ),
            "source_permanent_change_design_integrity":
                source_integrity,
            "source_live_change_closure_id":
                _text(
                    design_source.get(
                        "source_live_change_closure_id"
                    )
                ),
            "source_live_change_closure_hash":
                _text(
                    design_source.get(
                        "source_live_change_closure_hash"
                    )
                ),
            "source_live_change_outcome_id":
                _text(
                    design_source.get(
                        "source_live_change_outcome_id"
                    )
                ),
            "source_live_change_outcome_hash":
                _text(
                    design_source.get(
                        "source_live_change_outcome_hash"
                    )
                ),
            "source_runtime_event_id":
                _text(
                    design_source.get(
                        "source_runtime_event_id"
                    )
                ),
            "source_runtime_event_hash":
                _text(
                    design_source.get(
                        "source_runtime_event_hash"
                    )
                ),
            "source_live_change_apply_id":
                _text(
                    design_source.get(
                        "source_live_change_apply_id"
                    )
                ),
            "source_live_change_apply_hash":
                _text(
                    design_source.get(
                        "source_live_change_apply_hash"
                    )
                ),
            "source_live_change_design_id":
                _text(
                    design_source.get(
                        "source_live_change_design_id"
                    )
                ),
            "source_live_change_design_hash":
                _text(
                    design_source.get(
                        "source_live_change_design_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    design_source.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    design_source.get(
                        "source_proposal_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    design_source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    design_source.get(
                        "target_metric"
                    )
                ).upper(),
            "permanent_change_mode":
                _text(
                    design_source.get(
                        "permanent_change_mode"
                    )
                ).upper(),
            "artifact_ref":
                _text(
                    design_source.get(
                        "artifact_ref"
                    )
                ),
            "baseline_value":
                _float(
                    design_source.get(
                        "baseline_value"
                    )
                ),
            "candidate_value":
                _float(
                    design_source.get(
                        "candidate_value"
                    )
                ),
            "rollback_target_value":
                _float(
                    design_source.get(
                        "rollback_target_value"
                    )
                ),
            "target_scope_pct":
                _float(
                    design_source.get(
                        "target_scope_pct"
                    )
                ),
            "initial_stage_scope_pct":
                _float(
                    design_source.get(
                        "initial_stage_scope_pct"
                    )
                ),
            "rollout_stage_count":
                _int(
                    design_source.get(
                        "rollout_stage_count"
                    )
                ),
            "proof_clock_days":
                _int(
                    design_source.get(
                        "proof_clock_days"
                    )
                ),
            "design_min_post_change_outcomes":
                _int(
                    design_source.get(
                        "min_post_change_outcomes"
                    )
                ),
            "design_max_relative_error_degradation_pct":
                _float(
                    design_source.get(
                        "max_relative_error_degradation_pct"
                    )
                ),
            "design_rollback_observation_hours":
                _int(
                    design_source.get(
                        "rollback_observation_hours"
                    )
                ),
        }
    )

    if source_integrity != "OK":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY_INTEGRITY",
        }

    if _text(
        design_source.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_LOCKED_NO_APPLY":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY_INTEGRITY",
        }

    apply_history = (
        pd.DataFrame()
        if apply_snapshots is None
        else apply_snapshots.copy()
    )

    latest_apply = latest_permanent_change_apply_snapshot(
        apply_history
    )

    if not latest_apply:
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED",
            "apply_guard":
                "HUMAN_PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED",
        }

    base["latest_apply"] = latest_apply

    latest_integrity = _text(
        permanent_change_apply_snapshot_integrity(
            latest_apply
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY_INTEGRITY",
        }

    if not _apply_matches_design(
        latest_apply,
        design_source,
    ):
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY_SOURCE",
        }

    decision = _text(
        latest_apply.get(
            "apply_decision"
        )
    ).upper()

    base.update(
        {
            "apply_decision":
                decision,
            "permit_stage_number":
                _int(
                    latest_apply.get(
                        "permit_stage_number"
                    )
                ),
            "permit_scope_pct":
                _float(
                    latest_apply.get(
                        "permit_scope_pct"
                    )
                ),
            "permit_activation_window_hours":
                _int(
                    latest_apply.get(
                        "permit_activation_window_hours"
                    )
                ),
            "permit_min_post_change_outcomes":
                _int(
                    latest_apply.get(
                        "permit_min_post_change_outcomes"
                    )
                ),
            "permit_max_relative_error_degradation_pct":
                _float(
                    latest_apply.get(
                        "permit_max_relative_error_degradation_pct"
                    )
                ),
            "permit_rollback_observation_hours":
                _int(
                    latest_apply.get(
                        "permit_rollback_observation_hours"
                    )
                ),
            "apply_detail":
                _text(
                    latest_apply.get(
                        "apply_detail"
                    )
                ),
            "permanent_change_apply_permission":
                _text(
                    latest_apply.get(
                        "permanent_change_apply_permission"
                    )
                ).upper()
                or "NONE",
        }
    )

    if decision == "ISSUE_MANUAL_STAGE1_APPLY_PERMIT":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
            "apply_guard":
                "MANUAL_PERMANENT_STAGE1_APPLY_PERMIT_NO_AUTO_APPLY",
        }

    if decision == "REJECT":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_REJECTED",
            "apply_guard":
                "PERMANENT_CHANGE_APPLY_REJECTED_NO_APPLY",
        }

    if decision == "DEFER":
        return {
            **base,
            "apply_state":
                "PERMANENT_CHANGE_APPLY_DEFERRED",
            "apply_guard":
                "HOLD_PERMANENT_CHANGE_APPLY",
        }

    return {
        **base,
        "apply_state":
            "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
        "apply_guard":
            "HOLD_PERMANENT_CHANGE_APPLY_INTEGRITY",
    }


def build_flow_permanent_change_apply_lock(
    apply: dict,
    *,
    apply_decision: str,
    permit_scope_pct: float,
    permit_activation_window_hours: int,
    apply_detail: str,
    design_source_reviewed: bool,
    design_integrity_verified: bool,
    baseline_revalidated_confirmed: bool,
    candidate_artifact_verified: bool,
    stage1_scope_confirmed: bool,
    staged_rollout_isolation_confirmed: bool,
    change_window_reviewed: bool,
    rollback_ready_confirmed: bool,
    monitoring_ready_confirmed: bool,
    manual_external_apply_only_confirmed: bool,
    no_auto_stage_escalation_confirmed: bool,
    no_auto_permanent_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = apply or {}

    if _text(
        current.get("apply_state")
    ).upper() != "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED":
        raise ValueError(
            "Permanent Change Apply는 APPLY_REVIEW_REQUIRED 상태에서만 결정할 수 있습니다."
        )

    if _text(
        current.get(
            "source_permanent_change_design_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Permanent Change Design integrity가 OK가 아닙니다."
        )

    decision = _text(
        apply_decision
    ).upper()

    if decision not in PERMANENT_CHANGE_APPLY_DECISIONS:
        raise ValueError(
            "Permanent Change Apply decision vocabulary가 유효하지 않습니다."
        )

    detail = _text(
        apply_detail
    )

    if len(detail) < 60:
        raise ValueError(
            "Permanent Change Apply Review rationale을 60자 이상 기록하세요."
        )

    confirmations = {
        "design_source_reviewed":
            bool(
                design_source_reviewed
            ),
        "design_integrity_verified":
            bool(
                design_integrity_verified
            ),
        "baseline_revalidated_confirmed":
            bool(
                baseline_revalidated_confirmed
            ),
        "candidate_artifact_verified":
            bool(
                candidate_artifact_verified
            ),
        "stage1_scope_confirmed":
            bool(
                stage1_scope_confirmed
            ),
        "staged_rollout_isolation_confirmed":
            bool(
                staged_rollout_isolation_confirmed
            ),
        "change_window_reviewed":
            bool(
                change_window_reviewed
            ),
        "rollback_ready_confirmed":
            bool(
                rollback_ready_confirmed
            ),
        "monitoring_ready_confirmed":
            bool(
                monitoring_ready_confirmed
            ),
        "manual_external_apply_only_confirmed":
            bool(
                manual_external_apply_only_confirmed
            ),
        "no_auto_stage_escalation_confirmed":
            bool(
                no_auto_stage_escalation_confirmed
            ),
        "no_auto_permanent_apply_confirmed":
            bool(
                no_auto_permanent_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Permanent Change Apply Human Review 확인사항을 모두 검토해야 합니다."
        )

    design_stage_scope = _float(
        current.get(
            "initial_stage_scope_pct"
        )
    )

    target_scope = _float(
        current.get(
            "target_scope_pct"
        )
    )

    permit_scope = float(
        permit_scope_pct
    )

    activation_hours = int(
        permit_activation_window_hours
    )

    if decision == "ISSUE_MANUAL_STAGE1_APPLY_PERMIT":
        if not (
            0
            < permit_scope
            <= design_stage_scope
            <= 0.10
            and permit_scope
            <= target_scope
        ):
            raise ValueError(
                "Stage 1 Permit Scope은 0% 초과이며 locked Initial Stage Scope/Target Scope 이하이어야 합니다."
            )

        if not (
            1
            <= activation_hours
            <= 168
        ):
            raise ValueError(
                "Activation Window는 1~168시간이어야 합니다."
            )

    else:
        permit_scope = 0.0
        activation_hours = 0

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    source_ts = pd.to_datetime(
        current.get(
            "source_permanent_change_design_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    apply_ts = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            source_ts
        )
        or pd.isna(
            apply_ts
        )
        or apply_ts <= source_ts
    ):
        raise ValueError(
            "Permanent Change Apply Review는 source Design audit 이후에 저장되어야 합니다."
        )

    if decision == "ISSUE_MANUAL_STAGE1_APPLY_PERMIT":
        state = (
            "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
        )
        guard = (
            "MANUAL_PERMANENT_STAGE1_APPLY_PERMIT_NO_AUTO_APPLY"
        )
        permission = (
            "MANUAL_PERMANENT_STAGE1_APPLY_ONLY"
        )
        permit_stage = 1
        min_outcomes = max(
            5,
            _int(
                current.get(
                    "design_min_post_change_outcomes"
                )
            ),
        )
        max_degradation = max(
            0.0,
            _float(
                current.get(
                    "design_max_relative_error_degradation_pct"
                )
            ),
        )
        rollback_hours = max(
            24,
            _int(
                current.get(
                    "design_rollback_observation_hours"
                )
            ),
        )

    elif decision == "REJECT":
        state = (
            "PERMANENT_CHANGE_APPLY_REJECTED"
        )
        guard = (
            "PERMANENT_CHANGE_APPLY_REJECTED_NO_APPLY"
        )
        permission = "NONE"
        permit_stage = 0
        min_outcomes = 0
        max_degradation = 0.0
        rollback_hours = 0

    else:
        state = (
            "PERMANENT_CHANGE_APPLY_DEFERRED"
        )
        guard = (
            "HOLD_PERMANENT_CHANGE_APPLY"
        )
        permission = "NONE"
        permit_stage = 0
        min_outcomes = 0
        max_degradation = 0.0
        rollback_hours = 0

    base = {
        "apply_state":
            state,
        "apply_guard":
            guard,
        "apply_decision":
            decision,
        "source_permanent_change_design_id":
            _text(
                current.get(
                    "source_permanent_change_design_id"
                )
            ),
        "source_permanent_change_design_hash":
            _text(
                current.get(
                    "source_permanent_change_design_hash"
                )
            ),
        "source_permanent_change_design_created_at":
            _text(
                current.get(
                    "source_permanent_change_design_created_at"
                )
            ),
        "source_permanent_change_design_integrity":
            "OK",
        "source_live_change_closure_id":
            _text(
                current.get(
                    "source_live_change_closure_id"
                )
            ),
        "source_live_change_closure_hash":
            _text(
                current.get(
                    "source_live_change_closure_hash"
                )
            ),
        "source_live_change_outcome_id":
            _text(
                current.get(
                    "source_live_change_outcome_id"
                )
            ),
        "source_live_change_outcome_hash":
            _text(
                current.get(
                    "source_live_change_outcome_hash"
                )
            ),
        "source_runtime_event_id":
            _text(
                current.get(
                    "source_runtime_event_id"
                )
            ),
        "source_runtime_event_hash":
            _text(
                current.get(
                    "source_runtime_event_hash"
                )
            ),
        "source_live_change_apply_id":
            _text(
                current.get(
                    "source_live_change_apply_id"
                )
            ),
        "source_live_change_apply_hash":
            _text(
                current.get(
                    "source_live_change_apply_hash"
                )
            ),
        "source_live_change_design_id":
            _text(
                current.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                current.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "permanent_change_mode":
            _text(
                current.get(
                    "permanent_change_mode"
                )
            ),
        "artifact_ref":
            _text(
                current.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            _float(
                current.get(
                    "baseline_value"
                )
            ),
        "candidate_value":
            _float(
                current.get(
                    "candidate_value"
                )
            ),
        "rollback_target_value":
            _float(
                current.get(
                    "rollback_target_value"
                )
            ),
        "target_scope_pct":
            target_scope,
        "initial_stage_scope_pct":
            design_stage_scope,
        "rollout_stage_count":
            _int(
                current.get(
                    "rollout_stage_count"
                )
            ),
        "proof_clock_days":
            _int(
                current.get(
                    "proof_clock_days"
                )
            ),
        "design_min_post_change_outcomes":
            _int(
                current.get(
                    "design_min_post_change_outcomes"
                )
            ),
        "design_max_relative_error_degradation_pct":
            _float(
                current.get(
                    "design_max_relative_error_degradation_pct"
                )
            ),
        "design_rollback_observation_hours":
            _int(
                current.get(
                    "design_rollback_observation_hours"
                )
            ),
        "permit_stage_number":
            permit_stage,
        "permit_scope_pct":
            permit_scope,
        "permit_activation_window_hours":
            activation_hours,
        "permit_min_post_change_outcomes":
            min_outcomes,
        "permit_max_relative_error_degradation_pct":
            max_degradation,
        "permit_rollback_observation_hours":
            rollback_hours,
        "apply_detail":
            detail,
        **confirmations,
        "permanent_change_apply_permission":
            permission,
        "permanent_change_design_authorization":
            "NONE",
        "permanent_change_apply_authorization":
            "NONE",
        "permanent_change_runtime_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _apply_payload(
            base
        )
    )

    return {
        "permanent_change_apply_id": (
            "PCA-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[
                :8
            ]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_permanent_change_apply_queue(
    apply: dict | None,
) -> pd.DataFrame:
    row = apply or {}

    state = _text(
        row.get("apply_state")
    ).upper()

    mapping = {
        "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT": (
            "PA2",
            "WAIT",
            "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT",
            "LOCKED Permanent Change Design이 아직 없음",
            "Human Closure / Permanent Design evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "PERMANENT_CHANGE_APPLY_NOT_REQUIRED": (
            "PA3",
            "MONITOR",
            "PERMANENT_CHANGE_APPLY_NOT_REQUIRED",
            "현재 Permanent Design source에서는 Apply Review가 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "PERMANENT_CHANGE_APPLY_DEFERRED": (
            "PA2",
            "WAIT",
            "PERMANENT_CHANGE_APPLY_DEFERRED",
            "Human Permanent Change Apply Review가 DEFER 상태",
            "조건/evidence가 갱신될 때까지 대기",
        ),
        "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED": (
            "PA1",
            "REVIEW",
            "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
            "LOCKED Design 상태이나 immutable Design source가 없음",
            "Permanent Change Design snapshot을 먼저 확인",
        ),
        "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW": (
            "PA0",
            "BLOCKED",
            "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "Permanent Design 또는 Apply audit integrity mismatch",
            "immutable source lineage를 먼저 복구",
        ),
        "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED": (
            "PA1",
            "REVIEW",
            "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED",
            (
                f"stage1 cap {float(row.get('initial_stage_scope_pct',0)):.1%} · "
                f"target {float(row.get('target_scope_pct',0)):.1%}"
            ),
            "Human Apply Preflight 후 ISSUE_MANUAL_STAGE1_APPLY_PERMIT / REJECT / DEFER 결정",
        ),
        "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED": (
            "PA0",
            "REVIEW",
            "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED",
            "새 Permanent Design으로 기존 Apply decision이 stale",
            "현재 Design source 기준으로 Apply Review 재수행",
        ),
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY": (
            "PA3",
            "MONITOR",
            "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
            (
                f"manual stage {int(row.get('permit_stage_number',0))} · "
                f"scope {float(row.get('permit_scope_pct',0)):.1%} · "
                f"window {int(row.get('permit_activation_window_hours',0))}h"
            ),
            "실제 변경은 외부/수동 Permanent Runtime Gate에서만 수행; 자동 stage escalation 금지",
        ),
        "PERMANENT_CHANGE_APPLY_REJECTED": (
            "PA3",
            "MONITOR",
            "PERMANENT_CHANGE_APPLY_REJECTED",
            "Human Permanent Change Apply decision = REJECT",
            "실제 permanent apply 없음; locked baseline 유지",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "PA0",
            "BLOCKED",
            "PERMANENT_CHANGE_APPLY_UNKNOWN_STATE",
            state or "MISSING",
            "Permanent Change Apply state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            PERMANENT_CHANGE_APPLY_QUEUE_COLS,
    )
