from __future__ import annotations

from typing import Any
import pandas as pd


CONTROL_TOWER_COLS = [
    "priority",
    "domain",
    "status",
    "issue",
    "next_action",
    "go_to",
    "blocking",
]


SEQUENCE_COLS = [
    "step",
    "phase",
    "status",
    "detail",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _upper(value: Any) -> str:
    return _text(value).upper()


def _row(
    priority: str,
    domain: str,
    status: str,
    issue: str,
    next_action: str,
    go_to: str,
    *,
    blocking: bool,
) -> dict:
    return {
        "priority": priority,
        "domain": domain,
        "status": status,
        "issue": issue,
        "next_action": next_action,
        "go_to": go_to,
        "blocking": "YES" if blocking else "NO",
    }


def build_operations_control_tower(
    *,
    reconciliation_status: str,
    integration_status: str,
    csv_fail_count: int,
    data_quality_blocked: int,
    data_quality_review: int,
    review_overdue: int,
    review_attention_now: int,
    learning_release_gate: str,
    forecast_release_gate: str,
    recovery_release_gate: str,
    recovery_integration_status: str,
    schema_release_gate: str,
    schema_contract_drift_status: str,
    watchlist_count: int,
) -> dict:
    rows = []

    # -----------------------------
    # CT0: survival / integrity first
    # -----------------------------
    if _upper(reconciliation_status) != "PASS":
        rows.append(
            _row(
                "CT0",
                "Portfolio Reconciliation",
                "BLOCKED",
                f"Reconciliation {_upper(reconciliation_status) or 'MISSING'}",
                "총자산과 보유자산 합계/현금 연결을 먼저 맞춤",
                "Reconciliation",
                blocking=True,
            )
        )

    if _upper(integration_status) != "PASS":
        rows.append(
            _row(
                "CT0",
                "System Integration",
                "BLOCKED",
                f"Integration {_upper(integration_status) or 'MISSING'}",
                "공통가정/모듈 연결의 구조적 불일치를 먼저 확인",
                "System Integration",
                blocking=True,
            )
        )

    csv_fail = max(0, _int(csv_fail_count))
    if csv_fail > 0:
        rows.append(
            _row(
                "CT0",
                "Save / Data Integrity",
                "BLOCKED",
                f"CSV FAIL {csv_fail}",
                "읽기 실패 CSV를 먼저 복구하고 Save Health 재확인",
                "Save Center",
                blocking=True,
            )
        )

    dq_blocked = max(0, _int(data_quality_blocked))
    if dq_blocked > 0:
        rows.append(
            _row(
                "CT0",
                "Data Quality",
                "BLOCKED",
                f"Data Quality BLOCKED {dq_blocked}",
                "원본 데이터 누락/오류를 먼저 복구",
                "Data Quality",
                blocking=True,
            )
        )

    technical_gates = [
        (
            "Learning Cycle",
            _upper(learning_release_gate),
            "Learning Cycle Technical Release Gate",
            "Stability Audit",
        ),
        (
            "Forecast Calibration",
            _upper(forecast_release_gate),
            "Forecast Calibration Technical Release Gate",
            "Stability Audit",
        ),
        (
            "Recovery",
            _upper(recovery_release_gate),
            "Recovery Technical Release Gate",
            "Save Center",
        ),
        (
            "Schema Governance",
            _upper(schema_release_gate),
            "Schema Governance Technical Release Gate",
            "Stability Audit",
        ),
    ]

    for domain, gate, label, go_to in technical_gates:
        if gate != "PASS":
            rows.append(
                _row(
                    "CT0",
                    domain,
                    "BLOCKED",
                    f"{label} {gate or 'MISSING'}",
                    "기술 Gate의 FAIL/Integrity 문제를 운영 판단보다 먼저 해결",
                    go_to,
                    blocking=True,
                )
            )

    recovery_integration = _upper(
        recovery_integration_status
    )
    if recovery_integration != "PASS":
        rows.append(
            _row(
                "CT0",
                "Recovery Audit",
                "BLOCKED",
                f"Recovery Audit / Runbook {recovery_integration or 'MISSING'}",
                "현재 Backup Manifest 기준 Recovery Point / DR Runbook Closure를 확인",
                "Save Center",
                blocking=True,
            )
        )

    schema_drift = _upper(
        schema_contract_drift_status
    )
    if schema_drift != "CURRENT":
        rows.append(
            _row(
                "CT0",
                "Schema Contract",
                "BLOCKED",
                f"Reader-Writer Contract Drift {schema_drift or 'MISSING'}",
                "Schema drift / Baseline / Contract / Migration lineage를 확인",
                "Save Center",
                blocking=True,
            )
        )

    # -----------------------------
    # CT1: time-critical operating review
    # -----------------------------
    overdue = max(0, _int(review_overdue))
    if overdue > 0:
        rows.append(
            _row(
                "CT1",
                "Review Clock",
                "REVIEW",
                f"OVERDUE {overdue}",
                "가격 변동보다 먼저 기한 초과 Primary Source / Proof Clock을 검토",
                "Review Queue",
                blocking=False,
            )
        )

    attention = max(0, _int(review_attention_now))
    if attention > 0:
        rows.append(
            _row(
                "CT1",
                "Review Queue",
                "REVIEW",
                f"TODAY / NOW {attention}",
                "오늘 또는 즉시 검토할 운영 항목을 확인",
                "Review Queue",
                blocking=False,
            )
        )

    # -----------------------------
    # CT2: non-blocking data review
    # -----------------------------
    dq_review = max(0, _int(data_quality_review))
    if dq_review > 0:
        rows.append(
            _row(
                "CT2",
                "Data Quality",
                "REVIEW",
                f"Data Quality REVIEW {dq_review}",
                "REVIEW 데이터의 freshness/source/provenance를 확인",
                "Data Quality",
                blocking=False,
            )
        )

    if max(0, _int(watchlist_count)) == 0:
        rows.append(
            _row(
                "CT2",
                "Universe / Watchlist",
                "REVIEW",
                "Watchlist empty",
                "분석할 종목을 Watchlist에 등록",
                "Market Universe",
                blocking=False,
            )
        )

    # No active issue: provide routine safe sequence.
    if not rows:
        rows.append(
            _row(
                "CT3",
                "Daily Operations",
                "READY",
                "No blocking / overdue / immediate-review item",
                "Daily Briefing → Decision Summary → Monitoring Center 순으로 운영 점검",
                "Daily Briefing",
                blocking=False,
            )
        )

    order = {
        "CT0": 0,
        "CT1": 1,
        "CT2": 2,
        "CT3": 3,
    }

    table = pd.DataFrame(
        rows,
        columns=CONTROL_TOWER_COLS,
    )
    table["_p"] = table["priority"].map(order).fillna(9)
    table = (
        table.sort_values(
            ["_p", "domain", "issue"]
        )
        .drop(columns=["_p"])
        .reset_index(drop=True)
    )

    blocking_count = int(
        table["blocking"].eq("YES").sum()
    )
    review_count = int(
        table["status"].eq("REVIEW").sum()
    )

    if blocking_count > 0:
        system_state = "BLOCKED"
    elif review_count > 0:
        system_state = "REVIEW"
    else:
        system_state = "READY"

    first = table.iloc[0].to_dict() if not table.empty else {}

    return {
        "system_state": system_state,
        "blocking_count": blocking_count,
        "review_count": review_count,
        "top_priority": _text(first.get("priority")),
        "top_domain": _text(first.get("domain")),
        "top_issue": _text(first.get("issue")),
        "top_go_to": _text(first.get("go_to")),
        "priority_table": table,
        "execution_authorization": "NONE",
    }


def build_daily_operating_sequence(
    tower: dict | None,
) -> pd.DataFrame:
    result = tower or {}
    state = _upper(result.get("system_state"))

    if state == "BLOCKED":
        rows = [
            {
                "step": 1,
                "phase": "SURVIVAL / INTEGRITY",
                "status": "DO_FIRST",
                "detail": (
                    f"{_text(result.get('top_domain'))} · "
                    f"{_text(result.get('top_issue'))}"
                ),
                "go_to": _text(result.get("top_go_to")),
            },
            {
                "step": 2,
                "phase": "RECHECK",
                "status": "WAIT",
                "detail": "Blocking Gate를 해소한 뒤 Control Tower를 다시 계산",
                "go_to": "Operations Control Tower",
            },
            {
                "step": 3,
                "phase": "INVESTMENT WORK",
                "status": "HOLD",
                "detail": "Blocking technical/data issue 해소 전 신규 판단·실행 검토를 뒤로 미룸",
                "go_to": "Stability Audit",
            },
        ]
    elif state == "REVIEW":
        rows = [
            {
                "step": 1,
                "phase": "CLOCK / EVIDENCE",
                "status": "DO_FIRST",
                "detail": (
                    f"{_text(result.get('top_domain'))} · "
                    f"{_text(result.get('top_issue'))}"
                ),
                "go_to": _text(result.get("top_go_to")),
            },
            {
                "step": 2,
                "phase": "DECISION STATE",
                "status": "NEXT",
                "detail": "Decision Summary에서 현재 Lifecycle / Add Freeze / Portfolio Fit 확인",
                "go_to": "Decision Summary",
            },
            {
                "step": 3,
                "phase": "MONITOR",
                "status": "NEXT",
                "detail": "Monitoring Center에서 남은 운영 Review를 확인",
                "go_to": "Monitoring Center",
            },
        ]
    else:
        rows = [
            {
                "step": 1,
                "phase": "DAILY BRIEF",
                "status": "READY",
                "detail": "Daily Briefing에서 오늘 변한 Evidence / Risk / Clock 확인",
                "go_to": "Daily Briefing",
            },
            {
                "step": 2,
                "phase": "DECISION STATE",
                "status": "READY",
                "detail": "Decision Summary에서 종목별 현재 상태 확인",
                "go_to": "Decision Summary",
            },
            {
                "step": 3,
                "phase": "MONITOR",
                "status": "READY",
                "detail": "Monitoring Center / Review Queue에서 새 Review 발생 여부 확인",
                "go_to": "Monitoring Center",
            },
        ]

    return pd.DataFrame(
        rows,
        columns=SEQUENCE_COLS,
    )


def top_actions(
    tower: dict | None,
    limit: int = 3,
) -> pd.DataFrame:
    result = tower or {}
    table = result.get("priority_table")

    if not isinstance(table, pd.DataFrame) or table.empty:
        return pd.DataFrame(columns=CONTROL_TOWER_COLS)

    n = max(1, _int(limit))
    return table.head(n).reset_index(drop=True)
