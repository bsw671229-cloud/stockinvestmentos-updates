from __future__ import annotations

from typing import Any
import json
import pandas as pd

from engine.operations_flow_shadow_validation_outcome import (
    FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    SHADOW_VALIDATION_OUTCOME_STATES,
    VALIDATION_GUARD_BY_STATE,
    build_flow_shadow_validation_outcome,
    shadow_validation_outcome_snapshot_integrity,
    latest_shadow_validation_outcome_snapshot,
)
from engine.operations_flow_shadow_validation_plan import (
    FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
    shadow_validation_plan_snapshot_integrity,
)
from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    recalibration_proposal_snapshot_integrity,
)
from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    flow_projection_scorecard_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)


SHADOW_EVAL_RELEASE_CHECK_COLS = [
    "layer", "check", "status", "detail", "action"
]
SHADOW_EVAL_AUDIT_CHECK_COLS = [
    "layer", "check", "status", "detail", "action"
]
V139_CANDIDATE_CHECK_COLS = [
    "check", "status", "detail", "blocking"
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {"total": 0, "ok": 0, "missing": 0, "mismatch": 0}
    total = ok = missing = mismatch = 0
    for _, row in df.iterrows():
        total += 1
        status = _text(integrity_fn(row.to_dict()).get("status")).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1
    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0
    index = {}
    duplicate = 0
    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))
        if not item_id:
            continue
        if item_id in index:
            duplicate += 1
        index[item_id] = item
    return index, duplicate


def build_v139_shadow_evaluation_context(
    *,
    v138_context: dict | None,
    scorecard_snapshots: pd.DataFrame | None,
    qualified_outcomes: pd.DataFrame | None,
    shadow_validation_outcome_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v138_context or {}
    plan = upstream.get("plan") or {}
    proposal = upstream.get("proposal") or {}

    scorecard_df = _ensure_cols(
        scorecard_snapshots,
        FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    )
    qualified_df = _ensure_cols(
        qualified_outcomes,
        FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    )
    audit_df = _ensure_cols(
        shadow_validation_outcome_snapshots,
        FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    )

    evaluation = build_flow_shadow_validation_outcome(
        plan,
        proposal,
        scorecard_df,
        qualified_df,
    )

    latest_audit = latest_shadow_validation_outcome_snapshot(
        audit_df
    )
    latest_integrity = (
        _text(
            shadow_validation_outcome_snapshot_integrity(
                latest_audit
            ).get("status")
        ).upper()
        if latest_audit
        else "NONE"
    )

    return {
        "v138_context": upstream,
        "plan": plan,
        "proposal": proposal,
        "shadow_validation_plan_snapshots": _ensure_cols(
            upstream.get("shadow_validation_plan_snapshots"),
            FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
        ),
        "recalibration_proposal_snapshots": _ensure_cols(
            upstream.get("recalibration_proposal_snapshots"),
            FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
        ),
        "scorecard_snapshots": scorecard_df,
        "qualified_outcomes": qualified_df,
        "shadow_validation_outcome_snapshots": audit_df,
        "evaluation": evaluation,
        "evaluation_integrity": _integrity_counts(
            audit_df,
            shadow_validation_outcome_snapshot_integrity,
        ),
        "latest_evaluation_audit": latest_audit,
        "latest_evaluation_audit_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _current_locked_plan(plan: dict) -> dict:
    if _text(plan.get("plan_state")).upper() != "SHADOW_VALIDATION_PLAN_LOCKED":
        return {}
    row = plan.get("latest_plan") or {}
    if (
        row
        and _text(
            shadow_validation_plan_snapshot_integrity(row).get("status")
        ).upper() == "OK"
    ):
        return row
    return {}


def _current_locked_proposal(proposal: dict) -> dict:
    if _text(
        proposal.get("proposal_state")
    ).upper() != "RECALIBRATION_PROPOSAL_LOCKED":
        return {}
    row = proposal.get("latest_proposal") or {}
    if (
        row
        and _text(
            recalibration_proposal_snapshot_integrity(row).get("status")
        ).upper() == "OK"
    ):
        return row
    return {}


def _source_mapping_ok(ctx: dict) -> bool:
    ev = ctx.get("evaluation") or {}
    state = _text(ev.get("validation_state")).upper()

    no_source_states = {
        "SHADOW_EVAL_UPSTREAM_WAIT",
        "SHADOW_EVAL_NOT_REQUIRED",
    }
    if state in no_source_states:
        return True

    plan = _current_locked_plan(
        ctx.get("plan") or {}
    )
    proposal = _current_locked_proposal(
        ctx.get("proposal") or {}
    )

    if not plan:
        return state == "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW"

    if not proposal:
        return state == "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW"

    plan_ok = (
        _text(ev.get("source_plan_id"))
        == _text(plan.get("shadow_validation_plan_id"))
        and _text(ev.get("source_plan_hash"))
        == _text(plan.get("snapshot_hash"))
    )

    proposal_ok = (
        _text(ev.get("source_proposal_id"))
        == _text(proposal.get("recalibration_proposal_id"))
        and _text(ev.get("source_proposal_hash"))
        == _text(proposal.get("snapshot_hash"))
    )

    return plan_ok and proposal_ok


def _scorecard_mapping_ok(ctx: dict) -> bool:
    ev = ctx.get("evaluation") or {}
    state = _text(ev.get("validation_state")).upper()

    if state in {
        "SHADOW_EVAL_UPSTREAM_WAIT",
        "SHADOW_EVAL_NOT_REQUIRED",
        "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
        "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
    }:
        return True

    source_id = _text(ev.get("source_scorecard_snapshot_id"))
    source_hash = _text(ev.get("source_scorecard_hash"))

    if not source_id or not source_hash:
        return state == "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW"

    index, duplicate = _index_by_id(
        ctx.get("scorecard_snapshots"),
        "scorecard_snapshot_id",
    )
    if duplicate > 0:
        return False

    parent = index.get(source_id)
    if not parent:
        return state == "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW"

    return (
        _text(
            flow_projection_scorecard_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(parent.get("snapshot_hash")) == source_hash
    )


def _prospective_evidence_ok(ctx: dict) -> bool:
    ev = ctx.get("evaluation") or {}
    state = _text(ev.get("validation_state")).upper()

    if state in {
        "SHADOW_EVAL_UPSTREAM_WAIT",
        "SHADOW_EVAL_NOT_REQUIRED",
        "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
        "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
        "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW",
        "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED",
    }:
        return True

    # Pre-plan records may exist, but they must be excluded rather than
    # admitted to eligible evidence.
    eligible = _int(ev.get("eligible_outcomes"))
    required = _int(ev.get("required_future_outcomes"))
    future_seen = _int(ev.get("future_outcomes_seen"))
    preplan = _int(ev.get("preplan_outcomes"))
    preplan_projection = _int(ev.get("preplan_projection_outcomes"))

    return (
        eligible >= 0
        and required >= 3
        and future_seen >= eligible
        and preplan >= 0
        and preplan_projection >= 0
    )


def _evaluation_state_invariant(ctx: dict) -> bool:
    ev = ctx.get("evaluation") or {}
    state = _text(ev.get("validation_state")).upper()
    guard = _text(ev.get("validation_guard")).upper()

    if state not in SHADOW_VALIDATION_OUTCOME_STATES:
        return False

    if guard != VALIDATION_GUARD_BY_STATE.get(state, ""):
        return False

    eligible = _int(ev.get("eligible_outcomes"))
    required = max(3, _int(ev.get("required_future_outcomes")))
    invalid = _int(ev.get("invalid_outcomes"))
    assumption_drift = _int(ev.get("assumption_drift_outcomes"))
    baseline_drift = _int(ev.get("baseline_drift_outcomes"))

    if state == "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW":
        return invalid > 0

    if state == "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW":
        return invalid == 0 and assumption_drift > 0

    if state == "SHADOW_EVAL_BASELINE_DRIFT_REVIEW":
        return (
            invalid == 0
            and assumption_drift == 0
            and baseline_drift > 0
        )

    if state == "SHADOW_EVAL_EVIDENCE_MATURING":
        return (
            invalid == 0
            and assumption_drift == 0
            and baseline_drift == 0
            and 0 <= eligible < required
        )

    if state in {
        "SHADOW_EVAL_PASS",
        "SHADOW_EVAL_FAIL",
        "SHADOW_EVAL_INCONCLUSIVE",
    }:
        return (
            invalid == 0
            and assumption_drift == 0
            and baseline_drift == 0
            and eligible >= required
        )

    return True


def _authorization_violations(ctx: dict) -> int:
    violations = 0

    for item in [
        ctx.get("evaluation") or {},
        ctx.get("latest_evaluation_audit") or {},
        ctx.get("plan") or {},
        ctx.get("proposal") or {},
    ]:
        for field in [
            "validation_authorization",
            "plan_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(item.get(field)).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = ctx.get("shadow_validation_outcome_snapshots")
    if isinstance(history, pd.DataFrame) and not history.empty:
        for field in [
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue
            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(ctx.get("execution_authorization")).upper() != "NONE":
        violations += 1

    return violations


def build_v139_shadow_evaluation_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    ev = ctx.get("evaluation") or {}
    counts = ctx.get("evaluation_integrity") or {}
    state = _text(ev.get("validation_state")).upper()
    guard = _text(ev.get("validation_guard")).upper()

    checks = []

    checks.append(
        _technical_row(
            "Shadow Evaluation Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Shadow Evaluation audit immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Evaluation State / Guard Vocabulary",
            (
                state in SHADOW_VALIDATION_OUTCOME_STATES
                and guard == VALIDATION_GUARD_BY_STATE.get(state, "")
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {VALIDATION_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Shadow Evaluation state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Validation Plan / Proposal Source Mapping",
            _source_mapping_ok(ctx),
            (
                f"state {state or 'MISSING'} · "
                f"plan {_text(ev.get('source_plan_id')) or 'NONE'} · "
                f"proposal {_text(ev.get('source_proposal_id')) or 'NONE'}"
            ),
            "Evaluation source Plan/Proposal id/hash lineage 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Evaluation Scorecard Source Mapping",
            _scorecard_mapping_ok(ctx),
            (
                f"state {state or 'MISSING'} · "
                f"scorecard {_text(ev.get('source_scorecard_snapshot_id')) or 'NONE'} · "
                f"integrity {_text(ev.get('source_scorecard_integrity')) or 'NONE'}"
            ),
            "Evaluation source Scorecard id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Prospective OOS Evidence / Time-order Invariant",
            _prospective_evidence_ok(ctx),
            (
                f"eligible {_int(ev.get('eligible_outcomes'))} · "
                f"future {_int(ev.get('future_outcomes_seen'))} · "
                f"preplan outcome {_int(ev.get('preplan_outcomes'))} · "
                f"preplan projection {_int(ev.get('preplan_projection_outcomes'))}"
            ),
            "Plan 이후 생성된 Projection/Outcome만 eligible evidence로 인정",
        )
    )

    checks.append(
        _technical_row(
            "OOS Evidence State / Drift Invariant",
            _evaluation_state_invariant(ctx),
            (
                f"state {state or 'MISSING'} · "
                f"eligible {_int(ev.get('eligible_outcomes'))}/"
                f"{_int(ev.get('required_future_outcomes'))} · "
                f"invalid {_int(ev.get('invalid_outcomes'))} · "
                f"assumption drift {_int(ev.get('assumption_drift_outcomes'))} · "
                f"baseline drift {_int(ev.get('baseline_drift_outcomes'))}"
            ),
            "eligible count / drift / state mapping 확인",
        )
    )

    duplicate = _int(ev.get("duplicate_outcomes"))
    eligible = _int(ev.get("eligible_outcomes"))
    evidence_table = ev.get("evidence_table")
    unique_ok = True

    if isinstance(evidence_table, pd.DataFrame) and not evidence_table.empty:
        key_cols = [
            "source_projection_snapshot_id",
            "evidence_end_trend_snapshot_id",
        ]
        if all(col in evidence_table.columns for col in key_cols):
            unique_ok = not bool(
                evidence_table.duplicated(
                    subset=key_cols,
                    keep=False,
                ).any()
            )

    checks.append(
        _technical_row(
            "Shadow Evaluation Duplicate Resistance Invariant",
            (
                duplicate >= 0
                and eligible >= 0
                and unique_ok
            ),
            (
                f"eligible {eligible} · "
                f"duplicate collapsed {duplicate}"
            ),
            "Projection + ending Trend endpoint 중복이 eligible evidence를 부풀리지 않는지 확인",
        )
    )

    auth_violations = _authorization_violations(ctx)

    checks.append(
        _technical_row(
            "Shadow Evaluation No-Promotion Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            "Validation/Proposal/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1 for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state in {
            "SHADOW_EVAL_NOT_REQUIRED",
            "SHADOW_EVAL_PASS",
            "SHADOW_EVAL_FAIL",
            "SHADOW_EVAL_INCONCLUSIVE",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Shadow Evaluation Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"eligible {_int(ev.get('eligible_outcomes'))}/"
                f"{_int(ev.get('required_future_outcomes'))} · "
                f"improvement {_float(ev.get('relative_error_improvement_pct')):.1%}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 plan/evidence/drift wait는 Technical FAIL로 승격하지 않고 "
                    "사전등록된 prospective evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS" if technical_fail == 0 else "BLOCKED"
        ),
        "technical_pass": sum(
            1 for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "validation_state": state,
        "validation_guard": guard,
        "eligible_outcomes": _int(ev.get("eligible_outcomes")),
        "required_outcomes": _int(ev.get("required_future_outcomes")),
        "latest_shadow_validation_outcome_integrity":
            _text(ctx.get("latest_evaluation_audit_integrity")).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=SHADOW_EVAL_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _parse_json_list(value: Any) -> list[str]:
    raw = _text(value)
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
    except Exception:
        return []
    if not isinstance(parsed, list):
        return []
    return [
        _text(x)
        for x in parsed
        if _text(x)
    ]


def build_v139_shadow_evaluation_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    audit_df = _ensure_cols(
        ctx.get("shadow_validation_outcome_snapshots"),
        FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    )
    plan_df = _ensure_cols(
        ctx.get("shadow_validation_plan_snapshots"),
        FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
    )
    proposal_df = _ensure_cols(
        ctx.get("recalibration_proposal_snapshots"),
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )
    scorecard_df = _ensure_cols(
        ctx.get("scorecard_snapshots"),
        FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    )
    outcome_df = _ensure_cols(
        ctx.get("qualified_outcomes"),
        FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        audit_df,
        shadow_validation_outcome_snapshot_integrity,
    )

    plan_index, plan_dupes = _index_by_id(
        plan_df,
        "shadow_validation_plan_id",
    )
    proposal_index, proposal_dupes = _index_by_id(
        proposal_df,
        "recalibration_proposal_id",
    )
    scorecard_index, scorecard_dupes = _index_by_id(
        scorecard_df,
        "scorecard_snapshot_id",
    )
    outcome_index, outcome_dupes = _index_by_id(
        outcome_df,
        "outcome_snapshot_id",
    )

    state_violations = 0
    lineage_violations = 0
    outcome_lineage_violations = 0
    identity_duplicates = 0
    auth_violations = 0
    seen_ids = set()

    for _, row in audit_df.iterrows():
        item = row.to_dict()

        audit_id = _text(
            item.get("shadow_validation_outcome_id")
        )
        if audit_id:
            if audit_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(audit_id)

        state = _text(
            item.get("validation_state")
        ).upper()
        guard = _text(
            item.get("validation_guard")
        ).upper()

        if (
            state not in SHADOW_VALIDATION_OUTCOME_STATES
            or guard != VALIDATION_GUARD_BY_STATE.get(state, "")
        ):
            state_violations += 1

        for id_field, hash_field, index, integrity_fn in [
            (
                "source_plan_id",
                "source_plan_hash",
                plan_index,
                shadow_validation_plan_snapshot_integrity,
            ),
            (
                "source_proposal_id",
                "source_proposal_hash",
                proposal_index,
                recalibration_proposal_snapshot_integrity,
            ),
            (
                "source_scorecard_snapshot_id",
                "source_scorecard_hash",
                scorecard_index,
                flow_projection_scorecard_snapshot_integrity,
            ),
        ]:
            parent_id = _text(item.get(id_field))
            parent_hash = _text(item.get(hash_field))

            # Upstream / not-required audit states may legitimately have no
            # parent lineage yet.
            if not parent_id and not parent_hash:
                if state in {
                    "SHADOW_EVAL_UPSTREAM_WAIT",
                    "SHADOW_EVAL_NOT_REQUIRED",
                }:
                    continue
                lineage_violations += 1
                continue

            parent = index.get(parent_id)

            if (
                not parent
                or _text(
                    integrity_fn(parent).get("status")
                ).upper() != "OK"
                or _text(parent.get("snapshot_hash"))
                != parent_hash
            ):
                lineage_violations += 1

        ids = _parse_json_list(
            item.get("evidence_outcome_ids_json")
        )
        hashes = _parse_json_list(
            item.get("evidence_outcome_hashes_json")
        )

        if len(ids) != len(hashes):
            outcome_lineage_violations += 1
        else:
            for outcome_id, outcome_hash in zip(ids, hashes):
                parent = outcome_index.get(outcome_id)
                if (
                    not parent
                    or _text(
                        flow_projection_outcome_snapshot_integrity(
                            parent
                        ).get("status")
                    ).upper() != "OK"
                    or _text(parent.get("snapshot_hash"))
                    != outcome_hash
                ):
                    outcome_lineage_violations += 1

        for field in [
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(item.get(field)).upper() not in {"", "NONE"}:
                auth_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Shadow Evaluation Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Shadow Evaluation audit immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Evaluation Audit State / Guard / Authorization",
            (
                state_violations == 0
                and auth_violations == 0
            ),
            (
                f"state/guard violations {state_violations} · "
                f"authorization violations {auth_violations}"
            ),
            "Audit state/guard와 Authorization NONE 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Evaluation Audit → Plan / Proposal / Scorecard Lineage",
            (
                lineage_violations == 0
                and plan_dupes == 0
                and proposal_dupes == 0
                and scorecard_dupes == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"plan dup {plan_dupes} · "
                f"proposal dup {proposal_dupes} · "
                f"scorecard dup {scorecard_dupes}"
            ),
            "Audit source Plan/Proposal/Scorecard id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Evaluation Audit → Outcome Evidence Lineage",
            (
                outcome_lineage_violations == 0
                and outcome_dupes == 0
            ),
            (
                f"violations {outcome_lineage_violations} · "
                f"outcome duplicate ids {outcome_dupes}"
            ),
            "Audit evidence Outcome id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Evaluation Audit Identity Invariant",
            identity_duplicates == 0,
            f"duplicate audit ids {identity_duplicates}",
            "shadow_validation_outcome_id uniqueness 확인",
        )
    )

    technical_fail = sum(
        1 for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("evaluation") or {}).get(
            "validation_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state in {
            "SHADOW_EVAL_NOT_REQUIRED",
            "SHADOW_EVAL_PASS",
            "SHADOW_EVAL_FAIL",
            "SHADOW_EVAL_INCONCLUSIVE",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Shadow Evaluation Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current evaluation {current_state or 'MISSING'} · "
                f"saved audits {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 prospective OOS evidence가 성숙할 때 evaluation audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS" if technical_fail == 0 else "BLOCKED"
        ),
        "technical_pass": sum(
            1 for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=SHADOW_EVAL_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v139_release_readiness(
    *,
    v138_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    shadow_evaluation_release_gate: str,
    shadow_evaluation_audit_gate: str,
    shadow_evaluation_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.38 Shadow Validation Preregistration Release Baseline",
            _text(v138_release_status).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(v138_release_status).upper() or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(integration_consistency).upper() == "PASS",
            _text(integration_consistency).upper() or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Shadow Validation Outcome Technical Release Gate",
            _text(shadow_evaluation_release_gate).upper() == "PASS",
            _text(shadow_evaluation_release_gate).upper() or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Outcome Audit Integrity Gate",
            _text(shadow_evaluation_audit_gate).upper() == "PASS",
            _text(shadow_evaluation_audit_gate).upper() or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(execution_authorization).upper() == "NONE",
            _text(execution_authorization).upper() or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(shadow_evaluation_operating_status).upper() != "PASS"
        or _text(audit_operating_status).upper() != "PASS"
    ):
        operating_reviews.append(
            "SHADOW_EVALUATION_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(operating_reviews),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V139_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v139_integration_crosscheck(
    *,
    integration_consistency: str,
    shadow_evaluation_release_gate: str,
    shadow_evaluation_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(integration_consistency).upper() == "PASS",
            _text(integration_consistency).upper() or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Outcome Technical Gate",
            _text(shadow_evaluation_release_gate).upper() == "PASS",
            _text(shadow_evaluation_release_gate).upper() or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Outcome Audit Gate",
            _text(shadow_evaluation_audit_gate).upper() == "PASS",
            _text(shadow_evaluation_audit_gate).upper() or "MISSING",
        ),
    ]
    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]
    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V139_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v139_data_crosscheck(
    *,
    csv_fail_count: int,
    shadow_evaluation_release_gate: str,
    shadow_evaluation_audit_gate: str,
    latest_shadow_evaluation_integrity: str,
) -> dict:
    latest = _text(
        latest_shadow_evaluation_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Shadow Validation Outcome Technical Gate",
            _text(shadow_evaluation_release_gate).upper() == "PASS",
            _text(shadow_evaluation_release_gate).upper() or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Outcome Audit Gate",
            _text(shadow_evaluation_audit_gate).upper() == "PASS",
            _text(shadow_evaluation_audit_gate).upper() or "MISSING",
        ),
        _candidate_row(
            "Latest Shadow Validation Outcome Audit Integrity",
            latest in {"OK", "NONE"},
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V139_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
