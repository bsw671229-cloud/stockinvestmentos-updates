from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_calibration import (
    FLOW_CALIBRATION_SNAPSHOT_COLS,
    flow_calibration_snapshot_integrity,
    latest_flow_calibration_snapshot,
)
from engine.operations_flow_calibration_promotion import (
    FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS,
    flow_calibration_promotion_snapshot_integrity,
    latest_flow_calibration_promotion_snapshot,
)
from engine.operations_flow_projection import build_flow_projection
from engine.operations_flow_projection_admission import (
    FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS,
    flow_projection_admission_snapshot_integrity,
    latest_flow_projection_admission_snapshot,
    build_flow_projection_admission,
)


ADMISSION_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

ADMISSION_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V132_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


KNOWN_ADMISSION_STATES = {
    "ADMISSION_UPSTREAM_HOLD",
    "ADMISSION_CALIBRATION_SOURCE_REQUIRED",
    "ADMISSION_CALIBRATION_SOURCE_INTEGRITY_REVIEW",
    "ADMISSION_CALIBRATION_SOURCE_DRIFT_REVIEW",
    "ADMISSION_PROMOTION_SOURCE_REQUIRED",
    "ADMISSION_PROMOTION_SOURCE_INTEGRITY_REVIEW",
    "ADMISSION_PROMOTION_SOURCE_DRIFT_REVIEW",
    "ADMISSION_PROMOTION_AFTER_CALIBRATION_REQUIRED",
    "ADMISSION_SOURCE_TIME_INTEGRITY_REVIEW",
    "ADMISSION_READY_FOR_REVIEW",
}

KNOWN_EFFECTIVE_GUARDS = {
    "HOLD_INTEGRITY",
    "HOLD_HISTORY",
    "HOLD_CLOSED_SESSION",
    "HOLD_NO_CLEARING",
    "HOLD_MIXED",
    "HOLD_PROMOTION_PROOF",
    "HOLD_PROMOTION_STABILITY",
    "HOLD_ADMISSION_SOURCE",
    "ALLOW_PROJECTION_REVIEW",
}

READY_SOURCE_ORDER = {
    "PROMOTION_AFTER_CALIBRATION",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    source = pd.DataFrame() if df is None else df.copy()

    if source.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in source.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _fail_count(
    counts: dict | None,
) -> int:
    c = counts or {}
    return (
        _int(c.get("missing"))
        + _int(c.get("mismatch"))
    )


def _index_by_id(
    df: pd.DataFrame,
    *,
    id_col: str,
) -> tuple[dict, int]:
    if df.empty or id_col not in df.columns:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v132_admission_context(
    *,
    flow_context: dict | None,
    calibration_snapshots: pd.DataFrame | None,
    promotion_snapshots: pd.DataFrame | None,
    admission_snapshots: pd.DataFrame | None,
) -> dict:
    flow_ctx = flow_context or {}
    calibration = flow_ctx.get("calibration") or {}
    promotion = flow_ctx.get("calibration_promotion") or {}

    calibration_df = _ensure_cols(
        calibration_snapshots,
        FLOW_CALIBRATION_SNAPSHOT_COLS,
    )
    promotion_df = _ensure_cols(
        promotion_snapshots,
        FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS,
    )
    admission_df = _ensure_cols(
        admission_snapshots,
        FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS,
    )

    latest_calibration = latest_flow_calibration_snapshot(
        calibration_df
    )
    latest_promotion = latest_flow_calibration_promotion_snapshot(
        promotion_df
    )
    latest_admission = latest_flow_projection_admission_snapshot(
        admission_df
    )

    admission = build_flow_projection_admission(
        calibration,
        promotion,
        latest_calibration,
        latest_promotion,
    )

    projection = build_flow_projection(
        calibration,
        latest_calibration,
        admission=admission,
    )

    latest_admission_integrity = (
        _text(
            flow_projection_admission_snapshot_integrity(
                latest_admission
            ).get("status")
        ).upper()
        if latest_admission
        else "NONE"
    )

    return {
        "flow_context": flow_ctx,
        "calibration": calibration,
        "promotion": promotion,
        "admission": admission,
        "projection": projection,
        "calibration_snapshots": calibration_df,
        "promotion_snapshots": promotion_df,
        "admission_snapshots": admission_df,
        "latest_calibration": latest_calibration,
        "latest_promotion": latest_promotion,
        "latest_admission": latest_admission,
        "admission_integrity": _integrity_counts(
            admission_df,
            flow_projection_admission_snapshot_integrity,
        ),
        "latest_admission_integrity": latest_admission_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v132_admission_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    admission = ctx.get("admission") or {}
    projection = ctx.get("projection") or {}
    calibration = ctx.get("calibration") or {}
    promotion = ctx.get("promotion") or {}

    counts = ctx.get("admission_integrity") or {}
    checks = []

    integrity_fail = _fail_count(counts)
    checks.append(
        _technical_row(
            "Projection Admission Snapshot Integrity",
            integrity_fail == 0,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            (
                "operations_flow_projection_admission_snapshots.csv "
                "immutable hash 확인"
            ),
        )
    )

    state = _text(
        admission.get("admission_state")
    ).upper()
    guard = _text(
        admission.get("effective_projection_guard")
    ).upper()
    cal_guard = _text(
        calibration.get("projection_guard")
    ).upper()
    promotion_state = _text(
        promotion.get("promotion_state")
    ).upper()

    vocabulary_ok = (
        state in KNOWN_ADMISSION_STATES
        and guard in KNOWN_EFFECTIVE_GUARDS
    )
    checks.append(
        _technical_row(
            "Admission State / Guard Vocabulary",
            vocabulary_ok,
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'}"
            ),
            "Admission state / effective guard vocabulary 확인",
        )
    )

    if state == "ADMISSION_UPSTREAM_HOLD":
        non_relaxation_ok = (
            guard == cal_guard
            and guard != "ALLOW_PROJECTION_REVIEW"
        )
    elif state == "ADMISSION_READY_FOR_REVIEW":
        non_relaxation_ok = (
            guard == "ALLOW_PROJECTION_REVIEW"
            and cal_guard == "ALLOW_PROJECTION_REVIEW"
            and promotion_state == "PROMOTION_READY"
        )
    else:
        non_relaxation_ok = (
            guard == "HOLD_ADMISSION_SOURCE"
        )

    checks.append(
        _technical_row(
            "Admission Non-Relaxation Invariant",
            non_relaxation_ok,
            (
                f"state {state or 'MISSING'} · "
                f"calibration guard {cal_guard or 'MISSING'} · "
                f"admission guard {guard or 'MISSING'} · "
                f"promotion {promotion_state or 'MISSING'}"
            ),
            (
                "Admission이 upstream HOLD를 ALLOW로 완화하거나 "
                "source review 상태에서 HOLD_ADMISSION_SOURCE를 우회하지 않는지 확인"
            ),
        )
    )

    cal_fresh = _text(
        admission.get("calibration_source_freshness")
    ).upper()
    cal_integrity = _text(
        admission.get("calibration_source_integrity")
    ).upper()

    if state == "ADMISSION_UPSTREAM_HOLD":
        cal_mapping_ok = (
            cal_fresh == "NOT_REQUIRED"
            and cal_integrity == "NOT_REQUIRED"
        )
    elif state == "ADMISSION_READY_FOR_REVIEW":
        cal_mapping_ok = (
            cal_fresh == "CURRENT"
            and cal_integrity == "OK"
        )
    elif state == "ADMISSION_CALIBRATION_SOURCE_REQUIRED":
        cal_mapping_ok = cal_fresh == "MISSING"
    elif state == "ADMISSION_CALIBRATION_SOURCE_INTEGRITY_REVIEW":
        cal_mapping_ok = cal_fresh == "INVALID"
    elif state == "ADMISSION_CALIBRATION_SOURCE_DRIFT_REVIEW":
        cal_mapping_ok = cal_fresh == "DRIFTED"
    else:
        cal_mapping_ok = cal_fresh in {
            "CURRENT",
            "NOT_REQUIRED",
        }

    checks.append(
        _technical_row(
            "Calibration Source Lock Mapping",
            cal_mapping_ok,
            (
                f"state {state or 'MISSING'} · "
                f"freshness {cal_fresh or 'MISSING'} · "
                f"integrity {cal_integrity or 'MISSING'}"
            ),
            "Admission state와 Calibration source freshness/integrity mapping 확인",
        )
    )

    promo_fresh = _text(
        admission.get("promotion_source_freshness")
    ).upper()
    promo_integrity = _text(
        admission.get("promotion_source_integrity")
    ).upper()

    if state == "ADMISSION_UPSTREAM_HOLD":
        promo_mapping_ok = (
            promo_fresh == "NOT_REQUIRED"
            and promo_integrity == "NOT_REQUIRED"
        )
    elif state == "ADMISSION_READY_FOR_REVIEW":
        promo_mapping_ok = (
            promo_fresh == "CURRENT"
            and promo_integrity == "OK"
        )
    elif state == "ADMISSION_PROMOTION_SOURCE_REQUIRED":
        promo_mapping_ok = promo_fresh == "MISSING"
    elif state == "ADMISSION_PROMOTION_SOURCE_INTEGRITY_REVIEW":
        promo_mapping_ok = promo_fresh == "INVALID"
    elif state == "ADMISSION_PROMOTION_SOURCE_DRIFT_REVIEW":
        promo_mapping_ok = promo_fresh == "DRIFTED"
    else:
        promo_mapping_ok = promo_fresh in {
            "CURRENT",
            "MISSING",
            "NOT_REQUIRED",
        }

    checks.append(
        _technical_row(
            "Promotion Source Lock Mapping",
            promo_mapping_ok,
            (
                f"state {state or 'MISSING'} · "
                f"freshness {promo_fresh or 'MISSING'} · "
                f"integrity {promo_integrity or 'MISSING'}"
            ),
            "Admission state와 Promotion source freshness/integrity mapping 확인",
        )
    )

    order_state = _text(
        admission.get("source_order_state")
    ).upper()

    if state == "ADMISSION_UPSTREAM_HOLD":
        order_ok = order_state == "NOT_REQUIRED"
    elif state == "ADMISSION_READY_FOR_REVIEW":
        order_ok = order_state in READY_SOURCE_ORDER
    elif state == "ADMISSION_PROMOTION_AFTER_CALIBRATION_REQUIRED":
        order_ok = order_state == "PROMOTION_PRECEDES_CALIBRATION"
    elif state == "ADMISSION_SOURCE_TIME_INTEGRITY_REVIEW":
        order_ok = order_state == "INVALID_TIME"
    else:
        order_ok = order_state in {
            "NOT_APPLICABLE",
            "PROMOTION_AFTER_CALIBRATION",
        }

    checks.append(
        _technical_row(
            "Calibration → Promotion Save-order Invariant",
            order_ok,
            (
                f"state {state or 'MISSING'} · "
                f"source order {order_state or 'MISSING'}"
            ),
            (
                "PROMOTION_READY 이후 Calibration Snapshot → Promotion Audit Snapshot "
                "순서 확인"
            ),
        )
    )

    projection_state = _text(
        projection.get("projection_state")
    ).upper()

    if state == "ADMISSION_UPSTREAM_HOLD":
        handoff_ok = (
            projection_state != "READY_FOR_REVIEW"
            and projection_state != "HOLD_ADMISSION_SOURCE"
        )
    elif state == "ADMISSION_READY_FOR_REVIEW":
        handoff_ok = (
            projection_state == "READY_FOR_REVIEW"
        )
    else:
        handoff_ok = (
            projection_state == "HOLD_ADMISSION_SOURCE"
        )

    checks.append(
        _technical_row(
            "Admission → Projection Hand-off Invariant",
            handoff_ok,
            (
                f"admission {state or 'MISSING'} · "
                f"projection {projection_state or 'MISSING'}"
            ),
            "Admission state와 Projection state hand-off 확인",
        )
    )

    auth_violations = 0

    for source in [
        admission,
        projection,
    ]:
        for field in [
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in source
                and _text(source.get(field)).upper()
                not in {"", "NONE"}
            ):
                auth_violations += 1

    admission_df = ctx.get("admission_snapshots")
    if (
        isinstance(admission_df, pd.DataFrame)
        and not admission_df.empty
    ):
        for field in [
            "projection_authorization",
            "execution_authorization",
        ]:
            if field not in admission_df.columns:
                continue

            values = (
                admission_df[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            auth_violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if (
        _text(
            ctx.get("execution_authorization")
        ).upper()
        != "NONE"
    ):
        auth_violations += 1

    checks.append(
        _technical_row(
            "Projection Admission Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            (
                "Projection / Execution Authorization을 NONE으로 유지"
            ),
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state == "ADMISSION_READY_FOR_REVIEW"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Admission Operating State",
            "status": operating_status,
            "detail": (
                f"admission {state or 'MISSING'} · "
                f"calibration {cal_fresh or 'MISSING'} · "
                f"promotion {promo_fresh or 'MISSING'} · "
                f"order {order_state or 'MISSING'} · "
                f"projection {projection_state or 'MISSING'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream HOLD / source wait는 Technical FAIL로 승격하지 않고 "
                    "Evidence/Promotion/source freshness를 자연스럽게 충족"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "admission_state": state,
        "calibration_source_freshness": cal_fresh,
        "promotion_source_freshness": promo_fresh,
        "source_order_state": order_state,
        "projection_state": projection_state,
        "latest_admission_integrity": _text(
            ctx.get("latest_admission_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=ADMISSION_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v132_admission_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    admission_df = ctx.get("admission_snapshots")
    calibration_df = ctx.get("calibration_snapshots")
    promotion_df = ctx.get("promotion_snapshots")

    admission_df = (
        admission_df
        if isinstance(admission_df, pd.DataFrame)
        else pd.DataFrame()
    )
    calibration_df = (
        calibration_df
        if isinstance(calibration_df, pd.DataFrame)
        else pd.DataFrame()
    )
    promotion_df = (
        promotion_df
        if isinstance(promotion_df, pd.DataFrame)
        else pd.DataFrame()
    )

    counts = ctx.get("admission_integrity") or {}

    checks = []

    checks.append(
        _audit_row(
            "Projection Admission Audit Snapshot Integrity",
            _fail_count(counts) == 0,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Admission audit immutable hash 확인",
        )
    )

    vocabulary_violations = 0
    ready_mapping_violations = 0
    auth_violations = 0

    cal_index, cal_duplicates = _index_by_id(
        calibration_df,
        id_col="calibration_snapshot_id",
    )
    promo_index, promo_duplicates = _index_by_id(
        promotion_df,
        id_col="promotion_snapshot_id",
    )

    source_lineage_violations = (
        cal_duplicates
        + promo_duplicates
    )

    for _, row in admission_df.iterrows():
        item = row.to_dict()
        state = _text(
            item.get("admission_state")
        ).upper()
        guard = _text(
            item.get("effective_projection_guard")
        ).upper()

        if (
            state not in KNOWN_ADMISSION_STATES
            or guard not in KNOWN_EFFECTIVE_GUARDS
        ):
            vocabulary_violations += 1

        if state == "ADMISSION_READY_FOR_REVIEW":
            cal_fresh = _text(
                item.get("calibration_source_freshness")
            ).upper()
            promo_fresh = _text(
                item.get("promotion_source_freshness")
            ).upper()
            order_state = _text(
                item.get("source_order_state")
            ).upper()

            if not (
                guard == "ALLOW_PROJECTION_REVIEW"
                and cal_fresh == "CURRENT"
                and promo_fresh == "CURRENT"
                and order_state in READY_SOURCE_ORDER
            ):
                ready_mapping_violations += 1

            cal_id = _text(
                item.get("calibration_snapshot_id")
            )
            cal_hash = _text(
                item.get("calibration_snapshot_hash")
            )
            promo_id = _text(
                item.get("promotion_snapshot_id")
            )
            promo_hash = _text(
                item.get("promotion_snapshot_hash")
            )

            cal_parent = cal_index.get(cal_id)
            promo_parent = promo_index.get(promo_id)

            if (
                not cal_id
                or cal_parent is None
                or _text(
                    flow_calibration_snapshot_integrity(
                        cal_parent
                    ).get("status")
                ).upper()
                != "OK"
                or _text(
                    cal_parent.get("snapshot_hash")
                )
                != cal_hash
            ):
                source_lineage_violations += 1

            if (
                not promo_id
                or promo_parent is None
                or _text(
                    flow_calibration_promotion_snapshot_integrity(
                        promo_parent
                    ).get("status")
                ).upper()
                != "OK"
                or _text(
                    promo_parent.get("snapshot_hash")
                )
                != promo_hash
            ):
                source_lineage_violations += 1

        for field in [
            "projection_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {
                "",
                "NONE",
            }:
                auth_violations += 1

    checks.append(
        _audit_row(
            "Admission Audit State / Guard Vocabulary",
            vocabulary_violations == 0,
            f"violations {vocabulary_violations}",
            "저장 Admission audit state/guard vocabulary 확인",
        )
    )

    checks.append(
        _audit_row(
            "Admission READY Audit Source-lock Mapping",
            ready_mapping_violations == 0,
            f"violations {ready_mapping_violations}",
            "READY Admission audit의 CURRENT source / save-order / ALLOW mapping 확인",
        )
    )

    checks.append(
        _audit_row(
            "Admission READY Audit Source Lineage",
            source_lineage_violations == 0,
            (
                f"violations {source_lineage_violations} · "
                f"cal duplicates {cal_duplicates} · "
                f"promotion duplicates {promo_duplicates}"
            ),
            "READY Admission audit의 Calibration/Promotion parent id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Admission Audit Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"violations {auth_violations}"
            ),
            "저장 Admission audit authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    live_state = _text(
        (ctx.get("admission") or {}).get(
            "admission_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if (
            live_state == "ADMISSION_READY_FOR_REVIEW"
            and not admission_df.empty
        )
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Admission Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current admission {live_state or 'MISSING'} · "
                f"saved audits {len(admission_df)}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "Admission proof가 실제로 성숙할 때만 audit history를 저장하고 "
                    "upstream HOLD를 Snapshot 저장으로 우회하지 않음"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=ADMISSION_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v132_release_readiness(
    *,
    v131_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    admission_release_gate: str,
    admission_audit_gate: str,
    admission_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    v131 = _text(
        v131_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    admission_gate = _text(
        admission_release_gate
    ).upper()
    audit_gate = _text(
        admission_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.31 Calibration Promotion Release Baseline",
            v131 == "READY_FOR_RELEASE_REVIEW",
            v131 or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Admission Technical Release Gate",
            admission_gate == "PASS",
            admission_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Admission Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(
            admission_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "PROJECTION_ADMISSION_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V132_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v132_integration_crosscheck(
    *,
    integration_consistency: str,
    admission_release_gate: str,
    admission_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    admission_gate = _text(
        admission_release_gate
    ).upper()
    audit_gate = _text(
        admission_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Projection Admission Technical Gate",
            admission_gate == "PASS",
            admission_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Admission Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V132_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v132_data_crosscheck(
    *,
    csv_fail_count: int,
    admission_release_gate: str,
    admission_audit_gate: str,
    latest_admission_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    admission_gate = _text(
        admission_release_gate
    ).upper()
    audit_gate = _text(
        admission_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_admission_integrity
    ).upper()

    latest_ok = (
        latest_integrity in {
            "OK",
            "NONE",
        }
    )

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Admission Technical Gate",
            admission_gate == "PASS",
            admission_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Admission Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Projection Admission Snapshot Integrity",
            latest_ok,
            latest_integrity or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V132_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
