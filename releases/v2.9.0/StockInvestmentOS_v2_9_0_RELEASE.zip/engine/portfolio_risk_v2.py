from __future__ import annotations

from datetime import datetime
from typing import Any

import pandas as pd


RISK_OVERLAY_COLS = [
    "name",
    "ticker",
    "currency",
    "fx_hedge_ratio",
    "liquidity_days_to_exit",
    "reviewed",
    "source",
    "review_due_date",
    "note",
    "updated_at",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {"TRUE", "1", "YES", "Y", "PASS"}


def normalize_risk_overlays(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Stable dtypes across CSV reloads for Streamlit DataEditor.
    """
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in RISK_OVERLAY_COLS:
        if col not in out.columns:
            out[col] = ""

    text_cols = [
        "name",
        "ticker",
        "currency",
        "source",
        "review_due_date",
        "note",
        "updated_at",
    ]
    for col in text_cols:
        out[col] = out[col].map(_text).astype("object")

    for col in [
        "fx_hedge_ratio",
        "liquidity_days_to_exit",
    ]:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )

    out["reviewed"] = out["reviewed"].map(_bool).astype(bool)

    return out[RISK_OVERLAY_COLS].copy()


def overlay_editor_rows(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Ensure every current portfolio asset has one overlay row.

    Existing user-entered overlay data is preserved.
    """
    overlay = normalize_risk_overlays(overlays)

    if portfolio is None or portfolio.empty:
        return overlay

    p = portfolio.copy()
    for col in ["name", "ticker", "currency"]:
        if col not in p.columns:
            p[col] = ""

    rows = []
    for _, prow in p.iterrows():
        name = _text(prow.get("name"))
        ticker = _text(prow.get("ticker"))
        currency = _text(prow.get("currency")) or "KRW"

        if not name:
            continue

        hit = overlay.loc[
            overlay["name"].fillna("").astype(str).str.strip().eq(name)
        ].copy()
        if ticker and not hit.empty:
            ticker_hit = hit.loc[
                hit["ticker"].fillna("").astype(str).str.strip().eq(ticker)
            ]
            if not ticker_hit.empty:
                hit = ticker_hit

        if not hit.empty:
            row = hit.iloc[-1].to_dict()
            row["name"] = name
            row["ticker"] = ticker
            row["currency"] = currency
        else:
            row = {
                "name": name,
                "ticker": ticker,
                "currency": currency,
                "fx_hedge_ratio": "",
                "liquidity_days_to_exit": "",
                "reviewed": False,
                "source": "",
                "review_due_date": "",
                "note": "",
                "updated_at": "",
            }
        rows.append(row)

    return normalize_risk_overlays(pd.DataFrame(rows))


def portfolio_risk_budget_snapshot(
    mr_snapshot: dict,
    portfolio_car_budget: float,
) -> dict:
    direct = max(0.0, float(mr_snapshot.get("direct_bear_loss", 0.0) or 0.0))
    stress = max(0.0, float(mr_snapshot.get("stress_proxy", 0.0) or 0.0))
    budget = max(0.0, float(portfolio_car_budget or 0.0))

    direct_headroom = budget - direct
    stress_headroom = budget - stress

    status = (
        "PRE_EXISTING_BREACH"
        if direct > budget
        else "PASS"
    )

    return {
        "direct_bear_loss": direct,
        "stress_proxy": stress,
        "portfolio_car_budget": budget,
        "direct_headroom": direct_headroom,
        "stress_headroom": stress_headroom,
        "status": status,
        "cash_weight": float(mr_snapshot.get("cash_weight", 0.0) or 0.0),
        "corr_covered_weight": float(
            mr_snapshot.get("corr_covered_weight", 0.0) or 0.0
        ),
        "hhi": float(mr_snapshot.get("hhi", 0.0) or 0.0),
        "top_car_share": float(
            mr_snapshot.get("top_car_share", 0.0) or 0.0
        ),
    }


def _asset_value_lookup(portfolio: pd.DataFrame | None) -> dict[str, float]:
    if portfolio is None or portfolio.empty:
        return {}

    out: dict[str, float] = {}
    for _, row in portfolio.iterrows():
        name = _text(row.get("name"))
        if not name:
            continue
        value = _num(row.get("current_value_krw")) or 0.0
        out[name] = out.get(name, 0.0) + max(0.0, value)
    return out


def risk_overlay_status_table(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
    total_assets: float,
    *,
    liquidity_days_limit: float = 5.0,
    fx_unhedged_cap: float = 0.15,
) -> pd.DataFrame:
    overlay = overlay_editor_rows(portfolio, overlays)
    if overlay.empty:
        return pd.DataFrame()

    values = _asset_value_lookup(portfolio)
    total = max(0.0, float(total_assets or 0.0))

    asset_type_lookup = {}
    if portfolio is not None and not portfolio.empty:
        for _, row in portfolio.iterrows():
            name = _text(row.get("name"))
            if name:
                asset_type_lookup[name] = _text(row.get("asset_type")).lower()

    rows = []
    for _, row in overlay.iterrows():
        name = _text(row.get("name"))
        currency = (_text(row.get("currency")) or "KRW").upper()
        asset_type = asset_type_lookup.get(name, "")
        is_cash = asset_type == "cash" or name.lower() == "cash"

        value = values.get(name, 0.0)
        weight = value / total if total > 0 else 0.0

        hedge = _num(row.get("fx_hedge_ratio"))
        days = _num(row.get("liquidity_days_to_exit"))
        reviewed = _bool(row.get("reviewed"))

        issues = []

        fx_required = (currency not in {"", "KRW"}) and not is_cash
        if fx_required:
            if hedge is None:
                issues.append("FX_HEDGE_REVIEW_REQUIRED")
                unhedged_weight = None
            elif hedge < 0 or hedge > 1:
                issues.append("FX_HEDGE_RATIO_INVALID")
                unhedged_weight = None
            else:
                unhedged_weight = weight * (1.0 - hedge)
        else:
            unhedged_weight = 0.0

        if not is_cash:
            if days is None:
                issues.append("LIQUIDITY_DAYS_REQUIRED")
                liquidity_status = "REVIEW"
            elif days < 0:
                issues.append("LIQUIDITY_DAYS_INVALID")
                liquidity_status = "REVIEW"
            elif days > float(liquidity_days_limit):
                liquidity_status = "TIGHT"
                issues.append("LIQUIDITY_LIMIT_EXCEEDED")
            else:
                liquidity_status = "PASS"
        else:
            liquidity_status = "PASS"

        if not is_cash:
            if reviewed:
                if not _text(row.get("source")):
                    issues.append("OVERLAY_SOURCE_REQUIRED")
            else:
                issues.append("OVERLAY_HUMAN_REVIEW_REQUIRED")

        status = "PASS" if not issues else "REVIEW"

        rows.append(
            {
                "name": name,
                "ticker": _text(row.get("ticker")),
                "asset_type": asset_type,
                "currency": currency,
                "current_value_krw": value,
                "weight": weight,
                "fx_hedge_ratio": hedge,
                "unhedged_fx_weight": unhedged_weight,
                "liquidity_days_to_exit": days,
                "liquidity_status": liquidity_status,
                "reviewed": reviewed,
                "source": _text(row.get("source")),
                "review_due_date": _text(row.get("review_due_date")),
                "status": status,
                "issues": " | ".join(issues),
            }
        )

    return pd.DataFrame(rows)


def risk_overlay_summary(
    status_table: pd.DataFrame | None,
    *,
    fx_unhedged_cap: float = 0.15,
) -> dict:
    if status_table is None or status_table.empty:
        return {
            "portfolio_weight": 0.0,
            "reviewed_weight": 0.0,
            "review_coverage": 0.0,
            "foreign_weight": 0.0,
            "known_unhedged_fx_weight": 0.0,
            "fx_review_weight": 0.0,
            "liquidity_review_weight": 0.0,
            "tight_liquidity_weight": 0.0,
            "max_days_to_exit": None,
            "fx_gate": "REVIEW",
        }

    df = status_table.copy()
    weight = pd.to_numeric(df.get("weight"), errors="coerce").fillna(0.0)

    portfolio_weight = float(weight.sum())
    reviewed_mask = df.get("reviewed", False).fillna(False).astype(bool)
    reviewed_weight = float(weight.loc[reviewed_mask].sum())

    noncash_mask = ~df.get("asset_type", "").fillna("").astype(str).str.lower().eq("cash")
    relevant_weight = float(weight.loc[noncash_mask].sum())
    review_coverage = (
        reviewed_weight / relevant_weight
        if relevant_weight > 0
        else 1.0
    )

    foreign_mask = ~df.get("currency", "").fillna("").astype(str).str.upper().isin(["", "KRW"])
    foreign_weight = float(weight.loc[foreign_mask].sum())

    unhedged = pd.to_numeric(
        df.get("unhedged_fx_weight"),
        errors="coerce",
    )
    known_unhedged = float(unhedged.fillna(0.0).sum())

    fx_review_mask = df.get("issues", "").fillna("").astype(str).str.contains(
        "FX_HEDGE",
        regex=False,
    )
    fx_review_weight = float(weight.loc[fx_review_mask].sum())

    liquidity_review_mask = df.get("issues", "").fillna("").astype(str).str.contains(
        "LIQUIDITY_DAYS",
        regex=False,
    )
    liquidity_review_weight = float(weight.loc[liquidity_review_mask].sum())

    tight_mask = df.get("liquidity_status", "").fillna("").astype(str).eq("TIGHT")
    tight_liquidity_weight = float(weight.loc[tight_mask].sum())

    days = pd.to_numeric(
        df.get("liquidity_days_to_exit"),
        errors="coerce",
    )
    max_days = (
        float(days.max())
        if days.notna().any()
        else None
    )

    if fx_review_weight > 0:
        fx_gate = "REVIEW"
    elif known_unhedged > float(fx_unhedged_cap):
        fx_gate = "PRE_EXISTING_BREACH"
    else:
        fx_gate = "PASS"

    return {
        "portfolio_weight": portfolio_weight,
        "reviewed_weight": reviewed_weight,
        "review_coverage": review_coverage,
        "foreign_weight": foreign_weight,
        "known_unhedged_fx_weight": known_unhedged,
        "fx_review_weight": fx_review_weight,
        "liquidity_review_weight": liquidity_review_weight,
        "tight_liquidity_weight": tight_liquidity_weight,
        "max_days_to_exit": max_days,
        "fx_gate": fx_gate,
    }


def direct_currency_exposure(
    portfolio: pd.DataFrame | None,
    total_assets: float,
) -> pd.DataFrame:
    if portfolio is None or portfolio.empty:
        return pd.DataFrame(
            columns=["currency", "value_krw", "portfolio_weight"]
        )

    p = portfolio.copy()
    if "currency" not in p.columns:
        p["currency"] = "KRW"
    if "current_value_krw" not in p.columns:
        p["current_value_krw"] = 0.0

    p["currency"] = (
        p["currency"]
        .fillna("")
        .astype(str)
        .str.strip()
        .replace("", "KRW")
        .str.upper()
    )
    p["value_krw"] = pd.to_numeric(
        p["current_value_krw"],
        errors="coerce",
    ).fillna(0.0)

    out = (
        p.groupby("currency", as_index=False)["value_krw"]
        .sum()
        .sort_values("value_krw", ascending=False)
    )
    total = max(0.0, float(total_assets or 0.0))
    out["portfolio_weight"] = (
        out["value_krw"] / total
        if total > 0
        else 0.0
    )
    return out.reset_index(drop=True)


def top_risk_contributors(
    asset_contributions: pd.DataFrame | None,
    top_n: int = 10,
) -> pd.DataFrame:
    if asset_contributions is None or asset_contributions.empty:
        return pd.DataFrame()

    df = asset_contributions.copy()

    sort_col = None
    for candidate in [
        "capital_at_risk",
        "stress_component",
        "stress_mrc",
    ]:
        if candidate in df.columns:
            sort_col = candidate
            df[candidate] = pd.to_numeric(
                df[candidate],
                errors="coerce",
            ).fillna(0.0)
            break

    if sort_col is None:
        return df.head(top_n)

    return (
        df.sort_values(sort_col, ascending=False)
        .head(int(top_n))
        .reset_index(drop=True)
    )


def overlay_save_rows(
    edited: pd.DataFrame,
) -> pd.DataFrame:
    out = normalize_risk_overlays(edited)
    if "updated_at" in out.columns:
        now = datetime.now().isoformat()
        out["updated_at"] = now
    return out


def stress_reliability_status(
    corr_covered_weight: float | None,
    *,
    min_coverage: float = 0.60,
    source_status: str = "PASS",
) -> dict:
    coverage = _num(corr_covered_weight)
    if coverage is None:
        coverage = 0.0
    coverage = max(0.0, min(1.0, coverage))

    if coverage <= 1e-9:
        return {
            "status": "FALLBACK_DIRECT_CAR",
            "coverage": coverage,
            "decision_ready": False,
            "reason": "NO_CORRELATION_COVERAGE",
        }
    if str(source_status or "").upper() != "PASS":
        return {
            "status": "REVIEW",
            "coverage": coverage,
            "decision_ready": False,
            "reason": "CORRELATION_SOURCE_REVIEW",
        }

    if coverage < float(min_coverage):
        return {
            "status": "REVIEW",
            "coverage": coverage,
            "decision_ready": False,
            "reason": "CORRELATION_COVERAGE_BELOW_MINIMUM",
        }
    return {
        "status": "PASS",
        "coverage": coverage,
        "decision_ready": True,
        "reason": "CORRELATION_COVERAGE_SUFFICIENT",
    }


def risk_concentration_status(
    top_car_share: float | None,
    *,
    review_cap: float = 0.50,
) -> dict:
    share = _num(top_car_share)
    if share is None:
        return {
            "status": "REVIEW",
            "top_car_share": None,
            "headroom": None,
            "reason": "TOP_CAR_SHARE_MISSING",
        }

    headroom = float(review_cap) - share
    return {
        "status": "REVIEW" if share > float(review_cap) else "PASS",
        "top_car_share": share,
        "headroom": headroom,
        "reason": (
            "TOP_CAR_CONCENTRATION_ABOVE_REVIEW_CAP"
            if share > float(review_cap)
            else "TOP_CAR_CONCENTRATION_WITHIN_REVIEW_CAP"
        ),
    }


def currency_lookthrough_diagnostics(
    direct_currency: pd.DataFrame | None,
    lookthrough_currency: pd.DataFrame | None,
    *,
    cash_weight: float = 0.0,
    min_coverage: float = 0.80,
) -> dict:
    def _prepare(df: pd.DataFrame | None) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame(
                columns=["currency", "portfolio_weight"]
            )
        out = df.copy()
        if "currency" not in out.columns:
            out["currency"] = ""
        if "portfolio_weight" not in out.columns:
            out["portfolio_weight"] = 0.0
        out["currency"] = (
            out["currency"]
            .fillna("")
            .astype(str)
            .str.strip()
            .replace("", "UNKNOWN")
            .str.upper()
        )
        out["portfolio_weight"] = pd.to_numeric(
            out["portfolio_weight"],
            errors="coerce",
        ).fillna(0.0)
        return out

    direct = _prepare(direct_currency)
    look = _prepare(lookthrough_currency)

    direct_foreign = float(
        direct.loc[
            ~direct["currency"].isin(["KRW", "UNKNOWN"]),
            "portfolio_weight",
        ].sum()
    )
    look_foreign = float(
        look.loc[
            ~look["currency"].isin(["KRW", "UNKNOWN"]),
            "portfolio_weight",
        ].sum()
    )

    investable_weight = max(
        0.0,
        1.0 - max(0.0, float(cash_weight or 0.0)),
    )
    look_covered_weight = float(
        look["portfolio_weight"].clip(lower=0.0).sum()
    )
    look_coverage = (
        min(1.0, look_covered_weight / investable_weight)
        if investable_weight > 0
        else 1.0
    )

    unknown_weight = float(
        look.loc[
            look["currency"].eq("UNKNOWN"),
            "portfolio_weight",
        ].sum()
    )

    hidden_foreign = max(
        0.0,
        look_foreign - direct_foreign,
    )

    if look.empty:
        status = "REVIEW"
        reason = "LOOKTHROUGH_CURRENCY_MISSING"
    elif look_coverage < float(min_coverage):
        status = "REVIEW"
        reason = "LOOKTHROUGH_CURRENCY_COVERAGE_LOW"
    elif unknown_weight > 0:
        status = "REVIEW"
        reason = "LOOKTHROUGH_CURRENCY_UNKNOWN"
    else:
        status = "PASS"
        reason = "LOOKTHROUGH_CURRENCY_COVERAGE_OK"

    return {
        "status": status,
        "reason": reason,
        "direct_foreign_weight": direct_foreign,
        "lookthrough_foreign_weight": look_foreign,
        "hidden_foreign_weight": hidden_foreign,
        "lookthrough_covered_weight": look_covered_weight,
        "investable_weight": investable_weight,
        "lookthrough_coverage": look_coverage,
        "unknown_currency_weight": unknown_weight,
    }


def factor_policy_view(
    factor_table: pd.DataFrame | None,
    *,
    exempt_factors: tuple[str, ...] = ("Cash",),
) -> pd.DataFrame:
    """
    Portfolio Risk 2.0 policy presentation.

    Cash is liquidity optionality, not a risk factor subject to the same
    concentration cap as economic risk factors. The raw factor engine output
    is not mutated elsewhere; this is an explicit policy view.
    """
    if factor_table is None or factor_table.empty:
        return pd.DataFrame()

    out = factor_table.copy()
    if "factor" not in out.columns:
        return out

    exempt = {
        str(x or "").strip().lower()
        for x in exempt_factors
    }
    factor_key = (
        out["factor"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.lower()
    )
    mask = factor_key.isin(exempt)

    if "policy_cap" in out.columns:
        out.loc[mask, "policy_cap"] = None
    if "excess_exposure" in out.columns:
        out.loc[mask, "excess_exposure"] = 0.0
    if "new_risk_headroom" in out.columns:
        out.loc[mask, "new_risk_headroom"] = None
    if "breach_status" in out.columns:
        out.loc[mask, "breach_status"] = "POLICY_EXEMPT"

    out["policy_scope"] = "RISK_FACTOR"
    out.loc[mask, "policy_scope"] = "LIQUIDITY_OPTIONALITY"
    return out


def overlay_decision_readiness(
    status_table: pd.DataFrame | None,
    *,
    min_review_coverage: float = 0.80,
) -> dict:
    """
    Decision-use readiness for the FX/Liquidity overlay.

    This gate measures data/review completeness only. It does not say the
    portfolio is low-risk or high-risk.
    """
    if status_table is None or status_table.empty:
        return {
            "status": "REVIEW",
            "review_coverage": 0.0,
            "noncash_weight": 0.0,
            "pass_weight": 0.0,
            "review_weight": 0.0,
            "issue_rows": 0,
            "reason": "OVERLAY_EMPTY",
        }

    df = status_table.copy()
    weight = pd.to_numeric(
        df.get("weight"),
        errors="coerce",
    ).fillna(0.0)

    noncash_mask = ~(
        df.get("asset_type", "")
        .fillna("")
        .astype(str)
        .str.lower()
        .eq("cash")
    )
    noncash_weight = float(weight.loc[noncash_mask].sum())

    pass_mask = (
        df.get("status", "")
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("PASS")
        & noncash_mask
    )
    pass_weight = float(weight.loc[pass_mask].sum())

    review_weight = max(0.0, noncash_weight - pass_weight)
    review_coverage = (
        pass_weight / noncash_weight
        if noncash_weight > 0
        else 1.0
    )

    issue_rows = int(
        (
            df.get("status", "")
            .fillna("")
            .astype(str)
            .str.upper()
            .ne("PASS")
            & noncash_mask
        ).sum()
    )

    status = (
        "PASS"
        if review_coverage >= float(min_review_coverage)
        else "REVIEW"
    )
    reason = (
        "OVERLAY_COVERAGE_SUFFICIENT"
        if status == "PASS"
        else "OVERLAY_COVERAGE_BELOW_MINIMUM"
    )

    return {
        "status": status,
        "review_coverage": review_coverage,
        "noncash_weight": noncash_weight,
        "pass_weight": pass_weight,
        "review_weight": review_weight,
        "issue_rows": issue_rows,
        "reason": reason,
    }


def portfolio_risk_decision_gate(
    *,
    car_budget_status: str,
    concentration_status: str,
    stress_reliability_status_value: str,
    currency_lookthrough_status: str,
    liquidity_overlay_status: str = "REVIEW",
    economic_fx_status: str = "REVIEW",
    business_fx_status: str = "REVIEW",
    business_fx_evidence_history_status: str = "REVIEW",
) -> dict:
    """
    Composite decision-use readiness.

    This is NOT an investment recommendation. It only says whether the
    portfolio-risk inputs are sufficiently reviewed for decision support.
    """
    issues = []

    if str(car_budget_status or "").upper() != "PASS":
        issues.append("CAR_BUDGET")
    if str(concentration_status or "").upper() != "PASS":
        issues.append("TOP_CAR_CONCENTRATION")
    if str(stress_reliability_status_value or "").upper() != "PASS":
        issues.append("STRESS_RELIABILITY")
    if str(currency_lookthrough_status or "").upper() != "PASS":
        issues.append("ECONOMIC_CURRENCY_COVERAGE")
    if str(liquidity_overlay_status or "").upper() != "PASS":
        issues.append("LIQUIDITY_OVERLAY")
    if str(economic_fx_status or "").upper() != "PASS":
        issues.append("ECONOMIC_FX_OVERLAY")
    if str(business_fx_status or "").upper() != "PASS":
        issues.append("BUSINESS_FX_SENSITIVITY")
    if str(
        business_fx_evidence_history_status
        or ""
    ).upper() != "PASS":
        issues.append(
            "BUSINESS_FX_MULTIPERIOD_EVIDENCE"
        )

    return {
        "status": "PASS" if not issues else "REVIEW",
        "issues": issues,
    }


ECONOMIC_FX_OVERLAY_COLS = [
    "name",
    "ticker",
    "direct_currency",
    "economic_currency",
    "economic_fx_exposure_ratio",
    "economic_fx_hedge_ratio",
    "reviewed",
    "source",
    "review_due_date",
    "note",
    "updated_at",
]


def normalize_economic_fx_overlays(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Stable text/bool/numeric dtypes across CSV reloads.
    """
    if df is None:
        df = pd.DataFrame()
    out = df.copy()
    for col in ECONOMIC_FX_OVERLAY_COLS:
        if col not in out.columns:
            out[col] = ""

    text_cols = [
        "name",
        "ticker",
        "direct_currency",
        "economic_currency",
        "source",
        "review_due_date",
        "note",
        "updated_at",
    ]
    for col in text_cols:
        out[col] = out[col].map(_text).astype("object")

    for col in [
        "economic_fx_exposure_ratio",
        "economic_fx_hedge_ratio",
    ]:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )

    out["reviewed"] = out["reviewed"].map(_bool).astype(bool)

    return out[ECONOMIC_FX_OVERLAY_COLS].copy()


def economic_fx_editor_rows(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    One asset-level economic FX row per current portfolio asset.

    Direct non-KRW assets get a source suggestion only:
    economic currency = direct currency, exposure ratio = 1.0.
    Reviewed remains False.

    KRW-traded assets are intentionally NOT assumed to have zero FX exposure.
    This prevents KRW-listed overseas ETFs from disappearing from FX risk.
    """
    existing = normalize_economic_fx_overlays(overlays)

    if portfolio is None or portfolio.empty:
        return existing

    rows = []
    for _, prow in portfolio.iterrows():
        name = _text(prow.get("name"))
        ticker = _text(prow.get("ticker"))
        direct_currency = (
            _text(prow.get("currency")) or "KRW"
        ).upper()
        asset_type = _text(prow.get("asset_type")).lower()
        is_cash = (
            asset_type == "cash"
            or name.lower() in {"cash", "현금"}
        )

        if not name:
            continue

        hit = existing.loc[
            existing["name"]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(name)
        ].copy()
        if ticker and not hit.empty:
            ticker_hit = hit.loc[
                hit["ticker"]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(ticker)
            ]
            if not ticker_hit.empty:
                hit = ticker_hit

        if not hit.empty:
            row = hit.iloc[-1].to_dict()
            row["name"] = name
            row["ticker"] = ticker
            row["direct_currency"] = direct_currency
        else:
            wrapper_types = {
                "etf",
                "fund",
                "index_fund",
                "mutual_fund",
                "etn",
            }
            single_name_types = {
                "equity",
                "stock",
                "common_stock",
                "preferred_stock",
                "common",
                "preferred",
            }

            if is_cash:
                suggested_currency = "KRW"
                suggested_exposure = 0.0
                suggested_note = "CASH_POLICY_EXEMPT"
            elif direct_currency != "KRW":
                suggested_currency = direct_currency
                suggested_exposure = 1.0
                suggested_note = "DIRECT_CURRENCY_SUGGESTION"
            elif asset_type in wrapper_types:
                # KRW-listed wrapper may still hold foreign assets.
                suggested_currency = ""
                suggested_exposure = None
                suggested_note = "KRW_WRAPPER_REVIEW_REQUIRED"
            else:
                # Direct KRW security is not an Asset/Wrapper FX review target.
                # Any operating/business FX sensitivity belongs in the separate
                # Business FX Sensitivity Overlay.
                suggested_currency = "KRW"
                suggested_exposure = 0.0
                suggested_note = (
                    "BUSINESS_FX_SEPARATE"
                    if asset_type in single_name_types
                    else "DIRECT_KRW_SECURITY_POLICY_EXEMPT"
                )

            row = {
                "name": name,
                "ticker": ticker,
                "direct_currency": direct_currency,
                "economic_currency": suggested_currency,
                "economic_fx_exposure_ratio": suggested_exposure,
                "economic_fx_hedge_ratio": "",
                "reviewed": False,
                "source": "",
                "review_due_date": "",
                "note": suggested_note,
                "updated_at": "",
            }
        rows.append(row)

    return normalize_economic_fx_overlays(
        pd.DataFrame(rows)
    )


def economic_fx_status_table(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
    total_assets: float,
) -> pd.DataFrame:
    """
    Asset / Wrapper FX exposure only.

    Scope:
    - direct non-KRW security: review target
    - ETF/fund/ETN wrapper: review target even when traded in KRW
    - direct KRW single-name equity: Asset FX policy-exempt; Business FX is
      handled separately in Business FX Sensitivity Overlay
    - direct KRW non-wrapper security: policy-exempt
    - cash: policy-exempt
    """
    overlay = economic_fx_editor_rows(
        portfolio,
        overlays,
    )
    if overlay.empty:
        return pd.DataFrame()

    values = _asset_value_lookup(portfolio)
    total = max(0.0, float(total_assets or 0.0))

    asset_type_lookup = {}
    direct_currency_lookup = {}
    if portfolio is not None and not portfolio.empty:
        for _, row in portfolio.iterrows():
            name = _text(row.get("name"))
            if not name:
                continue
            asset_type_lookup[name] = _text(
                row.get("asset_type")
            ).lower()
            direct_currency_lookup[name] = (
                _text(row.get("currency")) or "KRW"
            ).upper()

    wrapper_types = {
        "etf",
        "fund",
        "index_fund",
        "mutual_fund",
        "etn",
    }
    single_name_types = {
        "equity",
        "stock",
        "common_stock",
        "preferred_stock",
        "common",
        "preferred",
    }

    rows = []
    for _, row in overlay.iterrows():
        name = _text(row.get("name"))
        asset_type = asset_type_lookup.get(name, "")
        is_cash = (
            asset_type == "cash"
            or name.lower() in {"cash", "현금"}
        )
        direct_currency = direct_currency_lookup.get(
            name,
            (_text(row.get("direct_currency")) or "KRW").upper(),
        )
        economic_currency = (
            _text(row.get("economic_currency"))
        ).upper()
        exposure_ratio = _num(
            row.get("economic_fx_exposure_ratio")
        )
        hedge_ratio = _num(
            row.get("economic_fx_hedge_ratio")
        )
        reviewed = _bool(row.get("reviewed"))
        source = _text(row.get("source"))

        value = values.get(name, 0.0)
        weight = (
            value / total
            if total > 0
            else 0.0
        )

        wrapper_review_target = bool(
            (direct_currency != "KRW")
            or (asset_type in wrapper_types)
        )
        issues = []

        if is_cash:
            scope = "CASH_POLICY_EXEMPT"
            exposure_ratio = 0.0
            economic_currency = (
                economic_currency
                or direct_currency
                or "KRW"
            )
            gross_fx_weight = 0.0
            known_unhedged_fx_weight = 0.0
            hidden_fx_weight = 0.0
            status = "PASS"

        elif not wrapper_review_target:
            scope = (
                "BUSINESS_FX_SEPARATE"
                if asset_type in single_name_types
                else "DIRECT_KRW_SECURITY_POLICY_EXEMPT"
            )
            # Asset / wrapper FX is zero by policy scope for a direct KRW
            # security. This says nothing about operating/business FX
            # sensitivity, which is reviewed separately.
            exposure_ratio = 0.0
            economic_currency = "KRW"
            gross_fx_weight = 0.0
            known_unhedged_fx_weight = 0.0
            hidden_fx_weight = 0.0
            status = "PASS"

        else:
            scope = "ASSET_OR_WRAPPER_FX_REVIEW"

            if exposure_ratio is None:
                issues.append(
                    "ECONOMIC_FX_EXPOSURE_REQUIRED"
                )
            elif exposure_ratio < 0 or exposure_ratio > 1:
                issues.append(
                    "ECONOMIC_FX_EXPOSURE_INVALID"
                )

            if exposure_ratio is not None and exposure_ratio > 0:
                if not economic_currency:
                    issues.append(
                        "ECONOMIC_CURRENCY_REQUIRED"
                    )
                elif economic_currency == "KRW":
                    issues.append(
                        "ECONOMIC_CURRENCY_CONFLICT"
                    )

                if hedge_ratio is None:
                    issues.append(
                        "ECONOMIC_FX_HEDGE_REQUIRED"
                    )
                elif hedge_ratio < 0 or hedge_ratio > 1:
                    issues.append(
                        "ECONOMIC_FX_HEDGE_INVALID"
                    )
            else:
                if hedge_ratio is not None and (
                    hedge_ratio < 0
                    or hedge_ratio > 1
                ):
                    issues.append(
                        "ECONOMIC_FX_HEDGE_INVALID"
                    )

            if reviewed:
                if not source:
                    issues.append(
                        "ECONOMIC_FX_SOURCE_REQUIRED"
                    )
            else:
                issues.append(
                    "ECONOMIC_FX_HUMAN_REVIEW_REQUIRED"
                )

            valid_exposure = (
                exposure_ratio
                if (
                    exposure_ratio is not None
                    and 0 <= exposure_ratio <= 1
                )
                else None
            )
            valid_hedge = (
                hedge_ratio
                if (
                    hedge_ratio is not None
                    and 0 <= hedge_ratio <= 1
                )
                else None
            )

            is_foreign_economic = bool(
                valid_exposure is not None
                and valid_exposure > 0
                and economic_currency
                and economic_currency != "KRW"
            )

            gross_fx_weight = (
                weight * valid_exposure
                if is_foreign_economic
                else 0.0
            )
            hidden_fx_weight = (
                gross_fx_weight
                if (
                    is_foreign_economic
                    and direct_currency == "KRW"
                )
                else 0.0
            )
            known_unhedged_fx_weight = (
                gross_fx_weight
                * (1.0 - valid_hedge)
                if (
                    is_foreign_economic
                    and valid_hedge is not None
                )
                else None
            )
            status = (
                "PASS"
                if not issues
                else "REVIEW"
            )

        rows.append(
            {
                "name": name,
                "ticker": _text(row.get("ticker")),
                "asset_type": asset_type,
                "scope": scope,
                "direct_currency": direct_currency,
                "economic_currency": economic_currency,
                "current_value_krw": value,
                "weight": weight,
                "economic_fx_exposure_ratio": exposure_ratio,
                "economic_fx_hedge_ratio": hedge_ratio,
                "gross_economic_fx_weight": gross_fx_weight,
                "hidden_fx_weight": hidden_fx_weight,
                "known_unhedged_economic_fx_weight": known_unhedged_fx_weight,
                "reviewed": reviewed,
                "source": source,
                "status": status,
                "issues": " | ".join(issues),
            }
        )

    return pd.DataFrame(rows)



def economic_fx_summary(
    status_table: pd.DataFrame | None,
    *,
    min_review_coverage: float = 0.80,
    unhedged_cap: float = 0.15,
) -> dict:
    if status_table is None or status_table.empty:
        return {
            "status": "REVIEW",
            "review_coverage": 0.0,
            "gross_economic_fx_weight": 0.0,
            "hidden_fx_weight": 0.0,
            "known_unhedged_economic_fx_weight": 0.0,
            "unknown_unhedged_weight": 0.0,
            "review_weight": 0.0,
            "issue_rows": 0,
            "reason": "ECONOMIC_FX_OVERLAY_EMPTY",
        }

    df = status_table.copy()
    weight = pd.to_numeric(
        df.get("weight"),
        errors="coerce",
    ).fillna(0.0)

    noncash_mask = ~(
        df.get("asset_type", "")
        .fillna("")
        .astype(str)
        .str.lower()
        .eq("cash")
    )
    noncash_weight = float(
        weight.loc[noncash_mask].sum()
    )

    pass_mask = (
        df.get("status", "")
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("PASS")
        & noncash_mask
    )
    pass_weight = float(
        weight.loc[pass_mask].sum()
    )
    review_weight = max(
        0.0,
        noncash_weight - pass_weight,
    )
    review_coverage = (
        pass_weight / noncash_weight
        if noncash_weight > 0
        else 1.0
    )

    gross = pd.to_numeric(
        df.get("gross_economic_fx_weight"),
        errors="coerce",
    ).fillna(0.0)
    hidden = pd.to_numeric(
        df.get("hidden_fx_weight"),
        errors="coerce",
    ).fillna(0.0)
    unhedged = pd.to_numeric(
        df.get(
            "known_unhedged_economic_fx_weight"
        ),
        errors="coerce",
    )

    gross_weight = float(gross.sum())
    hidden_weight = float(hidden.sum())
    known_unhedged = float(
        unhedged.fillna(0.0).sum()
    )

    unknown_unhedged_mask = (
        (gross > 0)
        & unhedged.isna()
    )
    unknown_unhedged_weight = float(
        gross.loc[unknown_unhedged_mask].sum()
    )

    issue_rows = int(
        (
            df.get("status", "")
            .fillna("")
            .astype(str)
            .str.upper()
            .ne("PASS")
            & noncash_mask
        ).sum()
    )

    if review_coverage < float(min_review_coverage):
        status = "REVIEW"
        reason = "ECONOMIC_FX_REVIEW_COVERAGE_LOW"
    elif unknown_unhedged_weight > 0:
        status = "REVIEW"
        reason = "ECONOMIC_FX_HEDGE_UNKNOWN"
    elif known_unhedged > float(unhedged_cap):
        status = "PRE_EXISTING_BREACH"
        reason = "ECONOMIC_UNHEDGED_FX_ABOVE_CAP"
    else:
        status = "PASS"
        reason = "ECONOMIC_FX_REVIEW_READY"

    return {
        "status": status,
        "review_coverage": review_coverage,
        "gross_economic_fx_weight": gross_weight,
        "hidden_fx_weight": hidden_weight,
        "known_unhedged_economic_fx_weight": known_unhedged,
        "unknown_unhedged_weight": unknown_unhedged_weight,
        "review_weight": review_weight,
        "issue_rows": issue_rows,
        "reason": reason,
    }


def economic_fx_overlay_save_rows(
    edited: pd.DataFrame,
) -> pd.DataFrame:
    out = normalize_economic_fx_overlays(edited)
    out["updated_at"] = datetime.now().isoformat()
    return out


BUSINESS_FX_OVERLAY_COLS = [
    "name",
    "ticker",
    "business_fx_currencies",
    "foreign_revenue_ratio",
    "foreign_cost_ratio",
    "krw_weakness_effect",
    "reviewed",
    "source",
    "review_due_date",
    "note",
    "updated_at",
]

_SINGLE_NAME_EQUITY_TYPES = {
    "equity",
    "stock",
    "common_stock",
    "preferred_stock",
    "common",
    "preferred",
}

_BUSINESS_FX_EFFECTS = {
    "KRW_WEAK_POSITIVE",
    "KRW_WEAK_NEGATIVE",
    "MIXED",
    "NEUTRAL",
}


def normalize_business_fx_overlays(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Stable dtypes for Streamlit DataEditor.

    Empty CSV text columns are often inferred by pandas as float because they
    contain only NaN. Streamlit TextColumn then raises a dtype mismatch.
    Normalize text/bool/numeric fields explicitly after every CSV load.
    """
    if df is None:
        df = pd.DataFrame()
    out = df.copy()
    for col in BUSINESS_FX_OVERLAY_COLS:
        if col not in out.columns:
            out[col] = ""

    text_cols = [
        "name",
        "ticker",
        "business_fx_currencies",
        "krw_weakness_effect",
        "source",
        "review_due_date",
        "note",
        "updated_at",
    ]
    for col in text_cols:
        out[col] = out[col].map(_text).astype("object")

    for col in [
        "foreign_revenue_ratio",
        "foreign_cost_ratio",
    ]:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )

    out["reviewed"] = out["reviewed"].map(_bool).astype(bool)

    return out[BUSINESS_FX_OVERLAY_COLS].copy()


def business_fx_editor_rows(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Business/operating FX sensitivity for single-name equities only.

    ETF/fund wrapper FX belongs in Asset / Wrapper Economic FX Overlay.
    """
    existing = normalize_business_fx_overlays(overlays)

    if portfolio is None or portfolio.empty:
        return existing

    rows = []
    for _, prow in portfolio.iterrows():
        name = _text(prow.get("name"))
        ticker = _text(prow.get("ticker"))
        asset_type = _text(prow.get("asset_type")).lower()

        if (
            not name
            or asset_type not in _SINGLE_NAME_EQUITY_TYPES
        ):
            continue

        hit = existing.loc[
            existing["name"]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(name)
        ].copy()
        if ticker and not hit.empty:
            ticker_hit = hit.loc[
                hit["ticker"]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(ticker)
            ]
            if not ticker_hit.empty:
                hit = ticker_hit

        if not hit.empty:
            row = hit.iloc[-1].to_dict()
            row["name"] = name
            row["ticker"] = ticker
        else:
            row = {
                "name": name,
                "ticker": ticker,
                "business_fx_currencies": "",
                "foreign_revenue_ratio": "",
                "foreign_cost_ratio": "",
                "krw_weakness_effect": "",
                "reviewed": False,
                "source": "",
                "review_due_date": "",
                "note": "",
                "updated_at": "",
            }
        rows.append(row)

    return normalize_business_fx_overlays(
        pd.DataFrame(rows)
    )


def business_fx_status_table(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
    total_assets: float,
) -> pd.DataFrame:
    editor = business_fx_editor_rows(
        portfolio,
        overlays,
    )
    if editor.empty:
        return pd.DataFrame()

    values = _asset_value_lookup(portfolio)
    total = max(0.0, float(total_assets or 0.0))

    rows = []
    for _, row in editor.iterrows():
        name = _text(row.get("name"))
        value = values.get(name, 0.0)
        weight = (
            value / total
            if total > 0
            else 0.0
        )

        currencies = _text(
            row.get("business_fx_currencies")
        ).upper()
        revenue_ratio = _num(
            row.get("foreign_revenue_ratio")
        )
        cost_ratio = _num(
            row.get("foreign_cost_ratio")
        )
        effect = _text(
            row.get("krw_weakness_effect")
        ).upper()
        reviewed = _bool(
            row.get("reviewed")
        )
        source = _text(
            row.get("source")
        )

        issues = []

        if effect not in _BUSINESS_FX_EFFECTS:
            issues.append(
                "BUSINESS_FX_EFFECT_REQUIRED"
            )

        if effect != "NEUTRAL" and not currencies:
            issues.append(
                "BUSINESS_FX_CURRENCIES_REQUIRED"
            )

        for label, ratio in [
            ("FOREIGN_REVENUE_RATIO", revenue_ratio),
            ("FOREIGN_COST_RATIO", cost_ratio),
        ]:
            if ratio is not None and (
                ratio < 0 or ratio > 1
            ):
                issues.append(
                    f"{label}_INVALID"
                )

        if reviewed:
            if not source:
                issues.append(
                    "BUSINESS_FX_SOURCE_REQUIRED"
                )
        else:
            issues.append(
                "BUSINESS_FX_HUMAN_REVIEW_REQUIRED"
            )

        quantified = bool(
            revenue_ratio is not None
            or cost_ratio is not None
        )
        status = (
            "PASS"
            if not issues
            else "REVIEW"
        )

        rows.append(
            {
                "name": name,
                "ticker": _text(row.get("ticker")),
                "weight": weight,
                "business_fx_currencies": currencies,
                "foreign_revenue_ratio": revenue_ratio,
                "foreign_cost_ratio": cost_ratio,
                "krw_weakness_effect": effect,
                "quantified": quantified,
                "reviewed": reviewed,
                "source": source,
                "status": status,
                "issues": " | ".join(issues),
            }
        )

    return pd.DataFrame(rows)


def business_fx_summary(
    status_table: pd.DataFrame | None,
    *,
    min_review_coverage: float = 0.80,
) -> dict:
    """
    Business FX is operational sensitivity, not a direct currency position.

    Therefore this summary reports review coverage and directional/quantified
    weights; it does not net or cap the exposure like a monetary FX position.
    """
    if status_table is None or status_table.empty:
        return {
            "status": "PASS",
            "eligible_equity_weight": 0.0,
            "review_coverage": 1.0,
            "review_weight": 0.0,
            "positive_weight": 0.0,
            "negative_weight": 0.0,
            "mixed_weight": 0.0,
            "neutral_weight": 0.0,
            "quantification_coverage": 1.0,
            "weighted_foreign_revenue_exposure": 0.0,
            "weighted_foreign_cost_exposure": 0.0,
            "issue_rows": 0,
            "reason": "NO_SINGLE_NAME_EQUITY",
        }

    df = status_table.copy()
    weight = pd.to_numeric(
        df.get("weight"),
        errors="coerce",
    ).fillna(0.0)

    eligible_weight = float(
        weight.sum()
    )
    pass_mask = (
        df.get("status", "")
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("PASS")
    )
    pass_weight = float(
        weight.loc[pass_mask].sum()
    )
    review_weight = max(
        0.0,
        eligible_weight - pass_weight,
    )
    review_coverage = (
        pass_weight / eligible_weight
        if eligible_weight > 0
        else 1.0
    )

    effect = (
        df.get("krw_weakness_effect", "")
        .fillna("")
        .astype(str)
        .str.upper()
    )

    def _effect_weight(label: str) -> float:
        return float(
            weight.loc[
                pass_mask & effect.eq(label)
            ].sum()
        )

    quantified_mask = (
        df.get("quantified", False)
        .fillna(False)
        .astype(bool)
        & pass_mask
    )
    quantified_weight = float(
        weight.loc[quantified_mask].sum()
    )
    quantification_coverage = (
        quantified_weight / eligible_weight
        if eligible_weight > 0
        else 1.0
    )

    revenue_ratio = pd.to_numeric(
        df.get("foreign_revenue_ratio"),
        errors="coerce",
    )
    cost_ratio = pd.to_numeric(
        df.get("foreign_cost_ratio"),
        errors="coerce",
    )

    weighted_revenue = float(
        (
            weight
            * revenue_ratio.fillna(0.0)
            * pass_mask.astype(float)
        ).sum()
    )
    weighted_cost = float(
        (
            weight
            * cost_ratio.fillna(0.0)
            * pass_mask.astype(float)
        ).sum()
    )

    issue_rows = int(
        (~pass_mask).sum()
    )

    status = (
        "PASS"
        if review_coverage >= float(
            min_review_coverage
        )
        else "REVIEW"
    )
    reason = (
        "BUSINESS_FX_REVIEW_READY"
        if status == "PASS"
        else "BUSINESS_FX_REVIEW_COVERAGE_LOW"
    )

    return {
        "status": status,
        "eligible_equity_weight": eligible_weight,
        "review_coverage": review_coverage,
        "review_weight": review_weight,
        "positive_weight": _effect_weight(
            "KRW_WEAK_POSITIVE"
        ),
        "negative_weight": _effect_weight(
            "KRW_WEAK_NEGATIVE"
        ),
        "mixed_weight": _effect_weight(
            "MIXED"
        ),
        "neutral_weight": _effect_weight(
            "NEUTRAL"
        ),
        "quantification_coverage": quantification_coverage,
        "weighted_foreign_revenue_exposure": weighted_revenue,
        "weighted_foreign_cost_exposure": weighted_cost,
        "issue_rows": issue_rows,
        "reason": reason,
    }


def business_fx_overlay_save_rows(
    edited: pd.DataFrame,
) -> pd.DataFrame:
    out = normalize_business_fx_overlays(
        edited
    )
    out["updated_at"] = datetime.now().isoformat()
    return out


BUSINESS_FX_EVIDENCE_COLS = [
    "name",
    "ticker",
    "period",
    "observed_currencies",
    "observed_effect",
    "observed_impact_krw",
    "source_title",
    "source_url_primary",
    "source_url_secondary",
    "reviewed",
    "note",
    "updated_at",
]

_BUSINESS_FX_OBSERVED_EFFECTS = {
    "KRW_WEAK_POSITIVE",
    "KRW_WEAK_NEGATIVE",
    "MIXED",
    "NEUTRAL",
    "UNDETERMINED",
}


def normalize_business_fx_evidence(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Stable dtypes for Evidence DataEditor and CSV round-trips.
    """
    if df is None:
        df = pd.DataFrame()
    out = df.copy()
    for col in BUSINESS_FX_EVIDENCE_COLS:
        if col not in out.columns:
            out[col] = ""

    text_cols = [
        "name",
        "ticker",
        "period",
        "observed_currencies",
        "observed_effect",
        "source_title",
        "source_url_primary",
        "source_url_secondary",
        "note",
        "updated_at",
    ]
    for col in text_cols:
        out[col] = out[col].map(_text).astype("object")

    out["observed_impact_krw"] = pd.to_numeric(
        out["observed_impact_krw"],
        errors="coerce",
    )
    out["reviewed"] = out["reviewed"].map(_bool).astype(bool)

    return out[BUSINESS_FX_EVIDENCE_COLS].copy()


def business_fx_evidence_editor_rows(
    portfolio: pd.DataFrame | None,
    evidence: pd.DataFrame | None,
) -> pd.DataFrame:
    existing = normalize_business_fx_evidence(evidence)

    if portfolio is None or portfolio.empty:
        return existing

    rows = []
    for _, prow in portfolio.iterrows():
        name = _text(prow.get("name"))
        ticker = _text(prow.get("ticker"))
        asset_type = _text(prow.get("asset_type")).lower()

        if (
            not name
            or asset_type not in _SINGLE_NAME_EQUITY_TYPES
        ):
            continue

        hit = existing.loc[
            existing["name"]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(name)
        ].copy()

        if ticker and not hit.empty:
            ticker_hit = hit.loc[
                hit["ticker"]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(ticker)
            ]
            if not ticker_hit.empty:
                hit = ticker_hit

        if not hit.empty:
            hit["_updated_sort"] = pd.to_datetime(
                hit["updated_at"],
                errors="coerce",
                utc=True,
            )
            hit = hit.sort_values(
                "_updated_sort",
                ascending=False,
                na_position="last",
            )
            row = hit.iloc[0].drop(
                labels=["_updated_sort"],
                errors="ignore",
            ).to_dict()
            row["name"] = name
            row["ticker"] = ticker
        else:
            row = {
                "name": name,
                "ticker": ticker,
                "period": "",
                "observed_currencies": "",
                "observed_effect": "",
                "observed_impact_krw": "",
                "source_title": "",
                "source_url_primary": "",
                "source_url_secondary": "",
                "reviewed": False,
                "note": "",
                "updated_at": "",
            }

        rows.append(row)

    return normalize_business_fx_evidence(
        pd.DataFrame(rows)
    )


def business_fx_evidence_status_table(
    evidence_editor: pd.DataFrame | None,
) -> pd.DataFrame:
    evidence = normalize_business_fx_evidence(
        evidence_editor
    )
    if evidence.empty:
        return pd.DataFrame()

    rows = []
    for _, row in evidence.iterrows():
        effect = _text(
            row.get("observed_effect")
        ).upper()
        currencies = _text(
            row.get("observed_currencies")
        )
        period = _text(
            row.get("period")
        )
        title = _text(
            row.get("source_title")
        )
        url1 = _text(
            row.get("source_url_primary")
        )
        url2 = _text(
            row.get("source_url_secondary")
        )
        reviewed = _bool(
            row.get("reviewed")
        )
        impact = _num(
            row.get("observed_impact_krw")
        )

        issues = []

        if not period:
            issues.append(
                "OBSERVED_PERIOD_REQUIRED"
            )
        if not currencies:
            issues.append(
                "OBSERVED_CURRENCIES_REQUIRED"
            )
        if effect not in _BUSINESS_FX_OBSERVED_EFFECTS:
            issues.append(
                "OBSERVED_EFFECT_REQUIRED"
            )
        if not title:
            issues.append(
                "SOURCE_TITLE_REQUIRED"
            )
        if not url1:
            issues.append(
                "PRIMARY_SOURCE_URL_REQUIRED"
            )
        if not reviewed:
            issues.append(
                "EVIDENCE_HUMAN_REVIEW_REQUIRED"
            )

        status = (
            "READY"
            if not issues
            else "REVIEW"
        )

        rows.append(
            {
                "name": _text(row.get("name")),
                "ticker": _text(row.get("ticker")),
                "period": period,
                "observed_currencies": currencies,
                "observed_effect": effect,
                "observed_impact_krw": impact,
                "source_title": title,
                "source_url_primary": url1,
                "source_url_secondary": url2,
                "reviewed": reviewed,
                "status": status,
                "issues": " | ".join(issues),
            }
        )

    return pd.DataFrame(rows)


def business_fx_evidence_summary(
    status_table: pd.DataFrame | None,
) -> dict:
    if status_table is None or status_table.empty:
        return {
            "ready": 0,
            "review": 0,
            "total": 0,
            "status": "REVIEW",
        }

    status = (
        status_table["status"]
        .fillna("")
        .astype(str)
        .str.upper()
    )
    ready = int(status.eq("READY").sum())
    review = int(status.ne("READY").sum())
    total = int(len(status_table))

    return {
        "ready": ready,
        "review": review,
        "total": total,
        "status": (
            "PASS"
            if total > 0 and ready == total
            else "REVIEW"
        ),
    }


def business_fx_evidence_save_rows(
    edited: pd.DataFrame,
) -> pd.DataFrame:
    out = normalize_business_fx_evidence(
        edited
    )
    out["updated_at"] = datetime.now().isoformat()
    return out


def apply_business_fx_evidence_to_overlay(
    overlay_df: pd.DataFrame | None,
    evidence_status_table: pd.DataFrame | None,
) -> tuple[pd.DataFrame, int]:
    """
    Copy only source-backed currencies + source into Business FX Overlay.

    Does NOT:
    - auto-copy recent observed_effect into long-run krw_weakness_effect
    - auto-check Reviewed
    - auto-fill foreign revenue/cost ratios
    """
    overlay = normalize_business_fx_overlays(
        overlay_df
    ).copy()

    if (
        evidence_status_table is None
        or evidence_status_table.empty
        or overlay.empty
    ):
        return overlay, 0

    applied = 0

    for _, ev in evidence_status_table.iterrows():
        if _text(ev.get("status")).upper() != "READY":
            continue

        name = _text(ev.get("name"))
        ticker = _text(ev.get("ticker"))

        mask = (
            overlay["name"]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(name)
        )

        if ticker:
            ticker_mask = (
                overlay["ticker"]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(ticker)
            )
            if (mask & ticker_mask).any():
                mask = mask & ticker_mask

        if not mask.any():
            continue

        currencies = _text(
            ev.get("observed_currencies")
        )
        title = _text(
            ev.get("source_title")
        )
        url1 = _text(
            ev.get("source_url_primary")
        )
        url2 = _text(
            ev.get("source_url_secondary")
        )

        source_parts = [
            x
            for x in [
                title,
                url1,
                url2,
            ]
            if x
        ]

        overlay.loc[
            mask,
            "business_fx_currencies",
        ] = currencies

        overlay.loc[
            mask,
            "source",
        ] = " | ".join(source_parts)

        overlay.loc[
            mask,
            "reviewed",
        ] = False

        observed_impact = _num(
            ev.get("observed_impact_krw")
        )

        note_parts = [
            "RECENT_OBSERVED_EFFECT="
            + _text(
                ev.get("observed_effect")
            ),
            "PERIOD="
            + _text(
                ev.get("period")
            ),
            "RECENT_OBSERVATION_NOT_LONG_RUN_EFFECT",
        ]

        if observed_impact is not None:
            note_parts.append(
                "IMPACT_KRW="
                + str(observed_impact)
            )

        overlay.loc[
            mask,
            "note",
        ] = "; ".join(note_parts)

        applied += int(mask.sum())

    return normalize_business_fx_overlays(
        overlay
    ), applied


def upsert_business_fx_evidence(
    existing: pd.DataFrame | None,
    edited_rows: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Preserve multi-period Business FX evidence history.

    Natural key = name + ticker + period.
    Same period => update; new period => append.
    """
    base = normalize_business_fx_evidence(existing)
    edited = normalize_business_fx_evidence(edited_rows)

    if edited.empty:
        return base

    out = base.copy()

    for _, row in edited.iterrows():
        name = _text(row.get("name"))
        ticker = _text(row.get("ticker"))
        period = _text(row.get("period"))

        mask = (
            out["name"].map(_text).eq(name)
            & out["ticker"].map(_text).eq(ticker)
            & out["period"].map(_text).eq(period)
        )
        if mask.any():
            out = out.loc[~mask].copy()

        row_df = normalize_business_fx_evidence(
            pd.DataFrame([row.to_dict()])
        )
        out = pd.concat(
            [out, row_df],
            ignore_index=True,
        )

    return normalize_business_fx_evidence(out)


def business_fx_evidence_history_table(
    evidence: pd.DataFrame | None,
    company: str = "",
) -> pd.DataFrame:
    """
    Full saved history with READY / REVIEW status.
    """
    history = normalize_business_fx_evidence(evidence)

    if company:
        company_key = _text(company)
        history = history.loc[
            history["name"].map(_text).eq(company_key)
        ].copy()

    if history.empty:
        return pd.DataFrame()

    status = business_fx_evidence_status_table(history)
    status["updated_at"] = history["updated_at"].values
    status["_updated_sort"] = pd.to_datetime(
        status["updated_at"],
        errors="coerce",
        utc=True,
    )

    return (
        status.sort_values(
            "_updated_sort",
            ascending=False,
            na_position="last",
        )
        .drop(columns=["_updated_sort"])
        .reset_index(drop=True)
    )




def _business_fx_period_window(period: str) -> tuple[int, int, int] | None:
    """
    Parse common annual/interim labels into non-overlapping month windows.

    Supported examples:
    - 2026 Q1 / Q2 / Q3 / Q4
    - 2026 H1 / H2
    - 2026 FY
    """
    text = _text(period).upper().replace("-", " ")
    parts = [x for x in text.split() if x]
    if len(parts) < 2:
        return None

    try:
        year = int(float(parts[0]))
    except Exception:
        return None

    label = parts[1]
    windows = {
        "Q1": (1, 3),
        "Q2": (4, 6),
        "Q3": (7, 9),
        "Q4": (10, 12),
        "H1": (1, 6),
        "H2": (7, 12),
        "FY": (1, 12),
        "ANNUAL": (1, 12),
        "FULL_YEAR": (1, 12),
        "YEAR": (1, 12),
    }
    if label not in windows:
        return None

    start_month, end_month = windows[label]
    return year, start_month, end_month


def business_fx_period_overlap_report(
    evidence_status_history: pd.DataFrame | None,
) -> dict:
    """
    Detect overlapping READY observation periods.

    Q1 + H1, Q2 + H1, or any quarter + FY are overlapping evidence
    and must not be treated as two independent long-run observations.
    """
    if evidence_status_history is None or evidence_status_history.empty:
        return {
            "overlap_count": 0,
            "overlap_pairs": [],
            "unparsed_periods": [],
        }

    df = evidence_status_history.copy()
    if "status" in df.columns:
        df = df.loc[
            df["status"]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq("READY")
        ].copy()

    parsed = []
    unparsed = []

    for _, row in df.iterrows():
        period = _text(row.get("period"))
        window = _business_fx_period_window(period)
        if window is None:
            if period:
                unparsed.append(period)
            continue
        parsed.append(
            {
                "period": period,
                "year": window[0],
                "start": window[1],
                "end": window[2],
            }
        )

    pairs = []
    for i in range(len(parsed)):
        for j in range(i + 1, len(parsed)):
            a = parsed[i]
            b = parsed[j]
            if a["year"] != b["year"]:
                continue
            overlap = max(a["start"], b["start"]) <= min(a["end"], b["end"])
            if overlap:
                pairs.append(
                    f"{a['period']} ↔ {b['period']}"
                )

    return {
        "overlap_count": len(pairs),
        "overlap_pairs": pairs,
        "unparsed_periods": sorted(set(unparsed)),
    }

def business_fx_multiperiod_summary(
    evidence_status_history: pd.DataFrame | None,
    *,
    min_ready_periods: int = 2,
) -> dict:
    """
    Descriptive multi-period FX evidence pattern.

    The candidate is only an input assist for later human review.
    It is not an automatic long-run conclusion.
    """
    if evidence_status_history is None or evidence_status_history.empty:
        return {
            "status": "REVIEW",
            "reason": "NO_BUSINESS_FX_EVIDENCE_HISTORY",
            "ready_periods": 0,
            "review_periods": 0,
            "positive_periods": 0,
            "negative_periods": 0,
            "mixed_periods": 0,
            "neutral_periods": 0,
            "undetermined_periods": 0,
            "candidate": "",
            "pattern": "NO_HISTORY",
            "overlap_count": 0,
            "overlap_pairs": [],
            "unparsed_periods": [],
            "source_integrity_status": "PASS",
            "source_integrity_issue_count": 0,
            "duplicate_primary_pairs": [],
            "duplicate_fingerprint_pairs": [],
            "period_title_mismatches": [],
            "impact_rows": 0,
            "known_abs_impact_krw": 0.0,
        }

    df = evidence_status_history.copy()
    status = (
        df["status"]
        .fillna("")
        .astype(str)
        .str.upper()
    )
    ready_df = df.loc[
        status.eq("READY")
    ].copy()

    ready_count = int(len(ready_df))
    review_count = int(
        len(df) - ready_count
    )

    effect = (
        ready_df.get(
            "observed_effect",
            pd.Series(dtype=object),
        )
        .fillna("")
        .astype(str)
        .str.upper()
    )

    counts = {
        "KRW_WEAK_POSITIVE": int(
            effect.eq("KRW_WEAK_POSITIVE").sum()
        ),
        "KRW_WEAK_NEGATIVE": int(
            effect.eq("KRW_WEAK_NEGATIVE").sum()
        ),
        "MIXED": int(
            effect.eq("MIXED").sum()
        ),
        "NEUTRAL": int(
            effect.eq("NEUTRAL").sum()
        ),
        "UNDETERMINED": int(
            effect.eq("UNDETERMINED").sum()
        ),
    }

    overlap_state = business_fx_period_overlap_report(
        ready_df
    )
    source_integrity = business_fx_source_integrity_report(
        ready_df
    )

    candidate = ""
    pattern = "INSUFFICIENT_HISTORY"

    determinate_effects = [
        x
        for x in effect.tolist()
        if x and x != "UNDETERMINED"
    ]
    unique_effects = sorted(
        set(determinate_effects)
    )

    if ready_count >= int(min_ready_periods):
        if source_integrity["status"] != "PASS":
            pattern = "SOURCE_INTEGRITY_REVIEW"
        elif overlap_state["overlap_count"] > 0:
            pattern = "OVERLAPPING_PERIODS"
        elif counts["UNDETERMINED"] > 0:
            pattern = "UNDETERMINED_PRESENT"
        elif not unique_effects:
            pattern = "NO_DETERMINATE_EFFECT"
        elif len(unique_effects) == 1:
            candidate = unique_effects[0]
            pattern = "CONSISTENT_" + unique_effects[0]
        else:
            candidate = "MIXED"
            pattern = "MIXED_DIRECTION"

    impact = pd.to_numeric(
        ready_df.get(
            "observed_impact_krw",
            pd.Series(dtype=float),
        ),
        errors="coerce",
    )
    impact_rows = int(
        impact.notna().sum()
    )
    known_abs_impact = float(
        impact.abs().fillna(0.0).sum()
    )

    if ready_count < int(min_ready_periods):
        gate = "REVIEW"
        reason = "INSUFFICIENT_READY_PERIODS"
    elif source_integrity["status"] != "PASS":
        gate = "REVIEW"
        reason = "BUSINESS_FX_SOURCE_INTEGRITY_REVIEW"
    elif overlap_state["overlap_count"] > 0:
        gate = "REVIEW"
        reason = "OVERLAPPING_READY_PERIODS"
    elif counts["UNDETERMINED"] > 0:
        gate = "REVIEW"
        reason = "UNDETERMINED_EFFECT_PRESENT"
    elif not candidate:
        gate = "REVIEW"
        reason = "LONG_RUN_PATTERN_UNRESOLVED"
    else:
        gate = "PASS"
        reason = "MULTIPERIOD_EVIDENCE_READY_FOR_HUMAN_LONG_RUN_REVIEW"

    return {
        "status": gate,
        "reason": reason,
        "ready_periods": ready_count,
        "review_periods": review_count,
        "positive_periods": counts["KRW_WEAK_POSITIVE"],
        "negative_periods": counts["KRW_WEAK_NEGATIVE"],
        "mixed_periods": counts["MIXED"],
        "neutral_periods": counts["NEUTRAL"],
        "undetermined_periods": counts["UNDETERMINED"],
        "candidate": candidate,
        "pattern": pattern,
        "overlap_count": overlap_state["overlap_count"],
        "overlap_pairs": overlap_state["overlap_pairs"],
        "unparsed_periods": overlap_state["unparsed_periods"],
        "source_integrity_status": source_integrity["status"],
        "source_integrity_issue_count": source_integrity["issue_count"],
        "duplicate_primary_pairs": source_integrity["duplicate_primary_pairs"],
        "duplicate_fingerprint_pairs": source_integrity["duplicate_fingerprint_pairs"],
        "period_title_mismatches": source_integrity["period_title_mismatches"],
        "impact_rows": impact_rows,
        "known_abs_impact_krw": known_abs_impact,
    }


def apply_business_fx_long_run_candidate(
    overlay_df: pd.DataFrame | None,
    company: str,
    candidate: str,
    *,
    evidence_pattern: str = "",
    ready_periods: int = 0,
) -> tuple[pd.DataFrame, int]:
    """
    Copy a multi-period candidate into the long-run overlay as input assist.

    Never auto-check Reviewed and never auto-fill revenue/cost ratios.
    """
    candidate_key = _text(candidate).upper()

    if candidate_key not in _BUSINESS_FX_EFFECTS:
        return normalize_business_fx_overlays(
            overlay_df
        ), 0

    overlay = normalize_business_fx_overlays(
        overlay_df
    ).copy()
    company_key = _text(company)

    mask = (
        overlay["name"]
        .map(_text)
        .eq(company_key)
    )
    if not mask.any():
        return overlay, 0

    overlay.loc[
        mask,
        "krw_weakness_effect",
    ] = candidate_key
    overlay.loc[
        mask,
        "reviewed",
    ] = False

    note_prefix = (
        "MULTIPERIOD_CANDIDATE="
        + candidate_key
        + "; PATTERN="
        + _text(evidence_pattern)
        + "; READY_PERIODS="
        + str(int(ready_periods))
        + "; HUMAN_LONG_RUN_REVIEW_REQUIRED"
    )

    existing_note = (
        overlay.loc[
            mask,
            "note",
        ]
        .map(_text)
    )
    overlay.loc[
        mask,
        "note",
    ] = existing_note.map(
        lambda x: (
            x + "; " + note_prefix
            if x
            else note_prefix
        )
    )

    return normalize_business_fx_overlays(
        overlay
    ), int(mask.sum())


def _business_fx_period_token(period: str) -> str:
    text = _text(period).upper().replace("-", " ")
    parts = [x for x in text.split() if x]
    if len(parts) < 2:
        return ""
    label = parts[1]
    aliases = {
        "Q1": "Q1",
        "Q2": "Q2",
        "Q3": "Q3",
        "Q4": "Q4",
        "H1": "H1",
        "H2": "H2",
        "FY": "FY",
        "ANNUAL": "FY",
        "FULL_YEAR": "FY",
        "YEAR": "FY",
    }
    return aliases.get(label, "")


def _title_period_mentions(title: str) -> set[str]:
    """
    Detect only explicit period mentions. Absence of a mention is not an error.
    """
    t = _text(title).upper()
    found = set()

    patterns = {
        "Q1": ["Q1", "1분기", "1Q"],
        "Q2": ["Q2", "2분기", "2Q"],
        "Q3": ["Q3", "3분기", "3Q"],
        "Q4": ["Q4", "4분기", "4Q"],
        "H1": ["H1", "반기", "상반기", "HALF YEAR", "HALF-YEAR"],
        "H2": ["H2", "하반기"],
        "FY": ["FY", "연간", "FULL YEAR", "FULL-YEAR"],
    }
    for key, tokens in patterns.items():
        if any(token.upper() in t for token in tokens):
            found.add(key)
    return found


def business_fx_source_integrity_report(
    evidence_status_history: pd.DataFrame | None,
) -> dict:
    """
    Cross-period source integrity guard.

    Flags:
    - same primary source URL used for different periods
    - exact same title/effect/impact fingerprint across different periods
    - source title explicitly names a different period than the evidence row

    The guard is conservative: it does not require a title to contain a period,
    but if it does, the period must be compatible with the row.
    """
    if evidence_status_history is None or evidence_status_history.empty:
        return {
            "status": "PASS",
            "duplicate_primary_pairs": [],
            "duplicate_fingerprint_pairs": [],
            "period_title_mismatches": [],
            "issue_count": 0,
        }

    df = evidence_status_history.copy()
    if "status" in df.columns:
        df = df.loc[
            df["status"]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq("READY")
        ].copy()

    if df.empty:
        return {
            "status": "PASS",
            "duplicate_primary_pairs": [],
            "duplicate_fingerprint_pairs": [],
            "period_title_mismatches": [],
            "issue_count": 0,
        }

    duplicate_primary_pairs = []
    duplicate_fingerprint_pairs = []
    period_title_mismatches = []

    rows = [row.to_dict() for _, row in df.iterrows()]

    for row in rows:
        period = _text(row.get("period"))
        source_title = _text(row.get("source_title"))
        token = _business_fx_period_token(period)
        mentions = _title_period_mentions(source_title)

        if token and mentions and token not in mentions:
            period_title_mismatches.append(
                f"{period} ↔ {source_title}"
            )

    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            a = rows[i]
            b = rows[j]
            pa = _text(a.get("period"))
            pb = _text(b.get("period"))
            if not pa or not pb or pa == pb:
                continue

            url_a = _text(a.get("source_url_primary"))
            url_b = _text(b.get("source_url_primary"))
            if url_a and url_b and url_a == url_b:
                duplicate_primary_pairs.append(
                    f"{pa} ↔ {pb}"
                )

            title_a = _text(a.get("source_title"))
            title_b = _text(b.get("source_title"))
            effect_a = _text(a.get("observed_effect")).upper()
            effect_b = _text(b.get("observed_effect")).upper()
            impact_a = _num(a.get("observed_impact_krw"))
            impact_b = _num(b.get("observed_impact_krw"))

            same_impact = (
                impact_a is not None
                and impact_b is not None
                and abs(impact_a - impact_b) <= 1.0
            )
            if (
                title_a
                and title_a == title_b
                and effect_a
                and effect_a == effect_b
                and same_impact
            ):
                duplicate_fingerprint_pairs.append(
                    f"{pa} ↔ {pb}"
                )

    issue_count = (
        len(duplicate_primary_pairs)
        + len(duplicate_fingerprint_pairs)
        + len(period_title_mismatches)
    )

    return {
        "status": "PASS" if issue_count == 0 else "REVIEW",
        "duplicate_primary_pairs": sorted(set(duplicate_primary_pairs)),
        "duplicate_fingerprint_pairs": sorted(set(duplicate_fingerprint_pairs)),
        "period_title_mismatches": sorted(set(period_title_mismatches)),
        "issue_count": issue_count,
    }


LIQUIDITY_OVERLAY_COLS = [
    "name",
    "ticker",
    "liquidity_days_to_exit",
    "reviewed",
    "source",
    "review_due_date",
    "note",
    "updated_at",
]


def normalize_liquidity_overlays(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Liquidity-only operational overlay.

    FX fields are intentionally excluded because FX is governed separately by:
    - Asset / Wrapper Economic FX Overlay
    - Business FX Sensitivity Overlay
    """
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in LIQUIDITY_OVERLAY_COLS:
        if col not in out.columns:
            out[col] = ""

    for col in [
        "name",
        "ticker",
        "source",
        "review_due_date",
        "note",
        "updated_at",
    ]:
        out[col] = out[col].map(_text).astype("object")

    out["liquidity_days_to_exit"] = pd.to_numeric(
        out["liquidity_days_to_exit"],
        errors="coerce",
    )
    out["reviewed"] = out["reviewed"].map(_bool).astype(bool)

    return out[LIQUIDITY_OVERLAY_COLS].copy()


def liquidity_overlay_editor_rows(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
    *,
    legacy_overlays: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """
    One liquidity row per current portfolio asset.

    When the new liquidity overlay is empty, any prior liquidity fields from
    asset_risk_overlays.csv are migrated as suggestions so earlier work is not
    lost. FX fields are ignored.
    """
    current = normalize_liquidity_overlays(overlays)

    legacy = (
        normalize_risk_overlays(legacy_overlays)
        if legacy_overlays is not None
        else pd.DataFrame()
    )

    if portfolio is None or portfolio.empty:
        return current

    rows = []
    for _, prow in portfolio.iterrows():
        name = _text(prow.get("name"))
        ticker = _text(prow.get("ticker"))

        if not name:
            continue

        hit = current.loc[
            current["name"].map(_text).eq(name)
        ].copy()
        if ticker and not hit.empty:
            ticker_hit = hit.loc[
                hit["ticker"].map(_text).eq(ticker)
            ]
            if not ticker_hit.empty:
                hit = ticker_hit

        if not hit.empty:
            row = hit.iloc[-1].to_dict()
            row["name"] = name
            row["ticker"] = ticker
        else:
            row = {
                "name": name,
                "ticker": ticker,
                "liquidity_days_to_exit": None,
                "reviewed": False,
                "source": "",
                "review_due_date": "",
                "note": "",
                "updated_at": "",
            }

            if legacy is not None and not legacy.empty:
                legacy_hit = legacy.loc[
                    legacy["name"].map(_text).eq(name)
                ].copy()
                if ticker and not legacy_hit.empty:
                    ticker_hit = legacy_hit.loc[
                        legacy_hit["ticker"].map(_text).eq(ticker)
                    ]
                    if not ticker_hit.empty:
                        legacy_hit = ticker_hit

                if not legacy_hit.empty:
                    old = legacy_hit.iloc[-1].to_dict()
                    row["liquidity_days_to_exit"] = _num(
                        old.get("liquidity_days_to_exit")
                    )
                    row["reviewed"] = _bool(old.get("reviewed"))
                    row["source"] = _text(old.get("source"))
                    row["review_due_date"] = _text(
                        old.get("review_due_date")
                    )
                    row["note"] = (
                        (
                            _text(old.get("note")) + "; "
                            if _text(old.get("note"))
                            else ""
                        )
                        + "MIGRATED_FROM_ASSET_RISK_OVERLAY"
                    )
        rows.append(row)

    return normalize_liquidity_overlays(
        pd.DataFrame(rows)
    )


def liquidity_status_table(
    portfolio: pd.DataFrame | None,
    overlays: pd.DataFrame | None,
    total_assets: float,
    *,
    liquidity_days_limit: float = 5.0,
) -> pd.DataFrame:
    editor = liquidity_overlay_editor_rows(
        portfolio,
        overlays,
    )
    if editor.empty:
        return pd.DataFrame()

    values = _asset_value_lookup(portfolio)
    total = max(0.0, float(total_assets or 0.0))

    asset_type_lookup = {}
    if portfolio is not None and not portfolio.empty:
        for _, row in portfolio.iterrows():
            name = _text(row.get("name"))
            if name:
                asset_type_lookup[name] = _text(
                    row.get("asset_type")
                ).lower()

    rows = []
    for _, row in editor.iterrows():
        name = _text(row.get("name"))
        asset_type = asset_type_lookup.get(name, "")
        is_cash = (
            asset_type == "cash"
            or name.lower() in {"cash", "현금"}
        )
        value = values.get(name, 0.0)
        weight = (
            value / total
            if total > 0
            else 0.0
        )

        days = _num(
            row.get("liquidity_days_to_exit")
        )
        reviewed = _bool(row.get("reviewed"))
        source = _text(row.get("source"))

        issues = []

        if is_cash:
            liquidity_status = "PASS"
            status = "PASS"
            days = 0.0
        else:
            if days is None:
                issues.append("LIQUIDITY_DAYS_REQUIRED")
                liquidity_status = "REVIEW"
            elif days < 0:
                issues.append("LIQUIDITY_DAYS_INVALID")
                liquidity_status = "REVIEW"
            elif days > float(liquidity_days_limit):
                issues.append("LIQUIDITY_LIMIT_EXCEEDED")
                liquidity_status = "TIGHT"
            else:
                liquidity_status = "PASS"

            if reviewed:
                if not source:
                    issues.append("LIQUIDITY_SOURCE_REQUIRED")
            else:
                issues.append("LIQUIDITY_HUMAN_REVIEW_REQUIRED")

            # Data readiness and operational liquidity risk are separate.
            # A reviewed position can be data-ready yet still be TIGHT.
            data_issues = [
                issue
                for issue in issues
                if issue != "LIQUIDITY_LIMIT_EXCEEDED"
            ]
            status = (
                "PASS"
                if not data_issues
                else "REVIEW"
            )

        rows.append(
            {
                "name": name,
                "ticker": _text(row.get("ticker")),
                "asset_type": asset_type,
                "current_value_krw": value,
                "weight": weight,
                "liquidity_days_to_exit": days,
                "liquidity_status": liquidity_status,
                "reviewed": reviewed,
                "source": source,
                "review_due_date": _text(
                    row.get("review_due_date")
                ),
                "status": status,
                "issues": " | ".join(issues),
            }
        )

    return pd.DataFrame(rows)


def liquidity_overlay_summary(
    status_table: pd.DataFrame | None,
    *,
    min_review_coverage: float = 0.80,
) -> dict:
    """
    Separate data readiness from operational liquidity risk.
    """
    if status_table is None or status_table.empty:
        return {
            "data_gate": "REVIEW",
            "risk_state": "REVIEW",
            "review_coverage": 0.0,
            "noncash_weight": 0.0,
            "pass_weight": 0.0,
            "review_weight": 0.0,
            "tight_liquidity_weight": 0.0,
            "max_days_to_exit": None,
            "issue_rows": 0,
            "reason": "LIQUIDITY_OVERLAY_EMPTY",
        }

    df = status_table.copy()
    weight = pd.to_numeric(
        df.get("weight"),
        errors="coerce",
    ).fillna(0.0)

    noncash_mask = ~(
        df.get("asset_type", "")
        .fillna("")
        .astype(str)
        .str.lower()
        .eq("cash")
    )
    noncash_weight = float(
        weight.loc[noncash_mask].sum()
    )

    pass_mask = (
        df.get("status", "")
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("PASS")
        & noncash_mask
    )
    pass_weight = float(
        weight.loc[pass_mask].sum()
    )
    review_weight = max(
        0.0,
        noncash_weight - pass_weight,
    )
    coverage = (
        pass_weight / noncash_weight
        if noncash_weight > 0
        else 1.0
    )

    tight_mask = (
        df.get("liquidity_status", "")
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("TIGHT")
        & noncash_mask
    )
    tight_weight = float(
        weight.loc[tight_mask].sum()
    )

    days = pd.to_numeric(
        df.get("liquidity_days_to_exit"),
        errors="coerce",
    )
    max_days = (
        float(days.loc[noncash_mask].max())
        if days.loc[noncash_mask].notna().any()
        else None
    )

    issue_rows = int(
        (
            df.get("status", "")
            .fillna("")
            .astype(str)
            .str.upper()
            .ne("PASS")
            & noncash_mask
        ).sum()
    )

    data_gate = (
        "PASS"
        if coverage >= float(min_review_coverage)
        else "REVIEW"
    )

    if data_gate != "PASS":
        reason = "LIQUIDITY_REVIEW_COVERAGE_LOW"
        risk_state = "REVIEW"
    elif tight_weight > 0:
        reason = "LIQUIDITY_TIGHT_POSITION_PRESENT"
        risk_state = "TIGHT"
    else:
        reason = "LIQUIDITY_REVIEW_READY"
        risk_state = "PASS"

    return {
        "data_gate": data_gate,
        "risk_state": risk_state,
        "review_coverage": coverage,
        "noncash_weight": noncash_weight,
        "pass_weight": pass_weight,
        "review_weight": review_weight,
        "tight_liquidity_weight": tight_weight,
        "max_days_to_exit": max_days,
        "issue_rows": issue_rows,
        "reason": reason,
    }


def liquidity_overlay_save_rows(
    edited: pd.DataFrame,
) -> pd.DataFrame:
    out = normalize_liquidity_overlays(edited)
    out["updated_at"] = datetime.now().isoformat()
    return out


HISTORICAL_CORRELATION_COLS = [
    "period",
    "as_of",
    "sample_start",
    "sample_end",
    "observation_count",
    "source",
    "ticker_a",
    "ticker_b",
    "correlation",
]


def normalize_historical_correlation_records(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in HISTORICAL_CORRELATION_COLS:
        if col not in out.columns:
            out[col] = ""

    for col in [
        "period",
        "as_of",
        "sample_start",
        "sample_end",
        "source",
        "ticker_a",
        "ticker_b",
    ]:
        out[col] = out[col].map(_text).astype("object")

    out["observation_count"] = pd.to_numeric(
        out["observation_count"],
        errors="coerce",
    )
    out["correlation"] = pd.to_numeric(
        out["correlation"],
        errors="coerce",
    )

    return out[HISTORICAL_CORRELATION_COLS].copy()


def historical_correlation_records_from_matrix(
    corr: pd.DataFrame,
    prices: pd.DataFrame | None,
    *,
    period: str,
    source: str = "connectors.market.multi_price_matrix",
    as_of: str = "",
) -> pd.DataFrame:
    """
    Persist a square correlation matrix with source/sample metadata.
    """
    if corr is None or corr.empty:
        return normalize_historical_correlation_records(
            pd.DataFrame()
        )

    matrix = corr.copy()
    matrix.index = matrix.index.map(str)
    matrix.columns = matrix.columns.map(str)

    numeric_prices = (
        prices.apply(
            pd.to_numeric,
            errors="coerce",
        )
        if prices is not None
        and not prices.empty
        else pd.DataFrame()
    )

    sample_start = ""
    sample_end = ""
    observation_count = 0

    if not numeric_prices.empty:
        idx = pd.to_datetime(
            numeric_prices.index,
            errors="coerce",
        )
        valid_idx = idx[
            ~pd.isna(idx)
        ]
        if len(valid_idx) > 0:
            sample_start = pd.Timestamp(
                valid_idx.min()
            ).date().isoformat()
            sample_end = pd.Timestamp(
                valid_idx.max()
            ).date().isoformat()

        returns = numeric_prices.pct_change(
            fill_method=None
        )
        observation_count = int(
            returns.dropna(
                how="all"
            ).shape[0]
        )

    stamp = (
        _text(as_of)
        or datetime.now().isoformat()
    )

    rows = []
    for a in matrix.index:
        for b in matrix.columns:
            value = _num(
                matrix.loc[a, b]
            )
            rows.append(
                {
                    "period": _text(period),
                    "as_of": stamp,
                    "sample_start": sample_start,
                    "sample_end": sample_end,
                    "observation_count": observation_count,
                    "source": _text(source),
                    "ticker_a": str(a),
                    "ticker_b": str(b),
                    "correlation": value,
                }
            )

    return normalize_historical_correlation_records(
        pd.DataFrame(rows)
    )


def _complete_correlation_submatrix(
    matrix: pd.DataFrame,
) -> pd.DataFrame:
    """
    Conservatively remove tickers causing missing pairwise correlations.

    This avoids silently treating missing correlation as zero.
    """
    if matrix is None or matrix.empty:
        return pd.DataFrame()

    m = matrix.copy()
    common = sorted(
        set(m.index.astype(str))
        & set(m.columns.astype(str))
    )
    m = m.reindex(
        index=common,
        columns=common,
    )

    while len(m) >= 2 and m.isna().any().any():
        missing = (
            m.isna().sum(axis=0)
            + m.isna().sum(axis=1)
        )
        worst = sorted(
            missing[
                missing == missing.max()
            ].index.astype(str)
        )[0]
        m = m.drop(
            index=worst,
            columns=worst,
        )

    if len(m) < 2:
        return pd.DataFrame()

    return m


def historical_correlation_matrix_from_records(
    records: pd.DataFrame | None,
) -> pd.DataFrame:
    data = normalize_historical_correlation_records(
        records
    )
    if data.empty:
        return pd.DataFrame()

    # One saved snapshot is expected, but use the latest build if the file
    # ever contains multiple builds.
    stamps = pd.to_datetime(
        data["as_of"],
        errors="coerce",
        utc=True,
    )
    if stamps.notna().any():
        latest = stamps.max()
        data = data.loc[
            stamps.eq(latest)
        ].copy()

    if data.empty:
        return pd.DataFrame()

    matrix = data.pivot_table(
        index="ticker_a",
        columns="ticker_b",
        values="correlation",
        aggfunc="last",
    )
    matrix.index = matrix.index.map(str)
    matrix.columns = matrix.columns.map(str)

    return _complete_correlation_submatrix(
        matrix
    )


def historical_correlation_source_health(
    records: pd.DataFrame | None,
    portfolio: pd.DataFrame | None,
    *,
    min_weight_coverage: float = 0.60,
    min_observations: int = 60,
    max_data_age_days: int = 10,
) -> dict:
    data = normalize_historical_correlation_records(
        records
    )
    matrix = historical_correlation_matrix_from_records(
        data
    )

    if data.empty:
        return {
            "status": "REVIEW",
            "reason": "CORRELATION_SOURCE_MISSING",
            "period": "",
            "as_of": "",
            "sample_start": "",
            "sample_end": "",
            "observation_count": 0,
            "ticker_count": 0,
            "matrix_valid": False,
            "covered_weight": 0.0,
            "covered_tickers": [],
            "missing_tickers": [],
            "data_age_days": None,
        }

    stamps = pd.to_datetime(
        data["as_of"],
        errors="coerce",
        utc=True,
    )
    if stamps.notna().any():
        latest = stamps.max()
        current = data.loc[
            stamps.eq(latest)
        ].copy()
    else:
        current = data.copy()

    first = current.iloc[0].to_dict()
    period = _text(first.get("period"))
    as_of = _text(first.get("as_of"))
    sample_start = _text(
        first.get("sample_start")
    )
    sample_end = _text(
        first.get("sample_end")
    )
    observation_count = int(
        pd.to_numeric(
            current["observation_count"],
            errors="coerce",
        )
        .fillna(0)
        .max()
    )

    matrix_valid = bool(
        not matrix.empty
        and len(matrix) >= 2
    )
    if matrix_valid:
        values = matrix.apply(
            pd.to_numeric,
            errors="coerce",
        )
        matrix_valid = bool(
            not values.isna().any().any()
            and ((values >= -1.000001) & (values <= 1.000001)).all().all()
            and (values - values.T).abs().max().max() <= 1e-6
        )

    covered_weight = 0.0
    covered_tickers = []
    missing_tickers = []

    if portfolio is not None and not portfolio.empty:
        p = portfolio.copy()
        if "ticker" not in p.columns:
            p["ticker"] = ""
        if "asset_type" not in p.columns:
            p["asset_type"] = ""
        if "current_value_krw" not in p.columns:
            p["current_value_krw"] = 0.0

        p["ticker"] = (
            p["ticker"]
            .fillna("")
            .astype(str)
            .str.strip()
        )
        p["asset_type"] = (
            p["asset_type"]
            .fillna("")
            .astype(str)
            .str.lower()
        )
        p["value"] = pd.to_numeric(
            p["current_value_krw"],
            errors="coerce",
        ).fillna(0.0)

        investable = p.loc[
            ~p["asset_type"].eq("cash")
        ].copy()
        investable_value = float(
            investable["value"].clip(
                lower=0.0
            ).sum()
        )

        matrix_tickers = set(
            matrix.index.astype(str)
        )

        for ticker, group in investable.groupby(
            "ticker",
            dropna=False,
        ):
            ticker = _text(ticker)
            if not ticker:
                continue
            value = float(
                group["value"].clip(
                    lower=0.0
                ).sum()
            )
            if ticker in matrix_tickers:
                covered_tickers.append(ticker)
                if investable_value > 0:
                    covered_weight += (
                        value / investable_value
                    )
            else:
                missing_tickers.append(ticker)

    data_age_days = None
    if sample_end:
        try:
            end_ts = pd.Timestamp(
                sample_end
            ).normalize()
            today_ts = pd.Timestamp.now().normalize()
            data_age_days = max(
                0,
                int(
                    (
                        today_ts
                        - end_ts
                    ).days
                ),
            )
        except Exception:
            data_age_days = None

    if not matrix_valid:
        status = "REVIEW"
        reason = "CORRELATION_MATRIX_INVALID"
    elif observation_count < int(
        min_observations
    ):
        status = "REVIEW"
        reason = "CORRELATION_OBSERVATIONS_LOW"
    elif covered_weight < float(
        min_weight_coverage
    ):
        status = "REVIEW"
        reason = "CORRELATION_WEIGHT_COVERAGE_LOW"
    elif (
        data_age_days is None
        or data_age_days > int(
            max_data_age_days
        )
    ):
        status = "REVIEW"
        reason = "CORRELATION_DATA_STALE"
    else:
        status = "PASS"
        reason = "CORRELATION_SOURCE_READY"

    return {
        "status": status,
        "reason": reason,
        "period": period,
        "as_of": as_of,
        "sample_start": sample_start,
        "sample_end": sample_end,
        "observation_count": observation_count,
        "ticker_count": int(
            len(matrix)
        ),
        "matrix_valid": matrix_valid,
        "covered_weight": min(
            1.0,
            max(
                0.0,
                covered_weight,
            ),
        ),
        "covered_tickers": sorted(
            set(covered_tickers)
        ),
        "missing_tickers": sorted(
            set(missing_tickers)
        ),
        "data_age_days": data_age_days,
    }


LIQUIDITY_SOURCE_ASSIST_COLS = [
    "name",
    "ticker",
    "market",
    "quantity",
    "history_period",
    "volume_window_days",
    "participation_rate",
    "observation_count",
    "avg_daily_volume_shares",
    "median_daily_volume_shares",
    "days_to_exit_proxy",
    "last_date",
    "source",
    "status",
    "issues",
    "updated_at",
]


def normalize_liquidity_source_assist(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in LIQUIDITY_SOURCE_ASSIST_COLS:
        if col not in out.columns:
            out[col] = ""

    text_cols = [
        "name",
        "ticker",
        "market",
        "history_period",
        "last_date",
        "source",
        "status",
        "issues",
        "updated_at",
    ]
    for col in text_cols:
        out[col] = out[col].map(_text).astype("object")

    numeric_cols = [
        "quantity",
        "volume_window_days",
        "participation_rate",
        "observation_count",
        "avg_daily_volume_shares",
        "median_daily_volume_shares",
        "days_to_exit_proxy",
    ]
    for col in numeric_cols:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )

    return out[LIQUIDITY_SOURCE_ASSIST_COLS].copy()


def liquidity_source_assist_from_history(
    *,
    name: str,
    ticker: str,
    market: str,
    quantity: float | None,
    history: pd.DataFrame | None,
    history_period: str = "3mo",
    volume_window_days: int = 20,
    participation_rate: float = 0.10,
    min_observations: int = 10,
    source: str = "connectors.market.price_history",
) -> dict:
    """
    Normal-market liquidity source assist.

    Proxy:
        Days-to-Exit = Position Quantity / (ADV shares × Participation Rate)

    This is not a stress-liquidity guarantee and does not model spread,
    market impact, auction rules, or halt risk.
    """
    issues = []
    qty = _num(quantity)
    window = max(1, int(volume_window_days))
    participation = _num(participation_rate)

    if not _text(ticker):
        issues.append("TICKER_REQUIRED")

    if qty is None or qty <= 0:
        issues.append("QUANTITY_REQUIRED")

    if participation is None or participation <= 0 or participation > 1:
        issues.append("PARTICIPATION_RATE_INVALID")

    observation_count = 0
    avg_volume = None
    median_volume = None
    days_to_exit = None
    last_date = ""

    if history is None or history.empty:
        issues.append("VOLUME_HISTORY_MISSING")
    else:
        hist = history.copy()

        volume_col = None
        for candidate in [
            "Volume",
            "volume",
            "VOLUME",
        ]:
            if candidate in hist.columns:
                volume_col = candidate
                break

        if volume_col is None:
            issues.append("VOLUME_COLUMN_MISSING")
        else:
            volume = pd.to_numeric(
                hist[volume_col],
                errors="coerce",
            )
            valid = volume.loc[
                volume.notna()
                & (volume > 0)
            ]

            tail = valid.tail(window)
            observation_count = int(
                len(tail)
            )

            if observation_count < int(
                min_observations
            ):
                issues.append(
                    "VOLUME_OBSERVATIONS_LOW"
                )

            if observation_count > 0:
                avg_volume = float(
                    tail.mean()
                )
                median_volume = float(
                    tail.median()
                )

            idx = None
            if "Date" in hist.columns:
                idx = pd.to_datetime(
                    hist["Date"],
                    errors="coerce",
                )
            elif "Datetime" in hist.columns:
                idx = pd.to_datetime(
                    hist["Datetime"],
                    errors="coerce",
                )
            else:
                try:
                    idx = pd.to_datetime(
                        hist.index,
                        errors="coerce",
                    )
                except Exception:
                    idx = None

            if idx is not None:
                try:
                    valid_dates = pd.Series(
                        idx
                    ).dropna()
                    if not valid_dates.empty:
                        last_date = (
                            pd.Timestamp(
                                valid_dates.max()
                            )
                            .date()
                            .isoformat()
                        )
                except Exception:
                    last_date = ""

    if (
        not issues
        and qty is not None
        and avg_volume is not None
        and avg_volume > 0
        and participation is not None
        and participation > 0
    ):
        daily_capacity = (
            avg_volume * participation
        )
        if daily_capacity > 0:
            days_to_exit = float(
                qty / daily_capacity
            )
        else:
            issues.append(
                "DAILY_CAPACITY_INVALID"
            )

    status = (
        "READY"
        if not issues
        else "REVIEW"
    )

    return {
        "name": _text(name),
        "ticker": _text(ticker),
        "market": _text(market),
        "quantity": qty,
        "history_period": _text(
            history_period
        ),
        "volume_window_days": window,
        "participation_rate": participation,
        "observation_count": observation_count,
        "avg_daily_volume_shares": avg_volume,
        "median_daily_volume_shares": median_volume,
        "days_to_exit_proxy": days_to_exit,
        "last_date": last_date,
        "source": _text(source),
        "status": status,
        "issues": " | ".join(issues),
        "updated_at": datetime.now().isoformat(),
    }


def liquidity_source_assist_summary(
    assist: pd.DataFrame | None,
    portfolio: pd.DataFrame | None,
    total_assets: float,
) -> dict:
    df = normalize_liquidity_source_assist(
        assist
    )
    if df.empty:
        return {
            "ready_assets": 0,
            "review_assets": 0,
            "weight_coverage": 0.0,
            "ready_weight": 0.0,
            "review_weight": 0.0,
        }

    values = _asset_value_lookup(
        portfolio
    )
    total = max(
        0.0,
        float(total_assets or 0.0),
    )

    ready_assets = 0
    review_assets = 0
    ready_weight = 0.0
    review_weight = 0.0

    for _, row in df.iterrows():
        name = _text(
            row.get("name")
        )
        status = _text(
            row.get("status")
        ).upper()
        weight = (
            values.get(name, 0.0) / total
            if total > 0
            else 0.0
        )

        if status == "READY":
            ready_assets += 1
            ready_weight += weight
        else:
            review_assets += 1
            review_weight += weight

    investable_weight = 0.0
    if portfolio is not None and not portfolio.empty:
        p = portfolio.copy()
        if "asset_type" not in p.columns:
            p["asset_type"] = ""
        if "current_value_krw" not in p.columns:
            p["current_value_krw"] = 0.0
        p["value"] = pd.to_numeric(
            p["current_value_krw"],
            errors="coerce",
        ).fillna(0.0)
        investable_value = float(
            p.loc[
                ~p["asset_type"]
                .fillna("")
                .astype(str)
                .str.lower()
                .eq("cash"),
                "value",
            ]
            .clip(lower=0.0)
            .sum()
        )
        investable_weight = (
            investable_value / total
            if total > 0
            else 0.0
        )

    weight_coverage = (
        ready_weight / investable_weight
        if investable_weight > 0
        else 1.0
    )

    return {
        "ready_assets": ready_assets,
        "review_assets": review_assets,
        "weight_coverage": min(
            1.0,
            max(
                0.0,
                weight_coverage,
            ),
        ),
        "ready_weight": ready_weight,
        "review_weight": review_weight,
    }


def apply_liquidity_assist_to_overlay(
    overlay_df: pd.DataFrame | None,
    assist_df: pd.DataFrame | None,
) -> tuple[pd.DataFrame, int]:
    """
    Copy READY source-assist proxy to Liquidity Overlay.

    Governance:
    - reviewed remains False
    - user must review proxy + source and then explicitly check Reviewed
    """
    overlay = normalize_liquidity_overlays(
        overlay_df
    ).copy()
    assist = normalize_liquidity_source_assist(
        assist_df
    )

    if overlay.empty or assist.empty:
        return overlay, 0

    applied = 0

    for _, row in assist.iterrows():
        if _text(
            row.get("status")
        ).upper() != "READY":
            continue

        name = _text(
            row.get("name")
        )
        ticker = _text(
            row.get("ticker")
        )

        mask = (
            overlay["name"]
            .map(_text)
            .eq(name)
        )
        if ticker:
            ticker_mask = (
                overlay["ticker"]
                .map(_text)
                .eq(ticker)
            )
            if (
                mask
                & ticker_mask
            ).any():
                mask = (
                    mask
                    & ticker_mask
                )

        if not mask.any():
            continue

        days = _num(
            row.get(
                "days_to_exit_proxy"
            )
        )
        if days is None:
            continue

        source_text = (
            "Market Volume Assist"
            + " | period="
            + _text(
                row.get(
                    "history_period"
                )
            )
            + " | ADV_window="
            + str(
                int(
                    _num(
                        row.get(
                            "volume_window_days"
                        )
                    )
                    or 0
                )
            )
            + " | participation="
            + (
                f"{float(row.get('participation_rate')):.1%}"
                if _num(
                    row.get(
                        "participation_rate"
                    )
                )
                is not None
                else "-"
            )
            + " | ADV_shares="
            + (
                f"{float(row.get('avg_daily_volume_shares')):,.0f}"
                if _num(
                    row.get(
                        "avg_daily_volume_shares"
                    )
                )
                is not None
                else "-"
            )
            + " | last="
            + _text(
                row.get("last_date")
            )
        )

        overlay.loc[
            mask,
            "liquidity_days_to_exit",
        ] = float(days)

        overlay.loc[
            mask,
            "source",
        ] = source_text

        overlay.loc[
            mask,
            "reviewed",
        ] = False

        old_note = (
            overlay.loc[
                mask,
                "note",
            ]
            .map(_text)
        )
        overlay.loc[
            mask,
            "note",
        ] = old_note.map(
            lambda x: (
                (
                    x + "; "
                    if x
                    else ""
                )
                + "SOURCE_ASSIST_PROXY_NOT_HUMAN_CONFIRMED"
            )
        )

        applied += int(
            mask.sum()
        )

    return (
        normalize_liquidity_overlays(
            overlay
        ),
        applied,
    )
