from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from typing import Any

import pandas as pd


FUNDAMENTAL_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "company",
    "stock_code",
    "source_kind",
    "source_business_year",
    "source_period",
    "source_report_code",
    "source_fs_div",
    "source_corp_code",
    "source_extraction_integrity",
    "revenue",
    "operating_profit",
    "cfo",
    "capex_proxy",
    "fcf_proxy",
    "cash",
    "debt_proxy",
    "net_cash_proxy",
    "issued_shares_proxy",
    "treasury_shares_proxy",
    "diluted_shares",
    "share_count_basis",
    "effective_tax_rate",
    "tax_rate_basis",
    "maintenance_capex",
    "invested_capital",
    "invested_capital_basis",
    "nopat",
    "owner_earnings_proxy",
    "fcf_per_share",
    "owner_earnings_per_share",
    "dividends_paid_proxy",
    "treasury_share_purchase_proxy",
    "treasury_share_disposal_proxy",
    "net_share_count_change",
    "net_share_count_change_pct",
    "capex_to_cfo",
    "dividend_to_fcf",
    "buyback_to_fcf",
    "fcf_after_dividend_buyback",
    "operating_margin",
    "cfo_margin",
    "fcf_margin",
    "roic",
    "iroic",
    "delta_nopat",
    "delta_invested_capital",
    "capital_change_to_period_nopat",
    "reinvestment_rate",
    "growth_identity_proxy",
    "manual_shares_confirmed",
    "manual_tax_confirmed",
    "manual_maintenance_capex_confirmed",
    "manual_invested_capital_confirmed",
    "prior_snapshot_id",
    "review_status",
    "hash_schema_version",
    "record_hash",
    "note",
]


def _clean(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if not math.isfinite(out):
        return None
    return out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _clean(value).upper() in {"TRUE", "1", "YES", "Y", "PASS"}


def normalize_fundamental_snapshots(df: pd.DataFrame | None) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()
    out = df.copy()
    for col in FUNDAMENTAL_SNAPSHOT_COLS:
        if col not in out.columns:
            out[col] = ""
    return out[FUNDAMENTAL_SNAPSHOT_COLS + [c for c in out.columns if c not in FUNDAMENTAL_SNAPSHOT_COLS]]


def latest_fundamental_snapshot(
    df: pd.DataFrame | None,
    company: str,
) -> dict:
    out = normalize_fundamental_snapshots(df)
    if out.empty:
        return {}
    hit = out.loc[
        out["company"].fillna("").astype(str).str.strip().eq(_clean(company))
    ].copy()
    if hit.empty:
        return {}

    hit["_created_sort"] = pd.to_datetime(
        hit["created_at"],
        errors="coerce",
        utc=True,
    )
    hit["_row_order"] = range(len(hit))
    hit = hit.sort_values(
        ["_created_sort", "_row_order"],
        ascending=[True, True],
        na_position="first",
    )
    return hit.iloc[-1].drop(
        labels=["_created_sort", "_row_order"],
        errors="ignore",
    ).to_dict()



def build_source_backed_suggestions(
    dart_summary: dict,
    share_summary: dict | None = None,
) -> dict:
    """
    Build *suggestions* from official structured-source extracts.

    Nothing returned here is automatically accepted into the calculation.
    Human confirmation remains mandatory in the UI.
    """
    src = dart_summary or {}
    shares = share_summary or {}

    tax_rate = _num(src.get("effective_tax_rate_proxy"))
    tax_status = _clean(src.get("effective_tax_rate_proxy_status")) or "MISSING"

    invested_capital = _num(src.get("invested_capital_proxy"))
    ic_status = _clean(src.get("invested_capital_proxy_status")) or "MISSING"

    share_count = _num(shares.get("distributed_shares_proxy"))
    if share_count is None:
        share_count = _num(shares.get("issued_shares_proxy"))
    share_status = _clean(shares.get("share_count_status")) or "MISSING"

    return {
        "share_count_proxy": share_count,
        "share_count_status": share_status,
        "share_count_basis": _clean(shares.get("share_count_basis")),
        "effective_tax_rate_proxy": tax_rate,
        "effective_tax_rate_status": tax_status,
        "tax_rate_basis": (
            "OpenDART income tax expense / pretax income"
            if tax_rate is not None
            else ""
        ),
        "invested_capital_proxy": invested_capital,
        "invested_capital_status": ic_status,
        "invested_capital_basis": (
            _clean(src.get("invested_capital_proxy_scope"))
            if invested_capital is not None
            else ""
        ),
        "maintenance_capex_proxy": None,
        "maintenance_capex_status": "NO_STRUCTURED_MAINTENANCE_SPLIT",
    }




def reviewed_snapshot_for_period(
    df: pd.DataFrame | None,
    company: str,
    business_year: str | int,
    period: str,
) -> dict:
    """
    Latest integrity-OK REVIEWED snapshot for one exact company/year/period.
    """
    out = normalize_fundamental_snapshots(df)
    if out.empty:
        return {}

    year = _clean(business_year)
    period_key = _clean(period).upper()

    hit = out.loc[
        out["company"].fillna("").astype(str).str.strip().eq(_clean(company))
        & out["source_business_year"].fillna("").astype(str).str.strip().eq(year)
        & out["source_period"].fillna("").astype(str).str.upper().eq(period_key)
        & out["review_status"].fillna("").astype(str).str.upper().eq("REVIEWED")
    ].copy()
    if hit.empty:
        return {}

    hit["_created_sort"] = pd.to_datetime(
        hit["created_at"],
        errors="coerce",
        utc=True,
    )
    hit = hit.sort_values(
        "_created_sort",
        ascending=False,
        na_position="last",
    )

    for _, row in hit.iterrows():
        candidate = row.drop(
            labels=["_created_sort"],
            errors="ignore",
        ).to_dict()
        if snapshot_integrity_status(candidate) == "OK":
            return candidate
    return {}


def source_period_growth_preview(
    current_summary: dict,
    prior_summary: dict,
    current_share_count: float | None = None,
    prior_share_count: float | None = None,
) -> pd.DataFrame:
    """
    Source-only YoY preview for same-period filings.

    This is descriptive and does not replace Human-confirmed Fundamental metrics.
    """
    def num(v):
        return _num(v)

    def growth(curr, prev):
        c = num(curr)
        p = num(prev)
        if c is None or p is None or p == 0:
            return None
        return c / p - 1.0

    rows = []
    for label, key in [
        ("Revenue", "revenue"),
        ("Operating Profit", "operating_profit"),
        ("CFO", "cfo"),
        ("FCF proxy", "fcf_proxy"),
        ("Net Cash proxy", "net_cash_proxy"),
    ]:
        curr = num(current_summary.get(key))
        prev = num(prior_summary.get(key))
        rows.append(
            {
                "metric": label,
                "prior": prev,
                "current": curr,
                "change_pct": growth(curr, prev),
            }
        )

    curr_shares = num(current_share_count)
    prev_shares = num(prior_share_count)
    rows.append(
        {
            "metric": "Outstanding Share Count proxy",
            "prior": prev_shares,
            "current": curr_shares,
            "change_pct": growth(curr_shares, prev_shares),
        }
    )
    return pd.DataFrame(rows)


def latest_comparable_fundamental_snapshot(
    df: pd.DataFrame | None,
    company: str,
    current_business_year: str | int,
    current_period: str,
) -> dict:
    """
    Latest reviewed snapshot from an earlier year with the same period basis.

    Examples:
    - H1 compares only with earlier H1
    - FY compares only with earlier FY

    This avoids mechanically mixing H1/FY/Q3 period economics in iROIC.
    """
    out = normalize_fundamental_snapshots(df)
    if out.empty:
        return {}

    current_year_text = _clean(current_business_year)
    try:
        current_year = int(float(current_year_text))
    except Exception:
        return {}

    period = _clean(current_period).upper()
    hit = out.loc[
        out["company"].fillna("").astype(str).str.strip().eq(_clean(company))
        & out["source_period"].fillna("").astype(str).str.upper().eq(period)
        & out["review_status"].fillna("").astype(str).str.upper().eq("REVIEWED")
    ].copy()
    if hit.empty:
        return {}

    hit["_year"] = pd.to_numeric(hit["source_business_year"], errors="coerce")
    hit = hit.loc[hit["_year"] < current_year].copy()
    if hit.empty:
        return {}

    hit["_created_sort"] = pd.to_datetime(
        hit["created_at"],
        errors="coerce",
        utc=True,
    )
    hit = hit.sort_values(
        ["_year", "_created_sort"],
        ascending=[False, False],
        na_position="last",
    )

    for _, row in hit.iterrows():
        candidate = row.drop(
            labels=["_year", "_created_sort"],
            errors="ignore",
        ).to_dict()
        if snapshot_integrity_status(candidate) == "OK":
            return candidate
    return {}




def build_capital_allocation_metrics(
    dart_summary: dict,
    *,
    current_share_count: float | None = None,
    issued_shares_proxy: float | None = None,
    prior_snapshot: dict | None = None,
) -> dict:
    """
    Descriptive Capital Allocation / per-share diagnostics.

    No value judgment is made about buyback quality, M&A quality or intrinsic value.
    """
    src = dart_summary or {}
    prior = prior_snapshot or {}

    cfo = _num(src.get("cfo"))
    capex = _num(src.get("capex_proxy"))
    if capex is not None:
        capex = abs(capex)
    fcf = _num(src.get("fcf_proxy"))

    dividends = _num(src.get("dividends_paid_proxy"))
    buybacks = _num(src.get("treasury_share_purchase_proxy"))
    disposals = _num(src.get("treasury_share_disposal_proxy"))

    current_shares = _num(current_share_count)
    issued = _num(issued_shares_proxy)
    treasury = None
    if issued is not None and current_shares is not None and issued >= current_shares:
        treasury = issued - current_shares

    prior_shares = _num(prior.get("diluted_shares"))
    net_share_change = None
    net_share_change_pct = None
    if current_shares is not None and prior_shares is not None and prior_shares > 0:
        net_share_change = current_shares - prior_shares
        net_share_change_pct = net_share_change / prior_shares

    def ratio(a, b):
        if a is None or b is None or b == 0:
            return None
        return a / b

    capex_to_cfo = ratio(capex, cfo)
    dividend_to_fcf = ratio(dividends, fcf)
    buyback_to_fcf = ratio(buybacks, fcf)

    fcf_after_distribution = None
    if fcf is not None:
        fcf_after_distribution = fcf
        if dividends is not None:
            fcf_after_distribution -= dividends
        if buybacks is not None:
            fcf_after_distribution -= buybacks

    return {
        "issued_shares_proxy": issued,
        "treasury_shares_proxy": treasury,
        "outstanding_share_count_proxy": current_shares,
        "prior_outstanding_share_count_proxy": prior_shares,
        "net_share_count_change": net_share_change,
        "net_share_count_change_pct": net_share_change_pct,
        "dividends_paid_proxy": dividends,
        "treasury_share_purchase_proxy": buybacks,
        "treasury_share_disposal_proxy": disposals,
        "capex_to_cfo": capex_to_cfo,
        "dividend_to_fcf": dividend_to_fcf,
        "buyback_to_fcf": buyback_to_fcf,
        "fcf_after_dividend_buyback": fcf_after_distribution,
    }


def build_fundamental_metrics(
    dart_summary: dict,
    *,
    diluted_shares: float | None = None,
    effective_tax_rate: float | None = None,
    maintenance_capex: float | None = None,
    invested_capital: float | None = None,
    prior_snapshot: dict | None = None,
    period: str = "",
) -> dict:
    """
    Build conservative fundamental metrics from a DART extraction plus
    explicitly supplied manual inputs.

    Guardrails:
    - FCF uses the existing DART FCF proxy only.
    - Owner Earnings proxy requires an explicit maintenance-capex input.
    - FCF/share requires an explicit diluted-share input.
    - ROIC requires both an explicit effective tax rate and invested capital.
    - iROIC requires a prior reviewed snapshot and positive incremental capital.
    - No value here changes Watchlist/Portfolio state automatically.
    """
    src = dart_summary or {}
    prior = prior_snapshot or {}

    revenue = _num(src.get("revenue"))
    op = _num(src.get("operating_profit"))
    cfo = _num(src.get("cfo"))
    capex_raw = _num(src.get("capex_proxy"))
    capex = abs(capex_raw) if capex_raw is not None else None
    fcf = _num(src.get("fcf_proxy"))
    cash = _num(src.get("cash"))
    debt = _num(src.get("interest_bearing_debt_proxy"))
    net_cash = _num(src.get("net_cash_proxy"))

    shares = _num(diluted_shares)
    tax = _num(effective_tax_rate)
    maint = _num(maintenance_capex)
    ic = _num(invested_capital)

    if shares is not None and shares <= 0:
        shares = None
    if tax is not None and not (0 <= tax <= 1):
        tax = None
    if maint is not None and maint < 0:
        maint = None
    if ic is not None and ic <= 0:
        ic = None

    def ratio(a, b):
        if a is None or b is None or b == 0:
            return None
        return a / b

    operating_margin = ratio(op, revenue)
    cfo_margin = ratio(cfo, revenue)
    fcf_margin = ratio(fcf, revenue)

    fcf_per_share = ratio(fcf, shares)

    owner_earnings = None
    if cfo is not None and maint is not None:
        owner_earnings = cfo - maint
    owner_earnings_per_share = ratio(owner_earnings, shares)

    nopat = None
    if op is not None and tax is not None:
        nopat = op * (1.0 - tax)

    roic = ratio(nopat, ic)

    prior_nopat = _num(prior.get("nopat"))
    prior_ic = _num(prior.get("invested_capital"))
    delta_nopat = None
    delta_ic = None
    iroic = None
    capital_change_to_period_nopat = None
    reinvestment_rate = None
    growth_identity = None

    period_key = _clean(period).upper()
    is_full_year = period_key in {"FY", "ANNUAL", "FULL_YEAR", "YEAR"}

    if nopat is not None and ic is not None and prior_nopat is not None and prior_ic is not None:
        delta_nopat = nopat - prior_nopat
        delta_ic = ic - prior_ic
        # iROIC is only shown when incremental invested capital is positive.
        # Capital release / negative delta-IC is economically different and
        # requires human interpretation rather than a mechanically huge ratio.
        if delta_ic > 0:
            iroic = delta_nopat / delta_ic
            if nopat != 0:
                capital_change_to_period_nopat = delta_ic / nopat

                # Standard g ~= ROIC x Reinvestment should use a consistent
                # full-year flow/stock basis. For H1/Q1/Q3, keep the raw
                # capital-change diagnostic but suppress the reinvestment/g
                # identity labels so interim numbers are not mistaken for a
                # sustainable growth identity.
                if is_full_year:
                    reinvestment_rate = capital_change_to_period_nopat

        if is_full_year and roic is not None and reinvestment_rate is not None:
            growth_identity = roic * reinvestment_rate

    quality = {
        "fcf_proxy": "PASS_PROXY" if fcf is not None else "MISSING",
        "fcf_per_share": "HUMAN_CONFIRMED_SHARE_COUNT_REQUIRED" if shares is None else ("CALCULATED" if fcf is not None else "MISSING_FCF"),
        "owner_earnings": "MANUAL_MAINTENANCE_CAPEX_REQUIRED" if maint is None else ("CALCULATED_PROXY" if cfo is not None else "MISSING_CFO"),
        "roic": "HUMAN_CONFIRMED_TAX_AND_INVESTED_CAPITAL_REQUIRED" if (tax is None or ic is None) else ("CALCULATED" if op is not None else "MISSING_OPERATING_PROFIT"),
        "iroic": "PRIOR_REVIEWED_SNAPSHOT_REQUIRED" if not prior else (
            "CALCULATED" if iroic is not None else "REVIEW_DELTA_INVESTED_CAPITAL"
        ),
    }

    return {
        "revenue": revenue,
        "operating_profit": op,
        "cfo": cfo,
        "capex_proxy": capex,
        "fcf_proxy": fcf,
        "cash": cash,
        "debt_proxy": debt,
        "net_cash_proxy": net_cash,
        "diluted_shares": shares,
        "effective_tax_rate": tax,
        "maintenance_capex": maint,
        "invested_capital": ic,
        "operating_margin": operating_margin,
        "cfo_margin": cfo_margin,
        "fcf_margin": fcf_margin,
        "fcf_per_share": fcf_per_share,
        "owner_earnings_proxy": owner_earnings,
        "owner_earnings_per_share": owner_earnings_per_share,
        "nopat": nopat,
        "roic": roic,
        "iroic": iroic,
        "delta_nopat": delta_nopat,
        "delta_invested_capital": delta_ic,
        "capital_change_to_period_nopat": capital_change_to_period_nopat,
        "reinvestment_rate": reinvestment_rate,
        "growth_identity_proxy": growth_identity,
        "quality": quality,
    }


FUNDAMENTAL_HASH_SCHEMA_VERSION = "v3"

_FUNDAMENTAL_BOOL_FIELDS = {
    "manual_shares_confirmed",
    "manual_tax_confirmed",
    "manual_maintenance_capex_confirmed",
    "manual_invested_capital_confirmed",
}

_FUNDAMENTAL_NUMERIC_ID_FIELDS = {
    "stock_code",
    "source_business_year",
    "source_report_code",
    "source_corp_code",
}

# KRW / share-count style quantities. These are economically discrete enough
# that 1-unit canonicalization is both stable and more meaningful than hashing
# binary float tails created by CSV parsing.
_FUNDAMENTAL_INTEGER_VALUE_FIELDS = {
    "revenue",
    "operating_profit",
    "cfo",
    "capex_proxy",
    "fcf_proxy",
    "cash",
    "debt_proxy",
    "net_cash_proxy",
    "issued_shares_proxy",
    "treasury_shares_proxy",
    "diluted_shares",
    "maintenance_capex",
    "invested_capital",
    "nopat",
    "owner_earnings_proxy",
    "dividends_paid_proxy",
    "treasury_share_purchase_proxy",
    "treasury_share_disposal_proxy",
    "net_share_count_change",
    "delta_nopat",
    "delta_invested_capital",
    "fcf_after_dividend_buyback",
}

# Per-share money values can legitimately be fractional.
_FUNDAMENTAL_PER_SHARE_FIELDS = {
    "fcf_per_share",
    "owner_earnings_per_share",
}

# Ratios/rates are canonicalized at 10 decimal places. This is far tighter
# than the UI precision while remaining stable across pandas CSV float parsing.
_FUNDAMENTAL_RATIO_FIELDS = {
    "effective_tax_rate",
    "net_share_count_change_pct",
    "capex_to_cfo",
    "dividend_to_fcf",
    "buyback_to_fcf",
    "operating_margin",
    "cfo_margin",
    "fcf_margin",
    "roic",
    "iroic",
    "capital_change_to_period_nopat",
    "reinvestment_rate",
    "growth_identity_proxy",
}

# v2 is kept readable so already-verified baselines remain valid.
_FUNDAMENTAL_HASH_SCHEMA_V2_FIELDS = (
    "snapshot_id","created_at","company","stock_code","source_kind",
    "source_business_year","source_period","source_report_code","source_fs_div",
    "source_corp_code","source_extraction_integrity","revenue","operating_profit",
    "cfo","capex_proxy","fcf_proxy","cash","debt_proxy","net_cash_proxy",
    "issued_shares_proxy","treasury_shares_proxy","diluted_shares","share_count_basis",
    "effective_tax_rate","tax_rate_basis","maintenance_capex","invested_capital",
    "invested_capital_basis","nopat","owner_earnings_proxy","fcf_per_share",
    "owner_earnings_per_share","dividends_paid_proxy","treasury_share_purchase_proxy",
    "treasury_share_disposal_proxy","net_share_count_change","net_share_count_change_pct",
    "capex_to_cfo","dividend_to_fcf","buyback_to_fcf","fcf_after_dividend_buyback",
    "operating_margin","cfo_margin","fcf_margin","roic","iroic","delta_nopat",
    "delta_invested_capital","capital_change_to_period_nopat","reinvestment_rate",
    "growth_identity_proxy","manual_shares_confirmed","manual_tax_confirmed",
    "manual_maintenance_capex_confirmed","manual_invested_capital_confirmed",
    "prior_snapshot_id","review_status","note","hash_schema_version",
)

# v3 protects reviewed economic/provenance content but intentionally excludes
# technical row identity (snapshot_id/created_at). Those fields are useful
# metadata, not the reviewed economic payload.
_FUNDAMENTAL_HASH_SCHEMA_V3_FIELDS = (
    "company","stock_code","source_kind",
    "source_business_year","source_period","source_report_code","source_fs_div",
    "source_corp_code","source_extraction_integrity",
    "revenue","operating_profit","cfo","capex_proxy","fcf_proxy","cash",
    "debt_proxy","net_cash_proxy","issued_shares_proxy","treasury_shares_proxy",
    "diluted_shares","share_count_basis","effective_tax_rate","tax_rate_basis",
    "maintenance_capex","invested_capital","invested_capital_basis","nopat",
    "owner_earnings_proxy","fcf_per_share","owner_earnings_per_share",
    "dividends_paid_proxy","treasury_share_purchase_proxy",
    "treasury_share_disposal_proxy","net_share_count_change",
    "net_share_count_change_pct","capex_to_cfo","dividend_to_fcf","buyback_to_fcf",
    "fcf_after_dividend_buyback","operating_margin","cfo_margin","fcf_margin",
    "roic","iroic","delta_nopat","delta_invested_capital",
    "capital_change_to_period_nopat","reinvestment_rate","growth_identity_proxy",
    "manual_shares_confirmed","manual_tax_confirmed",
    "manual_maintenance_capex_confirmed","manual_invested_capital_confirmed",
    "prior_snapshot_id","review_status","note","hash_schema_version",
)


def _canonical_numeric_v2(value: Any) -> str:
    number = _num(value)
    if number is None:
        return ""
    if number == 0:
        return "0"
    return format(float(number), ".15g")


def _canonical_numeric_id(value: Any) -> str:
    text = _clean(value)
    if not text:
        return ""
    try:
        number = float(text)
        if math.isfinite(number) and number.is_integer():
            return str(int(number))
    except Exception:
        pass
    return text


def _canonical_bool(value: Any) -> str:
    text = _clean(value).upper()
    if text in {"TRUE", "1", "YES", "Y", "PASS"}:
        return "true"
    if text in {"FALSE", "0", "NO", "N", "FAIL"}:
        return "false"
    if isinstance(value, bool):
        return "true" if value else "false"
    return "" if not text else text.lower()


def _fixed_decimal(value: Any, places: int) -> str:
    number = _num(value)
    if number is None:
        return ""
    rounded = round(float(number), places)
    if rounded == 0:
        return "0"
    text = f"{rounded:.{places}f}".rstrip("0").rstrip(".")
    return text or "0"


def _integer_unit(value: Any) -> str:
    number = _num(value)
    if number is None:
        return ""
    return str(int(round(float(number))))


def _canonical_hash_value_v2(field: str, value: Any) -> str:
    if field in _FUNDAMENTAL_BOOL_FIELDS:
        return _canonical_bool(value)
    if field in _FUNDAMENTAL_NUMERIC_ID_FIELDS:
        return _canonical_numeric_id(value)
    # dev8/v2 behavior retained exactly for old verified rows.
    if field in (
        _FUNDAMENTAL_INTEGER_VALUE_FIELDS
        | _FUNDAMENTAL_PER_SHARE_FIELDS
        | _FUNDAMENTAL_RATIO_FIELDS
    ):
        return _canonical_numeric_v2(value)
    return _clean(value)


def _canonical_hash_value_v3(field: str, value: Any) -> str:
    if field in _FUNDAMENTAL_BOOL_FIELDS:
        return _canonical_bool(value)
    if field in _FUNDAMENTAL_NUMERIC_ID_FIELDS:
        return _canonical_numeric_id(value)
    if field in _FUNDAMENTAL_INTEGER_VALUE_FIELDS:
        return _integer_unit(value)
    if field in _FUNDAMENTAL_PER_SHARE_FIELDS:
        return _fixed_decimal(value, 6)
    if field in _FUNDAMENTAL_RATIO_FIELDS:
        return _fixed_decimal(value, 10)
    return _clean(value)


# Current canonical helper is v3. Duplicate fingerprinting also benefits from
# the stable representation.
def _canonical_hash_value(field: str, value: Any) -> str:
    return _canonical_hash_value_v3(field, value)


def _hashable_payload_v2(record: dict) -> dict:
    return {
        k: _canonical_hash_value_v2(k, record.get(k, ""))
        for k in _FUNDAMENTAL_HASH_SCHEMA_V2_FIELDS
    }


def _hashable_payload_v3(record: dict) -> dict:
    return {
        k: _canonical_hash_value_v3(k, record.get(k, ""))
        for k in _FUNDAMENTAL_HASH_SCHEMA_V3_FIELDS
    }


def _hashable_payload(record: dict) -> dict:
    return _hashable_payload_v3(record)


def _calculate_hash(record: dict, version: str) -> str:
    if version == "v2":
        payload = _hashable_payload_v2(record)
    elif version == "v3":
        payload = _hashable_payload_v3(record)
    else:
        raise ValueError(f"Unsupported hash schema: {version}")
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def snapshot_integrity_status(record: dict) -> str:
    version = _clean(record.get("hash_schema_version"))
    expected = _clean(record.get("record_hash"))

    if not version:
        return "LEGACY_HASH"
    if version not in {"v2", "v3"}:
        return f"UNSUPPORTED_HASH_SCHEMA:{version}"
    if not expected:
        return "MISSING_HASH"

    actual = _calculate_hash(record, version)
    return "OK" if actual == expected else "HASH_MISMATCH"


def fundamental_snapshot_hash_report(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    out = normalize_fundamental_snapshots(df)
    if out.empty:
        return pd.DataFrame(
            columns=[
                "snapshot_id","company","source_business_year","source_period",
                "review_status","hash_schema_version","hash_status",
            ]
        )

    rows = []
    for _, row in out.iterrows():
        rec = row.to_dict()
        rows.append(
            {
                "snapshot_id": _clean(rec.get("snapshot_id")),
                "company": _clean(rec.get("company")),
                "source_business_year": _clean(rec.get("source_business_year")),
                "source_period": _clean(rec.get("source_period")),
                "review_status": _clean(rec.get("review_status")).upper(),
                "hash_schema_version": _clean(rec.get("hash_schema_version")) or "legacy",
                "hash_status": snapshot_integrity_status(rec),
            }
        )
    return pd.DataFrame(rows)


def migrate_verified_v2_to_v3(
    df: pd.DataFrame | None,
) -> tuple[pd.DataFrame, int]:
    """
    Safe migration: only v2 rows whose existing v2 hash verifies OK can move
    to v3. Financial/source/review values are not changed.
    """
    out = normalize_fundamental_snapshots(df).copy()
    if out.empty:
        return out, 0

    migrated = 0
    for idx, row in out.iterrows():
        rec = row.to_dict()
        if _clean(rec.get("hash_schema_version")) != "v2":
            continue
        if snapshot_integrity_status(rec) != "OK":
            continue
        out.at[idx, "hash_schema_version"] = "v3"
        migrated_rec = out.loc[idx].to_dict()
        out.at[idx, "record_hash"] = _calculate_hash(migrated_rec, "v3")
        migrated += 1
    return out, migrated


def remove_blocked_current_period_snapshots(
    df: pd.DataFrame | None,
    *,
    company: str,
    business_year: str | int,
    period: str,
) -> tuple[pd.DataFrame, int]:
    """
    Remove only HASH_MISMATCH rows for the selected company/year/period.
    Used to discard a just-created invalid technical record before re-saving
    under the stable v3 schema.
    """
    out = normalize_fundamental_snapshots(df).copy()
    if out.empty:
        return out, 0

    year = _canonical_numeric_id(business_year)
    period_key = _clean(period).upper()
    drop_indices = []

    for idx, row in out.iterrows():
        rec = row.to_dict()
        if _clean(rec.get("company")) != _clean(company):
            continue
        if _canonical_numeric_id(rec.get("source_business_year")) != year:
            continue
        if _clean(rec.get("source_period")).upper() != period_key:
            continue
        if snapshot_integrity_status(rec) == "HASH_MISMATCH":
            drop_indices.append(idx)

    if not drop_indices:
        return out, 0

    cleaned = out.drop(index=drop_indices).reset_index(drop=True)
    return normalize_fundamental_snapshots(cleaned), len(drop_indices)


def repair_fundamental_snapshot_hashes(
    df: pd.DataFrame | None,
) -> tuple[pd.DataFrame, int]:
    """
    Legacy rows without a schema can be migrated to v3 only by explicit user
    action. Existing v2/v3 HASH_MISMATCH rows are never silently re-hashed.
    """
    out = normalize_fundamental_snapshots(df).copy()
    if out.empty:
        return out, 0

    migrated = 0
    for idx, row in out.iterrows():
        rec = row.to_dict()
        if snapshot_integrity_status(rec) != "LEGACY_HASH":
            continue
        out.at[idx, "hash_schema_version"] = "v3"
        migrated_rec = out.loc[idx].to_dict()
        out.at[idx, "record_hash"] = _calculate_hash(migrated_rec, "v3")
        migrated += 1

    return out, migrated


def build_fundamental_snapshot_record(
    *,
    company: str,
    stock_code: str,
    source_meta: dict,
    dart_summary: dict,
    metrics: dict,
    manual_shares_confirmed: bool,
    manual_tax_confirmed: bool,
    manual_maintenance_capex_confirmed: bool,
    manual_invested_capital_confirmed: bool,
    share_count_basis: str = "",
    tax_rate_basis: str = "",
    invested_capital_basis: str = "",
    capital_allocation_metrics: dict | None = None,
    prior_snapshot: dict | None = None,
    review_status: str = "REVIEWED",
    note: str = "",
) -> dict:
    prior = prior_snapshot or {}
    allocation = capital_allocation_metrics or {}
    created_at = datetime.now(timezone.utc).isoformat()
    snapshot_seed = (
        f"{company}|{stock_code}|{source_meta.get('business_year','')}|"
        f"{source_meta.get('period','')}|{created_at}"
    )
    snapshot_id = hashlib.sha256(snapshot_seed.encode("utf-8")).hexdigest()[:20]

    record = {
        "snapshot_id": snapshot_id,
        "created_at": created_at,
        "company": _clean(company),
        "stock_code": _clean(stock_code),
        "source_kind": _clean(source_meta.get("source_kind", "OpenDART")),
        "source_business_year": _clean(source_meta.get("business_year")),
        "source_period": _clean(source_meta.get("period")),
        "source_report_code": _clean(source_meta.get("report_code")),
        "source_fs_div": _clean(source_meta.get("fs_div")),
        "source_corp_code": _clean(source_meta.get("corp_code")),
        "source_extraction_integrity": _clean(dart_summary.get("extraction_integrity_status")),
        "revenue": metrics.get("revenue"),
        "operating_profit": metrics.get("operating_profit"),
        "cfo": metrics.get("cfo"),
        "capex_proxy": metrics.get("capex_proxy"),
        "fcf_proxy": metrics.get("fcf_proxy"),
        "cash": metrics.get("cash"),
        "debt_proxy": metrics.get("debt_proxy"),
        "net_cash_proxy": metrics.get("net_cash_proxy"),
        "issued_shares_proxy": allocation.get("issued_shares_proxy"),
        "treasury_shares_proxy": allocation.get("treasury_shares_proxy"),
        "diluted_shares": metrics.get("diluted_shares"),
        "share_count_basis": _clean(share_count_basis),
        "effective_tax_rate": metrics.get("effective_tax_rate"),
        "tax_rate_basis": _clean(tax_rate_basis),
        "maintenance_capex": metrics.get("maintenance_capex"),
        "invested_capital": metrics.get("invested_capital"),
        "invested_capital_basis": _clean(invested_capital_basis),
        "nopat": metrics.get("nopat"),
        "owner_earnings_proxy": metrics.get("owner_earnings_proxy"),
        "fcf_per_share": metrics.get("fcf_per_share"),
        "owner_earnings_per_share": metrics.get("owner_earnings_per_share"),
        "dividends_paid_proxy": allocation.get("dividends_paid_proxy"),
        "treasury_share_purchase_proxy": allocation.get("treasury_share_purchase_proxy"),
        "treasury_share_disposal_proxy": allocation.get("treasury_share_disposal_proxy"),
        "net_share_count_change": allocation.get("net_share_count_change"),
        "net_share_count_change_pct": allocation.get("net_share_count_change_pct"),
        "capex_to_cfo": allocation.get("capex_to_cfo"),
        "dividend_to_fcf": allocation.get("dividend_to_fcf"),
        "buyback_to_fcf": allocation.get("buyback_to_fcf"),
        "fcf_after_dividend_buyback": allocation.get("fcf_after_dividend_buyback"),
        "operating_margin": metrics.get("operating_margin"),
        "cfo_margin": metrics.get("cfo_margin"),
        "fcf_margin": metrics.get("fcf_margin"),
        "roic": metrics.get("roic"),
        "iroic": metrics.get("iroic"),
        "delta_nopat": metrics.get("delta_nopat"),
        "delta_invested_capital": metrics.get("delta_invested_capital"),
        "capital_change_to_period_nopat": metrics.get("capital_change_to_period_nopat"),
        "reinvestment_rate": metrics.get("reinvestment_rate"),
        "growth_identity_proxy": metrics.get("growth_identity_proxy"),
        "manual_shares_confirmed": bool(manual_shares_confirmed),
        "manual_tax_confirmed": bool(manual_tax_confirmed),
        "manual_maintenance_capex_confirmed": bool(manual_maintenance_capex_confirmed),
        "manual_invested_capital_confirmed": bool(manual_invested_capital_confirmed),
        "prior_snapshot_id": _clean(prior.get("snapshot_id")),
        "review_status": _clean(review_status).upper() or "REVIEWED",
        "hash_schema_version": FUNDAMENTAL_HASH_SCHEMA_VERSION,
        "record_hash": "",
        "note": _clean(note),
    }

    record["record_hash"] = _calculate_hash(
        record,
        FUNDAMENTAL_HASH_SCHEMA_VERSION,
    )
    return record



def _snapshot_natural_key(record: dict) -> tuple[str, ...]:
    """
    One source-period identity. source_kind is intentionally excluded because
    the same filing may be reached through Session vs Comparable Backfill.
    """
    return (
        _clean(record.get("company")),
        _canonical_numeric_id(record.get("stock_code")),
        _canonical_numeric_id(record.get("source_business_year")),
        _clean(record.get("source_period")).upper(),
        _canonical_numeric_id(record.get("source_report_code")),
        _clean(record.get("source_fs_div")).upper(),
        _canonical_numeric_id(record.get("source_corp_code")),
    )


def _snapshot_revision_fingerprint(record: dict) -> str:
    """
    Fingerprint meaningful snapshot content while excluding technical identity
    fields that change on a repeated save.
    """
    excluded = {
        "snapshot_id",
        "created_at",
        "record_hash",
        "hash_schema_version",
        "prior_snapshot_id",
    }
    payload = {
        k: _canonical_hash_value(k, record.get(k, ""))
        for k in FUNDAMENTAL_SNAPSHOT_COLS
        if k not in excluded
    }
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def fundamental_snapshot_duplicate_report(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    out = normalize_fundamental_snapshots(df)
    if out.empty:
        return pd.DataFrame(
            columns=[
                "company",
                "source_business_year",
                "source_period",
                "source_report_code",
                "source_fs_div",
                "rows",
                "content_versions",
                "exact_duplicates_removable",
                "status",
            ]
        )

    work = out.copy()
    work["_natural_key"] = [
        _snapshot_natural_key(r.to_dict())
        for _, r in work.iterrows()
    ]
    work["_revision_fp"] = [
        _snapshot_revision_fingerprint(r.to_dict())
        for _, r in work.iterrows()
    ]

    rows = []
    for _, grp in work.groupby("_natural_key", dropna=False):
        if len(grp) <= 1:
            continue
        version_counts = grp["_revision_fp"].value_counts()
        exact_removable = int(
            sum(max(0, int(c) - 1) for c in version_counts.tolist())
        )
        content_versions = int(len(version_counts))
        status = (
            "EXACT_DUPLICATE"
            if content_versions == 1
            else (
                "MIXED_EXACT_AND_REVISIONS"
                if exact_removable > 0
                else "MULTIPLE_REVISIONS"
            )
        )
        first = grp.iloc[0]
        rows.append(
            {
                "company": _clean(first.get("company")),
                "source_business_year": _clean(first.get("source_business_year")),
                "source_period": _clean(first.get("source_period")),
                "source_report_code": _clean(first.get("source_report_code")),
                "source_fs_div": _clean(first.get("source_fs_div")),
                "rows": int(len(grp)),
                "content_versions": content_versions,
                "exact_duplicates_removable": exact_removable,
                "status": status,
            }
        )
    return pd.DataFrame(rows)


def consolidate_exact_fundamental_duplicates(
    df: pd.DataFrame | None,
) -> tuple[pd.DataFrame, int]:
    """
    Remove only repeated saves with identical meaningful content.
    Different reviewed revisions for the same source-period are preserved.
    Latest created_at is kept within each exact-content set.
    """
    out = normalize_fundamental_snapshots(df).copy()
    if out.empty:
        return out, 0

    out["_natural_key"] = [
        _snapshot_natural_key(r.to_dict())
        for _, r in out.iterrows()
    ]
    out["_revision_fp"] = [
        _snapshot_revision_fingerprint(r.to_dict())
        for _, r in out.iterrows()
    ]
    out["_created_sort"] = pd.to_datetime(
        out["created_at"],
        errors="coerce",
        utc=True,
    )
    out["_row_order"] = range(len(out))
    out = out.sort_values(
        ["_created_sort", "_row_order"],
        ascending=[True, True],
        na_position="first",
    )

    before = len(out)
    out = out.drop_duplicates(
        subset=["_natural_key", "_revision_fp"],
        keep="last",
    )
    removed = before - len(out)

    out = out.sort_values(
        ["_created_sort", "_row_order"],
        ascending=[True, True],
        na_position="first",
    ).drop(
        columns=[
            "_natural_key",
            "_revision_fp",
            "_created_sort",
            "_row_order",
        ],
        errors="ignore",
    )
    return normalize_fundamental_snapshots(out.reset_index(drop=True)), int(removed)


def append_fundamental_snapshot(
    existing: pd.DataFrame | None,
    record: dict,
) -> pd.DataFrame:
    """
    Append a reviewed revision, but do not create a byte-for-byte economic
    duplicate when the user repeats the same save action.
    """
    out = normalize_fundamental_snapshots(existing)
    new_key = _snapshot_natural_key(record)
    new_fp = _snapshot_revision_fingerprint(record)

    for _, row in out.iterrows():
        existing_record = row.to_dict()
        if (
            _snapshot_natural_key(existing_record) == new_key
            and _snapshot_revision_fingerprint(existing_record) == new_fp
        ):
            return out

    row = pd.DataFrame([record])
    row = normalize_fundamental_snapshots(row)
    return pd.concat([out, row], ignore_index=True)


