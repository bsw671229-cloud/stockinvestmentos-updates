from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


RECOVERY_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
    "next_action",
]


RECOVERY_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


RECOVERY_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "recovery_status",
    "csv_pass",
    "csv_fail",
    "current_csv_files",
    "backup_exists",
    "backup_modified",
    "backup_age_days",
    "backup_files",
    "backup_coverage_proxy",
    "recent_save_failures",
    "blocking_issues",
    "review_issues",
    "restore_authorization",
    "note",
    "snapshot_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _parse_timestamp(value: Any) -> pd.Timestamp | None:
    raw = _text(value)
    if not raw:
        return None

    ts = pd.to_datetime(
        raw,
        errors="coerce",
        utc=True,
    )
    if pd.isna(ts):
        return None

    return ts


def build_recovery_readiness(
    *,
    csv_pass: int,
    csv_fail: int,
    current_csv_files: int,
    backup_info: dict | None,
    save_events: pd.DataFrame | None = None,
    max_backup_age_days: int = 7,
    recent_event_window: int = 20,
    now: datetime | pd.Timestamp | str | None = None,
) -> dict:
    backup = backup_info or {}
    now_ts = pd.to_datetime(
        now or datetime.now().astimezone(),
        errors="coerce",
        utc=True,
    )
    if pd.isna(now_ts):
        now_ts = pd.Timestamp.now(
            tz="UTC"
        )

    csv_pass_n = max(
        0,
        _int(
            csv_pass
        ),
    )
    csv_fail_n = max(
        0,
        _int(
            csv_fail
        ),
    )
    current_files_n = max(
        0,
        _int(
            current_csv_files
        ),
    )

    backup_exists = _bool(
        backup.get(
            "exists",
            False,
        )
    )
    backup_modified = _text(
        backup.get(
            "modified",
            "",
        )
    )
    backup_files = max(
        0,
        _int(
            backup.get(
                "files",
                0,
            )
        ),
    )

    backup_ts = _parse_timestamp(
        backup_modified
    )

    if backup_ts is None:
        backup_age_days = None
    else:
        backup_age_days = (
            now_ts
            - backup_ts
        ).total_seconds() / 86400.0

    if current_files_n <= 0:
        coverage_proxy = 1.0
    else:
        coverage_proxy = min(
            1.0,
            float(
                backup_files
            )
            / float(
                current_files_n
            ),
        )

    events = (
        pd.DataFrame()
        if save_events is None
        else save_events.copy()
    )

    recent_save_failures = 0
    if (
        not events.empty
        and "status" in events.columns
    ):
        window = events.tail(
            max(
                1,
                _int(
                    recent_event_window
                ),
            )
        )
        recent_save_failures = int(
            window[
                "status"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq(
                "FAIL"
            )
            .sum()
        )

    checks = []
    blocking_issues = []
    review_issues = []

    # 1) Current CSV health
    if csv_fail_n > 0:
        checks.append(
            {
                "check":
                    "Current CSV Readability",
                "status":
                    "BLOCKED",
                "detail":
                    f"CSV PASS {csv_pass_n} · FAIL {csv_fail_n}",
                "blocking":
                    "YES",
                "next_action":
                    "읽기 실패 CSV를 먼저 복구한 뒤 Backup/Recovery 검토",
            }
        )
        blocking_issues.append(
            "CURRENT_CSV_FAIL"
        )
    else:
        checks.append(
            {
                "check":
                    "Current CSV Readability",
                "status":
                    "PASS",
                "detail":
                    f"CSV PASS {csv_pass_n} · FAIL 0",
                "blocking":
                    "NO",
                "next_action":
                    "",
            }
        )

    # 2) Backup existence
    if not backup_exists:
        checks.append(
            {
                "check":
                    "Full User Backup Exists",
                "status":
                    "REVIEW",
                "detail":
                    "No full backup found",
                "blocking":
                    "NO",
                "next_action":
                    "Save Center에서 사용자 데이터 전체 백업 생성",
            }
        )
        review_issues.append(
            "FULL_BACKUP_MISSING"
        )
    else:
        checks.append(
            {
                "check":
                    "Full User Backup Exists",
                "status":
                    "PASS",
                "detail":
                    f"backup files {backup_files}",
                "blocking":
                    "NO",
                "next_action":
                    "",
            }
        )

    # 3) Backup timestamp / freshness
    if backup_exists:
        if backup_ts is None:
            checks.append(
                {
                    "check":
                        "Backup Freshness",
                    "status":
                        "REVIEW",
                    "detail":
                        "Backup modified time is not parseable",
                    "blocking":
                        "NO",
                    "next_action":
                        "최근 백업 timestamp를 확인하고 새 전체 백업 생성",
                }
            )
            review_issues.append(
                "BACKUP_TIMESTAMP_INVALID"
            )
        elif backup_age_days < (-5.0 / 1440.0):
            checks.append(
                {
                    "check":
                        "Backup Freshness",
                    "status":
                        "REVIEW",
                    "detail":
                        f"backup timestamp is in the future ({backup_age_days:.2f} days)",
                    "blocking":
                        "NO",
                    "next_action":
                        "PC 시간대/시계를 확인하고 새 전체 백업 생성",
                }
            )
            review_issues.append(
                "BACKUP_TIMESTAMP_FUTURE"
            )
        elif backup_age_days > max(
            1,
            _int(
                max_backup_age_days
            ),
        ):
            checks.append(
                {
                    "check":
                        "Backup Freshness",
                    "status":
                        "REVIEW",
                    "detail":
                        f"backup age {backup_age_days:.1f} days",
                    "blocking":
                        "NO",
                    "next_action":
                        "현재 데이터 기준 새 전체 백업 생성",
                }
            )
            review_issues.append(
                "BACKUP_STALE"
            )
        else:
            checks.append(
                {
                    "check":
                        "Backup Freshness",
                    "status":
                        "PASS",
                    "detail":
                        f"backup age {max(0.0, backup_age_days):.1f} days",
                    "blocking":
                        "NO",
                    "next_action":
                        "",
                }
            )
    else:
        checks.append(
            {
                "check":
                    "Backup Freshness",
                "status":
                    "REVIEW",
                "detail":
                    "No backup to age-check",
                "blocking":
                    "NO",
                "next_action":
                    "전체 백업 생성 후 freshness 확인",
            }
        )

    # 4) Coverage proxy
    if backup_exists:
        if backup_files < current_files_n:
            checks.append(
                {
                    "check":
                        "Backup Coverage Proxy",
                    "status":
                        "REVIEW",
                    "detail":
                        (
                            f"backup files {backup_files} < "
                            f"current CSV files {current_files_n}"
                        ),
                    "blocking":
                        "NO",
                    "next_action":
                        "현재 CSV 세트를 포함하도록 새 전체 백업 생성",
                }
            )
            review_issues.append(
                "BACKUP_COVERAGE_PROXY_LOW"
            )
        else:
            checks.append(
                {
                    "check":
                        "Backup Coverage Proxy",
                    "status":
                        "PASS",
                    "detail":
                        (
                            f"backup files {backup_files} · "
                            f"current CSV files {current_files_n}"
                        ),
                    "blocking":
                        "NO",
                    "next_action":
                        "",
                }
            )
    else:
        checks.append(
            {
                "check":
                    "Backup Coverage Proxy",
                "status":
                    "REVIEW",
                "detail":
                    "No backup to compare",
                "blocking":
                    "NO",
                "next_action":
                    "전체 백업 생성",
            }
        )

    # 5) Recent save failures
    if recent_save_failures > 0:
        checks.append(
            {
                "check":
                    "Recent Save Events",
                "status":
                    "REVIEW",
                "detail":
                    (
                        f"FAIL {recent_save_failures} in last "
                        f"{max(1, _int(recent_event_window))} events"
                    ),
                "blocking":
                    "NO",
                "next_action":
                    "최근 저장 실패 원인과 현재 파일 상태를 확인",
            }
        )
        review_issues.append(
            "RECENT_SAVE_FAILURES"
        )
    else:
        checks.append(
            {
                "check":
                    "Recent Save Events",
                "status":
                    "PASS",
                "detail":
                    "No recent save failures",
                "blocking":
                    "NO",
                "next_action":
                    "",
            }
        )

    if blocking_issues:
        recovery_status = "BLOCKED"
    elif review_issues:
        recovery_status = "REVIEW"
    else:
        recovery_status = "PASS"

    return {
        "recovery_status":
            recovery_status,
        "csv_pass":
            csv_pass_n,
        "csv_fail":
            csv_fail_n,
        "current_csv_files":
            current_files_n,
        "backup_exists":
            backup_exists,
        "backup_modified":
            backup_modified,
        "backup_age_days":
            backup_age_days,
        "backup_files":
            backup_files,
        "backup_coverage_proxy":
            coverage_proxy,
        "recent_save_failures":
            recent_save_failures,
        "blocking_issues":
            list(
                dict.fromkeys(
                    blocking_issues
                )
            ),
        "review_issues":
            list(
                dict.fromkeys(
                    review_issues
                )
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                RECOVERY_CHECK_COLS,
            ),
        "restore_authorization":
            "NONE",
    }


def build_recovery_queue(
    readiness: dict | None,
) -> pd.DataFrame:
    result = readiness or {}
    rows = []

    for issue in result.get(
        "blocking_issues",
        [],
    ):
        rows.append(
            {
                "priority":
                    "RR0",
                "status":
                    "BLOCKED",
                "issue":
                    _text(
                        issue
                    ),
                "next_action":
                    "Save Center에서 현재 CSV Readability를 먼저 복구",
                "go_to":
                    "Save Center",
            }
        )

    review_action_map = {
        "FULL_BACKUP_MISSING":
            "Save Center에서 사용자 데이터 전체 백업 생성",
        "BACKUP_TIMESTAMP_INVALID":
            "최근 백업 timestamp 확인 후 새 전체 백업 생성",
        "BACKUP_TIMESTAMP_FUTURE":
            "PC 시간대/시계를 확인하고 새 전체 백업 생성",
        "BACKUP_STALE":
            "현재 데이터 기준 새 전체 백업 생성",
        "BACKUP_COVERAGE_PROXY_LOW":
            "현재 CSV 세트를 포함하도록 새 전체 백업 생성",
        "RECENT_SAVE_FAILURES":
            "최근 저장 실패 기록을 확인하고 현재 저장상태 재검사",
    }

    for issue in result.get(
        "review_issues",
        [],
    ):
        priority = (
            "RR1"
            if issue
            in {
                "FULL_BACKUP_MISSING",
                "BACKUP_TIMESTAMP_INVALID",
                "BACKUP_TIMESTAMP_FUTURE",
            }
            else "RR2"
        )

        rows.append(
            {
                "priority":
                    priority,
                "status":
                    "REVIEW",
                "issue":
                    _text(
                        issue
                    ),
                "next_action":
                    review_action_map.get(
                        issue,
                        "Recovery readiness 검토",
                    ),
                "go_to":
                    "Save Center",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            RECOVERY_QUEUE_COLS
        )

    order = {
        "RR0": 0,
        "RR1": 1,
        "RR2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            RECOVERY_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )


def build_recovery_snapshot(
    readiness: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    result = readiness or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    payload = {
        "recovery_status":
            _text(
                result.get(
                    "recovery_status"
                )
            ),
        "csv_pass":
            _int(
                result.get(
                    "csv_pass"
                )
            ),
        "csv_fail":
            _int(
                result.get(
                    "csv_fail"
                )
            ),
        "current_csv_files":
            _int(
                result.get(
                    "current_csv_files"
                )
            ),
        "backup_exists":
            bool(
                result.get(
                    "backup_exists",
                    False,
                )
            ),
        "backup_modified":
            _text(
                result.get(
                    "backup_modified"
                )
            ),
        "backup_age_days":
            (
                None
                if result.get(
                    "backup_age_days"
                )
                is None
                else round(
                    float(
                        result.get(
                            "backup_age_days"
                        )
                    ),
                    6,
                )
            ),
        "backup_files":
            _int(
                result.get(
                    "backup_files"
                )
            ),
        "backup_coverage_proxy":
            round(
                float(
                    result.get(
                        "backup_coverage_proxy",
                        0.0,
                    )
                    or 0.0
                ),
                6,
            ),
        "recent_save_failures":
            _int(
                result.get(
                    "recent_save_failures"
                )
            ),
        "blocking_issues":
            " | ".join(
                result.get(
                    "blocking_issues",
                    [],
                )
            ),
        "review_issues":
            " | ".join(
                result.get(
                    "review_issues",
                    [],
                )
            ),
        "restore_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        payload
    )

    snapshot_id = (
        "RRS-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot_hash[:8]
    )

    return {
        "snapshot_id":
            snapshot_id,
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
