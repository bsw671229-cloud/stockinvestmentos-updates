from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.backup_manifest_recovery import (
    recovery_point_lock_integrity,
)


RECOVERY_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


DR_RUNBOOK_LOCK_COLS = [
    "runbook_lock_id",
    "created_at",
    "runbook_version",
    "current_manifest_sha256",
    "recovery_point_id",
    "recovery_point_record_hash",
    "recovery_point_integrity_status",
    "recovery_release_gate",
    "technical_pass",
    "technical_fail",
    "operating_status",
    "rotation_status",
    "rotation_archive_candidates",
    "simulation_plan_hash",
    "simulation_step_count",
    "audit_closure_status",
    "release_evidence_confirmed",
    "emergency_copy_plan_confirmed",
    "isolated_staging_confirmed",
    "no_auto_delete_restore_confirmed",
    "human_review_confirmed",
    "restore_authorization",
    "issues",
    "note",
    "record_hash",
]


RECOVERY_RELEASE_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _matching_lock(
    drift: dict | None,
) -> dict:
    dr = drift or {}
    lock = dr.get(
        "matching_recovery_point"
    )
    return lock if isinstance(lock, dict) else {}


def _simulation_plan_hash(
    simulation: dict | None,
) -> str:
    sim = simulation or {}
    steps = sim.get(
        "steps"
    )

    if (
        isinstance(
            steps,
            pd.DataFrame,
        )
        and not steps.empty
    ):
        payload = steps.fillna(
            ""
        ).to_dict(
            orient="records"
        )
    else:
        payload = []

    return _hash(
        {
            "simulation_status":
                _text(
                    sim.get(
                        "simulation_status"
                    )
                ),
            "steps":
                payload,
            "restore_authorization":
                _text(
                    sim.get(
                        "restore_authorization"
                    )
                ),
        }
    )


def build_recovery_release_gate(
    readiness: dict | None,
    verification: dict | None,
    dry_run: dict | None,
    drift: dict | None,
    rotation: dict | None,
    simulation: dict | None,
) -> dict:
    ready = readiness or {}
    verify = verification or {}
    dry = dry_run or {}
    dr = drift or {}
    rot = rotation or {}
    sim = simulation or {}

    lock = _matching_lock(
        dr
    )
    lock_integrity = (
        recovery_point_lock_integrity(
            lock
        )[
            "status"
        ]
        if lock
        else "MISSING"
    )

    checks = []

    def technical(
        check: str,
        passed: bool,
        detail: str,
        action: str,
    ):
        checks.append(
            {
                "layer":
                    "TECHNICAL",
                "check":
                    check,
                "status":
                    (
                        "PASS"
                        if passed
                        else "FAIL"
                    ),
                "detail":
                    detail,
                "action":
                    (
                        ""
                        if passed
                        else action
                    ),
            }
        )

    technical(
        "Recovery Readiness",
        _text(
            ready.get(
                "recovery_status"
            )
        ).upper()
        == "PASS",
        _text(
            ready.get(
                "recovery_status"
            )
        )
        or "MISSING",
        "Save Center 1D의 CSV/Backup Freshness/Coverage를 먼저 PASS로 복구",
    )

    technical(
        "Backup Manifest Integrity",
        _text(
            verify.get(
                "manifest_status"
            )
        ).upper()
        == "PASS",
        (
            f"{_text(verify.get('manifest_status')) or 'MISSING'} · "
            f"missing {_int(verify.get('missing_files'))} · "
            f"hash mismatch {_int(verify.get('hash_mismatch'))}"
        ),
        "Save Center 1E Manifest Verification 문제를 먼저 해결",
    )

    technical(
        "Restore Dry-run Readability",
        _text(
            dry.get(
                "dryrun_status"
            )
        ).upper()
        == "PASS",
        (
            f"{_text(dry.get('dryrun_status')) or 'MISSING'} · "
            f"parse fail {_int(dry.get('parse_fail'))}"
        ),
        "Save Center 1E Dry-run parse 실패를 먼저 해결",
    )

    technical(
        "Recovery Point Current",
        _text(
            dr.get(
                "drift_status"
            )
        ).upper()
        == "CURRENT",
        (
            f"{_text(dr.get('drift_status')) or 'MISSING'} · "
            f"{_text(dr.get('matching_recovery_point_id')) or 'NO_LOCK'}"
        ),
        "최신 Manifest에 대해 Recovery Point Lock을 검증/생성",
    )

    technical(
        "Recovery Point Lock Integrity",
        lock_integrity
        == "OK",
        lock_integrity,
        "Recovery Point Lock immutable hash 무결성 확인",
    )

    technical(
        "Restore Simulation Readiness",
        _text(
            sim.get(
                "simulation_status"
            )
        ).upper()
        == "READY",
        (
            f"{_text(sim.get('simulation_status')) or 'MISSING'} · "
            f"steps {_int(sim.get('step_count'))}"
        ),
        "CURRENT Recovery Point와 Manifest/Dry-run 상태를 확인",
    )

    rotation_status = _text(
        rot.get(
            "rotation_status"
        )
    ).upper()

    technical(
        "Backup Rotation Integrity",
        rotation_status
        != "INTEGRITY_REVIEW",
        rotation_status
        or "MISSING",
        "Rotation 대상 Recovery Point Lock Hash 무결성을 확인",
    )

    auth_values = [
        _text(
            ready.get(
                "restore_authorization"
            )
        ).upper(),
        _text(
            dry.get(
                "restore_authorization"
            )
        ).upper(),
        _text(
            dr.get(
                "restore_authorization"
            )
        ).upper(),
        _text(
            sim.get(
                "restore_authorization"
            )
        ).upper(),
        _text(
            lock.get(
                "restore_authorization"
            )
        ).upper()
        if lock
        else "NONE",
    ]

    auth_ok = all(
        value == "NONE"
        for value in auth_values
    )

    technical(
        "Restore Authorization Invariant",
        auth_ok,
        (
            "NONE"
            if auth_ok
            else " | ".join(
                auth_values
            )
        ),
        "Recovery chain에서 Restore Authorization이 NONE인지 확인",
    )

    technical_fail = sum(
        1
        for row in checks
        if (
            row[
                "layer"
            ]
            == "TECHNICAL"
            and row[
                "status"
            ]
            == "FAIL"
        )
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    archive_candidates = _int(
        rot.get(
            "archive_candidates"
        )
    )

    operating_status = (
        "REVIEW"
        if (
            rotation_status == "REVIEW"
            or archive_candidates > 0
        )
        else "PASS"
    )

    checks.append(
        {
            "layer":
                "OPERATING",
            "check":
                "Backup Rotation / Retention Review",
            "status":
                operating_status,
            "detail":
                (
                    f"rotation {rotation_status or 'MISSING'} · "
                    f"archive candidates {archive_candidates}"
                ),
            "action":
                (
                    ""
                    if operating_status == "PASS"
                    else "오래된 Recovery Point를 archive 후보로만 Human Review; 자동 삭제 금지"
                ),
        }
    )

    return {
        "release_gate":
            release_gate,
        "technical_pass":
            sum(
                1
                for row in checks
                if (
                    row[
                        "layer"
                    ]
                    == "TECHNICAL"
                    and row[
                        "status"
                    ]
                    == "PASS"
                )
            ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "archive_candidates":
            archive_candidates,
        "matching_recovery_point_id":
            _text(
                dr.get(
                    "matching_recovery_point_id"
                )
            ),
        "matching_lock_integrity":
            lock_integrity,
        "simulation_plan_hash":
            _simulation_plan_hash(
                sim
            ),
        "simulation_step_count":
            _int(
                sim.get(
                    "step_count"
                )
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                RECOVERY_RELEASE_CHECK_COLS,
            ),
        "restore_authorization":
            "NONE",
    }


def latest_matching_runbook_lock(
    locks: pd.DataFrame | None,
    manifest_sha256: str,
) -> dict:
    if (
        locks is None
        or locks.empty
        or "current_manifest_sha256"
        not in locks.columns
    ):
        return {}

    manifest = _text(
        manifest_sha256
    ).lower()

    hit = locks.loc[
        locks[
            "current_manifest_sha256"
        ]
        .fillna("")
        .astype(str)
        .str.lower()
        .eq(
            manifest
        )
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit[
            "_ts"
        ] = pd.to_datetime(
            hit[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        hit = hit.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        hit.iloc[
            0
        ]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def validate_dr_runbook_lock(
    release_gate: dict | None,
    drift: dict | None,
    simulation: dict | None,
    existing_runbook: dict | None,
    *,
    release_evidence_confirmed: bool,
    emergency_copy_plan_confirmed: bool,
    isolated_staging_confirmed: bool,
    no_auto_delete_restore_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    release = release_gate or {}
    dr = drift or {}
    sim = simulation or {}
    existing = existing_runbook or {}

    issues = []

    if _text(
        release.get(
            "release_gate"
        )
    ).upper() != "PASS":
        issues.append(
            "RECOVERY_RELEASE_GATE_PASS_REQUIRED"
        )

    if _text(
        dr.get(
            "drift_status"
        )
    ).upper() != "CURRENT":
        issues.append(
            "CURRENT_RECOVERY_POINT_REQUIRED"
        )

    if _text(
        release.get(
            "matching_lock_integrity"
        )
    ).upper() != "OK":
        issues.append(
            "RECOVERY_POINT_LOCK_INTEGRITY_OK_REQUIRED"
        )

    if _text(
        sim.get(
            "simulation_status"
        )
    ).upper() != "READY":
        issues.append(
            "RESTORE_SIMULATION_READY_REQUIRED"
        )

    if existing:
        integrity = dr_runbook_lock_integrity(
            existing
        )
        if (
            integrity[
                "status"
            ]
            == "OK"
            and _text(
                existing.get(
                    "audit_closure_status"
                )
            ).upper()
            == "RECOVERY_AUDIT_CLOSED"
        ):
            issues.append(
                "CURRENT_RUNBOOK_ALREADY_LOCKED"
            )

    confirmations = [
        (
            release_evidence_confirmed,
            "RELEASE_EVIDENCE_CONFIRMATION_REQUIRED",
        ),
        (
            emergency_copy_plan_confirmed,
            "EMERGENCY_COPY_PLAN_CONFIRMATION_REQUIRED",
        ),
        (
            isolated_staging_confirmed,
            "ISOLATED_STAGING_CONFIRMATION_REQUIRED",
        ),
        (
            no_auto_delete_restore_confirmed,
            "NO_AUTO_DELETE_RESTORE_CONFIRMATION_REQUIRED",
        ),
        (
            human_review_confirmed,
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED",
        ),
    ]

    for passed, issue in confirmations:
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    blocking = [
        x
        for x in issues
        if x
        != "CURRENT_RUNBOOK_ALREADY_LOCKED"
    ]

    if (
        existing
        and "CURRENT_RUNBOOK_ALREADY_LOCKED"
        in issues
        and not blocking
    ):
        gate = "REVIEW"
        status = "ALREADY_LOCKED"
    elif not issues:
        gate = "PASS"
        status = "DR_RUNBOOK_LOCKED"
    else:
        gate = "REVIEW"
        status = "DRAFT"

    return {
        "runbook_gate":
            gate,
        "runbook_status":
            status,
        "audit_closure_status":
            (
                "RECOVERY_AUDIT_CLOSED"
                if gate == "PASS"
                else (
                    "RECOVERY_AUDIT_CLOSED"
                    if status == "ALREADY_LOCKED"
                    else "OPEN"
                )
            ),
        "restore_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _runbook_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "release_evidence_confirmed",
        "emergency_copy_plan_confirmed",
        "isolated_staging_confirmed",
        "no_auto_delete_restore_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in DR_RUNBOOK_LOCK_COLS:
        if col == "record_hash":
            continue

        if col in bool_fields:
            payload[
                col
            ] = bool(
                _bool(
                    row.get(
                        col
                    )
                )
            )
        else:
            payload[
                col
            ] = _text(
                row.get(
                    col
                )
            )

    return payload


def build_dr_runbook_lock_record(
    release_gate: dict,
    drift: dict,
    rotation: dict,
    simulation: dict,
    validation: dict,
    *,
    current_manifest_sha256: str,
    release_evidence_confirmed: bool,
    emergency_copy_plan_confirmed: bool,
    isolated_staging_confirmed: bool,
    no_auto_delete_restore_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    lock = _matching_lock(
        drift
    )

    manifest = _text(
        current_manifest_sha256
    ).lower()

    plan_hash = _simulation_plan_hash(
        simulation
    )

    runbook_lock_id = (
        "DRL-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + (
            manifest[:8]
            if manifest
            else "NOHASH"
        )
    )

    row = {
        "runbook_lock_id":
            runbook_lock_id,
        "created_at":
            now,
        "runbook_version":
            "DR-RUNBOOK-v1",
        "current_manifest_sha256":
            manifest,
        "recovery_point_id":
            _text(
                drift.get(
                    "matching_recovery_point_id"
                )
            ),
        "recovery_point_record_hash":
            _text(
                lock.get(
                    "record_hash"
                )
            ),
        "recovery_point_integrity_status":
            _text(
                release_gate.get(
                    "matching_lock_integrity"
                )
            ),
        "recovery_release_gate":
            _text(
                release_gate.get(
                    "release_gate"
                )
            ),
        "technical_pass":
            _int(
                release_gate.get(
                    "technical_pass"
                )
            ),
        "technical_fail":
            _int(
                release_gate.get(
                    "technical_fail"
                )
            ),
        "operating_status":
            _text(
                release_gate.get(
                    "operating_status"
                )
            ),
        "rotation_status":
            _text(
                rotation.get(
                    "rotation_status"
                )
            ),
        "rotation_archive_candidates":
            _int(
                rotation.get(
                    "archive_candidates"
                )
            ),
        "simulation_plan_hash":
            plan_hash,
        "simulation_step_count":
            _int(
                simulation.get(
                    "step_count"
                )
            ),
        "audit_closure_status":
            _text(
                validation.get(
                    "audit_closure_status"
                )
            ),
        "release_evidence_confirmed":
            bool(
                release_evidence_confirmed
            ),
        "emergency_copy_plan_confirmed":
            bool(
                emergency_copy_plan_confirmed
            ),
        "isolated_staging_confirmed":
            bool(
                isolated_staging_confirmed
            ),
        "no_auto_delete_restore_confirmed":
            bool(
                no_auto_delete_restore_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "restore_authorization":
            "NONE",
        "issues":
            " | ".join(
                validation.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _runbook_payload(
            row
        )
    )

    return row


def dr_runbook_lock_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status":
                "MISSING",
            "calculated_hash":
                "",
        }

    calculated = _hash(
        _runbook_payload(
            record
        )
    )

    return {
        "status":
            (
                "OK"
                if stored
                == calculated
                else "MISMATCH"
            ),
        "calculated_hash":
            calculated,
    }


def build_recovery_release_queue(
    release_gate: dict | None,
    runbook_locks: pd.DataFrame | None,
    current_manifest_sha256: str,
) -> pd.DataFrame:
    release = release_gate or {}
    rows = []

    if _text(
        release.get(
            "release_gate"
        )
    ).upper() != "PASS":
        rows.append(
            {
                "priority":
                    "DR0",
                "status":
                    "BLOCKED",
                "issue":
                    "RECOVERY_RELEASE_GATE_BLOCKED",
                "next_action":
                    "Save Center 1D~1F의 Recovery technical gate를 먼저 PASS로 복구",
                "go_to":
                    "Save Center",
            }
        )
    else:
        latest = latest_matching_runbook_lock(
            runbook_locks,
            current_manifest_sha256,
        )

        if not latest:
            rows.append(
                {
                    "priority":
                        "DR1",
                    "status":
                        "REVIEW",
                    "issue":
                        "CURRENT_RECOVERY_RUNBOOK_NOT_LOCKED",
                    "next_action":
                        "현재 Recovery Point에 대한 DR Runbook을 Human Review 후 Lock",
                    "go_to":
                        "Save Center",
                }
            )
        else:
            integrity = dr_runbook_lock_integrity(
                latest
            )

            if integrity[
                "status"
            ] != "OK":
                rows.append(
                    {
                        "priority":
                            "DR0",
                        "status":
                            "BLOCKED",
                        "issue":
                            "DR_RUNBOOK_LOCK_HASH_MISMATCH",
                        "next_action":
                            "Disaster Recovery Runbook Lock immutable hash 확인",
                        "go_to":
                            "Save Center",
                    }
                )

    if _text(
        release.get(
            "operating_status"
        )
    ).upper() == "REVIEW":
        rows.append(
            {
                "priority":
                    "DR2",
                "status":
                    "REVIEW",
                "issue":
                    "BACKUP_ROTATION_OPERATING_REVIEW",
                "next_action":
                    "오래된 Recovery Point archive 후보를 Human Review; 자동 삭제 금지",
                "go_to":
                    "Save Center",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            RECOVERY_RELEASE_QUEUE_COLS
        )

    order = {
        "DR0": 0,
        "DR1": 1,
        "DR2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            RECOVERY_RELEASE_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )
