from __future__ import annotations

from datetime import date
from typing import Any
import hashlib

import pandas as pd


COMPRESSED_GROUP_COLS = [
    "group_id",
    "priority",
    "category",
    "go_to",
    "status",
    "item_count",
    "subject_count",
    "bucket_summary",
    "earliest_due",
    "min_days_to_due",
    "sample_subjects",
    "sample_issues",
    "sample_actions",
]


SESSION_WORKLIST_COLS = [
    "session_rank",
    "priority",
    "phase",
    "category",
    "status",
    "item_count",
    "subject_count",
    "sample_subjects",
    "sample_issues",
    "next_action",
    "go_to",
    "group_id",
]


DETAIL_COLS = [
    "bucket",
    "due_date",
    "days_to_due",
    "category",
    "subject",
    "status",
    "issue",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    try:
        out = float(value)
    except Exception:
        return None

    if pd.isna(out):
        return None

    return out


def _unique_text(
    values: pd.Series,
    *,
    limit: int = 3,
) -> str:
    seen = []
    for value in values.tolist():
        text = _text(value)
        if not text:
            continue
        if text not in seen:
            seen.append(text)
        if len(seen) >= max(1, int(limit)):
            break

    return " | ".join(seen)


def _all_unique_text(
    values: pd.Series,
) -> list[str]:
    seen = []
    for value in values.tolist():
        text = _text(value)
        if text and text not in seen:
            seen.append(text)
    return seen


def _priority_for_row(
    row: dict,
) -> str:
    bucket = _text(
        row.get(
            "bucket"
        )
    ).upper()
    status = _text(
        row.get(
            "status"
        )
    ).upper()
    days = _num(
        row.get(
            "days_to_due"
        )
    )

    hard_status_tokens = [
        "BLOCKED",
        "FAIL",
        "INVALID",
        "MISMATCH",
        "BREACH",
    ]

    if any(
        token in status
        for token in hard_status_tokens
    ):
        return "RQ0"

    if (
        "OVERDUE" in bucket
        or (
            days is not None
            and days < 0
        )
    ):
        return "RQ0"

    if (
        "NOW" in bucket
        or "TODAY" in bucket
        or (
            days is not None
            and days == 0
        )
    ):
        return "RQ1"

    if (
        "NEXT 7" in bucket
        or (
            days is not None
            and 1 <= days <= 7
        )
    ):
        return "RQ2"

    if (
        "NEXT 30" in bucket
        or (
            days is not None
            and 8 <= days <= 30
        )
    ):
        return "RQ3"

    return "RQ4"


def _phase_for_priority(
    priority: str,
) -> str:
    return {
        "RQ0":
            "INTEGRITY / OVERDUE",
        "RQ1":
            "TODAY / NOW",
        "RQ2":
            "NEXT 7 DAYS",
        "RQ3":
            "NEXT 30 DAYS",
        "RQ4":
            "NO DATE / ROUTINE",
    }.get(
        _text(
            priority
        ).upper(),
        "REVIEW",
    )


def _normalize_queue(
    queue: pd.DataFrame | None,
) -> pd.DataFrame:
    df = (
        pd.DataFrame()
        if queue is None
        else queue.copy()
    )

    for col in DETAIL_COLS:
        if col not in df.columns:
            df[
                col
            ] = ""

    if df.empty:
        df[
            "_priority"
        ] = pd.Series(
            dtype="object"
        )
        df[
            "_group_id"
        ] = pd.Series(
            dtype="object"
        )
        return df

    df[
        "_priority"
    ] = df.apply(
        lambda row: _priority_for_row(
            row.to_dict()
        ),
        axis=1,
    )

    # Group by operational route, not by every individual subject.
    # This intentionally compresses repeated company-level items into one
    # human-review action group while the original rows remain drillable.
    def group_id(
        row: pd.Series,
    ) -> str:
        key = "|".join(
            [
                _text(
                    row.get(
                        "_priority"
                    )
                ),
                _text(
                    row.get(
                        "category"
                    )
                )
                or "UNCLASSIFIED",
                _text(
                    row.get(
                        "go_to"
                    )
                )
                or "Review Queue",
                _text(
                    row.get(
                        "status"
                    )
                )
                or "REVIEW",
            ]
        )

        return (
            "RQG-"
            + hashlib.sha256(
                key.encode(
                    "utf-8"
                )
            ).hexdigest()[:10]
        )

    df[
        "_group_id"
    ] = df.apply(
        group_id,
        axis=1,
    )

    return df


def compress_review_queue(
    queue: pd.DataFrame | None,
    *,
    sample_limit: int = 3,
) -> dict:
    df = _normalize_queue(
        queue
    )

    if df.empty:
        return {
            "raw_items":
                0,
            "action_groups":
                0,
            "attention_items":
                0,
            "attention_groups":
                0,
            "compression_ratio":
                0.0,
            "groups":
                pd.DataFrame(
                    columns=
                    COMPRESSED_GROUP_COLS
                ),
            "items":
                df,
        }

    rows = []

    for group_id, part in df.groupby(
        "_group_id",
        sort=False,
    ):
        priority = _text(
            part[
                "_priority"
            ].iloc[
                0
            ]
        )
        category = (
            _text(
                part[
                    "category"
                ].iloc[
                    0
                ]
            )
            or "UNCLASSIFIED"
        )
        go_to = (
            _text(
                part[
                    "go_to"
                ].iloc[
                    0
                ]
            )
            or "Review Queue"
        )
        status = (
            _text(
                part[
                    "status"
                ].iloc[
                    0
                ]
            )
            or "REVIEW"
        )

        days = pd.to_numeric(
            part[
                "days_to_due"
            ],
            errors="coerce",
        )
        due_dates = (
            part[
                "due_date"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
        )
        due_dates = due_dates.loc[
            due_dates.ne("")
        ]

        subjects = _all_unique_text(
            part[
                "subject"
            ]
        )

        buckets = _all_unique_text(
            part[
                "bucket"
            ]
        )

        rows.append(
            {
                "group_id":
                    group_id,
                "priority":
                    priority,
                "category":
                    category,
                "go_to":
                    go_to,
                "status":
                    status,
                "item_count":
                    int(
                        len(
                            part
                        )
                    ),
                "subject_count":
                    int(
                        len(
                            subjects
                        )
                    ),
                "bucket_summary":
                    " | ".join(
                        buckets[
                            :max(
                                1,
                                int(
                                    sample_limit
                                ),
                            )
                        ]
                    ),
                "earliest_due":
                    (
                        sorted(
                            due_dates.tolist()
                        )[
                            0
                        ]
                        if not due_dates.empty
                        else ""
                    ),
                "min_days_to_due":
                    (
                        float(
                            days.min()
                        )
                        if days.notna().any()
                        else None
                    ),
                "sample_subjects":
                    _unique_text(
                        part[
                            "subject"
                        ],
                        limit=sample_limit,
                    ),
                "sample_issues":
                    _unique_text(
                        part[
                            "issue"
                        ],
                        limit=sample_limit,
                    ),
                "sample_actions":
                    _unique_text(
                        part[
                            "next_action"
                        ],
                        limit=sample_limit,
                    ),
            }
        )

    groups = pd.DataFrame(
        rows,
        columns=
        COMPRESSED_GROUP_COLS,
    )

    order = {
        "RQ0": 0,
        "RQ1": 1,
        "RQ2": 2,
        "RQ3": 3,
        "RQ4": 4,
    }

    groups[
        "_p"
    ] = groups[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    groups = (
        groups.sort_values(
            [
                "_p",
                "item_count",
                "category",
            ],
            ascending=[
                True,
                False,
                True,
            ],
            na_position="last",
        )
        .drop(
            columns=[
                "_p"
            ]
        )
        .reset_index(
            drop=True
        )
    )

    attention_mask = df[
        "_priority"
    ].isin(
        [
            "RQ0",
            "RQ1",
        ]
    )

    attention_group_mask = groups[
        "priority"
    ].isin(
        [
            "RQ0",
            "RQ1",
        ]
    )

    raw_items = int(
        len(
            df
        )
    )
    action_groups = int(
        len(
            groups
        )
    )

    return {
        "raw_items":
            raw_items,
        "action_groups":
            action_groups,
        "attention_items":
            int(
                attention_mask.sum()
            ),
        "attention_groups":
            int(
                attention_group_mask.sum()
            ),
        "compression_ratio":
            (
                float(
                    raw_items
                )
                / float(
                    action_groups
                )
                if action_groups > 0
                else 0.0
            ),
        "groups":
            groups,
        "items":
            df,
    }


def build_session_worklist(
    compression: dict | None,
    *,
    max_groups: int = 5,
) -> pd.DataFrame:
    result = compression or {}
    groups = result.get(
        "groups"
    )

    if (
        not isinstance(
            groups,
            pd.DataFrame,
        )
        or groups.empty
    ):
        return pd.DataFrame(
            columns=
            SESSION_WORKLIST_COLS
        )

    n = max(
        1,
        int(
            max_groups
        ),
    )

    selected = groups.head(
        n
    ).copy()

    rows = []

    for rank, (_, row) in enumerate(
        selected.iterrows(),
        start=1,
    ):
        rows.append(
            {
                "session_rank":
                    rank,
                "priority":
                    _text(
                        row.get(
                            "priority"
                        )
                    ),
                "phase":
                    _phase_for_priority(
                        row.get(
                            "priority"
                        )
                    ),
                "category":
                    _text(
                        row.get(
                            "category"
                        )
                    ),
                "status":
                    _text(
                        row.get(
                            "status"
                        )
                    ),
                "item_count":
                    int(
                        row.get(
                            "item_count",
                            0,
                        )
                        or 0
                    ),
                "subject_count":
                    int(
                        row.get(
                            "subject_count",
                            0,
                        )
                        or 0
                    ),
                "sample_subjects":
                    _text(
                        row.get(
                            "sample_subjects"
                        )
                    ),
                "sample_issues":
                    _text(
                        row.get(
                            "sample_issues"
                        )
                    ),
                "next_action":
                    _text(
                        row.get(
                            "sample_actions"
                        )
                    ),
                "go_to":
                    _text(
                        row.get(
                            "go_to"
                        )
                    )
                    or "Review Queue",
                "group_id":
                    _text(
                        row.get(
                            "group_id"
                        )
                    ),
            }
        )

    return pd.DataFrame(
        rows,
        columns=
        SESSION_WORKLIST_COLS,
    )


def group_detail(
    compression: dict | None,
    group_id: str,
) -> pd.DataFrame:
    result = compression or {}
    items = result.get(
        "items"
    )

    if (
        not isinstance(
            items,
            pd.DataFrame,
        )
        or items.empty
        or "_group_id"
        not in items.columns
    ):
        return pd.DataFrame(
            columns=
            DETAIL_COLS
        )

    hit = items.loc[
        items[
            "_group_id"
        ]
        .fillna("")
        .astype(str)
        .eq(
            _text(
                group_id
            )
        )
    ].copy()

    if hit.empty:
        return pd.DataFrame(
            columns=
            DETAIL_COLS
        )

    for col in DETAIL_COLS:
        if col not in hit.columns:
            hit[
                col
            ] = ""

    return hit[
        DETAIL_COLS
    ].reset_index(
        drop=True
    )
