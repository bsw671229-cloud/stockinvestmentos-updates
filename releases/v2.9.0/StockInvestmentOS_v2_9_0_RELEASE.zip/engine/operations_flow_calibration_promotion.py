from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS = [
    "promotion_snapshot_id",
    "created_at",
    "calibration_state",
    "raw_projection_guard",
    "evidence_state",
    "evidence_window_state",
    "qualified_endpoints",
    "observed_intervals",
    "target_intervals",
    "positive_burn_intervals",
    "zero_burn_intervals",
    "negative_burn_intervals",
    "positive_burn_ratio",
    "avg_net_burn_per_interval",
    "latest_net_burn",
    "min_net_burn",
    "max_net_burn",
    "promotion_state",
    "promotion_guard",
    "effective_projection_guard",
    "projection_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PROMOTION_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _net_burn_series(
    calibration: dict | None,
) -> pd.Series:
    cal = calibration or {}
    intervals = cal.get("intervals")

    if not isinstance(intervals, pd.DataFrame) or intervals.empty:
        return pd.Series(dtype=float)

    if "net_burn" not in intervals.columns:
        return pd.Series(dtype=float)

    return pd.to_numeric(
        intervals["net_burn"],
        errors="coerce",
    ).dropna().astype(float).reset_index(drop=True)


def build_flow_calibration_promotion(
    calibration: dict | None,
    evidence: dict | None,
    *,
    min_promotion_intervals: int = 3,
    min_positive_burn_ratio: float = 2 / 3,
    max_negative_intervals: int = 0,
) -> dict:
    cal = calibration or {}
    ev = evidence or {}

    target = max(1, _int(min_promotion_intervals))
    min_ratio = min(1.0, max(0.0, float(min_positive_burn_ratio)))
    max_negative = max(0, _int(max_negative_intervals))

    raw_guard = _text(cal.get("projection_guard")).upper()
    calibration_state = _text(cal.get("calibration_state")).upper()
    evidence_state = _text(ev.get("evidence_state")).upper()
    window_state = _text(ev.get("evidence_window_state")).upper()
    qualified_endpoints = _int(ev.get("qualified_endpoints"))
    observed_intervals = _int(cal.get("observed_intervals"))

    burns = _net_burn_series(cal)

    positive = int(burns.gt(0).sum())
    zero = int(burns.eq(0).sum())
    negative = int(burns.lt(0).sum())
    ratio = (
        float(positive / len(burns))
        if len(burns) > 0
        else 0.0
    )
    avg_burn = (
        float(burns.mean())
        if len(burns) > 0
        else 0.0
    )
    latest_burn = (
        float(burns.iloc[-1])
        if len(burns) > 0
        else 0.0
    )
    min_burn = (
        float(burns.min())
        if len(burns) > 0
        else 0.0
    )
    max_burn = (
        float(burns.max())
        if len(burns) > 0
        else 0.0
    )

    alignment_ok = (
        _text(cal.get("interval_alignment_status")).upper()
        in {"", "OK"}
        and observed_intervals == _int(ev.get("qualified_intervals"))
    )

    if (
        not alignment_ok
        or evidence_state == "INTEGRITY_REVIEW"
        or calibration_state == "INTEGRITY_REVIEW"
    ):
        promotion_state = "PROMOTION_INTEGRITY_REVIEW"
        promotion_guard = "HOLD_INTEGRITY"
    elif observed_intervals < target:
        promotion_state = "PROMOTION_EVIDENCE_MATURING"
        promotion_guard = "HOLD_PROMOTION_PROOF"
    elif avg_burn <= 0:
        promotion_state = "PROMOTION_NO_CLEARING"
        promotion_guard = "HOLD_NO_CLEARING"
    elif negative > max_negative:
        promotion_state = "PROMOTION_ADVERSE_INTERVAL_REVIEW"
        promotion_guard = "HOLD_PROMOTION_STABILITY"
    elif ratio < min_ratio:
        promotion_state = "PROMOTION_MIXED_BURN"
        promotion_guard = "HOLD_PROMOTION_STABILITY"
    else:
        promotion_state = "PROMOTION_READY"
        promotion_guard = "ALLOW_PROJECTION_REVIEW"

    # Promotion can only further constrain an existing Calibration guard.
    # It cannot turn a pre-existing HOLD into ALLOW.
    if raw_guard == "ALLOW_PROJECTION_REVIEW":
        effective_guard = promotion_guard
    else:
        effective_guard = raw_guard or promotion_guard

    return {
        "calibration_state": calibration_state,
        "raw_projection_guard": raw_guard,
        "evidence_state": evidence_state,
        "evidence_window_state": window_state,
        "qualified_endpoints": qualified_endpoints,
        "observed_intervals": observed_intervals,
        "target_intervals": target,
        "positive_burn_intervals": positive,
        "zero_burn_intervals": zero,
        "negative_burn_intervals": negative,
        "positive_burn_ratio": ratio,
        "avg_net_burn_per_interval": avg_burn,
        "latest_net_burn": latest_burn,
        "min_net_burn": min_burn,
        "max_net_burn": max_burn,
        "min_positive_burn_ratio": min_ratio,
        "max_negative_intervals": max_negative,
        "promotion_state": promotion_state,
        "promotion_guard": promotion_guard,
        "effective_projection_guard": effective_guard,
        "projection_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def apply_flow_calibration_promotion_guard(
    calibration: dict | None,
    promotion: dict | None,
) -> dict:
    result = dict(calibration or {})
    promo = promotion or {}

    raw_guard = _text(result.get("projection_guard")).upper()
    effective_guard = (
        _text(promo.get("effective_projection_guard")).upper()
        or raw_guard
    )

    result["calibration_raw_projection_guard"] = raw_guard
    result["promotion_state"] = _text(promo.get("promotion_state"))
    result["promotion_guard"] = _text(promo.get("promotion_guard"))
    result["promotion_target_intervals"] = _int(
        promo.get("target_intervals")
    )
    result["promotion_observed_intervals"] = _int(
        promo.get("observed_intervals")
    )
    result["promotion_positive_burn_ratio"] = _float(
        promo.get("positive_burn_ratio")
    )
    result["promotion_negative_burn_intervals"] = _int(
        promo.get("negative_burn_intervals")
    )
    result["promotion_effective_projection_guard"] = effective_guard
    result["projection_guard"] = effective_guard
    result["projection_authorization"] = "NONE"
    result["execution_authorization"] = "NONE"

    return result


def build_flow_calibration_promotion_queue(
    promotion: dict | None,
) -> pd.DataFrame:
    promo = promotion or {}
    state = _text(promo.get("promotion_state")).upper()

    if state == "PROMOTION_INTEGRITY_REVIEW":
        rows = [{
            "priority": "CP0",
            "status": "BLOCKED",
            "issue": "CALIBRATION_PROMOTION_INTEGRITY_REVIEW",
            "detail": (
                f"intervals {_int(promo.get('observed_intervals'))}/"
                f"{_int(promo.get('target_intervals'))}"
            ),
            "next_action": (
                "Evidence/Calibration interval alignment와 immutable source integrity를 먼저 확인"
            ),
            "go_to": "Operations Control Tower",
        }]
    elif state == "PROMOTION_EVIDENCE_MATURING":
        rows = [{
            "priority": "CP1",
            "status": "WAIT",
            "issue": "CALIBRATION_PROMOTION_EVIDENCE_MATURING",
            "detail": (
                f"closed intervals {_int(promo.get('observed_intervals'))}/"
                f"{_int(promo.get('target_intervals'))}"
            ),
            "next_action": (
                "같은 Capacity regime의 실제 closed-session interval을 추가 축적. "
                "Snapshot 반복 저장으로 interval을 만들지 않음"
            ),
            "go_to": "Operations Control Tower",
        }]
    elif state == "PROMOTION_NO_CLEARING":
        rows = [{
            "priority": "CP1",
            "status": "REVIEW",
            "issue": "CALIBRATION_PROMOTION_NO_CLEARING",
            "detail": (
                f"avg burn {_float(promo.get('avg_net_burn_per_interval')):.2f}"
            ),
            "next_action": "Arrival/Exit Root Cause와 backlog clearing 구조를 검토",
            "go_to": "Review Queue",
        }]
    elif state == "PROMOTION_ADVERSE_INTERVAL_REVIEW":
        rows = [{
            "priority": "CP1",
            "status": "REVIEW",
            "issue": "CALIBRATION_PROMOTION_ADVERSE_INTERVAL",
            "detail": (
                f"negative intervals {_int(promo.get('negative_burn_intervals'))} · "
                f"latest burn {_float(promo.get('latest_net_burn')):.2f}"
            ),
            "next_action": (
                "평균이 양수여도 adverse interval이 있는지 원인 분해 후 추가 evidence를 확인"
            ),
            "go_to": "Operations Control Tower",
        }]
    elif state == "PROMOTION_MIXED_BURN":
        rows = [{
            "priority": "CP2",
            "status": "REVIEW",
            "issue": "CALIBRATION_PROMOTION_MIXED_BURN",
            "detail": (
                f"positive ratio {_float(promo.get('positive_burn_ratio')):.1%}"
            ),
            "next_action": "Burn 일관성이 안정되는지 closed-session history를 추가 검토",
            "go_to": "Operations Control Tower",
        }]
    else:
        rows = [{
            "priority": "CP3",
            "status": "MONITOR",
            "issue": "CALIBRATION_PROMOTION_READY",
            "detail": (
                f"intervals {_int(promo.get('observed_intervals'))} · "
                f"positive ratio {_float(promo.get('positive_burn_ratio')):.1%}"
            ),
            "next_action": (
                "Projection Review 가능 여부를 Human Review. 자동 Projection/Capacity 승인 없음"
            ),
            "go_to": "Operations Control Tower",
        }]

    order = {"CP0": 0, "CP1": 1, "CP2": 2, "CP3": 3}
    out = pd.DataFrame(rows, columns=PROMOTION_QUEUE_COLS)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(["_p", "issue"])
        .drop(columns=["_p"])
        .reset_index(drop=True)
    )


def _snapshot_payload(row: dict) -> dict:
    int_fields = {
        "qualified_endpoints",
        "observed_intervals",
        "target_intervals",
        "positive_burn_intervals",
        "zero_burn_intervals",
        "negative_burn_intervals",
    }
    float_fields = {
        "positive_burn_ratio",
        "avg_net_burn_per_interval",
        "latest_net_burn",
        "min_net_burn",
        "max_net_burn",
    }

    payload = {}
    for col in FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS:
        if col in {
            "promotion_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(row.get(col))
        elif col in float_fields:
            payload[col] = round(_float(row.get(col)), 10)
        else:
            payload[col] = _text(row.get(col))

    return payload


def build_flow_calibration_promotion_snapshot(
    promotion: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = _text(created_at) or datetime.now().astimezone().isoformat()
    base = {
        col: promotion.get(col, "")
        for col in FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS
        if col not in {
            "promotion_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }
    }
    base["projection_authorization"] = "NONE"
    base["execution_authorization"] = "NONE"

    snapshot_hash = _hash(_snapshot_payload(base))

    return {
        "promotion_snapshot_id": (
            "OCP-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_calibration_promotion_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {"status": "MISSING", "calculated_hash": ""}

    item = row.to_dict() if isinstance(row, pd.Series) else dict(row)
    stored = _text(item.get("snapshot_hash"))

    if not stored:
        return {"status": "MISSING", "calculated_hash": ""}

    calculated = _hash(_snapshot_payload(item))
    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def latest_flow_calibration_promotion_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()
    if df.empty:
        return {}

    for col in FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[df["_ts"].notna()].sort_values("_ts")
    if valid.empty:
        return {}

    return valid.iloc[-1].drop(labels=["_ts"]).to_dict()
