"""Pure, conservative risk review of manually supplied evidence and holdings.

No market-data lookup, persistence, or investment execution is performed.
Fractions are expressed as numbers in [0, 1], never percentages.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import math
from typing import Any

SCHEMA_VERSION = 2
MAX_POSITIONS = 1000


def _fraction(value: Any, name: str, errors: list[str], *, positive=False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        errors.append(f"{name}: 유한 숫자가 필요합니다")
        return 0.0
    try:
        number = float(value)
    except OverflowError:
        errors.append(f"{name}: 숫자가 허용 범위를 초과합니다")
        return 0.0
    if not math.isfinite(number) or number < 0 or number > 1 or (positive and number == 0):
        errors.append(f"{name}: {'0 초과 1 이하' if positive else '0 이상 1 이하'} 값이 필요합니다")
        return 0.0
    return number


def review_contract(contract: dict[str, Any], *, now: datetime | None = None) -> dict[str, Any]:
    """Return BLOCKED/REVIEW; even a valid risk envelope is not a buy instruction."""
    errors: list[str] = []
    result: dict[str, Any] = dict(schema_version=2, status="BLOCKED", blockers=errors,
                                execution_authorization="NONE", orders_enabled=False)
    if not isinstance(contract, dict):
        errors.append("검토 입력은 객체여야 합니다")
        return result
    if type(contract.get("schema_version")) is not int or contract.get("schema_version") != 2:
        errors.append("지원하는 입력 계약 버전은 2입니다")
    candidate = contract.get("candidate")
    budget = contract.get("budget")
    evidence = contract.get("evidence")
    positions = contract.get("positions")
    if not all(isinstance(x, dict) for x in (candidate, budget, evidence)):
        errors.append("종목·예산·근거 입력이 모두 필요합니다")
        return result
    if not isinstance(positions, list) or len(positions) > MAX_POSITIONS:
        errors.append(f"보유 내역은 {MAX_POSITIONS}건 이하의 목록이어야 합니다")
        return result
    symbol = candidate.get("symbol")
    factor = candidate.get("factor")
    if not isinstance(symbol, str) or not symbol.strip():
        errors.append("검토 종목 식별자가 필요합니다")
    if not isinstance(factor, str) or not factor.strip():
        errors.append("검토 종목의 투자 요인이 필요합니다")
    symbol = symbol.strip() if isinstance(symbol,str) else symbol
    factor = factor.strip() if isinstance(factor,str) else factor
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None or current.utcoffset() is None:
        errors.append("검토 시각에는 시간대가 필요합니다")
        return result
    ttl = evidence.get("max_age_days")
    if type(ttl) is not int or not 1 <= ttl <= 365:
        errors.append("근거 유효 기간은 1~365일의 정수여야 합니다")
    if not isinstance(evidence.get("source"), str) or not evidence["source"].strip():
        errors.append("근거 출처가 필요합니다")
    if evidence.get("user_attested") is not True:
        errors.append("입력 근거와 하방 가정에 대한 사용자 확인이 필요합니다")
    try:
        observed = datetime.fromisoformat(evidence.get("observed_at", ""))
        if observed.tzinfo is None or observed.utcoffset() is None:
            raise ValueError("timezone required")
        if observed > current + timedelta(minutes=5):
            errors.append("근거 확인 시각이 미래입니다")
        if type(ttl) is int and current - observed > timedelta(days=ttl):
            errors.append("근거 유효 기간이 지났습니다")
    except (ValueError, TypeError, OverflowError):
        errors.append("근거 확인 시각은 시간대를 포함해야 합니다")
    downside = _fraction(candidate.get("downside"), "검토 종목 하방", errors, positive=True)
    proposed = _fraction(candidate.get("proposed_weight"), "검토 비중", errors)
    per_loss = _fraction(budget.get("position_loss"), "종목 손실 예산", errors)
    portfolio_loss = _fraction(budget.get("portfolio_loss"), "포트폴리오 손실 예산", errors)
    caps = {k:_fraction(budget.get(k),k,errors) for k in
            ("single_name_cap","factor_cap","liquidity_cap","strategy_cap")}
    total_weight = other_loss = factor_other = current_candidate_weight = 0.0
    seen: set[str] = set()
    for index, position in enumerate(positions):
        if not isinstance(position, dict):
            errors.append(f"보유 내역 {index + 1}: 객체가 필요합니다")
            continue
        ticker, group = position.get("symbol"), position.get("factor")
        if not isinstance(ticker, str) or not ticker.strip() or ticker.strip() in seen:
            errors.append(f"보유 내역 {index + 1}: 종목 식별자 누락 또는 중복")
            continue
        ticker = ticker.strip()
        seen.add(ticker)
        if not isinstance(group, str) or not group.strip():
            errors.append(f"보유 내역 {index + 1}: 투자 요인이 필요합니다")
        group = group.strip() if isinstance(group,str) else group
        weight = _fraction(position.get("weight"), f"{ticker} 비중", errors)
        risk = _fraction(position.get("downside"), f"{ticker} 하방", errors, positive=True)
        total_weight += weight
        if ticker == (symbol.strip() if isinstance(symbol,str) else symbol):
            current_candidate_weight = weight
            if group != factor:
                errors.append("기존 보유와 검토 종목의 투자 요인이 다릅니다")
        else:
            other_loss += weight * risk
            if group == factor:
                factor_other += weight
    if total_weight > 1 + 1e-12:
        errors.append("전체 보유 비중이 100%를 초과합니다")
    if errors:
        return result
    limits = dict(
        position_loss=per_loss/downside,
        portfolio_loss=max(0.0,portfolio_loss-other_loss)/downside,
        single_name=caps["single_name_cap"],
        factor=max(0.0,caps["factor_cap"]-factor_other),
        liquidity=caps["liquidity_cap"],
        strategy=caps["strategy_cap"],
        capital=max(0.0,1-(total_weight-current_candidate_weight)),
    )
    max_weight = min(limits.values())
    limiting = [k for k,v in limits.items() if math.isclose(v,max_weight,abs_tol=1e-12,rel_tol=1e-12)]
    modeled_loss = other_loss + proposed * downside
    breaches = [k for k,v in limits.items() if proposed > v + 1e-12]
    if other_loss > portfolio_loss + 1e-12:
        breaches.append("existing_portfolio_loss")
    if factor_other > caps["factor_cap"] + 1e-12:
        breaches.append("existing_factor_cap")
    result.update(status="REVIEW" if not breaches else "BLOCKED", max_weight=max_weight,
                  proposed_weight=proposed, current_candidate_weight=current_candidate_weight,
                  candidate_loss=proposed*downside, modeled_portfolio_loss=modeled_loss,
                  remaining_portfolio_loss=max(0.0,portfolio_loss-other_loss),
                  limits=limits, limiting_factors=limiting, breaches=breaches,
                  evidence_basis="USER_ATTESTED", observed_at=evidence["observed_at"],
                  model="동시에 입력 하방에 도달하는 보유 종목의 손실 합계; 미입력 현금 비중은 하방 0 가정",
                  next_action="위험 상한 내 수동 검토; 매수·추가 투자 승인이 아님" if not breaches else "비중 확대 중단 후 상한 초과 원인 검토")
    return result


def convert_manual_v1(payload: dict[str, Any]) -> dict[str, Any]:
    """Explicit import adapter for the documented flat manual schema, not OS CSVs."""
    if not isinstance(payload,dict) or type(payload.get("schema_version")) is not int or payload.get("schema_version") != 1:
        raise ValueError("수동 입력 계약 버전 1만 변환할 수 있습니다")
    required = ("symbol","factor","downside","proposed_weight","position_loss","portfolio_loss",
                "single_name_cap","factor_cap","liquidity_cap","strategy_cap","positions","source",
                "observed_at","max_age_days","user_attested")
    missing = [k for k in required if k not in payload]
    if missing:
        raise ValueError("변환 입력 누락: " + ", ".join(missing))
    if not isinstance(payload['positions'],list) or not all(isinstance(p,dict) for p in payload['positions']):
        raise ValueError("보유 내역은 객체의 목록이어야 합니다")
    return dict(schema_version=2,
                candidate={k:payload[k] for k in ("symbol","factor","downside","proposed_weight")},
                budget={k:payload[k] for k in ("position_loss","portfolio_loss","single_name_cap","factor_cap","liquidity_cap","strategy_cap")},
                evidence={k:payload[k] for k in ("source","observed_at","max_age_days","user_attested")},
                positions=[dict(p) for p in payload["positions"]])
