from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json
import math

import pandas as pd

from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    flow_projection_snapshot_integrity,
)
from engine.operations_flow_trend import (
    FLOW_TREND_SNAPSHOT_COLS,
    flow_trend_snapshot_integrity,
)


FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS = [
    "outcome_snapshot_id",
    "created_at",
    "source_projection_snapshot_id",
    "source_projection_hash",
    "source_projection_created_at",
    "source_projection_integrity",
    "evidence_start_at",
    "evidence_end_at",
    "evidence_end_trend_snapshot_id",
    "evidence_end_trend_hash",
    "evidence_intervals",
    "invalid_evidence_count",
    "start_groups",
    "current_groups",
    "attention_groups",
    "capacity",
    "capacity_drift_count",
    "realized_net_burn_total",
    "realized_avg_net_burn",
    "base_burn_rate",
    "base_burn_error",
    "base_abs_pct_error",
    "base_expected_groups",
    "base_group_error",
    "base_clearance_intervals",
    "actual_clearance_intervals",
    "clearance_state",
    "evaluation_state",
    "recalibration_state",
    "capacity_decision_state",
    "projection_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PROJECTION_OUTCOME_EVIDENCE_COLS = [
    "interval",
    "trend_snapshot_id",
    "period_end",
    "current_groups",
    "attention_groups",
    "capacity",
    "net_burn",
    "cumulative_burn",
    "base_expected_groups",
    "base_group_error",
]


PROJECTION_OUTCOME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _optional_float(value: Any) -> float | None:
    text = _text(value)
    if not text:
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def _round_optional(value: Any) -> float | None:
    out = _optional_float(value)
    if out is None:
        return None
    return round(out, 10)


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def latest_ready_flow_projection_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )
    if df.empty:
        return {}

    for col in FLOW_PROJECTION_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    df = df.loc[
        df["_ts"].notna()
        & (
            df["projection_state"]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
            == "READY_FOR_REVIEW"
        )
    ].copy()

    if df.empty:
        return {}

    row = (
        df.sort_values("_ts")
        .iloc[-1]
        .drop(labels=["_ts"])
    )
    return row.to_dict()


def _trend_evidence_after_projection(
    projection: dict,
    trend_snapshots: pd.DataFrame | None,
    *,
    max_evaluation_intervals: int = 20,
) -> dict:
    source_ts = pd.to_datetime(
        projection.get("created_at"),
        errors="coerce",
        utc=True,
    )
    if pd.isna(source_ts):
        return {
            "valid": pd.DataFrame(
                columns=FLOW_TREND_SNAPSHOT_COLS
            ),
            "invalid_count": 0,
            "source_time_valid": False,
        }

    df = (
        pd.DataFrame()
        if trend_snapshots is None
        else trend_snapshots.copy()
    )
    if df.empty:
        return {
            "valid": pd.DataFrame(
                columns=FLOW_TREND_SNAPSHOT_COLS
            ),
            "invalid_count": 0,
            "source_time_valid": True,
        }

    for col in FLOW_TREND_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    post = df.loc[
        df["_ts"].notna()
        & (df["_ts"] > source_ts)
    ].copy()

    if post.empty:
        return {
            "valid": pd.DataFrame(
                columns=FLOW_TREND_SNAPSHOT_COLS
            ),
            "invalid_count": 0,
            "source_time_valid": True,
        }

    post = post.sort_values("_ts")
    valid_rows = []
    invalid_count = 0

    for _, row in post.iterrows():
        record = row.drop(labels=["_ts"]).to_dict()
        if (
            flow_trend_snapshot_integrity(
                record
            ).get("status")
            == "OK"
        ):
            valid_rows.append(record)
        else:
            invalid_count += 1

    valid = pd.DataFrame(
        valid_rows,
        columns=FLOW_TREND_SNAPSHOT_COLS,
    )

    limit = max(
        0,
        _int(max_evaluation_intervals),
    )
    if limit > 0 and len(valid) > limit:
        valid = valid.head(limit).copy()

    return {
        "valid": valid.reset_index(drop=True),
        "invalid_count": invalid_count,
        "source_time_valid": True,
    }


def build_flow_projection_outcome(
    projection_snapshot: dict | pd.Series | None,
    trend_snapshots: pd.DataFrame | None,
    *,
    min_evaluation_intervals: int = 2,
    max_evaluation_intervals: int = 20,
    relative_error_threshold: float = 0.50,
) -> dict:
    source = (
        {}
        if projection_snapshot is None
        else (
            projection_snapshot.to_dict()
            if isinstance(
                projection_snapshot,
                pd.Series,
            )
            else dict(
                projection_snapshot
            )
        )
    )

    empty_table = pd.DataFrame(
        columns=PROJECTION_OUTCOME_EVIDENCE_COLS
    )

    if not source:
        return {
            "source_projection_snapshot_id": "",
            "source_projection_hash": "",
            "source_projection_created_at": "",
            "source_projection_integrity": "MISSING",
            "evidence_start_at": "",
            "evidence_end_at": "",
            "evidence_end_trend_snapshot_id": "",
            "evidence_end_trend_hash": "",
            "evidence_intervals": 0,
            "invalid_evidence_count": 0,
            "start_groups": 0,
            "current_groups": 0,
            "attention_groups": 0,
            "capacity": 0,
            "capacity_drift_count": 0,
            "realized_net_burn_total": 0.0,
            "realized_avg_net_burn": None,
            "base_burn_rate": 0.0,
            "base_burn_error": None,
            "base_abs_pct_error": None,
            "base_expected_groups": None,
            "base_group_error": None,
            "base_clearance_intervals": None,
            "actual_clearance_intervals": None,
            "clearance_state": "NOT_EVALUATED",
            "evaluation_state": "PROJECTION_SOURCE_REQUIRED",
            "recalibration_state": "HOLD_SOURCE",
            "capacity_decision_state": "HOLD_SOURCE",
            "evidence_table": empty_table,
            "snapshot_eligible": False,
            "projection_authorization": "NONE",
            "capacity_authorization": "NONE",
            "execution_authorization": "NONE",
        }

    source_integrity = (
        flow_projection_snapshot_integrity(
            source
        ).get(
            "status",
            "MISMATCH",
        )
    )
    source_state = _text(
        source.get("projection_state")
    ).upper()

    start_groups = _int(
        source.get("current_groups")
    )
    source_attention = _int(
        source.get("attention_groups")
    )
    source_capacity = max(
        1,
        _int(
            source.get("capacity")
        ),
    )
    base_burn = _float(
        source.get("base_burn_rate")
    )
    base_clearance = _optional_float(
        source.get(
            "base_clearance_intervals"
        )
    )

    evidence_info = _trend_evidence_after_projection(
        source,
        trend_snapshots,
        max_evaluation_intervals=max_evaluation_intervals,
    )
    evidence = evidence_info["valid"]
    invalid_count = _int(
        evidence_info.get("invalid_count")
    )

    if not bool(
        evidence_info.get(
            "source_time_valid"
        )
    ):
        source_integrity = "INVALID_TIME"

    rows = []
    prev_groups = start_groups
    cumulative_burn = 0.0
    capacity_drift_count = 0
    actual_clearance = None

    for idx, row in evidence.iterrows():
        interval = idx + 1
        current_groups = _int(
            row.get(
                "current_group_count"
            )
        )
        attention_groups = _int(
            row.get(
                "attention_group_count"
            )
        )
        capacity = max(
            1,
            _int(
                row.get(
                    "capacity"
                )
            ),
        )
        net_burn = float(
            prev_groups
            - current_groups
        )
        cumulative_burn += net_burn

        if capacity != source_capacity:
            capacity_drift_count += 1

        expected_groups = max(
            0.0,
            float(
                start_groups
                - (
                    base_burn
                    * interval
                )
            ),
        )
        group_error = (
            float(current_groups)
            - expected_groups
        )

        rows.append(
            {
                "interval": interval,
                "trend_snapshot_id":
                    _text(
                        row.get(
                            "trend_snapshot_id"
                        )
                    ),
                "period_end":
                    _text(
                        row.get(
                            "created_at"
                        )
                    ),
                "current_groups":
                    current_groups,
                "attention_groups":
                    attention_groups,
                "capacity":
                    capacity,
                "net_burn":
                    net_burn,
                "cumulative_burn":
                    cumulative_burn,
                "base_expected_groups":
                    expected_groups,
                "base_group_error":
                    group_error,
            }
        )

        if (
            actual_clearance is None
            and current_groups == 0
        ):
            actual_clearance = float(
                interval
            )

        prev_groups = current_groups

    evidence_table = pd.DataFrame(
        rows,
        columns=PROJECTION_OUTCOME_EVIDENCE_COLS,
    )

    n = int(
        len(
            evidence_table
        )
    )

    if n > 0:
        last_row = evidence.iloc[
            n - 1
        ].to_dict()
        current_groups = _int(
            last_row.get(
                "current_group_count"
            )
        )
        attention_groups = _int(
            last_row.get(
                "attention_group_count"
            )
        )
        capacity = max(
            1,
            _int(
                last_row.get(
                    "capacity"
                )
            ),
        )
        evidence_start_at = _text(
            evidence.iloc[0].get(
                "created_at"
            )
        )
        evidence_end_at = _text(
            last_row.get(
                "created_at"
            )
        )
        evidence_end_id = _text(
            last_row.get(
                "trend_snapshot_id"
            )
        )
        evidence_end_hash = _text(
            last_row.get(
                "snapshot_hash"
            )
        )
        realized_total = float(
            start_groups
            - current_groups
        )
        realized_avg = (
            realized_total
            / n
        )
        base_burn_error = (
            realized_avg
            - base_burn
        )
        base_abs_pct_error = (
            abs(
                base_burn_error
            )
            / abs(
                base_burn
            )
            if abs(
                base_burn
            )
            > 1e-12
            else None
        )
        base_expected_groups = max(
            0.0,
            float(
                start_groups
                - (
                    base_burn
                    * n
                )
            ),
        )
        base_group_error = (
            float(
                current_groups
            )
            - base_expected_groups
        )
    else:
        current_groups = start_groups
        attention_groups = source_attention
        capacity = source_capacity
        evidence_start_at = ""
        evidence_end_at = ""
        evidence_end_id = ""
        evidence_end_hash = ""
        realized_total = 0.0
        realized_avg = None
        base_burn_error = None
        base_abs_pct_error = None
        base_expected_groups = None
        base_group_error = None

    if (
        actual_clearance is not None
    ):
        clearance_state = "CLEARED"
    elif (
        base_clearance is not None
        and n
        >= int(
            math.ceil(
                base_clearance
            )
        )
        and current_groups > 0
    ):
        clearance_state = (
            "BASE_WINDOW_MISSED"
        )
    else:
        clearance_state = "OPEN"

    min_intervals = max(
        1,
        _int(
            min_evaluation_intervals
        ),
    )
    threshold = max(
        0.0,
        float(
            relative_error_threshold
        ),
    )

    if source_integrity != "OK":
        evaluation_state = (
            "SOURCE_PROJECTION_INTEGRITY_REVIEW"
        )
    elif source_state != "READY_FOR_REVIEW":
        evaluation_state = (
            "SOURCE_PROJECTION_NOT_READY"
        )
    elif invalid_count > 0:
        evaluation_state = (
            "EVIDENCE_INTEGRITY_REVIEW"
        )
    elif n == 0:
        evaluation_state = (
            "WAIT_EVIDENCE"
        )
    elif capacity_drift_count > 0:
        evaluation_state = (
            "ASSUMPTION_DRIFT_REVIEW"
        )
    elif n < min_intervals:
        evaluation_state = (
            "EVIDENCE_MATURING"
        )
    elif clearance_state == "BASE_WINDOW_MISSED":
        evaluation_state = (
            "BASE_CLEARANCE_MISS_REVIEW"
        )
    elif (
        realized_avg is not None
        and base_burn > 0
        and realized_avg <= 0
    ):
        evaluation_state = (
            "MODEL_BREAK_REVIEW"
        )
    elif (
        base_abs_pct_error is not None
        and base_abs_pct_error
        > threshold
    ):
        evaluation_state = (
            "MODEL_ERROR_REVIEW"
        )
    elif clearance_state == "CLEARED":
        evaluation_state = (
            "CLEARED_REVIEW"
        )
    else:
        evaluation_state = (
            "WITHIN_REVIEW_BAND"
        )

    if evaluation_state in {
        "SOURCE_PROJECTION_INTEGRITY_REVIEW",
        "SOURCE_PROJECTION_NOT_READY",
    }:
        recalibration_state = "HOLD_SOURCE"
    elif evaluation_state in {
        "EVIDENCE_INTEGRITY_REVIEW",
    }:
        recalibration_state = (
            "HOLD_EVIDENCE_INTEGRITY"
        )
    elif evaluation_state in {
        "WAIT_EVIDENCE",
        "EVIDENCE_MATURING",
    }:
        recalibration_state = (
            "WAIT_EVIDENCE"
        )
    elif evaluation_state == "ASSUMPTION_DRIFT_REVIEW":
        recalibration_state = (
            "REBASE_REQUIRED"
        )
    elif evaluation_state in {
        "BASE_CLEARANCE_MISS_REVIEW",
        "MODEL_BREAK_REVIEW",
        "MODEL_ERROR_REVIEW",
    }:
        recalibration_state = (
            "RECALIBRATION_REVIEW"
        )
    else:
        recalibration_state = (
            "MONITOR"
        )

    attention_pressure = (
        attention_groups
        / max(
            1,
            capacity,
        )
    )

    if evaluation_state in {
        "SOURCE_PROJECTION_INTEGRITY_REVIEW",
        "SOURCE_PROJECTION_NOT_READY",
        "EVIDENCE_INTEGRITY_REVIEW",
        "WAIT_EVIDENCE",
        "EVIDENCE_MATURING",
    }:
        capacity_state = (
            "HOLD_EVIDENCE"
        )
    elif evaluation_state == "ASSUMPTION_DRIFT_REVIEW":
        capacity_state = (
            "REBASE_BEFORE_CAPACITY_REVIEW"
        )
    elif evaluation_state in {
        "BASE_CLEARANCE_MISS_REVIEW",
        "MODEL_BREAK_REVIEW",
        "MODEL_ERROR_REVIEW",
    }:
        if (
            attention_pressure >= 1.0
            or current_groups
            > start_groups
        ):
            capacity_state = (
                "REVIEW_CONSTRAINT_AFTER_RECALIBRATION"
            )
        else:
            capacity_state = (
                "HOLD_MODEL_RECALIBRATION"
            )
    else:
        capacity_state = (
            "NO_CHANGE_EVIDENCE"
        )

    snapshot_eligible = (
        source_integrity == "OK"
        and source_state == "READY_FOR_REVIEW"
        and invalid_count == 0
        and n > 0
    )

    return {
        "source_projection_snapshot_id":
            _text(
                source.get(
                    "projection_snapshot_id"
                )
            ),
        "source_projection_hash":
            _text(
                source.get(
                    "snapshot_hash"
                )
            ),
        "source_projection_created_at":
            _text(
                source.get(
                    "created_at"
                )
            ),
        "source_projection_integrity":
            source_integrity,
        "evidence_start_at":
            evidence_start_at,
        "evidence_end_at":
            evidence_end_at,
        "evidence_end_trend_snapshot_id":
            evidence_end_id,
        "evidence_end_trend_hash":
            evidence_end_hash,
        "evidence_intervals":
            n,
        "invalid_evidence_count":
            invalid_count,
        "start_groups":
            start_groups,
        "current_groups":
            current_groups,
        "attention_groups":
            attention_groups,
        "capacity":
            capacity,
        "capacity_drift_count":
            capacity_drift_count,
        "realized_net_burn_total":
            realized_total,
        "realized_avg_net_burn":
            realized_avg,
        "base_burn_rate":
            base_burn,
        "base_burn_error":
            base_burn_error,
        "base_abs_pct_error":
            base_abs_pct_error,
        "base_expected_groups":
            base_expected_groups,
        "base_group_error":
            base_group_error,
        "base_clearance_intervals":
            base_clearance,
        "actual_clearance_intervals":
            actual_clearance,
        "clearance_state":
            clearance_state,
        "evaluation_state":
            evaluation_state,
        "recalibration_state":
            recalibration_state,
        "capacity_decision_state":
            capacity_state,
        "evidence_table":
            evidence_table,
        "snapshot_eligible":
            snapshot_eligible,
        "projection_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }


def build_flow_projection_outcome_queue(
    outcome: dict | None,
) -> pd.DataFrame:
    result = outcome or {}
    state = _text(
        result.get(
            "evaluation_state"
        )
    ).upper()

    rows = []

    if state == "PROJECTION_SOURCE_REQUIRED":
        rows.append(
            {
                "priority": "FO1",
                "status": "WAIT",
                "issue": "FLOW_PROJECTION_READY_SOURCE_REQUIRED",
                "detail": "READY_FOR_REVIEW Projection Snapshot 없음",
                "next_action": (
                    "Projection Guard를 강제로 열지 말고 실제 Flow history가 "
                    "충분히 쌓인 뒤 READY Projection Snapshot을 저장"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "SOURCE_PROJECTION_INTEGRITY_REVIEW":
        rows.append(
            {
                "priority": "FO0",
                "status": "BLOCKED",
                "issue": "FLOW_PROJECTION_OUTCOME_SOURCE_INTEGRITY",
                "detail": "Projection Snapshot integrity mismatch",
                "next_action": (
                    "1I의 Projection Snapshot lineage/hash를 먼저 확인"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "SOURCE_PROJECTION_NOT_READY":
        rows.append(
            {
                "priority": "FO1",
                "status": "WAIT",
                "issue": "FLOW_PROJECTION_SOURCE_NOT_READY",
                "detail": "source Projection이 READY_FOR_REVIEW가 아님",
                "next_action": (
                    "현재 Guard를 유지하고 Projection 조건을 억지로 변경하지 않음"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "EVIDENCE_INTEGRITY_REVIEW":
        rows.append(
            {
                "priority": "FO0",
                "status": "BLOCKED",
                "issue": "FLOW_PROJECTION_OUTCOME_EVIDENCE_INTEGRITY",
                "detail": (
                    f"post-projection invalid trend snapshots "
                    f"{_int(result.get('invalid_evidence_count'))}"
                ),
                "next_action": (
                    "Flow Trend Snapshot integrity를 먼저 복구"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state in {
        "WAIT_EVIDENCE",
        "EVIDENCE_MATURING",
    }:
        rows.append(
            {
                "priority": "FO1",
                "status": "WAIT",
                "issue": "FLOW_PROJECTION_OUTCOME_EVIDENCE_MATURING",
                "detail": (
                    f"post-projection evidence intervals "
                    f"{_int(result.get('evidence_intervals'))}"
                ),
                "next_action": (
                    "실제 Queue 변화 시 Trend Snapshot을 정상 절차로 추가 축적"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "ASSUMPTION_DRIFT_REVIEW":
        rows.append(
            {
                "priority": "FO0",
                "status": "REVIEW",
                "issue": "FLOW_PROJECTION_CAPACITY_ASSUMPTION_DRIFT",
                "detail": (
                    f"capacity drift intervals "
                    f"{_int(result.get('capacity_drift_count'))}"
                ),
                "next_action": (
                    "기존 Projection 오차로 단정하지 말고 새 Calibration/Projection으로 rebase"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state in {
        "BASE_CLEARANCE_MISS_REVIEW",
        "MODEL_BREAK_REVIEW",
        "MODEL_ERROR_REVIEW",
    }:
        err = _optional_float(
            result.get(
                "base_abs_pct_error"
            )
        )
        rows.append(
            {
                "priority": "FO0",
                "status": "REVIEW",
                "issue": "FLOW_PROJECTION_MODEL_ERROR_REVIEW",
                "detail": (
                    state
                    + (
                        ""
                        if err is None
                        else f" · abs error {err:.1%}"
                    )
                ),
                "next_action": (
                    "Projection을 폐기/연장하기 전에 Calibration 재검토와 원인 분해를 수행"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state in {
        "WITHIN_REVIEW_BAND",
        "CLEARED_REVIEW",
    }:
        rows.append(
            {
                "priority": "FO2",
                "status": "MONITOR",
                "issue": "FLOW_PROJECTION_OUTCOME_MONITOR",
                "detail": state,
                "next_action": (
                    "추가 evidence를 축적하고 Capacity 자동 변경 없이 계속 모니터링"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    capacity_state = _text(
        result.get(
            "capacity_decision_state"
        )
    ).upper()
    if capacity_state in {
        "REVIEW_CONSTRAINT_AFTER_RECALIBRATION",
        "REBASE_BEFORE_CAPACITY_REVIEW",
    }:
        rows.append(
            {
                "priority": "FO1",
                "status": "REVIEW",
                "issue": "FLOW_CAPACITY_DECISION_GOVERNANCE",
                "detail": capacity_state,
                "next_action": (
                    "Capacity 변경 전에 Recalibration + 원인 검토 + Human Review 수행"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=PROJECTION_OUTCOME_QUEUE_COLS
        )

    order = {
        "FO0": 0,
        "FO1": 1,
        "FO2": 2,
    }
    out = pd.DataFrame(
        rows,
        columns=PROJECTION_OUTCOME_QUEUE_COLS,
    )
    out["_p"] = out["priority"].map(
        order
    ).fillna(9)

    return (
        out.sort_values(
            ["_p", "issue"]
        )
        .drop(
            columns=["_p"]
        )
        .reset_index(
            drop=True
        )
    )


def _snapshot_payload(
    row: dict,
) -> dict:
    return {
        "source_projection_snapshot_id":
            _text(
                row.get(
                    "source_projection_snapshot_id"
                )
            ),
        "source_projection_hash":
            _text(
                row.get(
                    "source_projection_hash"
                )
            ),
        "source_projection_created_at":
            _text(
                row.get(
                    "source_projection_created_at"
                )
            ),
        "source_projection_integrity":
            _text(
                row.get(
                    "source_projection_integrity"
                )
            ),
        "evidence_start_at":
            _text(
                row.get(
                    "evidence_start_at"
                )
            ),
        "evidence_end_at":
            _text(
                row.get(
                    "evidence_end_at"
                )
            ),
        "evidence_end_trend_snapshot_id":
            _text(
                row.get(
                    "evidence_end_trend_snapshot_id"
                )
            ),
        "evidence_end_trend_hash":
            _text(
                row.get(
                    "evidence_end_trend_hash"
                )
            ),
        "evidence_intervals":
            _int(
                row.get(
                    "evidence_intervals"
                )
            ),
        "invalid_evidence_count":
            _int(
                row.get(
                    "invalid_evidence_count"
                )
            ),
        "start_groups":
            _int(
                row.get(
                    "start_groups"
                )
            ),
        "current_groups":
            _int(
                row.get(
                    "current_groups"
                )
            ),
        "attention_groups":
            _int(
                row.get(
                    "attention_groups"
                )
            ),
        "capacity":
            _int(
                row.get(
                    "capacity"
                )
            ),
        "capacity_drift_count":
            _int(
                row.get(
                    "capacity_drift_count"
                )
            ),
        "realized_net_burn_total":
            round(
                _float(
                    row.get(
                        "realized_net_burn_total"
                    )
                ),
                10,
            ),
        "realized_avg_net_burn":
            _round_optional(
                row.get(
                    "realized_avg_net_burn"
                )
            ),
        "base_burn_rate":
            round(
                _float(
                    row.get(
                        "base_burn_rate"
                    )
                ),
                10,
            ),
        "base_burn_error":
            _round_optional(
                row.get(
                    "base_burn_error"
                )
            ),
        "base_abs_pct_error":
            _round_optional(
                row.get(
                    "base_abs_pct_error"
                )
            ),
        "base_expected_groups":
            _round_optional(
                row.get(
                    "base_expected_groups"
                )
            ),
        "base_group_error":
            _round_optional(
                row.get(
                    "base_group_error"
                )
            ),
        "base_clearance_intervals":
            _round_optional(
                row.get(
                    "base_clearance_intervals"
                )
            ),
        "actual_clearance_intervals":
            _round_optional(
                row.get(
                    "actual_clearance_intervals"
                )
            ),
        "clearance_state":
            _text(
                row.get(
                    "clearance_state"
                )
            ),
        "evaluation_state":
            _text(
                row.get(
                    "evaluation_state"
                )
            ),
        "recalibration_state":
            _text(
                row.get(
                    "recalibration_state"
                )
            ),
        "capacity_decision_state":
            _text(
                row.get(
                    "capacity_decision_state"
                )
            ),
        "projection_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }


def build_flow_projection_outcome_snapshot(
    outcome: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    if not bool(
        outcome.get(
            "snapshot_eligible"
        )
    ):
        raise ValueError(
            "Outcome Snapshot은 integrity OK인 READY Projection과 "
            "1개 이상의 유효 post-projection evidence가 필요합니다."
        )

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )
    payload = _snapshot_payload(
        outcome
    )
    snapshot_hash = _hash(
        payload
    )

    return {
        "outcome_snapshot_id":
            (
                "OFO-"
                + pd.Timestamp(
                    now
                ).strftime(
                    "%Y%m%dT%H%M%S"
                )
                + "-"
                + snapshot_hash[:8]
            ),
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def flow_projection_outcome_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "expected_hash": "",
            "actual_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(
            row,
            pd.Series,
        )
        else dict(
            row
        )
    )
    actual = _text(
        item.get(
            "snapshot_hash"
        )
    )
    expected = _hash(
        _snapshot_payload(
            item
        )
    )

    return {
        "status":
            (
                "OK"
                if actual
                and actual == expected
                else "MISMATCH"
            ),
        "expected_hash":
            expected,
        "actual_hash":
            actual,
    }


def latest_flow_projection_outcome_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )
    if df.empty:
        return {}

    for col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    created = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        created.notna()
    ].copy()

    if valid.empty:
        return {}

    valid["_created"] = created.loc[
        valid.index
    ]

    row = (
        valid.sort_values(
            "_created"
        )
        .iloc[-1]
        .drop(
            labels=[
                "_created"
            ]
        )
    )
    return row.to_dict()
