from __future__ import annotations

from datetime import date
from typing import Any
import pandas as pd

from engine.forecast_change_registry import (
    forecast_change_plan_integrity,
    build_forecast_change_queue,
)
from engine.forecast_change_implementation import (
    forecast_implementation_integrity,
    build_forecast_implementation_queue,
)
from engine.forecast_change_effect_review import (
    forecast_effect_review_integrity,
    build_forecast_effect_queue,
)


FORECAST_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _ensure_df(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    return pd.DataFrame() if df is None else df.copy()


def _integrity_counts(
    df: pd.DataFrame,
    fn,
) -> dict:
    total = 0
    ok = 0
    mismatch = 0
    missing = 0

    if not df.empty:
        for _, row in df.iterrows():
            total += 1
            status = _text(
                fn(
                    row.to_dict()
                ).get(
                    "status"
                )
            ).upper()

            if status == "OK":
                ok += 1
            elif status == "MISSING":
                missing += 1
            else:
                mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "mismatch": mismatch,
        "missing": missing,
    }


def _execution_authorization_violations(
    frames: list[pd.DataFrame],
) -> int:
    violations = 0

    for df in frames:
        if (
            df.empty
            or "execution_authorization"
            not in df.columns
        ):
            continue

        auth = (
            df[
                "execution_authorization"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
        )

        violations += int(
            auth.ne(
                "NONE"
            ).sum()
        )

    return violations


def _build_plan_map(
    plans: pd.DataFrame,
) -> dict:
    out = {}

    if (
        plans.empty
        or "change_plan_id"
        not in plans.columns
    ):
        return out

    for _, row in plans.iterrows():
        rid = _text(
            row.get(
                "change_plan_id"
            )
        )
        if rid:
            out[
                rid
            ] = row.to_dict()

    return out


def _build_event_map(
    events: pd.DataFrame,
) -> dict:
    out = {}

    if (
        events.empty
        or "implementation_id"
        not in events.columns
    ):
        return out

    for _, row in events.iterrows():
        rid = _text(
            row.get(
                "implementation_id"
            )
        )
        if rid:
            out[
                rid
            ] = row.to_dict()

    return out


def _parent_link_issues(
    plans: pd.DataFrame,
    events: pd.DataFrame,
    reviews: pd.DataFrame,
) -> list[str]:
    issues = []

    plan_map = _build_plan_map(
        plans
    )
    event_map = _build_event_map(
        events
    )

    if not events.empty:
        for _, row in events.iterrows():
            event = row.to_dict()

            plan_id = _text(
                event.get(
                    "change_plan_id"
                )
            )
            parent = plan_map.get(
                plan_id
            )

            if not parent:
                issues.append(
                    "IMPLEMENTATION_PARENT_PLAN_MISSING"
                )
                continue

            if (
                _text(
                    event.get(
                        "change_plan_record_hash"
                    )
                )
                != _text(
                    parent.get(
                        "record_hash"
                    )
                )
            ):
                issues.append(
                    "IMPLEMENTATION_PARENT_PLAN_HASH_MISMATCH"
                )

    if not reviews.empty:
        for _, row in reviews.iterrows():
            review = row.to_dict()

            plan_id = _text(
                review.get(
                    "change_plan_id"
                )
            )
            plan_parent = plan_map.get(
                plan_id
            )

            if not plan_parent:
                issues.append(
                    "EFFECT_REVIEW_PARENT_PLAN_MISSING"
                )
            elif (
                _text(
                    review.get(
                        "change_plan_record_hash"
                    )
                )
                != _text(
                    plan_parent.get(
                        "record_hash"
                    )
                )
            ):
                issues.append(
                    "EFFECT_REVIEW_PARENT_PLAN_HASH_MISMATCH"
                )

            event_id = _text(
                review.get(
                    "implementation_id"
                )
            )
            event_parent = event_map.get(
                event_id
            )

            if not event_parent:
                issues.append(
                    "EFFECT_REVIEW_PARENT_IMPLEMENTATION_MISSING"
                )
            elif (
                _text(
                    review.get(
                        "implementation_record_hash"
                    )
                )
                != _text(
                    event_parent.get(
                        "record_hash"
                    )
                )
            ):
                issues.append(
                    "EFFECT_REVIEW_PARENT_IMPLEMENTATION_HASH_MISMATCH"
                )

    return list(
        dict.fromkeys(
            issues
        )
    )


def build_forecast_calibration_release_gate(
    change_plans: pd.DataFrame | None,
    implementation_events: pd.DataFrame | None,
    effect_reviews: pd.DataFrame | None,
    learning_lineages: pd.DataFrame | None,
    *,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()

    plans = _ensure_df(
        change_plans
    )
    events = _ensure_df(
        implementation_events
    )
    reviews = _ensure_df(
        effect_reviews
    )
    learning = _ensure_df(
        learning_lineages
    )

    plan_integrity = _integrity_counts(
        plans,
        forecast_change_plan_integrity,
    )
    event_integrity = _integrity_counts(
        events,
        forecast_implementation_integrity,
    )
    review_integrity = _integrity_counts(
        reviews,
        forecast_effect_review_integrity,
    )

    parent_issues = _parent_link_issues(
        plans,
        events,
        reviews,
    )

    auth_violations = _execution_authorization_violations(
        [
            plans,
            events,
            reviews,
        ]
    )

    checks = []

    for label, summary in [
        (
            "Forecast Change Plan Integrity",
            plan_integrity,
        ),
        (
            "Forecast Implementation Event Integrity",
            event_integrity,
        ),
        (
            "Forecast Effect Review Integrity",
            review_integrity,
        ),
    ]:
        failures = (
            int(
                summary[
                    "mismatch"
                ]
            )
            + int(
                summary[
                    "missing"
                ]
            )
        )

        checks.append(
            {
                "layer": "TECHNICAL",
                "check": label,
                "status": (
                    "PASS"
                    if failures == 0
                    else "FAIL"
                ),
                "detail": (
                    f"records {summary['total']} · "
                    f"OK {summary['ok']} · "
                    f"MISMATCH {summary['mismatch']} · "
                    f"MISSING {summary['missing']}"
                ),
                "action": (
                    ""
                    if failures == 0
                    else "Hash mismatch / missing immutable hash를 확인"
                ),
            }
        )

    checks.append(
        {
            "layer": "TECHNICAL",
            "check": "Forecast Parent Lineage Integrity",
            "status": (
                "PASS"
                if not parent_issues
                else "FAIL"
            ),
            "detail": (
                "parent link issues 0"
                if not parent_issues
                else " | ".join(
                    parent_issues
                )
            ),
            "action": (
                ""
                if not parent_issues
                else "Change Plan → Implementation → Effect Review parent/hash 연결 확인"
            ),
        }
    )

    checks.append(
        {
            "layer": "TECHNICAL",
            "check": "Forecast Execution Authorization Invariant",
            "status": (
                "PASS"
                if auth_violations == 0
                else "FAIL"
            ),
            "detail": (
                f"non-NONE records {auth_violations}"
            ),
            "action": (
                ""
                if auth_violations == 0
                else "Forecast Calibration record의 Execution Authorization 확인"
            ),
        }
    )

    technical_fail = sum(
        1
        for row in checks
        if row[
            "status"
        ] == "FAIL"
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "FAIL"
    )

    change_queue = build_forecast_change_queue(
        plans,
        today=current_date,
    )

    implementation_queue = build_forecast_implementation_queue(
        plans,
        events,
        learning,
        min_post_samples=3,
        today=current_date,
    )

    effect_queue = build_forecast_effect_queue(
        plans,
        events,
        reviews,
        learning,
        min_post_samples=3,
        today=current_date,
    )

    change_open = int(
        len(
            change_queue
        )
    )
    implementation_open = int(
        len(
            implementation_queue
        )
    )
    effect_open = int(
        len(
            effect_queue
        )
    )

    if (
        change_open
        + implementation_open
        + effect_open
        == 0
    ):
        operating_status = "PASS"
    else:
        operating_status = "REVIEW"

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Forecast Calibration Open Work",
            "status": operating_status,
            "detail": (
                f"Change {change_open} · "
                f"Implementation {implementation_open} · "
                f"Effect {effect_open}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else "0E / 0F / 0G Queue에서 실제 Proof/Implementation 일정에 따라 추적"
            ),
        }
    )

    return {
        "release_gate":
            release_gate,
        "technical_pass":
            sum(
                1
                for row in checks
                if (
                    row[
                        "layer"
                    ]
                    == "TECHNICAL"
                    and row[
                        "status"
                    ]
                    == "PASS"
                )
            ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "change_open":
            change_open,
        "implementation_open":
            implementation_open,
        "effect_open":
            effect_open,
        "parent_link_issues":
            len(
                parent_issues
            ),
        "execution_authorization_violations":
            auth_violations,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                FORECAST_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }
