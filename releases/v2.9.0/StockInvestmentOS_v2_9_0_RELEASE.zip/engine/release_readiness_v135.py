from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_scorecard_input import (
    FLOW_SCORECARD_INPUT_SNAPSHOT_COLS,
    build_flow_scorecard_input_qualification,
    flow_scorecard_input_snapshot_integrity,
    latest_flow_scorecard_input_snapshot,
)
from engine.operations_flow_projection_scorecard import (
    build_flow_projection_scorecard,
)
from engine.operations_flow_projection_outcome import (
    flow_projection_outcome_snapshot_integrity,
)
from engine.operations_flow_projection_outcome_evidence import (
    flow_projection_outcome_evidence_snapshot_integrity,
)
from engine.operations_flow_projection_review import (
    flow_projection_review_snapshot_integrity,
)
from engine.operations_flow_projection import (
    flow_projection_snapshot_integrity,
)


SCORECARD_INPUT_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

SCORECARD_INPUT_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V135_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


KNOWN_INPUT_STATES = {
    "SCORECARD_INPUT_HISTORY_REQUIRED",
    "SCORECARD_INPUT_EVIDENCE_AUDIT_REQUIRED",
    "SCORECARD_INPUT_UNQUALIFIED_REVIEW",
    "SCORECARD_INPUT_INTEGRITY_REVIEW",
    "SCORECARD_INPUT_LINEAGE_REVIEW",
    "SCORECARD_INPUT_TIME_ORDER_REVIEW",
    "SCORECARD_INPUT_READY",
}

HARD_INPUT_STATES = {
    "SCORECARD_INPUT_INTEGRITY_REVIEW",
    "SCORECARD_INPUT_LINEAGE_REVIEW",
    "SCORECARD_INPUT_TIME_ORDER_REVIEW",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = 0
    ok = 0
    missing = 0
    mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty or id_col not in df.columns:
        return {}, 0

    index = {}
    duplicate = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))
        if not item_id:
            continue
        if item_id in index:
            duplicate += 1
        index[item_id] = item

    return index, duplicate


def build_v135_scorecard_input_context(
    *,
    outcome_snapshots: pd.DataFrame | None,
    outcome_evidence_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
    projection_snapshots: pd.DataFrame | None,
    scorecard_input_snapshots: pd.DataFrame | None,
) -> dict:
    outcome_df = pd.DataFrame() if outcome_snapshots is None else outcome_snapshots.copy()
    evidence_df = pd.DataFrame() if outcome_evidence_snapshots is None else outcome_evidence_snapshots.copy()
    review_df = pd.DataFrame() if review_snapshots is None else review_snapshots.copy()
    projection_df = pd.DataFrame() if projection_snapshots is None else projection_snapshots.copy()
    input_df = _ensure_cols(
        scorecard_input_snapshots,
        FLOW_SCORECARD_INPUT_SNAPSHOT_COLS,
    )

    qualification = build_flow_scorecard_input_qualification(
        outcome_df,
        evidence_df,
        review_df,
        projection_df,
    )

    scorecard = build_flow_projection_scorecard(
        qualification.get(
            "qualified_outcome_history",
            pd.DataFrame(),
        )
    )

    latest_input = latest_flow_scorecard_input_snapshot(
        input_df
    )
    latest_integrity = (
        _text(
            flow_scorecard_input_snapshot_integrity(
                latest_input
            ).get("status")
        ).upper()
        if latest_input
        else "NONE"
    )

    return {
        "outcome_snapshots": outcome_df,
        "outcome_evidence_snapshots": evidence_df,
        "review_snapshots": review_df,
        "projection_snapshots": projection_df,
        "scorecard_input_snapshots": input_df,
        "qualification": qualification,
        "scorecard": scorecard,
        "scorecard_input_integrity": _integrity_counts(
            input_df,
            flow_scorecard_input_snapshot_integrity,
        ),
        "latest_scorecard_input": latest_input,
        "latest_scorecard_input_integrity":
            latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v135_scorecard_input_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    q = ctx.get("qualification") or {}
    sc = ctx.get("scorecard") or {}
    counts = ctx.get("scorecard_input_integrity") or {}

    state = _text(
        q.get("qualification_state")
    ).upper()
    guard = _text(
        q.get("scorecard_guard")
    ).upper()

    total = _int(q.get("outcome_records_total"))
    valid = _int(q.get("valid_outcome_records"))
    invalid = _int(q.get("invalid_outcome_records"))
    qualified = _int(q.get("qualified_outcomes"))
    unqualified = _int(q.get("unqualified_outcomes"))
    duplicate = _int(q.get("duplicate_outcomes"))
    lineage_mismatch = _int(
        q.get("lineage_mismatch_count")
    )
    time_mismatch = _int(
        q.get("time_order_mismatch_count")
    )

    checks = []

    snapshot_integrity_ok = (
        _int(counts.get("missing")) == 0
        and _int(counts.get("mismatch")) == 0
    )
    checks.append(
        _technical_row(
            "Scorecard Input Snapshot Integrity",
            snapshot_integrity_ok,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "operations_flow_scorecard_input_snapshots.csv immutable hash 확인",
        )
    )

    vocab_ok = state in KNOWN_INPUT_STATES
    guard_ok = (
        (state == "SCORECARD_INPUT_READY" and guard == "ALLOW_SCORECARD_INPUT")
        or (
            state != "SCORECARD_INPUT_READY"
            and guard == "HOLD_SCORECARD_INPUT"
        )
    )
    checks.append(
        _technical_row(
            "Scorecard Input State / Guard Vocabulary",
            vocab_ok and guard_ok,
            f"state {state or 'MISSING'} · guard {guard or 'MISSING'}",
            "Scorecard Input state/guard mapping 확인",
        )
    )

    partition_ok = (
        total >= 0
        and valid >= 0
        and invalid >= 0
        and qualified >= 0
        and unqualified >= 0
        and duplicate >= 0
        and total == valid + invalid
        and qualified + unqualified + duplicate == valid
    )
    checks.append(
        _technical_row(
            "Outcome Qualification Cardinality Invariant",
            partition_ok,
            (
                f"total {total} · valid {valid} · invalid {invalid} · "
                f"qualified {qualified} · unqualified {unqualified} · "
                f"duplicates {duplicate}"
            ),
            "Outcome qualification partition / duplicate 계산 확인",
        )
    )

    hard_failure = (
        state in HARD_INPUT_STATES
        or invalid > 0
        or lineage_mismatch > 0
        or time_mismatch > 0
    )
    checks.append(
        _technical_row(
            "Scorecard Input Source Safety Invariant",
            not hard_failure,
            (
                f"state {state or 'MISSING'} · invalid {invalid} · "
                f"lineage mismatch {lineage_mismatch} · "
                f"time-order mismatch {time_mismatch}"
            ),
            "Outcome/Evidence/Review/Projection source integrity와 time-order 확인",
        )
    )

    duplicate_safe = (
        duplicate <= valid
        and qualified <= valid
        and (
            valid == 0
            or qualified + duplicate <= valid
        )
    )
    checks.append(
        _technical_row(
            "Scorecard Input Duplicate Resistance Invariant",
            duplicate_safe,
            (
                f"valid {valid} · qualified {qualified} · "
                f"duplicate collapsed {duplicate}"
            ),
            "같은 Projection + Trend endpoint 중복 Outcome collapse 확인",
        )
    )

    scorecard_state = _text(
        sc.get("scorecard_state")
    ).upper()
    if state == "SCORECARD_INPUT_READY":
        handoff_ok = (
            qualified > 0
            and scorecard_state
            not in {
                "",
                "SCORECARD_HISTORY_REQUIRED",
            }
        )
    else:
        handoff_ok = (
            scorecard_state
            == "SCORECARD_HISTORY_REQUIRED"
        )

    checks.append(
        _technical_row(
            "Scorecard Input → Scorecard Hand-off Invariant",
            handoff_ok,
            (
                f"input {state or 'MISSING'} · "
                f"qualified {qualified} · "
                f"scorecard {scorecard_state or 'MISSING'}"
            ),
            "qualified Outcome history만 Scorecard / Proof Clock에 전달되는지 확인",
        )
    )

    if state == "SCORECARD_INPUT_READY":
        lineage_complete = all(
            _text(q.get(field))
            for field in [
                "latest_qualified_outcome_id",
                "latest_qualified_outcome_hash",
                "latest_evidence_audit_id",
                "latest_evidence_audit_hash",
                "latest_review_snapshot_id",
                "latest_review_snapshot_hash",
                "latest_projection_snapshot_id",
                "latest_projection_snapshot_hash",
            ]
        )
    else:
        lineage_complete = True

    checks.append(
        _technical_row(
            "Latest Qualified Outcome Lineage Completeness",
            lineage_complete,
            (
                f"input {state or 'MISSING'} · "
                f"outcome {_text(q.get('latest_qualified_outcome_id')) or 'NONE'} · "
                f"evidence {_text(q.get('latest_evidence_audit_id')) or 'NONE'} · "
                f"review {_text(q.get('latest_review_snapshot_id')) or 'NONE'} · "
                f"projection {_text(q.get('latest_projection_snapshot_id')) or 'NONE'}"
            ),
            "READY Scorecard Input의 Outcome/Evidence/Review/Projection lineage 확인",
        )
    )

    auth_violations = 0
    for item in [q, sc]:
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(item.get(field)).upper()
                not in {"", "NONE"}
            ):
                auth_violations += 1

    input_df = ctx.get("scorecard_input_snapshots")
    if isinstance(input_df, pd.DataFrame) and not input_df.empty:
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in input_df.columns:
                continue
            vals = (
                input_df[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            auth_violations += int(
                (~vals.isin(["", "NONE"])).sum()
            )

    if _text(
        ctx.get("execution_authorization")
    ).upper() != "NONE":
        auth_violations += 1

    checks.append(
        _technical_row(
            "Scorecard Input Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            "Projection / Capacity / Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state == "SCORECARD_INPUT_READY"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Scorecard Input Qualification Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"qualified {qualified} · "
                f"duplicates {duplicate} · "
                f"scorecard {scorecard_state or 'MISSING'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 history/evidence-audit wait는 Technical FAIL로 승격하지 않고 "
                    "audited Outcome evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "qualification_state": state,
        "qualified_outcomes": qualified,
        "scorecard_state": scorecard_state,
        "duplicate_outcomes": duplicate,
        "latest_scorecard_input_integrity":
            _text(
                ctx.get(
                    "latest_scorecard_input_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=SCORECARD_INPUT_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v135_scorecard_input_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    input_df = ctx.get("scorecard_input_snapshots")
    outcome_df = ctx.get("outcome_snapshots")
    evidence_df = ctx.get("outcome_evidence_snapshots")
    review_df = ctx.get("review_snapshots")
    projection_df = ctx.get("projection_snapshots")

    input_df = _ensure_cols(
        input_df,
        FLOW_SCORECARD_INPUT_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        input_df,
        flow_scorecard_input_snapshot_integrity,
    )

    outcome_index, outcome_dup = _index_by_id(
        outcome_df,
        "outcome_snapshot_id",
    )
    evidence_index, evidence_dup = _index_by_id(
        evidence_df,
        "outcome_evidence_snapshot_id",
    )
    review_index, review_dup = _index_by_id(
        review_df,
        "review_snapshot_id",
    )
    projection_index, projection_dup = _index_by_id(
        projection_df,
        "projection_snapshot_id",
    )

    state_guard_violations = 0
    authorization_violations = 0
    outcome_lineage_violations = 0
    upstream_lineage_violations = 0

    input_ids = set()
    input_duplicate_ids = 0

    for _, row in input_df.iterrows():
        item = row.to_dict()
        input_id = _text(
            item.get("scorecard_input_snapshot_id")
        )
        if input_id:
            if input_id in input_ids:
                input_duplicate_ids += 1
            input_ids.add(input_id)

        state = _text(
            item.get("qualification_state")
        ).upper()
        guard = _text(
            item.get("scorecard_guard")
        ).upper()

        valid_mapping = (
            state in KNOWN_INPUT_STATES
            and (
                (
                    state == "SCORECARD_INPUT_READY"
                    and guard == "ALLOW_SCORECARD_INPUT"
                )
                or (
                    state != "SCORECARD_INPUT_READY"
                    and guard == "HOLD_SCORECARD_INPUT"
                )
            )
        )
        if not valid_mapping:
            state_guard_violations += 1

        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if (
                _text(item.get(field)).upper()
                not in {"", "NONE"}
            ):
                authorization_violations += 1

        qualified_count = _int(
            item.get("qualified_outcomes")
        )
        if qualified_count <= 0:
            continue

        outcome_id = _text(
            item.get("latest_qualified_outcome_id")
        )
        outcome_hash = _text(
            item.get("latest_qualified_outcome_hash")
        )
        evidence_id = _text(
            item.get("latest_evidence_audit_id")
        )
        evidence_hash = _text(
            item.get("latest_evidence_audit_hash")
        )
        review_id = _text(
            item.get("latest_review_snapshot_id")
        )
        review_hash = _text(
            item.get("latest_review_snapshot_hash")
        )
        projection_id = _text(
            item.get("latest_projection_snapshot_id")
        )
        projection_hash = _text(
            item.get("latest_projection_snapshot_hash")
        )

        outcome_parent = outcome_index.get(
            outcome_id
        )
        if (
            not outcome_parent
            or _text(
                flow_projection_outcome_snapshot_integrity(
                    outcome_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                outcome_parent.get("snapshot_hash")
            )
            != outcome_hash
        ):
            outcome_lineage_violations += 1

        evidence_parent = evidence_index.get(
            evidence_id
        )
        review_parent = review_index.get(
            review_id
        )
        projection_parent = projection_index.get(
            projection_id
        )

        if (
            not evidence_parent
            or _text(
                flow_projection_outcome_evidence_snapshot_integrity(
                    evidence_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                evidence_parent.get("snapshot_hash")
            )
            != evidence_hash
        ):
            upstream_lineage_violations += 1

        if (
            not review_parent
            or _text(
                flow_projection_review_snapshot_integrity(
                    review_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                review_parent.get("snapshot_hash")
            )
            != review_hash
        ):
            upstream_lineage_violations += 1

        if (
            not projection_parent
            or _text(
                flow_projection_snapshot_integrity(
                    projection_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                projection_parent.get("snapshot_hash")
            )
            != projection_hash
        ):
            upstream_lineage_violations += 1

    checks = []

    integrity_ok = (
        _int(counts.get("missing")) == 0
        and _int(counts.get("mismatch")) == 0
    )
    checks.append(
        _audit_row(
            "Scorecard Input Audit Snapshot Integrity",
            integrity_ok,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Scorecard Input audit immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Scorecard Input Audit State / Guard / Authorization",
            (
                state_guard_violations == 0
                and authorization_violations == 0
            ),
            (
                f"state/guard violations {state_guard_violations} · "
                f"authorization violations {authorization_violations}"
            ),
            "저장된 Scorecard Input audit state/guard/authorization 확인",
        )
    )

    checks.append(
        _audit_row(
            "Scorecard Input Audit → Outcome Lineage",
            (
                outcome_lineage_violations == 0
                and outcome_dup == 0
            ),
            (
                f"violations {outcome_lineage_violations} · "
                f"outcome duplicate ids {outcome_dup}"
            ),
            "READY audit의 latest Outcome id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Scorecard Input Audit → Evidence / Review / Projection Lineage",
            (
                upstream_lineage_violations == 0
                and evidence_dup == 0
                and review_dup == 0
                and projection_dup == 0
            ),
            (
                f"violations {upstream_lineage_violations} · "
                f"evidence duplicates {evidence_dup} · "
                f"review duplicates {review_dup} · "
                f"projection duplicates {projection_dup}"
            ),
            "Evidence/Review/Projection parent id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Scorecard Input Audit Identity Invariant",
            input_duplicate_ids == 0,
            f"duplicate input audit ids {input_duplicate_ids}",
            "scorecard_input_snapshot_id uniqueness 확인",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("qualification") or {}).get(
            "qualification_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state == "SCORECARD_INPUT_READY"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Scorecard Input Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current input {current_state or 'MISSING'} · "
                f"saved audits {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "Scorecard Input proof가 실제 Outcome Evidence에 의해 성숙할 때 audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=SCORECARD_INPUT_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v135_release_readiness(
    *,
    v134_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    scorecard_input_release_gate: str,
    scorecard_input_audit_gate: str,
    input_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(
        v134_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    input_gate = _text(
        scorecard_input_release_gate
    ).upper()
    audit_gate = _text(
        scorecard_input_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.34 Projection Outcome Evidence Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Scorecard Input Qualification Technical Release Gate",
            input_gate == "PASS",
            input_gate or "MISSING",
        ),
        _candidate_row(
            "Scorecard Input Qualification Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(input_operating_status).upper() != "PASS"
        or _text(audit_operating_status).upper() != "PASS"
    ):
        operating_reviews.append(
            "SCORECARD_INPUT_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V135_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v135_integration_crosscheck(
    *,
    integration_consistency: str,
    scorecard_input_release_gate: str,
    scorecard_input_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    input_gate = _text(
        scorecard_input_release_gate
    ).upper()
    audit_gate = _text(
        scorecard_input_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Scorecard Input Qualification Technical Gate",
            input_gate == "PASS",
            input_gate or "MISSING",
        ),
        _candidate_row(
            "Scorecard Input Qualification Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V135_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v135_data_crosscheck(
    *,
    csv_fail_count: int,
    scorecard_input_release_gate: str,
    scorecard_input_audit_gate: str,
    latest_scorecard_input_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    input_gate = _text(
        scorecard_input_release_gate
    ).upper()
    audit_gate = _text(
        scorecard_input_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_scorecard_input_integrity
    ).upper()

    latest_ok = (
        latest_integrity
        in {"OK", "NONE"}
    )

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Scorecard Input Qualification Technical Gate",
            input_gate == "PASS",
            input_gate or "MISSING",
        ),
        _candidate_row(
            "Scorecard Input Qualification Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Scorecard Input Audit Integrity",
            latest_ok,
            latest_integrity or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V135_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
