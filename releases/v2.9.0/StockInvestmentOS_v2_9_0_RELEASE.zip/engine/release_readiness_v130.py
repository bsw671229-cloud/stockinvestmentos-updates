from __future__ import annotations

from typing import Any
import json

import pandas as pd

from engine.operations_flow_evidence_quality import (
    FLOW_EVIDENCE_SNAPSHOT_COLS,
    flow_evidence_snapshot_integrity,
)


EVIDENCE_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

EVIDENCE_LINEAGE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V130_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = 0
    ok = 0
    missing = 0
    mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _fail_count(counts: dict | None) -> int:
    c = counts or {}
    return _int(c.get("missing")) + _int(c.get("mismatch"))


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _latest_snapshot(
    df: pd.DataFrame | None,
) -> dict:
    source = _ensure_cols(
        df,
        FLOW_EVIDENCE_SNAPSHOT_COLS,
    )
    if source.empty:
        return {}

    source["_ts"] = pd.to_datetime(
        source["created_at"],
        errors="coerce",
        utc=True,
    )
    source = source.loc[
        source["_ts"].notna()
    ].sort_values("_ts")

    if source.empty:
        return {}

    return (
        source.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def build_v130_evidence_context(
    *,
    flow_context: dict | None,
    sessions: pd.DataFrame | None,
    trend_snapshots: pd.DataFrame | None,
    evidence_snapshots: pd.DataFrame | None,
) -> dict:
    flow_ctx = flow_context or {}
    evidence = flow_ctx.get("evidence_quality") or {}
    calibration = flow_ctx.get("calibration") or {}

    evidence_df = _ensure_cols(
        evidence_snapshots,
        FLOW_EVIDENCE_SNAPSHOT_COLS,
    )
    latest = _latest_snapshot(evidence_df)

    latest_integrity = (
        _text(
            flow_evidence_snapshot_integrity(
                latest
            ).get("status")
        ).upper()
        if latest
        else "NONE"
    )

    return {
        "flow_context": flow_ctx,
        "evidence": evidence,
        "calibration": calibration,
        "sessions": (
            pd.DataFrame()
            if sessions is None
            else sessions.copy()
        ),
        "trend_snapshots": (
            pd.DataFrame()
            if trend_snapshots is None
            else trend_snapshots.copy()
        ),
        "evidence_snapshots": evidence_df,
        "evidence_integrity": _integrity_counts(
            evidence_df,
            flow_evidence_snapshot_integrity,
        ),
        "latest_evidence": latest,
        "latest_evidence_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v130_evidence_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    ev = ctx.get("evidence") or {}
    cal = ctx.get("calibration") or {}
    integrity = ctx.get("evidence_integrity") or {}

    checks = []

    integrity_fail = _fail_count(integrity)
    checks.append(
        _technical_row(
            "Flow Evidence Snapshot Integrity",
            integrity_fail == 0,
            (
                f"records {_int(integrity.get('total'))} · "
                f"OK {_int(integrity.get('ok'))} · "
                f"MISSING {_int(integrity.get('missing'))} · "
                f"MISMATCH {_int(integrity.get('mismatch'))}"
            ),
            "operations_flow_evidence_snapshots.csv immutable hash 확인",
        )
    )

    pair_issues = _int(ev.get("invalid_session_pairs"))
    invalid_trend = _int(ev.get("invalid_trend_snapshots"))
    invalid_close = _int(ev.get("invalid_session_closes"))
    invalid_open = _int(ev.get("invalid_session_opens"))
    session_integrity_ok = (
        pair_issues == 0
        and invalid_trend == 0
        and invalid_close == 0
        and invalid_open == 0
    )
    checks.append(
        _technical_row(
            "Session / Trend Evidence Integrity Invariant",
            session_integrity_ok,
            (
                f"pair issues {pair_issues} · "
                f"trend invalid {invalid_trend} · "
                f"open invalid {invalid_open} · "
                f"close invalid {invalid_close}"
            ),
            "Daily Operations OPEN/CLOSE lineage와 Trend Snapshot immutable hash 확인",
        )
    )

    lifetime = _int(ev.get("lifetime_qualified_endpoints"))
    consecutive = _int(ev.get("recent_consecutive_endpoints"))
    active = _int(ev.get("capacity_regime_endpoints"))
    qualified = _int(ev.get("qualified_endpoints"))
    intervals = _int(ev.get("qualified_intervals"))

    cardinality_ok = (
        0 <= active <= consecutive <= lifetime
        and qualified == active
        and intervals == max(0, active - 1)
    )
    checks.append(
        _technical_row(
            "Evidence Window Cardinality Invariant",
            cardinality_ok,
            (
                f"lifetime {lifetime} · consecutive {consecutive} · "
                f"capacity regime {active} · qualified {qualified} · "
                f"intervals {intervals}"
            ),
            "recent consecutive window / capacity regime / interval 계산 확인",
        )
    )

    saved = _int(cal.get("saved_trend_snapshots"))
    observed = _int(cal.get("observed_intervals"))
    alignment = _text(
        cal.get("interval_alignment_status")
    ).upper() or "MISSING"

    calibration_alignment_ok = (
        saved == active
        and observed == intervals
        and alignment in {"OK", "NOT_REQUIRED"}
    )
    checks.append(
        _technical_row(
            "Calibration ↔ Evidence Window Alignment",
            calibration_alignment_ok,
            (
                f"saved {saved}/{active} · "
                f"observed {observed}/{intervals} · "
                f"alignment {alignment}"
            ),
            "Calibration saved endpoints / observed intervals가 active evidence window와 일치하는지 확인",
        )
    )

    state = _text(ev.get("evidence_state")).upper()
    guard = _text(ev.get("calibration_history_guard")).upper()
    window = _text(ev.get("evidence_window_state")).upper()
    boundary = _text(ev.get("latest_boundary_status")).upper()
    min_required = max(
        1,
        _int(ev.get("min_qualified_endpoints")),
    )

    allowed_states = {
        "INTEGRITY_REVIEW",
        "CLOSED_SESSION_EVIDENCE_REQUIRED",
        "EVIDENCE_MATURING",
        "EVIDENCE_READY",
    }
    allowed_windows = {
        "INTEGRITY_REVIEW",
        "RECENT_SESSION_GAP",
        "CONSECUTIVE_WINDOW_MATURING",
        "CAPACITY_REGIME_MATURING",
        "WINDOW_READY",
    }

    state_ok = state in allowed_states and window in allowed_windows

    if state == "INTEGRITY_REVIEW":
        state_ok = state_ok and guard == "HOLD_INTEGRITY"
    elif state == "CLOSED_SESSION_EVIDENCE_REQUIRED":
        state_ok = (
            state_ok
            and guard == "HOLD_CLOSED_SESSION"
            and boundary != "QUALIFIED"
            and active == 0
        )
    elif state == "EVIDENCE_MATURING":
        state_ok = (
            state_ok
            and guard == "HOLD_HISTORY"
            and boundary == "QUALIFIED"
            and active < min_required
        )
    elif state == "EVIDENCE_READY":
        state_ok = (
            state_ok
            and guard == "ALLOW_QUALIFIED_CALIBRATION"
            and boundary == "QUALIFIED"
            and active >= min_required
            and window == "WINDOW_READY"
        )

    checks.append(
        _technical_row(
            "Evidence State / History Guard Invariant",
            state_ok,
            (
                f"state {state or 'MISSING'} · "
                f"window {window or 'MISSING'} · "
                f"boundary {boundary or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"qualified {active}/{min_required}"
            ),
            "Evidence State / Window State / Boundary / History Guard 연결 확인",
        )
    )

    latest_capacity = _int(ev.get("latest_capacity"))
    breaks = _int(ev.get("capacity_regime_break_count"))
    capacity_regime_ok = (
        active <= consecutive
        and breaks == max(0, consecutive - active)
    )
    if active > 0:
        capacity_regime_ok = (
            capacity_regime_ok
            and latest_capacity > 0
        )

    checks.append(
        _technical_row(
            "Capacity Regime Isolation Invariant",
            capacity_regime_ok,
            (
                f"latest capacity {latest_capacity} · "
                f"consecutive {consecutive} · "
                f"active regime {active} · "
                f"regime breaks {breaks}"
            ),
            "Capacity 변경 이전 endpoint가 현재 Calibration clock에 혼입되는지 확인",
        )
    )

    execution = _text(
        ctx.get("execution_authorization")
    ).upper()
    auth_ok = execution == "NONE"

    data_sources = [
        ctx.get("evidence_snapshots"),
    ]
    for df in data_sources:
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue
        if "execution_authorization" not in df.columns:
            continue
        values = (
            df["execution_authorization"]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
        )
        if not values.isin(["", "NONE"]).all():
            auth_ok = False

    checks.append(
        _technical_row(
            "Evidence Qualification Authorization Invariant",
            auth_ok,
            "NONE" if auth_ok else "non-NONE authorization detected",
            "Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state == "EVIDENCE_READY"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Flow Evidence Qualification Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"window {window or 'MISSING'} · "
                f"qualified {active}/{min_required} · "
                f"intervals {intervals}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 Evidence WAIT는 Technical FAIL로 승격하지 말고 "
                    "실제 OPEN → Trend Snapshot → CLOSE evidence를 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL"
            and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "evidence_state": state,
        "window_state": window,
        "qualified_endpoints": active,
        "qualified_intervals": intervals,
        "latest_boundary": boundary,
        "latest_evidence_integrity": _text(
            ctx.get("latest_evidence_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=EVIDENCE_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if not isinstance(df, pd.DataFrame) or df.empty or id_col not in df.columns:
        return {}, 0

    index = {}
    duplicate = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        key = _text(item.get(id_col))
        if not key:
            continue
        if key in index:
            duplicate += 1
        index[key] = item

    return index, duplicate


def _lineage_row(
    check: str,
    *,
    checked: int,
    missing: int,
    mismatch: int,
    duplicate: int,
    action: str,
) -> dict:
    passed = (
        missing == 0
        and mismatch == 0
        and duplicate == 0
    )
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": (
            f"checked {checked} · "
            f"missing {missing} · "
            f"mismatch {mismatch} · "
            f"duplicate {duplicate}"
        ),
        "action": "" if passed else action,
    }


def build_v130_evidence_lineage_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    ev = ctx.get("evidence") or {}
    trend_df = (
        ctx.get("trend_snapshots")
        if isinstance(ctx.get("trend_snapshots"), pd.DataFrame)
        else pd.DataFrame()
    )
    sessions = (
        ctx.get("sessions")
        if isinstance(ctx.get("sessions"), pd.DataFrame)
        else pd.DataFrame()
    )
    evidence_df = (
        ctx.get("evidence_snapshots")
        if isinstance(ctx.get("evidence_snapshots"), pd.DataFrame)
        else pd.DataFrame()
    )

    trend_index, trend_dup = _index_by_id(
        trend_df,
        "trend_snapshot_id",
    )
    close_index, close_dup = _index_by_id(
        sessions.loc[
            sessions.get(
                "event_type",
                pd.Series(
                    index=sessions.index,
                    dtype=object,
                ),
            )
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
            .eq("CLOSE")
        ].copy()
        if not sessions.empty and "event_type" in sessions.columns
        else pd.DataFrame(),
        "event_id",
    )

    endpoint_table = ev.get("endpoint_table")
    endpoint_df = (
        endpoint_table
        if isinstance(endpoint_table, pd.DataFrame)
        else pd.DataFrame()
    )

    checked = missing = mismatch = 0
    for _, row in endpoint_df.iterrows():
        checked += 1
        trend_id = _text(row.get("trend_snapshot_id"))
        trend_hash = _text(row.get("snapshot_hash"))
        parent = trend_index.get(trend_id)
        if not trend_id or parent is None:
            missing += 1
            continue
        if _text(parent.get("snapshot_hash")) != trend_hash:
            mismatch += 1

    checks = [
        _lineage_row(
            "Active Evidence Endpoint → Trend Snapshot Lineage",
            checked=checked,
            missing=missing,
            mismatch=mismatch,
            duplicate=trend_dup,
            action="Qualified endpoint trend id/hash와 Trend Snapshot history 확인",
        )
    ]

    checked = missing = mismatch = 0
    for _, row in endpoint_df.iterrows():
        checked += 1
        close_id = _text(row.get("close_event_id"))
        parent = close_index.get(close_id)
        if not close_id or parent is None:
            missing += 1
            continue

        if _text(parent.get("event_type")).upper() != "CLOSE":
            mismatch += 1
            continue

        session_date = _text(row.get("session_date"))
        parent_date = _text(parent.get("session_date"))
        if session_date and parent_date and session_date != parent_date:
            mismatch += 1

    checks.append(
        _lineage_row(
            "Active Evidence Endpoint → Session CLOSE Lineage",
            checked=checked,
            missing=missing,
            mismatch=mismatch,
            duplicate=close_dup,
            action="Qualified endpoint close_event_id와 Daily Operations CLOSE record 확인",
        )
    )

    checked = missing = mismatch = 0
    for _, row in evidence_df.iterrows():
        record = row.to_dict()
        if _text(
            flow_evidence_snapshot_integrity(
                record
            ).get("status")
        ).upper() != "OK":
            continue

        try:
            ids = json.loads(
                _text(record.get("endpoint_ids_json"))
                or "[]"
            )
            hashes = json.loads(
                _text(record.get("endpoint_hashes_json"))
                or "[]"
            )
        except Exception:
            checked += 1
            mismatch += 1
            continue

        if len(ids) != len(hashes):
            checked += max(len(ids), len(hashes), 1)
            mismatch += 1
            continue

        for trend_id, trend_hash in zip(ids, hashes):
            checked += 1
            parent = trend_index.get(_text(trend_id))
            if parent is None:
                missing += 1
                continue
            if _text(parent.get("snapshot_hash")) != _text(trend_hash):
                mismatch += 1

    checks.append(
        _lineage_row(
            "Evidence Audit Snapshot → Trend Snapshot Lineage",
            checked=checked,
            missing=missing,
            mismatch=mismatch,
            duplicate=0,
            action="Evidence Snapshot endpoint id/hash JSON과 Trend Snapshot history 확인",
        )
    )

    active = _int(ev.get("qualified_endpoints"))
    intervals = _int(ev.get("qualified_intervals"))
    cal = ctx.get("calibration") or {}
    saved = _int(cal.get("saved_trend_snapshots"))
    observed = _int(cal.get("observed_intervals"))
    alignment = _text(
        cal.get("interval_alignment_status")
    ).upper() or "MISSING"

    cal_mismatch = 0
    if saved != active:
        cal_mismatch += 1
    if observed != intervals:
        cal_mismatch += 1
    if alignment not in {"OK", "NOT_REQUIRED"}:
        cal_mismatch += 1

    checks.append(
        _lineage_row(
            "Evidence Window → Calibration Lineage",
            checked=1,
            missing=0,
            mismatch=cal_mismatch,
            duplicate=0,
            action="active evidence window와 Calibration saved/observed interval alignment 확인",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    state = _text(
        ev.get("evidence_state")
    ).upper()
    operating_status = (
        "PASS"
        if state == "EVIDENCE_READY"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Evidence Lineage Operating Stage",
            "status": operating_status,
            "detail": (
                f"evidence {state or 'MISSING'} · "
                f"active endpoints {active} · "
                f"intervals {intervals}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "EVIDENCE_MATURING / CLOSED_SESSION_EVIDENCE_REQUIRED는 "
                    "lineage Technical FAIL로 취급하지 않음"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL"
            and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=EVIDENCE_LINEAGE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v130_release_readiness(
    *,
    v129_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    evidence_release_gate: str,
    evidence_lineage_gate: str,
    evidence_operating_status: str,
    lineage_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(v129_release_status).upper()
    integration = _text(integration_consistency).upper()
    csv_fail = _int(csv_fail_count)
    evidence_gate = _text(evidence_release_gate).upper()
    lineage_gate = _text(evidence_lineage_gate).upper()
    execution = _text(execution_authorization).upper()

    checks = [
        _candidate_row(
            "v1.29 Projection Governance Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Flow Evidence Qualification Technical Release Gate",
            evidence_gate == "PASS",
            evidence_gate or "MISSING",
        ),
        _candidate_row(
            "Flow Evidence Lineage Integrity Gate",
            lineage_gate == "PASS",
            lineage_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(evidence_operating_status).upper() != "PASS"
        or _text(lineage_operating_status).upper() != "PASS"
    ):
        operating_reviews.append(
            "FLOW_EVIDENCE_QUALIFICATION_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(operating_reviews),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V130_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v130_integration_crosscheck(
    *,
    integration_consistency: str,
    evidence_release_gate: str,
    evidence_lineage_gate: str,
) -> dict:
    integration = _text(integration_consistency).upper()
    evidence = _text(evidence_release_gate).upper()
    lineage = _text(evidence_lineage_gate).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Flow Evidence Qualification Technical Gate",
            evidence == "PASS",
            evidence or "MISSING",
        ),
        _candidate_row(
            "Flow Evidence Lineage Integrity Gate",
            lineage == "PASS",
            lineage or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V130_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v130_data_crosscheck(
    *,
    csv_fail_count: int,
    evidence_release_gate: str,
    evidence_lineage_gate: str,
    latest_evidence_integrity: str,
) -> dict:
    csv_fail = _int(csv_fail_count)
    evidence = _text(evidence_release_gate).upper()
    lineage = _text(evidence_lineage_gate).upper()
    latest = _text(latest_evidence_integrity).upper()

    latest_ok = latest in {"OK", "NONE"}

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Flow Evidence Qualification Technical Gate",
            evidence == "PASS",
            evidence or "MISSING",
        ),
        _candidate_row(
            "Flow Evidence Lineage Integrity Gate",
            lineage == "PASS",
            lineage or "MISSING",
        ),
        _candidate_row(
            "Latest Flow Evidence Snapshot Integrity",
            latest_ok,
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V130_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
