from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    flow_projection_scorecard_snapshot_integrity,
    latest_flow_projection_scorecard_snapshot,
)


FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS = [
    "recalibration_review_id",
    "created_at",
    "review_state",
    "source_scorecard_snapshot_id",
    "source_scorecard_hash",
    "source_scorecard_created_at",
    "source_scorecard_integrity",
    "source_scorecard_freshness",
    "source_scorecard_state",
    "source_error_regime",
    "source_proof_clock_count",
    "source_proof_clock_target",
    "primary_attribution",
    "secondary_attribution",
    "attribution_detail",
    "source_review_confirmed",
    "alternatives_reviewed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


RECALIBRATION_REVIEW_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


ATTRIBUTION_VALUES = {
    "MODEL",
    "PARAMETER",
    "EXECUTION",
    "EXOGENOUS",
}

RECALIBRATION_STATES = {
    "RECALIBRATION_UPSTREAM_WAIT",
    "RECALIBRATION_NOT_REQUIRED",
    "RECALIBRATION_REBASE_FIRST",
    "RECALIBRATION_PROOF_MATURING",
    "RECALIBRATION_SCORECARD_SOURCE_REQUIRED",
    "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW",
    "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW",
    "RECALIBRATION_ATTRIBUTION_REQUIRED",
    "RECALIBRATION_CONTRACT_LOCKED",
    "RECALIBRATION_CONTRACT_SUPERSEDED",
    "RECALIBRATION_CONTRACT_INTEGRITY_REVIEW",
}


_SCORECARD_INT_FIELDS = {
    "outcome_snapshots_total",
    "unique_evidence_endpoints",
    "eligible_outcomes",
    "invalid_outcome_count",
    "proof_clock_count",
    "proof_clock_target",
    "latest_current_groups",
    "latest_attention_groups",
    "latest_capacity",
    "latest_evidence_intervals",
    "override_review_ttl_intervals",
}

_SCORECARD_FLOAT_FIELDS = {
    "avg_abs_pct_error",
    "latest_abs_pct_error",
    "latest_signed_burn_error",
    "latest_realized_avg_burn",
    "base_burn_rate",
}

_SCORECARD_TEXT_FIELDS = {
    "source_projection_snapshot_id",
    "proof_clock_state",
    "error_regime",
    "scorecard_state",
    "latest_evaluation_state",
    "latest_recalibration_state",
    "latest_capacity_decision_state",
    "capacity_override_review_gate",
    "override_review_approval_state",
    "projection_authorization",
    "capacity_authorization",
    "capacity_override_authorization",
    "execution_authorization",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def scorecard_source_freshness(
    scorecard: dict | None,
    source_snapshot: dict | None,
    *,
    float_tolerance: float = 1e-8,
) -> dict:
    current = scorecard or {}
    source = source_snapshot or {}

    if not source:
        return {
            "status": "MISSING",
            "source_integrity": "NONE",
            "mismatches": [],
            "mismatch_count": 0,
        }

    integrity = flow_projection_scorecard_snapshot_integrity(source)
    integrity_status = _text(
        integrity.get("status")
    ).upper()

    if integrity_status != "OK":
        return {
            "status": "INVALID",
            "source_integrity": integrity_status or "INVALID",
            "mismatches": ["snapshot_hash"],
            "mismatch_count": 1,
        }

    mismatches = []

    for field in _SCORECARD_INT_FIELDS:
        if _int(current.get(field)) != _int(source.get(field)):
            mismatches.append(field)

    for field in _SCORECARD_FLOAT_FIELDS:
        if (
            abs(
                _float(current.get(field))
                - _float(source.get(field))
            )
            > float(float_tolerance)
        ):
            mismatches.append(field)

    for field in _SCORECARD_TEXT_FIELDS:
        if _text(current.get(field)) != _text(source.get(field)):
            mismatches.append(field)

    return {
        "status": "CURRENT" if not mismatches else "DRIFTED",
        "source_integrity": "OK",
        "mismatches": mismatches,
        "mismatch_count": len(mismatches),
    }


def latest_recalibration_review_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )
    if df.empty:
        return {}

    for col in FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _review_payload(row: dict) -> dict:
    int_fields = {
        "source_proof_clock_count",
        "source_proof_clock_target",
    }
    bool_fields = {
        "source_review_confirmed",
        "alternatives_reviewed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS:
        if col in {
            "recalibration_review_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(row.get(col))
        elif col in bool_fields:
            payload[col] = bool(_bool(row.get(col)))
        else:
            payload[col] = _text(row.get(col))

    return payload


def recalibration_review_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )
    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _review_payload(item)
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def _contract_matches_scorecard(
    contract: dict | None,
    source_scorecard: dict | None,
) -> bool:
    row = contract or {}
    source = source_scorecard or {}

    if not row or not source:
        return False

    if (
        recalibration_review_snapshot_integrity(
            row
        ).get("status")
        != "OK"
    ):
        return False

    if _text(row.get("review_state")).upper() != "RECALIBRATION_CONTRACT_LOCKED":
        return False

    return (
        _text(
            row.get("source_scorecard_snapshot_id")
        )
        == _text(
            source.get("scorecard_snapshot_id")
        )
        and _text(
            row.get("source_scorecard_hash")
        )
        == _text(
            source.get("snapshot_hash")
        )
    )


def build_flow_recalibration_review(
    scorecard: dict | None,
    source_scorecard_snapshot: dict | None,
    review_snapshots: pd.DataFrame | None,
) -> dict:
    sc = scorecard or {}
    source = source_scorecard_snapshot or {}
    history = (
        pd.DataFrame()
        if review_snapshots is None
        else review_snapshots.copy()
    )

    scorecard_state = _text(
        sc.get("scorecard_state")
    ).upper()
    error_regime = _text(
        sc.get("error_regime")
    ).upper()
    proof_count = _int(
        sc.get("proof_clock_count")
    )
    proof_target = max(
        1,
        _int(sc.get("proof_clock_target")),
    )

    base = {
        "source_scorecard_snapshot_id": _text(
            source.get("scorecard_snapshot_id")
        ),
        "source_scorecard_hash": _text(
            source.get("snapshot_hash")
        ),
        "source_scorecard_created_at": _text(
            source.get("created_at")
        ),
        "source_scorecard_integrity": "NONE",
        "source_scorecard_freshness": "NOT_REQUIRED",
        "source_scorecard_mismatches": [],
        "scorecard_state": scorecard_state,
        "error_regime": error_regime,
        "proof_clock_count": proof_count,
        "proof_clock_target": proof_target,
        "latest_contract": {},
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    # Upstream states that do not justify recalibration review yet.
    if scorecard_state in {
        "",
        "SCORECARD_HISTORY_REQUIRED",
        "SCORECARD_EVIDENCE_MATURING",
    }:
        return {
            **base,
            "review_state": "RECALIBRATION_UPSTREAM_WAIT",
            "review_guard": "HOLD_PROOF_CLOCK",
            "source_scorecard_freshness": "NOT_REQUIRED",
        }

    if scorecard_state == "MONITOR":
        return {
            **base,
            "review_state": "RECALIBRATION_NOT_REQUIRED",
            "review_guard": "NO_RECALIBRATION_ACTION",
            "source_scorecard_freshness": "NOT_REQUIRED",
        }

    if scorecard_state == "REBASE_REQUIRED":
        return {
            **base,
            "review_state": "RECALIBRATION_REBASE_FIRST",
            "review_guard": "HOLD_ASSUMPTION_DRIFT",
            "source_scorecard_freshness": "NOT_REQUIRED",
        }

    if scorecard_state == "RECALIBRATION_PROOF_MATURING":
        return {
            **base,
            "review_state": "RECALIBRATION_PROOF_MATURING",
            "review_guard": "HOLD_PROOF_CLOCK",
            "source_scorecard_freshness": "NOT_REQUIRED",
        }

    if scorecard_state != "RECALIBRATION_PROOF_MET":
        return {
            **base,
            "review_state": "RECALIBRATION_UPSTREAM_WAIT",
            "review_guard": "HOLD_PROOF_CLOCK",
            "source_scorecard_freshness": "NOT_REQUIRED",
        }

    fresh = scorecard_source_freshness(
        sc,
        source,
    )
    fresh_status = _text(
        fresh.get("status")
    ).upper()
    source_integrity = _text(
        fresh.get("source_integrity")
    ).upper()

    base.update(
        {
            "source_scorecard_integrity":
                source_integrity,
            "source_scorecard_freshness":
                fresh_status,
            "source_scorecard_mismatches":
                list(
                    fresh.get("mismatches", [])
                ),
        }
    )

    if fresh_status == "MISSING":
        return {
            **base,
            "review_state": "RECALIBRATION_SCORECARD_SOURCE_REQUIRED",
            "review_guard": "HOLD_SCORECARD_SOURCE",
        }

    if fresh_status == "INVALID":
        return {
            **base,
            "review_state": "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW",
            "review_guard": "HOLD_SCORECARD_SOURCE",
        }

    if fresh_status == "DRIFTED":
        return {
            **base,
            "review_state": "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW",
            "review_guard": "HOLD_SCORECARD_SOURCE",
        }

    latest = latest_recalibration_review_snapshot(
        history
    )

    if latest:
        integrity = recalibration_review_snapshot_integrity(
            latest
        )
        if _text(integrity.get("status")).upper() != "OK":
            return {
                **base,
                "latest_contract": latest,
                "review_state": "RECALIBRATION_CONTRACT_INTEGRITY_REVIEW",
                "review_guard": "HOLD_CONTRACT_INTEGRITY",
            }

        latest_source_id = _text(
            latest.get("source_scorecard_snapshot_id")
        )
        latest_source_hash = _text(
            latest.get("source_scorecard_hash")
        )

        if (
            latest_source_id
            == _text(
                source.get("scorecard_snapshot_id")
            )
            and latest_source_hash
            == _text(
                source.get("snapshot_hash")
            )
        ):
            if _text(
                latest.get("review_state")
            ).upper() == "RECALIBRATION_CONTRACT_LOCKED":
                return {
                    **base,
                    "latest_contract": latest,
                    "review_state": "RECALIBRATION_CONTRACT_LOCKED",
                    "review_guard": "CONTRACT_LOCKED",
                }
        elif _text(
            latest.get("review_state")
        ).upper() == "RECALIBRATION_CONTRACT_LOCKED":
            return {
                **base,
                "latest_contract": latest,
                "review_state": "RECALIBRATION_CONTRACT_SUPERSEDED",
                "review_guard": "HOLD_SCORECARD_SOURCE",
            }

    return {
        **base,
        "latest_contract": latest,
        "review_state": "RECALIBRATION_ATTRIBUTION_REQUIRED",
        "review_guard": "HUMAN_ATTRIBUTION_REQUIRED",
    }


def build_flow_recalibration_review_queue(
    review: dict | None,
) -> pd.DataFrame:
    rv = review or {}
    state = _text(
        rv.get("review_state")
    ).upper()

    mapping = {
        "RECALIBRATION_UPSTREAM_WAIT": (
            "RR2",
            "WAIT",
            "RECALIBRATION_UPSTREAM_WAIT",
            "Proof Clock / qualified Outcome history가 아직 충분하지 않음",
            "실제 qualified Outcome evidence를 자연스럽게 축적",
        ),
        "RECALIBRATION_NOT_REQUIRED": (
            "RR3",
            "MONITOR",
            "RECALIBRATION_NOT_REQUIRED",
            "현재 Scorecard가 MONITOR 상태",
            "자동 Recalibration 없이 추가 evidence 모니터링",
        ),
        "RECALIBRATION_REBASE_FIRST": (
            "RR0",
            "REVIEW",
            "RECALIBRATION_REBASE_FIRST",
            "Capacity assumption drift가 model error보다 우선",
            "새 Calibration/Projection으로 rebase한 뒤 새 evidence clock 시작",
        ),
        "RECALIBRATION_PROOF_MATURING": (
            "RR1",
            "WAIT",
            "RECALIBRATION_PROOF_MATURING",
            (
                f"proof {rv.get('proof_clock_count',0)}/"
                f"{rv.get('proof_clock_target',0)}"
            ),
            "중복 저장 없이 새로운 qualified evidence endpoint를 기다림",
        ),
        "RECALIBRATION_SCORECARD_SOURCE_REQUIRED": (
            "RR1",
            "REVIEW",
            "RECALIBRATION_SCORECARD_SOURCE_REQUIRED",
            "CURRENT Scorecard Snapshot 없음",
            "1K에서 현재 Scorecard Snapshot 저장",
        ),
        "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW": (
            "RR0",
            "BLOCKED",
            "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY",
            "Scorecard Snapshot integrity mismatch",
            "Scorecard Snapshot hash/integrity를 먼저 복구",
        ),
        "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW": (
            "RR0",
            "BLOCKED",
            "RECALIBRATION_SCORECARD_SOURCE_DRIFT",
            (
                "Scorecard Snapshot이 live Scorecard와 다름"
            ),
            "현재 Scorecard를 검토한 뒤 새 Scorecard Snapshot 저장",
        ),
        "RECALIBRATION_ATTRIBUTION_REQUIRED": (
            "RR0",
            "REVIEW",
            "RECALIBRATION_ATTRIBUTION_REQUIRED",
            (
                f"{rv.get('error_regime','')} · "
                f"proof {rv.get('proof_clock_count',0)}/"
                f"{rv.get('proof_clock_target',0)}"
            ),
            "Model / Parameter / Execution / Exogenous 원인 분해 Human Review 수행",
        ),
        "RECALIBRATION_CONTRACT_LOCKED": (
            "RR3",
            "MONITOR",
            "RECALIBRATION_CONTRACT_LOCKED",
            "Human attribution contract locked",
            "자동 parameter 변경 없이 별도 Recalibration proposal 단계로 전달",
        ),
        "RECALIBRATION_CONTRACT_SUPERSEDED": (
            "RR0",
            "REVIEW",
            "RECALIBRATION_CONTRACT_SUPERSEDED",
            "새 Scorecard source로 기존 contract가 superseded됨",
            "새 Scorecard 기준으로 원인 분해를 다시 검토",
        ),
        "RECALIBRATION_CONTRACT_INTEGRITY_REVIEW": (
            "RR0",
            "BLOCKED",
            "RECALIBRATION_CONTRACT_INTEGRITY",
            "Recalibration Review audit hash mismatch",
            "audit integrity를 먼저 복구",
        ),
    }

    priority, status, issue, detail, action = mapping.get(
        state,
        (
            "RR0",
            "BLOCKED",
            "RECALIBRATION_UNKNOWN_STATE",
            state or "MISSING",
            "Recalibration state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority": priority,
                "status": status,
                "issue": issue,
                "detail": detail,
                "next_action": action,
                "go_to": "Operations Control Tower",
            }
        ],
        columns=RECALIBRATION_REVIEW_QUEUE_COLS,
    )


def build_flow_recalibration_review_lock(
    review: dict,
    *,
    primary_attribution: str,
    secondary_attribution: str = "",
    attribution_detail: str,
    source_review_confirmed: bool,
    alternatives_reviewed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    rv = review or {}

    if _text(
        rv.get("review_state")
    ).upper() != "RECALIBRATION_ATTRIBUTION_REQUIRED":
        raise ValueError(
            "Recalibration Contract는 ATTRIBUTION_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    primary = _text(
        primary_attribution
    ).upper()
    secondary = _text(
        secondary_attribution
    ).upper()

    if primary not in ATTRIBUTION_VALUES:
        raise ValueError(
            "Primary attribution은 MODEL / PARAMETER / EXECUTION / EXOGENOUS 중 하나여야 합니다."
        )

    if secondary and secondary not in ATTRIBUTION_VALUES:
        raise ValueError(
            "Secondary attribution도 정의된 attribution vocabulary를 사용해야 합니다."
        )

    if secondary == primary:
        raise ValueError(
            "Secondary attribution은 Primary와 달라야 합니다."
        )

    detail = _text(
        attribution_detail
    )
    if len(detail) < 10:
        raise ValueError(
            "Attribution detail을 10자 이상 기록하세요."
        )

    confirmations = {
        "source_review_confirmed": bool(
            source_review_confirmed
        ),
        "alternatives_reviewed": bool(
            alternatives_reviewed
        ),
        "no_auto_recalibration_confirmed": bool(
            no_auto_recalibration_confirmed
        ),
        "no_auto_capacity_confirmed": bool(
            no_auto_capacity_confirmed
        ),
        "no_execution_authorization_confirmed": bool(
            no_execution_authorization_confirmed
        ),
        "human_review_confirmed": bool(
            human_review_confirmed
        ),
    }

    if not all(confirmations.values()):
        raise ValueError(
            "Recalibration Human Review 확인사항을 모두 검토해야 합니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        "review_state": "RECALIBRATION_CONTRACT_LOCKED",
        "source_scorecard_snapshot_id": _text(
            rv.get("source_scorecard_snapshot_id")
        ),
        "source_scorecard_hash": _text(
            rv.get("source_scorecard_hash")
        ),
        "source_scorecard_created_at": _text(
            rv.get("source_scorecard_created_at")
        ),
        "source_scorecard_integrity": _text(
            rv.get("source_scorecard_integrity")
        ),
        "source_scorecard_freshness": _text(
            rv.get("source_scorecard_freshness")
        ),
        "source_scorecard_state": _text(
            rv.get("scorecard_state")
        ),
        "source_error_regime": _text(
            rv.get("error_regime")
        ),
        "source_proof_clock_count": _int(
            rv.get("proof_clock_count")
        ),
        "source_proof_clock_target": _int(
            rv.get("proof_clock_target")
        ),
        "primary_attribution": primary,
        "secondary_attribution": secondary,
        "attribution_detail": detail,
        **confirmations,
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(
        _review_payload(base)
    )

    return {
        "recalibration_review_id": (
            "ORR-"
            + pd.Timestamp(now).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }
