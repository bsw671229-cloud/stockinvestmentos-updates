from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    recalibration_proposal_snapshot_integrity,
)
from engine.operations_flow_shadow_validation_plan import (
    FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
    SHADOW_VALIDATION_PLAN_STATES,
    PLAN_GUARD_BY_STATE,
    build_flow_shadow_validation_plan,
    shadow_validation_plan_snapshot_integrity,
    latest_shadow_validation_plan_snapshot,
)


SHADOW_VALIDATION_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

SHADOW_VALIDATION_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V138_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))
        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v138_shadow_validation_context(
    *,
    v137_context: dict | None,
    shadow_validation_plan_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v137_context or {}
    proposal = upstream.get("proposal") or {}

    plan_df = _ensure_cols(
        shadow_validation_plan_snapshots,
        FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
    )

    plan = build_flow_shadow_validation_plan(
        proposal,
        plan_df,
        default_min_future_outcomes=3,
        default_min_future_closed_intervals=2,
        default_min_relative_error_improvement_pct=0.15,
        default_max_relative_error_degradation_pct=0.10,
    )

    latest_plan = latest_shadow_validation_plan_snapshot(
        plan_df
    )

    latest_integrity = (
        _text(
            shadow_validation_plan_snapshot_integrity(
                latest_plan
            ).get("status")
        ).upper()
        if latest_plan
        else "NONE"
    )

    return {
        "v137_context": upstream,
        "proposal": proposal,
        "recalibration_proposal_snapshots": _ensure_cols(
            upstream.get("recalibration_proposal_snapshots"),
            FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
        ),
        "shadow_validation_plan_snapshots": plan_df,
        "plan": plan,
        "plan_integrity": _integrity_counts(
            plan_df,
            shadow_validation_plan_snapshot_integrity,
        ),
        "latest_plan": latest_plan,
        "latest_plan_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _current_source_proposal(
    proposal: dict,
) -> dict:
    state = _text(
        proposal.get("proposal_state")
    ).upper()
    source = proposal.get("latest_proposal") or {}

    if (
        state == "RECALIBRATION_PROPOSAL_LOCKED"
        and source
        and _text(
            recalibration_proposal_snapshot_integrity(
                source
            ).get("status")
        ).upper()
        == "OK"
    ):
        return source

    return {}


def _plan_source_mapping_ok(
    plan: dict,
    proposal: dict,
) -> bool:
    state = _text(
        plan.get("plan_state")
    ).upper()

    if state in {
        "SHADOW_VALIDATION_UPSTREAM_WAIT",
        "SHADOW_VALIDATION_NOT_REQUIRED",
        "SHADOW_VALIDATION_PROPOSAL_REQUIRED",
    }:
        return (
            not _text(
                plan.get("source_proposal_id")
            )
            and not _text(
                plan.get("source_proposal_hash")
            )
        )

    source = _current_source_proposal(
        proposal
    )

    if state in {
        "SHADOW_VALIDATION_PLAN_REQUIRED",
        "SHADOW_VALIDATION_PLAN_LOCKED",
    }:
        return (
            bool(source)
            and _text(
                plan.get("source_proposal_id")
            )
            == _text(
                source.get("recalibration_proposal_id")
            )
            and _text(
                plan.get("source_proposal_hash")
            )
            == _text(
                source.get("snapshot_hash")
            )
        )

    if state == "SHADOW_VALIDATION_PLAN_SUPERSEDED":
        latest = plan.get("latest_plan") or {}
        return (
            bool(source)
            and bool(latest)
            and _text(
                latest.get("source_proposal_id")
            )
            != _text(
                source.get("recalibration_proposal_id")
            )
        )

    if state == "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW":
        return True

    return False


def _locked_plan_contract_ok(
    plan: dict,
) -> bool:
    if _text(
        plan.get("plan_state")
    ).upper() != "SHADOW_VALIDATION_PLAN_LOCKED":
        return True

    row = plan.get("latest_plan") or {}

    if _text(
        shadow_validation_plan_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    confirmations = [
        "preregistration_confirmed",
        "shadow_only_confirmed",
        "no_live_apply_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(row.get(field))
        for field in confirmations
    ):
        return False

    if _text(
        row.get("evaluation_metric")
    ).upper() != "BASE_ABS_ERROR_REDUCTION":
        return False

    if _int(
        row.get("min_future_outcomes")
    ) < 3:
        return False

    if _int(
        row.get("min_future_closed_intervals")
    ) < 2:
        return False

    improvement = _float(
        row.get("min_relative_error_improvement_pct")
    )
    degradation = _float(
        row.get("max_relative_error_degradation_pct")
    )

    if not (0.0 <= improvement <= 0.50):
        return False

    if not (0.0 <= degradation <= 0.25):
        return False

    if not _bool(
        row.get("require_same_capacity")
    ):
        return False

    if not _bool(
        row.get("require_no_assumption_drift")
    ):
        return False

    if len(
        _text(row.get("plan_detail"))
    ) < 30:
        return False

    for field in [
        "plan_authorization",
        "recalibration_authorization",
        "capacity_authorization",
        "execution_authorization",
    ]:
        if _text(
            row.get(field)
        ).upper() not in {"", "NONE"}:
            return False

    return True


def _time_order_ok(
    plan: dict,
) -> bool:
    if _text(
        plan.get("plan_state")
    ).upper() != "SHADOW_VALIDATION_PLAN_LOCKED":
        return True

    row = plan.get("latest_plan") or {}

    proposal_ts = pd.to_datetime(
        row.get("source_proposal_created_at"),
        errors="coerce",
        utc=True,
    )
    plan_ts = pd.to_datetime(
        row.get("created_at"),
        errors="coerce",
        utc=True,
    )

    if pd.isna(proposal_ts) or pd.isna(plan_ts):
        return False

    return plan_ts >= proposal_ts


def build_v138_shadow_validation_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    plan = ctx.get("plan") or {}
    proposal = ctx.get("proposal") or {}
    counts = ctx.get("plan_integrity") or {}

    state = _text(
        plan.get("plan_state")
    ).upper()
    guard = _text(
        plan.get("plan_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Shadow Validation Plan Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Shadow Validation Plan immutable hash 확인",
        )
    )

    expected_guard = PLAN_GUARD_BY_STATE.get(
        state,
        "",
    )
    vocabulary_ok = (
        state in SHADOW_VALIDATION_PLAN_STATES
        and bool(expected_guard)
        and guard == expected_guard
    )

    checks.append(
        _technical_row(
            "Shadow Validation State / Guard Vocabulary",
            vocabulary_ok,
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {expected_guard or 'UNKNOWN'}"
            ),
            "Validation Plan state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Validation Plan → Proposal Source Mapping",
            _plan_source_mapping_ok(
                plan,
                proposal,
            ),
            (
                f"state {state or 'MISSING'} · "
                f"plan proposal {_text(plan.get('source_proposal_id')) or 'NONE'} · "
                f"current proposal "
                f"{_text((_current_source_proposal(proposal)).get('recalibration_proposal_id')) or 'NONE'}"
            ),
            "Validation Plan source Proposal id/hash/supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Validation Preregistration Contract Invariant",
            _locked_plan_contract_ok(
                plan
            ),
            (
                f"state {state or 'MISSING'} · "
                f"metric {_text(plan.get('evaluation_metric')) or 'NONE'} · "
                f"future outcomes {_int(plan.get('min_future_outcomes'))} · "
                f"future intervals {_int(plan.get('min_future_closed_intervals'))}"
            ),
            "LOCKED Plan의 criteria/confirmations/no-apply 조건 확인",
        )
    )

    checks.append(
        _technical_row(
            "Proposal → Validation Plan Time-Order Invariant",
            _time_order_ok(
                plan
            ),
            (
                f"state {state or 'MISSING'} · "
                f"proposal created {_text((plan.get('latest_plan') or {}).get('source_proposal_created_at')) or 'NONE'} · "
                f"plan created {_text((plan.get('latest_plan') or {}).get('created_at')) or 'NONE'}"
            ),
            "Validation criteria가 Proposal 이후, future validation 이전에 사전등록됐는지 확인",
        )
    )

    supersession_ok = True
    if state == "SHADOW_VALIDATION_PLAN_SUPERSEDED":
        latest = plan.get("latest_plan") or {}
        source = _current_source_proposal(
            proposal
        )
        supersession_ok = (
            bool(latest)
            and bool(source)
            and _text(
                shadow_validation_plan_snapshot_integrity(
                    latest
                ).get("status")
            ).upper()
            == "OK"
            and (
                _text(
                    latest.get("source_proposal_id")
                )
                != _text(
                    source.get("recalibration_proposal_id")
                )
                or _text(
                    latest.get("source_proposal_hash")
                )
                != _text(
                    source.get("snapshot_hash")
                )
            )
        )

    checks.append(
        _technical_row(
            "Shadow Validation Plan Supersession Invariant",
            supersession_ok,
            (
                f"state {state or 'MISSING'} · "
                f"latest plan "
                f"{_text((plan.get('latest_plan') or {}).get('shadow_validation_plan_id')) or 'NONE'}"
            ),
            "새 LOCKED Proposal에서 기존 Validation Plan 재사용 차단 확인",
        )
    )

    # Current source proposal must remain immutable if a source is required.
    source = _current_source_proposal(
        proposal
    )

    if state in {
        "SHADOW_VALIDATION_PLAN_REQUIRED",
        "SHADOW_VALIDATION_PLAN_LOCKED",
        "SHADOW_VALIDATION_PLAN_SUPERSEDED",
    }:
        source_integrity_ok = (
            bool(source)
            and _text(
                recalibration_proposal_snapshot_integrity(
                    source
                ).get("status")
            ).upper()
            == "OK"
        )
    else:
        source_integrity_ok = True

    checks.append(
        _technical_row(
            "Shadow Validation Source Proposal Integrity Invariant",
            source_integrity_ok,
            (
                f"state {state or 'MISSING'} · "
                f"proposal integrity "
                f"{_text(plan.get('source_proposal_integrity')) or 'NOT_REQUIRED'}"
            ),
            "source Proposal immutable hash 확인",
        )
    )

    auth_violations = 0

    for item in [
        plan,
        plan.get("latest_plan") or {},
        proposal,
    ]:
        for field in [
            "plan_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                auth_violations += 1

    history = ctx.get(
        "shadow_validation_plan_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "plan_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            auth_violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        ctx.get("execution_authorization")
    ).upper() != "NONE":
        auth_violations += 1

    checks.append(
        _technical_row(
            "Shadow Validation No-Apply Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            "Plan/Proposal/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "SHADOW_VALIDATION_NOT_REQUIRED",
            "SHADOW_VALIDATION_PLAN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Shadow Validation Preregistration Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"scope {_text(plan.get('proposal_scope')) or 'NONE'} · "
                f"future outcomes {_int(plan.get('min_future_outcomes'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream/proposal/preregistration wait는 Technical FAIL로 승격하지 않고 "
                    "Proof/Contract/Proposal evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "plan_state": state,
        "proposal_scope": _text(
            plan.get("proposal_scope")
        ).upper(),
        "latest_shadow_validation_plan_integrity":
            _text(
                ctx.get(
                    "latest_plan_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=SHADOW_VALIDATION_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v138_shadow_validation_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    plan_df = _ensure_cols(
        ctx.get(
            "shadow_validation_plan_snapshots"
        ),
        FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
    )
    proposal_df = _ensure_cols(
        ctx.get(
            "recalibration_proposal_snapshots"
        ),
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        plan_df,
        shadow_validation_plan_snapshot_integrity,
    )

    proposal_index, proposal_duplicates = _index_by_id(
        proposal_df,
        "recalibration_proposal_id",
    )

    contract_violations = 0
    proposal_lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    auth_violations = 0

    seen_ids = set()

    for _, row in plan_df.iterrows():
        item = row.to_dict()

        plan_id = _text(
            item.get("shadow_validation_plan_id")
        )

        if plan_id:
            if plan_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(plan_id)

        if (
            _text(
                item.get("plan_state")
            ).upper()
            != "SHADOW_VALIDATION_PLAN_LOCKED"
            or _text(
                item.get("plan_guard")
            ).upper()
            != "PLAN_LOCKED_SHADOW_ONLY"
            or _text(
                item.get("evaluation_metric")
            ).upper()
            != "BASE_ABS_ERROR_REDUCTION"
            or _int(
                item.get("min_future_outcomes")
            ) < 3
            or _int(
                item.get("min_future_closed_intervals")
            ) < 2
            or not (
                0.0
                <= _float(
                    item.get(
                        "min_relative_error_improvement_pct"
                    )
                )
                <= 0.50
            )
            or not (
                0.0
                <= _float(
                    item.get(
                        "max_relative_error_degradation_pct"
                    )
                )
                <= 0.25
            )
            or not _bool(
                item.get("require_same_capacity")
            )
            or not _bool(
                item.get("require_no_assumption_drift")
            )
            or len(
                _text(
                    item.get("plan_detail")
                )
            ) < 30
            or not all(
                _bool(
                    item.get(field)
                )
                for field in [
                    "preregistration_confirmed",
                    "shadow_only_confirmed",
                    "no_live_apply_confirmed",
                    "no_auto_capacity_confirmed",
                    "no_execution_authorization_confirmed",
                    "human_review_confirmed",
                ]
            )
        ):
            contract_violations += 1

        proposal_id = _text(
            item.get("source_proposal_id")
        )
        proposal_hash = _text(
            item.get("source_proposal_hash")
        )
        parent = proposal_index.get(
            proposal_id
        )

        if (
            not parent
            or _text(
                recalibration_proposal_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != proposal_hash
        ):
            proposal_lineage_violations += 1

        proposal_ts = pd.to_datetime(
            item.get("source_proposal_created_at"),
            errors="coerce",
            utc=True,
        )
        plan_ts = pd.to_datetime(
            item.get("created_at"),
            errors="coerce",
            utc=True,
        )

        if (
            pd.isna(proposal_ts)
            or pd.isna(plan_ts)
            or plan_ts < proposal_ts
        ):
            time_order_violations += 1

        for field in [
            "plan_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                auth_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Shadow Validation Plan Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Validation Plan immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Validation Plan Audit Contract Invariant",
            contract_violations == 0,
            f"violations {contract_violations}",
            "LOCKED Plan criteria/confirmations/no-apply 조건 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Validation Plan Audit → Proposal Lineage",
            (
                proposal_lineage_violations == 0
                and proposal_duplicates == 0
            ),
            (
                f"violations {proposal_lineage_violations} · "
                f"proposal duplicate ids {proposal_duplicates}"
            ),
            "Plan source Proposal id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Validation Plan Audit Identity / Time-Order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate plan ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Plan identity uniqueness와 Proposal→Plan 사전등록 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Validation Plan Audit Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            "Plan/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("plan") or {}).get(
            "plan_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "SHADOW_VALIDATION_NOT_REQUIRED",
            "SHADOW_VALIDATION_PLAN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Shadow Validation Plan Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current plan {current_state or 'MISSING'} · "
                f"saved plans {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 LOCKED Proposal이 생기고 미래 validation criteria 사전등록이 필요할 때만 "
                    "Plan audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=SHADOW_VALIDATION_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v138_release_readiness(
    *,
    v137_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    shadow_validation_release_gate: str,
    shadow_validation_audit_gate: str,
    shadow_validation_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(
        v137_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    plan_gate = _text(
        shadow_validation_release_gate
    ).upper()
    audit_gate = _text(
        shadow_validation_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.37 Recalibration Proposal Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Shadow Validation Plan Technical Release Gate",
            plan_gate == "PASS",
            plan_gate or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Plan Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(
            shadow_validation_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "SHADOW_VALIDATION_PLAN_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V138_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v138_integration_crosscheck(
    *,
    integration_consistency: str,
    shadow_validation_release_gate: str,
    shadow_validation_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    plan_gate = _text(
        shadow_validation_release_gate
    ).upper()
    audit_gate = _text(
        shadow_validation_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Plan Technical Gate",
            plan_gate == "PASS",
            plan_gate or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Plan Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V138_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v138_data_crosscheck(
    *,
    csv_fail_count: int,
    shadow_validation_release_gate: str,
    shadow_validation_audit_gate: str,
    latest_plan_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    plan_gate = _text(
        shadow_validation_release_gate
    ).upper()
    audit_gate = _text(
        shadow_validation_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_plan_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Shadow Validation Plan Technical Gate",
            plan_gate == "PASS",
            plan_gate or "MISSING",
        ),
        _candidate_row(
            "Shadow Validation Plan Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Shadow Validation Plan Integrity",
            latest_integrity in {"OK", "NONE"},
            latest_integrity or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V138_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
