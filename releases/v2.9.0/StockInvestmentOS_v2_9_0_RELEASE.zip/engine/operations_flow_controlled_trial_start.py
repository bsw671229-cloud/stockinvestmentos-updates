from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_controlled_trial_design import (
    controlled_trial_design_snapshot_integrity,
)


FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS = [
    "controlled_trial_start_id",
    "created_at",
    "start_state",
    "start_guard",
    "source_trial_design_id",
    "source_trial_design_hash",
    "source_trial_design_created_at",
    "source_trial_design_integrity",
    "source_adoption_review_id",
    "source_adoption_review_hash",
    "source_validation_outcome_id",
    "source_validation_outcome_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "trial_mode",
    "design_max_scope_pct",
    "design_session_cap",
    "design_min_trial_outcomes",
    "design_max_relative_error_degradation_pct",
    "permit_scope_pct",
    "permit_session_budget",
    "permit_min_trial_outcomes",
    "permit_max_relative_error_degradation_pct",
    "start_decision",
    "start_detail",
    "design_source_reviewed",
    "isolation_rechecked",
    "kill_switch_ready_confirmed",
    "rollback_ready_confirmed",
    "manual_start_confirmed",
    "no_live_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "shadow_trial_permission",
    "trial_start_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


CONTROLLED_TRIAL_START_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


CONTROLLED_TRIAL_START_STATES = {
    "TRIAL_START_UPSTREAM_WAIT",
    "TRIAL_START_NOT_REQUIRED",
    "TRIAL_START_DESIGN_SOURCE_REQUIRED",
    "TRIAL_START_SOURCE_INTEGRITY_REVIEW",
    "TRIAL_START_REVIEW_REQUIRED",
    "TRIAL_START_SOURCE_SUPERSEDED",
    "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
    "TRIAL_START_REJECTED",
    "TRIAL_START_DEFERRED",
}


TRIAL_START_GUARD_BY_STATE = {
    "TRIAL_START_UPSTREAM_WAIT": "HOLD_TRIAL_DESIGN",
    "TRIAL_START_NOT_REQUIRED": "NO_TRIAL_START",
    "TRIAL_START_DESIGN_SOURCE_REQUIRED": "HOLD_TRIAL_DESIGN_SOURCE",
    "TRIAL_START_SOURCE_INTEGRITY_REVIEW": "HOLD_TRIAL_START_INTEGRITY",
    "TRIAL_START_REVIEW_REQUIRED": "HUMAN_TRIAL_START_REVIEW_REQUIRED",
    "TRIAL_START_SOURCE_SUPERSEDED": "HOLD_TRIAL_START_SOURCE",
    "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY": "SHADOW_TRIAL_PERMIT_ISSUED_NO_EXECUTION",
    "TRIAL_START_REJECTED": "TRIAL_START_REJECTED_NO_EXECUTION",
    "TRIAL_START_DEFERRED": "TRIAL_START_DEFERRED_NO_EXECUTION",
}


TRIAL_START_DECISIONS = {
    "ISSUE_SHADOW_TRIAL_PERMIT",
    "REJECT",
    "DEFER",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _start_payload(row: dict) -> dict:
    int_fields = {
        "design_session_cap",
        "design_min_trial_outcomes",
        "permit_session_budget",
        "permit_min_trial_outcomes",
    }

    float_fields = {
        "design_max_scope_pct",
        "design_max_relative_error_degradation_pct",
        "permit_scope_pct",
        "permit_max_relative_error_degradation_pct",
    }

    bool_fields = {
        "design_source_reviewed",
        "isolation_rechecked",
        "kill_switch_ready_confirmed",
        "rollback_ready_confirmed",
        "manual_start_confirmed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS:
        if col in {
            "controlled_trial_start_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def controlled_trial_start_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get(
            "snapshot_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _start_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_controlled_trial_start_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _locked_design_source(
    design: dict | None,
) -> dict:
    row = design or {}

    if _text(
        row.get(
            "design_state"
        )
    ).upper() != "TRIAL_DESIGN_LOCKED":
        return {}

    latest = row.get(
        "latest_design"
    ) or {}

    if not latest:
        return {}

    if _text(
        controlled_trial_design_snapshot_integrity(
            latest
        ).get(
            "status"
        )
    ).upper() != "OK":
        return {}

    return latest


def _start_matches_design(
    start: dict | None,
    design_source: dict | None,
) -> bool:
    row = start or {}
    source = design_source or {}

    if not row or not source:
        return False

    if _text(
        controlled_trial_start_snapshot_integrity(
            row
        ).get(
            "status"
        )
    ).upper() != "OK":
        return False

    return (
        _text(
            row.get(
                "source_trial_design_id"
            )
        )
        == _text(
            source.get(
                "controlled_trial_design_id"
            )
        )
        and _text(
            row.get(
                "source_trial_design_hash"
            )
        )
        == _text(
            source.get(
                "snapshot_hash"
            )
        )
    )


def _locked_state_from_decision(
    decision: str,
) -> str:
    value = _text(
        decision
    ).upper()

    if value == "ISSUE_SHADOW_TRIAL_PERMIT":
        return "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY"

    if value == "REJECT":
        return "TRIAL_START_REJECTED"

    if value == "DEFER":
        return "TRIAL_START_DEFERRED"

    return "TRIAL_START_SOURCE_INTEGRITY_REVIEW"


def build_flow_controlled_trial_start(
    controlled_trial_design: dict | None,
    start_snapshots: pd.DataFrame | None,
) -> dict:
    design = controlled_trial_design or {}
    design_state = _text(
        design.get(
            "design_state"
        )
    ).upper()

    base = {
        "source_trial_design_id": "",
        "source_trial_design_hash": "",
        "source_trial_design_created_at": "",
        "source_trial_design_integrity": "NONE",
        "source_adoption_review_id": _text(
            design.get(
                "source_adoption_review_id"
            )
        ),
        "source_adoption_review_hash": _text(
            design.get(
                "source_adoption_review_hash"
            )
        ),
        "source_validation_outcome_id": _text(
            design.get(
                "source_validation_outcome_id"
            )
        ),
        "source_validation_outcome_hash": _text(
            design.get(
                "source_validation_outcome_hash"
            )
        ),
        "source_proposal_id": _text(
            design.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            design.get(
                "source_proposal_hash"
            )
        ),
        "proposal_scope": _text(
            design.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            design.get(
                "target_metric"
            )
        ).upper(),
        "trial_mode": _text(
            design.get(
                "trial_mode"
            )
        ).upper() or "SHADOW_CANARY_ONLY",
        "design_max_scope_pct": _float(
            design.get(
                "max_trial_scope_pct"
            )
        ),
        "design_session_cap": _int(
            design.get(
                "max_trial_sessions"
            )
        ),
        "design_min_trial_outcomes": _int(
            design.get(
                "min_trial_outcomes"
            )
        ),
        "design_max_relative_error_degradation_pct": _float(
            design.get(
                "max_relative_error_degradation_pct"
            )
        ),
        "permit_scope_pct": 0.0,
        "permit_session_budget": 0,
        "permit_min_trial_outcomes": 0,
        "permit_max_relative_error_degradation_pct": 0.0,
        "start_decision": "",
        "start_detail": "",
        "latest_start": {},
        "shadow_trial_permission": "NONE",
        "trial_start_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if design_state in {
        "",
        "TRIAL_DESIGN_UPSTREAM_WAIT",
        "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED",
        "TRIAL_DESIGN_REQUIRED",
        "TRIAL_DESIGN_SUPERSEDED",
        "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW",
    }:
        return {
            **base,
            "start_state": "TRIAL_START_UPSTREAM_WAIT",
            "start_guard": "HOLD_TRIAL_DESIGN",
        }

    if design_state == "TRIAL_DESIGN_NOT_REQUIRED":
        return {
            **base,
            "start_state": "TRIAL_START_NOT_REQUIRED",
            "start_guard": "NO_TRIAL_START",
        }

    if design_state != "TRIAL_DESIGN_LOCKED":
        return {
            **base,
            "start_state": "TRIAL_START_UPSTREAM_WAIT",
            "start_guard": "HOLD_TRIAL_DESIGN",
        }

    source = _locked_design_source(
        design
    )

    if not source:
        return {
            **base,
            "start_state": "TRIAL_START_DESIGN_SOURCE_REQUIRED",
            "start_guard": "HOLD_TRIAL_DESIGN_SOURCE",
        }

    source_integrity = _text(
        controlled_trial_design_snapshot_integrity(
            source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_trial_design_id":
                _text(
                    source.get(
                        "controlled_trial_design_id"
                    )
                ),
            "source_trial_design_hash":
                _text(
                    source.get(
                        "snapshot_hash"
                    )
                ),
            "source_trial_design_created_at":
                _text(
                    source.get(
                        "created_at"
                    )
                ),
            "source_trial_design_integrity":
                source_integrity,
            "source_adoption_review_id":
                _text(
                    source.get(
                        "source_adoption_review_id"
                    )
                ),
            "source_adoption_review_hash":
                _text(
                    source.get(
                        "source_adoption_review_hash"
                    )
                ),
            "source_validation_outcome_id":
                _text(
                    source.get(
                        "source_validation_outcome_id"
                    )
                ),
            "source_validation_outcome_hash":
                _text(
                    source.get(
                        "source_validation_outcome_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    source.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    source.get(
                        "source_proposal_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    source.get(
                        "target_metric"
                    )
                ).upper(),
            "trial_mode":
                _text(
                    source.get(
                        "trial_mode"
                    )
                ).upper(),
            "design_max_scope_pct":
                _float(
                    source.get(
                        "max_trial_scope_pct"
                    )
                ),
            "design_session_cap":
                _int(
                    source.get(
                        "max_trial_sessions"
                    )
                ),
            "design_min_trial_outcomes":
                _int(
                    source.get(
                        "min_trial_outcomes"
                    )
                ),
            "design_max_relative_error_degradation_pct":
                _float(
                    source.get(
                        "max_relative_error_degradation_pct"
                    )
                ),
        }
    )

    if source_integrity != "OK":
        return {
            **base,
            "start_state": "TRIAL_START_SOURCE_INTEGRITY_REVIEW",
            "start_guard": "HOLD_TRIAL_START_INTEGRITY",
        }

    history = (
        pd.DataFrame()
        if start_snapshots is None
        else start_snapshots.copy()
    )

    latest = latest_controlled_trial_start_snapshot(
        history
    )

    if not latest:
        return {
            **base,
            "start_state": "TRIAL_START_REVIEW_REQUIRED",
            "start_guard": "HUMAN_TRIAL_START_REVIEW_REQUIRED",
        }

    base[
        "latest_start"
    ] = latest

    latest_integrity = _text(
        controlled_trial_start_snapshot_integrity(
            latest
        ).get(
            "status"
        )
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "start_state": "TRIAL_START_SOURCE_INTEGRITY_REVIEW",
            "start_guard": "HOLD_TRIAL_START_INTEGRITY",
        }

    if not _start_matches_design(
        latest,
        source,
    ):
        return {
            **base,
            "start_state": "TRIAL_START_SOURCE_SUPERSEDED",
            "start_guard": "HOLD_TRIAL_START_SOURCE",
        }

    state = _locked_state_from_decision(
        latest.get(
            "start_decision"
        )
    )

    return {
        **base,
        "start_state":
            state,
        "start_guard":
            TRIAL_START_GUARD_BY_STATE.get(
                state,
                "HOLD_TRIAL_START_INTEGRITY",
            ),
        "permit_scope_pct":
            _float(
                latest.get(
                    "permit_scope_pct"
                )
            ),
        "permit_session_budget":
            _int(
                latest.get(
                    "permit_session_budget"
                )
            ),
        "permit_min_trial_outcomes":
            _int(
                latest.get(
                    "permit_min_trial_outcomes"
                )
            ),
        "permit_max_relative_error_degradation_pct":
            _float(
                latest.get(
                    "permit_max_relative_error_degradation_pct"
                )
            ),
        "start_decision":
            _text(
                latest.get(
                    "start_decision"
                )
            ).upper(),
        "start_detail":
            _text(
                latest.get(
                    "start_detail"
                )
            ),
        "shadow_trial_permission":
            _text(
                latest.get(
                    "shadow_trial_permission"
                )
            ).upper()
            or "NONE",
    }


def build_flow_controlled_trial_start_lock(
    start: dict,
    *,
    start_decision: str,
    start_detail: str,
    permit_scope_pct: float,
    permit_session_budget: int,
    design_source_reviewed: bool,
    isolation_rechecked: bool,
    kill_switch_ready_confirmed: bool,
    rollback_ready_confirmed: bool,
    manual_start_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = start or {}

    if _text(
        current.get(
            "start_state"
        )
    ).upper() != "TRIAL_START_REVIEW_REQUIRED":
        raise ValueError(
            "Controlled Trial Start Review는 TRIAL_START_REVIEW_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_trial_design_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Controlled Trial Design integrity가 OK가 아닙니다."
        )

    decision = _text(
        start_decision
    ).upper()

    if decision not in TRIAL_START_DECISIONS:
        raise ValueError(
            "Trial Start decision은 ISSUE_SHADOW_TRIAL_PERMIT / REJECT / DEFER 중 하나여야 합니다."
        )

    detail = _text(
        start_detail
    )

    if len(
        detail
    ) < 40:
        raise ValueError(
            "Trial Start rationale을 40자 이상 기록하세요."
        )

    design_scope = _float(
        current.get(
            "design_max_scope_pct"
        )
    )
    design_sessions = _int(
        current.get(
            "design_session_cap"
        )
    )
    design_outcomes = _int(
        current.get(
            "design_min_trial_outcomes"
        )
    )
    design_degradation = _float(
        current.get(
            "design_max_relative_error_degradation_pct"
        )
    )

    scope = float(
        permit_scope_pct
    )
    sessions = int(
        permit_session_budget
    )

    confirmations = {
        "design_source_reviewed":
            bool(
                design_source_reviewed
            ),
        "isolation_rechecked":
            bool(
                isolation_rechecked
            ),
        "kill_switch_ready_confirmed":
            bool(
                kill_switch_ready_confirmed
            ),
        "rollback_ready_confirmed":
            bool(
                rollback_ready_confirmed
            ),
        "manual_start_confirmed":
            bool(
                manual_start_confirmed
            ),
        "no_live_apply_confirmed":
            bool(
                no_live_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    required_common = [
        "design_source_reviewed",
        "isolation_rechecked",
        "kill_switch_ready_confirmed",
        "rollback_ready_confirmed",
        "manual_start_confirmed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        confirmations[
            field
        ]
        for field in required_common
    ):
        raise ValueError(
            "Controlled Trial Start Human Review 확인사항을 모두 검토해야 합니다."
        )

    if decision == "ISSUE_SHADOW_TRIAL_PERMIT":
        if not (
            0.01
            <= scope
            <= min(
                0.10,
                design_scope,
            )
        ):
            raise ValueError(
                "Shadow Trial permit scope는 1% 이상이며 Design scope cap 이하여야 합니다."
            )

        if not (
            1
            <= sessions
            <= design_sessions
        ):
            raise ValueError(
                "Shadow Trial permit session budget은 1 이상이며 Design session cap 이하여야 합니다."
            )
    else:
        scope = 0.0
        sessions = 0

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    source_created = pd.to_datetime(
        current.get(
            "source_trial_design_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    start_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            source_created
        )
        or pd.isna(
            start_created
        )
        or start_created <= source_created
    ):
        raise ValueError(
            "Trial Start Review는 source Trial Design 이후에 저장되어야 합니다."
        )

    state = _locked_state_from_decision(
        decision
    )

    permission = (
        "SHADOW_CANARY_ONLY"
        if decision == "ISSUE_SHADOW_TRIAL_PERMIT"
        else "NONE"
    )

    base = {
        "start_state":
            state,
        "start_guard":
            TRIAL_START_GUARD_BY_STATE[
                state
            ],
        "source_trial_design_id":
            _text(
                current.get(
                    "source_trial_design_id"
                )
            ),
        "source_trial_design_hash":
            _text(
                current.get(
                    "source_trial_design_hash"
                )
            ),
        "source_trial_design_created_at":
            _text(
                current.get(
                    "source_trial_design_created_at"
                )
            ),
        "source_trial_design_integrity":
            "OK",
        "source_adoption_review_id":
            _text(
                current.get(
                    "source_adoption_review_id"
                )
            ),
        "source_adoption_review_hash":
            _text(
                current.get(
                    "source_adoption_review_hash"
                )
            ),
        "source_validation_outcome_id":
            _text(
                current.get(
                    "source_validation_outcome_id"
                )
            ),
        "source_validation_outcome_hash":
            _text(
                current.get(
                    "source_validation_outcome_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "trial_mode":
            "SHADOW_CANARY_ONLY",
        "design_max_scope_pct":
            design_scope,
        "design_session_cap":
            design_sessions,
        "design_min_trial_outcomes":
            design_outcomes,
        "design_max_relative_error_degradation_pct":
            design_degradation,
        "permit_scope_pct":
            scope,
        "permit_session_budget":
            sessions,
        "permit_min_trial_outcomes":
            design_outcomes,
        "permit_max_relative_error_degradation_pct":
            design_degradation,
        "start_decision":
            decision,
        "start_detail":
            detail,
        **confirmations,
        "shadow_trial_permission":
            permission,
        "trial_start_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _start_payload(
            base
        )
    )

    return {
        "controlled_trial_start_id": (
            "OTS-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_controlled_trial_start_queue(
    start: dict | None,
) -> pd.DataFrame:
    row = start or {}
    state = _text(
        row.get(
            "start_state"
        )
    ).upper()

    mapping = {
        "TRIAL_START_UPSTREAM_WAIT": (
            "TS2",
            "WAIT",
            "TRIAL_START_UPSTREAM_WAIT",
            "LOCKED Controlled Trial Design이 아직 없음",
            "Human Adoption / Trial Design evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "TRIAL_START_NOT_REQUIRED": (
            "TS3",
            "MONITOR",
            "TRIAL_START_NOT_REQUIRED",
            "현재 Trial Design source에서는 Trial Start가 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "TRIAL_START_DESIGN_SOURCE_REQUIRED": (
            "TS1",
            "REVIEW",
            "TRIAL_START_DESIGN_SOURCE_REQUIRED",
            "TRIAL_DESIGN_LOCKED 상태지만 immutable Design source 없음",
            "Controlled Trial Design audit을 먼저 확인",
        ),
        "TRIAL_START_SOURCE_INTEGRITY_REVIEW": (
            "TS0",
            "BLOCKED",
            "TRIAL_START_SOURCE_INTEGRITY_REVIEW",
            "Trial Design 또는 Trial Start immutable hash mismatch",
            "source Design / Start audit integrity를 먼저 복구",
        ),
        "TRIAL_START_REVIEW_REQUIRED": (
            "TS1",
            "REVIEW",
            "TRIAL_START_REVIEW_REQUIRED",
            (
                f"design scope <= {float(row.get('design_max_scope_pct',0)):.1%} · "
                f"sessions <= {row.get('design_session_cap',0)}"
            ),
            "Kill switch / rollback readiness를 확인하고 ISSUE/REJECT/DEFER Human decision",
        ),
        "TRIAL_START_SOURCE_SUPERSEDED": (
            "TS0",
            "REVIEW",
            "TRIAL_START_SOURCE_SUPERSEDED",
            "새 Controlled Trial Design으로 기존 Start decision이 stale",
            "현재 Design 기준으로 Start Review 재수행",
        ),
        "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY": (
            "TS3",
            "MONITOR",
            "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
            (
                f"shadow scope {float(row.get('permit_scope_pct',0)):.1%} · "
                f"session budget {row.get('permit_session_budget',0)}"
            ),
            "Future Trial Runtime이 이 permit을 소비할 때도 live apply/Execution 권한 없음",
        ),
        "TRIAL_START_REJECTED": (
            "TS3",
            "MONITOR",
            "TRIAL_START_REJECTED",
            "Human Trial Start decision = REJECT",
            "Trial 시작 없음; 새 Design/evidence cycle까지 대기",
        ),
        "TRIAL_START_DEFERRED": (
            "TS2",
            "MONITOR",
            "TRIAL_START_DEFERRED",
            "Human Trial Start decision = DEFER",
            "새 evidence/운영 조건 확인 후 재검토",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "TS0",
            "BLOCKED",
            "TRIAL_START_UNKNOWN_STATE",
            state or "MISSING",
            "Trial Start state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            CONTROLLED_TRIAL_START_QUEUE_COLS,
    )
