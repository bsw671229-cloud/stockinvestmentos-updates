from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_trend import (
    FLOW_TREND_SNAPSHOT_COLS,
    flow_trend_snapshot_integrity,
)
from engine.operations_session import (
    OPERATIONS_SESSION_COLS,
    operations_session_integrity,
    current_open_session,
)


FLOW_EVIDENCE_SNAPSHOT_COLS = [
    "evidence_snapshot_id",
    "created_at",
    "raw_trend_snapshots",
    "valid_trend_snapshots",
    "invalid_trend_snapshots",
    "session_close_records",
    "valid_session_closes",
    "invalid_session_closes",
    "closed_session_dates",
    "qualified_endpoints",
    "qualified_intervals",
    "same_day_superseded",
    "unqualified_valid_snapshots",
    "closed_dates_without_trend",
    "coverage_ratio",
    "evidence_state",
    "calibration_history_guard",
    "endpoint_ids_json",
    "endpoint_hashes_json",
    "endpoint_dates_json",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


FLOW_EVIDENCE_ENDPOINT_COLS = [
    "session_date",
    "close_event_id",
    "close_created_at",
    "trend_snapshot_id",
    "trend_created_at",
    "current_group_count",
    "attention_group_count",
    "capacity",
    "snapshot_hash",
]


FLOW_EVIDENCE_BOUNDARY_COLS = [
    "session_date",
    "session_id",
    "close_event_id",
    "open_created_at",
    "close_created_at",
    "boundary_status",
    "same_day_trend_count",
    "in_window_trend_count",
    "latest_pre_open_trend_at",
    "first_post_close_trend_at",
    "selected_trend_snapshot_id",
    "selected_trend_created_at",
]


FLOW_EVIDENCE_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _local_date(value: Any) -> str:
    raw = _text(value)
    if not raw:
        return ""
    try:
        return pd.Timestamp(raw).date().isoformat()
    except Exception:
        return ""


def _normalize_trend(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()

    for col in FLOW_TREND_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return {
            "all": df,
            "valid": df.copy(),
            "invalid_count": 0,
        }

    valid_rows = []
    invalid_count = 0

    for _, row in df.iterrows():
        record = row.to_dict()
        if flow_trend_snapshot_integrity(record).get("status") == "OK":
            valid_rows.append(record)
        else:
            invalid_count += 1

    valid = pd.DataFrame(
        valid_rows,
        columns=FLOW_TREND_SNAPSHOT_COLS,
    )

    if not valid.empty:
        valid["_ts"] = pd.to_datetime(
            valid["created_at"],
            errors="coerce",
            utc=True,
        )
        valid["_local_date"] = valid["created_at"].map(_local_date)
        valid = (
            valid.loc[
                valid["_ts"].notna()
                & valid["_local_date"].ne("")
            ]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    return {
        "all": df,
        "valid": valid,
        "invalid_count": invalid_count,
    }


def _normalize_closes(
    sessions: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if sessions is None else sessions.copy()

    for col in OPERATIONS_SESSION_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return {
            "close_records": 0,
            "valid": pd.DataFrame(columns=OPERATIONS_SESSION_COLS),
            "invalid_count": 0,
        }

    close_df = df.loc[
        df["event_type"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("CLOSE")
    ].copy()

    valid_rows = []
    invalid_count = 0

    for _, row in close_df.iterrows():
        record = row.to_dict()
        if operations_session_integrity(record).get("status") == "OK":
            valid_rows.append(record)
        else:
            invalid_count += 1

    valid = pd.DataFrame(
        valid_rows,
        columns=OPERATIONS_SESSION_COLS,
    )

    if not valid.empty:
        valid["_ts"] = pd.to_datetime(
            valid["created_at"],
            errors="coerce",
            utc=True,
        )
        valid["_session_date"] = (
            valid["session_date"]
            .fillna("")
            .astype(str)
            .str.strip()
        )

        fallback = valid["created_at"].map(_local_date)
        valid["_session_date"] = valid["_session_date"].where(
            valid["_session_date"].ne(""),
            fallback,
        )

        valid = (
            valid.loc[
                valid["_ts"].notna()
                & valid["_session_date"].ne("")
            ]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    return {
        "close_records": int(len(close_df)),
        "valid": valid,
        "invalid_count": invalid_count,
    }


def _normalize_opens(
    sessions: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if sessions is None else sessions.copy()

    for col in OPERATIONS_SESSION_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return {
            "open_records": 0,
            "valid": pd.DataFrame(columns=OPERATIONS_SESSION_COLS),
            "invalid_count": 0,
        }

    open_df = df.loc[
        df["event_type"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("OPEN")
    ].copy()

    valid_rows = []
    invalid_count = 0

    for _, row in open_df.iterrows():
        record = row.to_dict()
        if operations_session_integrity(record).get("status") == "OK":
            valid_rows.append(record)
        else:
            invalid_count += 1

    valid = pd.DataFrame(
        valid_rows,
        columns=OPERATIONS_SESSION_COLS,
    )

    if not valid.empty:
        valid["_ts"] = pd.to_datetime(
            valid["created_at"],
            errors="coerce",
            utc=True,
        )
        valid["_session_date"] = (
            valid["session_date"]
            .fillna("")
            .astype(str)
            .str.strip()
        )
        fallback = valid["created_at"].map(_local_date)
        valid["_session_date"] = valid["_session_date"].where(
            valid["_session_date"].ne(""),
            fallback,
        )
        valid = (
            valid.loc[
                valid["_ts"].notna()
                & valid["_session_date"].ne("")
            ]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    return {
        "open_records": int(len(open_df)),
        "valid": valid,
        "invalid_count": invalid_count,
    }


def _find_open_for_close(
    close_row: pd.Series | dict,
    valid_open: pd.DataFrame,
) -> dict:
    if valid_open.empty:
        return {
            "status": "MISSING_OPEN",
            "open": {},
        }

    session_id = _text(close_row.get("session_id"))
    close_ts = close_row.get("_ts")

    if not session_id or pd.isna(close_ts):
        return {
            "status": "INVALID_CLOSE_KEY",
            "open": {},
        }

    hits = valid_open.loc[
        valid_open["session_id"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(session_id)
        & valid_open["_ts"].le(close_ts)
    ].copy()

    if hits.empty:
        return {
            "status": "MISSING_OPEN",
            "open": {},
        }

    open_row = (
        hits.sort_values("_ts")
        .iloc[-1]
        .to_dict()
    )

    parent_hash = _text(close_row.get("parent_open_record_hash"))
    open_hash = _text(open_row.get("record_hash"))

    if not parent_hash or not open_hash or parent_hash != open_hash:
        return {
            "status": "PARENT_HASH_MISMATCH",
            "open": open_row,
        }

    return {
        "status": "OK",
        "open": open_row,
    }


def build_flow_evidence_quality(
    trend_snapshots: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    *,
    min_qualified_endpoints: int = 3,
) -> dict:
    trend_info = _normalize_trend(trend_snapshots)
    close_info = _normalize_closes(sessions)
    open_info = _normalize_opens(sessions)

    trend_all = trend_info["all"]
    valid_trend = trend_info["valid"]
    valid_close = close_info["valid"]
    valid_open = open_info["valid"]

    min_endpoints = max(1, _int(min_qualified_endpoints))

    endpoint_rows = []
    boundary_rows = []
    same_day_superseded = 0
    closed_dates_without_trend = 0
    invalid_session_pairs = 0

    if not valid_close.empty:
        latest_close_by_date = (
            valid_close
            .sort_values("_ts")
            .groupby("_session_date", as_index=False)
            .tail(1)
            .sort_values("_ts")
            .reset_index(drop=True)
        )
    else:
        latest_close_by_date = pd.DataFrame()

    for _, close_row in latest_close_by_date.iterrows():
        session_date = _text(close_row.get("_session_date"))
        close_ts = close_row.get("_ts")
        session_id = _text(close_row.get("session_id"))

        pair = _find_open_for_close(
            close_row,
            valid_open,
        )
        open_row = pair.get("open") or {}
        open_ts = open_row.get("_ts")

        same_day = (
            pd.DataFrame()
            if valid_trend.empty
            else valid_trend.loc[
                valid_trend["_local_date"].eq(session_date)
            ].copy()
        )

        before_open = pd.DataFrame()
        after_close = pd.DataFrame()
        candidates = pd.DataFrame()

        if pair.get("status") == "OK" and not pd.isna(open_ts) and not pd.isna(close_ts):
            if not same_day.empty:
                before_open = same_day.loc[
                    same_day["_ts"].lt(open_ts)
                ].copy()
                after_close = same_day.loc[
                    same_day["_ts"].gt(close_ts)
                ].copy()
                candidates = same_day.loc[
                    same_day["_ts"].ge(open_ts)
                    & same_day["_ts"].le(close_ts)
                ].copy()
        else:
            invalid_session_pairs += 1

        selected_id = ""
        selected_created = ""
        boundary_status = ""
        latest_pre_open = ""
        first_post_close = ""

        if not before_open.empty:
            latest_pre_open = _text(
                before_open.sort_values("_ts").iloc[-1].get("created_at")
            )
        if not after_close.empty:
            first_post_close = _text(
                after_close.sort_values("_ts").iloc[0].get("created_at")
            )

        if pair.get("status") != "OK":
            boundary_status = "SESSION_PAIR_INTEGRITY_REVIEW"
            closed_dates_without_trend += 1
        elif not candidates.empty:
            candidates = candidates.sort_values("_ts")
            latest = candidates.iloc[-1].to_dict()

            same_day_superseded += max(0, int(len(candidates)) - 1)

            selected_id = _text(latest.get("trend_snapshot_id"))
            selected_created = _text(latest.get("created_at"))

            endpoint_rows.append(
                {
                    "session_date": session_date,
                    "close_event_id": _text(close_row.get("event_id")),
                    "close_created_at": _text(close_row.get("created_at")),
                    "trend_snapshot_id": selected_id,
                    "trend_created_at": selected_created,
                    "current_group_count": _int(
                        latest.get("current_group_count")
                    ),
                    "attention_group_count": _int(
                        latest.get("attention_group_count")
                    ),
                    "capacity": _int(latest.get("capacity")),
                    "snapshot_hash": _text(latest.get("snapshot_hash")),
                }
            )
            boundary_status = "QUALIFIED"
        else:
            closed_dates_without_trend += 1
            if not before_open.empty and not after_close.empty:
                boundary_status = "OUTSIDE_SESSION_WINDOW_ONLY"
            elif not after_close.empty:
                boundary_status = "POST_CLOSE_TREND_ONLY"
            elif not before_open.empty:
                boundary_status = "PRE_OPEN_TREND_ONLY"
            else:
                boundary_status = "NO_SAME_DAY_TREND"

        boundary_rows.append(
            {
                "session_date": session_date,
                "session_id": session_id,
                "close_event_id": _text(close_row.get("event_id")),
                "open_created_at": _text(open_row.get("created_at")),
                "close_created_at": _text(close_row.get("created_at")),
                "boundary_status": boundary_status,
                "same_day_trend_count": int(len(same_day)),
                "in_window_trend_count": int(len(candidates)),
                "latest_pre_open_trend_at": latest_pre_open,
                "first_post_close_trend_at": first_post_close,
                "selected_trend_snapshot_id": selected_id,
                "selected_trend_created_at": selected_created,
            }
        )

    all_endpoint_table = pd.DataFrame(
        endpoint_rows,
        columns=FLOW_EVIDENCE_ENDPOINT_COLS,
    )
    boundary_table = pd.DataFrame(
        boundary_rows,
        columns=FLOW_EVIDENCE_BOUNDARY_COLS,
    )

    # ------------------------------------------------------------------
    # v1.30-dev4: Calibration may use only the trailing uninterrupted run
    # of qualified closed sessions. An older qualified endpoint must not
    # "bridge across" a recent closed session that lacks valid evidence.
    # ------------------------------------------------------------------
    recent_boundary_rows = []
    if not boundary_table.empty:
        for _, row in boundary_table.iloc[::-1].iterrows():
            if _text(row.get("boundary_status")).upper() != "QUALIFIED":
                break
            recent_boundary_rows.append(row.to_dict())

    recent_boundary_rows.reverse()
    recent_boundary = pd.DataFrame(
        recent_boundary_rows,
        columns=FLOW_EVIDENCE_BOUNDARY_COLS,
    )

    recent_ids = (
        recent_boundary["selected_trend_snapshot_id"]
        .fillna("")
        .astype(str)
        .str.strip()
        .tolist()
        if not recent_boundary.empty
        else []
    )
    recent_ids = [x for x in recent_ids if x]

    if all_endpoint_table.empty or not recent_ids:
        recent_endpoint_table = pd.DataFrame(
            columns=FLOW_EVIDENCE_ENDPOINT_COLS
        )
    else:
        recent_endpoint_table = (
            all_endpoint_table.loc[
                all_endpoint_table["trend_snapshot_id"]
                .fillna("")
                .astype(str)
                .isin(recent_ids)
            ]
            .copy()
            .reset_index(drop=True)
        )

    # ------------------------------------------------------------------
    # Calibration also stays inside the latest Capacity regime. If the
    # Capacity value changes, prior endpoints remain audit history but do
    # not contribute to the new regime's calibration clock.
    # ------------------------------------------------------------------
    latest_capacity = 0
    active_endpoint_rows = []
    if not recent_endpoint_table.empty:
        latest_capacity = _int(
            recent_endpoint_table.iloc[-1].get("capacity")
        )
        for _, row in recent_endpoint_table.iloc[::-1].iterrows():
            if _int(row.get("capacity")) != latest_capacity:
                break
            active_endpoint_rows.append(row.to_dict())

    active_endpoint_rows.reverse()
    endpoint_table = pd.DataFrame(
        active_endpoint_rows,
        columns=FLOW_EVIDENCE_ENDPOINT_COLS,
    )

    active_ids = set(
        endpoint_table["trend_snapshot_id"]
        .fillna("")
        .astype(str)
        .str.strip()
        .tolist()
        if not endpoint_table.empty
        else []
    )

    if endpoint_table.empty or valid_trend.empty:
        qualified = pd.DataFrame(
            columns=FLOW_TREND_SNAPSHOT_COLS
        )
    else:
        qualified = (
            valid_trend.loc[
                valid_trend["trend_snapshot_id"]
                .fillna("")
                .astype(str)
                .isin(active_ids)
            ]
            .sort_values("_ts")
            [FLOW_TREND_SNAPSHOT_COLS]
            .reset_index(drop=True)
        )

    raw_count = int(len(trend_all))
    valid_count = int(len(valid_trend))
    invalid_trend = _int(trend_info.get("invalid_count"))
    close_records = _int(close_info.get("close_records"))
    valid_closes = int(len(valid_close))
    invalid_closes = _int(close_info.get("invalid_count"))
    invalid_opens = _int(open_info.get("invalid_count"))
    closed_dates = int(
        latest_close_by_date["_session_date"].nunique()
        if not latest_close_by_date.empty
        else 0
    )

    lifetime_qualified = int(len(all_endpoint_table))
    recent_consecutive = int(len(recent_endpoint_table))
    qualified_count = int(len(qualified))
    qualified_intervals = max(0, qualified_count - 1)
    capacity_regime_break_count = max(
        0,
        recent_consecutive - qualified_count,
    )

    unqualified_valid = max(
        0,
        valid_count - lifetime_qualified - same_day_superseded,
    )

    coverage_ratio = (
        float(lifetime_qualified / closed_dates)
        if closed_dates > 0
        else 0.0
    )

    boundary_counts = (
        {}
        if boundary_table.empty
        else (
            boundary_table["boundary_status"]
            .fillna("")
            .astype(str)
            .value_counts()
            .to_dict()
        )
    )

    latest_boundary_status = (
        _text(boundary_table.iloc[-1].get("boundary_status")).upper()
        if not boundary_table.empty
        else "NONE"
    )

    if (
        invalid_trend > 0
        or invalid_closes > 0
        or invalid_session_pairs > 0
    ):
        evidence_state = "INTEGRITY_REVIEW"
        history_guard = "HOLD_INTEGRITY"
        window_state = "INTEGRITY_REVIEW"
    elif latest_boundary_status != "QUALIFIED":
        evidence_state = "CLOSED_SESSION_EVIDENCE_REQUIRED"
        history_guard = "HOLD_CLOSED_SESSION"
        window_state = "RECENT_SESSION_GAP"
    elif qualified_count < min_endpoints:
        evidence_state = "EVIDENCE_MATURING"
        history_guard = "HOLD_HISTORY"
        window_state = (
            "CAPACITY_REGIME_MATURING"
            if capacity_regime_break_count > 0
            else "CONSECUTIVE_WINDOW_MATURING"
        )
    else:
        evidence_state = "EVIDENCE_READY"
        history_guard = "ALLOW_QUALIFIED_CALIBRATION"
        window_state = "WINDOW_READY"

    return {
        "raw_trend_snapshots": raw_count,
        "valid_trend_snapshots": valid_count,
        "invalid_trend_snapshots": invalid_trend,
        "session_open_records": _int(open_info.get("open_records")),
        "valid_session_opens": int(len(valid_open)),
        "invalid_session_opens": invalid_opens,
        "session_close_records": close_records,
        "valid_session_closes": valid_closes,
        "invalid_session_closes": invalid_closes,
        "invalid_session_pairs": invalid_session_pairs,
        "closed_session_dates": closed_dates,
        "lifetime_qualified_endpoints": lifetime_qualified,
        "recent_consecutive_endpoints": recent_consecutive,
        "capacity_regime_endpoints": qualified_count,
        "capacity_regime_break_count": capacity_regime_break_count,
        "latest_capacity": latest_capacity,
        "latest_boundary_status": latest_boundary_status,
        "evidence_window_state": window_state,
        "qualified_endpoints": qualified_count,
        "qualified_intervals": qualified_intervals,
        "same_day_superseded": same_day_superseded,
        "unqualified_valid_snapshots": unqualified_valid,
        "closed_dates_without_trend": closed_dates_without_trend,
        "coverage_ratio": coverage_ratio,
        "evidence_state": evidence_state,
        "calibration_history_guard": history_guard,
        "min_qualified_endpoints": min_endpoints,
        "qualified_trend_history": qualified,
        "endpoint_table": endpoint_table,
        "all_qualified_endpoint_table": all_endpoint_table,
        "recent_consecutive_endpoint_table": recent_endpoint_table,
        "boundary_table": boundary_table,
        "boundary_status_counts": boundary_counts,
        "execution_authorization": "NONE",
    }


def build_flow_evidence_capture_readiness(
    trend_snapshots: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
) -> dict:
    trend_info = _normalize_trend(trend_snapshots)
    valid_trend = trend_info["valid"]
    open_session = current_open_session(sessions)

    if not open_session:
        return {
            "capture_state": "NO_OPEN_SESSION",
            "session_id": "",
            "session_date": "",
            "open_created_at": "",
            "eligible_trend_snapshots": 0,
            "same_session_superseded": 0,
            "latest_trend_snapshot_id": "",
            "latest_trend_created_at": "",
            "close_blocking": False,
            "execution_authorization": "NONE",
        }

    if (
        open_session.get("_integrity_issue")
        or operations_session_integrity(open_session).get("status") != "OK"
    ):
        return {
            "capture_state": "OPEN_SESSION_INTEGRITY_REVIEW",
            "session_id": _text(open_session.get("session_id")),
            "session_date": _text(open_session.get("session_date")),
            "open_created_at": _text(open_session.get("created_at")),
            "eligible_trend_snapshots": 0,
            "same_session_superseded": 0,
            "latest_trend_snapshot_id": "",
            "latest_trend_created_at": "",
            "close_blocking": False,
            "execution_authorization": "NONE",
        }

    open_ts = pd.to_datetime(
        open_session.get("created_at"),
        errors="coerce",
        utc=True,
    )
    session_date = (
        _text(open_session.get("session_date"))
        or _local_date(open_session.get("created_at"))
    )

    if pd.isna(open_ts) or not session_date:
        return {
            "capture_state": "OPEN_SESSION_INTEGRITY_REVIEW",
            "session_id": _text(open_session.get("session_id")),
            "session_date": session_date,
            "open_created_at": _text(open_session.get("created_at")),
            "eligible_trend_snapshots": 0,
            "same_session_superseded": 0,
            "latest_trend_snapshot_id": "",
            "latest_trend_created_at": "",
            "close_blocking": False,
            "execution_authorization": "NONE",
        }

    if valid_trend.empty:
        eligible = pd.DataFrame()
    else:
        eligible = valid_trend.loc[
            valid_trend["_local_date"].eq(session_date)
            & valid_trend["_ts"].ge(open_ts)
        ].copy()

    if eligible.empty:
        state = "TREND_SNAPSHOT_REQUIRED_BEFORE_CLOSE"
        latest_id = ""
        latest_created = ""
    else:
        eligible = eligible.sort_values("_ts")
        latest = eligible.iloc[-1].to_dict()
        state = "READY_FOR_EVIDENCE_CLOSE"
        latest_id = _text(latest.get("trend_snapshot_id"))
        latest_created = _text(latest.get("created_at"))

    return {
        "capture_state": state,
        "session_id": _text(open_session.get("session_id")),
        "session_date": session_date,
        "open_created_at": _text(open_session.get("created_at")),
        "eligible_trend_snapshots": int(len(eligible)),
        "same_session_superseded": max(0, int(len(eligible)) - 1),
        "latest_trend_snapshot_id": latest_id,
        "latest_trend_created_at": latest_created,
        # This guard is advisory. Operating close must remain possible even
        # when Flow evidence is unavailable.
        "close_blocking": False,
        "execution_authorization": "NONE",
    }


def apply_flow_evidence_guard(
    calibration: dict | None,
    evidence: dict | None,
) -> dict:
    result = dict(calibration or {})
    ev = evidence or {}

    qualified = _int(ev.get("qualified_endpoints"))
    qualified_intervals = max(
        0,
        _int(ev.get("qualified_intervals")),
    )
    invalid = (
        _int(ev.get("invalid_trend_snapshots"))
        + _int(ev.get("invalid_session_closes"))
        + _int(ev.get("invalid_session_pairs"))
    )
    guard = _text(ev.get("calibration_history_guard")).upper()
    min_endpoints = max(1, _int(ev.get("min_qualified_endpoints")))

    observed_intervals = _int(
        result.get("observed_intervals")
    )
    interval_alignment = (
        observed_intervals == qualified_intervals
    )

    result["saved_trend_snapshots"] = qualified
    result["invalid_trend_snapshots"] = max(
        _int(result.get("invalid_trend_snapshots")),
        invalid,
    )
    result["evidence_quality_state"] = _text(
        ev.get("evidence_state")
    )
    result["evidence_history_guard"] = guard
    result["qualified_closed_session_endpoints"] = qualified
    result["qualified_closed_session_intervals"] = qualified_intervals
    result["evidence_window_state"] = _text(
        ev.get("evidence_window_state")
    )
    result["lifetime_qualified_endpoints"] = _int(
        ev.get("lifetime_qualified_endpoints")
    )
    result["recent_consecutive_endpoints"] = _int(
        ev.get("recent_consecutive_endpoints")
    )
    result["capacity_regime_endpoints"] = _int(
        ev.get("capacity_regime_endpoints")
    )
    result["capacity_regime_break_count"] = _int(
        ev.get("capacity_regime_break_count")
    )
    result["evidence_latest_capacity"] = _int(
        ev.get("latest_capacity")
    )
    result["calibration_interval_mode"] = "CLOSED_SESSION_ONLY"
    result["interval_alignment_status"] = (
        "OK" if interval_alignment else "MISMATCH"
    )

    if not interval_alignment:
        result["calibration_state"] = "INTEGRITY_REVIEW"
        result["projection_guard"] = "HOLD_INTEGRITY"
    elif guard == "HOLD_INTEGRITY":
        result["calibration_state"] = "INTEGRITY_REVIEW"
        result["projection_guard"] = "HOLD_INTEGRITY"
    elif qualified < min_endpoints:
        # Preserve the existing v1.28 vocabulary so historical release-gate
        # invariants remain backwards compatible.
        result["calibration_state"] = "INSUFFICIENT_HISTORY"
        result["projection_guard"] = "HOLD_HISTORY"

    return result


def build_closed_session_calibration_trend(
    trend: dict | None,
    evidence: dict | None,
) -> dict:
    """
    Return a calibration-only copy of the Flow Trend where the synthetic LIVE
    interval is removed. Calibration evidence must be composed only of
    completed closed-session endpoints.

    Operational Trend can still keep its LIVE interval for monitoring.
    """
    result = dict(trend or {})
    ev = evidence or {}

    history = result.get("history_table")
    if not isinstance(history, pd.DataFrame) or history.empty:
        closed = pd.DataFrame()
        live_rows = 0
    else:
        table = history.copy()
        if "period_end" not in table.columns:
            table["period_end"] = ""
        is_live = (
            table["period_end"]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
            .eq("LIVE")
        )
        live_rows = int(is_live.sum())
        closed = table.loc[~is_live].reset_index(drop=True)

    expected = max(
        0,
        _int(ev.get("qualified_intervals")),
    )
    actual = int(len(closed))

    result["history_table"] = closed
    result["calibration_interval_mode"] = "CLOSED_SESSION_ONLY"
    result["closed_session_intervals"] = actual
    result["expected_closed_session_intervals"] = expected
    result["live_intervals_excluded"] = live_rows
    result["closed_interval_alignment_status"] = (
        "OK" if actual == expected else "MISMATCH"
    )
    return result



def build_flow_evidence_queue(
    evidence: dict | None,
) -> pd.DataFrame:
    ev = evidence or {}
    rows = []

    state = _text(ev.get("evidence_state")).upper()
    boundary_counts = ev.get("boundary_status_counts") or {}

    if state == "INTEGRITY_REVIEW":
        rows.append(
            {
                "priority": "FE0",
                "status": "BLOCKED",
                "issue": "FLOW_EVIDENCE_INTEGRITY",
                "detail": (
                    f"trend invalid {_int(ev.get('invalid_trend_snapshots'))} · "
                    f"open invalid {_int(ev.get('invalid_session_opens'))} · "
                    f"close invalid {_int(ev.get('invalid_session_closes'))} · "
                    f"pair invalid {_int(ev.get('invalid_session_pairs'))}"
                ),
                "next_action": (
                    "Trend Snapshot과 Daily Operations OPEN→CLOSE parent hash lineage를 먼저 확인"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "CLOSED_SESSION_EVIDENCE_REQUIRED":
        rows.append(
            {
                "priority": "FE1",
                "status": "WAIT",
                "issue": "CLOSED_SESSION_EVIDENCE_REQUIRED",
                "detail": (
                    f"raw trend {_int(ev.get('raw_trend_snapshots'))} · "
                    f"closed dates {_int(ev.get('closed_session_dates'))} · "
                    "qualified 0"
                ),
                "next_action": (
                    "실제 다음 Session에서는 OPEN 이후 Flow Trend Snapshot을 저장하고 그 뒤 Session을 CLOSE. "
                    "과거 CLOSE 뒤 Snapshot을 소급 evidence로 인정하지 않음"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "EVIDENCE_MATURING":
        rows.append(
            {
                "priority": "FE1",
                "status": "WAIT",
                "issue": "FLOW_EVIDENCE_MATURING",
                "detail": (
                    f"qualified {_int(ev.get('qualified_endpoints'))}/"
                    f"{_int(ev.get('min_qualified_endpoints'))} · "
                    f"intervals {_int(ev.get('qualified_intervals'))}"
                ),
                "next_action": (
                    "새 Daily Operations Session마다 OPEN→Trend Snapshot→CLOSE 순서를 실제 운영 흐름에 맞게 반복"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if _int(boundary_counts.get("POST_CLOSE_TREND_ONLY")) > 0:
        rows.append(
            {
                "priority": "FE1",
                "status": "REVIEW",
                "issue": "POST_CLOSE_TREND_ONLY",
                "detail": (
                    f"closed-session dates "
                    f"{_int(boundary_counts.get('POST_CLOSE_TREND_ONLY'))}"
                ),
                "next_action": (
                    "CLOSE 이후 저장된 Trend Snapshot은 소급 evidence로 사용하지 않음. "
                    "다음 실제 Session에서 Trend Snapshot을 CLOSE 전에 저장"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if _int(boundary_counts.get("PRE_OPEN_TREND_ONLY")) > 0:
        rows.append(
            {
                "priority": "FE1",
                "status": "REVIEW",
                "issue": "PRE_OPEN_TREND_ONLY",
                "detail": (
                    f"closed-session dates "
                    f"{_int(boundary_counts.get('PRE_OPEN_TREND_ONLY'))}"
                ),
                "next_action": (
                    "Session OPEN 이전 Snapshot은 해당 Session evidence로 사용하지 않음. "
                    "OPEN 이후 최신 상태를 Snapshot으로 저장"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if _int(boundary_counts.get("OUTSIDE_SESSION_WINDOW_ONLY")) > 0:
        rows.append(
            {
                "priority": "FE1",
                "status": "REVIEW",
                "issue": "OUTSIDE_SESSION_WINDOW_ONLY",
                "detail": (
                    f"closed-session dates "
                    f"{_int(boundary_counts.get('OUTSIDE_SESSION_WINDOW_ONLY'))}"
                ),
                "next_action": (
                    "OPEN~CLOSE 구간 안에 저장된 Trend Snapshot이 필요함"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if _int(boundary_counts.get("NO_SAME_DAY_TREND")) > 0:
        rows.append(
            {
                "priority": "FE1",
                "status": "WAIT",
                "issue": "NO_SAME_DAY_TREND",
                "detail": (
                    f"closed-session dates "
                    f"{_int(boundary_counts.get('NO_SAME_DAY_TREND'))}"
                ),
                "next_action": (
                    "다음 실제 Session에서 OPEN 이후 Trend Snapshot을 저장한 뒤 CLOSE"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    window_state = _text(
        ev.get("evidence_window_state")
    ).upper()

    if window_state == "RECENT_SESSION_GAP":
        rows.append(
            {
                "priority": "FE1",
                "status": "WAIT",
                "issue": "RECENT_CLOSED_SESSION_GAP",
                "detail": (
                    f"lifetime qualified {_int(ev.get('lifetime_qualified_endpoints'))} · "
                    f"active qualified {_int(ev.get('qualified_endpoints'))} · "
                    f"latest boundary {_text(ev.get('latest_boundary_status')) or 'MISSING'}"
                ),
                "next_action": (
                    "과거 qualified endpoint로 최근 evidence gap을 메우지 않음. "
                    "다음 실제 Session에서 OPEN→Trend Snapshot→CLOSE 순서로 새 연속 window를 시작"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if window_state == "CAPACITY_REGIME_MATURING":
        rows.append(
            {
                "priority": "FE1",
                "status": "WAIT",
                "issue": "FLOW_CAPACITY_REGIME_RESET",
                "detail": (
                    f"recent consecutive {_int(ev.get('recent_consecutive_endpoints'))} · "
                    f"current capacity regime {_int(ev.get('capacity_regime_endpoints'))} · "
                    f"capacity {_int(ev.get('latest_capacity'))}"
                ),
                "next_action": (
                    "Capacity 변경 이전 endpoint는 audit history로 보존하되 현재 Calibration clock에서는 제외. "
                    "새 Capacity regime에서 closed-session evidence를 다시 축적"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    superseded = _int(ev.get("same_day_superseded"))
    if superseded > 0:
        rows.append(
            {
                "priority": "FE2",
                "status": "INFO",
                "issue": "IN_SESSION_SNAPSHOT_SUPERSEDED",
                "detail": f"earlier in-session snapshots {superseded}",
                "next_action": (
                    "같은 Session window에서는 CLOSE 이전 최신 Trend Snapshot 1개만 Calibration evidence로 계산"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        rows.append(
            {
                "priority": "FE3",
                "status": "MONITOR",
                "issue": "FLOW_EVIDENCE_READY",
                "detail": (
                    f"qualified {_int(ev.get('qualified_endpoints'))} · "
                    f"coverage {_float(ev.get('coverage_ratio')):.1%}"
                ),
                "next_action": (
                    "Qualified session-window history를 사용해 Calibration을 계속 검토. "
                    "Projection/Capacity 자동 승인은 없음"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    order = {"FE0": 0, "FE1": 1, "FE2": 2, "FE3": 3}
    out = pd.DataFrame(rows, columns=FLOW_EVIDENCE_QUEUE_COLS)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(["_p", "issue"])
        .drop(columns=["_p"])
        .reset_index(drop=True)
    )


def _snapshot_payload(row: dict) -> dict:
    int_fields = {
        "raw_trend_snapshots",
        "valid_trend_snapshots",
        "invalid_trend_snapshots",
        "session_close_records",
        "valid_session_closes",
        "invalid_session_closes",
        "closed_session_dates",
        "qualified_endpoints",
        "qualified_intervals",
        "same_day_superseded",
        "unqualified_valid_snapshots",
        "closed_dates_without_trend",
    }

    payload = {}

    for col in FLOW_EVIDENCE_SNAPSHOT_COLS:
        if col in {
            "evidence_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(row.get(col))
        elif col == "coverage_ratio":
            payload[col] = round(_float(row.get(col)), 10)
        else:
            payload[col] = _text(row.get(col))

    return payload


def build_flow_evidence_snapshot(
    evidence: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    ev = evidence or {}
    now = _text(created_at) or datetime.now().astimezone().isoformat()

    endpoints = ev.get("endpoint_table")
    endpoint_df = (
        pd.DataFrame(columns=FLOW_EVIDENCE_ENDPOINT_COLS)
        if not isinstance(endpoints, pd.DataFrame)
        else endpoints.copy()
    )

    endpoint_ids = (
        endpoint_df["trend_snapshot_id"].fillna("").astype(str).tolist()
        if "trend_snapshot_id" in endpoint_df.columns
        else []
    )
    endpoint_hashes = (
        endpoint_df["snapshot_hash"].fillna("").astype(str).tolist()
        if "snapshot_hash" in endpoint_df.columns
        else []
    )
    endpoint_dates = (
        endpoint_df["session_date"].fillna("").astype(str).tolist()
        if "session_date" in endpoint_df.columns
        else []
    )

    base = {
        "raw_trend_snapshots": _int(ev.get("raw_trend_snapshots")),
        "valid_trend_snapshots": _int(ev.get("valid_trend_snapshots")),
        "invalid_trend_snapshots": _int(ev.get("invalid_trend_snapshots")),
        "session_close_records": _int(ev.get("session_close_records")),
        "valid_session_closes": _int(ev.get("valid_session_closes")),
        "invalid_session_closes": _int(ev.get("invalid_session_closes")),
        "closed_session_dates": _int(ev.get("closed_session_dates")),
        "qualified_endpoints": _int(ev.get("qualified_endpoints")),
        "qualified_intervals": _int(ev.get("qualified_intervals")),
        "same_day_superseded": _int(ev.get("same_day_superseded")),
        "unqualified_valid_snapshots": _int(ev.get("unqualified_valid_snapshots")),
        "closed_dates_without_trend": _int(ev.get("closed_dates_without_trend")),
        "coverage_ratio": _float(ev.get("coverage_ratio")),
        "evidence_state": _text(ev.get("evidence_state")),
        "calibration_history_guard": _text(
            ev.get("calibration_history_guard")
        ),
        "endpoint_ids_json": json.dumps(
            endpoint_ids,
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "endpoint_hashes_json": json.dumps(
            endpoint_hashes,
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "endpoint_dates_json": json.dumps(
            endpoint_dates,
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(_snapshot_payload(base))

    return {
        "evidence_snapshot_id": (
            "OFE-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_evidence_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = row.to_dict() if isinstance(row, pd.Series) else dict(row)
    stored = _text(item.get("snapshot_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_snapshot_payload(item))

    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def latest_flow_evidence_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()

    if df.empty:
        return {}

    for col in FLOW_EVIDENCE_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[df["_ts"].notna()].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )
