from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_live_change_apply import (
    FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    live_change_apply_snapshot_integrity,
)
from engine.operations_flow_live_change_runtime import (
    FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS,
    LIVE_CHANGE_RUNTIME_STATES,
    LIVE_CHANGE_RUNTIME_GUARD_BY_STATE,
    LIVE_CHANGE_RUNTIME_EVENT_TYPES,
    LIVE_CHANGE_RUNTIME_KILL_TRIGGERS,
    build_flow_live_change_runtime,
    live_change_runtime_snapshot_integrity,
    latest_live_change_runtime_snapshot,
)


LIVE_CHANGE_RUNTIME_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

LIVE_CHANGE_RUNTIME_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V148_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v148_live_change_runtime_context(
    *,
    v147_context: dict | None,
    live_change_runtime_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v147_context or {}
    apply = upstream.get("apply") or {}

    runtime_df = _ensure_cols(
        live_change_runtime_snapshots,
        FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS,
    )

    apply_df = _ensure_cols(
        upstream.get("live_change_apply_snapshots"),
        FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    runtime = build_flow_live_change_runtime(
        apply,
        runtime_df,
    )

    latest_runtime = latest_live_change_runtime_snapshot(
        runtime_df
    )

    latest_integrity = (
        _text(
            live_change_runtime_snapshot_integrity(
                latest_runtime
            ).get("status")
        ).upper()
        if latest_runtime
        else "NONE"
    )

    return {
        "v147_context": upstream,
        "apply": apply,
        "live_change_apply_snapshots": apply_df,
        "live_change_runtime_snapshots": runtime_df,
        "runtime": runtime,
        "runtime_integrity": _integrity_counts(
            runtime_df,
            live_change_runtime_snapshot_integrity,
        ),
        "latest_runtime": latest_runtime,
        "latest_runtime_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _apply_routing_ok(
    runtime: dict,
    apply: dict,
) -> bool:
    runtime_state = _text(
        runtime.get("runtime_state")
    ).upper()
    apply_state = _text(
        apply.get("apply_state")
    ).upper()

    if apply_state == "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY":
        return runtime_state in {
            "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
            "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
            "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY",
            "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
            "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
        }

    if apply_state in {
        "LIVE_CHANGE_APPLY_NOT_REQUIRED",
        "LIVE_CHANGE_APPLY_REJECTED",
    }:
        return runtime_state == "LIVE_CHANGE_RUNTIME_NOT_REQUIRED"

    if apply_state == "LIVE_CHANGE_APPLY_DEFERRED":
        return runtime_state == "LIVE_CHANGE_RUNTIME_DEFERRED"

    return runtime_state == "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT"


def _apply_source_mapping_ok(
    context: dict,
) -> bool:
    runtime = context.get("runtime") or {}
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if state in {
        "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT",
        "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
        "LIVE_CHANGE_RUNTIME_DEFERRED",
    }:
        return True

    source_id = _text(
        runtime.get("source_live_change_apply_id")
    )
    source_hash = _text(
        runtime.get("source_live_change_apply_hash")
    )

    if not source_id or not source_hash:
        return state in {
            "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
            "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        }

    index, duplicates = _index_by_id(
        context.get("live_change_apply_snapshots"),
        "live_change_apply_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(source_id)

    return (
        bool(parent)
        and _text(
            live_change_apply_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(parent.get("snapshot_hash"))
        == source_hash
        and _text(parent.get("apply_state")).upper()
        == "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY"
        and _text(
            parent.get("live_change_apply_permission")
        ).upper()
        == "MANUAL_CANARY_APPLY_ONLY"
    )


def _session_budget_state_ok(
    runtime: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if state in {
        "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT",
        "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
        "LIVE_CHANGE_RUNTIME_DEFERRED",
        "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
        "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
    }:
        return True

    budget = _int(
        runtime.get("permit_session_budget")
    )
    used = _int(
        runtime.get("sessions_used")
    )
    remaining = _int(
        runtime.get("sessions_remaining")
    )

    if budget <= 0:
        return False

    if used < 0 or used > budget:
        return False

    if remaining != max(0, budget - used):
        return False

    if state == "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION":
        return used < budget and remaining > 0

    if state == "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY":
        return (
            bool(
                _text(
                    runtime.get("active_session_id")
                )
            )
            and 1
            <= _int(
                runtime.get("session_index")
            )
            <= budget
            and bool(
                _text(
                    runtime.get("activation_receipt_ref")
                )
            )
        )

    if state == "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED":
        return used >= budget and remaining == 0

    if state == "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED":
        return bool(
            _text(
                runtime.get("active_session_id")
            )
        )

    return True


def _event_state_machine_ok(
    context: dict,
) -> bool:
    df = context.get(
        "live_change_runtime_snapshots"
    )

    if not isinstance(df, pd.DataFrame) or df.empty:
        return True

    history = df.copy()

    for col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
        if col not in history.columns:
            history[col] = ""

    history["_ts"] = pd.to_datetime(
        history["created_at"],
        errors="coerce",
        utc=True,
    )

    if history["_ts"].isna().any():
        return False

    history = history.sort_values("_ts")

    source_groups = {}

    for _, row in history.iterrows():
        item = row.to_dict()

        if _text(
            live_change_runtime_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            return False

        source_key = (
            _text(
                item.get(
                    "source_live_change_apply_id"
                )
            ),
            _text(
                item.get(
                    "source_live_change_apply_hash"
                )
            ),
        )

        if not all(source_key):
            return False

        source_groups.setdefault(
            source_key,
            [],
        ).append(item)

    for rows in source_groups.values():
        active_session = ""
        killed = False
        last_ts = None
        seen_sessions = set()

        for item in rows:
            ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if last_ts is not None and ts <= last_ts:
                return False
            last_ts = ts

            event_type = _text(
                item.get("event_type")
            ).upper()
            session_id = _text(
                item.get("runtime_session_id")
            )

            if event_type not in LIVE_CHANGE_RUNTIME_EVENT_TYPES:
                return False

            if event_type == "ACTIVATE":
                if killed or active_session or not session_id:
                    return False
                if session_id in seen_sessions:
                    return False
                if len(
                    _text(
                        item.get("activation_receipt_ref")
                    )
                ) < 8:
                    return False
                if _bool(
                    item.get("kill_switch_latched")
                ):
                    return False
                if _bool(
                    item.get("rollback_required")
                ):
                    return False

                if _text(
                    item.get("proposal_scope")
                ).upper() == "PARAMETER_SHADOW":
                    if abs(
                        _float(
                            item.get("observed_pre_value")
                        )
                        - _float(
                            item.get("baseline_value")
                        )
                    ) > 1e-9:
                        return False
                    if abs(
                        _float(
                            item.get("observed_post_value")
                        )
                        - _float(
                            item.get("candidate_value")
                        )
                    ) > 1e-9:
                        return False

                active_session = session_id
                seen_sessions.add(session_id)

            elif event_type == "CLOSE":
                if killed or session_id != active_session:
                    return False
                if not _bool(
                    item.get(
                        "baseline_restore_confirmed"
                    )
                ):
                    return False
                if abs(
                    _float(
                        item.get("observed_post_value")
                    )
                    - _float(
                        item.get("baseline_value")
                    )
                ) > 1e-9:
                    return False
                active_session = ""

            elif event_type == "KILL_SWITCH":
                if killed or session_id != active_session:
                    return False
                if _text(
                    item.get("kill_switch_trigger")
                ).upper() not in LIVE_CHANGE_RUNTIME_KILL_TRIGGERS:
                    return False
                if not _bool(
                    item.get("kill_switch_latched")
                ):
                    return False
                if not _bool(
                    item.get("rollback_required")
                ):
                    return False
                active_session = ""
                killed = True

    return True


def _rollback_contract_ok(
    runtime: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if state == "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED":
        latest = runtime.get("latest_event") or {}
        return (
            _text(
                latest.get("event_type")
            ).upper()
            == "KILL_SWITCH"
            and _text(
                latest.get("kill_switch_trigger")
            ).upper()
            in LIVE_CHANGE_RUNTIME_KILL_TRIGGERS
            and _bool(
                latest.get("kill_switch_latched")
            )
            and _bool(
                latest.get("rollback_required")
            )
            and _text(
                runtime.get("runtime_guard")
            ).upper()
            == "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED"
        )

    if state == "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED":
        latest = runtime.get("latest_event") or {}
        return (
            _text(
                latest.get("event_type")
            ).upper()
            == "CLOSE"
            and _bool(
                latest.get(
                    "baseline_restore_confirmed"
                )
            )
            and abs(
                _float(
                    latest.get("observed_post_value")
                )
                - _float(
                    latest.get("baseline_value")
                )
            ) <= 1e-9
        )

    return True


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    runtime = context.get("runtime") or {}
    state = _text(
        runtime.get("runtime_state")
    ).upper()
    latest = context.get(
        "latest_runtime"
    ) or {}

    if state in {
        "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY",
        "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
        "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
    }:
        if not latest:
            return False

        source_ts = pd.to_datetime(
            runtime.get(
                "source_live_change_apply_created_at"
            ),
            errors="coerce",
            utc=True,
        )
        runtime_ts = pd.to_datetime(
            latest.get("created_at"),
            errors="coerce",
            utc=True,
        )

        return (
            not pd.isna(source_ts)
            and not pd.isna(runtime_ts)
            and runtime_ts > source_ts
        )

    if state == "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(
                latest.get(
                    "source_live_change_apply_id"
                )
            )
            != _text(
                runtime.get(
                    "source_live_change_apply_id"
                )
            )
            or _text(
                latest.get(
                    "source_live_change_apply_hash"
                )
            )
            != _text(
                runtime.get(
                    "source_live_change_apply_hash"
                )
            )
        )

    return True


def _no_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("runtime") or {},
        context.get("latest_runtime") or {},
        context.get("apply") or {},
    ]:
        for field in [
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "live_change_design_authorization",
            "trial_closure_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "live_change_runtime_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v148_live_change_runtime_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    runtime = ctx.get("runtime") or {}
    apply = ctx.get("apply") or {}
    counts = ctx.get("runtime_integrity") or {}

    state = _text(
        runtime.get("runtime_state")
    ).upper()
    guard = _text(
        runtime.get("runtime_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Live Change Runtime Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Runtime immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Runtime State / Guard Vocabulary",
            (
                state in LIVE_CHANGE_RUNTIME_STATES
                and guard
                == LIVE_CHANGE_RUNTIME_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {LIVE_CHANGE_RUNTIME_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Live Change Runtime state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Apply → Runtime State Invariant",
            _apply_routing_ok(
                runtime,
                apply,
            ),
            (
                f"apply {_text(apply.get('apply_state')) or 'MISSING'} · "
                f"runtime {state or 'MISSING'}"
            ),
            "Apply permit/Reject/Defer와 Runtime state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Runtime → Immutable Apply Permit Source Mapping",
            _apply_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"apply source {_text(runtime.get('source_live_change_apply_id')) or 'NONE'} · "
                f"integrity {_text(runtime.get('source_live_change_apply_integrity')) or 'NONE'}"
            ),
            "Runtime source Apply Permit id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Runtime Session Budget / Active Session Invariant",
            _session_budget_state_ok(
                runtime
            ),
            (
                f"state {state or 'MISSING'} · "
                f"sessions {_int(runtime.get('sessions_used'))}/"
                f"{_int(runtime.get('permit_session_budget'))} · "
                f"remaining {_int(runtime.get('sessions_remaining'))}"
            ),
            "Runtime session budget, remaining count, active session/receipt 확인",
        )
    )

    checks.append(
        _technical_row(
            "Manual Activation / Baseline Restore / Kill-Switch Invariant",
            (
                _event_state_machine_ok(
                    ctx
                )
                and _rollback_contract_ok(
                    runtime
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"receipt {_text(runtime.get('activation_receipt_ref')) or 'NONE'} · "
                f"kill {_bool(runtime.get('kill_switch_latched'))} · "
                f"rollback {_bool(runtime.get('rollback_required'))}"
            ),
            "ACTIVATE/CLOSE/KILL_SWITCH 순서, observed baseline/candidate, rollback contract 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Runtime Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"permit created {_text(runtime.get('source_live_change_apply_created_at')) or 'NONE'} · "
                f"latest runtime {_text((ctx.get('latest_runtime') or {}).get('live_change_runtime_event_id')) or 'NONE'}"
            ),
            "Runtime 저장 순서와 새 Apply Permit source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Runtime No-Auto-Apply Authorization Invariant",
            _no_authorization_ok(
                ctx
            ),
            "NONE",
            "Runtime/Apply/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
            "LIVE_CHANGE_RUNTIME_DEFERRED",
            "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Runtime Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"permission {_text(runtime.get('live_change_runtime_permission')) or 'NONE'} · "
                f"sessions {_int(runtime.get('sessions_used'))}/"
                f"{_int(runtime.get('permit_session_budget'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 runtime wait/ready/active/kill-switch 상태는 Technical FAIL로 승격하지 않고 "
                    "external activation/rollback evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "runtime_state": state,
        "apply_state": _text(
            apply.get("apply_state")
        ).upper(),
        "latest_live_change_runtime_integrity":
            _text(
                ctx.get("latest_runtime_integrity")
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_RUNTIME_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_event_contract_ok(
    item: dict,
) -> bool:
    event_type = _text(
        item.get("event_type")
    ).upper()
    state = _text(
        item.get("runtime_state")
    ).upper()
    guard = _text(
        item.get("runtime_guard")
    ).upper()

    if (
        event_type not in LIVE_CHANGE_RUNTIME_EVENT_TYPES
        or state not in LIVE_CHANGE_RUNTIME_STATES
        or guard
        != LIVE_CHANGE_RUNTIME_GUARD_BY_STATE.get(
            state,
            "",
        )
    ):
        return False

    required_flags = [
        "permit_source_reviewed",
        "rollback_path_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            item.get(field)
        )
        for field in required_flags
    ):
        return False

    if event_type == "ACTIVATE":
        activate_flags = [
            "baseline_freshness_confirmed",
            "candidate_artifact_verified",
            "canary_isolation_confirmed",
            "change_window_confirmed",
            "manual_external_activation_confirmed",
        ]

        if not all(
            _bool(
                item.get(field)
            )
            for field in activate_flags
        ):
            return False

        if state != "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY":
            return False

        if len(
            _text(
                item.get("activation_receipt_ref")
            )
        ) < 8:
            return False

        if _text(
            item.get("proposal_scope")
        ).upper() == "PARAMETER_SHADOW":
            if abs(
                _float(
                    item.get("observed_pre_value")
                )
                - _float(
                    item.get("baseline_value")
                )
            ) > 1e-9:
                return False

            if abs(
                _float(
                    item.get("observed_post_value")
                )
                - _float(
                    item.get("candidate_value")
                )
            ) > 1e-9:
                return False

        return (
            not _bool(
                item.get("kill_switch_latched")
            )
            and not _bool(
                item.get("rollback_required")
            )
        )

    if event_type == "CLOSE":
        return (
            state
            in {
                "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
                "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            }
            and _bool(
                item.get("baseline_restore_confirmed")
            )
            and abs(
                _float(
                    item.get("observed_post_value")
                )
                - _float(
                    item.get("baseline_value")
                )
            )
            <= 1e-9
            and not _bool(
                item.get("kill_switch_latched")
            )
            and not _bool(
                item.get("rollback_required")
            )
        )

    if event_type == "KILL_SWITCH":
        return (
            state
            == "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED"
            and _text(
                item.get("kill_switch_trigger")
            ).upper()
            in LIVE_CHANGE_RUNTIME_KILL_TRIGGERS
            and _bool(
                item.get("kill_switch_latched")
            )
            and _bool(
                item.get("rollback_required")
            )
        )

    return False


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v148_live_change_runtime_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    runtime_df = _ensure_cols(
        ctx.get(
            "live_change_runtime_snapshots"
        ),
        FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS,
    )

    apply_df = _ensure_cols(
        ctx.get(
            "live_change_apply_snapshots"
        ),
        FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        runtime_df,
        live_change_runtime_snapshot_integrity,
    )

    apply_index, apply_duplicates = _index_by_id(
        apply_df,
        "live_change_apply_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    ordered = runtime_df.copy()

    if not ordered.empty:
        ordered["_ts"] = pd.to_datetime(
            ordered["created_at"],
            errors="coerce",
            utc=True,
        )
        ordered = ordered.sort_values("_ts")

    for _, row in ordered.iterrows():
        item = row.to_dict()

        event_id = _text(
            item.get(
                "live_change_runtime_event_id"
            )
        )

        if event_id:
            if event_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(event_id)

        if not _saved_event_contract_ok(
            item
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_live_change_apply_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_live_change_apply_hash"
            )
        )

        parent = apply_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                live_change_apply_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("apply_state")
            ).upper()
            != "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY"
            or _text(
                parent.get("live_change_apply_permission")
            ).upper()
            != "MANUAL_CANARY_APPLY_ONLY"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )
            event_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(event_ts)
                or event_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    state_machine_ok = _event_state_machine_ok(
        ctx
    )
    if not state_machine_ok:
        contract_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Live Change Runtime Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Runtime immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Runtime Audit Activation / Rollback Contract",
            contract_violations == 0,
            (
                f"contract violations {contract_violations} · "
                f"state machine {'OK' if state_machine_ok else 'FAIL'}"
            ),
            "ACTIVATE/CLOSE/KILL_SWITCH, receipt, baseline restore, rollback contract 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Runtime Audit → Apply Permit Lineage",
            (
                lineage_violations == 0
                and apply_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"apply duplicate ids {apply_duplicates}"
            ),
            "Runtime source immutable Manual Canary Apply Permit id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Runtime Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate runtime ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Runtime audit identity uniqueness 및 Apply Permit 이후 event 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Runtime Audit No-Auto-Apply Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else f"non-NONE sources {authorization_violations}"
            ),
            "Runtime/Apply/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("runtime") or {}).get(
            "runtime_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
            "LIVE_CHANGE_RUNTIME_DEFERRED",
            "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Runtime Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current runtime {current_state or 'MISSING'} · "
                f"saved events {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 MANUAL_CANARY_APPLY_ONLY permit 이후 external ACTIVATE/CLOSE/KILL evidence가 생길 때만 "
                    "Runtime audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_RUNTIME_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v148_release_readiness(
    *,
    v147_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    live_change_runtime_release_gate: str,
    live_change_runtime_audit_gate: str,
    live_change_runtime_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.47 Live Change Apply Release Baseline",
            _text(v147_release_status).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(v147_release_status).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(integration_consistency).upper()
            == "PASS",
            _text(integration_consistency).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Live Change Runtime Technical Release Gate",
            _text(live_change_runtime_release_gate).upper()
            == "PASS",
            _text(live_change_runtime_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Runtime Audit Integrity Gate",
            _text(live_change_runtime_audit_gate).upper()
            == "PASS",
            _text(live_change_runtime_audit_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(execution_authorization).upper()
            == "NONE",
            _text(execution_authorization).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            live_change_runtime_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "LIVE_CHANGE_RUNTIME_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V148_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v148_integration_crosscheck(
    *,
    integration_consistency: str,
    live_change_runtime_release_gate: str,
    live_change_runtime_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(integration_consistency).upper()
            == "PASS",
            _text(integration_consistency).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Runtime Technical Gate",
            _text(live_change_runtime_release_gate).upper()
            == "PASS",
            _text(live_change_runtime_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Runtime Audit Gate",
            _text(live_change_runtime_audit_gate).upper()
            == "PASS",
            _text(live_change_runtime_audit_gate).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V148_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v148_data_crosscheck(
    *,
    csv_fail_count: int,
    live_change_runtime_release_gate: str,
    live_change_runtime_audit_gate: str,
    latest_live_change_runtime_integrity: str,
) -> dict:
    latest = _text(
        latest_live_change_runtime_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Live Change Runtime Technical Gate",
            _text(live_change_runtime_release_gate).upper()
            == "PASS",
            _text(live_change_runtime_release_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Runtime Audit Gate",
            _text(live_change_runtime_audit_gate).upper()
            == "PASS",
            _text(live_change_runtime_audit_gate).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Live Change Runtime Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V148_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
