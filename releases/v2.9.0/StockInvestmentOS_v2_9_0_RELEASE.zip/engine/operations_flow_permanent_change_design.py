from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_live_change_outcome_closure import (
    live_change_outcome_closure_snapshot_integrity,
    latest_live_change_outcome_closure_snapshot,
)


FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS = [
    "permanent_change_design_id",
    "created_at",
    "design_state",
    "design_guard",
    "source_live_change_closure_id",
    "source_live_change_closure_hash",
    "source_live_change_closure_created_at",
    "source_live_change_closure_integrity",
    "source_live_change_outcome_id",
    "source_live_change_outcome_hash",
    "source_runtime_event_id",
    "source_runtime_event_hash",
    "source_live_change_apply_id",
    "source_live_change_apply_hash",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "closure_decision",
    "source_permanent_change_design_permission",
    "proposal_scope",
    "target_metric",
    "source_change_mode",
    "permanent_change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "target_scope_pct",
    "initial_stage_scope_pct",
    "rollout_stage_count",
    "proof_clock_days",
    "min_post_change_outcomes",
    "max_relative_error_degradation_pct",
    "rollback_observation_hours",
    "design_detail",
    "rollout_detail",
    "rollback_detail",
    "monitoring_detail",
    "source_reviewed",
    "post_change_evidence_reviewed",
    "baseline_locked_confirmed",
    "candidate_artifact_verified",
    "staged_rollout_confirmed",
    "reversible_rollout_confirmed",
    "rollback_path_confirmed",
    "monitoring_plan_confirmed",
    "separate_apply_gate_required_confirmed",
    "no_permanent_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "permanent_change_design_permission",
    "permanent_change_design_authorization",
    "permanent_change_apply_authorization",
    "permanent_change_runtime_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PERMANENT_CHANGE_DESIGN_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


PERMANENT_CHANGE_DESIGN_STATES = {
    "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT",
    "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
    "PERMANENT_CHANGE_DESIGN_DEFERRED",
    "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
    "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
    "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED",
    "PERMANENT_CHANGE_DESIGN_REQUIRED",
    "PERMANENT_CHANGE_DESIGN_LOCKED",
}


PERMANENT_CHANGE_DESIGN_GUARD_BY_STATE = {
    "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT":
        "HOLD_LIVE_CHANGE_CLOSURE",
    "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED":
        "NO_PERMANENT_CHANGE_DESIGN",
    "PERMANENT_CHANGE_DESIGN_DEFERRED":
        "HOLD_PERMANENT_CHANGE_DESIGN",
    "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED":
        "HOLD_PERMANENT_CHANGE_CLOSURE_SOURCE",
    "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW":
        "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
    "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED":
        "HOLD_PERMANENT_CHANGE_DESIGN_SOURCE",
    "PERMANENT_CHANGE_DESIGN_REQUIRED":
        "HUMAN_PERMANENT_CHANGE_DESIGN_REQUIRED",
    "PERMANENT_CHANGE_DESIGN_LOCKED":
        "PERMANENT_CHANGE_DESIGN_LOCKED_NO_APPLY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass

    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )

    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _design_payload(
    row: dict,
) -> dict:
    int_fields = {
        "rollout_stage_count",
        "proof_clock_days",
        "min_post_change_outcomes",
        "rollback_observation_hours",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "target_scope_pct",
        "initial_stage_scope_pct",
        "max_relative_error_degradation_pct",
    }

    bool_fields = {
        "source_reviewed",
        "post_change_evidence_reviewed",
        "baseline_locked_confirmed",
        "candidate_artifact_verified",
        "staged_rollout_confirmed",
        "reversible_rollout_confirmed",
        "rollback_path_confirmed",
        "monitoring_plan_confirmed",
        "separate_apply_gate_required_confirmed",
        "no_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS:
        if col in {
            "permanent_change_design_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def permanent_change_design_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(
            row,
            pd.Series,
        )
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _design_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_permanent_change_design_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values(
        "_ts"
    )

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _permanent_mode(
    proposal_scope: Any,
) -> str:
    scope = _text(
        proposal_scope
    ).upper()

    if scope == "PARAMETER_SHADOW":
        return "PARAMETER_PERMANENT_STAGED_DESIGN"

    if scope == "MODEL_SHADOW":
        return "MODEL_PERMANENT_STAGED_DESIGN"

    return "PERMANENT_CHANGE_STAGED_DESIGN"


def _accepted_closure_source(
    closure: dict | None,
) -> dict:
    row = closure or {}

    if _text(
        row.get("closure_state")
    ).upper() != (
        "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
    ):
        return {}

    if _text(
        row.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_REVIEW_ONLY":
        return {}

    latest = row.get(
        "latest_closure"
    ) or {}

    if not latest:
        return {}

    if _text(
        live_change_outcome_closure_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get("decision")
    ).upper() != (
        "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
    ):
        return {}

    if _text(
        latest.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_REVIEW_ONLY":
        return {}

    return latest


def _design_matches_source(
    design: dict,
    closure_source: dict,
) -> bool:
    if not design or not closure_source:
        return False

    if _text(
        permanent_change_design_snapshot_integrity(
            design
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            design.get(
                "source_live_change_closure_id"
            )
        )
        == _text(
            closure_source.get(
                "live_change_outcome_closure_id"
            )
        )
        and _text(
            design.get(
                "source_live_change_closure_hash"
            )
        )
        == _text(
            closure_source.get(
                "snapshot_hash"
            )
        )
    )


def build_flow_permanent_change_design(
    live_change_closure: dict | None,
    closure_snapshots: pd.DataFrame | None,
    design_snapshots: pd.DataFrame | None,
) -> dict:
    closure = live_change_closure or {}

    closure_state = _text(
        closure.get("closure_state")
    ).upper()

    base = {
        "source_live_change_closure_id": "",
        "source_live_change_closure_hash": "",
        "source_live_change_closure_created_at": "",
        "source_live_change_closure_integrity": "NONE",
        "source_live_change_outcome_id": _text(
            closure.get(
                "source_live_change_outcome_id"
            )
        ),
        "source_live_change_outcome_hash": _text(
            closure.get(
                "source_live_change_outcome_hash"
            )
        ),
        "source_runtime_event_id": _text(
            closure.get(
                "source_runtime_event_id"
            )
        ),
        "source_runtime_event_hash": _text(
            closure.get(
                "source_runtime_event_hash"
            )
        ),
        "source_live_change_apply_id": _text(
            closure.get(
                "source_live_change_apply_id"
            )
        ),
        "source_live_change_apply_hash": _text(
            closure.get(
                "source_live_change_apply_hash"
            )
        ),
        "source_live_change_design_id": _text(
            closure.get(
                "source_live_change_design_id"
            )
        ),
        "source_live_change_design_hash": _text(
            closure.get(
                "source_live_change_design_hash"
            )
        ),
        "source_proposal_id": _text(
            closure.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            closure.get(
                "source_proposal_hash"
            )
        ),
        "closure_decision": _text(
            closure.get("decision")
        ).upper(),
        "source_permanent_change_design_permission":
            _text(
                closure.get(
                    "permanent_change_design_permission"
                )
            ).upper()
            or "NONE",
        "proposal_scope": _text(
            closure.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            closure.get(
                "target_metric"
            )
        ).upper(),
        "source_change_mode": _text(
            closure.get(
                "change_mode"
            )
        ).upper(),
        "permanent_change_mode": _permanent_mode(
            closure.get(
                "proposal_scope"
            )
        ),
        "artifact_ref": _text(
            closure.get(
                "artifact_ref"
            )
        ),
        "baseline_value": _float(
            closure.get(
                "baseline_value"
            )
        ),
        "candidate_value": _float(
            closure.get(
                "candidate_value"
            )
        ),
        "rollback_target_value": _float(
            closure.get(
                "rollback_target_value"
            )
        ),
        "target_scope_pct": 1.0,
        "initial_stage_scope_pct": 0.05,
        "rollout_stage_count": 3,
        "proof_clock_days": 30,
        "min_post_change_outcomes": 5,
        "max_relative_error_degradation_pct": 0.03,
        "rollback_observation_hours": 72,
        "design_detail": "",
        "rollout_detail": "",
        "rollback_detail": "",
        "monitoring_detail": "",
        "latest_design": {},
        "permanent_change_design_permission": "NONE",
        "permanent_change_design_authorization": "NONE",
        "permanent_change_apply_authorization": "NONE",
        "permanent_change_runtime_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if closure_state in {
        "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
        "LIVE_CHANGE_CLOSURE_REJECTED",
        "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
    }:
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
            "design_guard":
                "NO_PERMANENT_CHANGE_DESIGN",
        }

    if closure_state == "LIVE_CHANGE_CLOSURE_DEFERRED":
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_DEFERRED",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN",
        }

    if closure_state != (
        "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
    ):
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT",
            "design_guard":
                "HOLD_LIVE_CHANGE_CLOSURE",
        }

    if _text(
        closure.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_REVIEW_ONLY":
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
        }

    closure_source = _accepted_closure_source(
        closure
    )

    if not closure_source:
        history = (
            pd.DataFrame()
            if closure_snapshots is None
            else closure_snapshots.copy()
        )

        latest = latest_live_change_outcome_closure_snapshot(
            history
        )

        if not latest:
            return {
                **base,
                "design_state":
                    "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
                "design_guard":
                    "HOLD_PERMANENT_CHANGE_CLOSURE_SOURCE",
            }

        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
        }

    source_integrity = _text(
        live_change_outcome_closure_snapshot_integrity(
            closure_source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_live_change_closure_id":
                _text(
                    closure_source.get(
                        "live_change_outcome_closure_id"
                    )
                ),
            "source_live_change_closure_hash":
                _text(
                    closure_source.get(
                        "snapshot_hash"
                    )
                ),
            "source_live_change_closure_created_at":
                _text(
                    closure_source.get(
                        "created_at"
                    )
                ),
            "source_live_change_closure_integrity":
                source_integrity,
            "source_live_change_outcome_id":
                _text(
                    closure_source.get(
                        "source_live_change_outcome_id"
                    )
                ),
            "source_live_change_outcome_hash":
                _text(
                    closure_source.get(
                        "source_live_change_outcome_hash"
                    )
                ),
            "source_runtime_event_id":
                _text(
                    closure_source.get(
                        "source_runtime_event_id"
                    )
                ),
            "source_runtime_event_hash":
                _text(
                    closure_source.get(
                        "source_runtime_event_hash"
                    )
                ),
            "source_live_change_apply_id":
                _text(
                    closure_source.get(
                        "source_live_change_apply_id"
                    )
                ),
            "source_live_change_apply_hash":
                _text(
                    closure_source.get(
                        "source_live_change_apply_hash"
                    )
                ),
            "source_live_change_design_id":
                _text(
                    closure_source.get(
                        "source_live_change_design_id"
                    )
                ),
            "source_live_change_design_hash":
                _text(
                    closure_source.get(
                        "source_live_change_design_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    closure_source.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    closure_source.get(
                        "source_proposal_hash"
                    )
                ),
            "closure_decision":
                _text(
                    closure_source.get(
                        "decision"
                    )
                ).upper(),
            "source_permanent_change_design_permission":
                _text(
                    closure_source.get(
                        "permanent_change_design_permission"
                    )
                ).upper(),
            "proposal_scope":
                _text(
                    closure_source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    closure_source.get(
                        "target_metric"
                    )
                ).upper(),
            "source_change_mode":
                _text(
                    closure_source.get(
                        "change_mode"
                    )
                ).upper(),
            "permanent_change_mode":
                _permanent_mode(
                    closure_source.get(
                        "proposal_scope"
                    )
                ),
            "artifact_ref":
                _text(
                    closure_source.get(
                        "artifact_ref"
                    )
                ),
            "baseline_value":
                _float(
                    closure_source.get(
                        "baseline_value"
                    )
                ),
            "candidate_value":
                _float(
                    closure_source.get(
                        "candidate_value"
                    )
                ),
            "rollback_target_value":
                _float(
                    closure_source.get(
                        "rollback_target_value"
                    )
                ),
        }
    )

    if source_integrity != "OK":
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
        }

    if (
        base["proposal_scope"]
        not in {
            "PARAMETER_SHADOW",
            "MODEL_SHADOW",
        }
    ):
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
        }

    if (
        base["proposal_scope"]
        == "PARAMETER_SHADOW"
        and (
            base["baseline_value"] <= 0
            or base["candidate_value"] <= 0
            or abs(
                base["rollback_target_value"]
                - base["baseline_value"]
            )
            > 1e-9
        )
    ):
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
        }

    design_history = (
        pd.DataFrame()
        if design_snapshots is None
        else design_snapshots.copy()
    )

    latest_design = latest_permanent_change_design_snapshot(
        design_history
    )

    if not latest_design:
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_REQUIRED",
            "design_guard":
                "HUMAN_PERMANENT_CHANGE_DESIGN_REQUIRED",
        }

    base["latest_design"] = latest_design

    latest_integrity = _text(
        permanent_change_design_snapshot_integrity(
            latest_design
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_INTEGRITY",
        }

    if not _design_matches_source(
        latest_design,
        closure_source,
    ):
        return {
            **base,
            "design_state":
                "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED",
            "design_guard":
                "HOLD_PERMANENT_CHANGE_DESIGN_SOURCE",
        }

    return {
        **base,
        "target_scope_pct":
            _float(
                latest_design.get(
                    "target_scope_pct"
                )
            ),
        "initial_stage_scope_pct":
            _float(
                latest_design.get(
                    "initial_stage_scope_pct"
                )
            ),
        "rollout_stage_count":
            _int(
                latest_design.get(
                    "rollout_stage_count"
                )
            ),
        "proof_clock_days":
            _int(
                latest_design.get(
                    "proof_clock_days"
                )
            ),
        "min_post_change_outcomes":
            _int(
                latest_design.get(
                    "min_post_change_outcomes"
                )
            ),
        "max_relative_error_degradation_pct":
            _float(
                latest_design.get(
                    "max_relative_error_degradation_pct"
                )
            ),
        "rollback_observation_hours":
            _int(
                latest_design.get(
                    "rollback_observation_hours"
                )
            ),
        "design_detail":
            _text(
                latest_design.get(
                    "design_detail"
                )
            ),
        "rollout_detail":
            _text(
                latest_design.get(
                    "rollout_detail"
                )
            ),
        "rollback_detail":
            _text(
                latest_design.get(
                    "rollback_detail"
                )
            ),
        "monitoring_detail":
            _text(
                latest_design.get(
                    "monitoring_detail"
                )
            ),
        "permanent_change_design_permission":
            _text(
                latest_design.get(
                    "permanent_change_design_permission"
                )
            ).upper()
            or "NONE",
        "design_state":
            "PERMANENT_CHANGE_DESIGN_LOCKED",
        "design_guard":
            "PERMANENT_CHANGE_DESIGN_LOCKED_NO_APPLY",
    }


def build_flow_permanent_change_design_lock(
    design: dict,
    *,
    target_scope_pct: float,
    initial_stage_scope_pct: float,
    rollout_stage_count: int,
    proof_clock_days: int,
    min_post_change_outcomes: int,
    max_relative_error_degradation_pct: float,
    rollback_observation_hours: int,
    design_detail: str,
    rollout_detail: str,
    rollback_detail: str,
    monitoring_detail: str,
    source_reviewed: bool,
    post_change_evidence_reviewed: bool,
    baseline_locked_confirmed: bool,
    candidate_artifact_verified: bool,
    staged_rollout_confirmed: bool,
    reversible_rollout_confirmed: bool,
    rollback_path_confirmed: bool,
    monitoring_plan_confirmed: bool,
    separate_apply_gate_required_confirmed: bool,
    no_permanent_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = design or {}

    if _text(
        current.get("design_state")
    ).upper() != "PERMANENT_CHANGE_DESIGN_REQUIRED":
        raise ValueError(
            "Permanent Change Design은 DESIGN_REQUIRED 상태에서만 lock할 수 있습니다."
        )

    if _text(
        current.get(
            "source_live_change_closure_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Live Change Closure integrity가 OK가 아닙니다."
        )

    if _text(
        current.get(
            "source_permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_REVIEW_ONLY":
        raise ValueError(
            "PERMANENT_DESIGN_REVIEW_ONLY permission이 필요합니다."
        )

    target_scope = float(
        target_scope_pct
    )

    stage_scope = float(
        initial_stage_scope_pct
    )

    stages = int(
        rollout_stage_count
    )

    proof_days = int(
        proof_clock_days
    )

    min_outcomes = int(
        min_post_change_outcomes
    )

    degradation = float(
        max_relative_error_degradation_pct
    )

    rollback_hours = int(
        rollback_observation_hours
    )

    if not (
        0 < target_scope <= 1.0
    ):
        raise ValueError(
            "Target Scope은 0% 초과 100% 이하여야 합니다."
        )

    if not (
        0 < stage_scope <= 0.10
        and stage_scope <= target_scope
    ):
        raise ValueError(
            "Initial Stage Scope은 0% 초과, 10% 이하이며 Target Scope 이하여야 합니다."
        )

    if not (
        2 <= stages <= 10
    ):
        raise ValueError(
            "Rollout Stage Count는 2~10이어야 합니다."
        )

    if not (
        7 <= proof_days <= 365
    ):
        raise ValueError(
            "Proof Clock은 7~365일이어야 합니다."
        )

    if min_outcomes < 5:
        raise ValueError(
            "Permanent Change Design은 최소 5개의 post-change outcome을 요구합니다."
        )

    if not (
        0 <= degradation <= 0.10
    ):
        raise ValueError(
            "허용 relative error degradation은 0~10%여야 합니다."
        )

    if not (
        24 <= rollback_hours <= 720
    ):
        raise ValueError(
            "Rollback Observation Window는 24~720시간이어야 합니다."
        )

    proposal_scope = _text(
        current.get("proposal_scope")
    ).upper()

    baseline = _float(
        current.get("baseline_value")
    )

    candidate = _float(
        current.get("candidate_value")
    )

    rollback_target = _float(
        current.get("rollback_target_value")
    )

    if proposal_scope == "PARAMETER_SHADOW":
        if (
            baseline <= 0
            or candidate <= 0
            or abs(
                rollback_target
                - baseline
            )
            > 1e-9
        ):
            raise ValueError(
                "PARAMETER_SHADOW의 baseline/candidate/rollback source가 유효하지 않습니다."
            )

        if abs(
            candidate
            - baseline
        ) <= 1e-12:
            raise ValueError(
                "Permanent candidate가 baseline과 동일합니다."
            )

    elif proposal_scope == "MODEL_SHADOW":
        if len(
            _text(
                current.get("artifact_ref")
            )
        ) < 10:
            raise ValueError(
                "MODEL_SHADOW는 검증 가능한 candidate artifact reference가 필요합니다."
            )

    else:
        raise ValueError(
            "지원하지 않는 permanent-change proposal scope입니다."
        )

    details = {
        "Permanent Change Design":
            _text(
                design_detail
            ),
        "Staged Rollout Plan":
            _text(
                rollout_detail
            ),
        "Rollback Plan":
            _text(
                rollback_detail
            ),
        "Monitoring Plan":
            _text(
                monitoring_detail
            ),
    }

    for label, detail in details.items():
        if len(detail) < 60:
            raise ValueError(
                f"{label}을 60자 이상 기록하세요."
            )

    confirmations = {
        "source_reviewed":
            bool(
                source_reviewed
            ),
        "post_change_evidence_reviewed":
            bool(
                post_change_evidence_reviewed
            ),
        "baseline_locked_confirmed":
            bool(
                baseline_locked_confirmed
            ),
        "candidate_artifact_verified":
            bool(
                candidate_artifact_verified
            ),
        "staged_rollout_confirmed":
            bool(
                staged_rollout_confirmed
            ),
        "reversible_rollout_confirmed":
            bool(
                reversible_rollout_confirmed
            ),
        "rollback_path_confirmed":
            bool(
                rollback_path_confirmed
            ),
        "monitoring_plan_confirmed":
            bool(
                monitoring_plan_confirmed
            ),
        "separate_apply_gate_required_confirmed":
            bool(
                separate_apply_gate_required_confirmed
            ),
        "no_permanent_apply_confirmed":
            bool(
                no_permanent_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Permanent Change Design Human Review 확인사항을 모두 검토해야 합니다."
        )

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    source_ts = pd.to_datetime(
        current.get(
            "source_live_change_closure_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    design_ts = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            source_ts
        )
        or pd.isna(
            design_ts
        )
        or design_ts <= source_ts
    ):
        raise ValueError(
            "Permanent Change Design은 source Human Closure 이후에 저장되어야 합니다."
        )

    base = {
        "design_state":
            "PERMANENT_CHANGE_DESIGN_LOCKED",
        "design_guard":
            "PERMANENT_CHANGE_DESIGN_LOCKED_NO_APPLY",
        "source_live_change_closure_id":
            _text(
                current.get(
                    "source_live_change_closure_id"
                )
            ),
        "source_live_change_closure_hash":
            _text(
                current.get(
                    "source_live_change_closure_hash"
                )
            ),
        "source_live_change_closure_created_at":
            _text(
                current.get(
                    "source_live_change_closure_created_at"
                )
            ),
        "source_live_change_closure_integrity":
            "OK",
        "source_live_change_outcome_id":
            _text(
                current.get(
                    "source_live_change_outcome_id"
                )
            ),
        "source_live_change_outcome_hash":
            _text(
                current.get(
                    "source_live_change_outcome_hash"
                )
            ),
        "source_runtime_event_id":
            _text(
                current.get(
                    "source_runtime_event_id"
                )
            ),
        "source_runtime_event_hash":
            _text(
                current.get(
                    "source_runtime_event_hash"
                )
            ),
        "source_live_change_apply_id":
            _text(
                current.get(
                    "source_live_change_apply_id"
                )
            ),
        "source_live_change_apply_hash":
            _text(
                current.get(
                    "source_live_change_apply_hash"
                )
            ),
        "source_live_change_design_id":
            _text(
                current.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                current.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "closure_decision":
            _text(
                current.get(
                    "closure_decision"
                )
            ),
        "source_permanent_change_design_permission":
            "PERMANENT_DESIGN_REVIEW_ONLY",
        "proposal_scope":
            proposal_scope,
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "source_change_mode":
            _text(
                current.get(
                    "source_change_mode"
                )
            ),
        "permanent_change_mode":
            _text(
                current.get(
                    "permanent_change_mode"
                )
            ),
        "artifact_ref":
            _text(
                current.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            baseline,
        "candidate_value":
            candidate,
        "rollback_target_value":
            rollback_target,
        "target_scope_pct":
            target_scope,
        "initial_stage_scope_pct":
            stage_scope,
        "rollout_stage_count":
            stages,
        "proof_clock_days":
            proof_days,
        "min_post_change_outcomes":
            min_outcomes,
        "max_relative_error_degradation_pct":
            degradation,
        "rollback_observation_hours":
            rollback_hours,
        "design_detail":
            details[
                "Permanent Change Design"
            ],
        "rollout_detail":
            details[
                "Staged Rollout Plan"
            ],
        "rollback_detail":
            details[
                "Rollback Plan"
            ],
        "monitoring_detail":
            details[
                "Monitoring Plan"
            ],
        **confirmations,
        "permanent_change_design_permission":
            "PERMANENT_DESIGN_LOCKED_NO_APPLY",
        "permanent_change_design_authorization":
            "NONE",
        "permanent_change_apply_authorization":
            "NONE",
        "permanent_change_runtime_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _design_payload(
            base
        )
    )

    return {
        "permanent_change_design_id": (
            "PCD-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[
                :8
            ]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_permanent_change_design_queue(
    design: dict | None,
) -> pd.DataFrame:
    row = design or {}

    state = _text(
        row.get("design_state")
    ).upper()

    mapping = {
        "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT": (
            "PD2",
            "WAIT",
            "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT",
            "Human Permanent Adoption Closure ACCEPT가 아직 없음",
            "Live Change Outcome / Closure evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED": (
            "PD3",
            "MONITOR",
            "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
            "현재 Closure source에서는 Permanent Change Design이 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "PERMANENT_CHANGE_DESIGN_DEFERRED": (
            "PD2",
            "WAIT",
            "PERMANENT_CHANGE_DESIGN_DEFERRED",
            "Human Permanent Adoption Review가 DEFER 상태",
            "새 post-change evidence 또는 새 canary cycle까지 대기",
        ),
        "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED": (
            "PD1",
            "REVIEW",
            "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
            "ACCEPT 상태이지만 immutable Closure source가 없음",
            "Human Permanent Adoption Closure snapshot을 먼저 저장",
        ),
        "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW": (
            "PD0",
            "BLOCKED",
            "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "Closure source 또는 permanent design source integrity mismatch",
            "immutable source lineage를 먼저 복구",
        ),
        "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED": (
            "PD0",
            "REVIEW",
            "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED",
            "새 Closure source로 기존 Permanent Design이 stale",
            "현재 Closure source 기준으로 Permanent Design을 재작성",
        ),
        "PERMANENT_CHANGE_DESIGN_REQUIRED": (
            "PD1",
            "REVIEW",
            "PERMANENT_CHANGE_DESIGN_REQUIRED",
            (
                f"scope {row.get('proposal_scope','')} · "
                f"target {row.get('target_metric','')} · "
                f"permission {row.get('source_permanent_change_design_permission','NONE')}"
            ),
            "baseline/candidate/rollback/staged rollout/monitoring을 Human Review하고 design lock",
        ),
        "PERMANENT_CHANGE_DESIGN_LOCKED": (
            "PD3",
            "MONITOR",
            "PERMANENT_CHANGE_DESIGN_LOCKED",
            (
                f"target scope {float(row.get('target_scope_pct',0)):.1%} · "
                f"stage1 {float(row.get('initial_stage_scope_pct',0)):.1%} · "
                f"stages {int(row.get('rollout_stage_count',0))}"
            ),
            "별도 Permanent Change Apply Preflight 전에는 실제 permanent apply 금지",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "PD0",
            "BLOCKED",
            "PERMANENT_CHANGE_DESIGN_UNKNOWN_STATE",
            state or "MISSING",
            "Permanent Change Design state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            PERMANENT_CHANGE_DESIGN_QUEUE_COLS,
    )
