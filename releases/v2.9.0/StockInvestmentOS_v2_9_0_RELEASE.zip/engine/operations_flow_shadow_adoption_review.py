from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_shadow_validation_outcome import (
    shadow_validation_outcome_snapshot_integrity,
    latest_shadow_validation_outcome_snapshot,
)


FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS = [
    "shadow_adoption_review_id",
    "created_at",
    "adoption_state",
    "adoption_guard",
    "source_validation_outcome_id",
    "source_validation_outcome_hash",
    "source_validation_outcome_created_at",
    "source_validation_outcome_integrity",
    "source_plan_id",
    "source_plan_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "source_scorecard_snapshot_id",
    "source_scorecard_hash",
    "validation_state",
    "validation_guard",
    "proposal_scope",
    "target_metric",
    "eligible_outcomes",
    "relative_error_improvement_pct",
    "decision",
    "decision_detail",
    "validation_evidence_reviewed",
    "risk_reversal_reviewed",
    "controlled_trial_only_confirmed",
    "no_live_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "adoption_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


SHADOW_ADOPTION_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


SHADOW_ADOPTION_STATES = {
    "ADOPTION_UPSTREAM_WAIT",
    "ADOPTION_VALIDATION_FAILED",
    "ADOPTION_VALIDATION_INCONCLUSIVE",
    "ADOPTION_VALIDATION_AUDIT_REQUIRED",
    "ADOPTION_VALIDATION_INTEGRITY_REVIEW",
    "ADOPTION_SOURCE_SUPERSEDED",
    "ADOPTION_REVIEW_REQUIRED",
    "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
    "ADOPTION_REJECTED",
    "ADOPTION_DEFERRED",
}


ADOPTION_GUARD_BY_STATE = {
    "ADOPTION_UPSTREAM_WAIT": "HOLD_VALIDATION_RESULT",
    "ADOPTION_VALIDATION_FAILED": "NO_ADOPTION",
    "ADOPTION_VALIDATION_INCONCLUSIVE": "HOLD_ADOPTION_EVIDENCE",
    "ADOPTION_VALIDATION_AUDIT_REQUIRED": "HOLD_VALIDATION_AUDIT",
    "ADOPTION_VALIDATION_INTEGRITY_REVIEW": "HOLD_VALIDATION_INTEGRITY",
    "ADOPTION_SOURCE_SUPERSEDED": "HOLD_VALIDATION_AUDIT",
    "ADOPTION_REVIEW_REQUIRED": "HUMAN_ADOPTION_REVIEW_REQUIRED",
    "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL": "ACCEPTED_FOR_TRIAL_NO_APPLY",
    "ADOPTION_REJECTED": "ADOPTION_REJECTED_NO_APPLY",
    "ADOPTION_DEFERRED": "ADOPTION_DEFERRED_NO_APPLY",
}


ADOPTION_DECISIONS = {
    "ACCEPT_FOR_CONTROLLED_TRIAL",
    "REJECT",
    "DEFER",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _review_payload(row: dict) -> dict:
    int_fields = {
        "eligible_outcomes",
    }
    float_fields = {
        "relative_error_improvement_pct",
    }
    bool_fields = {
        "validation_evidence_reviewed",
        "risk_reversal_reviewed",
        "controlled_trial_only_confirmed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS:
        if col in {
            "shadow_adoption_review_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def shadow_adoption_review_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get(
            "snapshot_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _review_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_shadow_adoption_review_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _evaluation_matches_live(
    audit: dict,
    live: dict,
) -> bool:
    if not audit or not live:
        return False

    if _text(
        shadow_validation_outcome_snapshot_integrity(
            audit
        ).get("status")
    ).upper() != "OK":
        return False

    fields = [
        "validation_state",
        "validation_guard",
        "source_plan_id",
        "source_plan_hash",
        "source_proposal_id",
        "source_proposal_hash",
        "source_scorecard_snapshot_id",
        "source_scorecard_hash",
        "proposal_scope",
        "target_metric",
        "evidence_outcome_ids_json",
        "evidence_outcome_hashes_json",
    ]

    for field in fields:
        if _text(
            audit.get(field)
        ) != _text(
            live.get(field)
        ):
            return False

    if _int(
        audit.get(
            "eligible_outcomes"
        )
    ) != _int(
        live.get(
            "eligible_outcomes"
        )
    ):
        return False

    if abs(
        _float(
            audit.get(
                "relative_error_improvement_pct"
            )
        )
        - _float(
            live.get(
                "relative_error_improvement_pct"
            )
        )
    ) > 1e-8:
        return False

    return True


def _review_matches_evaluation(
    review: dict,
    evaluation_audit: dict,
) -> bool:
    if not review or not evaluation_audit:
        return False

    if _text(
        shadow_adoption_review_snapshot_integrity(
            review
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            review.get(
                "source_validation_outcome_id"
            )
        )
        == _text(
            evaluation_audit.get(
                "shadow_validation_outcome_id"
            )
        )
        and _text(
            review.get(
                "source_validation_outcome_hash"
            )
        )
        == _text(
            evaluation_audit.get(
                "snapshot_hash"
            )
        )
    )


def _locked_review_state(
    review: dict,
) -> str:
    decision = _text(
        review.get(
            "decision"
        )
    ).upper()

    if decision == "ACCEPT_FOR_CONTROLLED_TRIAL":
        return "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL"

    if decision == "REJECT":
        return "ADOPTION_REJECTED"

    if decision == "DEFER":
        return "ADOPTION_DEFERRED"

    return "ADOPTION_VALIDATION_INTEGRITY_REVIEW"


def build_flow_shadow_adoption_review(
    shadow_validation_outcome: dict | None,
    validation_outcome_snapshots: pd.DataFrame | None,
    adoption_review_snapshots: pd.DataFrame | None,
) -> dict:
    live = shadow_validation_outcome or {}

    live_state = _text(
        live.get(
            "validation_state"
        )
    ).upper()

    base = {
        "source_validation_outcome_id": "",
        "source_validation_outcome_hash": "",
        "source_validation_outcome_created_at": "",
        "source_validation_outcome_integrity": "NONE",
        "source_plan_id": _text(
            live.get(
                "source_plan_id"
            )
        ),
        "source_plan_hash": _text(
            live.get(
                "source_plan_hash"
            )
        ),
        "source_proposal_id": _text(
            live.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            live.get(
                "source_proposal_hash"
            )
        ),
        "source_scorecard_snapshot_id": _text(
            live.get(
                "source_scorecard_snapshot_id"
            )
        ),
        "source_scorecard_hash": _text(
            live.get(
                "source_scorecard_hash"
            )
        ),
        "validation_state": live_state,
        "validation_guard": _text(
            live.get(
                "validation_guard"
            )
        ).upper(),
        "proposal_scope": _text(
            live.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            live.get(
                "target_metric"
            )
        ).upper(),
        "eligible_outcomes": _int(
            live.get(
                "eligible_outcomes"
            )
        ),
        "relative_error_improvement_pct": _float(
            live.get(
                "relative_error_improvement_pct"
            )
        ),
        "decision": "",
        "decision_detail": "",
        "latest_review": {},
        "adoption_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if live_state in {
        "",
        "SHADOW_EVAL_UPSTREAM_WAIT",
        "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES",
        "SHADOW_EVAL_EVIDENCE_MATURING",
        "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED",
        "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
        "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
        "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW",
        "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW",
        "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW",
        "SHADOW_EVAL_BASELINE_DRIFT_REVIEW",
        "SHADOW_EVAL_NOT_REQUIRED",
    }:
        return {
            **base,
            "adoption_state": "ADOPTION_UPSTREAM_WAIT",
            "adoption_guard": "HOLD_VALIDATION_RESULT",
        }

    if live_state == "SHADOW_EVAL_FAIL":
        return {
            **base,
            "adoption_state": "ADOPTION_VALIDATION_FAILED",
            "adoption_guard": "NO_ADOPTION",
        }

    if live_state == "SHADOW_EVAL_INCONCLUSIVE":
        return {
            **base,
            "adoption_state": "ADOPTION_VALIDATION_INCONCLUSIVE",
            "adoption_guard": "HOLD_ADOPTION_EVIDENCE",
        }

    if live_state != "SHADOW_EVAL_PASS":
        return {
            **base,
            "adoption_state": "ADOPTION_UPSTREAM_WAIT",
            "adoption_guard": "HOLD_VALIDATION_RESULT",
        }

    eval_history = (
        pd.DataFrame()
        if validation_outcome_snapshots is None
        else validation_outcome_snapshots.copy()
    )

    latest_eval = latest_shadow_validation_outcome_snapshot(
        eval_history
    )

    if not latest_eval:
        return {
            **base,
            "adoption_state": "ADOPTION_VALIDATION_AUDIT_REQUIRED",
            "adoption_guard": "HOLD_VALIDATION_AUDIT",
        }

    eval_integrity = _text(
        shadow_validation_outcome_snapshot_integrity(
            latest_eval
        ).get("status")
    ).upper()

    base.update(
        {
            "source_validation_outcome_id":
                _text(
                    latest_eval.get(
                        "shadow_validation_outcome_id"
                    )
                ),
            "source_validation_outcome_hash":
                _text(
                    latest_eval.get(
                        "snapshot_hash"
                    )
                ),
            "source_validation_outcome_created_at":
                _text(
                    latest_eval.get(
                        "created_at"
                    )
                ),
            "source_validation_outcome_integrity":
                eval_integrity,
        }
    )

    if eval_integrity != "OK":
        return {
            **base,
            "adoption_state": "ADOPTION_VALIDATION_INTEGRITY_REVIEW",
            "adoption_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    if not _evaluation_matches_live(
        latest_eval,
        live,
    ):
        return {
            **base,
            "adoption_state": "ADOPTION_SOURCE_SUPERSEDED",
            "adoption_guard": "HOLD_VALIDATION_AUDIT",
        }

    review_history = (
        pd.DataFrame()
        if adoption_review_snapshots is None
        else adoption_review_snapshots.copy()
    )

    latest_review = latest_shadow_adoption_review_snapshot(
        review_history
    )

    if not latest_review:
        return {
            **base,
            "adoption_state": "ADOPTION_REVIEW_REQUIRED",
            "adoption_guard": "HUMAN_ADOPTION_REVIEW_REQUIRED",
        }

    review_integrity = _text(
        shadow_adoption_review_snapshot_integrity(
            latest_review
        ).get("status")
    ).upper()

    if review_integrity != "OK":
        return {
            **base,
            "latest_review": latest_review,
            "adoption_state": "ADOPTION_VALIDATION_INTEGRITY_REVIEW",
            "adoption_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    if not _review_matches_evaluation(
        latest_review,
        latest_eval,
    ):
        return {
            **base,
            "latest_review": latest_review,
            "adoption_state": "ADOPTION_SOURCE_SUPERSEDED",
            "adoption_guard": "HOLD_VALIDATION_AUDIT",
        }

    locked_state = _locked_review_state(
        latest_review
    )

    return {
        **base,
        "latest_review": latest_review,
        "decision": _text(
            latest_review.get(
                "decision"
            )
        ).upper(),
        "decision_detail": _text(
            latest_review.get(
                "decision_detail"
            )
        ),
        "adoption_state": locked_state,
        "adoption_guard": ADOPTION_GUARD_BY_STATE.get(
            locked_state,
            "HOLD_VALIDATION_INTEGRITY",
        ),
    }


def build_flow_shadow_adoption_review_lock(
    review: dict,
    *,
    decision: str,
    decision_detail: str,
    validation_evidence_reviewed: bool,
    risk_reversal_reviewed: bool,
    controlled_trial_only_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = review or {}

    if _text(
        current.get(
            "adoption_state"
        )
    ).upper() != "ADOPTION_REVIEW_REQUIRED":
        raise ValueError(
            "Shadow Adoption Review는 ADOPTION_REVIEW_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_validation_outcome_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Shadow Validation Outcome integrity가 OK가 아닙니다."
        )

    decision_value = _text(
        decision
    ).upper()

    if decision_value not in ADOPTION_DECISIONS:
        raise ValueError(
            "Adoption decision은 ACCEPT_FOR_CONTROLLED_TRIAL / REJECT / DEFER 중 하나여야 합니다."
        )

    detail = _text(
        decision_detail
    )

    if len(
        detail
    ) < 30:
        raise ValueError(
            "Adoption decision rationale을 30자 이상 기록하세요."
        )

    confirmations = {
        "validation_evidence_reviewed":
            bool(
                validation_evidence_reviewed
            ),
        "risk_reversal_reviewed":
            bool(
                risk_reversal_reviewed
            ),
        "controlled_trial_only_confirmed":
            bool(
                controlled_trial_only_confirmed
            ),
        "no_live_apply_confirmed":
            bool(
                no_live_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    required_common = [
        "validation_evidence_reviewed",
        "risk_reversal_reviewed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        confirmations[
            field
        ]
        for field in required_common
    ):
        raise ValueError(
            "Shadow Adoption Human Review 확인사항을 모두 검토해야 합니다."
        )

    if (
        decision_value
        == "ACCEPT_FOR_CONTROLLED_TRIAL"
        and not confirmations[
            "controlled_trial_only_confirmed"
        ]
    ):
        raise ValueError(
            "ACCEPT 결정은 controlled-trial-only 확인이 필요합니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    source_created = pd.to_datetime(
        current.get(
            "source_validation_outcome_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    review_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            source_created
        )
        or pd.isna(
            review_created
        )
        or review_created <= source_created
    ):
        raise ValueError(
            "Adoption Review는 source Validation Outcome audit 이후에 저장되어야 합니다."
        )

    if decision_value == "ACCEPT_FOR_CONTROLLED_TRIAL":
        state = "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL"
    elif decision_value == "REJECT":
        state = "ADOPTION_REJECTED"
    else:
        state = "ADOPTION_DEFERRED"

    base = {
        "adoption_state":
            state,
        "adoption_guard":
            ADOPTION_GUARD_BY_STATE[
                state
            ],
        "source_validation_outcome_id":
            _text(
                current.get(
                    "source_validation_outcome_id"
                )
            ),
        "source_validation_outcome_hash":
            _text(
                current.get(
                    "source_validation_outcome_hash"
                )
            ),
        "source_validation_outcome_created_at":
            _text(
                current.get(
                    "source_validation_outcome_created_at"
                )
            ),
        "source_validation_outcome_integrity":
            "OK",
        "source_plan_id":
            _text(
                current.get(
                    "source_plan_id"
                )
            ),
        "source_plan_hash":
            _text(
                current.get(
                    "source_plan_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "source_scorecard_snapshot_id":
            _text(
                current.get(
                    "source_scorecard_snapshot_id"
                )
            ),
        "source_scorecard_hash":
            _text(
                current.get(
                    "source_scorecard_hash"
                )
            ),
        "validation_state":
            "SHADOW_EVAL_PASS",
        "validation_guard":
            "SHADOW_VALIDATION_PASS_NO_APPLY",
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "eligible_outcomes":
            _int(
                current.get(
                    "eligible_outcomes"
                )
            ),
        "relative_error_improvement_pct":
            _float(
                current.get(
                    "relative_error_improvement_pct"
                )
            ),
        "decision":
            decision_value,
        "decision_detail":
            detail,
        **confirmations,
        "adoption_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _review_payload(
            base
        )
    )

    return {
        "shadow_adoption_review_id": (
            "OAR-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_shadow_adoption_queue(
    review: dict | None,
) -> pd.DataFrame:
    row = review or {}
    state = _text(
        row.get(
            "adoption_state"
        )
    ).upper()

    mapping = {
        "ADOPTION_UPSTREAM_WAIT": (
            "SA2",
            "WAIT",
            "ADOPTION_UPSTREAM_WAIT",
            "Shadow Validation PASS audit이 아직 없음",
            "Plan 이후 prospective OOS evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "ADOPTION_VALIDATION_FAILED": (
            "SA3",
            "MONITOR",
            "ADOPTION_VALIDATION_FAILED",
            "Shadow Validation FAIL",
            "live apply 없이 Proposal 폐기/재검토",
        ),
        "ADOPTION_VALIDATION_INCONCLUSIVE": (
            "SA2",
            "REVIEW",
            "ADOPTION_VALIDATION_INCONCLUSIVE",
            "Shadow Validation 결과가 preregistered 기준 사이",
            "기준을 사후 변경하지 말고 새 Plan cycle 또는 추가 evidence 검토",
        ),
        "ADOPTION_VALIDATION_AUDIT_REQUIRED": (
            "SA1",
            "REVIEW",
            "ADOPTION_VALIDATION_AUDIT_REQUIRED",
            "live SHADOW_EVAL_PASS는 있으나 immutable PASS audit이 없음",
            "Shadow Validation Outcome Snapshot을 먼저 저장",
        ),
        "ADOPTION_VALIDATION_INTEGRITY_REVIEW": (
            "SA0",
            "BLOCKED",
            "ADOPTION_VALIDATION_INTEGRITY_REVIEW",
            "Validation 또는 Adoption audit integrity mismatch",
            "immutable audit integrity를 먼저 복구",
        ),
        "ADOPTION_SOURCE_SUPERSEDED": (
            "SA0",
            "REVIEW",
            "ADOPTION_SOURCE_SUPERSEDED",
            "새 Validation PASS source로 기존 Adoption Review가 stale",
            "현재 PASS audit 기준으로 Human Adoption Review 재수행",
        ),
        "ADOPTION_REVIEW_REQUIRED": (
            "SA1",
            "REVIEW",
            "ADOPTION_REVIEW_REQUIRED",
            (
                f"PASS improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%} · "
                f"eligible {row.get('eligible_outcomes',0)}"
            ),
            "PASS evidence를 Human Review하고 ACCEPT/REJECT/DEFER 결정",
        ),
        "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL": (
            "SA3",
            "MONITOR",
            "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
            "Human decision = ACCEPT_FOR_CONTROLLED_TRIAL",
            "live apply 금지; 별도 controlled trial design gate 필요",
        ),
        "ADOPTION_REJECTED": (
            "SA3",
            "MONITOR",
            "ADOPTION_REJECTED",
            "Human decision = REJECT",
            "Proposal 폐기/재검토; live apply 없음",
        ),
        "ADOPTION_DEFERRED": (
            "SA2",
            "MONITOR",
            "ADOPTION_DEFERRED",
            "Human decision = DEFER",
            "새 evidence 또는 새 proposal cycle까지 대기",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "SA0",
            "BLOCKED",
            "ADOPTION_UNKNOWN_STATE",
            state or "MISSING",
            "Shadow Adoption state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            SHADOW_ADOPTION_QUEUE_COLS,
    )
