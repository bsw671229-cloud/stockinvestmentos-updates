from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_live_change_design import (
    FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    live_change_design_snapshot_integrity,
)
from engine.operations_flow_live_change_apply import (
    FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    LIVE_CHANGE_APPLY_STATES,
    LIVE_CHANGE_APPLY_GUARD_BY_STATE,
    LIVE_CHANGE_APPLY_DECISIONS,
    build_flow_live_change_apply,
    live_change_apply_snapshot_integrity,
    latest_live_change_apply_snapshot,
)


LIVE_CHANGE_APPLY_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

LIVE_CHANGE_APPLY_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V147_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0
    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))
        if not item_id:
            continue
        if item_id in index:
            duplicates += 1
        index[item_id] = item

    return index, duplicates


def build_v147_live_change_apply_context(
    *,
    v146_context: dict | None,
    live_change_apply_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v146_context or {}
    design = upstream.get("design") or {}

    apply_df = _ensure_cols(
        live_change_apply_snapshots,
        FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    design_df = _ensure_cols(
        upstream.get("live_change_design_snapshots"),
        FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    apply = build_flow_live_change_apply(
        design,
        apply_df,
    )

    latest_apply = latest_live_change_apply_snapshot(
        apply_df
    )

    latest_integrity = (
        _text(
            live_change_apply_snapshot_integrity(
                latest_apply
            ).get("status")
        ).upper()
        if latest_apply
        else "NONE"
    )

    return {
        "v146_context": upstream,
        "design": design,
        "live_change_design_snapshots": design_df,
        "live_change_apply_snapshots": apply_df,
        "apply": apply,
        "apply_integrity": _integrity_counts(
            apply_df,
            live_change_apply_snapshot_integrity,
        ),
        "latest_apply": latest_apply,
        "latest_apply_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _design_routing_ok(
    apply: dict,
    design: dict,
) -> bool:
    apply_state = _text(
        apply.get("apply_state")
    ).upper()
    design_state = _text(
        design.get("design_state")
    ).upper()

    if design_state == "LIVE_CHANGE_DESIGN_LOCKED":
        return apply_state in {
            "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
            "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
            "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED",
            "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
            "LIVE_CHANGE_APPLY_REJECTED",
            "LIVE_CHANGE_APPLY_DEFERRED",
        }

    if design_state == "LIVE_CHANGE_DESIGN_NOT_REQUIRED":
        return apply_state == "LIVE_CHANGE_APPLY_NOT_REQUIRED"

    if design_state == "LIVE_CHANGE_DESIGN_DEFERRED":
        return apply_state == "LIVE_CHANGE_APPLY_DEFERRED"

    return apply_state == "LIVE_CHANGE_APPLY_UPSTREAM_WAIT"


def _design_source_mapping_ok(
    context: dict,
) -> bool:
    apply = context.get("apply") or {}
    state = _text(
        apply.get("apply_state")
    ).upper()

    if state in {
        "LIVE_CHANGE_APPLY_UPSTREAM_WAIT",
        "LIVE_CHANGE_APPLY_NOT_REQUIRED",
        "LIVE_CHANGE_APPLY_DEFERRED",
    }:
        return True

    source_id = _text(
        apply.get("source_live_change_design_id")
    )
    source_hash = _text(
        apply.get("source_live_change_design_hash")
    )

    if not source_id or not source_hash:
        return state in {
            "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
            "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
        }

    index, duplicates = _index_by_id(
        context.get("live_change_design_snapshots"),
        "live_change_design_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(source_id)

    return (
        bool(parent)
        and _text(
            live_change_design_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(parent.get("snapshot_hash")) == source_hash
        and _text(parent.get("design_state")).upper()
        == "LIVE_CHANGE_DESIGN_LOCKED"
        and _text(
            parent.get("live_change_design_permission")
        ).upper()
        == "DESIGN_LOCKED_NO_APPLY"
    )


def _permit_contract_ok(
    apply: dict,
) -> bool:
    state = _text(
        apply.get("apply_state")
    ).upper()

    if state not in {
        "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
        "LIVE_CHANGE_APPLY_REJECTED",
        "LIVE_CHANGE_APPLY_DEFERRED",
    }:
        return True

    row = apply.get("latest_apply") or {}

    if not row:
        return False

    if _text(
        live_change_apply_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    decision = _text(
        row.get("apply_decision")
    ).upper()

    expected_state = {
        "ISSUE_MANUAL_CANARY_APPLY_PERMIT":
            "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
        "REJECT":
            "LIVE_CHANGE_APPLY_REJECTED",
        "DEFER":
            "LIVE_CHANGE_APPLY_DEFERRED",
    }.get(decision)

    if decision not in LIVE_CHANGE_APPLY_DECISIONS:
        return False

    if expected_state != state:
        return False

    if len(
        _text(row.get("apply_detail"))
    ) < 50:
        return False

    required = [
        "design_source_reviewed",
        "baseline_revalidated_confirmed",
        "candidate_artifact_verified",
        "canary_isolation_rechecked",
        "change_window_reviewed",
        "rollback_ready_confirmed",
        "manual_apply_only_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(row.get(field))
        for field in required
    ):
        return False

    if decision == "ISSUE_MANUAL_CANARY_APPLY_PERMIT":
        scope = _float(
            row.get("permit_scope_pct")
        )
        sessions = _int(
            row.get("permit_session_budget")
        )
        design_scope = _float(
            row.get("design_max_scope_pct")
        )
        design_sessions = _int(
            row.get("design_max_sessions")
        )

        return (
            _text(
                row.get("live_change_apply_permission")
            ).upper()
            == "MANUAL_CANARY_APPLY_ONLY"
            and 0.01 <= scope <= min(0.05, design_scope)
            and 1 <= sessions <= design_sessions
            and _int(
                row.get("permit_min_post_change_outcomes")
            )
            == _int(
                row.get("design_min_post_change_outcomes")
            )
            and abs(
                _float(
                    row.get(
                        "permit_max_relative_error_degradation_pct"
                    )
                )
                - _float(
                    row.get(
                        "design_max_relative_error_degradation_pct"
                    )
                )
            )
            <= 1e-12
        )

    return (
        _text(
            row.get("live_change_apply_permission")
        ).upper()
        in {"", "NONE"}
        and _float(
            row.get("permit_scope_pct")
        )
        == 0.0
        and _int(
            row.get("permit_session_budget")
        )
        == 0
    )


def _baseline_candidate_rollback_ok(
    apply: dict,
) -> bool:
    state = _text(
        apply.get("apply_state")
    ).upper()

    if state not in {
        "LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
        "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
        "LIVE_CHANGE_APPLY_REJECTED",
        "LIVE_CHANGE_APPLY_DEFERRED",
    }:
        return True

    baseline = _float(
        apply.get("baseline_value")
    )
    candidate = _float(
        apply.get("candidate_value")
    )
    rollback = _float(
        apply.get("rollback_target_value")
    )

    if abs(
        rollback - baseline
    ) > 1e-12:
        return False

    proposal_scope = _text(
        apply.get("proposal_scope")
    ).upper()

    if proposal_scope == "PARAMETER_SHADOW":
        return abs(
            candidate - baseline
        ) > 1e-12

    if proposal_scope == "MODEL_SHADOW":
        return len(
            _text(
                apply.get("artifact_ref")
            )
        ) >= 10

    return proposal_scope in {
        "",
        "PARAMETER_SHADOW",
        "MODEL_SHADOW",
    }


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    apply = context.get("apply") or {}
    state = _text(
        apply.get("apply_state")
    ).upper()
    latest = context.get("latest_apply") or {}

    if state in {
        "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
        "LIVE_CHANGE_APPLY_REJECTED",
        "LIVE_CHANGE_APPLY_DEFERRED",
    }:
        source_ts = pd.to_datetime(
            apply.get("source_live_change_design_created_at"),
            errors="coerce",
            utc=True,
        )
        apply_ts = pd.to_datetime(
            latest.get("created_at"),
            errors="coerce",
            utc=True,
        )

        return (
            not pd.isna(source_ts)
            and not pd.isna(apply_ts)
            and apply_ts > source_ts
        )

    if state == "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(
                latest.get("source_live_change_design_id")
            )
            != _text(
                apply.get("source_live_change_design_id")
            )
            or _text(
                latest.get("source_live_change_design_hash")
            )
            != _text(
                apply.get("source_live_change_design_hash")
            )
        )

    return True


def _no_live_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("apply") or {},
        context.get("latest_apply") or {},
        context.get("design") or {},
    ]:
        for field in [
            "live_change_apply_authorization",
            "live_change_runtime_authorization",
            "live_change_design_authorization",
            "trial_closure_authorization",
            "live_change_review_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(item.get(field)).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "live_change_apply_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "live_change_apply_authorization",
            "live_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v147_live_change_apply_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    apply = ctx.get("apply") or {}
    design = ctx.get("design") or {}
    counts = ctx.get("apply_integrity") or {}

    state = _text(
        apply.get("apply_state")
    ).upper()
    guard = _text(
        apply.get("apply_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Live Change Apply Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Apply immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Apply State / Guard Vocabulary",
            (
                state in LIVE_CHANGE_APPLY_STATES
                and guard
                == LIVE_CHANGE_APPLY_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {LIVE_CHANGE_APPLY_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Live Change Apply state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Design → Apply State Invariant",
            _design_routing_ok(
                apply,
                design,
            ),
            (
                f"design {_text(design.get('design_state')) or 'MISSING'} · "
                f"apply {state or 'MISSING'}"
            ),
            "Live Change Design LOCK/WAIT/NOT_REQUIRED/DEFER와 Apply state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Apply → Immutable Design Source Mapping",
            _design_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"design {_text(apply.get('source_live_change_design_id')) or 'NONE'} · "
                f"integrity {_text(apply.get('source_live_change_design_integrity')) or 'NONE'}"
            ),
            "Apply source Design id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Apply Baseline / Candidate / Rollback Invariant",
            _baseline_candidate_rollback_ok(
                apply
            ),
            (
                f"state {state or 'MISSING'} · "
                f"baseline {_float(apply.get('baseline_value')):.4f} · "
                f"candidate {_float(apply.get('candidate_value')):.4f} · "
                f"rollback {_float(apply.get('rollback_target_value')):.4f}"
            ),
            "Baseline freshness, candidate artifact, rollback target 일치 확인",
        )
    )

    checks.append(
        _technical_row(
            "Manual Canary Permit / Human Preflight Contract Invariant",
            _permit_contract_ok(
                apply
            ),
            (
                f"state {state or 'MISSING'} · "
                f"decision {_text(apply.get('apply_decision')) or 'NONE'} · "
                f"scope {_float(apply.get('permit_scope_pct')):.1%} · "
                f"sessions {_int(apply.get('permit_session_budget'))}"
            ),
            "Permit hard bounds와 Human preflight confirmations 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Apply Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"design created {_text(apply.get('source_live_change_design_created_at')) or 'NONE'} · "
                f"latest apply {_text((ctx.get('latest_apply') or {}).get('live_change_apply_id')) or 'NONE'}"
            ),
            "Apply Review 저장 순서와 새 Design source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Apply No-Auto-Apply Authorization Invariant",
            _no_live_authorization_ok(
                ctx
            ),
            "NONE",
            "Apply/Runtime/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "LIVE_CHANGE_APPLY_NOT_REQUIRED",
            "LIVE_CHANGE_APPLY_DEFERRED",
            "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
            "LIVE_CHANGE_APPLY_REJECTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Apply Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"decision {_text(apply.get('apply_decision')) or 'NONE'} · "
                f"permission {_text(apply.get('live_change_apply_permission')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 design/apply wait는 Technical FAIL로 승격하지 않고 "
                    "Human preflight 및 immutable source evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "apply_state": state,
        "design_state": _text(
            design.get("design_state")
        ).upper(),
        "latest_live_change_apply_integrity":
            _text(
                ctx.get("latest_apply_integrity")
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_APPLY_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_apply_contract_ok(
    item: dict,
) -> bool:
    decision = _text(
        item.get("apply_decision")
    ).upper()
    state = _text(
        item.get("apply_state")
    ).upper()
    guard = _text(
        item.get("apply_guard")
    ).upper()

    expected_state = {
        "ISSUE_MANUAL_CANARY_APPLY_PERMIT":
            "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
        "REJECT":
            "LIVE_CHANGE_APPLY_REJECTED",
        "DEFER":
            "LIVE_CHANGE_APPLY_DEFERRED",
    }.get(decision)

    if (
        decision not in LIVE_CHANGE_APPLY_DECISIONS
        or state != expected_state
        or guard
        != LIVE_CHANGE_APPLY_GUARD_BY_STATE.get(
            state,
            "",
        )
        or len(
            _text(
                item.get("apply_detail")
            )
        ) < 50
    ):
        return False

    required = [
        "design_source_reviewed",
        "baseline_revalidated_confirmed",
        "candidate_artifact_verified",
        "canary_isolation_rechecked",
        "change_window_reviewed",
        "rollback_ready_confirmed",
        "manual_apply_only_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(item.get(field))
        for field in required
    ):
        return False

    baseline = _float(
        item.get("baseline_value")
    )
    rollback = _float(
        item.get("rollback_target_value")
    )

    if abs(rollback - baseline) > 1e-12:
        return False

    if decision == "ISSUE_MANUAL_CANARY_APPLY_PERMIT":
        scope = _float(
            item.get("permit_scope_pct")
        )
        sessions = _int(
            item.get("permit_session_budget")
        )
        return (
            _text(
                item.get("live_change_apply_permission")
            ).upper()
            == "MANUAL_CANARY_APPLY_ONLY"
            and 0.01
            <= scope
            <= min(
                0.05,
                _float(
                    item.get("design_max_scope_pct")
                ),
            )
            and 1
            <= sessions
            <= _int(
                item.get("design_max_sessions")
            )
            and _int(
                item.get("permit_min_post_change_outcomes")
            )
            == _int(
                item.get("design_min_post_change_outcomes")
            )
            and abs(
                _float(
                    item.get(
                        "permit_max_relative_error_degradation_pct"
                    )
                )
                - _float(
                    item.get(
                        "design_max_relative_error_degradation_pct"
                    )
                )
            )
            <= 1e-12
        )

    return (
        _text(
            item.get("live_change_apply_permission")
        ).upper()
        in {"", "NONE"}
        and _float(
            item.get("permit_scope_pct")
        )
        == 0.0
        and _int(
            item.get("permit_session_budget")
        )
        == 0
    )


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v147_live_change_apply_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    apply_df = _ensure_cols(
        ctx.get(
            "live_change_apply_snapshots"
        ),
        FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    design_df = _ensure_cols(
        ctx.get(
            "live_change_design_snapshots"
        ),
        FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        apply_df,
        live_change_apply_snapshot_integrity,
    )

    design_index, design_duplicates = _index_by_id(
        design_df,
        "live_change_design_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in apply_df.iterrows():
        item = row.to_dict()

        apply_id = _text(
            item.get("live_change_apply_id")
        )

        if apply_id:
            if apply_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(apply_id)

        if not _saved_apply_contract_ok(item):
            contract_violations += 1

        design_id = _text(
            item.get("source_live_change_design_id")
        )
        design_hash = _text(
            item.get("source_live_change_design_hash")
        )
        parent = design_index.get(design_id)

        if (
            not parent
            or _text(
                live_change_design_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(parent.get("snapshot_hash"))
            != design_hash
            or _text(
                parent.get("design_state")
            ).upper()
            != "LIVE_CHANGE_DESIGN_LOCKED"
            or _text(
                parent.get(
                    "live_change_design_permission"
                )
            ).upper()
            != "DESIGN_LOCKED_NO_APPLY"
        ):
            lineage_violations += 1
        else:
            design_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )
            apply_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(design_ts)
                or pd.isna(apply_ts)
                or apply_ts <= design_ts
            ):
                time_order_violations += 1

        for field in [
            "live_change_apply_authorization",
            "live_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Live Change Apply Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Apply immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Apply Audit Human Preflight / Permit Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "Apply decision, baseline preflight, canary permit bound, confirmations 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Apply Audit → Locked Design Lineage",
            (
                lineage_violations == 0
                and design_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"design duplicate ids {design_duplicates}"
            ),
            "Apply source locked Live Change Design id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Apply Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate apply ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Apply audit identity uniqueness 및 Design audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Apply Audit No-Auto-Apply Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("apply") or {}).get(
            "apply_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "LIVE_CHANGE_APPLY_NOT_REQUIRED",
            "LIVE_CHANGE_APPLY_DEFERRED",
            "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
            "LIVE_CHANGE_APPLY_REJECTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Apply Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current apply {current_state or 'MISSING'} · "
                f"saved reviews {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 locked Live Change Design 이후 baseline/candidate/rollback preflight가 필요할 때만 "
                    "Apply audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_APPLY_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v147_release_readiness(
    *,
    v146_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    live_change_apply_release_gate: str,
    live_change_apply_audit_gate: str,
    live_change_apply_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.46 Live Change Design Release Baseline",
            _text(
                v146_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v146_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Live Change Apply Technical Release Gate",
            _text(
                live_change_apply_release_gate
            ).upper()
            == "PASS",
            _text(
                live_change_apply_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Apply Audit Integrity Gate",
            _text(
                live_change_apply_audit_gate
            ).upper()
            == "PASS",
            _text(
                live_change_apply_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            live_change_apply_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "LIVE_CHANGE_APPLY_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V147_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v147_integration_crosscheck(
    *,
    integration_consistency: str,
    live_change_apply_release_gate: str,
    live_change_apply_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Apply Technical Gate",
            _text(
                live_change_apply_release_gate
            ).upper()
            == "PASS",
            _text(
                live_change_apply_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Apply Audit Gate",
            _text(
                live_change_apply_audit_gate
            ).upper()
            == "PASS",
            _text(
                live_change_apply_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V147_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v147_data_crosscheck(
    *,
    csv_fail_count: int,
    live_change_apply_release_gate: str,
    live_change_apply_audit_gate: str,
    latest_live_change_apply_integrity: str,
) -> dict:
    latest = _text(
        latest_live_change_apply_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Live Change Apply Technical Gate",
            _text(
                live_change_apply_release_gate
            ).upper()
            == "PASS",
            _text(
                live_change_apply_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Apply Audit Gate",
            _text(
                live_change_apply_audit_gate
            ).upper()
            == "PASS",
            _text(
                live_change_apply_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Live Change Apply Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V147_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
