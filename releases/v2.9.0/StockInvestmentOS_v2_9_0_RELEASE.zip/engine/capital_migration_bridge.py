from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


MIGRATION_BRIDGE_REVIEW_COLS = [
    "reviewed_at",
    "donor",
    "recipient",
    "donor_kind",
    "recipient_kind",
    "donor_health",
    "recipient_health",
    "donor_input_status",
    "recipient_input_status",
    "donor_forward_er",
    "donor_risk_penalty",
    "donor_risk_adjusted_er",
    "recipient_forward_er",
    "recipient_risk_penalty",
    "recipient_risk_adjusted_er",
    "signed_risk_penalty_delta",
    "mapped_incremental_risk_penalty",
    "tax_cost",
    "trading_cost",
    "cp_net_switching_gap_reference",
    "migration_donor_forward_er",
    "migration_recipient_forward_er",
    "migration_incremental_risk_penalty",
    "migration_net_switching_gap",
    "donor_er_delta",
    "recipient_er_delta",
    "risk_penalty_delta",
    "net_gap_delta",
    "mapping_gate",
    "reconciliation_gate",
    "assumption_snapshot_hash",
    "execution_authorization",
    "issues",
    "note",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _stable_num(value: Any, places: int = 12) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _hash(payload: dict) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _row_lookup(
    df: pd.DataFrame | None,
    name: str,
) -> dict:
    if df is None or df.empty:
        return {}
    if "name" not in df.columns:
        return {}
    hit = df.loc[
        df["name"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(_text(name))
    ]
    if hit.empty:
        return {}
    return hit.iloc[-1].to_dict()


def build_migration_assumption_bridge(
    universe: pd.DataFrame | None,
    health: pd.DataFrame | None,
    donor_name: str,
    recipient_name: str,
) -> dict:
    """
    Bridge approved Capital Productivity assumptions into Capital Migration.

    Capital Productivity compares:
        Recipient risk-adjusted ER - Donor risk-adjusted ER

    Capital Migration currently has:
        Recipient Forward ER - Donor Forward ER - Incremental Risk Penalty

    Therefore an exact bridge is possible only when:
        Incremental Risk Penalty
        = Recipient Risk Penalty - Donor Risk Penalty
        >= 0

    If that signed delta is negative, the existing Migration input cannot
    represent the same economics exactly and the bridge remains REVIEW.
    """
    donor = _row_lookup(
        universe,
        donor_name,
    )
    recipient = _row_lookup(
        universe,
        recipient_name,
    )
    donor_health_row = _row_lookup(
        health,
        donor_name,
    )
    recipient_health_row = _row_lookup(
        health,
        recipient_name,
    )

    issues = []

    if not donor:
        issues.append(
            "DONOR_ASSUMPTION_NOT_FOUND"
        )
    if not recipient:
        issues.append(
            "RECIPIENT_ASSUMPTION_NOT_FOUND"
        )

    donor_health = _text(
        donor_health_row.get(
            "health_status"
        )
    ).upper()
    recipient_health = _text(
        recipient_health_row.get(
            "health_status"
        )
    ).upper()

    donor_input_status = _text(
        donor.get(
            "input_status"
        )
    ).upper()
    recipient_input_status = _text(
        recipient.get(
            "input_status"
        )
    ).upper()

    if donor and donor_input_status != "READY":
        issues.append(
            "DONOR_ASSUMPTION_NOT_READY"
        )
    if recipient and recipient_input_status != "READY":
        issues.append(
            "RECIPIENT_ASSUMPTION_NOT_READY"
        )

    if donor and donor_health != "PASS":
        issues.append(
            "DONOR_ASSUMPTION_HEALTH_NOT_PASS"
        )
    if recipient and recipient_health != "PASS":
        issues.append(
            "RECIPIENT_ASSUMPTION_HEALTH_NOT_PASS"
        )

    if (
        _text(donor_name)
        and _text(donor_name)
        == _text(recipient_name)
    ):
        issues.append(
            "DONOR_RECIPIENT_SAME_ASSET"
        )

    donor_er = _num(
        donor.get("forward_er")
    )
    donor_risk = _num(
        donor.get("risk_penalty")
    )
    donor_ra = _num(
        donor.get(
            "risk_adjusted_er"
        )
    )

    recipient_er = _num(
        recipient.get("forward_er")
    )
    recipient_risk = _num(
        recipient.get("risk_penalty")
    )
    recipient_ra = _num(
        recipient.get(
            "risk_adjusted_er"
        )
    )

    required = {
        "DONOR_FORWARD_ER_REQUIRED":
            donor_er,
        "DONOR_RISK_PENALTY_REQUIRED":
            donor_risk,
        "DONOR_RISK_ADJUSTED_ER_REQUIRED":
            donor_ra,
        "RECIPIENT_FORWARD_ER_REQUIRED":
            recipient_er,
        "RECIPIENT_RISK_PENALTY_REQUIRED":
            recipient_risk,
        "RECIPIENT_RISK_ADJUSTED_ER_REQUIRED":
            recipient_ra,
    }
    for issue, value in required.items():
        if value is None:
            issues.append(issue)

    signed_delta = None
    mapped_incremental = None

    if (
        donor_risk is not None
        and recipient_risk is not None
    ):
        signed_delta = (
            recipient_risk
            - donor_risk
        )

        if signed_delta < -1e-12:
            issues.append(
                "SIGNED_RISK_DELTA_NOT_REPRESENTABLE"
            )
        else:
            mapped_incremental = max(
                0.0,
                signed_delta,
            )

    payload = {
        "donor": _text(
            donor_name
        ),
        "recipient": _text(
            recipient_name
        ),
        "donor_forward_er":
            _stable_num(
                donor_er
            ),
        "donor_risk_penalty":
            _stable_num(
                donor_risk
            ),
        "donor_risk_adjusted_er":
            _stable_num(
                donor_ra
            ),
        "recipient_forward_er":
            _stable_num(
                recipient_er
            ),
        "recipient_risk_penalty":
            _stable_num(
                recipient_risk
            ),
        "recipient_risk_adjusted_er":
            _stable_num(
                recipient_ra
            ),
        "donor_health":
            donor_health,
        "recipient_health":
            recipient_health,
        "donor_input_status":
            donor_input_status,
        "recipient_input_status":
            recipient_input_status,
        "donor_approved_calibration_id":
            _text(
                donor_health_row.get(
                    "approved_calibration_id"
                )
            ),
        "recipient_approved_calibration_id":
            _text(
                recipient_health_row.get(
                    "approved_calibration_id"
                )
            ),
        "donor_revalidation_id":
            _text(
                donor_health_row.get(
                    "latest_revalidation_id"
                )
            ),
        "recipient_revalidation_id":
            _text(
                recipient_health_row.get(
                    "latest_revalidation_id"
                )
            ),
    }

    return {
        "donor":
            _text(donor_name),
        "recipient":
            _text(recipient_name),
        "donor_kind":
            _text(
                donor.get("kind")
            ).upper(),
        "recipient_kind":
            _text(
                recipient.get("kind")
            ).upper(),
        "donor_health":
            donor_health,
        "recipient_health":
            recipient_health,
        "donor_input_status":
            donor_input_status,
        "recipient_input_status":
            recipient_input_status,
        "donor_forward_er":
            donor_er,
        "donor_risk_penalty":
            donor_risk,
        "donor_risk_adjusted_er":
            donor_ra,
        "recipient_forward_er":
            recipient_er,
        "recipient_risk_penalty":
            recipient_risk,
        "recipient_risk_adjusted_er":
            recipient_ra,
        "signed_risk_penalty_delta":
            signed_delta,
        "mapped_incremental_risk_penalty":
            mapped_incremental,
        "mapping_gate":
            "PASS"
            if not issues
            else "REVIEW",
        "assumption_snapshot_hash":
            _hash(payload),
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def migration_bridge_reference(
    bridge: dict,
    *,
    tax_cost: float,
    trading_cost: float,
) -> dict:
    donor_ra = _num(
        bridge.get(
            "donor_risk_adjusted_er"
        )
    )
    recipient_ra = _num(
        bridge.get(
            "recipient_risk_adjusted_er"
        )
    )
    tax = max(
        0.0,
        float(
            tax_cost
            or 0.0
        ),
    )
    trading = max(
        0.0,
        float(
            trading_cost
            or 0.0
        ),
    )

    cp_gap = None
    if (
        donor_ra is not None
        and recipient_ra is not None
    ):
        cp_gap = (
            recipient_ra
            - donor_ra
            - tax
            - trading
        )

    return {
        "tax_cost":
            tax,
        "trading_cost":
            trading,
        "cp_net_switching_gap_reference":
            cp_gap,
    }


def reconcile_migration_assumption_bridge(
    bridge: dict,
    *,
    donor_forward_er: float,
    recipient_forward_er: float,
    incremental_risk_penalty: float,
    tax_cost: float,
    trading_cost: float,
    migration_net_switching_gap: float | None,
    tolerance: float = 0.0005,
) -> dict:
    """
    Reconcile Capital Migration inputs with the approved Capital Productivity
    economics.

    PASS is a consistency gate only. It is not an execution authorization.
    """
    issues = []
    tol = max(
        0.0,
        float(
            tolerance
            or 0.0
        ),
    )

    if _text(
        bridge.get(
            "mapping_gate"
        )
    ).upper() != "PASS":
        issues.append(
            "ASSUMPTION_BRIDGE_NOT_READY"
        )

    expected_donor = _num(
        bridge.get(
            "donor_forward_er"
        )
    )
    expected_recipient = _num(
        bridge.get(
            "recipient_forward_er"
        )
    )
    expected_incremental = _num(
        bridge.get(
            "mapped_incremental_risk_penalty"
        )
    )

    actual_donor = _num(
        donor_forward_er
    )
    actual_recipient = _num(
        recipient_forward_er
    )
    actual_incremental = _num(
        incremental_risk_penalty
    )

    donor_delta = (
        None
        if (
            expected_donor is None
            or actual_donor is None
        )
        else actual_donor
        - expected_donor
    )
    recipient_delta = (
        None
        if (
            expected_recipient is None
            or actual_recipient is None
        )
        else actual_recipient
        - expected_recipient
    )
    risk_delta = (
        None
        if (
            expected_incremental is None
            or actual_incremental is None
        )
        else actual_incremental
        - expected_incremental
    )

    if (
        donor_delta is None
        or abs(
            donor_delta
        )
        > tol
    ):
        issues.append(
            "DONOR_FORWARD_ER_MISMATCH"
        )
    if (
        recipient_delta is None
        or abs(
            recipient_delta
        )
        > tol
    ):
        issues.append(
            "RECIPIENT_FORWARD_ER_MISMATCH"
        )
    if (
        risk_delta is None
        or abs(
            risk_delta
        )
        > tol
    ):
        issues.append(
            "INCREMENTAL_RISK_PENALTY_MISMATCH"
        )

    reference = migration_bridge_reference(
        bridge,
        tax_cost=tax_cost,
        trading_cost=trading_cost,
    )
    cp_gap = _num(
        reference.get(
            "cp_net_switching_gap_reference"
        )
    )
    migration_gap = _num(
        migration_net_switching_gap
    )
    net_gap_delta = (
        None
        if (
            cp_gap is None
            or migration_gap is None
        )
        else migration_gap
        - cp_gap
    )

    if (
        net_gap_delta is None
        or abs(
            net_gap_delta
        )
        > tol
    ):
        issues.append(
            "NET_SWITCHING_GAP_MISMATCH"
        )

    return {
        **reference,
        "migration_donor_forward_er":
            actual_donor,
        "migration_recipient_forward_er":
            actual_recipient,
        "migration_incremental_risk_penalty":
            actual_incremental,
        "migration_net_switching_gap":
            migration_gap,
        "donor_er_delta":
            donor_delta,
        "recipient_er_delta":
            recipient_delta,
        "risk_penalty_delta":
            risk_delta,
        "net_gap_delta":
            net_gap_delta,
        "reconciliation_gate":
            "PASS"
            if not issues
            else "REVIEW",
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def migration_bridge_review_row(
    bridge: dict,
    reconciliation: dict,
    *,
    note: str = "",
) -> dict:
    row = {
        "reviewed_at":
            datetime.now().isoformat(),
        "donor":
            _text(
                bridge.get("donor")
            ),
        "recipient":
            _text(
                bridge.get("recipient")
            ),
        "donor_kind":
            _text(
                bridge.get(
                    "donor_kind"
                )
            ),
        "recipient_kind":
            _text(
                bridge.get(
                    "recipient_kind"
                )
            ),
        "donor_health":
            _text(
                bridge.get(
                    "donor_health"
                )
            ),
        "recipient_health":
            _text(
                bridge.get(
                    "recipient_health"
                )
            ),
        "donor_input_status":
            _text(
                bridge.get(
                    "donor_input_status"
                )
            ),
        "recipient_input_status":
            _text(
                bridge.get(
                    "recipient_input_status"
                )
            ),
        "donor_forward_er":
            _num(
                bridge.get(
                    "donor_forward_er"
                )
            ),
        "donor_risk_penalty":
            _num(
                bridge.get(
                    "donor_risk_penalty"
                )
            ),
        "donor_risk_adjusted_er":
            _num(
                bridge.get(
                    "donor_risk_adjusted_er"
                )
            ),
        "recipient_forward_er":
            _num(
                bridge.get(
                    "recipient_forward_er"
                )
            ),
        "recipient_risk_penalty":
            _num(
                bridge.get(
                    "recipient_risk_penalty"
                )
            ),
        "recipient_risk_adjusted_er":
            _num(
                bridge.get(
                    "recipient_risk_adjusted_er"
                )
            ),
        "signed_risk_penalty_delta":
            _num(
                bridge.get(
                    "signed_risk_penalty_delta"
                )
            ),
        "mapped_incremental_risk_penalty":
            _num(
                bridge.get(
                    "mapped_incremental_risk_penalty"
                )
            ),
        "tax_cost":
            _num(
                reconciliation.get(
                    "tax_cost"
                )
            ),
        "trading_cost":
            _num(
                reconciliation.get(
                    "trading_cost"
                )
            ),
        "cp_net_switching_gap_reference":
            _num(
                reconciliation.get(
                    "cp_net_switching_gap_reference"
                )
            ),
        "migration_donor_forward_er":
            _num(
                reconciliation.get(
                    "migration_donor_forward_er"
                )
            ),
        "migration_recipient_forward_er":
            _num(
                reconciliation.get(
                    "migration_recipient_forward_er"
                )
            ),
        "migration_incremental_risk_penalty":
            _num(
                reconciliation.get(
                    "migration_incremental_risk_penalty"
                )
            ),
        "migration_net_switching_gap":
            _num(
                reconciliation.get(
                    "migration_net_switching_gap"
                )
            ),
        "donor_er_delta":
            _num(
                reconciliation.get(
                    "donor_er_delta"
                )
            ),
        "recipient_er_delta":
            _num(
                reconciliation.get(
                    "recipient_er_delta"
                )
            ),
        "risk_penalty_delta":
            _num(
                reconciliation.get(
                    "risk_penalty_delta"
                )
            ),
        "net_gap_delta":
            _num(
                reconciliation.get(
                    "net_gap_delta"
                )
            ),
        "mapping_gate":
            _text(
                bridge.get(
                    "mapping_gate"
                )
            ),
        "reconciliation_gate":
            _text(
                reconciliation.get(
                    "reconciliation_gate"
                )
            ),
        "assumption_snapshot_hash":
            _text(
                bridge.get(
                    "assumption_snapshot_hash"
                )
            ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                reconciliation.get(
                    "issues",
                    []
                )
            ),
        "note":
            _text(note),
    }
    return row
