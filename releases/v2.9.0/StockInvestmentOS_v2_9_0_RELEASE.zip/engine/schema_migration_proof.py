from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json
import pandas as pd

from engine.schema_evolution_guard import build_schema_snapshot
from engine.schema_migration_contract import (
    schema_migration_proposal_integrity,
    assess_schema_contract,
)


SCHEMA_MIGRATION_PROOF_COLS = [
    "migration_proof_id",
    "created_at",
    "migration_proposal_id",
    "migration_proposal_record_hash",
    "file",
    "migration_type",
    "baseline_schema_hash",
    "proposal_current_schema_hash",
    "observed_current_schema_hash",
    "implementation_reference",
    "implementation_summary",
    "compatibility_test_summary",
    "rollback_readiness",
    "proof_evidence",
    "source_proposal_confirmed",
    "external_implementation_confirmed",
    "reader_writer_test_confirmed",
    "rollback_plan_confirmed",
    "no_auto_migration_confirmed",
    "human_review_confirmed",
    "proof_gate",
    "proof_status",
    "migration_authorization",
    "issues",
    "note",
    "record_hash",
]


SCHEMA_PROOF_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {"TRUE", "1", "YES", "Y", "PASS"}


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def latest_proposal_for_file(
    proposals: pd.DataFrame | None,
    file_name: str,
) -> dict:
    if proposals is None or proposals.empty or "file" not in proposals.columns:
        return {}

    hit = proposals.loc[
        proposals["file"].fillna("").astype(str).eq(_text(file_name))
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit["_ts"] = pd.to_datetime(hit["created_at"], errors="coerce", utc=True)
        hit = hit.sort_values("_ts", ascending=False, na_position="last")

    return hit.iloc[0].drop(labels=["_ts"], errors="ignore").to_dict()


def latest_matching_proof(
    proofs: pd.DataFrame | None,
    file_name: str,
    current_schema_hash: str,
) -> dict:
    if (
        proofs is None
        or proofs.empty
        or "file" not in proofs.columns
        or "observed_current_schema_hash" not in proofs.columns
    ):
        return {}

    hit = proofs.loc[
        proofs["file"].fillna("").astype(str).eq(_text(file_name))
        & proofs["observed_current_schema_hash"]
        .fillna("")
        .astype(str)
        .str.lower()
        .eq(_text(current_schema_hash).lower())
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit["_ts"] = pd.to_datetime(hit["created_at"], errors="coerce", utc=True)
        hit = hit.sort_values("_ts", ascending=False, na_position="last")

    return hit.iloc[0].drop(labels=["_ts"], errors="ignore").to_dict()


def build_schema_contract_drift(
    contract: dict | None,
    baseline: dict | None,
    comparison: dict | None,
    compatibility: dict | None,
) -> dict:
    assessment = assess_schema_contract(
        contract or {},
        baseline or {},
        comparison or {},
    )

    contract_status = _text(assessment.get("contract_status")).upper()
    schema_status = _text((comparison or {}).get("schema_status")).upper()
    compatibility_status = _text(
        (compatibility or {}).get("compatibility_status")
    ).upper()

    issues = []

    if contract_status == "CURRENT":
        drift_status = "CURRENT"
    elif contract_status in {"INTEGRITY_REVIEW", "BLOCKED"}:
        drift_status = "BLOCKED"
        issues.extend(assessment.get("issues", []))
    elif contract_status == "MISSING":
        drift_status = "NO_CONTRACT"
        issues.append("READER_WRITER_CONTRACT_REQUIRED")
    elif schema_status == "BLOCKED" or compatibility_status == "BLOCKED":
        drift_status = "BLOCKED"
        issues.append("BLOCKING_SCHEMA_DRIFT")
    else:
        drift_status = "DRIFTED"
        issues.append("SCHEMA_CONTRACT_DRIFT_REVIEW")

    return {
        "contract_drift_status": drift_status,
        "contract_status": contract_status,
        "schema_status": schema_status,
        "compatibility_status": compatibility_status,
        "issues": list(dict.fromkeys(issues)),
        "migration_authorization": "NONE",
    }


def validate_migration_proof(
    proposal: dict | None,
    current_scan: pd.DataFrame | None,
    *,
    implementation_reference: str,
    implementation_summary: str,
    compatibility_test_summary: str,
    rollback_readiness: str,
    proof_evidence: str,
    source_proposal_confirmed: bool,
    external_implementation_confirmed: bool,
    reader_writer_test_confirmed: bool,
    rollback_plan_confirmed: bool,
    no_auto_migration_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    proposal_row = proposal or {}
    issues = []

    if not proposal_row:
        issues.append("MIGRATION_PROPOSAL_REQUIRED")
    else:
        if schema_migration_proposal_integrity(proposal_row)["status"] != "OK":
            issues.append("MIGRATION_PROPOSAL_INTEGRITY_FAILED")

        if _text(proposal_row.get("proposal_status")).upper() != (
            "READY_FOR_IMPLEMENTATION_REVIEW"
        ):
            issues.append("PROPOSAL_READY_FOR_IMPLEMENTATION_REVIEW_REQUIRED")

    observed_hash = build_schema_snapshot(current_scan)["snapshot_hash"]
    proposal_hash = _text(proposal_row.get("current_schema_hash"))

    if proposal_row and proposal_hash and proposal_hash != observed_hash:
        issues.append("CURRENT_SCHEMA_CHANGED_SINCE_PROPOSAL")

    for value, issue in [
        (implementation_reference, "IMPLEMENTATION_REFERENCE_REQUIRED"),
        (implementation_summary, "IMPLEMENTATION_SUMMARY_REQUIRED"),
        (compatibility_test_summary, "COMPATIBILITY_TEST_SUMMARY_REQUIRED"),
        (rollback_readiness, "ROLLBACK_READINESS_REQUIRED"),
        (proof_evidence, "PROOF_EVIDENCE_REQUIRED"),
    ]:
        if not _text(value):
            issues.append(issue)

    for passed, issue in [
        (source_proposal_confirmed, "SOURCE_PROPOSAL_CONFIRMATION_REQUIRED"),
        (
            external_implementation_confirmed,
            "EXTERNAL_IMPLEMENTATION_CONFIRMATION_REQUIRED",
        ),
        (reader_writer_test_confirmed, "READER_WRITER_TEST_CONFIRMATION_REQUIRED"),
        (rollback_plan_confirmed, "ROLLBACK_PLAN_CONFIRMATION_REQUIRED"),
        (no_auto_migration_confirmed, "NO_AUTO_MIGRATION_CONFIRMATION_REQUIRED"),
        (human_review_confirmed, "HUMAN_REVIEW_CONFIRMATION_REQUIRED"),
    ]:
        if not _bool(passed):
            issues.append(issue)

    gate = "PASS" if not issues else "REVIEW"

    return {
        "proof_gate": gate,
        "proof_status": (
            "MIGRATION_PROOF_ACCEPTED" if gate == "PASS" else "DRAFT"
        ),
        "observed_current_schema_hash": observed_hash,
        "migration_authorization": "NONE",
        "issues": list(dict.fromkeys(issues)),
    }


def _proof_payload(row: dict) -> dict:
    bool_fields = {
        "source_proposal_confirmed",
        "external_implementation_confirmed",
        "reader_writer_test_confirmed",
        "rollback_plan_confirmed",
        "no_auto_migration_confirmed",
        "human_review_confirmed",
    }

    payload = {}
    for col in SCHEMA_MIGRATION_PROOF_COLS:
        if col == "record_hash":
            continue
        if col in bool_fields:
            payload[col] = bool(_bool(row.get(col)))
        else:
            payload[col] = _text(row.get(col))
    return payload


def build_migration_proof_record(
    proposal: dict,
    validation: dict,
    *,
    implementation_reference: str,
    implementation_summary: str,
    compatibility_test_summary: str,
    rollback_readiness: str,
    proof_evidence: str,
    source_proposal_confirmed: bool,
    external_implementation_confirmed: bool,
    reader_writer_test_confirmed: bool,
    rollback_plan_confirmed: bool,
    no_auto_migration_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    proposal_row = proposal or {}
    review = validation or {}

    now = _text(created_at) or datetime.now().astimezone().isoformat()
    proposal_id = _text(proposal_row.get("migration_proposal_id"))
    observed_hash = _text(review.get("observed_current_schema_hash"))

    proof_id = (
        "SMPF-"
        + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
        + "-"
        + hashlib.sha256(
            (proposal_id + "|" + observed_hash).encode("utf-8")
        ).hexdigest()[:8]
    )

    row = {
        "migration_proof_id": proof_id,
        "created_at": now,
        "migration_proposal_id": proposal_id,
        "migration_proposal_record_hash": _text(proposal_row.get("record_hash")),
        "file": _text(proposal_row.get("file")),
        "migration_type": _text(proposal_row.get("migration_type")),
        "baseline_schema_hash": _text(proposal_row.get("baseline_schema_hash")),
        "proposal_current_schema_hash": _text(
            proposal_row.get("current_schema_hash")
        ),
        "observed_current_schema_hash": observed_hash,
        "implementation_reference": _text(implementation_reference),
        "implementation_summary": _text(implementation_summary),
        "compatibility_test_summary": _text(compatibility_test_summary),
        "rollback_readiness": _text(rollback_readiness),
        "proof_evidence": _text(proof_evidence),
        "source_proposal_confirmed": bool(source_proposal_confirmed),
        "external_implementation_confirmed": bool(
            external_implementation_confirmed
        ),
        "reader_writer_test_confirmed": bool(reader_writer_test_confirmed),
        "rollback_plan_confirmed": bool(rollback_plan_confirmed),
        "no_auto_migration_confirmed": bool(no_auto_migration_confirmed),
        "human_review_confirmed": bool(human_review_confirmed),
        "proof_gate": _text(review.get("proof_gate")),
        "proof_status": _text(review.get("proof_status")),
        "migration_authorization": "NONE",
        "issues": " | ".join(review.get("issues", [])),
        "note": _text(note),
        "record_hash": "",
    }

    row["record_hash"] = _hash(_proof_payload(row))
    return row


def migration_proof_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(record.get("record_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_proof_payload(record))

    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def build_compatibility_closure(
    comparison: dict | None,
    contract_drift: dict | None,
    proposals: pd.DataFrame | None,
    proofs: pd.DataFrame | None,
    current_scan: pd.DataFrame | None,
) -> dict:
    compare = comparison or {}
    drift = contract_drift or {}
    changed_files = _int(compare.get("changed_files"))
    current_hash = build_schema_snapshot(current_scan)["snapshot_hash"]

    if (
        changed_files == 0
        and _text(drift.get("contract_drift_status")).upper() == "CURRENT"
    ):
        return {
            "closure_status": "NO_CHANGE",
            "changed_files": 0,
            "proposal_missing": 0,
            "proof_pending": 0,
            "proof_accepted": 0,
            "integrity_issues": 0,
            "current_schema_hash": current_hash,
            "details": pd.DataFrame(),
            "migration_authorization": "NONE",
        }

    diff = compare.get("diff")
    if not isinstance(diff, pd.DataFrame) or diff.empty:
        return {
            "closure_status": "BLOCKED",
            "changed_files": changed_files,
            "proposal_missing": changed_files,
            "proof_pending": 0,
            "proof_accepted": 0,
            "integrity_issues": 1,
            "current_schema_hash": current_hash,
            "details": pd.DataFrame(),
            "migration_authorization": "NONE",
        }

    changed = diff.loc[diff["migration_type"].ne("CURRENT")].copy()

    rows = []
    proposal_missing = 0
    proof_pending = 0
    proof_accepted = 0
    integrity_issues = 0

    for _, row in changed.iterrows():
        file_name = _text(row.get("file"))
        proposal = latest_proposal_for_file(proposals, file_name)

        proposal_id = ""
        proof_id = ""

        if not proposal:
            item_status = "PROPOSAL_MISSING"
            proposal_missing += 1

        elif schema_migration_proposal_integrity(proposal)["status"] != "OK":
            item_status = "PROPOSAL_INTEGRITY_REVIEW"
            proposal_id = _text(proposal.get("migration_proposal_id"))
            integrity_issues += 1

        elif _text(proposal.get("current_schema_hash")) != current_hash:
            item_status = "PROPOSAL_STALE"
            proposal_id = _text(proposal.get("migration_proposal_id"))
            proof_pending += 1

        else:
            proposal_id = _text(proposal.get("migration_proposal_id"))
            proof = latest_matching_proof(proofs, file_name, current_hash)

            if not proof:
                item_status = "PROOF_PENDING"
                proof_pending += 1

            elif migration_proof_integrity(proof)["status"] != "OK":
                item_status = "PROOF_INTEGRITY_REVIEW"
                proof_id = _text(proof.get("migration_proof_id"))
                integrity_issues += 1

            elif _text(proof.get("proof_status")).upper() == (
                "MIGRATION_PROOF_ACCEPTED"
            ):
                item_status = "PROOF_ACCEPTED"
                proof_id = _text(proof.get("migration_proof_id"))
                proof_accepted += 1

            else:
                item_status = "PROOF_PENDING"
                proof_id = _text(proof.get("migration_proof_id"))
                proof_pending += 1

        rows.append(
            {
                "file": file_name,
                "migration_type": _text(row.get("migration_type")),
                "closure_item_status": item_status,
                "proposal_id": proposal_id,
                "proof_id": proof_id,
            }
        )

    if integrity_issues > 0:
        closure_status = "INTEGRITY_REVIEW"
    elif proposal_missing > 0:
        closure_status = "PROPOSAL_PENDING"
    elif proof_pending > 0:
        closure_status = "PROOF_PENDING"
    elif changed_files > 0 and proof_accepted == changed_files:
        closure_status = "READY_FOR_BASELINE_REFRESH"
    else:
        closure_status = "REVIEW"

    return {
        "closure_status": closure_status,
        "changed_files": changed_files,
        "proposal_missing": proposal_missing,
        "proof_pending": proof_pending,
        "proof_accepted": proof_accepted,
        "integrity_issues": integrity_issues,
        "current_schema_hash": current_hash,
        "details": pd.DataFrame(rows),
        "migration_authorization": "NONE",
    }


def build_schema_proof_queue(
    contract_drift: dict | None,
    closure: dict | None,
) -> pd.DataFrame:
    drift = contract_drift or {}
    close = closure or {}
    rows = []

    drift_status = _text(drift.get("contract_drift_status")).upper()
    closure_status = _text(close.get("closure_status")).upper()

    if drift_status in {"BLOCKED", "NO_CONTRACT"}:
        rows.append(
            {
                "priority": "SP0",
                "status": "BLOCKED",
                "issue": (
                    "SCHEMA_CONTRACT_DRIFT_BLOCKED"
                    if drift_status == "BLOCKED"
                    else "READER_WRITER_CONTRACT_REQUIRED"
                ),
                "next_action": "Baseline/Contract integrity를 먼저 확인",
                "go_to": "Save Center",
            }
        )

    if closure_status == "PROPOSAL_PENDING":
        rows.append(
            {
                "priority": "SP1",
                "status": "REVIEW",
                "issue": "SCHEMA_MIGRATION_PROPOSAL_PENDING",
                "next_action": "Schema drift file별 Migration Proposal Human Review",
                "go_to": "Save Center",
            }
        )
    elif closure_status == "PROOF_PENDING":
        rows.append(
            {
                "priority": "SP2",
                "status": "REVIEW",
                "issue": "SCHEMA_MIGRATION_PROOF_PENDING",
                "next_action": "외부 구현/Compatibility/rollback evidence를 검토",
                "go_to": "Save Center",
            }
        )
    elif closure_status == "READY_FOR_BASELINE_REFRESH":
        rows.append(
            {
                "priority": "SP3",
                "status": "REVIEW",
                "issue": "SCHEMA_COMPATIBILITY_PROOF_ACCEPTED",
                "next_action": "Proof accepted · 새 Baseline/Contract refresh를 별도 Human Review",
                "go_to": "Save Center",
            }
        )
    elif closure_status == "INTEGRITY_REVIEW":
        rows.append(
            {
                "priority": "SP0",
                "status": "BLOCKED",
                "issue": "SCHEMA_PROPOSAL_OR_PROOF_INTEGRITY_REVIEW",
                "next_action": "Proposal/Proof immutable hash 확인",
                "go_to": "Save Center",
            }
        )

    if not rows:
        return pd.DataFrame(columns=SCHEMA_PROOF_QUEUE_COLS)

    order = {"SP0": 0, "SP1": 1, "SP2": 2, "SP3": 3}
    out = pd.DataFrame(rows)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(["_p", "issue"])
        .drop(columns=["_p"])[SCHEMA_PROOF_QUEUE_COLS]
        .reset_index(drop=True)
    )
