from __future__ import annotations

from typing import Any
import json

import pandas as pd

from engine.operations_flow_trend import (
    FLOW_TREND_SNAPSHOT_COLS,
    flow_trend_snapshot_integrity,
)
from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    flow_projection_snapshot_integrity,
)
from engine.operations_flow_projection_review import (
    FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    flow_projection_review_snapshot_integrity,
)
from engine.operations_flow_projection_outcome_evidence import (
    FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS,
    build_guarded_flow_projection_outcome,
    flow_projection_outcome_evidence_snapshot_integrity,
    latest_flow_projection_outcome_evidence_snapshot,
)


OUTCOME_EVIDENCE_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V134_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


KNOWN_WINDOW_GUARDS = {
    "OUTCOME_REVIEW_SOURCE_REQUIRED": "HOLD_REVIEW_SOURCE",
    "OUTCOME_REVIEW_LOCK_REQUIRED": "HOLD_REVIEW_LOCK",
    "OUTCOME_REVIEW_SOURCE_SUPERSEDED": "HOLD_REVIEW_SUPERSEDED",
    "OUTCOME_REVIEW_INTEGRITY_REVIEW": "HOLD_INTEGRITY",
    "OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW": "HOLD_INTEGRITY",
    "OUTCOME_ANTI_HINDSIGHT_REVIEW": "HOLD_ANTI_HINDSIGHT",
    "OUTCOME_WAIT_CLOSED_SESSION": "HOLD_CLOSED_SESSION",
    "OUTCOME_EVIDENCE_GAP_REVIEW": "HOLD_EVIDENCE_GAP",
    "OUTCOME_EVIDENCE_INTEGRITY_REVIEW": "HOLD_INTEGRITY",
    "OUTCOME_EVIDENCE_MATURING": "ALLOW_OUTCOME_TRACKING",
    "OUTCOME_EVIDENCE_READY": "ALLOW_OUTCOME_TRACKING",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    source = pd.DataFrame() if df is None else df.copy()

    if source.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in source.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _fail_count(
    counts: dict | None,
) -> int:
    c = counts or {}
    return (
        _int(c.get("missing"))
        + _int(c.get("mismatch"))
    )


def _index_by_id(
    df: pd.DataFrame,
    *,
    id_col: str,
) -> tuple[dict, int]:
    if df.empty or id_col not in df.columns:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def _parse_json_list(
    value: Any,
) -> list[str]:
    raw = _text(value)

    if not raw:
        return []

    try:
        parsed = json.loads(raw)
    except Exception:
        return []

    if not isinstance(parsed, list):
        return []

    return [
        _text(item)
        for item in parsed
        if _text(item)
    ]


def build_v134_outcome_evidence_context(
    *,
    projection_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
    trend_snapshots: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    outcome_evidence_snapshots: pd.DataFrame | None,
) -> dict:
    projection_df = _ensure_cols(
        projection_snapshots,
        FLOW_PROJECTION_SNAPSHOT_COLS,
    )
    review_df = _ensure_cols(
        review_snapshots,
        FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    )
    trend_df = _ensure_cols(
        trend_snapshots,
        FLOW_TREND_SNAPSHOT_COLS,
    )
    audit_df = _ensure_cols(
        outcome_evidence_snapshots,
        FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS,
    )

    guarded = build_guarded_flow_projection_outcome(
        projection_df,
        review_df,
        trend_df,
        sessions,
        min_evaluation_endpoints=2,
        max_evaluation_endpoints=20,
        relative_error_threshold=0.50,
    )

    latest_audit = latest_flow_projection_outcome_evidence_snapshot(
        audit_df
    )

    latest_integrity = (
        _text(
            flow_projection_outcome_evidence_snapshot_integrity(
                latest_audit
            ).get("status")
        ).upper()
        if latest_audit
        else "NONE"
    )

    return {
        "projection_snapshots": projection_df,
        "review_snapshots": review_df,
        "trend_snapshots": trend_df,
        "sessions": (
            pd.DataFrame()
            if sessions is None
            else sessions.copy()
        ),
        "outcome_evidence_snapshots": audit_df,
        "window": guarded.get("window") or {},
        "outcome": guarded.get("outcome") or {},
        "audit_integrity": _integrity_counts(
            audit_df,
            flow_projection_outcome_evidence_snapshot_integrity,
        ),
        "latest_audit": latest_audit,
        "latest_audit_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v134_outcome_evidence_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    window = ctx.get("window") or {}
    outcome = ctx.get("outcome") or {}
    counts = ctx.get("audit_integrity") or {}
    trend_df = (
        ctx.get("trend_snapshots")
        if isinstance(
            ctx.get("trend_snapshots"),
            pd.DataFrame,
        )
        else pd.DataFrame()
    )

    checks = []

    integrity_fail = _fail_count(counts)

    checks.append(
        _technical_row(
            "Outcome Evidence Snapshot Integrity",
            integrity_fail == 0,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            (
                "operations_flow_projection_outcome_evidence_snapshots.csv "
                "immutable hash 확인"
            ),
        )
    )

    state = _text(
        window.get("window_state")
    ).upper()
    guard = _text(
        window.get("tracking_guard")
    ).upper()

    expected_guard = KNOWN_WINDOW_GUARDS.get(state, "")

    checks.append(
        _technical_row(
            "Outcome Evidence State / Guard Vocabulary",
            bool(expected_guard) and guard == expected_guard,
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {expected_guard or 'UNKNOWN'}"
            ),
            "Outcome Evidence state / guard vocabulary 확인",
        )
    )

    review_state = _text(
        window.get("review_state")
    ).upper()
    review_id = _text(
        window.get("review_snapshot_id")
    )
    source_id = _text(
        window.get("source_projection_snapshot_id")
    )

    if state == "OUTCOME_REVIEW_SOURCE_REQUIRED":
        review_mapping_ok = (
            not review_id
            and not source_id
        )
    elif state in {
        "OUTCOME_REVIEW_LOCK_REQUIRED",
        "OUTCOME_REVIEW_SOURCE_SUPERSEDED",
        "OUTCOME_REVIEW_INTEGRITY_REVIEW",
    }:
        review_mapping_ok = (
            review_state != "PROJECTION_REVIEW_LOCKED"
            or not source_id
        )
    else:
        review_mapping_ok = (
            review_state == "PROJECTION_REVIEW_LOCKED"
            and bool(review_id)
            and bool(source_id)
        )

    checks.append(
        _technical_row(
            "Review Lock / Outcome Evidence Source Mapping",
            bool(review_mapping_ok),
            (
                f"state {state or 'MISSING'} · "
                f"review {review_state or 'MISSING'} · "
                f"review audit {review_id or 'NONE'} · "
                f"projection source {source_id or 'NONE'}"
            ),
            (
                "LOCKED Review source가 없는 Outcome Evidence tracking 또는 "
                "잘못된 review/source mapping 확인"
            ),
        )
    )

    contamination = _int(
        window.get("prelock_contamination_count")
    )

    anti_hindsight_ok = (
        (
            contamination > 0
            and state == "OUTCOME_ANTI_HINDSIGHT_REVIEW"
            and guard == "HOLD_ANTI_HINDSIGHT"
        )
        or (
            contamination == 0
            and state != "OUTCOME_ANTI_HINDSIGHT_REVIEW"
        )
    )

    checks.append(
        _technical_row(
            "Projection Review Anti-Hindsight Invariant",
            anti_hindsight_ok,
            (
                f"pre-lock contamination {contamination} · "
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'}"
            ),
            (
                "Projection 생성 후 Review Lock 전 Trend evidence가 있으면 "
                "Anti-Hindsight HOLD가 적용되는지 확인"
            ),
        )
    )

    gap_count = _int(
        window.get("closed_session_gap_count")
    )

    gap_ok = (
        (
            gap_count > 0
            and state == "OUTCOME_EVIDENCE_GAP_REVIEW"
            and guard == "HOLD_EVIDENCE_GAP"
        )
        or (
            gap_count == 0
            and state != "OUTCOME_EVIDENCE_GAP_REVIEW"
        )
    )

    checks.append(
        _technical_row(
            "Closed-Session Outcome Evidence Gap Invariant",
            gap_ok,
            (
                f"gap count {gap_count} · "
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'}"
            ),
            (
                "post-lock closed-session evidence gap을 건너뛰어 "
                "Outcome window를 이어 붙이지 않는지 확인"
            ),
        )
    )

    endpoint_ids = [
        _text(item)
        for item in window.get("endpoint_ids", [])
        if _text(item)
    ]
    endpoint_hashes = [
        _text(item)
        for item in window.get("endpoint_hashes", [])
        if _text(item)
    ]

    trend_index, trend_duplicates = _index_by_id(
        trend_df,
        id_col="trend_snapshot_id",
    )

    endpoint_missing = 0
    endpoint_mismatch = 0

    for idx, endpoint_id in enumerate(
        endpoint_ids
    ):
        parent = trend_index.get(
            endpoint_id
        )

        if parent is None:
            endpoint_missing += 1
            continue

        if _text(
            flow_trend_snapshot_integrity(
                parent
            ).get("status")
        ).upper() != "OK":
            endpoint_mismatch += 1
            continue

        expected_hash = (
            endpoint_hashes[idx]
            if idx < len(endpoint_hashes)
            else ""
        )

        if (
            expected_hash
            and _text(
                parent.get("snapshot_hash")
            )
            != expected_hash
        ):
            endpoint_mismatch += 1

    endpoint_lineage_ok = (
        endpoint_missing == 0
        and endpoint_mismatch == 0
        and trend_duplicates == 0
        and len(endpoint_hashes)
        in {
            0,
            len(endpoint_ids),
        }
    )

    checks.append(
        _technical_row(
            "Outcome Evidence Endpoint Trend Lineage",
            endpoint_lineage_ok,
            (
                f"endpoints {len(endpoint_ids)} · "
                f"missing {endpoint_missing} · "
                f"mismatch {endpoint_mismatch} · "
                f"trend duplicates {trend_duplicates}"
            ),
            (
                "Outcome Evidence endpoint id/hash와 Trend Snapshot lineage 확인"
            ),
        )
    )

    outcome_state = _text(
        outcome.get("evaluation_state")
    ).upper()
    outcome_window_state = _text(
        outcome.get("outcome_evidence_state")
    ).upper()

    handoff_ok = (
        outcome_window_state == state
    )

    if state in {
        "OUTCOME_ANTI_HINDSIGHT_REVIEW",
        "OUTCOME_EVIDENCE_GAP_REVIEW",
        "OUTCOME_EVIDENCE_INTEGRITY_REVIEW",
        "OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW",
    }:
        handoff_ok = (
            handoff_ok
            and not bool(
                outcome.get("snapshot_eligible")
            )
        )

    checks.append(
        _technical_row(
            "Outcome Evidence Window / Outcome Hand-off Invariant",
            handoff_ok,
            (
                f"window {state or 'MISSING'} · "
                f"outcome evidence {outcome_window_state or 'MISSING'} · "
                f"evaluation {outcome_state or 'MISSING'} · "
                f"snapshot eligible {bool(outcome.get('snapshot_eligible'))}"
            ),
            (
                "Outcome Evidence window와 guarded Outcome evaluation/snapshot "
                "eligibility 연결 확인"
            ),
        )
    )

    auth_violations = 0

    for item in [
        window,
        outcome,
    ]:
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {
                    "",
                    "NONE",
                }
            ):
                auth_violations += 1

    audit_df = ctx.get(
        "outcome_evidence_snapshots"
    )

    if isinstance(audit_df, pd.DataFrame):
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in audit_df.columns:
                continue

            values = (
                audit_df[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            auth_violations += int(
                (
                    ~values.isin(
                        [
                            "",
                            "NONE",
                        ]
                    )
                ).sum()
            )

    if _text(
        ctx.get("execution_authorization")
    ).upper() != "NONE":
        auth_violations += 1

    checks.append(
        _technical_row(
            "Outcome Evidence Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            (
                "Projection / Capacity / Execution Authorization을 NONE으로 유지"
            ),
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if (
            state == "OUTCOME_EVIDENCE_READY"
            and outcome_state
            in {
                "WITHIN_REVIEW_BAND",
                "CLEARED_REVIEW",
            }
        )
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Outcome Evidence Operating State",
            "status": operating_status,
            "detail": (
                f"window {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"eligible {_int(window.get('eligible_endpoints'))} · "
                f"gaps {gap_count} · "
                f"anti-hindsight {contamination}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 source-required / closed-session wait / maturing 상태는 "
                    "Technical FAIL로 승격하지 않음"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "window_state": state,
        "tracking_guard": guard,
        "eligible_endpoints": _int(
            window.get("eligible_endpoints")
        ),
        "closed_session_gap_count": gap_count,
        "prelock_contamination_count": contamination,
        "latest_audit_integrity": _text(
            ctx.get("latest_audit_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=OUTCOME_EVIDENCE_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_parent_lineage(
    ctx: dict,
) -> dict:
    audits = (
        ctx.get("outcome_evidence_snapshots")
        if isinstance(
            ctx.get("outcome_evidence_snapshots"),
            pd.DataFrame,
        )
        else pd.DataFrame()
    )
    projections = (
        ctx.get("projection_snapshots")
        if isinstance(
            ctx.get("projection_snapshots"),
            pd.DataFrame,
        )
        else pd.DataFrame()
    )
    reviews = (
        ctx.get("review_snapshots")
        if isinstance(
            ctx.get("review_snapshots"),
            pd.DataFrame,
        )
        else pd.DataFrame()
    )
    trends = (
        ctx.get("trend_snapshots")
        if isinstance(
            ctx.get("trend_snapshots"),
            pd.DataFrame,
        )
        else pd.DataFrame()
    )

    projection_index, projection_duplicates = _index_by_id(
        projections,
        id_col="projection_snapshot_id",
    )
    review_index, review_duplicates = _index_by_id(
        reviews,
        id_col="review_snapshot_id",
    )
    trend_index, trend_duplicates = _index_by_id(
        trends,
        id_col="trend_snapshot_id",
    )

    parent_missing = 0
    parent_mismatch = 0
    endpoint_missing = 0
    endpoint_mismatch = 0

    for _, row in audits.iterrows():
        item = row.to_dict()

        review_id = _text(
            item.get("review_snapshot_id")
        )
        review_hash = _text(
            item.get("review_snapshot_hash")
        )
        projection_id = _text(
            item.get("source_projection_snapshot_id")
        )
        projection_hash = _text(
            item.get("source_projection_hash")
        )

        if review_id:
            parent = review_index.get(
                review_id
            )

            if parent is None:
                parent_missing += 1
            elif (
                _text(
                    flow_projection_review_snapshot_integrity(
                        parent
                    ).get("status")
                ).upper()
                != "OK"
                or (
                    review_hash
                    and _text(
                        parent.get("snapshot_hash")
                    )
                    != review_hash
                )
            ):
                parent_mismatch += 1

        if projection_id:
            parent = projection_index.get(
                projection_id
            )

            if parent is None:
                parent_missing += 1
            elif (
                _text(
                    flow_projection_snapshot_integrity(
                        parent
                    ).get("status")
                ).upper()
                != "OK"
                or (
                    projection_hash
                    and _text(
                        parent.get("snapshot_hash")
                    )
                    != projection_hash
                )
            ):
                parent_mismatch += 1

        endpoint_ids = _parse_json_list(
            item.get("endpoint_ids_json")
        )
        endpoint_hashes = _parse_json_list(
            item.get("endpoint_hashes_json")
        )

        if len(endpoint_hashes) not in {
            0,
            len(endpoint_ids),
        }:
            endpoint_mismatch += 1

        for idx, endpoint_id in enumerate(
            endpoint_ids
        ):
            parent = trend_index.get(
                endpoint_id
            )

            if parent is None:
                endpoint_missing += 1
                continue

            if _text(
                flow_trend_snapshot_integrity(
                    parent
                ).get("status")
            ).upper() != "OK":
                endpoint_mismatch += 1
                continue

            expected_hash = (
                endpoint_hashes[idx]
                if idx < len(endpoint_hashes)
                else ""
            )

            if (
                expected_hash
                and _text(
                    parent.get("snapshot_hash")
                )
                != expected_hash
            ):
                endpoint_mismatch += 1

    return {
        "parent_missing": parent_missing,
        "parent_mismatch": parent_mismatch,
        "endpoint_missing": endpoint_missing,
        "endpoint_mismatch": endpoint_mismatch,
        "projection_duplicates": projection_duplicates,
        "review_duplicates": review_duplicates,
        "trend_duplicates": trend_duplicates,
    }


def build_v134_outcome_evidence_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    audit_df = (
        ctx.get("outcome_evidence_snapshots")
        if isinstance(
            ctx.get("outcome_evidence_snapshots"),
            pd.DataFrame,
        )
        else pd.DataFrame()
    )
    counts = ctx.get("audit_integrity") or {}

    checks = []

    integrity_fail = _fail_count(counts)

    checks.append(
        _technical_row(
            "Outcome Evidence Audit Snapshot Integrity",
            integrity_fail == 0,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Outcome Evidence audit immutable hash 확인",
        )
    )

    vocabulary_violations = 0

    if not audit_df.empty:
        for _, row in audit_df.iterrows():
            state = _text(
                row.get("window_state")
            ).upper()
            guard = _text(
                row.get("tracking_guard")
            ).upper()
            expected_guard = KNOWN_WINDOW_GUARDS.get(
                state,
                "",
            )

            if (
                not expected_guard
                or guard != expected_guard
            ):
                vocabulary_violations += 1

    checks.append(
        _technical_row(
            "Outcome Evidence Audit State / Guard Vocabulary",
            vocabulary_violations == 0,
            f"violations {vocabulary_violations}",
            "저장 Outcome Evidence audit state / guard vocabulary 확인",
        )
    )

    lineage = _audit_parent_lineage(
        ctx
    )

    parent_lineage_ok = (
        lineage["parent_missing"] == 0
        and lineage["parent_mismatch"] == 0
        and lineage["projection_duplicates"] == 0
        and lineage["review_duplicates"] == 0
    )

    checks.append(
        _technical_row(
            "Outcome Evidence Audit Review / Projection Parent Lineage",
            parent_lineage_ok,
            (
                f"missing {lineage['parent_missing']} · "
                f"mismatch {lineage['parent_mismatch']} · "
                f"projection duplicates {lineage['projection_duplicates']} · "
                f"review duplicates {lineage['review_duplicates']}"
            ),
            "Outcome Evidence audit의 Review / Projection parent id/hash 확인",
        )
    )

    endpoint_lineage_ok = (
        lineage["endpoint_missing"] == 0
        and lineage["endpoint_mismatch"] == 0
        and lineage["trend_duplicates"] == 0
    )

    checks.append(
        _technical_row(
            "Outcome Evidence Audit Trend Endpoint Lineage",
            endpoint_lineage_ok,
            (
                f"missing {lineage['endpoint_missing']} · "
                f"mismatch {lineage['endpoint_mismatch']} · "
                f"trend duplicates {lineage['trend_duplicates']}"
            ),
            "저장 Outcome Evidence endpoint id/hash와 Trend Snapshot 확인",
        )
    )

    auth_violations = 0

    if not audit_df.empty:
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in audit_df.columns:
                continue

            values = (
                audit_df[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            auth_violations += int(
                (
                    ~values.isin(
                        [
                            "",
                            "NONE",
                        ]
                    )
                ).sum()
            )

    checks.append(
        _technical_row(
            "Outcome Evidence Audit Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"violations {auth_violations}"
            ),
            "저장 Outcome Evidence audit Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("window") or {}).get(
            "window_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state == "OUTCOME_EVIDENCE_READY"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Outcome Evidence Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current window {current_state or 'MISSING'} · "
                f"saved audits {len(audit_df)}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "Outcome Evidence가 실제 closed-session evidence로 "
                    "성숙할 때 audit history를 필요 시 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=OUTCOME_EVIDENCE_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v134_release_readiness(
    *,
    v133_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    outcome_evidence_release_gate: str,
    outcome_evidence_audit_gate: str,
    evidence_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    v133 = _text(
        v133_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )
    evidence_gate = _text(
        outcome_evidence_release_gate
    ).upper()
    audit_gate = _text(
        outcome_evidence_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()

    checks = [
        _candidate_row(
            "v1.33 Projection Human Review Release Baseline",
            v133 == "READY_FOR_RELEASE_REVIEW",
            v133 or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Outcome Evidence Technical Release Gate",
            evidence_gate == "PASS",
            evidence_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Outcome Evidence Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            evidence_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "PROJECTION_OUTCOME_EVIDENCE_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V134_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v134_integration_crosscheck(
    *,
    integration_consistency: str,
    outcome_evidence_release_gate: str,
    outcome_evidence_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    evidence_gate = _text(
        outcome_evidence_release_gate
    ).upper()
    audit_gate = _text(
        outcome_evidence_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Projection Outcome Evidence Technical Gate",
            evidence_gate == "PASS",
            evidence_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Outcome Evidence Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V134_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v134_data_crosscheck(
    *,
    csv_fail_count: int,
    outcome_evidence_release_gate: str,
    outcome_evidence_audit_gate: str,
    latest_outcome_evidence_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    evidence_gate = _text(
        outcome_evidence_release_gate
    ).upper()
    audit_gate = _text(
        outcome_evidence_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_outcome_evidence_integrity
    ).upper()

    latest_ok = (
        latest_integrity
        in {
            "",
            "NONE",
            "OK",
        }
    )

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Outcome Evidence Technical Gate",
            evidence_gate == "PASS",
            evidence_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Outcome Evidence Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Outcome Evidence Audit Integrity",
            latest_ok,
            latest_integrity or "NONE",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V134_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
