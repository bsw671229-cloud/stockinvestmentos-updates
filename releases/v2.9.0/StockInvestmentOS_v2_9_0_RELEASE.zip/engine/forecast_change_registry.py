from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd


FORECAST_CHANGE_AREAS = [
    "MODEL_LOGIC",
    "ASSUMPTION_PARAMETER",
    "EXECUTION_PROCESS",
    "EVIDENCE_MONITORING",
    "CLASSIFICATION_RULE",
    "NO_CHANGE",
]


FORECAST_CHANGE_PLAN_COLS = [
    "change_plan_id",
    "created_at",
    "scope",
    "company",
    "forecast_error_class",
    "source_sample_size",
    "source_error_count",
    "source_error_share",
    "source_recurrence_status",
    "source_review_lane",
    "source_cohort_hash",
    "change_area",
    "change_target",
    "baseline_description",
    "proposed_change",
    "expected_improvement",
    "proof_date",
    "implementation_status",
    "source_pattern_confirmed",
    "no_auto_apply_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "plan_gate",
    "plan_status",
    "next_gate",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


FORECAST_CHANGE_QUEUE_COLS = [
    "priority",
    "company",
    "forecast_error_class",
    "change_area",
    "plan_status",
    "implementation_status",
    "proof_date",
    "days_to_proof",
    "status",
    "issue",
    "next_action",
    "go_to",
    "change_plan_id",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _stable_num(
    value: Any,
    places: int = 12,
) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _normalize_error_class(value: Any) -> str:
    raw = _text(
        value
    ).upper()

    if raw in {
        "MODEL",
        "PARAMETER",
        "EXECUTION",
        "EXOGENOUS",
        "NONE",
        "OTHER",
    }:
        return raw

    if raw in {
        "",
        "N/A",
        "NA",
        "NO_ERROR",
        "NO ERROR",
    }:
        return "NONE"

    return "OTHER"


def expected_change_area(
    forecast_error_class: str,
) -> str:
    error = _normalize_error_class(
        forecast_error_class
    )

    mapping = {
        "MODEL":
            "MODEL_LOGIC",
        "PARAMETER":
            "ASSUMPTION_PARAMETER",
        "EXECUTION":
            "EXECUTION_PROCESS",
        "EXOGENOUS":
            "EVIDENCE_MONITORING",
        "OTHER":
            "CLASSIFICATION_RULE",
        "NONE":
            "NO_CHANGE",
    }
    return mapping[
        error
    ]


def change_next_gate(
    change_area: str,
) -> str:
    area = _text(
        change_area
    ).upper()

    mapping = {
        "MODEL_LOGIC":
            "MODEL_REVIEW",
        "ASSUMPTION_PARAMETER":
            "ASSUMPTION_REVALIDATION",
        "EXECUTION_PROCESS":
            "PROCESS_REVIEW",
        "EVIDENCE_MONITORING":
            "EVIDENCE_REGIME_REVIEW",
        "CLASSIFICATION_RULE":
            "CLASSIFICATION_REVIEW",
        "NO_CHANGE":
            "OBSERVE",
    }
    return mapping.get(
        area,
        "REVIEW_REQUIRED",
    )


def change_go_to(
    change_area: str,
) -> str:
    area = _text(
        change_area
    ).upper()

    mapping = {
        "MODEL_LOGIC":
            "Decision Journal",
        "ASSUMPTION_PARAMETER":
            "Capital Productivity",
        "EXECUTION_PROCESS":
            "Execution Checklist",
        "EVIDENCE_MONITORING":
            "Evidence Impact Review",
        "CLASSIFICATION_RULE":
            "Decision Journal",
        "NO_CHANGE":
            "Decision Journal",
    }
    return mapping.get(
        area,
        "Review Queue",
    )


def cohort_snapshot_hash(
    cohort_row: dict | None,
) -> str:
    row = cohort_row or {}

    payload = {
        "scope":
            _text(
                row.get(
                    "scope"
                )
            ),
        "company":
            _text(
                row.get(
                    "company"
                )
            ),
        "forecast_error_class":
            _normalize_error_class(
                row.get(
                    "forecast_error_class"
                )
            ),
        "sample_size":
            int(
                _num(
                    row.get(
                        "sample_size"
                    )
                )
                or 0
            ),
        "error_count":
            int(
                _num(
                    row.get(
                        "error_count"
                    )
                )
                or 0
            ),
        "error_share":
            _stable_num(
                row.get(
                    "error_share"
                )
            ),
        "process_followed_count":
            int(
                _num(
                    row.get(
                        "process_followed_count"
                    )
                )
                or 0
            ),
        "process_other_count":
            int(
                _num(
                    row.get(
                        "process_other_count"
                    )
                )
                or 0
            ),
        "earliest_at":
            _text(
                row.get(
                    "earliest_at"
                )
            ),
        "latest_at":
            _text(
                row.get(
                    "latest_at"
                )
            ),
        "recurrence_status":
            _text(
                row.get(
                    "recurrence_status"
                )
            ).upper(),
        "review_lane":
            _text(
                row.get(
                    "review_lane"
                )
            ).upper(),
    }

    return _hash(
        payload
    )


def validate_forecast_change_plan(
    cohort_row: dict | None,
    *,
    change_area: str,
    change_target: str,
    baseline_description: str,
    proposed_change: str,
    expected_improvement: str,
    proof_date: str,
    source_pattern_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()
    row = cohort_row or {}
    issues = []

    recurrence_status = _text(
        row.get(
            "recurrence_status"
        )
    ).upper()
    error_class = _normalize_error_class(
        row.get(
            "forecast_error_class"
        )
    )

    if recurrence_status != "REVIEW":
        issues.append(
            "RECURRING_PATTERN_REQUIRED"
        )

    expected_area = expected_change_area(
        error_class
    )
    selected_area = _text(
        change_area
    ).upper()

    if selected_area not in FORECAST_CHANGE_AREAS:
        issues.append(
            "CHANGE_AREA_REQUIRED"
        )
    elif selected_area != expected_area:
        issues.append(
            "CHANGE_AREA_ERROR_CLASS_MISMATCH"
        )

    if not _text(
        change_target
    ):
        issues.append(
            "CHANGE_TARGET_REQUIRED"
        )

    if not _text(
        baseline_description
    ):
        issues.append(
            "BASELINE_DESCRIPTION_REQUIRED"
        )

    if not _text(
        proposed_change
    ):
        issues.append(
            "PROPOSED_CHANGE_REQUIRED"
        )

    if not _text(
        expected_improvement
    ):
        issues.append(
            "EXPECTED_IMPROVEMENT_REQUIRED"
        )

    proof_ts = pd.to_datetime(
        proof_date,
        errors="coerce",
    )

    if pd.isna(
        proof_ts
    ):
        issues.append(
            "PROOF_DATE_REQUIRED"
        )
    elif proof_ts.date() <= current_date:
        issues.append(
            "PROOF_DATE_MUST_BE_FUTURE"
        )

    confirmations = {
        "SOURCE_PATTERN_CONFIRMATION_REQUIRED":
            source_pattern_confirmed,
        "NO_AUTO_APPLY_CONFIRMATION_REQUIRED":
            no_auto_apply_confirmed,
        "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED":
            no_execution_authorization_confirmed,
        "HUMAN_REVIEW_CONFIRMATION_REQUIRED":
            human_review_confirmed,
    }

    for issue, passed in confirmations.items():
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    plan_gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    return {
        "plan_gate":
            plan_gate,
        "plan_status":
            (
                "REGISTERED_FOR_IMPLEMENTATION_REVIEW"
                if plan_gate == "PASS"
                else "DRAFT"
            ),
        "implementation_status":
            "NOT_IMPLEMENTED",
        "expected_change_area":
            expected_area,
        "next_gate":
            change_next_gate(
                selected_area
            ),
        "go_to":
            change_go_to(
                selected_area
            ),
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _record_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "source_pattern_confirmed",
        "no_auto_apply_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }
    number_fields = {
        "source_error_share",
    }

    payload = {}

    for field in FORECAST_CHANGE_PLAN_COLS:
        if field == "record_hash":
            continue

        if field in bool_fields:
            payload[field] = bool(
                _bool(
                    row.get(
                        field
                    )
                )
            )
        elif field in number_fields:
            payload[field] = _stable_num(
                row.get(
                    field
                )
            )
        else:
            payload[field] = _text(
                row.get(
                    field
                )
            )

    return payload


def build_forecast_change_plan_record(
    cohort_row: dict,
    validation: dict,
    *,
    change_area: str,
    change_target: str,
    baseline_description: str,
    proposed_change: str,
    expected_improvement: str,
    proof_date: str,
    source_pattern_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    row = cohort_row or {}
    review = validation or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    source_hash = cohort_snapshot_hash(
        row
    )

    plan_id = (
        "FCP-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + source_hash[:8]
    )

    record = {
        "change_plan_id":
            plan_id,
        "created_at":
            now,
        "scope":
            _text(
                row.get(
                    "scope"
                )
            ),
        "company":
            _text(
                row.get(
                    "company"
                )
            ),
        "forecast_error_class":
            _normalize_error_class(
                row.get(
                    "forecast_error_class"
                )
            ),
        "source_sample_size":
            int(
                _num(
                    row.get(
                        "sample_size"
                    )
                )
                or 0
            ),
        "source_error_count":
            int(
                _num(
                    row.get(
                        "error_count"
                    )
                )
                or 0
            ),
        "source_error_share":
            float(
                _num(
                    row.get(
                        "error_share"
                    )
                )
                or 0.0
            ),
        "source_recurrence_status":
            _text(
                row.get(
                    "recurrence_status"
                )
            ),
        "source_review_lane":
            _text(
                row.get(
                    "review_lane"
                )
            ),
        "source_cohort_hash":
            source_hash,
        "change_area":
            _text(
                change_area
            ).upper(),
        "change_target":
            _text(
                change_target
            ),
        "baseline_description":
            _text(
                baseline_description
            ),
        "proposed_change":
            _text(
                proposed_change
            ),
        "expected_improvement":
            _text(
                expected_improvement
            ),
        "proof_date":
            _text(
                proof_date
            ),
        "implementation_status":
            _text(
                review.get(
                    "implementation_status",
                    "NOT_IMPLEMENTED",
                )
            ),
        "source_pattern_confirmed":
            bool(
                source_pattern_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "plan_gate":
            _text(
                review.get(
                    "plan_gate"
                )
            ),
        "plan_status":
            _text(
                review.get(
                    "plan_status"
                )
            ),
        "next_gate":
            _text(
                review.get(
                    "next_gate"
                )
            ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                review.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    record[
        "record_hash"
    ] = _hash(
        _record_payload(
            record
        )
    )

    return record


def forecast_change_plan_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _record_payload(
            record
        )
    )

    return {
        "status":
            "OK"
            if stored
            == calculated
            else "MISMATCH",
        "calculated_hash":
            calculated,
    }


def build_forecast_change_queue(
    plans: pd.DataFrame | None,
    *,
    today: date | None = None,
) -> pd.DataFrame:
    current_date = today or date.today()

    if plans is None or plans.empty:
        return pd.DataFrame(
            columns=
            FORECAST_CHANGE_QUEUE_COLS
        )

    df = plans.copy()

    for col in FORECAST_CHANGE_PLAN_COLS:
        if col not in df.columns:
            df[
                col
            ] = ""

    rows = []

    for _, row in df.iterrows():
        item = row.to_dict()

        integrity = forecast_change_plan_integrity(
            item
        )

        proof_ts = pd.to_datetime(
            item.get(
                "proof_date"
            ),
            errors="coerce",
        )

        if pd.isna(
            proof_ts
        ):
            days_to_proof = None
        else:
            days_to_proof = (
                proof_ts.date()
                - current_date
            ).days

        if integrity[
            "status"
        ] != "OK":
            priority = "FC0"
            status = "INTEGRITY_REVIEW"
            issue = "FORECAST_CHANGE_PLAN_HASH_MISMATCH"
            next_action = "Forecast Change Plan Hash 무결성 확인"
        elif _text(
            item.get(
                "plan_status"
            )
        ).upper() != "REGISTERED_FOR_IMPLEMENTATION_REVIEW":
            priority = "FC0"
            status = "PLAN_REVIEW"
            issue = "FORECAST_CHANGE_PLAN_NOT_REGISTERED"
            next_action = "Decision Journal Forecast Calibration에서 Plan Human Review"
        elif _text(
            item.get(
                "implementation_status"
            )
        ).upper() == "NOT_IMPLEMENTED":
            priority = "FC1"
            status = "IMPLEMENTATION_REVIEW_PENDING"
            issue = "CHANGE_PLAN_NOT_IMPLEMENTED"
            next_action = (
                "원본 Model/Assumption/Process/Evidence Review에서 실제 변경 필요성을 독립 검토"
            )
        else:
            priority = "FC2"
            status = "IMPLEMENTATION_STATUS_REVIEW"
            issue = "IMPLEMENTATION_STATUS_NOT_RECOGNIZED"
            next_action = "Change Plan implementation 상태를 확인"

        rows.append(
            {
                "priority":
                    priority,
                "company":
                    _text(
                        item.get(
                            "company"
                        )
                    ),
                "forecast_error_class":
                    _text(
                        item.get(
                            "forecast_error_class"
                        )
                    ),
                "change_area":
                    _text(
                        item.get(
                            "change_area"
                        )
                    ),
                "plan_status":
                    _text(
                        item.get(
                            "plan_status"
                        )
                    ),
                "implementation_status":
                    _text(
                        item.get(
                            "implementation_status"
                        )
                    ),
                "proof_date":
                    _text(
                        item.get(
                            "proof_date"
                        )
                    ),
                "days_to_proof":
                    days_to_proof,
                "status":
                    status,
                "issue":
                    issue,
                "next_action":
                    next_action,
                "go_to":
                    change_go_to(
                        item.get(
                            "change_area"
                        )
                    ),
                "change_plan_id":
                    _text(
                        item.get(
                            "change_plan_id"
                        )
                    ),
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            FORECAST_CHANGE_QUEUE_COLS
        )

    out = pd.DataFrame(
        rows
    )

    priority_order = {
        "FC0": 0,
        "FC1": 1,
        "FC2": 2,
    }

    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        priority_order
    ).fillna(
        9
    )

    out = out.sort_values(
        [
            "_p",
            "days_to_proof",
            "company",
            "forecast_error_class",
        ],
        ascending=[
            True,
            True,
            True,
            True,
        ],
        na_position="last",
    ).drop(
        columns=[
            "_p"
        ]
    )

    return out[
        FORECAST_CHANGE_QUEUE_COLS
    ].reset_index(
        drop=True
    )
