from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_live_change_outcome_closure import (
    FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    live_change_outcome_closure_snapshot_integrity,
)
from engine.operations_flow_permanent_change_design import (
    FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    PERMANENT_CHANGE_DESIGN_STATES,
    PERMANENT_CHANGE_DESIGN_GUARD_BY_STATE,
    build_flow_permanent_change_design,
    permanent_change_design_snapshot_integrity,
    latest_permanent_change_design_snapshot,
)


PERMANENT_CHANGE_DESIGN_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

PERMANENT_CHANGE_DESIGN_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V151_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


V150_RELEASE_ZIP_SHA256 = (
    "f50d3733a72b5dc940b8ef91da591b44a4f41e9675087c26645b0174589775d4"
)

V150_RELEASE_MANIFEST_FILE_SHA256 = (
    "dd9502b85748721131eebc1d5c8c79e3d7bc205e1d4385cfe8176485d8422d9a"
)

V150_RELEASE_NOTES_FILE_SHA256 = (
    "e0f60b9e648d2b92a6c3d8e5c6ecfcfcc641d41815e385468e2a05eb78aebf69"
)

V150_BASELINE_PROVENANCE_REL = "release_baselines/v1_50_0.json"


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass

    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = (
        pd.DataFrame()
        if df is None
        else df.copy()
    )

    for col in cols:
        if col not in out.columns:
            out[col] = ""

    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1

        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def _sha256_path(
    path: Path,
) -> str:
    h = hashlib.sha256()

    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(
                1024 * 1024
            ),
            b"",
        ):
            h.update(chunk)

    return h.hexdigest()


def verify_v150_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(
        code_root
    ).resolve()

    provenance_path = (
        root
        / V150_BASELINE_PROVENANCE_REL
    )

    record = {}
    record_ok = False
    record_detail = ""

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            record_detail = (
                f"{type(exc).__name__}: {exc}"
            )
        else:
            record_ok = (
                _text(
                    record.get(
                        "release_version"
                    )
                )
                == "v1.50.0"
                and _text(
                    record.get(
                        "release_zip_sha256"
                    )
                ).lower()
                == V150_RELEASE_ZIP_SHA256
                and _text(
                    record.get(
                        "manifest_file_sha256"
                    )
                ).lower()
                == V150_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get(
                        "release_notes_file_sha256"
                    )
                ).lower()
                == V150_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get(
                        "provenance_status"
                    )
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )

            record_detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    manifest_path = (
        root
        / "manifest_sha256.json"
    )

    notes_path = (
        root
        / "RELEASE_NOTES_v1_50_0.txt"
    )

    legacy_manifest_ok = (
        manifest_path.is_file()
        and _sha256_path(
            manifest_path
        )
        == V150_RELEASE_MANIFEST_FILE_SHA256
    )

    legacy_notes_ok = (
        notes_path.is_file()
        and _sha256_path(
            notes_path
        )
        == V150_RELEASE_NOTES_FILE_SHA256
    )

    original_artifacts_ok = (
        legacy_manifest_ok
        and legacy_notes_ok
    )

    verified = (
        record_ok
        or original_artifacts_ok
    )

    source = (
        "PROVENANCE_RECORD"
        if record_ok
        else (
            "ORIGINAL_V150_RELEASE_ARTIFACTS"
            if original_artifacts_ok
            else "NONE"
        )
    )

    return {
        "status": (
            "VERIFIED"
            if verified
            else "BLOCKED"
        ),
        "verified": verified,
        "source": source,
        "record_path": str(
            provenance_path
        ),
        "record_detail": record_detail,
        "release_version": "v1.50.0",
        "release_zip_sha256":
            V150_RELEASE_ZIP_SHA256,
        "manifest_file_sha256":
            V150_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256":
            V150_RELEASE_NOTES_FILE_SHA256,
        "original_manifest_match":
            legacy_manifest_ok,
        "original_release_notes_match":
            legacy_notes_ok,
    }


def build_v151_permanent_change_design_context(
    *,
    v150_context: dict | None,
    permanent_change_design_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v150_context or {}
    closure = upstream.get("closure") or {}

    closure_df = _ensure_cols(
        upstream.get(
            "live_change_closure_snapshots"
        ),
        FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    )

    design_df = _ensure_cols(
        permanent_change_design_snapshots,
        FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    design = build_flow_permanent_change_design(
        closure,
        closure_df,
        design_df,
    )

    latest_design = latest_permanent_change_design_snapshot(
        design_df
    )

    latest_integrity = (
        _text(
            permanent_change_design_snapshot_integrity(
                latest_design
            ).get("status")
        ).upper()
        if latest_design
        else "NONE"
    )

    return {
        "v150_context": upstream,
        "closure": closure,
        "live_change_closure_snapshots": closure_df,
        "permanent_change_design_snapshots": design_df,
        "design": design,
        "design_integrity": _integrity_counts(
            design_df,
            permanent_change_design_snapshot_integrity,
        ),
        "latest_design": latest_design,
        "latest_design_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail": detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def _closure_routing_ok(
    design: dict,
    closure: dict,
) -> bool:
    state = _text(
        design.get("design_state")
    ).upper()

    closure_state = _text(
        closure.get("closure_state")
    ).upper()

    if closure_state in {
        "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
        "LIVE_CHANGE_CLOSURE_REJECTED",
        "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
    }:
        return (
            state
            == "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED"
        )

    if closure_state == "LIVE_CHANGE_CLOSURE_DEFERRED":
        return (
            state
            == "PERMANENT_CHANGE_DESIGN_DEFERRED"
        )

    if closure_state != (
        "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
    ):
        return (
            state
            == "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT"
        )

    return state in {
        "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
        "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
        "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED",
        "PERMANENT_CHANGE_DESIGN_REQUIRED",
        "PERMANENT_CHANGE_DESIGN_LOCKED",
    }


def _closure_source_mapping_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    state = _text(
        design.get("design_state")
    ).upper()

    source_id = _text(
        design.get(
            "source_live_change_closure_id"
        )
    )

    source_hash = _text(
        design.get(
            "source_live_change_closure_hash"
        )
    )

    if state in {
        "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT",
        "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
        "PERMANENT_CHANGE_DESIGN_DEFERRED",
    }:
        return (
            not source_id
            and not source_hash
        )

    if state == "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED":
        return (
            not source_id
            and not source_hash
        )

    if not source_id or not source_hash:
        return False

    index, duplicates = _index_by_id(
        context.get(
            "live_change_closure_snapshots"
        ),
        "live_change_outcome_closure_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    return (
        bool(parent)
        and _text(
            live_change_outcome_closure_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("decision")
        ).upper()
        == "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
        and _text(
            parent.get(
                "permanent_change_design_permission"
            )
        ).upper()
        == "PERMANENT_DESIGN_REVIEW_ONLY"
    )


def _source_business_contract_ok(
    design: dict,
) -> bool:
    state = _text(
        design.get("design_state")
    ).upper()

    if state in {
        "PERMANENT_CHANGE_DESIGN_UPSTREAM_WAIT",
        "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
        "PERMANENT_CHANGE_DESIGN_DEFERRED",
        "PERMANENT_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
        "PERMANENT_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
    }:
        return True

    scope = _text(
        design.get("proposal_scope")
    ).upper()

    baseline = _float(
        design.get("baseline_value")
    )

    candidate = _float(
        design.get("candidate_value")
    )

    rollback = _float(
        design.get("rollback_target_value")
    )

    if scope == "PARAMETER_SHADOW":
        return (
            baseline > 0
            and candidate > 0
            and abs(
                candidate
                - baseline
            )
            > 1e-12
            and abs(
                rollback
                - baseline
            )
            <= 1e-9
        )

    if scope == "MODEL_SHADOW":
        return (
            len(
                _text(
                    design.get("artifact_ref")
                )
            )
            >= 10
        )

    return False


def _locked_design_contract_ok(
    design: dict,
) -> bool:
    state = _text(
        design.get("design_state")
    ).upper()

    if state != "PERMANENT_CHANGE_DESIGN_LOCKED":
        return True

    latest = design.get(
        "latest_design"
    ) or {}

    if not latest:
        return False

    confirmations = [
        "source_reviewed",
        "post_change_evidence_reviewed",
        "baseline_locked_confirmed",
        "candidate_artifact_verified",
        "staged_rollout_confirmed",
        "reversible_rollout_confirmed",
        "rollback_path_confirmed",
        "monitoring_plan_confirmed",
        "separate_apply_gate_required_confirmed",
        "no_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            latest.get(field)
        )
        for field in confirmations
    ):
        return False

    target_scope = _float(
        latest.get(
            "target_scope_pct"
        )
    )

    stage_scope = _float(
        latest.get(
            "initial_stage_scope_pct"
        )
    )

    stages = _int(
        latest.get(
            "rollout_stage_count"
        )
    )

    proof_days = _int(
        latest.get(
            "proof_clock_days"
        )
    )

    min_outcomes = _int(
        latest.get(
            "min_post_change_outcomes"
        )
    )

    degradation = _float(
        latest.get(
            "max_relative_error_degradation_pct"
        )
    )

    rollback_hours = _int(
        latest.get(
            "rollback_observation_hours"
        )
    )

    details_ok = all(
        len(
            _text(
                latest.get(field)
            )
        )
        >= 60
        for field in [
            "design_detail",
            "rollout_detail",
            "rollback_detail",
            "monitoring_detail",
        ]
    )

    return (
        0
        < target_scope
        <= 1.0
        and 0
        < stage_scope
        <= 0.10
        and stage_scope
        <= target_scope
        and 2
        <= stages
        <= 10
        and 7
        <= proof_days
        <= 365
        and min_outcomes
        >= 5
        and 0
        <= degradation
        <= 0.10
        and 24
        <= rollback_hours
        <= 720
        and details_ok
        and _text(
            latest.get(
                "permanent_change_design_permission"
            )
        ).upper()
        == "PERMANENT_DESIGN_LOCKED_NO_APPLY"
    )


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    latest = context.get(
        "latest_design"
    ) or {}

    state = _text(
        design.get("design_state")
    ).upper()

    if not latest:
        return True

    source_ts = pd.to_datetime(
        design.get(
            "source_live_change_closure_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    design_ts = pd.to_datetime(
        latest.get("created_at"),
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_ts)
        or pd.isna(design_ts)
        or design_ts <= source_ts
    ):
        return False

    if state == "PERMANENT_CHANGE_DESIGN_SOURCE_SUPERSEDED":
        return (
            _text(
                latest.get(
                    "source_live_change_closure_id"
                )
            )
            != _text(
                design.get(
                    "source_live_change_closure_id"
                )
            )
            or _text(
                latest.get(
                    "source_live_change_closure_hash"
                )
            )
            != _text(
                design.get(
                    "source_live_change_closure_hash"
                )
            )
        )

    if state == "PERMANENT_CHANGE_DESIGN_LOCKED":
        return (
            _text(
                latest.get(
                    "source_live_change_closure_id"
                )
            )
            == _text(
                design.get(
                    "source_live_change_closure_id"
                )
            )
            and _text(
                latest.get(
                    "source_live_change_closure_hash"
                )
            )
            == _text(
                design.get(
                    "source_live_change_closure_hash"
                )
            )
        )

    return True


def _no_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("design") or {},
        context.get("latest_design") or {},
        context.get("closure") or {},
    ]:
        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "permanent_change_authorization",
            "live_change_closure_authorization",
            "live_change_outcome_authorization",
            "live_change_runtime_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "permanent_change_design_snapshots"
    )

    if (
        isinstance(
            history,
            pd.DataFrame,
        )
        and not history.empty
    ):
        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (
                    ~values.isin(
                        ["", "NONE"]
                    )
                ).sum()
            )

    return (
        violations == 0
        and _text(
            context.get(
                "execution_authorization"
            )
        ).upper()
        == "NONE"
    )


def build_v151_permanent_change_design_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    design = ctx.get("design") or {}
    closure = ctx.get("closure") or {}
    counts = ctx.get(
        "design_integrity"
    ) or {}

    state = _text(
        design.get("design_state")
    ).upper()

    guard = _text(
        design.get("design_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Permanent Change Design Snapshot Integrity",
            (
                _int(
                    counts.get("missing")
                )
                == 0
                and _int(
                    counts.get("mismatch")
                )
                == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Permanent Change Design immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Change Design State / Guard Vocabulary",
            (
                state
                in PERMANENT_CHANGE_DESIGN_STATES
                and guard
                == PERMANENT_CHANGE_DESIGN_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {PERMANENT_CHANGE_DESIGN_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Permanent Change Design state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Human Closure → Permanent Design State Invariant",
            _closure_routing_ok(
                design,
                closure,
            ),
            (
                f"closure {_text(closure.get('closure_state')) or 'MISSING'} · "
                f"design {state or 'MISSING'}"
            ),
            "Human Closure와 Permanent Design state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Design → Immutable Closure Source Mapping",
            _closure_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"closure source {_text(design.get('source_live_change_closure_id')) or 'NONE'} · "
                f"integrity {_text(design.get('source_live_change_closure_integrity')) or 'NONE'}"
            ),
            "Permanent Design source Closure id/hash/integrity/decision/permission 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Candidate / Baseline / Rollback Invariant",
            _source_business_contract_ok(
                design
            ),
            (
                f"scope {_text(design.get('proposal_scope')) or 'NONE'} · "
                f"baseline {_float(design.get('baseline_value')):.4f} · "
                f"candidate {_float(design.get('candidate_value')):.4f} · "
                f"rollback {_float(design.get('rollback_target_value')):.4f}"
            ),
            "Permanent candidate source와 locked prior baseline/rollback target 확인",
        )
    )

    checks.append(
        _technical_row(
            "Staged Rollout / Proof Clock / Monitoring Invariant",
            _locked_design_contract_ok(
                design
            ),
            (
                f"state {state or 'MISSING'} · "
                f"target {_float(design.get('target_scope_pct')):.1%} · "
                f"stage1 {_float(design.get('initial_stage_scope_pct')):.1%} · "
                f"stages {_int(design.get('rollout_stage_count'))} · "
                f"proof {_int(design.get('proof_clock_days'))}d"
            ),
            "Staged rollout, reversible design, proof clock, monitoring, separate apply gate 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Design Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(design.get('source_live_change_closure_created_at')) or 'NONE'} · "
                f"latest {_text((ctx.get('latest_design') or {}).get('created_at')) or 'NONE'}"
            ),
            "Human Closure 이후 Design 저장 및 source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Design No-Apply / No-Execution Authorization Invariant",
            _no_authorization_ok(
                ctx
            ),
            "NONE",
            "Permanent Design/Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"]
        == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
            "PERMANENT_CHANGE_DESIGN_DEFERRED",
            "PERMANENT_CHANGE_DESIGN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Permanent Change Design Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"permission {_text(design.get('permanent_change_design_permission')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status
                == "PASS"
                else (
                    "정상 upstream/source/design-review/supersession 상태는 Technical FAIL로 승격하지 않고 "
                    "Human Closure/Design evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail
            == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"]
                == "TECHNICAL"
                and row["status"]
                == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "design_state": state,
        "closure_state": _text(
            closure.get("closure_state")
        ).upper(),
        "latest_permanent_change_design_integrity":
            _text(
                ctx.get(
                    "latest_design_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=
                PERMANENT_CHANGE_DESIGN_RELEASE_CHECK_COLS,
        ),
        "execution_authorization":
            "NONE",
    }


def _saved_design_contract_ok(
    item: dict,
) -> bool:
    state = _text(
        item.get("design_state")
    ).upper()

    guard = _text(
        item.get("design_guard")
    ).upper()

    if (
        state
        != "PERMANENT_CHANGE_DESIGN_LOCKED"
        or guard
        != "PERMANENT_CHANGE_DESIGN_LOCKED_NO_APPLY"
    ):
        return False

    if _text(
        item.get(
            "permanent_change_design_permission"
        )
    ).upper() != "PERMANENT_DESIGN_LOCKED_NO_APPLY":
        return False

    confirmations = [
        "source_reviewed",
        "post_change_evidence_reviewed",
        "baseline_locked_confirmed",
        "candidate_artifact_verified",
        "staged_rollout_confirmed",
        "reversible_rollout_confirmed",
        "rollback_path_confirmed",
        "monitoring_plan_confirmed",
        "separate_apply_gate_required_confirmed",
        "no_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            item.get(field)
        )
        for field in confirmations
    ):
        return False

    if not (
        0
        < _float(
            item.get("target_scope_pct")
        )
        <= 1.0
    ):
        return False

    stage = _float(
        item.get(
            "initial_stage_scope_pct"
        )
    )

    target = _float(
        item.get(
            "target_scope_pct"
        )
    )

    if not (
        0
        < stage
        <= 0.10
        and stage
        <= target
    ):
        return False

    if not (
        2
        <= _int(
            item.get(
                "rollout_stage_count"
            )
        )
        <= 10
    ):
        return False

    if not (
        7
        <= _int(
            item.get(
                "proof_clock_days"
            )
        )
        <= 365
    ):
        return False

    if _int(
        item.get(
            "min_post_change_outcomes"
        )
    ) < 5:
        return False

    degradation = _float(
        item.get(
            "max_relative_error_degradation_pct"
        )
    )

    if not (
        0
        <= degradation
        <= 0.10
    ):
        return False

    if not (
        24
        <= _int(
            item.get(
                "rollback_observation_hours"
            )
        )
        <= 720
    ):
        return False

    if not all(
        len(
            _text(
                item.get(field)
            )
        )
        >= 60
        for field in [
            "design_detail",
            "rollout_detail",
            "rollback_detail",
            "monitoring_detail",
        ]
    ):
        return False

    scope = _text(
        item.get("proposal_scope")
    ).upper()

    if scope == "PARAMETER_SHADOW":
        baseline = _float(
            item.get("baseline_value")
        )
        candidate = _float(
            item.get("candidate_value")
        )
        rollback = _float(
            item.get(
                "rollback_target_value"
            )
        )

        if not (
            baseline > 0
            and candidate > 0
            and abs(
                candidate
                - baseline
            )
            > 1e-12
            and abs(
                rollback
                - baseline
            )
            <= 1e-9
        ):
            return False

    elif scope == "MODEL_SHADOW":
        if len(
            _text(
                item.get("artifact_ref")
            )
        ) < 10:
            return False

    else:
        return False

    return True


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail": detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def build_v151_permanent_change_design_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    design_df = _ensure_cols(
        ctx.get(
            "permanent_change_design_snapshots"
        ),
        FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    closure_df = _ensure_cols(
        ctx.get(
            "live_change_closure_snapshots"
        ),
        FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        design_df,
        permanent_change_design_snapshot_integrity,
    )

    closure_index, closure_duplicates = _index_by_id(
        closure_df,
        "live_change_outcome_closure_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in design_df.iterrows():
        item = row.to_dict()

        design_id = _text(
            item.get(
                "permanent_change_design_id"
            )
        )

        if design_id:
            if design_id in seen_ids:
                identity_duplicates += 1

            seen_ids.add(
                design_id
            )

        if not _saved_design_contract_ok(
            item
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_live_change_closure_id"
            )
        )

        source_hash = _text(
            item.get(
                "source_live_change_closure_hash"
            )
        )

        parent = closure_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                live_change_outcome_closure_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("decision")
            ).upper()
            != "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
            or _text(
                parent.get(
                    "permanent_change_design_permission"
                )
            ).upper()
            != "PERMANENT_DESIGN_REVIEW_ONLY"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )

            design_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(design_ts)
                or design_ts
                <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {
                "",
                "NONE",
            }:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Permanent Change Design Audit Snapshot Integrity",
            (
                _int(
                    counts.get("missing")
                )
                == 0
                and _int(
                    counts.get("mismatch")
                )
                == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Permanent Change Design immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Design Audit Staged-Rollout Contract",
            contract_violations
            == 0,
            (
                f"contract violations {contract_violations}"
            ),
            "Design lock confirmations, staged rollout, proof clock, monitoring contract 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Design Audit → Human Closure Lineage",
            (
                lineage_violations
                == 0
                and closure_duplicates
                == 0
            ),
            (
                f"lineage violations {lineage_violations} · "
                f"closure duplicate ids {closure_duplicates}"
            ),
            "Design source immutable Human Closure id/hash/decision/permission lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Design Audit Identity / Time-order Invariant",
            (
                identity_duplicates
                == 0
                and time_order_violations
                == 0
            ),
            (
                f"duplicate design ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Design audit identity uniqueness 및 Human Closure 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Design Audit No-Apply Authorization Invariant",
            authorization_violations
            == 0,
            (
                "NONE"
                if authorization_violations
                == 0
                else f"non-NONE sources {authorization_violations}"
            ),
            "Permanent Design/Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"]
        == "FAIL"
    )

    current_state = _text(
        (
            ctx.get("design")
            or {}
        ).get(
            "design_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED",
            "PERMANENT_CHANGE_DESIGN_DEFERRED",
            "PERMANENT_CHANGE_DESIGN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Permanent Change Design Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current design {current_state or 'MISSING'} · "
                f"saved designs {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status
                == "PASS"
                else (
                    "실제 Human Closure ACCEPT 이후 Permanent Design lock이 필요할 때만 "
                    "immutable design history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail
            == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"]
                == "TECHNICAL"
                and row["status"]
                == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=
                PERMANENT_CHANGE_DESIGN_AUDIT_CHECK_COLS,
        ),
        "execution_authorization":
            "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v151_release_readiness(
    *,
    v150_release_status: str,
    v150_baseline_provenance: dict | None,
    integration_consistency: str,
    csv_fail_count: int,
    design_release_gate: str,
    design_audit_gate: str,
    work_ready_release_gate: str,
    design_operating_status: str,
    audit_operating_status: str,
    work_ready_operating_status: str,
    execution_authorization: str,
) -> dict:
    provenance = (
        v150_baseline_provenance
        or {}
    )

    checks = [
        _candidate_row(
            "v1.50 Immutable Release Baseline Provenance",
            bool(
                provenance.get(
                    "verified"
                )
            ),
            (
                f"{_text(provenance.get('status')) or 'MISSING'} · "
                f"source {_text(provenance.get('source')) or 'NONE'} · "
                f"dynamic-v1.50 {_text(v150_release_status).upper() or 'MISSING'}"
            ),
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Permanent Change Design Technical Release Gate",
            _text(
                design_release_gate
            ).upper()
            == "PASS",
            _text(
                design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Design Audit Integrity Gate",
            _text(
                design_audit_gate
            ).upper()
            == "PASS",
            _text(
                design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Software Update Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"]
        != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            design_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "PERMANENT_CHANGE_DESIGN_REVIEW"
        )

    if _text(
        work_ready_operating_status
    ).upper() != "PASS":
        operating_reviews.append(
            "WORK_READY_RELEASE_MANAGER_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=
                V151_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization":
            "NONE",
    }


def build_v151_integration_crosscheck(
    *,
    integration_consistency: str,
    design_release_gate: str,
    design_audit_gate: str,
    work_ready_release_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Design Technical Gate",
            _text(
                design_release_gate
            ).upper()
            == "PASS",
            _text(
                design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Design Audit Gate",
            _text(
                design_audit_gate
            ).upper()
            == "PASS",
            _text(
                design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"]
        != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=
                V151_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization":
            "NONE",
    }


def build_v151_data_crosscheck(
    *,
    csv_fail_count: int,
    design_release_gate: str,
    design_audit_gate: str,
    work_ready_release_gate: str,
    latest_design_integrity: str,
) -> dict:
    latest = _text(
        latest_design_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Permanent Change Design Technical Gate",
            _text(
                design_release_gate
            ).upper()
            == "PASS",
            _text(
                design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Design Audit Gate",
            _text(
                design_audit_gate
            ).upper()
            == "PASS",
            _text(
                design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Permanent Change Design Audit Integrity",
            latest
            in {
                "OK",
                "NONE",
            },
            latest
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"]
        != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=
                V151_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization":
            "NONE",
    }
