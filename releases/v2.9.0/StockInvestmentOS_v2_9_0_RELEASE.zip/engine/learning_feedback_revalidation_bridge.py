from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.learning_feedback_governance import (
    learning_feedback_record_integrity,
)
from engine.capital_productivity import (
    normalize_capital_productivity_inputs,
)
from engine.capital_productivity_revalidation import (
    assumption_fingerprint,
)


LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS = [
    "bridge_id",
    "created_at",
    "feedback_id",
    "feedback_record_hash",
    "feedback_integrity_status",
    "company",
    "feedback_target",
    "change_direction",
    "proposed_delta",
    "source_next_gate",
    "bridge_route",
    "current_forward_er",
    "current_risk_penalty",
    "current_hurdle_rate",
    "proposed_forward_er",
    "proposed_risk_penalty",
    "proposed_hurdle_rate",
    "current_assumption_fingerprint",
    "assumption_health_status",
    "assumption_provenance_type",
    "source_review_due_date",
    "source_rationale",
    "current_values_confirmed",
    "route_confirmed",
    "proposal_only_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "bridge_gate",
    "draft_status",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


LEARNING_FEEDBACK_BRIDGE_QUEUE_COLS = [
    "priority",
    "bucket",
    "due_date",
    "days_to_due",
    "category",
    "subject",
    "target",
    "direction",
    "status",
    "issue",
    "next_action",
    "go_to",
    "feedback_id",
    "bridge_id",
    "bridge_route",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _stable_num(
    value: Any,
    places: int = 12,
) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _lookup_subject(
    df: pd.DataFrame | None,
    company: str,
) -> dict:
    if df is None or df.empty:
        return {}
    if "name" not in df.columns:
        return {}
    hit = df.loc[
        df["name"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(company)
        )
    ]
    if hit.empty:
        return {}
    return hit.iloc[-1].to_dict()


def feedback_bridge_route(
    feedback_target: str,
    change_direction: str,
) -> dict:
    target = _text(
        feedback_target
    ).upper()
    direction = _text(
        change_direction
    ).upper()

    if target in {
        "FORWARD_ER",
        "RISK_PENALTY",
        "HURDLE",
    }:
        if direction in {
            "INCREASE",
            "DECREASE",
        }:
            return {
                "bridge_route":
                    "CAPITAL_PRODUCTIVITY_CALIBRATION",
                "go_to":
                    "Capital Productivity",
                "next_action":
                    "Calibration Range에서 새 Source/Evidence와 함께 값을 다시 검토",
            }
        return {
            "bridge_route":
                "CAPITAL_PRODUCTIVITY_REVALIDATION",
            "go_to":
                "Capital Productivity",
            "next_action":
                "Assumption Revalidation에서 값 변경 없는 재검토 적합성 확인",
        }

    mapping = {
        "THESIS": (
            "THESIS_REVALIDATION",
            "Thesis Monitor",
            "Thesis / Invalidation / KPI를 원본 화면에서 재검토",
        ),
        "POSITION_SIZE": (
            "RISK_BUDGET_REVIEW",
            "Position Sizing",
            "Position Size / Risk Budget을 원본 화면에서 재검토",
        ),
        "PROCESS": (
            "PROCESS_REVIEW",
            "Decision Journal",
            "Decision Process / Execution Error를 원본 기록에서 재검토",
        ),
        "EVIDENCE_MONITOR": (
            "EVIDENCE_REVIEW",
            "Evidence Impact Review",
            "새 Primary Source / Evidence Impact를 재검토",
        ),
        "NO_CHANGE": (
            "NO_CHANGE_REVIEW",
            "Decision Journal",
            "No-change 근거와 다음 Proof Clock을 검토",
        ),
    }

    route, go_to, next_action = mapping.get(
        target,
        (
            "REVIEW_REQUIRED",
            "Review Queue",
            "Feedback Target route를 Human Review",
        ),
    )
    return {
        "bridge_route": route,
        "go_to": go_to,
        "next_action": next_action,
    }


def build_feedback_revalidation_context(
    feedback_row: dict | None,
    capital_productivity_inputs: pd.DataFrame | None,
    assumption_health: pd.DataFrame | None = None,
) -> dict:
    feedback = feedback_row or {}
    issues = []

    integrity = learning_feedback_record_integrity(
        feedback
    )
    status = _text(
        feedback.get(
            "proposal_status"
        )
    ).upper()

    if integrity["status"] != "OK":
        issues.append(
            "LEARNING_FEEDBACK_INTEGRITY_FAILED"
        )

    if status != "APPROVED_FOR_REVALIDATION":
        issues.append(
            "APPROVED_FOR_REVALIDATION_REQUIRED"
        )

    if _text(
        feedback.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    company = _text(
        feedback.get(
            "company"
        )
    )
    target = _text(
        feedback.get(
            "feedback_target"
        )
    ).upper()
    direction = _text(
        feedback.get(
            "change_direction"
        )
    ).upper()
    delta = _num(
        feedback.get(
            "proposed_delta"
        )
    )

    route = feedback_bridge_route(
        target,
        direction,
    )

    cp_inputs = normalize_capital_productivity_inputs(
        capital_productivity_inputs
    )
    input_row = _lookup_subject(
        cp_inputs,
        company,
    )
    health_row = _lookup_subject(
        assumption_health,
        company,
    )

    numeric_target = target in {
        "FORWARD_ER",
        "RISK_PENALTY",
        "HURDLE",
    }

    if numeric_target and not input_row:
        issues.append(
            "CAPITAL_PRODUCTIVITY_ASSUMPTION_NOT_FOUND"
        )

    current_forward_er = _num(
        input_row.get(
            "forward_er"
        )
    )
    current_risk_penalty = _num(
        input_row.get(
            "risk_penalty"
        )
    )
    current_hurdle = _num(
        input_row.get(
            "hurdle_rate"
        )
    )

    proposed_forward_er = current_forward_er
    proposed_risk_penalty = current_risk_penalty
    proposed_hurdle = current_hurdle

    current_value = None
    if target == "FORWARD_ER":
        current_value = current_forward_er
    elif target == "RISK_PENALTY":
        current_value = current_risk_penalty
    elif target == "HURDLE":
        current_value = current_hurdle

    proposed_value = current_value

    if numeric_target:
        if current_value is None:
            issues.append(
                "CURRENT_TARGET_VALUE_REQUIRED"
            )
        elif direction in {
            "INCREASE",
            "DECREASE",
        }:
            if delta is None or delta <= 0:
                issues.append(
                    "POSITIVE_PROPOSED_DELTA_REQUIRED"
                )
            else:
                signed = (
                    delta
                    if direction == "INCREASE"
                    else -delta
                )
                proposed_value = (
                    current_value
                    + signed
                )
                if (
                    target in {
                        "RISK_PENALTY",
                        "HURDLE",
                    }
                    and proposed_value < 0
                ):
                    issues.append(
                        "PROPOSED_VALUE_BELOW_ZERO"
                    )

        if target == "FORWARD_ER":
            proposed_forward_er = proposed_value
        elif target == "RISK_PENALTY":
            proposed_risk_penalty = proposed_value
        elif target == "HURDLE":
            proposed_hurdle = proposed_value

    current_fingerprint = (
        assumption_fingerprint(
            input_row
        )
        if input_row
        else ""
    )

    return {
        "feedback_id": _text(
            feedback.get(
                "feedback_id"
            )
        ),
        "feedback_record_hash": _text(
            feedback.get(
                "record_hash"
            )
        ),
        "feedback_integrity_status":
            integrity["status"],
        "feedback_status": status,
        "company": company,
        "feedback_target": target,
        "change_direction": direction,
        "proposed_delta": delta,
        "source_next_gate": _text(
            feedback.get(
                "next_gate"
            )
        ),
        "bridge_route": route[
            "bridge_route"
        ],
        "go_to": route[
            "go_to"
        ],
        "next_action": route[
            "next_action"
        ],
        "current_forward_er":
            current_forward_er,
        "current_risk_penalty":
            current_risk_penalty,
        "current_hurdle_rate":
            current_hurdle,
        "proposed_forward_er":
            proposed_forward_er,
        "proposed_risk_penalty":
            proposed_risk_penalty,
        "proposed_hurdle_rate":
            proposed_hurdle,
        "current_assumption_fingerprint":
            current_fingerprint,
        "assumption_health_status": _text(
            health_row.get(
                "health_status"
            )
        ).upper(),
        "assumption_provenance_type": _text(
            health_row.get(
                "provenance_type"
            )
        ).upper(),
        "source_review_due_date": _text(
            feedback.get(
                "review_due_date"
            )
        ),
        "source_rationale": _text(
            feedback.get(
                "rationale"
            )
        ),
        "numeric_target":
            numeric_target,
        "context_gate": (
            "PASS"
            if not issues
            else "REVIEW"
        ),
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def validate_feedback_revalidation_draft(
    context: dict,
    *,
    current_values_confirmed: bool,
    route_confirmed: bool,
    proposal_only_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    ctx = context or {}
    issues = []

    if _text(
        ctx.get(
            "context_gate"
        )
    ).upper() != "PASS":
        issues.append(
            "BRIDGE_CONTEXT_NOT_READY"
        )

    if not bool(
        ctx.get(
            "numeric_target"
        )
    ):
        issues.append(
            "NON_ASSUMPTION_TARGET_USE_REVIEW_QUEUE_ROUTE"
        )

    confirmations = {
        "CURRENT_VALUES_CONFIRMATION_REQUIRED":
            current_values_confirmed,
        "BRIDGE_ROUTE_CONFIRMATION_REQUIRED":
            route_confirmed,
        "PROPOSAL_ONLY_CONFIRMATION_REQUIRED":
            proposal_only_confirmed,
        "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED":
            no_execution_authorization_confirmed,
        "HUMAN_REVIEW_CONFIRMATION_REQUIRED":
            human_review_confirmed,
    }

    for issue, passed in confirmations.items():
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    return {
        "bridge_gate":
            "PASS"
            if not issues
            else "REVIEW",
        "draft_status":
            "READY_FOR_SOURCE_REVIEW"
            if not issues
            else "DRAFT",
        "bridge_route": _text(
            ctx.get(
                "bridge_route"
            )
        ),
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _draft_hash_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "current_values_confirmed",
        "route_confirmed",
        "proposal_only_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }
    numeric_fields = {
        "proposed_delta",
        "current_forward_er",
        "current_risk_penalty",
        "current_hurdle_rate",
        "proposed_forward_er",
        "proposed_risk_penalty",
        "proposed_hurdle_rate",
    }

    payload = {}
    for field in LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS:
        if field == "record_hash":
            continue
        if field in bool_fields:
            payload[field] = bool(
                _bool(
                    row.get(
                        field
                    )
                )
            )
        elif field in numeric_fields:
            payload[field] = _stable_num(
                row.get(
                    field
                )
            )
        else:
            payload[field] = _text(
                row.get(
                    field
                )
            )
    return payload


def build_feedback_revalidation_draft_record(
    context: dict,
    review: dict,
    *,
    current_values_confirmed: bool,
    route_confirmed: bool,
    proposal_only_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    ctx = context or {}
    rv = review or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    feedback_id = _text(
        ctx.get(
            "feedback_id"
        )
    )

    bridge_id = (
        "LFR-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            (
                feedback_id
                + "|"
                + _text(
                    ctx.get(
                        "bridge_route"
                    )
                )
            ).encode(
                "utf-8"
            )
        ).hexdigest()[:8]
    )

    row = {
        "bridge_id": bridge_id,
        "created_at": now,
        "feedback_id":
            feedback_id,
        "feedback_record_hash": _text(
            ctx.get(
                "feedback_record_hash"
            )
        ),
        "feedback_integrity_status": _text(
            ctx.get(
                "feedback_integrity_status"
            )
        ),
        "company": _text(
            ctx.get(
                "company"
            )
        ),
        "feedback_target": _text(
            ctx.get(
                "feedback_target"
            )
        ),
        "change_direction": _text(
            ctx.get(
                "change_direction"
            )
        ),
        "proposed_delta": _num(
            ctx.get(
                "proposed_delta"
            )
        ),
        "source_next_gate": _text(
            ctx.get(
                "source_next_gate"
            )
        ),
        "bridge_route": _text(
            ctx.get(
                "bridge_route"
            )
        ),
        "current_forward_er": _num(
            ctx.get(
                "current_forward_er"
            )
        ),
        "current_risk_penalty": _num(
            ctx.get(
                "current_risk_penalty"
            )
        ),
        "current_hurdle_rate": _num(
            ctx.get(
                "current_hurdle_rate"
            )
        ),
        "proposed_forward_er": _num(
            ctx.get(
                "proposed_forward_er"
            )
        ),
        "proposed_risk_penalty": _num(
            ctx.get(
                "proposed_risk_penalty"
            )
        ),
        "proposed_hurdle_rate": _num(
            ctx.get(
                "proposed_hurdle_rate"
            )
        ),
        "current_assumption_fingerprint": _text(
            ctx.get(
                "current_assumption_fingerprint"
            )
        ),
        "assumption_health_status": _text(
            ctx.get(
                "assumption_health_status"
            )
        ),
        "assumption_provenance_type": _text(
            ctx.get(
                "assumption_provenance_type"
            )
        ),
        "source_review_due_date": _text(
            ctx.get(
                "source_review_due_date"
            )
        ),
        "source_rationale": _text(
            ctx.get(
                "source_rationale"
            )
        ),
        "current_values_confirmed":
            bool(
                current_values_confirmed
            ),
        "route_confirmed":
            bool(
                route_confirmed
            ),
        "proposal_only_confirmed":
            bool(
                proposal_only_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "bridge_gate": _text(
            rv.get(
                "bridge_gate"
            )
        ),
        "draft_status": _text(
            rv.get(
                "draft_status"
            )
        ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                rv.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _draft_hash_payload(
            row
        )
    )
    return row


def feedback_revalidation_draft_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _draft_hash_payload(
            record
        )
    )
    return {
        "status":
            "OK"
            if stored
            == calculated
            else "MISMATCH",
        "calculated_hash":
            calculated,
    }


def _bucket_for_due(
    due_value: Any,
    current_date: date,
) -> tuple[str, int | None]:
    parsed = pd.to_datetime(
        due_value,
        errors="coerce",
    )
    if pd.isna(parsed):
        return "NO DATE", None

    due = parsed.date()
    days = (
        due
        - current_date
    ).days

    if days < 0:
        return "OVERDUE", days
    if days == 0:
        return "TODAY", days
    if days <= 7:
        return "NEXT 7 DAYS", days
    if days <= 30:
        return "NEXT 30 DAYS", days
    return "FUTURE", days


def build_learning_feedback_bridge_queue(
    feedback_proposals: pd.DataFrame | None,
    bridge_drafts: pd.DataFrame | None,
    *,
    today: date | None = None,
) -> pd.DataFrame:
    current_date = today or date.today()

    if (
        feedback_proposals is None
        or feedback_proposals.empty
    ):
        return pd.DataFrame(
            columns=
            LEARNING_FEEDBACK_BRIDGE_QUEUE_COLS
        )

    proposals = feedback_proposals.copy()
    for col in [
        "feedback_id",
        "company",
        "feedback_target",
        "change_direction",
        "proposal_status",
        "review_due_date",
        "record_hash",
        "next_gate",
        "execution_authorization",
    ]:
        if col not in proposals.columns:
            proposals[
                col
            ] = ""

    drafts = (
        pd.DataFrame()
        if bridge_drafts is None
        else bridge_drafts.copy()
    )
    for col in LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS:
        if col not in drafts.columns:
            drafts[
                col
            ] = ""

    rows = []

    approved = proposals.loc[
        proposals[
            "proposal_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "APPROVED_FOR_REVALIDATION"
        )
    ].copy()

    for _, proposal in approved.iterrows():
        p = proposal.to_dict()
        feedback_id = _text(
            p.get(
                "feedback_id"
            )
        )
        company = _text(
            p.get(
                "company"
            )
        )
        target = _text(
            p.get(
                "feedback_target"
            )
        ).upper()
        direction = _text(
            p.get(
                "change_direction"
            )
        ).upper()

        integrity = learning_feedback_record_integrity(
            p
        )
        route = feedback_bridge_route(
            target,
            direction,
        )

        bucket, days = _bucket_for_due(
            p.get(
                "review_due_date"
            ),
            current_date,
        )

        draft_hit = drafts.loc[
            drafts[
                "feedback_id"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(
                feedback_id
            )
        ].copy()

        latest_draft = {}
        if not draft_hit.empty:
            sort = pd.to_datetime(
                draft_hit[
                    "created_at"
                ],
                errors="coerce",
                utc=True,
            )
            draft_hit = draft_hit.assign(
                _sort=sort
            ).sort_values(
                "_sort",
                ascending=False,
                na_position="last",
            )
            latest_draft = (
                draft_hit.iloc[0]
                .drop(
                    labels=[
                        "_sort"
                    ],
                    errors="ignore",
                )
                .to_dict()
            )

        if integrity["status"] != "OK":
            priority = "LF0"
            status = "INTEGRITY_REVIEW"
            issue = "LEARNING_FEEDBACK_RECORD_HASH_MISMATCH"
            next_action = (
                "Decision Journal Learning Feedback 원본 무결성 확인"
            )
            go_to = "Decision Journal"
            bridge_id = ""
        elif not latest_draft:
            priority = "LF1"
            status = "PENDING_DRAFT"
            issue = (
                "APPROVED_FEEDBACK_NOT_YET_BRIDGED"
            )
            next_action = (
                "Capital Productivity에서 Revalidation Draft 생성"
                if target in {
                    "FORWARD_ER",
                    "RISK_PENALTY",
                    "HURDLE",
                }
                else route[
                    "next_action"
                ]
            )
            go_to = (
                "Capital Productivity"
                if target in {
                    "FORWARD_ER",
                    "RISK_PENALTY",
                    "HURDLE",
                }
                else route[
                    "go_to"
                ]
            )
            bridge_id = ""
        else:
            draft_integrity = feedback_revalidation_draft_integrity(
                latest_draft
            )
            bridge_id = _text(
                latest_draft.get(
                    "bridge_id"
                )
            )

            if draft_integrity[
                "status"
            ] != "OK":
                priority = "LF0"
                status = "DRAFT_INTEGRITY_REVIEW"
                issue = "REVALIDATION_DRAFT_HASH_MISMATCH"
                next_action = (
                    "Learning Feedback Revalidation Draft 무결성 확인"
                )
                go_to = "Capital Productivity"
            elif _text(
                latest_draft.get(
                    "draft_status"
                )
            ).upper() == "READY_FOR_SOURCE_REVIEW":
                priority = "LF2"
                status = "SOURCE_REVIEW_PENDING"
                issue = (
                    "DRAFT_READY_SOURCE_REVIEW_NOT_AUTOMATIC"
                )
                next_action = route[
                    "next_action"
                ]
                go_to = route[
                    "go_to"
                ]
            else:
                priority = "LF1"
                status = "DRAFT_REVIEW"
                issue = "REVALIDATION_DRAFT_NOT_READY"
                next_action = (
                    "Bridge Draft Human Review 완료"
                )
                go_to = "Capital Productivity"

        rows.append(
            {
                "priority":
                    priority,
                "bucket":
                    bucket,
                "due_date":
                    _text(
                        p.get(
                            "review_due_date"
                        )
                    ),
                "days_to_due":
                    days,
                "category":
                    "Learning Feedback Bridge",
                "subject":
                    company,
                "target":
                    target,
                "direction":
                    direction,
                "status":
                    status,
                "issue":
                    issue,
                "next_action":
                    next_action,
                "go_to":
                    go_to,
                "feedback_id":
                    feedback_id,
                "bridge_id":
                    bridge_id,
                "bridge_route":
                    route[
                        "bridge_route"
                    ],
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            LEARNING_FEEDBACK_BRIDGE_QUEUE_COLS
        )

    out = pd.DataFrame(
        rows
    )

    priority_order = {
        "LF0": 0,
        "LF1": 1,
        "LF2": 2,
    }
    bucket_order = {
        "OVERDUE": 0,
        "TODAY": 1,
        "NEXT 7 DAYS": 2,
        "NEXT 30 DAYS": 3,
        "FUTURE": 4,
        "NO DATE": 5,
    }

    out["_priority"] = out[
        "priority"
    ].map(
        priority_order
    ).fillna(
        9
    )
    out["_bucket"] = out[
        "bucket"
    ].map(
        bucket_order
    ).fillna(
        9
    )

    out = out.sort_values(
        [
            "_priority",
            "_bucket",
            "due_date",
            "subject",
        ],
        ascending=[
            True,
            True,
            True,
            True,
        ],
        na_position="last",
    ).drop(
        columns=[
            "_priority",
            "_bucket",
        ]
    )

    return out[
        LEARNING_FEEDBACK_BRIDGE_QUEUE_COLS
    ].reset_index(
        drop=True
    )


def learning_feedback_bridge_queue_summary(
    queue: pd.DataFrame | None,
) -> dict:
    if queue is None or queue.empty:
        return {
            "total": 0,
            "integrity": 0,
            "pending_draft": 0,
            "source_review_pending": 0,
            "overdue": 0,
        }

    status = (
        queue[
            "status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
    )

    return {
        "total":
            int(
                len(
                    queue
                )
            ),
        "integrity":
            int(
                status.isin(
                    [
                        "INTEGRITY_REVIEW",
                        "DRAFT_INTEGRITY_REVIEW",
                    ]
                ).sum()
            ),
        "pending_draft":
            int(
                status.eq(
                    "PENDING_DRAFT"
                ).sum()
            ),
        "source_review_pending":
            int(
                status.eq(
                    "SOURCE_REVIEW_PENDING"
                ).sum()
            ),
        "overdue":
            int(
                queue[
                    "bucket"
                ]
                .fillna("")
                .astype(str)
                .eq(
                    "OVERDUE"
                ).sum()
            ),
    }
