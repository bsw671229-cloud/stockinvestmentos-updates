from __future__ import annotations

from datetime import date
from typing import Any
import pandas as pd

from engine.capital_productivity import (
    normalize_calibration_drafts,
    calibration_draft_integrity,
    calibration_reference_hash,
    capital_productivity_universe,
    capital_productivity_source_assist,
    capital_productivity_forward_risk_assist,
)
from engine.capital_productivity_revalidation import (
    post_revalidation_integrity,
)


ASSUMPTION_HEALTH_COLS = [
    "name","ticker","kind","provenance_type","input_status_before_health",
    "reviewed","review_due_date","review_due_gate","approved_calibration_id",
    "approved_at","calibration_hash_status","reference_status",
    "input_match_status","latest_revalidation_id","revalidation_hash_status",
    "revalidation_lineage_status","revalidation_lineage_issues",
    "health_status","health_issues","next_action",
]

def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()

def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out

def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {"TRUE","1","YES","Y","PASS"}

def _close(left: Any, right: Any, tol: float = 1e-9) -> bool:
    l = _num(left); r = _num(right)
    if l is None and r is None:
        return True
    if l is None or r is None:
        return False
    return abs(l-r) <= tol

def _latest_approved_operating_draft(
    drafts: pd.DataFrame | None,
    name: str,
    ticker: str,
) -> dict:
    df = normalize_calibration_drafts(drafts)
    if df.empty:
        return {}
    hit = df.loc[
        df["name"].fillna("").astype(str).str.strip().eq(_text(name))
        & df["approval_status"].fillna("").astype(str).str.upper().eq("APPROVED")
        & df["purpose"].fillna("").astype(str).str.upper().eq("OPERATING_ASSUMPTION")
    ].copy()
    if hit.empty:
        return {}
    ticker_text = _text(ticker)
    if ticker_text:
        ticker_hit = hit.loc[
            hit["ticker"].fillna("").astype(str).str.strip().eq(ticker_text)
        ].copy()
        if not ticker_hit.empty:
            hit = ticker_hit
    sort_series = pd.Series(pd.NaT, index=hit.index, dtype="datetime64[ns, UTC]")
    for col in ["approved_at","updated_at","created_at"]:
        if col in hit.columns:
            sort_series = sort_series.fillna(
                pd.to_datetime(hit[col], errors="coerce", utc=True)
            )
    hit["_sort"] = sort_series
    hit = hit.sort_values("_sort", ascending=False, na_position="last")
    return hit.iloc[0].drop(labels=["_sort"], errors="ignore").to_dict()

def _reference_lookup(forward_risk_assist: pd.DataFrame | None) -> dict[str, dict]:
    if forward_risk_assist is None or forward_risk_assist.empty:
        return {}
    out = {}
    for _, row in forward_risk_assist.iterrows():
        name = _text(row.get("name"))
        if name:
            out[name] = row.to_dict()
    return out

def build_assumption_health(
    universe: pd.DataFrame | None,
    forward_risk_assist: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    revalidations: pd.DataFrame | None = None,
    *,
    today: date | None = None,
) -> pd.DataFrame:
    current_date = today or date.today()
    if universe is None or universe.empty:
        return pd.DataFrame(columns=ASSUMPTION_HEALTH_COLS)

    refs = _reference_lookup(forward_risk_assist)
    rows = []

    for _, urow in universe.iterrows():
        u = urow.to_dict()
        name = _text(u.get("name"))
        ticker = _text(u.get("ticker"))
        kind = _text(u.get("kind")).upper()
        input_status = _text(u.get("input_status")).upper()
        reviewed = _bool(u.get("reviewed"))

        due = pd.to_datetime(u.get("review_due_date"), errors="coerce")
        if pd.isna(due):
            review_due_date = ""
            review_due_gate = "REVIEW"
        else:
            review_due_date = due.date().isoformat()
            review_due_gate = "PASS" if due.date() >= current_date else "EXPIRED"

        revalidation = post_revalidation_integrity(
            u,
            revalidations,
        )
        revalidation_status = _text(
            revalidation.get("status")
        ).upper()
        latest_revalidation_id = _text(
            revalidation.get("latest_revalidation_id")
        )
        revalidation_hash_status = (
            _text(revalidation.get("revalidation_hash_status")).upper()
            or "N/A"
        )
        revalidation_lineage_issues = " | ".join(
            revalidation.get("issues", [])
        )

        draft = _latest_approved_operating_draft(
            calibration_drafts, name, ticker
        )

        issues = []
        approved_id = ""
        approved_at = ""
        calibration_hash_status = "N/A"
        reference_status = "N/A"
        input_match_status = "N/A"

        if draft:
            provenance_type = "APPROVED_CALIBRATION"
            approved_id = _text(draft.get("calibration_id"))
            approved_at = _text(draft.get("approved_at"))
            calibration_hash_status = calibration_draft_integrity(draft)

            current_ref = refs.get(name, {})
            if not current_ref:
                reference_status = "REVIEW"
                issues.append("CURRENT_REFERENCE_MISSING")
            else:
                current_hash = calibration_reference_hash(current_ref)
                stored_hash = _text(draft.get("reference_hash"))
                reference_status = (
                    "MATCH" if stored_hash and stored_hash == current_hash else "MISMATCH"
                )
                if reference_status != "MATCH":
                    issues.append("REFERENCE_DRIFT")

            input_checks = [
                _close(u.get("forward_er"), draft.get("selected_forward_er")),
                _close(u.get("risk_penalty"), draft.get("selected_risk_penalty")),
            ]
            draft_hurdle = _num(draft.get("hurdle_rate"))
            if draft_hurdle is not None:
                input_checks.append(_close(u.get("hurdle_rate"), draft_hurdle))

            draft_due = pd.to_datetime(draft.get("review_due_date"), errors="coerce")
            if (
                revalidation_status not in {
                    "REVALIDATION_MATCH",
                    "POST_REVALIDATION_INPUT_MISMATCH",
                    "REVALIDATION_HASH_MISMATCH",
                    "REVALIDATION_RECORD_MISSING",
                }
                and not pd.isna(draft_due)
            ):
                input_checks.append(
                    (not pd.isna(due) and due.date() == draft_due.date())
                )
            if approved_id:
                input_checks.append(approved_id in _text(u.get("source")))

            input_match_status = "MATCH" if all(input_checks) else "MISMATCH"
            if input_match_status != "MATCH":
                issues.append("APPROVED_INPUT_MISMATCH")
            if calibration_hash_status != "OK":
                issues.append("APPROVED_CALIBRATION_HASH_NOT_OK")
        else:
            provenance_type = "MANUAL_REVIEW" if reviewed else "UNREVIEWED"

        if revalidation_status == "POST_REVALIDATION_INPUT_MISMATCH":
            issues.append("POST_REVALIDATION_INPUT_MISMATCH")
            issues.extend(revalidation.get("issues", []))
        elif revalidation_status == "REVALIDATION_RECORD_MISSING":
            issues.append("REVALIDATION_RECORD_MISSING")
        elif revalidation_status == "REVALIDATION_HASH_MISMATCH":
            issues.append("REVALIDATION_HASH_MISMATCH")
            issues.extend(revalidation.get("issues", []))

        if input_status != "READY":
            issues.append("REGISTER_INPUT_NOT_READY")
        if review_due_gate == "REVIEW":
            issues.append("REVIEW_DUE_DATE_REQUIRED")
        elif review_due_gate == "EXPIRED":
            issues.append("ASSUMPTION_EXPIRED")
        if not reviewed:
            issues.append("HUMAN_REVIEW_REQUIRED")

        if revalidation_status in {
            "REVALIDATION_HASH_MISMATCH",
            "REVALIDATION_RECORD_MISSING",
        }:
            health_status = "HASH_MISMATCH"
        elif revalidation_status == "POST_REVALIDATION_INPUT_MISMATCH":
            health_status = "INPUT_MISMATCH"
        elif draft:
            if calibration_hash_status != "OK":
                health_status = "HASH_MISMATCH"
            elif reference_status == "MISMATCH":
                health_status = "REFERENCE_DRIFT"
            elif input_match_status == "MISMATCH":
                health_status = "INPUT_MISMATCH"
            elif review_due_gate == "EXPIRED":
                health_status = "EXPIRED"
            elif issues:
                health_status = "REVIEW"
            else:
                health_status = "PASS"
        else:
            if review_due_gate == "EXPIRED":
                health_status = "EXPIRED"
            elif issues:
                health_status = "REVIEW"
            else:
                health_status = "PASS"

        next_action = {
            "PASS":"NONE / CONTINUE MONITORING",
            "REFERENCE_DRIFT":"RECALIBRATE AGAINST CURRENT REFERENCES",
            "INPUT_MISMATCH":"RESTORE OR RE-APPROVE OPERATING ASSUMPTION",
            "HASH_MISMATCH":"CALIBRATION INTEGRITY REVIEW",
            "EXPIRED":"REVIEW FORWARD ASSUMPTION NOW",
            "REVIEW":"COMPLETE MISSING REVIEW / SOURCE",
        }.get(health_status, "REVIEW")

        rows.append({
            "name":name,
            "ticker":ticker,
            "kind":kind,
            "provenance_type":provenance_type,
            "input_status_before_health":input_status,
            "reviewed":reviewed,
            "review_due_date":review_due_date,
            "review_due_gate":review_due_gate,
            "approved_calibration_id":approved_id,
            "approved_at":approved_at,
            "calibration_hash_status":calibration_hash_status,
            "reference_status":reference_status,
            "input_match_status":input_match_status,
            "latest_revalidation_id":latest_revalidation_id,
            "revalidation_hash_status":revalidation_hash_status,
            "revalidation_lineage_status":revalidation_status,
            "revalidation_lineage_issues":revalidation_lineage_issues,
            "health_status":health_status,
            "health_issues":" | ".join(list(dict.fromkeys(issues))),
            "next_action":next_action,
        })

    return pd.DataFrame(rows, columns=ASSUMPTION_HEALTH_COLS)

def assumption_health_summary(health: pd.DataFrame | None) -> dict:
    empty = {
        "total":0,"pass":0,"review":0,"expired":0,"reference_drift":0,
        "input_mismatch":0,"hash_mismatch":0,"manual":0,"calibration":0,
        "revalidation_match":0,"post_revalidation_mismatch":0,
        "revalidation_record_missing":0,"revalidation_hash_mismatch":0,
    }
    if health is None or health.empty:
        return empty

    status = health["health_status"].fillna("").astype(str).str.upper()
    provenance = health["provenance_type"].fillna("").astype(str).str.upper()
    lineage = (
        health["revalidation_lineage_status"]
        .fillna("").astype(str).str.upper()
        if "revalidation_lineage_status" in health.columns
        else pd.Series("", index=health.index, dtype="object")
    )
    return {
        "total":int(len(health)),
        "pass":int(status.eq("PASS").sum()),
        "review":int(status.eq("REVIEW").sum()),
        "expired":int(status.eq("EXPIRED").sum()),
        "reference_drift":int(status.eq("REFERENCE_DRIFT").sum()),
        "input_mismatch":int(status.eq("INPUT_MISMATCH").sum()),
        "hash_mismatch":int(status.eq("HASH_MISMATCH").sum()),
        "manual":int(provenance.eq("MANUAL_REVIEW").sum()),
        "calibration":int(provenance.eq("APPROVED_CALIBRATION").sum()),
        "revalidation_match":int(lineage.eq("REVALIDATION_MATCH").sum()),
        "post_revalidation_mismatch":int(
            lineage.eq("POST_REVALIDATION_INPUT_MISMATCH").sum()
        ),
        "revalidation_record_missing":int(
            lineage.eq("REVALIDATION_RECORD_MISSING").sum()
        ),
        "revalidation_hash_mismatch":int(
            lineage.eq("REVALIDATION_HASH_MISMATCH").sum()
        ),
    }

def apply_assumption_health_gate(
    universe: pd.DataFrame | None,
    health: pd.DataFrame | None,
) -> pd.DataFrame:
    if universe is None:
        return pd.DataFrame()
    out = universe.copy()
    if out.empty or health is None or health.empty:
        return out

    health_lookup = {
        _text(row.get("name")): row.to_dict()
        for _, row in health.iterrows()
    }

    if "assumption_health_status" not in out.columns:
        out["assumption_health_status"] = ""
    if "assumption_health_issues" not in out.columns:
        out["assumption_health_issues"] = ""
    if "issues" not in out.columns:
        out["issues"] = ""

    for idx, row in out.iterrows():
        name = _text(row.get("name"))
        h = health_lookup.get(name)
        if not h:
            continue
        status = _text(h.get("health_status")).upper()
        issues = _text(h.get("health_issues"))
        out.loc[idx, "assumption_health_status"] = status
        out.loc[idx, "assumption_health_issues"] = issues

        if status != "PASS":
            out.loc[idx, "input_status"] = "REVIEW"
            existing_issues = _text(out.loc[idx, "issues"])
            combined = [
                x for x in [
                    existing_issues,
                    "ASSUMPTION_HEALTH_" + (status or "REVIEW"),
                    issues,
                ] if _text(x)
            ]
            out.loc[idx, "issues"] = " | ".join(list(dict.fromkeys(combined)))

    return out


ASSUMPTION_REVIEW_QUEUE_COLS = [
    "priority","priority_rank","bucket","due_date","days_to_due",
    "category","subject","kind","provenance_type","status",
    "issue","next_action","go_to",
]


def build_capital_productivity_health_context(
    portfolio: pd.DataFrame | None,
    watchlist: pd.DataFrame | None,
    inputs: pd.DataFrame | None,
    total_assets: float,
    state_df: pd.DataFrame | None,
    audit_evidence: pd.DataFrame | None,
    fundamental_snapshots: pd.DataFrame | None,
    scenario_refreshes: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    revalidations: pd.DataFrame | None = None,
    *,
    today: date | None = None,
) -> dict:
    universe = capital_productivity_universe(
        portfolio,
        watchlist,
        inputs,
        total_assets,
        today=today,
    )
    source_assist = capital_productivity_source_assist(
        universe,
        watchlist,
        state_df,
        audit_evidence,
        fundamental_snapshots,
    )
    forward_risk = capital_productivity_forward_risk_assist(
        source_assist,
        watchlist,
        scenario_refreshes,
    )
    health = build_assumption_health(
        universe,
        forward_risk,
        calibration_drafts,
        revalidations,
        today=today,
    )
    gated_universe = apply_assumption_health_gate(
        universe,
        health,
    )
    return {
        "universe": universe,
        "source_assist": source_assist,
        "forward_risk": forward_risk,
        "health": health,
        "gated_universe": gated_universe,
        "summary": assumption_health_summary(health),
    }


def _queue_bucket(
    due_date: date | None,
    *,
    today: date,
    force_now: bool = False,
) -> tuple[str, int | None]:
    if force_now:
        return "NOW", 0
    if due_date is None:
        return "NO DATE", None

    days = (due_date - today).days
    if days < 0:
        return "OVERDUE", days
    if days == 0:
        return "TODAY", 0
    if days <= 7:
        return "NEXT 7 DAYS", days
    if days <= 30:
        return "NEXT 30 DAYS", days
    return "FUTURE", days


def build_assumption_review_queue(
    health: pd.DataFrame | None,
    *,
    today: date | None = None,
    expiry_warning_days: int = 30,
) -> pd.DataFrame:
    current_date = today or date.today()
    warning_days = max(1, int(expiry_warning_days))

    if health is None or health.empty:
        return pd.DataFrame(columns=ASSUMPTION_REVIEW_QUEUE_COLS)

    p1_statuses = {
        "HASH_MISMATCH",
        "INPUT_MISMATCH",
        "REFERENCE_DRIFT",
    }
    rows = []

    for _, hrow in health.iterrows():
        h = hrow.to_dict()
        name = _text(h.get("name"))
        kind = _text(h.get("kind")).upper()
        provenance = _text(h.get("provenance_type")).upper()
        status = _text(h.get("health_status")).upper()

        due_ts = pd.to_datetime(h.get("review_due_date"), errors="coerce")
        due = None if pd.isna(due_ts) else due_ts.date()
        days_to_due = None if due is None else (due - current_date).days

        priority = ""
        priority_rank = 99
        category = "Capital Productivity Assumption"
        issue = _text(h.get("health_issues"))
        next_action = _text(h.get("next_action"))
        force_now = False

        if status in p1_statuses:
            priority = "P1_INTEGRITY_OR_DRIFT"
            priority_rank = 1
            category = "Capital Productivity Integrity"
            force_now = True
            issue = status + ((" | " + issue) if issue else "")

        elif status == "EXPIRED":
            priority = "P2_EXPIRY"
            priority_rank = 2
            category = "Capital Productivity Expiry Clock"
            issue = "ASSUMPTION_EXPIRED" + ((" | " + issue) if issue else "")

        elif (
            status == "PASS"
            and days_to_due is not None
            and 0 <= days_to_due <= warning_days
        ):
            priority = "P2_EXPIRY"
            priority_rank = 2
            category = "Capital Productivity Expiry Clock"
            issue = f"ASSUMPTION_REVIEW_DUE_IN_{days_to_due}_DAYS"
            next_action = "REVALIDATE FORWARD ASSUMPTION BEFORE EXPIRY"

        elif status == "REVIEW" and kind in {"HOLDING", "CASH"}:
            priority = "P3_HOLDING_REVIEW"
            priority_rank = 3
            category = (
                "Capital Productivity Holding Review"
                if kind == "HOLDING"
                else "Capital Productivity Cash Review"
            )
            force_now = True
            if not issue:
                issue = "HOLDING_ASSUMPTION_REVIEW_REQUIRED"
            if not next_action:
                next_action = "COMPLETE SOURCE / FORWARD ER / RISK PENALTY REVIEW"

        elif status == "REVIEW" and kind == "WATCHLIST":
            priority = "P4_WATCHLIST_REVIEW"
            priority_rank = 4
            category = "Capital Productivity Watchlist Review"
            if not issue:
                issue = "WATCHLIST_ASSUMPTION_REVIEW_REQUIRED"
            if not next_action:
                next_action = "COMPLETE SOURCE / FORWARD ER / RISK PENALTY REVIEW"

        else:
            continue

        bucket, bucket_days = _queue_bucket(
            due,
            today=current_date,
            force_now=force_now,
        )

        rows.append({
            "priority": priority,
            "priority_rank": priority_rank,
            "bucket": bucket,
            "due_date": due.isoformat() if due is not None else "",
            "days_to_due": bucket_days if bucket_days is not None else "",
            "category": category,
            "subject": name,
            "kind": kind,
            "provenance_type": provenance,
            "status": status,
            "issue": issue,
            "next_action": next_action or "REVIEW CAPITAL PRODUCTIVITY ASSUMPTION",
            "go_to": "Capital Productivity",
        })

    if not rows:
        return pd.DataFrame(columns=ASSUMPTION_REVIEW_QUEUE_COLS)

    out = pd.DataFrame(rows, columns=ASSUMPTION_REVIEW_QUEUE_COLS)
    bucket_order = {
        "OVERDUE": 0,
        "TODAY": 1,
        "NOW": 2,
        "NEXT 7 DAYS": 3,
        "NEXT 30 DAYS": 4,
        "FUTURE": 5,
        "NO DATE": 6,
    }
    out["_bucket_order"] = out["bucket"].map(bucket_order).fillna(99)
    out["_due_sort"] = pd.to_numeric(
        out["days_to_due"],
        errors="coerce",
    ).fillna(999999)

    return (
        out.sort_values(
            ["priority_rank","_bucket_order","_due_sort","subject"],
            ascending=[True,True,True,True],
        )
        .drop(columns=["_bucket_order","_due_sort"])
        .reset_index(drop=True)
    )


def assumption_review_queue_summary(
    queue: pd.DataFrame | None,
) -> dict:
    if queue is None or queue.empty:
        return {
            "total":0,"p1":0,"p2":0,"p3":0,"p4":0,
            "overdue":0,"today":0,"now":0,
            "next_7_days":0,"next_30_days":0,"no_date":0,
            "attention_now":0,
        }

    priority = queue["priority"].fillna("").astype(str)
    bucket = queue["bucket"].fillna("").astype(str)

    overdue = int(bucket.eq("OVERDUE").sum())
    today_count = int(bucket.eq("TODAY").sum())
    now_count = int(bucket.eq("NOW").sum())

    return {
        "total": int(len(queue)),
        "p1": int(priority.str.startswith("P1_").sum()),
        "p2": int(priority.str.startswith("P2_").sum()),
        "p3": int(priority.str.startswith("P3_").sum()),
        "p4": int(priority.str.startswith("P4_").sum()),
        "overdue": overdue,
        "today": today_count,
        "now": now_count,
        "next_7_days": int(bucket.eq("NEXT 7 DAYS").sum()),
        "next_30_days": int(bucket.eq("NEXT 30 DAYS").sum()),
        "no_date": int(bucket.eq("NO DATE").sum()),
        "attention_now": overdue + today_count + now_count,
    }
