from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.pretrade_decision_packet import (
    pretrade_packet_integrity,
)


PRETRADE_FILL_LINEAGE_COLS = [
    "lineage_id",
    "created_at",
    "packet_id",
    "packet_status",
    "packet_integrity_status",
    "packet_snapshot_hash",
    "locked_decision_state",
    "execution_authorization",
    "fill_id",
    "fill_name",
    "fill_ticker",
    "fill_side",
    "fill_leg",
    "actual_fill_timestamp",
    "fill_timestamp_status",
    "fill_timestamp_confirmed",
    "quote_timestamp",
    "quote_age_at_fill_minutes",
    "quote_age_gate",
    "freshness_evidence_status",
    "freshness_evaluated_at",
    "freshness_evidence_age_minutes",
    "planned_quantity",
    "actual_quantity",
    "quantity_delta",
    "quantity_status",
    "locked_quote_price_krw",
    "actual_fill_price_krw",
    "price_slippage_bps",
    "break_even_price_krw",
    "price_boundary_status",
    "planned_gross_krw",
    "actual_gross_krw",
    "gross_delta_krw",
    "fees_tax_krw",
    "actual_cash_delta_krw",
    "recipient_headroom_krw",
    "lineage_status",
    "issues",
    "note",
    "record_hash",
]


PRETRADE_POSTTRADE_LINEAGE_COLS = [
    "linked_at",
    "packet_id",
    "fill_id",
    "fill_lineage_id",
    "fill_lineage_status",
    "fill_lineage_integrity",
    "packet_snapshot_hash",
    "post_trade_audit_status",
    "post_trade_hard_blocks",
    "post_trade_reviews",
    "execution_authorization",
    "note",
    "lineage_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _stable_num(
    value: Any,
    places: int = 8,
) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _parse_aware_timestamp(
    value: Any,
) -> dict:
    text = _text(value)
    if not text:
        return {
            "status": "MISSING",
            "timestamp": None,
            "normalized": "",
            "issue": "ACTUAL_FILL_TIMESTAMP_REQUIRED",
        }

    try:
        ts = pd.Timestamp(text)
    except Exception:
        return {
            "status": "INVALID",
            "timestamp": None,
            "normalized": "",
            "issue": "ACTUAL_FILL_TIMESTAMP_INVALID",
        }

    if ts.tzinfo is None:
        return {
            "status": "TIMEZONE_REQUIRED",
            "timestamp": None,
            "normalized": "",
            "issue": "ACTUAL_FILL_TIMESTAMP_TIMEZONE_REQUIRED",
        }

    return {
        "status": "PASS",
        "timestamp": ts,
        "normalized": ts.isoformat(),
        "issue": "",
    }


def _packet_quote_timestamp(
    value: Any,
) -> dict:
    text = _text(value)
    if not text:
        return {
            "status": "MISSING",
            "timestamp": None,
            "issue": "LOCKED_QUOTE_TIMESTAMP_MISSING",
        }
    try:
        ts = pd.Timestamp(text)
    except Exception:
        return {
            "status": "INVALID",
            "timestamp": None,
            "issue": "LOCKED_QUOTE_TIMESTAMP_INVALID",
        }
    if ts.tzinfo is None:
        return {
            "status": "TIMEZONE_REQUIRED",
            "timestamp": None,
            "issue": "LOCKED_QUOTE_TIMESTAMP_TIMEZONE_REQUIRED",
        }
    return {
        "status": "PASS",
        "timestamp": ts,
        "issue": "",
    }


def _latest_current_freshness_before_fill(
    freshness_reviews: pd.DataFrame | None,
    packet_id: str,
    fill_ts: pd.Timestamp | None,
    max_evidence_age_minutes: float,
) -> dict:
    if (
        freshness_reviews is None
        or freshness_reviews.empty
        or fill_ts is None
    ):
        return {
            "status": "NOT_FOUND",
            "evaluated_at": "",
            "age_minutes": None,
        }

    df = freshness_reviews.copy()
    for col in [
        "packet_id",
        "live_status",
        "evaluated_at",
        "evaluation_hash",
    ]:
        if col not in df.columns:
            df[col] = ""

    hit = df.loc[
        df["packet_id"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(_text(packet_id))
        & df["live_status"]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("CURRENT")
    ].copy()

    if hit.empty:
        return {
            "status": "NOT_FOUND",
            "evaluated_at": "",
            "age_minutes": None,
        }

    hit["_ts"] = pd.to_datetime(
        hit["evaluated_at"],
        errors="coerce",
        utc=True,
    )
    hit = hit.dropna(
        subset=["_ts"]
    )
    if hit.empty:
        return {
            "status": "NOT_FOUND",
            "evaluated_at": "",
            "age_minutes": None,
        }

    fill_utc = fill_ts.tz_convert("UTC")
    hit = hit.loc[
        hit["_ts"] <= fill_utc
    ].sort_values(
        "_ts",
        ascending=False,
    )
    if hit.empty:
        return {
            "status": "NOT_FOUND_BEFORE_FILL",
            "evaluated_at": "",
            "age_minutes": None,
        }

    row = hit.iloc[0]
    age = (
        fill_utc
        - row["_ts"]
    ).total_seconds() / 60.0

    evaluation_hash = _text(
        row.get("evaluation_hash")
    )
    hash_present = (
        len(evaluation_hash) == 64
    )

    if (
        age
        <= max(
            0.0,
            float(
                max_evidence_age_minutes
            ),
        )
        and hash_present
    ):
        status = "CURRENT_RECENT"
    elif not hash_present:
        status = "CURRENT_HASH_MISSING"
    else:
        status = "CURRENT_TOO_OLD"

    return {
        "status": status,
        "evaluated_at": _text(
            row.get("evaluated_at")
        ),
        "age_minutes": float(age),
    }


def evaluate_pretrade_fill_link(
    packet_row: dict | None,
    freshness_reviews: pd.DataFrame | None,
    *,
    fill_name: str,
    fill_ticker: str,
    fill_side: str,
    quantity: float,
    fill_price: float,
    fees_tax: float,
    actual_fill_timestamp: str,
    fill_timestamp_confirmed: bool,
    max_quote_age_minutes: float = 5.0,
    future_tolerance_minutes: float = 2.0,
    max_current_evidence_age_minutes: float = 5.0,
) -> dict:
    """
    Compare an already-executed broker fill with a locked Pre-Trade Packet.

    This is reconciliation / lineage only.
    MATCH never means the trade was authorized.
    Execution Authorization remains NONE.
    """
    packet = packet_row or {}
    issues = []

    integrity = pretrade_packet_integrity(
        packet
    )

    packet_status = _text(
        packet.get("packet_status")
    ).upper()
    execution_authorization = _text(
        packet.get(
            "execution_authorization"
        )
    ).upper()

    if (
        integrity.get(
            "integrity_status"
        )
        != "OK"
    ):
        issues.append(
            "PACKET_INTEGRITY_FAILED"
        )

    if packet_status != "REVIEW_COMPLETE":
        issues.append(
            "PACKET_NOT_REVIEW_COMPLETE"
        )

    if execution_authorization != "NONE":
        issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    fill_side_norm = _text(
        fill_side
    ).upper()
    fill_name_norm = _text(
        fill_name
    )
    donor = _text(
        packet.get("donor")
    )
    recipient = _text(
        packet.get("recipient")
    )

    if (
        fill_name_norm == donor
        and fill_side_norm == "SELL"
    ):
        fill_leg = "DONOR_SELL"
    elif (
        fill_name_norm == recipient
        and fill_side_norm == "BUY"
    ):
        fill_leg = "RECIPIENT_BUY"
    else:
        fill_leg = "UNMAPPED"
        issues.append(
            "FILL_NOT_MAPPED_TO_PACKET_LEG"
        )

    fill_ts_info = _parse_aware_timestamp(
        actual_fill_timestamp
    )
    fill_ts = fill_ts_info[
        "timestamp"
    ]
    if fill_ts_info["issue"]:
        issues.append(
            fill_ts_info["issue"]
        )
    if not _bool(
        fill_timestamp_confirmed
    ):
        issues.append(
            "ACTUAL_FILL_TIMESTAMP_CONFIRMATION_REQUIRED"
        )

    quote_ts_info = _packet_quote_timestamp(
        packet.get(
            "quote_timestamp"
        )
    )
    quote_ts = quote_ts_info[
        "timestamp"
    ]
    if quote_ts_info["issue"]:
        issues.append(
            quote_ts_info["issue"]
        )

    quote_age_at_fill = None
    quote_age_gate = "NOT_EVALUABLE"
    if (
        fill_ts is not None
        and quote_ts is not None
    ):
        quote_age_at_fill = (
            fill_ts.tz_convert("UTC")
            - quote_ts.tz_convert("UTC")
        ).total_seconds() / 60.0

        future_tol = max(
            0.0,
            float(
                future_tolerance_minutes
            ),
        )
        max_quote_age = max(
            0.0,
            float(
                max_quote_age_minutes
            ),
        )

        if quote_age_at_fill < -future_tol:
            quote_age_gate = "REVIEW"
            issues.append(
                "FILL_TIMESTAMP_BEFORE_LOCKED_QUOTE"
            )
        elif quote_age_at_fill > max_quote_age:
            quote_age_gate = "REVIEW"
            issues.append(
                "LOCKED_QUOTE_EXPIRED_AT_FILL"
            )
        else:
            quote_age_gate = "PASS"

    freshness = (
        _latest_current_freshness_before_fill(
            freshness_reviews,
            _text(
                packet.get("packet_id")
            ),
            fill_ts,
            max_current_evidence_age_minutes,
        )
    )
    if (
        freshness["status"]
        != "CURRENT_RECENT"
    ):
        issues.append(
            "RECENT_CURRENT_FRESHNESS_EVIDENCE_REQUIRED"
        )

    actual_qty = max(
        0.0,
        float(
            _num(quantity)
            or 0.0
        ),
    )
    actual_price = max(
        0.0,
        float(
            _num(fill_price)
            or 0.0
        ),
    )
    actual_fees = max(
        0.0,
        float(
            _num(fees_tax)
            or 0.0
        ),
    )

    planned_qty = None
    locked_quote_price = _num(
        packet.get(
            "quote_price_krw"
        )
    )
    break_even_price = _num(
        packet.get(
            "break_even_sell_price_krw"
        )
    )
    planned_gross = _num(
        packet.get(
            "executable_gross_trim_krw"
        )
    )

    if fill_leg == "DONOR_SELL":
        planned_qty = _num(
            packet.get(
                "quote_required_quantity"
            )
        )
        if (
            planned_qty is None
            or planned_qty <= 0
        ):
            planned_qty = _num(
                packet.get(
                    "required_sell_quantity"
                )
            )

        if (
            planned_qty is None
            or planned_qty <= 0
        ):
            quantity_status = "NOT_EVALUABLE"
            issues.append(
                "LOCKED_DONOR_SELL_QUANTITY_MISSING"
            )
            quantity_delta = None
        else:
            quantity_delta = (
                actual_qty
                - planned_qty
            )
            quantity_status = (
                "MATCH"
                if abs(
                    quantity_delta
                )
                <= 1e-9
                else "DRIFT"
            )
            if (
                quantity_status
                != "MATCH"
            ):
                issues.append(
                    "FILL_QUANTITY_DIFFERS_FROM_LOCKED_PLAN"
                )

        if (
            break_even_price is None
            or break_even_price <= 0
            or actual_price <= 0
        ):
            price_boundary_status = "NOT_EVALUABLE"
            issues.append(
                "FILL_PRICE_BOUNDARY_NOT_EVALUABLE"
            )
        elif (
            actual_price
            >= break_even_price
        ):
            price_boundary_status = "WITHIN_LOCKED_BOUNDARY"
        else:
            price_boundary_status = "BELOW_LOCKED_BREAK_EVEN"
            issues.append(
                "FILL_PRICE_BELOW_LOCKED_BREAK_EVEN"
            )

    elif fill_leg == "RECIPIENT_BUY":
        planned_qty = None
        quantity_delta = None
        quantity_status = "NOT_LOCKED"
        price_boundary_status = "NOT_LOCKED"
        issues.append(
            "RECIPIENT_BUY_TERMS_NOT_LOCKED_IN_PACKET"
        )
    else:
        planned_qty = None
        quantity_delta = None
        quantity_status = "NOT_EVALUABLE"
        price_boundary_status = "NOT_EVALUABLE"

    price_slippage_bps = None
    if (
        locked_quote_price is not None
        and locked_quote_price > 0
        and actual_price > 0
    ):
        if fill_side_norm == "SELL":
            price_slippage_bps = (
                (
                    actual_price
                    - locked_quote_price
                )
                / locked_quote_price
                * 10000.0
            )
        elif fill_side_norm == "BUY":
            price_slippage_bps = (
                (
                    locked_quote_price
                    - actual_price
                )
                / locked_quote_price
                * 10000.0
            )

    actual_gross = (
        actual_qty
        * actual_price
    )

    if fill_side_norm == "SELL":
        actual_cash_delta = (
            actual_gross
            - actual_fees
        )
    elif fill_side_norm == "BUY":
        actual_cash_delta = -(
            actual_gross
            + actual_fees
        )
    else:
        actual_cash_delta = 0.0

    gross_delta = (
        None
        if planned_gross is None
        else (
            actual_gross
            - planned_gross
        )
    )

    recipient_headroom = _num(
        packet.get(
            "recipient_headroom_krw"
        )
    )

    invalidating = {
        "PACKET_INTEGRITY_FAILED",
        "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE",
    }

    if any(
        issue in invalidating
        for issue in issues
    ):
        lineage_status = "INVALIDATED"
    elif issues:
        lineage_status = "REVIEW"
    else:
        lineage_status = "MATCH"

    return {
        "packet_id": _text(
            packet.get("packet_id")
        ),
        "packet_status": packet_status,
        "packet_integrity_status":
            integrity.get(
                "integrity_status",
                "MISMATCH",
            ),
        "packet_snapshot_hash": _text(
            packet.get(
                "snapshot_hash"
            )
        ),
        "locked_decision_state": _text(
            packet.get(
                "decision_state"
            )
        ),
        "execution_authorization": "NONE",
        "fill_name": fill_name_norm,
        "fill_ticker": _text(
            fill_ticker
        ),
        "fill_side": fill_side_norm,
        "fill_leg": fill_leg,
        "actual_fill_timestamp":
            fill_ts_info[
                "normalized"
            ]
            or _text(
                actual_fill_timestamp
            ),
        "fill_timestamp_status":
            fill_ts_info[
                "status"
            ],
        "fill_timestamp_confirmed":
            bool(
                fill_timestamp_confirmed
            ),
        "quote_timestamp": _text(
            packet.get(
                "quote_timestamp"
            )
        ),
        "quote_age_at_fill_minutes":
            quote_age_at_fill,
        "quote_age_gate":
            quote_age_gate,
        "freshness_evidence_status":
            freshness[
                "status"
            ],
        "freshness_evaluated_at":
            freshness[
                "evaluated_at"
            ],
        "freshness_evidence_age_minutes":
            freshness[
                "age_minutes"
            ],
        "planned_quantity":
            planned_qty,
        "actual_quantity":
            actual_qty,
        "quantity_delta":
            quantity_delta,
        "quantity_status":
            quantity_status,
        "locked_quote_price_krw":
            locked_quote_price,
        "actual_fill_price_krw":
            actual_price,
        "price_slippage_bps":
            price_slippage_bps,
        "break_even_price_krw":
            break_even_price,
        "price_boundary_status":
            price_boundary_status,
        "planned_gross_krw":
            planned_gross,
        "actual_gross_krw":
            actual_gross,
        "gross_delta_krw":
            gross_delta,
        "fees_tax_krw":
            actual_fees,
        "actual_cash_delta_krw":
            actual_cash_delta,
        "recipient_headroom_krw":
            recipient_headroom,
        "lineage_status":
            lineage_status,
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _fill_lineage_hash_payload(
    row: dict,
) -> dict:
    fields = [
        "lineage_id",
        "created_at",
        "packet_id",
        "packet_snapshot_hash",
        "locked_decision_state",
        "execution_authorization",
        "fill_id",
        "fill_name",
        "fill_ticker",
        "fill_side",
        "fill_leg",
        "actual_fill_timestamp",
        "fill_timestamp_status",
        "fill_timestamp_confirmed",
        "quote_timestamp",
        "quote_age_at_fill_minutes",
        "quote_age_gate",
        "freshness_evidence_status",
        "freshness_evaluated_at",
        "freshness_evidence_age_minutes",
        "planned_quantity",
        "actual_quantity",
        "quantity_delta",
        "quantity_status",
        "locked_quote_price_krw",
        "actual_fill_price_krw",
        "price_slippage_bps",
        "break_even_price_krw",
        "price_boundary_status",
        "planned_gross_krw",
        "actual_gross_krw",
        "gross_delta_krw",
        "fees_tax_krw",
        "actual_cash_delta_krw",
        "recipient_headroom_krw",
        "lineage_status",
        "issues",
        "note",
    ]
    payload = {}
    number_fields = {
        "quote_age_at_fill_minutes",
        "freshness_evidence_age_minutes",
        "planned_quantity",
        "actual_quantity",
        "quantity_delta",
        "locked_quote_price_krw",
        "actual_fill_price_krw",
        "price_slippage_bps",
        "break_even_price_krw",
        "planned_gross_krw",
        "actual_gross_krw",
        "gross_delta_krw",
        "fees_tax_krw",
        "actual_cash_delta_krw",
        "recipient_headroom_krw",
    }
    for field in fields:
        if field in number_fields:
            payload[field] = _stable_num(
                row.get(field)
            )
        elif field == "fill_timestamp_confirmed":
            payload[field] = bool(
                _bool(
                    row.get(field)
                )
            )
        else:
            payload[field] = _text(
                row.get(field)
            )
    return payload


def build_pretrade_fill_lineage_record(
    preview: dict,
    *,
    fill_id: str,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    p = preview or {}
    now = (
        _text(created_at)
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    lineage_id = (
        "PTF-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + (
            _text(
                p.get(
                    "packet_snapshot_hash"
                )
            )[:8]
            or "NOHASH"
        )
    )

    row = {
        "lineage_id": lineage_id,
        "created_at": now,
        "packet_id": _text(
            p.get("packet_id")
        ),
        "packet_status": _text(
            p.get(
                "packet_status"
            )
        ),
        "packet_integrity_status": _text(
            p.get(
                "packet_integrity_status"
            )
        ),
        "packet_snapshot_hash": _text(
            p.get(
                "packet_snapshot_hash"
            )
        ),
        "locked_decision_state": _text(
            p.get(
                "locked_decision_state"
            )
        ),
        "execution_authorization": "NONE",
        "fill_id": _text(
            fill_id
        ),
        "fill_name": _text(
            p.get(
                "fill_name"
            )
        ),
        "fill_ticker": _text(
            p.get(
                "fill_ticker"
            )
        ),
        "fill_side": _text(
            p.get(
                "fill_side"
            )
        ),
        "fill_leg": _text(
            p.get(
                "fill_leg"
            )
        ),
        "actual_fill_timestamp": _text(
            p.get(
                "actual_fill_timestamp"
            )
        ),
        "fill_timestamp_status": _text(
            p.get(
                "fill_timestamp_status"
            )
        ),
        "fill_timestamp_confirmed": bool(
            p.get(
                "fill_timestamp_confirmed",
                False,
            )
        ),
        "quote_timestamp": _text(
            p.get(
                "quote_timestamp"
            )
        ),
        "quote_age_at_fill_minutes": _num(
            p.get(
                "quote_age_at_fill_minutes"
            )
        ),
        "quote_age_gate": _text(
            p.get(
                "quote_age_gate"
            )
        ),
        "freshness_evidence_status": _text(
            p.get(
                "freshness_evidence_status"
            )
        ),
        "freshness_evaluated_at": _text(
            p.get(
                "freshness_evaluated_at"
            )
        ),
        "freshness_evidence_age_minutes": _num(
            p.get(
                "freshness_evidence_age_minutes"
            )
        ),
        "planned_quantity": _num(
            p.get(
                "planned_quantity"
            )
        ),
        "actual_quantity": _num(
            p.get(
                "actual_quantity"
            )
        ),
        "quantity_delta": _num(
            p.get(
                "quantity_delta"
            )
        ),
        "quantity_status": _text(
            p.get(
                "quantity_status"
            )
        ),
        "locked_quote_price_krw": _num(
            p.get(
                "locked_quote_price_krw"
            )
        ),
        "actual_fill_price_krw": _num(
            p.get(
                "actual_fill_price_krw"
            )
        ),
        "price_slippage_bps": _num(
            p.get(
                "price_slippage_bps"
            )
        ),
        "break_even_price_krw": _num(
            p.get(
                "break_even_price_krw"
            )
        ),
        "price_boundary_status": _text(
            p.get(
                "price_boundary_status"
            )
        ),
        "planned_gross_krw": _num(
            p.get(
                "planned_gross_krw"
            )
        ),
        "actual_gross_krw": _num(
            p.get(
                "actual_gross_krw"
            )
        ),
        "gross_delta_krw": _num(
            p.get(
                "gross_delta_krw"
            )
        ),
        "fees_tax_krw": _num(
            p.get(
                "fees_tax_krw"
            )
        ),
        "actual_cash_delta_krw": _num(
            p.get(
                "actual_cash_delta_krw"
            )
        ),
        "recipient_headroom_krw": _num(
            p.get(
                "recipient_headroom_krw"
            )
        ),
        "lineage_status": _text(
            p.get(
                "lineage_status"
            )
        ),
        "issues": " | ".join(
            p.get(
                "issues",
                [],
            )
        ),
        "note": _text(note),
        "record_hash": "",
    }

    row["record_hash"] = _hash(
        _fill_lineage_hash_payload(
            row
        )
    )
    return row


def pretrade_fill_lineage_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )
    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _fill_lineage_hash_payload(
            record
        )
    )
    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash":
            calculated,
    }


def _posttrade_hash_payload(
    row: dict,
) -> dict:
    return {
        "linked_at": _text(
            row.get("linked_at")
        ),
        "packet_id": _text(
            row.get("packet_id")
        ),
        "fill_id": _text(
            row.get("fill_id")
        ),
        "fill_lineage_id": _text(
            row.get(
                "fill_lineage_id"
            )
        ),
        "fill_lineage_status": _text(
            row.get(
                "fill_lineage_status"
            )
        ),
        "fill_lineage_integrity": _text(
            row.get(
                "fill_lineage_integrity"
            )
        ),
        "packet_snapshot_hash": _text(
            row.get(
                "packet_snapshot_hash"
            )
        ),
        "post_trade_audit_status": _text(
            row.get(
                "post_trade_audit_status"
            )
        ),
        "post_trade_hard_blocks": _stable_num(
            row.get(
                "post_trade_hard_blocks"
            ),
            places=0,
        ),
        "post_trade_reviews": _stable_num(
            row.get(
                "post_trade_reviews"
            ),
            places=0,
        ),
        "execution_authorization": "NONE",
        "note": _text(
            row.get("note")
        ),
    }


def build_pretrade_posttrade_lineage_record(
    fill_lineage_row: dict,
    post_trade_summary: dict,
    *,
    note: str = "",
    linked_at: str | None = None,
) -> dict:
    lineage = fill_lineage_row or {}
    summary = post_trade_summary or {}

    integrity = pretrade_fill_lineage_integrity(
        lineage
    )
    now = (
        _text(linked_at)
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    row = {
        "linked_at": now,
        "packet_id": _text(
            lineage.get(
                "packet_id"
            )
        ),
        "fill_id": _text(
            summary.get(
                "fill_id",
                lineage.get(
                    "fill_id"
                ),
            )
        ),
        "fill_lineage_id": _text(
            lineage.get(
                "lineage_id"
            )
        ),
        "fill_lineage_status": _text(
            lineage.get(
                "lineage_status"
            )
        ),
        "fill_lineage_integrity":
            integrity[
                "status"
            ],
        "packet_snapshot_hash": _text(
            lineage.get(
                "packet_snapshot_hash"
            )
        ),
        "post_trade_audit_status": _text(
            summary.get(
                "audit_status"
            )
        ),
        "post_trade_hard_blocks": int(
            _num(
                summary.get(
                    "hard_blocks"
                )
            )
            or 0
        ),
        "post_trade_reviews": int(
            _num(
                summary.get(
                    "reviews"
                )
            )
            or 0
        ),
        "execution_authorization": "NONE",
        "note": _text(note),
        "lineage_hash": "",
    }

    row["lineage_hash"] = _hash(
        _posttrade_hash_payload(
            row
        )
    )
    return row


def pretrade_posttrade_lineage_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "lineage_hash"
        )
    )
    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _posttrade_hash_payload(
            record
        )
    )
    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash":
            calculated,
    }
