from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


PRETRADE_PACKET_COLS = [
    "packet_id",
    "created_at",
    "packet_status",
    "packet_purpose",
    "donor",
    "recipient",
    "donor_kind",
    "recipient_kind",
    "comparison_amount_krw",
    "decision_state",
    "decision_reason",
    "legacy_migration_status",
    "migration_v2_status",
    "bridge_mapping_gate",
    "bridge_reconciliation_gate",
    "donor_health",
    "recipient_health",
    "donor_forward_er",
    "donor_risk_penalty",
    "donor_risk_adjusted_er",
    "recipient_forward_er",
    "recipient_risk_penalty",
    "recipient_risk_adjusted_er",
    "net_switching_gap",
    "migration_hurdle",
    "recipient_hurdle_spread",
    "recipient_headroom_krw",
    "cash_repair_gate",
    "required_cash_repair_krw",
    "gross_trim_needed_krw",
    "quantity_step_gate",
    "required_sell_quantity",
    "executable_gross_trim_krw",
    "post_trade_cash_krw",
    "cash_over_repair_krw",
    "sensitivity_gate",
    "sensitivity_boundary_status",
    "break_even_sell_price_krw",
    "worst_case_required_quantity",
    "quote_validation_gate",
    "quote_freshness_gate",
    "quote_source",
    "quote_timestamp",
    "quote_price_krw",
    "quote_required_quantity",
    "quote_boundary_status",
    "donor_lifecycle_gate",
    "recipient_lifecycle_gate",
    "recipient_execution_gate",
    "recipient_add_freeze_gate",
    "recipient_survival_gate",
    "recipient_fit_gate",
    "recipient_capacity_gate",
    "cash_reserve_gate",
    "switching_gap_gate",
    "recipient_factor_risk_gate",
    "assumption_snapshot_hash",
    "portfolio_snapshot_hash",
    "sensitivity_scenario_hash",
    "quote_snapshot_hash",
    "migration_context_hash",
    "snapshot_hash",
    "snapshot_payload_json",
    "review_basis",
    "source_gate_confirmed",
    "decision_gate_confirmed",
    "quote_gate_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "review_gate",
    "execution_authorization",
    "review_note",
    "record_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _stable_num(value: Any, places: int = 12) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _canonical_scalar(value: Any) -> Any:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass

    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, (int, float)):
        number = _num(value)
        if number is not None:
            return f"{number:.12f}"
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    return _text(value)


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def dataframe_snapshot_hash(
    df: pd.DataFrame | None,
) -> str:
    if df is None or df.empty:
        return _hash([])

    source = df.copy()
    columns = sorted(
        [str(c) for c in source.columns]
    )
    source = source.reindex(
        columns=columns
    )

    rows = []
    for _, row in source.iterrows():
        rows.append(
            {
                col: _canonical_scalar(
                    row.get(col)
                )
                for col in columns
            }
        )

    # Deterministic row order independent of current dataframe index.
    rows = sorted(
        rows,
        key=lambda x: json.dumps(
            x,
            ensure_ascii=False,
            sort_keys=True,
            default=str,
        ),
    )
    return _hash(rows)


def _health_lookup(
    health: pd.DataFrame | None,
    name: str,
) -> dict:
    if health is None or health.empty:
        return {}
    if "name" not in health.columns:
        return {}
    hit = health.loc[
        health["name"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(name)
        )
    ]
    if hit.empty:
        return {}
    return hit.iloc[-1].to_dict()


def _gate(value: Any) -> str:
    return _text(value).upper()


def build_pretrade_packet_context(
    *,
    donor_name: str,
    recipient_name: str,
    donor_kind: str,
    recipient_kind: str,
    comparison_amount_krw: float,
    portfolio: pd.DataFrame | None,
    assumption_health: pd.DataFrame | None,
    assumption_bridge: dict,
    bridge_reconciliation: dict,
    migration_review: dict,
    migration_v2_review: dict,
    cash_repair_plan: dict,
    quantity_plan: dict,
    sensitivity_plan: dict,
    quote_validation: dict,
) -> dict:
    """
    Build an immutable pre-trade decision snapshot.

    Completeness is independent from the investment decision:
    a packet can be REVIEW_COMPLETE while the underlying decision state is
    BLOCKED / REVIEW. That records a completed "do not execute" review without
    turning it into an authorization.
    """
    donor = _text(donor_name)
    recipient = _text(recipient_name)

    donor_health = _health_lookup(
        assumption_health,
        donor,
    )
    recipient_health = _health_lookup(
        assumption_health,
        recipient,
    )

    issues = []

    bridge_gate = _gate(
        assumption_bridge.get(
            "mapping_gate"
        )
    )
    bridge_recon_gate = _gate(
        bridge_reconciliation.get(
            "reconciliation_gate"
        )
    )
    quote_gate = _gate(
        quote_validation.get(
            "quote_validation_gate"
        )
    )
    quote_freshness = _gate(
        quote_validation.get(
            "quote_freshness_gate"
        )
    )

    if bridge_gate != "PASS":
        issues.append(
            "ASSUMPTION_BRIDGE_NOT_PASS"
        )
    if bridge_recon_gate != "PASS":
        issues.append(
            "ASSUMPTION_RECONCILIATION_NOT_PASS"
        )
    if _gate(
        donor_health.get(
            "health_status"
        )
    ) != "PASS":
        issues.append(
            "DONOR_ASSUMPTION_HEALTH_NOT_PASS"
        )
    if _gate(
        recipient_health.get(
            "health_status"
        )
    ) != "PASS":
        issues.append(
            "RECIPIENT_ASSUMPTION_HEALTH_NOT_PASS"
        )
    if quote_gate != "PASS":
        issues.append(
            "PRETRADE_QUOTE_VALIDATION_NOT_PASS"
        )
    if quote_freshness != "PASS":
        issues.append(
            "PRETRADE_QUOTE_NOT_FRESH"
        )

    assumption_hash = _text(
        assumption_bridge.get(
            "assumption_snapshot_hash"
        )
    )
    sensitivity_hash = _text(
        sensitivity_plan.get(
            "scenario_hash"
        )
    )
    quote_hash = _text(
        quote_validation.get(
            "quote_snapshot_hash"
        )
    )

    if not assumption_hash:
        issues.append(
            "ASSUMPTION_SNAPSHOT_HASH_REQUIRED"
        )
    if not sensitivity_hash:
        issues.append(
            "SENSITIVITY_SCENARIO_HASH_REQUIRED"
        )
    if not quote_hash:
        issues.append(
            "QUOTE_SNAPSHOT_HASH_REQUIRED"
        )

    portfolio_hash = dataframe_snapshot_hash(
        portfolio
    )

    migration_context_payload = {
        "legacy_migration_status":
            _text(
                migration_review.get(
                    "decision_status"
                )
            ),
        "migration_v2_status":
            _text(
                migration_v2_review.get(
                    "decision_status"
                )
            ),
        "legacy_migration_reason":
            _text(
                migration_review.get(
                    "decision_reason"
                )
            ),
        "migration_v2_reason":
            _text(
                migration_v2_review.get(
                    "decision_reason"
                )
            ),
        "donor_capacity_gate":
            _gate(
                migration_review.get(
                    "donor_capacity_gate"
                )
            ),
        "recipient_lifecycle_gate":
            _gate(
                migration_review.get(
                    "lifecycle_gate"
                )
            ),
        "recipient_execution_gate":
            _gate(
                migration_review.get(
                    "execution_gate"
                )
            ),
        "recipient_add_freeze_gate":
            _gate(
                migration_review.get(
                    "add_freeze_gate"
                )
            ),
        "recipient_survival_gate":
            _gate(
                migration_review.get(
                    "survival_gate"
                )
            ),
        "recipient_fit_gate":
            _gate(
                migration_review.get(
                    "fit_gate"
                )
            ),
        "recipient_capacity_gate":
            _gate(
                migration_review.get(
                    "recipient_capacity_gate"
                )
            ),
        "cash_reserve_gate":
            _gate(
                migration_review.get(
                    "cash_reserve_gate"
                )
            ),
        "switching_gap_gate":
            _gate(
                migration_review.get(
                    "switching_gap_gate"
                )
            ),
        "recipient_factor_risk_gate":
            _gate(
                migration_v2_review.get(
                    "recipient_factor_risk_gate"
                )
            ),
        "net_switching_gap":
            _stable_num(
                migration_review.get(
                    "net_switching_gap"
                )
            ),
        "migration_hurdle":
            _stable_num(
                migration_review.get(
                    "migration_hurdle"
                )
            ),
        "comparison_amount_krw":
            _stable_num(
                comparison_amount_krw,
                places=2,
            ),
    }
    migration_context_hash = _hash(
        migration_context_payload
    )

    # Decision state records the underlying result without endorsing it.
    decision_state = (
        _text(
            migration_v2_review.get(
                "decision_status"
            )
        )
        or _text(
            migration_review.get(
                "decision_status"
            )
        )
        or "REVIEW"
    )
    decision_reason = (
        _text(
            migration_v2_review.get(
                "decision_reason"
            )
        )
        or _text(
            migration_review.get(
                "decision_reason"
            )
        )
    )

    snapshot_payload = {
        "packet_schema":
            "v1",
        "donor":
            donor,
        "recipient":
            recipient,
        "donor_kind":
            _text(
                donor_kind
            ).upper(),
        "recipient_kind":
            _text(
                recipient_kind
            ).upper(),
        "comparison_amount_krw":
            _stable_num(
                comparison_amount_krw,
                places=2,
            ),
        "decision_state":
            decision_state,
        "decision_reason":
            decision_reason,
        "assumption_bridge": {
            "mapping_gate":
                bridge_gate,
            "assumption_snapshot_hash":
                assumption_hash,
            "donor_forward_er":
                _stable_num(
                    assumption_bridge.get(
                        "donor_forward_er"
                    )
                ),
            "donor_risk_penalty":
                _stable_num(
                    assumption_bridge.get(
                        "donor_risk_penalty"
                    )
                ),
            "donor_risk_adjusted_er":
                _stable_num(
                    assumption_bridge.get(
                        "donor_risk_adjusted_er"
                    )
                ),
            "recipient_forward_er":
                _stable_num(
                    assumption_bridge.get(
                        "recipient_forward_er"
                    )
                ),
            "recipient_risk_penalty":
                _stable_num(
                    assumption_bridge.get(
                        "recipient_risk_penalty"
                    )
                ),
            "recipient_risk_adjusted_er":
                _stable_num(
                    assumption_bridge.get(
                        "recipient_risk_adjusted_er"
                    )
                ),
        },
        "assumption_health": {
            "donor_health":
                _gate(
                    donor_health.get(
                        "health_status"
                    )
                ),
            "recipient_health":
                _gate(
                    recipient_health.get(
                        "health_status"
                    )
                ),
            "donor_provenance":
                _text(
                    donor_health.get(
                        "provenance_type"
                    )
                ),
            "recipient_provenance":
                _text(
                    recipient_health.get(
                        "provenance_type"
                    )
                ),
            "donor_revalidation_id":
                _text(
                    donor_health.get(
                        "latest_revalidation_id"
                    )
                ),
            "recipient_revalidation_id":
                _text(
                    recipient_health.get(
                        "latest_revalidation_id"
                    )
                ),
            "donor_calibration_id":
                _text(
                    donor_health.get(
                        "approved_calibration_id"
                    )
                ),
            "recipient_calibration_id":
                _text(
                    recipient_health.get(
                        "approved_calibration_id"
                    )
                ),
        },
        "bridge_reconciliation": {
            "gate":
                bridge_recon_gate,
            "cp_net_switching_gap_reference":
                _stable_num(
                    bridge_reconciliation.get(
                        "cp_net_switching_gap_reference"
                    )
                ),
            "migration_net_switching_gap":
                _stable_num(
                    bridge_reconciliation.get(
                        "migration_net_switching_gap"
                    )
                ),
            "net_gap_delta":
                _stable_num(
                    bridge_reconciliation.get(
                        "net_gap_delta"
                    )
                ),
        },
        "cash_repair": {
            "step1_gate":
                _gate(
                    cash_repair_plan.get(
                        "step1_cash_repair_gate"
                    )
                ),
            "required_cash_repair_krw":
                _stable_num(
                    cash_repair_plan.get(
                        "cash_shortfall_krw"
                    ),
                    places=2,
                ),
            "gross_trim_needed_krw":
                _stable_num(
                    cash_repair_plan.get(
                        "step1_required_gross_trim_krw"
                    ),
                    places=2,
                ),
            "step2_recipient_gate":
                _gate(
                    cash_repair_plan.get(
                        "step2_recipient_gate"
                    )
                ),
        },
        "quantity_step": {
            "gate":
                _gate(
                    quantity_plan.get(
                        "quantity_step_gate"
                    )
                ),
            "required_sell_quantity":
                _stable_num(
                    quantity_plan.get(
                        "required_sell_quantity"
                    ),
                    places=6,
                ),
            "executable_gross_trim_krw":
                _stable_num(
                    quantity_plan.get(
                        "executable_gross_trim_krw"
                    ),
                    places=2,
                ),
            "post_trade_cash_krw":
                _stable_num(
                    quantity_plan.get(
                        "post_trade_cash_krw"
                    ),
                    places=2,
                ),
        },
        "sensitivity": {
            "gate":
                _gate(
                    sensitivity_plan.get(
                        "robustness_gate"
                    )
                ),
            "boundary_status":
                _text(
                    sensitivity_plan.get(
                        "boundary_status"
                    )
                ),
            "break_even_sell_price_krw":
                _stable_num(
                    sensitivity_plan.get(
                        "break_even_sell_price_krw"
                    ),
                    places=2,
                ),
            "worst_case_required_quantity":
                _stable_num(
                    sensitivity_plan.get(
                        "worst_case_required_sell_quantity"
                    ),
                    places=6,
                ),
            "scenario_hash":
                sensitivity_hash,
        },
        "quote_validation": {
            "gate":
                quote_gate,
            "freshness_gate":
                quote_freshness,
            "source":
                _text(
                    quote_validation.get(
                        "quote_source"
                    )
                ),
            "timestamp":
                _text(
                    quote_validation.get(
                        "quote_timestamp"
                    )
                ),
            "quote_price_krw":
                _stable_num(
                    quote_validation.get(
                        "quote_price_krw"
                    ),
                    places=2,
                ),
            "required_quantity":
                _stable_num(
                    quote_validation.get(
                        "quote_required_sell_quantity"
                    ),
                    places=6,
                ),
            "boundary_status":
                _text(
                    quote_validation.get(
                        "boundary_status"
                    )
                ),
            "quote_snapshot_hash":
                quote_hash,
        },
        "migration_context_hash":
            migration_context_hash,
        "portfolio_snapshot_hash":
            portfolio_hash,
    }

    snapshot_json = json.dumps(
        snapshot_payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    snapshot_hash = hashlib.sha256(
        snapshot_json.encode(
            "utf-8"
        )
    ).hexdigest()

    completeness_gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    return {
        "donor":
            donor,
        "recipient":
            recipient,
        "donor_kind":
            _text(
                donor_kind
            ).upper(),
        "recipient_kind":
            _text(
                recipient_kind
            ).upper(),
        "comparison_amount_krw":
            max(
                0.0,
                float(
                    comparison_amount_krw
                    or 0.0
                ),
            ),
        "decision_state":
            decision_state,
        "decision_reason":
            decision_reason,
        "legacy_migration_status":
            _text(
                migration_review.get(
                    "decision_status"
                )
            ),
        "migration_v2_status":
            _text(
                migration_v2_review.get(
                    "decision_status"
                )
            ),
        "bridge_mapping_gate":
            bridge_gate,
        "bridge_reconciliation_gate":
            bridge_recon_gate,
        "donor_health":
            _gate(
                donor_health.get(
                    "health_status"
                )
            ),
        "recipient_health":
            _gate(
                recipient_health.get(
                    "health_status"
                )
            ),
        "donor_forward_er":
            _num(
                assumption_bridge.get(
                    "donor_forward_er"
                )
            ),
        "donor_risk_penalty":
            _num(
                assumption_bridge.get(
                    "donor_risk_penalty"
                )
            ),
        "donor_risk_adjusted_er":
            _num(
                assumption_bridge.get(
                    "donor_risk_adjusted_er"
                )
            ),
        "recipient_forward_er":
            _num(
                assumption_bridge.get(
                    "recipient_forward_er"
                )
            ),
        "recipient_risk_penalty":
            _num(
                assumption_bridge.get(
                    "recipient_risk_penalty"
                )
            ),
        "recipient_risk_adjusted_er":
            _num(
                assumption_bridge.get(
                    "recipient_risk_adjusted_er"
                )
            ),
        "net_switching_gap":
            _num(
                migration_review.get(
                    "net_switching_gap"
                )
            ),
        "migration_hurdle":
            _num(
                migration_review.get(
                    "migration_hurdle"
                )
            ),
        "recipient_hurdle_spread":
            _num(
                cash_repair_plan.get(
                    "recipient_hurdle_spread"
                )
            ),
        "recipient_headroom_krw":
            _num(
                cash_repair_plan.get(
                    "recipient_headroom_krw"
                )
            ),
        "cash_repair_gate":
            _gate(
                cash_repair_plan.get(
                    "step1_cash_repair_gate"
                )
            ),
        "required_cash_repair_krw":
            _num(
                cash_repair_plan.get(
                    "cash_shortfall_krw"
                )
            ),
        "gross_trim_needed_krw":
            _num(
                cash_repair_plan.get(
                    "step1_required_gross_trim_krw"
                )
            ),
        "quantity_step_gate":
            _gate(
                quantity_plan.get(
                    "quantity_step_gate"
                )
            ),
        "required_sell_quantity":
            _num(
                quantity_plan.get(
                    "required_sell_quantity"
                )
            ),
        "executable_gross_trim_krw":
            _num(
                quantity_plan.get(
                    "executable_gross_trim_krw"
                )
            ),
        "post_trade_cash_krw":
            _num(
                quantity_plan.get(
                    "post_trade_cash_krw"
                )
            ),
        "cash_over_repair_krw":
            _num(
                quantity_plan.get(
                    "cash_over_repair_krw"
                )
            ),
        "sensitivity_gate":
            _gate(
                sensitivity_plan.get(
                    "robustness_gate"
                )
            ),
        "sensitivity_boundary_status":
            _text(
                sensitivity_plan.get(
                    "boundary_status"
                )
            ),
        "break_even_sell_price_krw":
            _num(
                sensitivity_plan.get(
                    "break_even_sell_price_krw"
                )
            ),
        "worst_case_required_quantity":
            _num(
                sensitivity_plan.get(
                    "worst_case_required_sell_quantity"
                )
            ),
        "quote_validation_gate":
            quote_gate,
        "quote_freshness_gate":
            quote_freshness,
        "quote_source":
            _text(
                quote_validation.get(
                    "quote_source"
                )
            ),
        "quote_timestamp":
            _text(
                quote_validation.get(
                    "quote_timestamp"
                )
            ),
        "quote_price_krw":
            _num(
                quote_validation.get(
                    "quote_price_krw"
                )
            ),
        "quote_required_quantity":
            _num(
                quote_validation.get(
                    "quote_required_sell_quantity"
                )
            ),
        "quote_boundary_status":
            _text(
                quote_validation.get(
                    "boundary_status"
                )
            ),
        "donor_lifecycle_gate":
            _gate(
                migration_review.get(
                    "donor_capacity_gate"
                )
            ),
        "recipient_lifecycle_gate":
            _gate(
                migration_review.get(
                    "lifecycle_gate"
                )
            ),
        "recipient_execution_gate":
            _gate(
                migration_review.get(
                    "execution_gate"
                )
            ),
        "recipient_add_freeze_gate":
            _gate(
                migration_review.get(
                    "add_freeze_gate"
                )
            ),
        "recipient_survival_gate":
            _gate(
                migration_review.get(
                    "survival_gate"
                )
            ),
        "recipient_fit_gate":
            _gate(
                migration_review.get(
                    "fit_gate"
                )
            ),
        "recipient_capacity_gate":
            _gate(
                migration_review.get(
                    "recipient_capacity_gate"
                )
            ),
        "cash_reserve_gate":
            _gate(
                migration_review.get(
                    "cash_reserve_gate"
                )
            ),
        "switching_gap_gate":
            _gate(
                migration_review.get(
                    "switching_gap_gate"
                )
            ),
        "recipient_factor_risk_gate":
            _gate(
                migration_v2_review.get(
                    "recipient_factor_risk_gate"
                )
            ),
        "assumption_snapshot_hash":
            assumption_hash,
        "portfolio_snapshot_hash":
            portfolio_hash,
        "sensitivity_scenario_hash":
            sensitivity_hash,
        "quote_snapshot_hash":
            quote_hash,
        "migration_context_hash":
            migration_context_hash,
        "snapshot_hash":
            snapshot_hash,
        "snapshot_payload_json":
            snapshot_json,
        "completeness_gate":
            completeness_gate,
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def validate_pretrade_packet_review(
    context: dict,
    *,
    review_basis: str,
    source_gate_confirmed: bool,
    decision_gate_confirmed: bool,
    quote_gate_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    issues = []

    if _gate(
        context.get(
            "completeness_gate"
        )
    ) != "PASS":
        issues.append(
            "PACKET_CONTEXT_NOT_COMPLETE"
        )

    if not _text(
        review_basis
    ):
        issues.append(
            "PACKET_REVIEW_BASIS_REQUIRED"
        )

    confirmations = {
        "SOURCE_GATE_CONFIRMATION_REQUIRED":
            source_gate_confirmed,
        "DECISION_GATE_CONFIRMATION_REQUIRED":
            decision_gate_confirmed,
        "QUOTE_GATE_CONFIRMATION_REQUIRED":
            quote_gate_confirmed,
        "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED":
            no_execution_authorization_confirmed,
        "HUMAN_REVIEW_CONFIRMATION_REQUIRED":
            human_review_confirmed,
    }
    for issue, passed in confirmations.items():
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    return {
        "review_gate":
            "PASS"
            if not issues
            else "REVIEW",
        "final_packet_status":
            "REVIEW_COMPLETE"
            if not issues
            else "DRAFT",
        "execution_authorization":
            "NONE",
        "issues":
            issues,
    }


def _record_hash_payload(
    record: dict,
) -> dict:
    return {
        "packet_id":
            _text(
                record.get(
                    "packet_id"
                )
            ),
        "created_at":
            _text(
                record.get(
                    "created_at"
                )
            ),
        "packet_status":
            _text(
                record.get(
                    "packet_status"
                )
            ),
        "snapshot_hash":
            _text(
                record.get(
                    "snapshot_hash"
                )
            ),
        "review_basis":
            _text(
                record.get(
                    "review_basis"
                )
            ),
        "source_gate_confirmed":
            bool(
                _bool(
                    record.get(
                        "source_gate_confirmed"
                    )
                )
            ),
        "decision_gate_confirmed":
            bool(
                _bool(
                    record.get(
                        "decision_gate_confirmed"
                    )
                )
            ),
        "quote_gate_confirmed":
            bool(
                _bool(
                    record.get(
                        "quote_gate_confirmed"
                    )
                )
            ),
        "no_execution_authorization_confirmed":
            bool(
                _bool(
                    record.get(
                        "no_execution_authorization_confirmed"
                    )
                )
            ),
        "human_review_confirmed":
            bool(
                _bool(
                    record.get(
                        "human_review_confirmed"
                    )
                )
            ),
        "review_gate":
            _text(
                record.get(
                    "review_gate"
                )
            ),
        "execution_authorization":
            _text(
                record.get(
                    "execution_authorization"
                )
            ),
        "review_note":
            _text(
                record.get(
                    "review_note"
                )
            ),
    }


def build_pretrade_packet_record(
    context: dict,
    review: dict,
    *,
    save_status: str,
    review_basis: str,
    source_gate_confirmed: bool,
    decision_gate_confirmed: bool,
    quote_gate_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    review_note: str = "",
    created_at: str | None = None,
) -> dict:
    ctx = context or {}
    rev = review or {}

    requested = _text(
        save_status
    ).upper()
    if requested not in {
        "DRAFT",
        "REVIEW_COMPLETE",
    }:
        requested = "DRAFT"

    if (
        requested
        == "REVIEW_COMPLETE"
        and _gate(
            rev.get(
                "review_gate"
            )
        )
        != "PASS"
    ):
        packet_status = "DRAFT"
    else:
        packet_status = requested

    now = (
        _text(
            created_at
        )
        or datetime.now().isoformat()
    )
    snapshot_hash = _text(
        ctx.get(
            "snapshot_hash"
        )
    )

    packet_id = (
        "PTP-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + (
            snapshot_hash[:10]
            if snapshot_hash
            else "NOHASH"
        )
    )

    row = {
        "packet_id":
            packet_id,
        "created_at":
            now,
        "packet_status":
            packet_status,
        "packet_purpose":
            "PRE_TRADE_DECISION_REVIEW",
        "donor":
            _text(
                ctx.get("donor")
            ),
        "recipient":
            _text(
                ctx.get("recipient")
            ),
        "donor_kind":
            _text(
                ctx.get(
                    "donor_kind"
                )
            ),
        "recipient_kind":
            _text(
                ctx.get(
                    "recipient_kind"
                )
            ),
        "comparison_amount_krw":
            _num(
                ctx.get(
                    "comparison_amount_krw"
                )
            ),
        "decision_state":
            _text(
                ctx.get(
                    "decision_state"
                )
            ),
        "decision_reason":
            _text(
                ctx.get(
                    "decision_reason"
                )
            ),
        "legacy_migration_status":
            _text(
                ctx.get(
                    "legacy_migration_status"
                )
            ),
        "migration_v2_status":
            _text(
                ctx.get(
                    "migration_v2_status"
                )
            ),
        "bridge_mapping_gate":
            _text(
                ctx.get(
                    "bridge_mapping_gate"
                )
            ),
        "bridge_reconciliation_gate":
            _text(
                ctx.get(
                    "bridge_reconciliation_gate"
                )
            ),
        "donor_health":
            _text(
                ctx.get(
                    "donor_health"
                )
            ),
        "recipient_health":
            _text(
                ctx.get(
                    "recipient_health"
                )
            ),
        "donor_forward_er":
            _num(
                ctx.get(
                    "donor_forward_er"
                )
            ),
        "donor_risk_penalty":
            _num(
                ctx.get(
                    "donor_risk_penalty"
                )
            ),
        "donor_risk_adjusted_er":
            _num(
                ctx.get(
                    "donor_risk_adjusted_er"
                )
            ),
        "recipient_forward_er":
            _num(
                ctx.get(
                    "recipient_forward_er"
                )
            ),
        "recipient_risk_penalty":
            _num(
                ctx.get(
                    "recipient_risk_penalty"
                )
            ),
        "recipient_risk_adjusted_er":
            _num(
                ctx.get(
                    "recipient_risk_adjusted_er"
                )
            ),
        "net_switching_gap":
            _num(
                ctx.get(
                    "net_switching_gap"
                )
            ),
        "migration_hurdle":
            _num(
                ctx.get(
                    "migration_hurdle"
                )
            ),
        "recipient_hurdle_spread":
            _num(
                ctx.get(
                    "recipient_hurdle_spread"
                )
            ),
        "recipient_headroom_krw":
            _num(
                ctx.get(
                    "recipient_headroom_krw"
                )
            ),
        "cash_repair_gate":
            _text(
                ctx.get(
                    "cash_repair_gate"
                )
            ),
        "required_cash_repair_krw":
            _num(
                ctx.get(
                    "required_cash_repair_krw"
                )
            ),
        "gross_trim_needed_krw":
            _num(
                ctx.get(
                    "gross_trim_needed_krw"
                )
            ),
        "quantity_step_gate":
            _text(
                ctx.get(
                    "quantity_step_gate"
                )
            ),
        "required_sell_quantity":
            _num(
                ctx.get(
                    "required_sell_quantity"
                )
            ),
        "executable_gross_trim_krw":
            _num(
                ctx.get(
                    "executable_gross_trim_krw"
                )
            ),
        "post_trade_cash_krw":
            _num(
                ctx.get(
                    "post_trade_cash_krw"
                )
            ),
        "cash_over_repair_krw":
            _num(
                ctx.get(
                    "cash_over_repair_krw"
                )
            ),
        "sensitivity_gate":
            _text(
                ctx.get(
                    "sensitivity_gate"
                )
            ),
        "sensitivity_boundary_status":
            _text(
                ctx.get(
                    "sensitivity_boundary_status"
                )
            ),
        "break_even_sell_price_krw":
            _num(
                ctx.get(
                    "break_even_sell_price_krw"
                )
            ),
        "worst_case_required_quantity":
            _num(
                ctx.get(
                    "worst_case_required_quantity"
                )
            ),
        "quote_validation_gate":
            _text(
                ctx.get(
                    "quote_validation_gate"
                )
            ),
        "quote_freshness_gate":
            _text(
                ctx.get(
                    "quote_freshness_gate"
                )
            ),
        "quote_source":
            _text(
                ctx.get(
                    "quote_source"
                )
            ),
        "quote_timestamp":
            _text(
                ctx.get(
                    "quote_timestamp"
                )
            ),
        "quote_price_krw":
            _num(
                ctx.get(
                    "quote_price_krw"
                )
            ),
        "quote_required_quantity":
            _num(
                ctx.get(
                    "quote_required_quantity"
                )
            ),
        "quote_boundary_status":
            _text(
                ctx.get(
                    "quote_boundary_status"
                )
            ),
        "donor_lifecycle_gate":
            _text(
                ctx.get(
                    "donor_lifecycle_gate"
                )
            ),
        "recipient_lifecycle_gate":
            _text(
                ctx.get(
                    "recipient_lifecycle_gate"
                )
            ),
        "recipient_execution_gate":
            _text(
                ctx.get(
                    "recipient_execution_gate"
                )
            ),
        "recipient_add_freeze_gate":
            _text(
                ctx.get(
                    "recipient_add_freeze_gate"
                )
            ),
        "recipient_survival_gate":
            _text(
                ctx.get(
                    "recipient_survival_gate"
                )
            ),
        "recipient_fit_gate":
            _text(
                ctx.get(
                    "recipient_fit_gate"
                )
            ),
        "recipient_capacity_gate":
            _text(
                ctx.get(
                    "recipient_capacity_gate"
                )
            ),
        "cash_reserve_gate":
            _text(
                ctx.get(
                    "cash_reserve_gate"
                )
            ),
        "switching_gap_gate":
            _text(
                ctx.get(
                    "switching_gap_gate"
                )
            ),
        "recipient_factor_risk_gate":
            _text(
                ctx.get(
                    "recipient_factor_risk_gate"
                )
            ),
        "assumption_snapshot_hash":
            _text(
                ctx.get(
                    "assumption_snapshot_hash"
                )
            ),
        "portfolio_snapshot_hash":
            _text(
                ctx.get(
                    "portfolio_snapshot_hash"
                )
            ),
        "sensitivity_scenario_hash":
            _text(
                ctx.get(
                    "sensitivity_scenario_hash"
                )
            ),
        "quote_snapshot_hash":
            _text(
                ctx.get(
                    "quote_snapshot_hash"
                )
            ),
        "migration_context_hash":
            _text(
                ctx.get(
                    "migration_context_hash"
                )
            ),
        "snapshot_hash":
            snapshot_hash,
        "snapshot_payload_json":
            _text(
                ctx.get(
                    "snapshot_payload_json"
                )
            ),
        "review_basis":
            _text(
                review_basis
            ),
        "source_gate_confirmed":
            bool(
                source_gate_confirmed
            ),
        "decision_gate_confirmed":
            bool(
                decision_gate_confirmed
            ),
        "quote_gate_confirmed":
            bool(
                quote_gate_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "review_gate":
            _text(
                rev.get(
                    "review_gate"
                )
            ),
        "execution_authorization":
            "NONE",
        "review_note":
            _text(
                review_note
            ),
        "record_hash":
            "",
    }

    row["record_hash"] = _hash(
        _record_hash_payload(
            row
        )
    )
    return row


def pretrade_packet_integrity(
    packet_row: dict | None,
) -> dict:
    row = packet_row or {}

    snapshot_json = _text(
        row.get(
            "snapshot_payload_json"
        )
    )
    stored_snapshot_hash = _text(
        row.get(
            "snapshot_hash"
        )
    )
    stored_record_hash = _text(
        row.get(
            "record_hash"
        )
    )

    if not snapshot_json:
        snapshot_status = "MISSING"
    else:
        snapshot_status = (
            "OK"
            if hashlib.sha256(
                snapshot_json.encode(
                    "utf-8"
                )
            ).hexdigest()
            == stored_snapshot_hash
            else "MISMATCH"
        )

    record_status = (
        "MISSING"
        if not stored_record_hash
        else (
            "OK"
            if _hash(
                _record_hash_payload(
                    row
                )
            )
            == stored_record_hash
            else "MISMATCH"
        )
    )

    return {
        "snapshot_hash_status":
            snapshot_status,
        "record_hash_status":
            record_status,
        "integrity_status":
            "OK"
            if (
                snapshot_status
                == "OK"
                and record_status
                == "OK"
            )
            else "MISMATCH",
    }


# ============================================================
# v1.21.0-dev2
# Packet Freshness / STALE / INVALIDATED governance
# ============================================================

PRETRADE_PACKET_FRESHNESS_COLS = [
    "evaluated_at",
    "packet_id",
    "packet_created_at",
    "packet_status",
    "live_status",
    "locked_decision_state",
    "live_decision_state",
    "quote_age_minutes",
    "max_quote_age_minutes",
    "future_tolerance_minutes",
    "snapshot_hash_status",
    "record_hash_status",
    "integrity_status",
    "identity_status",
    "assumption_status",
    "portfolio_status",
    "migration_status",
    "sensitivity_status",
    "quote_status",
    "full_snapshot_status",
    "stored_assumption_snapshot_hash",
    "live_assumption_snapshot_hash",
    "stored_portfolio_snapshot_hash",
    "live_portfolio_snapshot_hash",
    "stored_migration_context_hash",
    "live_migration_context_hash",
    "stored_sensitivity_scenario_hash",
    "live_sensitivity_scenario_hash",
    "stored_quote_snapshot_hash",
    "live_quote_snapshot_hash",
    "stored_snapshot_hash",
    "live_snapshot_hash",
    "execution_authorization",
    "issues",
    "note",
    "evaluation_hash",
]


def _compare_text(
    stored: Any,
    live: Any,
) -> bool:
    return _text(stored) == _text(live)


def _compare_num(
    stored: Any,
    live: Any,
    tolerance: float = 1e-6,
) -> bool:
    a = _num(stored)
    b = _num(live)
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    return abs(a - b) <= max(0.0, float(tolerance))


def _component_check(
    component: str,
    stored_value: Any,
    live_value: Any,
    *,
    value_type: str = "text",
    tolerance: float = 1e-6,
) -> dict:
    if value_type == "number":
        match = _compare_num(
            stored_value,
            live_value,
            tolerance=tolerance,
        )
    else:
        match = _compare_text(
            stored_value,
            live_value,
        )

    return {
        "component": component,
        "stored": _text(stored_value),
        "live": _text(live_value),
        "status": "MATCH" if match else "DRIFT",
    }


def _aware_quote_age_minutes(
    quote_timestamp: Any,
    *,
    now: str | pd.Timestamp | None = None,
) -> dict:
    ts_text = _text(quote_timestamp)
    if not ts_text:
        return {
            "status": "MISSING",
            "age_minutes": None,
            "issue": "LOCKED_QUOTE_TIMESTAMP_MISSING",
        }

    try:
        quote_ts = pd.Timestamp(ts_text)
    except Exception:
        return {
            "status": "INVALID",
            "age_minutes": None,
            "issue": "LOCKED_QUOTE_TIMESTAMP_INVALID",
        }

    if quote_ts.tzinfo is None:
        return {
            "status": "TIMEZONE_REQUIRED",
            "age_minutes": None,
            "issue": "LOCKED_QUOTE_TIMESTAMP_TIMEZONE_REQUIRED",
        }

    try:
        if now is None:
            now_ts = pd.Timestamp.now(tz="UTC")
        else:
            now_ts = pd.Timestamp(now)
            if now_ts.tzinfo is None:
                now_ts = now_ts.tz_localize("UTC")
            else:
                now_ts = now_ts.tz_convert("UTC")
        quote_utc = quote_ts.tz_convert("UTC")
        age = (now_ts - quote_utc).total_seconds() / 60.0
    except Exception:
        return {
            "status": "INVALID",
            "age_minutes": None,
            "issue": "LOCKED_QUOTE_AGE_NOT_EVALUABLE",
        }

    return {
        "status": "OK",
        "age_minutes": float(age),
        "issue": "",
    }


def evaluate_pretrade_packet_freshness(
    packet_row: dict | None,
    live_context: dict | None,
    *,
    now: str | pd.Timestamp | None = None,
    max_quote_age_minutes: float = 5.0,
    future_tolerance_minutes: float = 2.0,
) -> dict:
    """
    Reconcile a locked REVIEW_COMPLETE packet with current live state.

    CURRENT:
      - locked packet integrity is intact
      - packet is REVIEW_COMPLETE
      - locked quote remains inside current freshness policy
      - identity / assumption / portfolio / migration / sensitivity / quote
        fingerprints still match current live context
      - live packet context remains complete

    STALE:
      - immutable historical packet is intact, but current state or time moved on

    INVALIDATED:
      - the stored immutable packet itself fails cryptographic/governance integrity

    CURRENT never means "buy/sell approved".
    Execution Authorization remains NONE.
    """
    row = packet_row or {}
    live = live_context or {}

    max_age = max(
        0.0,
        float(
            _num(max_quote_age_minutes)
            or 0.0
        ),
    )
    future_tol = max(
        0.0,
        float(
            _num(future_tolerance_minutes)
            or 0.0
        ),
    )

    integrity = pretrade_packet_integrity(row)

    invalidation_issues = []
    stale_issues = []
    component_checks = []

    if integrity["snapshot_hash_status"] != "OK":
        invalidation_issues.append(
            "LOCKED_SNAPSHOT_INTEGRITY_FAILED"
        )
    if integrity["record_hash_status"] != "OK":
        invalidation_issues.append(
            "LOCKED_RECORD_INTEGRITY_FAILED"
        )

    if _text(row.get("execution_authorization")).upper() != "NONE":
        invalidation_issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    if (
        _text(row.get("packet_status")).upper()
        == "REVIEW_COMPLETE"
        and _text(row.get("review_gate")).upper()
        != "PASS"
    ):
        invalidation_issues.append(
            "REVIEW_COMPLETE_WITHOUT_REVIEW_PASS"
        )

    if (
        _text(row.get("packet_status")).upper()
        != "REVIEW_COMPLETE"
    ):
        stale_issues.append(
            "PACKET_NOT_REVIEW_COMPLETE"
        )

    identity_fields = [
        ("Donor", "donor", "donor"),
        ("Recipient", "recipient", "recipient"),
        ("Donor Kind", "donor_kind", "donor_kind"),
        ("Recipient Kind", "recipient_kind", "recipient_kind"),
    ]
    identity_match = True
    for label, stored_key, live_key in identity_fields:
        check = _component_check(
            label,
            row.get(stored_key),
            live.get(live_key),
        )
        component_checks.append(check)
        if check["status"] != "MATCH":
            identity_match = False

    amount_check = _component_check(
        "Comparison Amount",
        row.get("comparison_amount_krw"),
        live.get("comparison_amount_krw"),
        value_type="number",
        tolerance=0.5,
    )
    component_checks.append(amount_check)
    if amount_check["status"] != "MATCH":
        identity_match = False

    if not identity_match:
        stale_issues.append(
            "PACKET_IDENTITY_OR_AMOUNT_DRIFT"
        )

    hash_specs = [
        (
            "Assumption Snapshot",
            "assumption_snapshot_hash",
            "ASSUMPTION_SNAPSHOT_DRIFT",
            "assumption_status",
        ),
        (
            "Portfolio Snapshot",
            "portfolio_snapshot_hash",
            "PORTFOLIO_SNAPSHOT_DRIFT",
            "portfolio_status",
        ),
        (
            "Migration Context",
            "migration_context_hash",
            "MIGRATION_CONTEXT_DRIFT",
            "migration_status",
        ),
        (
            "Sensitivity Scenario",
            "sensitivity_scenario_hash",
            "SENSITIVITY_SCENARIO_DRIFT",
            "sensitivity_status",
        ),
        (
            "Quote Snapshot",
            "quote_snapshot_hash",
            "QUOTE_SNAPSHOT_DRIFT",
            "quote_status",
        ),
        (
            "Full Packet Snapshot",
            "snapshot_hash",
            "FULL_PACKET_SNAPSHOT_DRIFT",
            "full_snapshot_status",
        ),
    ]

    component_statuses = {}
    for label, key, issue, status_key in hash_specs:
        check = _component_check(
            label,
            row.get(key),
            live.get(key),
        )
        component_checks.append(check)
        component_statuses[status_key] = check["status"]
        if check["status"] != "MATCH":
            stale_issues.append(issue)

    quote_age = _aware_quote_age_minutes(
        row.get("quote_timestamp"),
        now=now,
    )
    quote_age_minutes = quote_age.get(
        "age_minutes"
    )

    if quote_age.get("issue"):
        stale_issues.append(
            quote_age["issue"]
        )
    elif quote_age_minutes is not None:
        if quote_age_minutes < -future_tol:
            stale_issues.append(
                "LOCKED_QUOTE_TIMESTAMP_IN_FUTURE"
            )
        elif quote_age_minutes > max_age:
            stale_issues.append(
                "LOCKED_QUOTE_EXPIRED"
            )

    if _gate(
        live.get("quote_validation_gate")
    ) != "PASS":
        stale_issues.append(
            "LIVE_QUOTE_VALIDATION_NOT_PASS"
        )
    if _gate(
        live.get("quote_freshness_gate")
    ) != "PASS":
        stale_issues.append(
            "LIVE_QUOTE_NOT_FRESH"
        )
    if _gate(
        live.get("bridge_mapping_gate")
    ) != "PASS":
        stale_issues.append(
            "LIVE_ASSUMPTION_BRIDGE_NOT_PASS"
        )
    if _gate(
        live.get("bridge_reconciliation_gate")
    ) != "PASS":
        stale_issues.append(
            "LIVE_ASSUMPTION_RECONCILIATION_NOT_PASS"
        )
    if _gate(
        live.get("donor_health")
    ) != "PASS":
        stale_issues.append(
            "LIVE_DONOR_ASSUMPTION_HEALTH_NOT_PASS"
        )
    if _gate(
        live.get("recipient_health")
    ) != "PASS":
        stale_issues.append(
            "LIVE_RECIPIENT_ASSUMPTION_HEALTH_NOT_PASS"
        )
    if _gate(
        live.get("completeness_gate")
    ) != "PASS":
        stale_issues.append(
            "LIVE_PACKET_CONTEXT_NOT_COMPLETE"
        )

    invalidation_issues = list(
        dict.fromkeys(invalidation_issues)
    )
    stale_issues = list(
        dict.fromkeys(stale_issues)
    )

    if invalidation_issues:
        live_status = "INVALIDATED"
        issues = invalidation_issues + stale_issues
    elif stale_issues:
        live_status = "STALE"
        issues = stale_issues
    else:
        live_status = "CURRENT"
        issues = []

    return {
        "packet_id": _text(
            row.get("packet_id")
        ),
        "packet_status": _text(
            row.get("packet_status")
        ).upper(),
        "packet_created_at": _text(
            row.get("created_at")
        ),
        "live_status": live_status,
        "locked_decision_state": _text(
            row.get("decision_state")
        ),
        "live_decision_state": _text(
            live.get("decision_state")
        ),
        "quote_age_minutes": quote_age_minutes,
        "max_quote_age_minutes": max_age,
        "future_tolerance_minutes": future_tol,
        "snapshot_hash_status":
            integrity["snapshot_hash_status"],
        "record_hash_status":
            integrity["record_hash_status"],
        "integrity_status":
            integrity["integrity_status"],
        "identity_status":
            "MATCH" if identity_match else "DRIFT",
        "assumption_status":
            component_statuses.get(
                "assumption_status",
                "DRIFT",
            ),
        "portfolio_status":
            component_statuses.get(
                "portfolio_status",
                "DRIFT",
            ),
        "migration_status":
            component_statuses.get(
                "migration_status",
                "DRIFT",
            ),
        "sensitivity_status":
            component_statuses.get(
                "sensitivity_status",
                "DRIFT",
            ),
        "quote_status":
            component_statuses.get(
                "quote_status",
                "DRIFT",
            ),
        "full_snapshot_status":
            component_statuses.get(
                "full_snapshot_status",
                "DRIFT",
            ),
        "stored_assumption_snapshot_hash": _text(
            row.get("assumption_snapshot_hash")
        ),
        "live_assumption_snapshot_hash": _text(
            live.get("assumption_snapshot_hash")
        ),
        "stored_portfolio_snapshot_hash": _text(
            row.get("portfolio_snapshot_hash")
        ),
        "live_portfolio_snapshot_hash": _text(
            live.get("portfolio_snapshot_hash")
        ),
        "stored_migration_context_hash": _text(
            row.get("migration_context_hash")
        ),
        "live_migration_context_hash": _text(
            live.get("migration_context_hash")
        ),
        "stored_sensitivity_scenario_hash": _text(
            row.get("sensitivity_scenario_hash")
        ),
        "live_sensitivity_scenario_hash": _text(
            live.get("sensitivity_scenario_hash")
        ),
        "stored_quote_snapshot_hash": _text(
            row.get("quote_snapshot_hash")
        ),
        "live_quote_snapshot_hash": _text(
            live.get("quote_snapshot_hash")
        ),
        "stored_snapshot_hash": _text(
            row.get("snapshot_hash")
        ),
        "live_snapshot_hash": _text(
            live.get("snapshot_hash")
        ),
        "execution_authorization": "NONE",
        "issues": issues,
        "invalidation_issues": invalidation_issues,
        "stale_issues": stale_issues,
        "component_checks": component_checks,
    }


def _freshness_evaluation_payload(
    row: dict,
) -> dict:
    return {
        "evaluated_at": _text(
            row.get("evaluated_at")
        ),
        "packet_id": _text(
            row.get("packet_id")
        ),
        "packet_created_at": _text(
            row.get("packet_created_at")
        ),
        "packet_status": _text(
            row.get("packet_status")
        ),
        "live_status": _text(
            row.get("live_status")
        ),
        "locked_decision_state": _text(
            row.get("locked_decision_state")
        ),
        "live_decision_state": _text(
            row.get("live_decision_state")
        ),
        "quote_age_minutes": _stable_num(
            row.get("quote_age_minutes"),
            places=6,
        ),
        "max_quote_age_minutes": _stable_num(
            row.get("max_quote_age_minutes"),
            places=6,
        ),
        "integrity_status": _text(
            row.get("integrity_status")
        ),
        "identity_status": _text(
            row.get("identity_status")
        ),
        "assumption_status": _text(
            row.get("assumption_status")
        ),
        "portfolio_status": _text(
            row.get("portfolio_status")
        ),
        "migration_status": _text(
            row.get("migration_status")
        ),
        "sensitivity_status": _text(
            row.get("sensitivity_status")
        ),
        "quote_status": _text(
            row.get("quote_status")
        ),
        "full_snapshot_status": _text(
            row.get("full_snapshot_status")
        ),
        "stored_snapshot_hash": _text(
            row.get("stored_snapshot_hash")
        ),
        "live_snapshot_hash": _text(
            row.get("live_snapshot_hash")
        ),
        "execution_authorization": "NONE",
        "issues": _text(
            row.get("issues")
        ),
        "note": _text(
            row.get("note")
        ),
    }


def build_pretrade_packet_freshness_record(
    evaluation: dict,
    *,
    note: str = "",
    evaluated_at: str | None = None,
) -> dict:
    e = evaluation or {}
    now_text = (
        _text(evaluated_at)
        or datetime.now().astimezone().isoformat()
    )

    row = {
        "evaluated_at": now_text,
        "packet_id": _text(
            e.get("packet_id")
        ),
        "packet_created_at": _text(
            e.get("packet_created_at")
        ),
        "packet_status": _text(
            e.get("packet_status")
        ),
        "live_status": _text(
            e.get("live_status")
        ),
        "locked_decision_state": _text(
            e.get("locked_decision_state")
        ),
        "live_decision_state": _text(
            e.get("live_decision_state")
        ),
        "quote_age_minutes": _num(
            e.get("quote_age_minutes")
        ),
        "max_quote_age_minutes": _num(
            e.get("max_quote_age_minutes")
        ),
        "future_tolerance_minutes": _num(
            e.get("future_tolerance_minutes")
        ),
        "snapshot_hash_status": _text(
            e.get("snapshot_hash_status")
        ),
        "record_hash_status": _text(
            e.get("record_hash_status")
        ),
        "integrity_status": _text(
            e.get("integrity_status")
        ),
        "identity_status": _text(
            e.get("identity_status")
        ),
        "assumption_status": _text(
            e.get("assumption_status")
        ),
        "portfolio_status": _text(
            e.get("portfolio_status")
        ),
        "migration_status": _text(
            e.get("migration_status")
        ),
        "sensitivity_status": _text(
            e.get("sensitivity_status")
        ),
        "quote_status": _text(
            e.get("quote_status")
        ),
        "full_snapshot_status": _text(
            e.get("full_snapshot_status")
        ),
        "stored_assumption_snapshot_hash": _text(
            e.get("stored_assumption_snapshot_hash")
        ),
        "live_assumption_snapshot_hash": _text(
            e.get("live_assumption_snapshot_hash")
        ),
        "stored_portfolio_snapshot_hash": _text(
            e.get("stored_portfolio_snapshot_hash")
        ),
        "live_portfolio_snapshot_hash": _text(
            e.get("live_portfolio_snapshot_hash")
        ),
        "stored_migration_context_hash": _text(
            e.get("stored_migration_context_hash")
        ),
        "live_migration_context_hash": _text(
            e.get("live_migration_context_hash")
        ),
        "stored_sensitivity_scenario_hash": _text(
            e.get("stored_sensitivity_scenario_hash")
        ),
        "live_sensitivity_scenario_hash": _text(
            e.get("live_sensitivity_scenario_hash")
        ),
        "stored_quote_snapshot_hash": _text(
            e.get("stored_quote_snapshot_hash")
        ),
        "live_quote_snapshot_hash": _text(
            e.get("live_quote_snapshot_hash")
        ),
        "stored_snapshot_hash": _text(
            e.get("stored_snapshot_hash")
        ),
        "live_snapshot_hash": _text(
            e.get("live_snapshot_hash")
        ),
        "execution_authorization": "NONE",
        "issues": " | ".join(
            e.get("issues", [])
        ),
        "note": _text(note),
        "evaluation_hash": "",
    }

    row["evaluation_hash"] = _hash(
        _freshness_evaluation_payload(row)
    )
    return row

