from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import json
import os
import re

import pandas as pd


RECOVERY_POINT_LOCK_COLS = [
    "recovery_point_id",
    "created_at",
    "backup_folder_name",
    "backup_modified",
    "manifest_sha256",
    "manifest_entries",
    "manifest_files_ok",
    "manifest_missing",
    "manifest_hash_mismatch",
    "dryrun_files_checked",
    "dryrun_csv_ok",
    "dryrun_json_ok",
    "dryrun_parse_fail",
    "discovery_source",
    "manifest_status",
    "dryrun_status",
    "lock_gate",
    "lock_status",
    "manifest_confirmed",
    "dryrun_no_write_confirmed",
    "no_restore_authorization_confirmed",
    "human_review_confirmed",
    "restore_authorization",
    "issues",
    "note",
    "record_hash",
]


MANIFEST_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


_HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash_bytes(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _hash_payload(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _parse_ts(value: Any) -> pd.Timestamp | None:
    raw = _text(value)
    if not raw:
        return None
    ts = pd.to_datetime(
        raw,
        errors="coerce",
        utc=True,
    )
    if pd.isna(ts):
        return None
    return ts


def _candidate_from_value(
    value: Any,
    project_root: Path,
) -> list[Path]:
    raw = _text(value)
    if not raw:
        return []

    p = Path(raw)
    candidates = []

    if p.is_absolute():
        candidates.append(
            p
        )
    else:
        candidates.extend(
            [
                project_root / p,
                project_root / "backups" / p,
                project_root / "backup" / p,
                project_root / "user_backups" / p,
                project_root / "data_backups" / p,
                project_root / "data" / "backups" / p,
            ]
        )

    return candidates


def discover_latest_backup_folder(
    project_root: str | Path,
    backup_info: dict | None = None,
) -> dict:
    root = Path(
        project_root
    ).resolve()
    info = backup_info or {}

    explicit = []

    for key in [
        "path",
        "folder",
        "dir",
        "backup_path",
        "backup_dir",
        "name",
    ]:
        explicit.extend(
            _candidate_from_value(
                info.get(
                    key
                ),
                root,
            )
        )

    checked = []

    for candidate in explicit:
        checked.append(
            str(
                candidate
            )
        )
        folder = (
            candidate.parent
            if candidate.name.lower()
            == "manifest.json"
            else candidate
        )
        if (
            folder.is_dir()
            and (
                folder
                / "manifest.json"
            ).is_file()
        ):
            return {
                "status":
                    "FOUND",
                "backup_folder":
                    str(
                        folder.resolve()
                    ),
                "folder_name":
                    folder.name,
                "manifest_path":
                    str(
                        (
                            folder
                            / "manifest.json"
                        ).resolve()
                    ),
                "discovery_source":
                    "BACKUP_INFO",
                "candidates_checked":
                    len(
                        checked
                    ),
                "issues":
                    [],
            }

    search_roots = [
        root / "backups",
        root / "backup",
        root / "user_backups",
        root / "data_backups",
        root / "data" / "backups",
        root / "data" / "backup",
    ]

    manifests = []

    for search_root in search_roots:
        if not search_root.is_dir():
            continue

        try:
            for manifest in search_root.rglob(
                "manifest.json"
            ):
                if manifest.is_file():
                    manifests.append(
                        manifest
                    )
        except Exception:
            continue

    # Conservative fallback: scan project root, pruning large/code dirs.
    if not manifests:
        skip_dirs = {
            ".venv",
            "venv",
            "__pycache__",
            ".git",
            "engine",
            "connectors",
            "node_modules",
        }

        try:
            for current, dirs, files in os.walk(
                root
            ):
                rel_parts = Path(
                    current
                ).relative_to(
                    root
                ).parts

                if len(
                    rel_parts
                ) > 4:
                    dirs[:] = []
                    continue

                dirs[:] = [
                    d
                    for d in dirs
                    if d
                    not in skip_dirs
                ]

                if "manifest.json" in files:
                    manifests.append(
                        Path(
                            current
                        )
                        / "manifest.json"
                    )
        except Exception:
            pass

    if not manifests:
        return {
            "status":
                "NOT_FOUND",
            "backup_folder":
                "",
            "folder_name":
                "",
            "manifest_path":
                "",
            "discovery_source":
                "NONE",
            "candidates_checked":
                len(
                    checked
                ),
            "issues":
                [
                    "BACKUP_MANIFEST_NOT_FOUND"
                ],
        }

    target_modified = _parse_ts(
        info.get(
            "modified"
        )
    )

    ranked = []

    for manifest in manifests:
        try:
            mtime = pd.Timestamp(
                manifest.stat().st_mtime,
                unit="s",
                tz="UTC",
            )
        except Exception:
            mtime = pd.Timestamp(
                "1970-01-01",
                tz="UTC",
            )

        if target_modified is None:
            distance = 0.0
        else:
            distance = abs(
                (
                    mtime
                    - target_modified
                ).total_seconds()
            )

        ranked.append(
            (
                distance,
                -mtime.timestamp(),
                manifest,
            )
        )

    ranked.sort(
        key=lambda x: (
            x[0],
            x[1],
        )
    )

    selected = ranked[
        0
    ][
        2
    ]
    folder = selected.parent

    return {
        "status":
            "FOUND",
        "backup_folder":
            str(
                folder.resolve()
            ),
        "folder_name":
            folder.name,
        "manifest_path":
            str(
                selected.resolve()
            ),
        "discovery_source":
            "PROJECT_SCAN",
        "candidates_checked":
            len(
                manifests
            ),
        "issues":
            [],
    }


def _entry_from_dict(
    item: dict,
) -> tuple[str, str] | None:
    path_value = ""

    for key in [
        "path",
        "file",
        "filename",
        "name",
        "relative_path",
        "relpath",
    ]:
        if _text(
            item.get(
                key
            )
        ):
            path_value = _text(
                item.get(
                    key
                )
            )
            break

    hash_value = ""

    for key in [
        "sha256",
        "sha_256",
        "hash",
        "checksum",
    ]:
        candidate = _text(
            item.get(
                key
            )
        )
        if _HEX64.match(
            candidate
        ):
            hash_value = candidate.lower()
            break

    if (
        path_value
        and hash_value
    ):
        return (
            path_value,
            hash_value,
        )

    return None


def extract_manifest_entries(
    manifest_obj: Any,
) -> list[dict]:
    entries = []

    def add(
        path_value: Any,
        hash_value: Any,
    ):
        p = _text(
            path_value
        )
        h = _text(
            hash_value
        ).lower()

        if (
            p
            and _HEX64.match(
                h
            )
        ):
            entries.append(
                {
                    "path":
                        p,
                    "sha256":
                        h,
                }
            )

    if isinstance(
        manifest_obj,
        list,
    ):
        for item in manifest_obj:
            if isinstance(
                item,
                dict,
            ):
                parsed = _entry_from_dict(
                    item
                )
                if parsed:
                    add(
                        *parsed
                    )

    elif isinstance(
        manifest_obj,
        dict,
    ):
        for container_key in [
            "files",
            "manifest",
            "entries",
        ]:
            container = manifest_obj.get(
                container_key
            )

            if isinstance(
                container,
                dict,
            ):
                for key, value in container.items():
                    if isinstance(
                        value,
                        dict,
                    ):
                        parsed = _entry_from_dict(
                            {
                                **value,
                                "path":
                                    value.get(
                                        "path",
                                        key,
                                    ),
                            }
                        )
                        if parsed:
                            add(
                                *parsed
                            )
                    else:
                        add(
                            key,
                            value,
                        )

            elif isinstance(
                container,
                list,
            ):
                for item in container:
                    if isinstance(
                        item,
                        dict,
                    ):
                        parsed = _entry_from_dict(
                            item
                        )
                        if parsed:
                            add(
                                *parsed
                            )

        # Direct {relative_path: sha256} or {relative_path: {sha256:...}}
        for key, value in manifest_obj.items():
            if key in {
                "files",
                "manifest",
                "entries",
            }:
                continue

            if isinstance(
                value,
                dict,
            ):
                parsed = _entry_from_dict(
                    {
                        **value,
                        "path":
                            value.get(
                                "path",
                                key,
                            ),
                    }
                )
                if parsed:
                    add(
                        *parsed
                    )
            else:
                add(
                    key,
                    value,
                )

    # Deduplicate by path, last value wins.
    dedup = {}
    for item in entries:
        dedup[
            item[
                "path"
            ]
        ] = item[
            "sha256"
        ]

    return [
        {
            "path":
                key,
            "sha256":
                value,
        }
        for key, value in dedup.items()
    ]


def _resolve_backup_file(
    backup_folder: Path,
    entry_path: str,
) -> Path | None:
    raw = _text(
        entry_path
    ).replace(
        "\\",
        "/",
    )

    if not raw:
        return None

    p = Path(
        raw
    )

    candidates = []

    if p.is_absolute():
        candidates.append(
            p
        )
    else:
        candidates.append(
            backup_folder
            / p
        )

        # Some manifests may store "data/x.csv" while the backup flattens data files.
        if len(
            p.parts
        ) > 1:
            candidates.append(
                backup_folder
                / p.name
            )

    for candidate in candidates:
        try:
            if candidate.is_file():
                return candidate
        except Exception:
            pass

    # Safe basename fallback if uniquely present.
    try:
        hits = [
            x
            for x in backup_folder.rglob(
                p.name
            )
            if x.is_file()
        ]
    except Exception:
        hits = []

    if len(
        hits
    ) == 1:
        return hits[
            0
        ]

    return None


def verify_backup_manifest(
    discovery: dict | None,
) -> dict:
    info = discovery or {}

    if _text(
        info.get(
            "status"
        )
    ).upper() != "FOUND":
        return {
            "manifest_status":
                "REVIEW",
            "backup_folder":
                "",
            "folder_name":
                "",
            "manifest_path":
                "",
            "manifest_sha256":
                "",
            "manifest_entries":
                0,
            "files_ok":
                0,
            "missing_files":
                0,
            "hash_mismatch":
                0,
            "entry_rows":
                pd.DataFrame(),
            "issues":
                [
                    "BACKUP_FOLDER_NOT_DISCOVERED"
                ],
        }

    folder = Path(
        _text(
            info.get(
                "backup_folder"
            )
        )
    )
    manifest_path = Path(
        _text(
            info.get(
                "manifest_path"
            )
        )
    )

    if not manifest_path.is_file():
        return {
            "manifest_status":
                "BLOCKED",
            "backup_folder":
                str(
                    folder
                ),
            "folder_name":
                folder.name,
            "manifest_path":
                str(
                    manifest_path
                ),
            "manifest_sha256":
                "",
            "manifest_entries":
                0,
            "files_ok":
                0,
            "missing_files":
                0,
            "hash_mismatch":
                0,
            "entry_rows":
                pd.DataFrame(),
            "issues":
                [
                    "MANIFEST_JSON_MISSING"
                ],
        }

    try:
        manifest_sha = _hash_bytes(
            manifest_path
        )
        manifest_obj = json.loads(
            manifest_path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {
            "manifest_status":
                "BLOCKED",
            "backup_folder":
                str(
                    folder
                ),
            "folder_name":
                folder.name,
            "manifest_path":
                str(
                    manifest_path
                ),
            "manifest_sha256":
                "",
            "manifest_entries":
                0,
            "files_ok":
                0,
            "missing_files":
                0,
            "hash_mismatch":
                0,
            "entry_rows":
                pd.DataFrame(),
            "issues":
                [
                    "MANIFEST_JSON_INVALID"
                ],
        }

    entries = extract_manifest_entries(
        manifest_obj
    )

    if not entries:
        return {
            "manifest_status":
                "BLOCKED",
            "backup_folder":
                str(
                    folder
                ),
            "folder_name":
                folder.name,
            "manifest_path":
                str(
                    manifest_path
                ),
            "manifest_sha256":
                manifest_sha,
            "manifest_entries":
                0,
            "files_ok":
                0,
            "missing_files":
                0,
            "hash_mismatch":
                0,
            "entry_rows":
                pd.DataFrame(),
            "issues":
                [
                    "MANIFEST_NO_HASH_ENTRIES"
                ],
        }

    rows = []
    files_ok = 0
    missing = 0
    mismatch = 0

    for entry in entries:
        path_text = entry[
            "path"
        ]
        expected = entry[
            "sha256"
        ]
        actual_file = _resolve_backup_file(
            folder,
            path_text,
        )

        if actual_file is None:
            status = "MISSING"
            actual_hash = ""
            missing += 1
        else:
            try:
                actual_hash = _hash_bytes(
                    actual_file
                )
            except Exception:
                actual_hash = ""

            if actual_hash == expected:
                status = "PASS"
                files_ok += 1
            else:
                status = "HASH_MISMATCH"
                mismatch += 1

        rows.append(
            {
                "manifest_path":
                    path_text,
                "status":
                    status,
                "expected_sha256":
                    expected,
                "actual_sha256":
                    actual_hash,
            }
        )

    issues = []

    if missing > 0:
        issues.append(
            "MANIFEST_FILE_MISSING"
        )

    if mismatch > 0:
        issues.append(
            "MANIFEST_HASH_MISMATCH"
        )

    status = (
        "PASS"
        if not issues
        else "BLOCKED"
    )

    return {
        "manifest_status":
            status,
        "backup_folder":
            str(
                folder.resolve()
            ),
        "folder_name":
            folder.name,
        "manifest_path":
            str(
                manifest_path.resolve()
            ),
        "manifest_sha256":
            manifest_sha,
        "manifest_entries":
            len(
                entries
            ),
        "files_ok":
            files_ok,
        "missing_files":
            missing,
        "hash_mismatch":
            mismatch,
        "entry_rows":
            pd.DataFrame(
                rows
            ),
        "issues":
            issues,
    }


def restore_dry_run(
    verification: dict | None,
) -> dict:
    result = verification or {}

    if _text(
        result.get(
            "manifest_status"
        )
    ).upper() != "PASS":
        return {
            "dryrun_status":
                "BLOCKED",
            "files_checked":
                0,
            "csv_ok":
                0,
            "json_ok":
                0,
            "binary_ok":
                0,
            "private_skipped":
                0,
            "parse_fail":
                0,
            "rows":
                pd.DataFrame(),
            "issues":
                [
                    "MANIFEST_PASS_REQUIRED"
                ],
            "restore_authorization":
                "NONE",
        }

    folder = Path(
        _text(
            result.get(
                "backup_folder"
            )
        )
    )

    entry_rows = result.get(
        "entry_rows"
    )

    if (
        not isinstance(
            entry_rows,
            pd.DataFrame,
        )
        or entry_rows.empty
    ):
        return {
            "dryrun_status":
                "BLOCKED",
            "files_checked":
                0,
            "csv_ok":
                0,
            "json_ok":
                0,
            "binary_ok":
                0,
            "private_skipped":
                0,
            "parse_fail":
                0,
            "rows":
                pd.DataFrame(),
            "issues":
                [
                    "NO_VERIFIED_MANIFEST_ENTRIES"
                ],
            "restore_authorization":
                "NONE",
        }

    rows = []
    csv_ok = 0
    json_ok = 0
    binary_ok = 0
    private_skipped = 0
    parse_fail = 0

    for _, manifest_row in entry_rows.iterrows():
        rel = _text(
            manifest_row.get(
                "manifest_path"
            )
        )
        file_path = _resolve_backup_file(
            folder,
            rel,
        )

        if file_path is None:
            rows.append(
                {
                    "file":
                        rel,
                    "type":
                        "",
                    "status":
                        "MISSING",
                    "detail":
                        "verified entry file not found during dry-run",
                }
            )
            parse_fail += 1
            continue

        suffix = file_path.suffix.lower()
        name = file_path.name.lower()

        try:
            if name == ".env":
                status = "SKIPPED_PRIVATE"
                detail = "private file existence verified; content not parsed"
                private_skipped += 1

            elif suffix == ".csv":
                try:
                    pd.read_csv(
                        file_path,
                        dtype=str,
                        keep_default_na=False,
                    )
                except pd.errors.EmptyDataError:
                    # Empty CSV can still be restored byte-for-byte.
                    pass

                status = "PASS"
                detail = "CSV readable"
                csv_ok += 1

            elif suffix == ".json":
                json.loads(
                    file_path.read_text(
                        encoding="utf-8"
                    )
                )
                status = "PASS"
                detail = "JSON parseable"
                json_ok += 1

            else:
                with file_path.open(
                    "rb"
                ) as f:
                    f.read(
                        1
                    )
                status = "PASS"
                detail = "binary/readable"
                binary_ok += 1

        except Exception as exc:
            status = "PARSE_FAIL"
            detail = type(
                exc
            ).__name__
            parse_fail += 1

        rows.append(
            {
                "file":
                    rel,
                "type":
                    suffix
                    or name,
                "status":
                    status,
                "detail":
                    detail,
            }
        )

    issues = []

    if parse_fail > 0:
        issues.append(
            "RESTORE_DRYRUN_PARSE_FAIL"
        )

    return {
        "dryrun_status":
            (
                "PASS"
                if not issues
                else "BLOCKED"
            ),
        "files_checked":
            len(
                rows
            ),
        "csv_ok":
            csv_ok,
        "json_ok":
            json_ok,
        "binary_ok":
            binary_ok,
        "private_skipped":
            private_skipped,
        "parse_fail":
            parse_fail,
        "rows":
            pd.DataFrame(
                rows
            ),
        "issues":
            issues,
        "restore_authorization":
            "NONE",
    }


def validate_recovery_point_lock(
    verification: dict | None,
    dry_run: dict | None,
    *,
    manifest_confirmed: bool,
    dryrun_no_write_confirmed: bool,
    no_restore_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    manifest = verification or {}
    dry = dry_run or {}
    issues = []

    if _text(
        manifest.get(
            "manifest_status"
        )
    ).upper() != "PASS":
        issues.append(
            "MANIFEST_VERIFICATION_PASS_REQUIRED"
        )

    if _text(
        dry.get(
            "dryrun_status"
        )
    ).upper() != "PASS":
        issues.append(
            "RESTORE_DRYRUN_PASS_REQUIRED"
        )

    if not _bool(
        manifest_confirmed
    ):
        issues.append(
            "MANIFEST_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        dryrun_no_write_confirmed
    ):
        issues.append(
            "DRYRUN_NO_WRITE_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        no_restore_authorization_confirmed
    ):
        issues.append(
            "NO_RESTORE_AUTHORIZATION_CONFIRMATION_REQUIRED"
        )

    if not _bool(
        human_review_confirmed
    ):
        issues.append(
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED"
        )

    gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    return {
        "lock_gate":
            gate,
        "lock_status":
            (
                "RECOVERY_POINT_LOCKED"
                if gate == "PASS"
                else "DRAFT"
            ),
        "restore_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _lock_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "manifest_confirmed",
        "dryrun_no_write_confirmed",
        "no_restore_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in RECOVERY_POINT_LOCK_COLS:
        if col == "record_hash":
            continue

        if col in bool_fields:
            payload[
                col
            ] = bool(
                _bool(
                    row.get(
                        col
                    )
                )
            )
        else:
            payload[
                col
            ] = _text(
                row.get(
                    col
                )
            )

    return payload


def build_recovery_point_lock_record(
    discovery: dict,
    verification: dict,
    dry_run: dict,
    validation: dict,
    *,
    backup_modified: str = "",
    manifest_confirmed: bool,
    dryrun_no_write_confirmed: bool,
    no_restore_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    manifest_sha = _text(
        verification.get(
            "manifest_sha256"
        )
    )

    recovery_point_id = (
        "RPL-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + (
            manifest_sha[:8]
            if manifest_sha
            else "NOHASH"
        )
    )

    row = {
        "recovery_point_id":
            recovery_point_id,
        "created_at":
            now,
        "backup_folder_name":
            _text(
                discovery.get(
                    "folder_name"
                )
            ),
        "backup_modified":
            _text(
                backup_modified
            ),
        "manifest_sha256":
            manifest_sha,
        "manifest_entries":
            _int(
                verification.get(
                    "manifest_entries"
                )
            ),
        "manifest_files_ok":
            _int(
                verification.get(
                    "files_ok"
                )
            ),
        "manifest_missing":
            _int(
                verification.get(
                    "missing_files"
                )
            ),
        "manifest_hash_mismatch":
            _int(
                verification.get(
                    "hash_mismatch"
                )
            ),
        "dryrun_files_checked":
            _int(
                dry_run.get(
                    "files_checked"
                )
            ),
        "dryrun_csv_ok":
            _int(
                dry_run.get(
                    "csv_ok"
                )
            ),
        "dryrun_json_ok":
            _int(
                dry_run.get(
                    "json_ok"
                )
            ),
        "dryrun_parse_fail":
            _int(
                dry_run.get(
                    "parse_fail"
                )
            ),
        "discovery_source":
            _text(
                discovery.get(
                    "discovery_source"
                )
            ),
        "manifest_status":
            _text(
                verification.get(
                    "manifest_status"
                )
            ),
        "dryrun_status":
            _text(
                dry_run.get(
                    "dryrun_status"
                )
            ),
        "lock_gate":
            _text(
                validation.get(
                    "lock_gate"
                )
            ),
        "lock_status":
            _text(
                validation.get(
                    "lock_status"
                )
            ),
        "manifest_confirmed":
            bool(
                manifest_confirmed
            ),
        "dryrun_no_write_confirmed":
            bool(
                dryrun_no_write_confirmed
            ),
        "no_restore_authorization_confirmed":
            bool(
                no_restore_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "restore_authorization":
            "NONE",
        "issues":
            " | ".join(
                validation.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash_payload(
        _lock_payload(
            row
        )
    )

    return row


def recovery_point_lock_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status":
                "MISSING",
            "calculated_hash":
                "",
        }

    calculated = _hash_payload(
        _lock_payload(
            record
        )
    )

    return {
        "status":
            (
                "OK"
                if stored
                == calculated
                else "MISMATCH"
            ),
        "calculated_hash":
            calculated,
    }


def latest_matching_recovery_point(
    locks: pd.DataFrame | None,
    manifest_sha256: str,
) -> dict:
    if (
        locks is None
        or locks.empty
        or "manifest_sha256"
        not in locks.columns
    ):
        return {}

    hit = locks.loc[
        locks[
            "manifest_sha256"
        ]
        .fillna("")
        .astype(str)
        .str.lower()
        .eq(
            _text(
                manifest_sha256
            ).lower()
        )
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit[
            "_ts"
        ] = pd.to_datetime(
            hit[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        hit = hit.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        hit.iloc[
            0
        ]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def build_manifest_recovery_queue(
    discovery: dict | None,
    verification: dict | None,
    dry_run: dict | None,
    locks: pd.DataFrame | None,
) -> pd.DataFrame:
    disc = discovery or {}
    ver = verification or {}
    dry = dry_run or {}
    rows = []

    if _text(
        disc.get(
            "status"
        )
    ).upper() != "FOUND":
        rows.append(
            {
                "priority":
                    "RI0",
                "status":
                    "BLOCKED",
                "issue":
                    "BACKUP_MANIFEST_NOT_DISCOVERED",
                "next_action":
                    "Save Center에서 최신 전체 백업이 존재하는지 확인",
                "go_to":
                    "Save Center",
            }
        )
    elif _text(
        ver.get(
            "manifest_status"
        )
    ).upper() != "PASS":
        rows.append(
            {
                "priority":
                    "RI0",
                "status":
                    "BLOCKED",
                "issue":
                    "BACKUP_MANIFEST_VERIFICATION_FAILED",
                "next_action":
                    "Manifest missing/hash mismatch를 확인하고 새 전체 백업 생성",
                "go_to":
                    "Save Center",
            }
        )
    elif _text(
        dry.get(
            "dryrun_status"
        )
    ).upper() != "PASS":
        rows.append(
            {
                "priority":
                    "RI1",
                "status":
                    "BLOCKED",
                "issue":
                    "RESTORE_DRYRUN_FAILED",
                "next_action":
                    "Dry-run parse 실패 파일을 확인하고 백업을 재생성",
                "go_to":
                    "Save Center",
            }
        )
    else:
        latest_lock = latest_matching_recovery_point(
            locks,
            _text(
                ver.get(
                    "manifest_sha256"
                )
            ),
        )

        if not latest_lock:
            rows.append(
                {
                    "priority":
                        "RI2",
                    "status":
                        "REVIEW",
                    "issue":
                        "VERIFIED_BACKUP_NOT_LOCKED",
                    "next_action":
                        "Manifest/Dry-run 확인 후 Recovery Point Lock을 Human Review",
                    "go_to":
                        "Save Center",
                }
            )
        else:
            integrity = recovery_point_lock_integrity(
                latest_lock
            )

            if integrity[
                "status"
            ] != "OK":
                rows.append(
                    {
                        "priority":
                            "RI0",
                        "status":
                            "BLOCKED",
                        "issue":
                            "RECOVERY_POINT_LOCK_HASH_MISMATCH",
                        "next_action":
                            "Recovery Point Lock Hash 무결성 확인",
                        "go_to":
                            "Save Center",
                    }
                )

    if not rows:
        return pd.DataFrame(
            columns=
            MANIFEST_QUEUE_COLS
        )

    order = {
        "RI0": 0,
        "RI1": 1,
        "RI2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            MANIFEST_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )
