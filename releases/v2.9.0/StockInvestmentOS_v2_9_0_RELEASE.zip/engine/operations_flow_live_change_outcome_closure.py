from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_live_change_outcome import (
    live_change_outcome_snapshot_integrity,
    latest_live_change_outcome_snapshot,
)


FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS = [
    "live_change_outcome_closure_id",
    "created_at",
    "closure_state",
    "closure_guard",
    "source_live_change_outcome_id",
    "source_live_change_outcome_hash",
    "source_live_change_outcome_created_at",
    "source_live_change_outcome_integrity",
    "source_runtime_event_id",
    "source_runtime_event_hash",
    "source_live_change_apply_id",
    "source_live_change_apply_hash",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "outcome_state",
    "outcome_guard",
    "proposal_scope",
    "target_metric",
    "change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "eligible_post_change_outcomes",
    "required_post_change_outcomes",
    "relative_error_improvement_pct",
    "rollback_required",
    "kill_switch_trigger",
    "decision",
    "decision_detail",
    "rollback_detail",
    "outcome_source_reviewed",
    "post_change_evidence_reviewed",
    "permanence_risk_reviewed",
    "permanent_design_review_only_confirmed",
    "rollback_completed_confirmed",
    "prior_baseline_restored_confirmed",
    "rollback_integrity_verified",
    "postmortem_reviewed",
    "no_permanent_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "permanent_change_design_permission",
    "live_change_closure_authorization",
    "permanent_change_review_authorization",
    "permanent_change_authorization",
    "live_change_outcome_authorization",
    "live_change_runtime_authorization",
    "live_change_apply_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


LIVE_CHANGE_OUTCOME_CLOSURE_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


LIVE_CHANGE_OUTCOME_CLOSURE_STATES = {
    "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT",
    "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
    "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED",
    "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
    "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED",
    "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED",
    "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
    "LIVE_CHANGE_CLOSURE_REJECTED",
    "LIVE_CHANGE_CLOSURE_DEFERRED",
    "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
}


LIVE_CHANGE_CLOSURE_GUARD_BY_STATE = {
    "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT": "HOLD_LIVE_CHANGE_OUTCOME",
    "LIVE_CHANGE_CLOSURE_NOT_REQUIRED": "NO_LIVE_CHANGE_CLOSURE",
    "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED": "HOLD_LIVE_CHANGE_OUTCOME_AUDIT",
    "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW": "HOLD_LIVE_CHANGE_CLOSURE_INTEGRITY",
    "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED": "HOLD_LIVE_CHANGE_CLOSURE_SOURCE",
    "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED": "HUMAN_PERMANENT_ADOPTION_REVIEW_REQUIRED",
    "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED": "LIVE_CHANGE_ROLLBACK_CLOSURE_REQUIRED",
    "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW":
        "PERMANENT_CHANGE_DESIGN_REVIEW_ONLY_NO_APPLY",
    "LIVE_CHANGE_CLOSURE_REJECTED": "LIVE_CHANGE_CLOSURE_REJECTED_NO_ADOPTION",
    "LIVE_CHANGE_CLOSURE_DEFERRED": "LIVE_CHANGE_CLOSURE_DEFERRED_NO_ADOPTION",
    "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED": "LIVE_CHANGE_ROLLBACK_CLOSED_NO_ADOPTION",
}


LIVE_CHANGE_OUTCOME_CLOSURE_DECISIONS = {
    "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
    "REJECT",
    "DEFER",
    "ROLLBACK_CLOSED",
}


ROLLBACK_OUTCOME_STATES = {
    "LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED",
}


TERMINAL_OUTCOME_STATES = {
    "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
    "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
    *ROLLBACK_OUTCOME_STATES,
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _closure_payload(row: dict) -> dict:
    int_fields = {
        "eligible_post_change_outcomes",
        "required_post_change_outcomes",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "relative_error_improvement_pct",
    }

    bool_fields = {
        "rollback_required",
        "outcome_source_reviewed",
        "post_change_evidence_reviewed",
        "permanence_risk_reviewed",
        "permanent_design_review_only_confirmed",
        "rollback_completed_confirmed",
        "prior_baseline_restored_confirmed",
        "rollback_integrity_verified",
        "postmortem_reviewed",
        "no_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS:
        if col in {
            "live_change_outcome_closure_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def live_change_outcome_closure_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _closure_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_live_change_outcome_closure_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _outcome_matches_live(
    audit: dict,
    live: dict,
) -> bool:
    if not audit or not live:
        return False

    if _text(
        live_change_outcome_snapshot_integrity(
            audit
        ).get("status")
    ).upper() != "OK":
        return False

    text_fields = [
        "outcome_state",
        "outcome_guard",
        "source_live_change_apply_id",
        "source_live_change_apply_hash",
        "source_runtime_event_id",
        "source_runtime_event_hash",
        "source_live_change_design_id",
        "source_live_change_design_hash",
        "source_proposal_id",
        "source_proposal_hash",
        "proposal_scope",
        "target_metric",
        "change_mode",
        "artifact_ref",
        "kill_switch_trigger",
        "evidence_outcome_ids_json",
        "evidence_outcome_hashes_json",
    ]

    for field in text_fields:
        if _text(
            audit.get(field)
        ) != _text(
            live.get(field)
        ):
            return False

    int_fields = [
        "eligible_post_change_outcomes",
        "required_post_change_outcomes",
    ]

    for field in int_fields:
        if _int(
            audit.get(field)
        ) != _int(
            live.get(field)
        ):
            return False

    float_fields = [
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "relative_error_improvement_pct",
    ]

    for field in float_fields:
        if abs(
            _float(
                audit.get(field)
            )
            - _float(
                live.get(field)
            )
        ) > 1e-8:
            return False

    if _bool(
        audit.get("rollback_required")
    ) != _bool(
        live.get("rollback_required")
    ):
        return False

    return True


def _closure_matches_outcome(
    closure: dict,
    outcome_audit: dict,
) -> bool:
    if not closure or not outcome_audit:
        return False

    if _text(
        live_change_outcome_closure_snapshot_integrity(
            closure
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            closure.get(
                "source_live_change_outcome_id"
            )
        )
        == _text(
            outcome_audit.get(
                "live_change_outcome_id"
            )
        )
        and _text(
            closure.get(
                "source_live_change_outcome_hash"
            )
        )
        == _text(
            outcome_audit.get(
                "snapshot_hash"
            )
        )
    )


def _state_from_decision(
    decision: str,
) -> str:
    value = _text(
        decision
    ).upper()

    return {
        "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW":
            "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
        "REJECT":
            "LIVE_CHANGE_CLOSURE_REJECTED",
        "DEFER":
            "LIVE_CHANGE_CLOSURE_DEFERRED",
        "ROLLBACK_CLOSED":
            "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
    }.get(
        value,
        "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
    )


def build_flow_live_change_outcome_closure(
    live_change_outcome: dict | None,
    live_change_outcome_snapshots: pd.DataFrame | None,
    closure_snapshots: pd.DataFrame | None,
) -> dict:
    live = live_change_outcome or {}
    live_state = _text(
        live.get("outcome_state")
    ).upper()

    base = {
        "source_live_change_outcome_id": "",
        "source_live_change_outcome_hash": "",
        "source_live_change_outcome_created_at": "",
        "source_live_change_outcome_integrity": "NONE",
        "source_runtime_event_id": _text(
            live.get("source_runtime_event_id")
        ),
        "source_runtime_event_hash": _text(
            live.get("source_runtime_event_hash")
        ),
        "source_live_change_apply_id": _text(
            live.get("source_live_change_apply_id")
        ),
        "source_live_change_apply_hash": _text(
            live.get("source_live_change_apply_hash")
        ),
        "source_live_change_design_id": _text(
            live.get("source_live_change_design_id")
        ),
        "source_live_change_design_hash": _text(
            live.get("source_live_change_design_hash")
        ),
        "source_proposal_id": _text(
            live.get("source_proposal_id")
        ),
        "source_proposal_hash": _text(
            live.get("source_proposal_hash")
        ),
        "outcome_state": live_state,
        "outcome_guard": _text(
            live.get("outcome_guard")
        ).upper(),
        "proposal_scope": _text(
            live.get("proposal_scope")
        ).upper(),
        "target_metric": _text(
            live.get("target_metric")
        ).upper(),
        "change_mode": _text(
            live.get("change_mode")
        ).upper(),
        "artifact_ref": _text(
            live.get("artifact_ref")
        ),
        "baseline_value": _float(
            live.get("baseline_value")
        ),
        "candidate_value": _float(
            live.get("candidate_value")
        ),
        "rollback_target_value": _float(
            live.get("rollback_target_value")
        ),
        "eligible_post_change_outcomes": _int(
            live.get("eligible_post_change_outcomes")
        ),
        "required_post_change_outcomes": _int(
            live.get("required_post_change_outcomes")
        ),
        "relative_error_improvement_pct": _float(
            live.get("relative_error_improvement_pct")
        ),
        "rollback_required": _bool(
            live.get("rollback_required")
        ),
        "kill_switch_trigger": _text(
            live.get("kill_switch_trigger")
        ).upper(),
        "decision": "",
        "decision_detail": "",
        "rollback_detail": "",
        "latest_closure": {},
        "permanent_change_design_permission": "NONE",
        "live_change_closure_authorization": "NONE",
        "permanent_change_review_authorization": "NONE",
        "permanent_change_authorization": "NONE",
        "live_change_outcome_authorization": "NONE",
        "live_change_runtime_authorization": "NONE",
        "live_change_apply_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if live_state == "LIVE_CHANGE_OUTCOME_NOT_REQUIRED":
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
            "closure_guard":
                "NO_LIVE_CHANGE_CLOSURE",
        }

    if live_state not in TERMINAL_OUTCOME_STATES:
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT",
            "closure_guard":
                "HOLD_LIVE_CHANGE_OUTCOME",
        }

    outcome_history = (
        pd.DataFrame()
        if live_change_outcome_snapshots is None
        else live_change_outcome_snapshots.copy()
    )

    latest_outcome = latest_live_change_outcome_snapshot(
        outcome_history
    )

    if not latest_outcome:
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED",
            "closure_guard":
                "HOLD_LIVE_CHANGE_OUTCOME_AUDIT",
        }

    outcome_integrity = _text(
        live_change_outcome_snapshot_integrity(
            latest_outcome
        ).get("status")
    ).upper()

    base.update(
        {
            "source_live_change_outcome_id":
                _text(
                    latest_outcome.get(
                        "live_change_outcome_id"
                    )
                ),
            "source_live_change_outcome_hash":
                _text(
                    latest_outcome.get(
                        "snapshot_hash"
                    )
                ),
            "source_live_change_outcome_created_at":
                _text(
                    latest_outcome.get(
                        "created_at"
                    )
                ),
            "source_live_change_outcome_integrity":
                outcome_integrity,
        }
    )

    if outcome_integrity != "OK":
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
            "closure_guard":
                "HOLD_LIVE_CHANGE_CLOSURE_INTEGRITY",
        }

    if not _outcome_matches_live(
        latest_outcome,
        live,
    ):
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED",
            "closure_guard":
                "HOLD_LIVE_CHANGE_CLOSURE_SOURCE",
        }

    closure_history = (
        pd.DataFrame()
        if closure_snapshots is None
        else closure_snapshots.copy()
    )

    latest_closure = latest_live_change_outcome_closure_snapshot(
        closure_history
    )

    if not latest_closure:
        if live_state in ROLLBACK_OUTCOME_STATES:
            return {
                **base,
                "closure_state":
                    "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED",
                "closure_guard":
                    "LIVE_CHANGE_ROLLBACK_CLOSURE_REQUIRED",
            }

        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED",
            "closure_guard":
                "HUMAN_PERMANENT_ADOPTION_REVIEW_REQUIRED",
        }

    base[
        "latest_closure"
    ] = latest_closure

    latest_integrity = _text(
        live_change_outcome_closure_snapshot_integrity(
            latest_closure
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
            "closure_guard":
                "HOLD_LIVE_CHANGE_CLOSURE_INTEGRITY",
        }

    if not _closure_matches_outcome(
        latest_closure,
        latest_outcome,
    ):
        return {
            **base,
            "closure_state":
                "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED",
            "closure_guard":
                "HOLD_LIVE_CHANGE_CLOSURE_SOURCE",
        }

    state = _state_from_decision(
        latest_closure.get("decision")
    )

    return {
        **base,
        "decision": _text(
            latest_closure.get("decision")
        ).upper(),
        "decision_detail": _text(
            latest_closure.get("decision_detail")
        ),
        "rollback_detail": _text(
            latest_closure.get("rollback_detail")
        ),
        "permanent_change_design_permission": _text(
            latest_closure.get(
                "permanent_change_design_permission"
            )
        ).upper() or "NONE",
        "closure_state": state,
        "closure_guard":
            LIVE_CHANGE_CLOSURE_GUARD_BY_STATE.get(
                state,
                "HOLD_LIVE_CHANGE_CLOSURE_INTEGRITY",
            ),
    }


def build_flow_live_change_outcome_closure_lock(
    closure: dict,
    *,
    decision: str,
    decision_detail: str,
    rollback_detail: str,
    outcome_source_reviewed: bool,
    post_change_evidence_reviewed: bool,
    permanence_risk_reviewed: bool,
    permanent_design_review_only_confirmed: bool,
    rollback_completed_confirmed: bool,
    prior_baseline_restored_confirmed: bool,
    rollback_integrity_verified: bool,
    postmortem_reviewed: bool,
    no_permanent_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = closure or {}

    state = _text(
        current.get("closure_state")
    ).upper()

    if state not in {
        "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED",
        "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED",
    }:
        raise ValueError(
            "Live Change Outcome Closure는 REVIEW_REQUIRED 또는 ROLLBACK_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_live_change_outcome_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Live Change Outcome integrity가 OK가 아닙니다."
        )

    decision_value = _text(
        decision
    ).upper()

    if decision_value not in LIVE_CHANGE_OUTCOME_CLOSURE_DECISIONS:
        raise ValueError(
            "Live Change Outcome Closure decision vocabulary가 유효하지 않습니다."
        )

    outcome_state = _text(
        current.get("outcome_state")
    ).upper()

    if state == "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED":
        if decision_value != "ROLLBACK_CLOSED":
            raise ValueError(
                "Rollback Required Live Change Outcome은 ROLLBACK_CLOSED 결정만 허용합니다."
            )

    elif outcome_state == "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION":
        if decision_value not in {
            "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
            "REJECT",
            "DEFER",
        }:
            raise ValueError(
                "PASS Live Change Outcome은 ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW / REJECT / DEFER만 허용합니다."
            )

    elif outcome_state == "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION":
        if decision_value not in {
            "REJECT",
            "DEFER",
        }:
            raise ValueError(
                "INCONCLUSIVE Live Change Outcome은 REJECT / DEFER만 허용합니다."
            )

    detail = _text(
        decision_detail
    )

    if len(detail) < 50:
        raise ValueError(
            "Permanent Adoption Review rationale을 50자 이상 기록하세요."
        )

    common_confirmations = {
        "outcome_source_reviewed":
            bool(
                outcome_source_reviewed
            ),
        "post_change_evidence_reviewed":
            bool(
                post_change_evidence_reviewed
            ),
        "permanence_risk_reviewed":
            bool(
                permanence_risk_reviewed
            ),
        "no_permanent_apply_confirmed":
            bool(
                no_permanent_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        common_confirmations.values()
    ):
        raise ValueError(
            "Permanent Adoption Human Review 공통 확인사항을 모두 검토해야 합니다."
        )

    if (
        decision_value
        == "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
        and not bool(
            permanent_design_review_only_confirmed
        )
    ):
        raise ValueError(
            "ACCEPT 결정은 permanent-change-design-review-only 확인이 필요합니다."
        )

    rollback_text = _text(
        rollback_detail
    )

    if decision_value == "ROLLBACK_CLOSED":
        rollback_confirmations = [
            rollback_completed_confirmed,
            prior_baseline_restored_confirmed,
            rollback_integrity_verified,
            postmortem_reviewed,
        ]

        if not all(
            bool(x)
            for x in rollback_confirmations
        ):
            raise ValueError(
                "Live Change rollback closure 확인사항을 모두 검토해야 합니다."
            )

        if len(rollback_text) < 50:
            raise ValueError(
                "Live Change rollback closure detail을 50자 이상 기록하세요."
            )

    else:
        rollback_text = ""

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    source_created = pd.to_datetime(
        current.get(
            "source_live_change_outcome_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    closure_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_created)
        or pd.isna(closure_created)
        or closure_created <= source_created
    ):
        raise ValueError(
            "Permanent Adoption Review는 source Live Change Outcome audit 이후에 저장되어야 합니다."
        )

    closure_state = _state_from_decision(
        decision_value
    )

    permission = (
        "PERMANENT_DESIGN_REVIEW_ONLY"
        if decision_value
        == "ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW"
        else "NONE"
    )

    base = {
        "closure_state":
            closure_state,
        "closure_guard":
            LIVE_CHANGE_CLOSURE_GUARD_BY_STATE[
                closure_state
            ],
        "source_live_change_outcome_id":
            _text(
                current.get(
                    "source_live_change_outcome_id"
                )
            ),
        "source_live_change_outcome_hash":
            _text(
                current.get(
                    "source_live_change_outcome_hash"
                )
            ),
        "source_live_change_outcome_created_at":
            _text(
                current.get(
                    "source_live_change_outcome_created_at"
                )
            ),
        "source_live_change_outcome_integrity":
            "OK",
        "source_runtime_event_id":
            _text(
                current.get(
                    "source_runtime_event_id"
                )
            ),
        "source_runtime_event_hash":
            _text(
                current.get(
                    "source_runtime_event_hash"
                )
            ),
        "source_live_change_apply_id":
            _text(
                current.get(
                    "source_live_change_apply_id"
                )
            ),
        "source_live_change_apply_hash":
            _text(
                current.get(
                    "source_live_change_apply_hash"
                )
            ),
        "source_live_change_design_id":
            _text(
                current.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                current.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "outcome_state":
            _text(
                current.get(
                    "outcome_state"
                )
            ),
        "outcome_guard":
            _text(
                current.get(
                    "outcome_guard"
                )
            ),
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "change_mode":
            _text(
                current.get(
                    "change_mode"
                )
            ),
        "artifact_ref":
            _text(
                current.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            _float(
                current.get(
                    "baseline_value"
                )
            ),
        "candidate_value":
            _float(
                current.get(
                    "candidate_value"
                )
            ),
        "rollback_target_value":
            _float(
                current.get(
                    "rollback_target_value"
                )
            ),
        "eligible_post_change_outcomes":
            _int(
                current.get(
                    "eligible_post_change_outcomes"
                )
            ),
        "required_post_change_outcomes":
            _int(
                current.get(
                    "required_post_change_outcomes"
                )
            ),
        "relative_error_improvement_pct":
            _float(
                current.get(
                    "relative_error_improvement_pct"
                )
            ),
        "rollback_required":
            _bool(
                current.get(
                    "rollback_required"
                )
            ),
        "kill_switch_trigger":
            _text(
                current.get(
                    "kill_switch_trigger"
                )
            ),
        "decision":
            decision_value,
        "decision_detail":
            detail,
        "rollback_detail":
            rollback_text,
        **common_confirmations,
        "permanent_design_review_only_confirmed":
            bool(
                permanent_design_review_only_confirmed
            ),
        "rollback_completed_confirmed":
            bool(
                rollback_completed_confirmed
            ),
        "prior_baseline_restored_confirmed":
            bool(
                prior_baseline_restored_confirmed
            ),
        "rollback_integrity_verified":
            bool(
                rollback_integrity_verified
            ),
        "postmortem_reviewed":
            bool(
                postmortem_reviewed
            ),
        "permanent_change_design_permission":
            permission,
        "live_change_closure_authorization":
            "NONE",
        "permanent_change_review_authorization":
            "NONE",
        "permanent_change_authorization":
            "NONE",
        "live_change_outcome_authorization":
            "NONE",
        "live_change_runtime_authorization":
            "NONE",
        "live_change_apply_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _closure_payload(
            base
        )
    )

    return {
        "live_change_outcome_closure_id": (
            "LCC-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_live_change_outcome_closure_queue(
    closure: dict | None,
) -> pd.DataFrame:
    row = closure or {}

    state = _text(
        row.get("closure_state")
    ).upper()

    mapping = {
        "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT": (
            "PC2",
            "WAIT",
            "LIVE_CHANGE_CLOSURE_UPSTREAM_WAIT",
            "terminal Live Change Outcome이 아직 없음",
            "Runtime / post-change Outcome evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "LIVE_CHANGE_CLOSURE_NOT_REQUIRED": (
            "PC3",
            "MONITOR",
            "LIVE_CHANGE_CLOSURE_NOT_REQUIRED",
            "현재 Live Change Outcome source에서는 Closure Review가 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED": (
            "PC1",
            "REVIEW",
            "LIVE_CHANGE_CLOSURE_OUTCOME_AUDIT_REQUIRED",
            "terminal Live Change Outcome은 있으나 immutable Outcome audit이 없음",
            "Live Change Outcome Snapshot을 먼저 저장",
        ),
        "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW": (
            "PC0",
            "BLOCKED",
            "LIVE_CHANGE_CLOSURE_SOURCE_INTEGRITY_REVIEW",
            "Live Change Outcome 또는 Closure audit integrity mismatch",
            "immutable source/audit integrity를 먼저 복구",
        ),
        "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED": (
            "PC0",
            "REVIEW",
            "LIVE_CHANGE_CLOSURE_SOURCE_SUPERSEDED",
            "새 Live Change Outcome audit으로 기존 Closure decision이 stale",
            "현재 Outcome audit 기준으로 Permanent Adoption Review 재수행",
        ),
        "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED": (
            "PC1",
            "REVIEW",
            "LIVE_CHANGE_CLOSURE_REVIEW_REQUIRED",
            (
                f"outcome {row.get('outcome_state','')} · "
                f"improvement {float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "PASS/INCONCLUSIVE evidence를 Human Review하고 ACCEPT/REJECT/DEFER 결정",
        ),
        "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED": (
            "PC0",
            "BLOCKED",
            "LIVE_CHANGE_CLOSURE_ROLLBACK_REQUIRED",
            (
                f"outcome {row.get('outcome_state','')} · "
                f"kill {row.get('kill_switch_trigger','') or 'NONE'}"
            ),
            "rollback 완료/기준선 복원/integrity/post-mortem 확인 후 ROLLBACK_CLOSED",
        ),
        "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW": (
            "PC3",
            "MONITOR",
            "LIVE_CHANGE_CLOSURE_ACCEPTED_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
            "Human decision = ACCEPT_FOR_PERMANENT_CHANGE_DESIGN_REVIEW",
            "permanent apply 금지; 별도 Permanent Change Design gate만 검토",
        ),
        "LIVE_CHANGE_CLOSURE_REJECTED": (
            "PC3",
            "MONITOR",
            "LIVE_CHANGE_CLOSURE_REJECTED",
            "Human decision = REJECT",
            "candidate permanent adoption 없음; 기존 baseline 유지",
        ),
        "LIVE_CHANGE_CLOSURE_DEFERRED": (
            "PC2",
            "MONITOR",
            "LIVE_CHANGE_CLOSURE_DEFERRED",
            "Human decision = DEFER",
            "새 post-change evidence 또는 새 canary cycle까지 대기",
        ),
        "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED": (
            "PC3",
            "MONITOR",
            "LIVE_CHANGE_CLOSURE_ROLLBACK_CLOSED",
            "Rollback closure verified",
            "baseline 복원 audit을 유지하고 새 permanent-change review는 별도 cycle에서 시작",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "PC0",
            "BLOCKED",
            "LIVE_CHANGE_CLOSURE_UNKNOWN_STATE",
            state or "MISSING",
            "Live Change Closure state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            LIVE_CHANGE_OUTCOME_CLOSURE_QUEUE_COLS,
    )
