from __future__ import annotations

from typing import Any
import pandas as pd


RELEASE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v123_release_readiness(
    *,
    stable_technical_gate: str,
    integration_consistency: str,
    csv_fail_count: int,
    learning_release_gate: str,
    forecast_release_gate: str,
    learning_operating_status: str = "",
    forecast_operating_status: str = "",
) -> dict:
    stable = _text(
        stable_technical_gate
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    learning = _text(
        learning_release_gate
    ).upper()
    forecast = _text(
        forecast_release_gate
    ).upper()
    csv_fail = int(
        csv_fail_count
        or 0
    )

    checks = [
        _row(
            "Stable Technical Gate",
            stable == "PASS",
            stable or "MISSING",
        ),
        _row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Learning Cycle Technical Release Gate",
            learning == "PASS",
            learning or "MISSING",
        ),
        _row(
            "Forecast Calibration Technical Release Gate",
            forecast == "PASS",
            forecast or "MISSING",
        ),
    ]

    blockers = [
        item[
            "check"
        ]
        for item in checks
        if item[
            "status"
        ] != "PASS"
    ]

    operating_reviews = []

    learning_operating = _text(
        learning_operating_status
    ).upper()
    forecast_operating = _text(
        forecast_operating_status
    ).upper()

    if (
        learning_operating
        and learning_operating
        != "PASS"
    ):
        operating_reviews.append(
            "LEARNING_OPERATING_REVIEW"
        )

    if (
        forecast_operating
        and forecast_operating
        != "PASS"
    ):
        operating_reviews.append(
            "FORECAST_OPERATING_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count":
            len(
                blockers
            ),
        "blockers":
            blockers,
        "operating_review_count":
            len(
                operating_reviews
            ),
        "operating_reviews":
            operating_reviews,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v123_integration_crosscheck(
    *,
    integration_consistency: str,
    learning_release_gate: str,
    forecast_release_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    learning = _text(
        learning_release_gate
    ).upper()
    forecast = _text(
        forecast_release_gate
    ).upper()

    checks = [
        _row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _row(
            "Learning Cycle Integration",
            learning == "PASS",
            learning or "MISSING",
        ),
        _row(
            "Forecast Calibration Integration",
            forecast == "PASS",
            forecast or "MISSING",
        ),
    ]

    blockers = [
        item[
            "check"
        ]
        for item in checks
        if item[
            "status"
        ] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v123_data_crosscheck(
    *,
    csv_fail_count: int,
    learning_release_gate: str,
    forecast_release_gate: str,
) -> dict:
    csv_fail = int(
        csv_fail_count
        or 0
    )
    learning = _text(
        learning_release_gate
    ).upper()
    forecast = _text(
        forecast_release_gate
    ).upper()

    checks = [
        _row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Learning Release Data Gate",
            learning == "PASS",
            learning or "MISSING",
        ),
        _row(
            "Forecast Calibration Release Data Gate",
            forecast == "PASS",
            forecast or "MISSING",
        ),
    ]

    blockers = [
        item[
            "check"
        ]
        for item in checks
        if item[
            "status"
        ] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }
