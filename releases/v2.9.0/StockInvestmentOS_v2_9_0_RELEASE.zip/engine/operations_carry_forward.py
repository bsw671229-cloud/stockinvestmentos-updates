from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd


CARRY_FORWARD_COLS = [
    "group_id",
    "priority",
    "category",
    "go_to",
    "status",
    "item_count",
    "subject_count",
    "first_seen_date",
    "last_seen_date",
    "age_days",
    "closed_sessions_seen",
    "aging_status",
    "sla_days",
    "sla_status",
    "sample_subjects",
    "sample_issues",
    "next_action",
]


CAPACITY_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "group_id",
    "category",
    "age_days",
    "closed_sessions_seen",
    "next_action",
    "go_to",
]


CARRY_FORWARD_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "action_groups",
    "attention_groups",
    "session_capacity",
    "overflow_groups",
    "aging_groups",
    "stale_groups",
    "sla_breaches",
    "oldest_age_days",
    "oldest_group_id",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _parse_date(value: Any):
    raw = _text(value)
    if not raw:
        return None

    ts = pd.to_datetime(
        raw,
        errors="coerce",
        utc=True,
    )

    if pd.isna(ts):
        return None

    return ts.date()


def _split_group_ids(value: Any) -> list[str]:
    raw = _text(value)
    if not raw:
        return []

    out = []
    for part in raw.split("|"):
        item = part.strip()
        if item and item not in out:
            out.append(item)

    return out


def _sla_days(priority: str) -> int:
    return {
        "RQ0": 0,
        "RQ1": 1,
        "RQ2": 7,
        "RQ3": 30,
        "RQ4": 60,
    }.get(
        _text(priority).upper(),
        30,
    )


def _aging_status(
    age_days: int,
    closed_sessions_seen: int,
) -> str:
    if age_days >= 14 or closed_sessions_seen >= 5:
        return "STALE"

    if age_days >= 7 or closed_sessions_seen >= 3:
        return "AGING"

    if closed_sessions_seen >= 1:
        return "CARRY_FORWARD"

    return "NEW"


def build_carry_forward_aging(
    current_groups: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    *,
    today: date | str | None = None,
) -> dict:
    groups = (
        pd.DataFrame()
        if current_groups is None
        else current_groups.copy()
    )
    session_df = (
        pd.DataFrame()
        if sessions is None
        else sessions.copy()
    )

    if today is None:
        today_date = date.today()
    elif isinstance(today, date):
        today_date = today
    else:
        parsed = pd.to_datetime(
            today,
            errors="coerce",
        )
        today_date = (
            parsed.date()
            if pd.notna(parsed)
            else date.today()
        )

    if groups.empty:
        return {
            "table":
                pd.DataFrame(
                    columns=
                    CARRY_FORWARD_COLS
                ),
            "action_groups":
                0,
            "aging_groups":
                0,
            "stale_groups":
                0,
            "sla_breaches":
                0,
            "oldest_age_days":
                0,
            "oldest_group_id":
                "",
            "execution_authorization":
                "NONE",
        }

    for col in [
        "group_id",
        "priority",
        "category",
        "go_to",
        "status",
        "item_count",
        "subject_count",
        "sample_subjects",
        "sample_issues",
        "sample_actions",
    ]:
        if col not in groups.columns:
            groups[col] = ""

    # Build session history for each compressed group from CLOSE events only.
    history = {}

    if (
        not session_df.empty
        and "event_type" in session_df.columns
        and "worklist_group_ids" in session_df.columns
    ):
        close_df = session_df.loc[
            session_df[
                "event_type"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq("CLOSE")
        ].copy()

        for _, row in close_df.iterrows():
            seen_date = _parse_date(
                row.get(
                    "created_at"
                )
            )

            if seen_date is None:
                continue

            for group_id in _split_group_ids(
                row.get(
                    "worklist_group_ids"
                )
            ):
                entry = history.setdefault(
                    group_id,
                    {
                        "dates": [],
                        "sessions": 0,
                    },
                )

                entry["dates"].append(
                    seen_date
                )
                entry["sessions"] += 1

    rows = []

    for _, row in groups.iterrows():
        group_id = _text(
            row.get(
                "group_id"
            )
        )
        hist = history.get(
            group_id,
            {
                "dates": [],
                "sessions": 0,
            },
        )

        dates = hist[
            "dates"
        ]

        if dates:
            first_seen = min(
                dates
            )
            last_seen = max(
                dates
            )
            age_days = max(
                0,
                (
                    today_date
                    - first_seen
                ).days,
            )
        else:
            first_seen = today_date
            last_seen = today_date
            age_days = 0

        sessions_seen = _int(
            hist.get(
                "sessions"
            )
        )
        priority = _text(
            row.get(
                "priority"
            )
        ).upper()
        sla_days = _sla_days(
            priority
        )

        # RQ0 is immediate; any carry-forward is an SLA breach.
        if priority == "RQ0":
            sla_status = (
                "BREACH"
                if sessions_seen > 0
                or age_days > 0
                else "DUE_NOW"
            )
        else:
            sla_status = (
                "BREACH"
                if age_days > sla_days
                else "WITHIN_SLA"
            )

        rows.append(
            {
                "group_id":
                    group_id,
                "priority":
                    priority,
                "category":
                    _text(
                        row.get(
                            "category"
                        )
                    ),
                "go_to":
                    _text(
                        row.get(
                            "go_to"
                        )
                    ),
                "status":
                    _text(
                        row.get(
                            "status"
                        )
                    ),
                "item_count":
                    _int(
                        row.get(
                            "item_count"
                        )
                    ),
                "subject_count":
                    _int(
                        row.get(
                            "subject_count"
                        )
                    ),
                "first_seen_date":
                    first_seen.isoformat(),
                "last_seen_date":
                    last_seen.isoformat(),
                "age_days":
                    age_days,
                "closed_sessions_seen":
                    sessions_seen,
                "aging_status":
                    _aging_status(
                        age_days,
                        sessions_seen,
                    ),
                "sla_days":
                    sla_days,
                "sla_status":
                    sla_status,
                "sample_subjects":
                    _text(
                        row.get(
                            "sample_subjects"
                        )
                    ),
                "sample_issues":
                    _text(
                        row.get(
                            "sample_issues"
                        )
                    ),
                "next_action":
                    _text(
                        row.get(
                            "sample_actions"
                        )
                    ),
            }
        )

    out = pd.DataFrame(
        rows,
        columns=
        CARRY_FORWARD_COLS,
    )

    status_order = {
        "STALE": 0,
        "AGING": 1,
        "CARRY_FORWARD": 2,
        "NEW": 3,
    }
    priority_order = {
        "RQ0": 0,
        "RQ1": 1,
        "RQ2": 2,
        "RQ3": 3,
        "RQ4": 4,
    }

    out["_age"] = out[
        "aging_status"
    ].map(
        status_order
    ).fillna(
        9
    )
    out["_priority"] = out[
        "priority"
    ].map(
        priority_order
    ).fillna(
        9
    )

    out = (
        out.sort_values(
            [
                "sla_status",
                "_age",
                "_priority",
                "age_days",
                "item_count",
            ],
            ascending=[
                True,
                True,
                True,
                False,
                False,
            ],
        )
        .drop(
            columns=[
                "_age",
                "_priority",
            ]
        )
        .reset_index(
            drop=True
        )
    )

    aging_groups = int(
        out[
            "aging_status"
        ]
        .isin(
            [
                "AGING",
                "STALE",
            ]
        )
        .sum()
    )
    stale_groups = int(
        out[
            "aging_status"
        ]
        .eq(
            "STALE"
        )
        .sum()
    )
    sla_breaches = int(
        out[
            "sla_status"
        ]
        .eq(
            "BREACH"
        )
        .sum()
    )

    if out.empty:
        oldest_age = 0
        oldest_group = ""
    else:
        idx = out[
            "age_days"
        ].astype(int).idxmax()
        oldest_age = int(
            out.loc[
                idx,
                "age_days",
            ]
        )
        oldest_group = _text(
            out.loc[
                idx,
                "group_id",
            ]
        )

    return {
        "table":
            out,
        "action_groups":
            int(
                len(
                    out
                )
            ),
        "aging_groups":
            aging_groups,
        "stale_groups":
            stale_groups,
        "sla_breaches":
            sla_breaches,
        "oldest_age_days":
            oldest_age,
        "oldest_group_id":
            oldest_group,
        "execution_authorization":
            "NONE",
    }


def build_review_capacity_plan(
    compression: dict | None,
    aging: dict | None,
    *,
    session_capacity: int = 5,
) -> dict:
    comp = compression or {}
    age = aging or {}

    action_groups = _int(
        comp.get(
            "action_groups"
        )
    )
    attention_groups = _int(
        comp.get(
            "attention_groups"
        )
    )
    capacity = max(
        1,
        _int(
            session_capacity
        ),
    )

    overflow_groups = max(
        0,
        action_groups - capacity,
    )
    attention_overflow = max(
        0,
        attention_groups - capacity,
    )

    if (
        _int(
            age.get(
                "sla_breaches"
            )
        )
        > 0
    ):
        capacity_status = "SLA_REVIEW"
    elif attention_overflow > 0:
        capacity_status = "OVER_CAPACITY"
    elif overflow_groups > 0:
        capacity_status = "ROUTINE_OVERFLOW"
    else:
        capacity_status = "WITHIN_CAPACITY"

    return {
        "capacity_status":
            capacity_status,
        "action_groups":
            action_groups,
        "attention_groups":
            attention_groups,
        "session_capacity":
            capacity,
        "overflow_groups":
            overflow_groups,
        "attention_overflow":
            attention_overflow,
        "aging_groups":
            _int(
                age.get(
                    "aging_groups"
                )
            ),
        "stale_groups":
            _int(
                age.get(
                    "stale_groups"
                )
            ),
        "sla_breaches":
            _int(
                age.get(
                    "sla_breaches"
                )
            ),
        "oldest_age_days":
            _int(
                age.get(
                    "oldest_age_days"
                )
            ),
        "execution_authorization":
            "NONE",
    }


def build_carry_forward_queue(
    aging: dict | None,
    capacity: dict | None,
) -> pd.DataFrame:
    age = aging or {}
    cap = capacity or {}
    table = age.get(
        "table"
    )

    rows = []

    if (
        isinstance(
            table,
            pd.DataFrame,
        )
        and not table.empty
    ):
        for _, row in table.iterrows():
            aging_status = _text(
                row.get(
                    "aging_status"
                )
            ).upper()
            sla_status = _text(
                row.get(
                    "sla_status"
                )
            ).upper()

            if sla_status == "BREACH":
                queue_priority = "CF0"
                queue_status = "REVIEW"
                issue = "OPERATING_SLA_BREACH"
            elif aging_status == "STALE":
                queue_priority = "CF1"
                queue_status = "REVIEW"
                issue = "CARRY_FORWARD_STALE"
            elif aging_status == "AGING":
                queue_priority = "CF2"
                queue_status = "REVIEW"
                issue = "CARRY_FORWARD_AGING"
            else:
                continue

            rows.append(
                {
                    "priority":
                        queue_priority,
                    "status":
                        queue_status,
                    "issue":
                        issue,
                    "group_id":
                        _text(
                            row.get(
                                "group_id"
                            )
                        ),
                    "category":
                        _text(
                            row.get(
                                "category"
                            )
                        ),
                    "age_days":
                        _int(
                            row.get(
                                "age_days"
                            )
                        ),
                    "closed_sessions_seen":
                        _int(
                            row.get(
                                "closed_sessions_seen"
                            )
                        ),
                    "next_action":
                        (
                            _text(
                                row.get(
                                    "next_action"
                                )
                            )
                            or "원본 Review Queue / 원본 화면에서 미해결 원인을 재검토"
                        ),
                    "go_to":
                        _text(
                            row.get(
                                "go_to"
                            )
                        )
                        or "Review Queue",
                }
            )

    if (
        _int(
            cap.get(
                "attention_overflow"
            )
        )
        > 0
    ):
        rows.append(
            {
                "priority":
                    "CF2",
                "status":
                    "REVIEW",
                "issue":
                    "ATTENTION_GROUP_CAPACITY_OVERFLOW",
                "group_id":
                    "",
                "category":
                    "Review Capacity",
                "age_days":
                    0,
                "closed_sessions_seen":
                    0,
                "next_action":
                    "이번 Session 상위 5개 처리 후 남은 Attention Group을 다음 Session으로 Carry-forward",
                "go_to":
                    "Operations Control Tower",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            CAPACITY_QUEUE_COLS
        )

    order = {
        "CF0": 0,
        "CF1": 1,
        "CF2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out["_p"] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "age_days",
                "category",
            ],
            ascending=[
                True,
                False,
                True,
            ],
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            CAPACITY_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )


def build_carry_forward_snapshot(
    aging: dict,
    capacity: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    payload = {
        "action_groups":
            _int(
                capacity.get(
                    "action_groups"
                )
            ),
        "attention_groups":
            _int(
                capacity.get(
                    "attention_groups"
                )
            ),
        "session_capacity":
            _int(
                capacity.get(
                    "session_capacity"
                )
            ),
        "overflow_groups":
            _int(
                capacity.get(
                    "overflow_groups"
                )
            ),
        "aging_groups":
            _int(
                aging.get(
                    "aging_groups"
                )
            ),
        "stale_groups":
            _int(
                aging.get(
                    "stale_groups"
                )
            ),
        "sla_breaches":
            _int(
                aging.get(
                    "sla_breaches"
                )
            ),
        "oldest_age_days":
            _int(
                aging.get(
                    "oldest_age_days"
                )
            ),
        "oldest_group_id":
            _text(
                aging.get(
                    "oldest_group_id"
                )
            ),
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        payload
    )

    snapshot_id = (
        "OCF-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot_hash[:8]
    )

    return {
        "snapshot_id":
            snapshot_id,
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
