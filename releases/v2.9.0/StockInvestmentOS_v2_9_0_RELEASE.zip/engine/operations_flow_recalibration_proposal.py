from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_recalibration_review import (
    recalibration_review_snapshot_integrity,
)
from engine.operations_flow_projection_scorecard import (
    flow_projection_scorecard_snapshot_integrity,
)


FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS = [
    "recalibration_proposal_id",
    "created_at",
    "proposal_state",
    "proposal_guard",
    "source_recalibration_review_id",
    "source_recalibration_review_hash",
    "source_recalibration_review_created_at",
    "source_recalibration_review_integrity",
    "source_scorecard_snapshot_id",
    "source_scorecard_hash",
    "source_scorecard_integrity",
    "primary_attribution",
    "secondary_attribution",
    "proposal_scope",
    "target_metric",
    "current_value",
    "proposed_value",
    "delta_abs",
    "delta_pct",
    "max_abs_delta_pct",
    "proposal_detail",
    "shadow_only_confirmed",
    "no_live_parameter_change_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "proposal_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


RECALIBRATION_PROPOSAL_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


RECALIBRATION_PROPOSAL_STATES = {
    "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
    "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
    "RECALIBRATION_PROPOSAL_REBASE_FIRST",
    "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED",
    "RECALIBRATION_PARAMETER_DELTA_REQUIRED",
    "RECALIBRATION_EXECUTION_REMEDIATION_ONLY",
    "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY",
    "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW",
    "RECALIBRATION_PROPOSAL_SUPERSEDED",
    "RECALIBRATION_PROPOSAL_LOCKED",
}


PROPOSAL_GUARD_BY_STATE = {
    "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT": "HOLD_RECALIBRATION_CONTRACT",
    "RECALIBRATION_PROPOSAL_NOT_REQUIRED": "NO_RECALIBRATION_PROPOSAL",
    "RECALIBRATION_PROPOSAL_REBASE_FIRST": "HOLD_ASSUMPTION_DRIFT",
    "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED": "HOLD_MODEL_PROPOSAL",
    "RECALIBRATION_PARAMETER_DELTA_REQUIRED": "HOLD_PARAMETER_PROPOSAL",
    "RECALIBRATION_EXECUTION_REMEDIATION_ONLY": "NO_MODEL_CHANGE",
    "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY": "NO_MODEL_CHANGE",
    "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW": "HOLD_PROPOSAL_INTEGRITY",
    "RECALIBRATION_PROPOSAL_SUPERSEDED": "HOLD_RECALIBRATION_CONTRACT",
    "RECALIBRATION_PROPOSAL_LOCKED": "PROPOSAL_LOCKED_SHADOW_ONLY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _proposal_payload(row: dict) -> dict:
    float_fields = {
        "current_value",
        "proposed_value",
        "delta_abs",
        "delta_pct",
        "max_abs_delta_pct",
    }
    bool_fields = {
        "shadow_only_confirmed",
        "no_live_parameter_change_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS:
        if col in {
            "recalibration_proposal_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in float_fields:
            payload[col] = round(
                _float(row.get(col)),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(row.get(col))
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def recalibration_proposal_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )
    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _proposal_payload(item)
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_recalibration_proposal_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _contract_source_valid(
    contract: dict | None,
    scorecard_snapshot: dict | None,
) -> bool:
    row = contract or {}
    sc = scorecard_snapshot or {}

    if not row or not sc:
        return False

    if (
        _text(
            recalibration_review_snapshot_integrity(
                row
            ).get("status")
        ).upper()
        != "OK"
    ):
        return False

    if (
        _text(
            flow_projection_scorecard_snapshot_integrity(
                sc
            ).get("status")
        ).upper()
        != "OK"
    ):
        return False

    return (
        _text(
            row.get(
                "source_scorecard_snapshot_id"
            )
        )
        == _text(
            sc.get(
                "scorecard_snapshot_id"
            )
        )
        and _text(
            row.get(
                "source_scorecard_hash"
            )
        )
        == _text(
            sc.get(
                "snapshot_hash"
            )
        )
    )


def _proposal_matches_contract(
    proposal: dict | None,
    contract: dict | None,
) -> bool:
    prop = proposal or {}
    con = contract or {}

    if not prop or not con:
        return False

    if (
        _text(
            recalibration_proposal_snapshot_integrity(
                prop
            ).get("status")
        ).upper()
        != "OK"
    ):
        return False

    return (
        _text(
            prop.get(
                "source_recalibration_review_id"
            )
        )
        == _text(
            con.get(
                "recalibration_review_id"
            )
        )
        and _text(
            prop.get(
                "source_recalibration_review_hash"
            )
        )
        == _text(
            con.get(
                "snapshot_hash"
            )
        )
    )


def build_flow_recalibration_proposal(
    recalibration_review: dict | None,
    source_scorecard_snapshot: dict | None,
    proposal_snapshots: pd.DataFrame | None,
    *,
    max_parameter_delta_pct: float = 0.50,
) -> dict:
    review = recalibration_review or {}
    scorecard = source_scorecard_snapshot or {}

    review_state = _text(
        review.get("review_state")
    ).upper()

    base = {
        "source_recalibration_review_id": "",
        "source_recalibration_review_hash": "",
        "source_recalibration_review_created_at": "",
        "source_recalibration_review_integrity": "NONE",
        "source_scorecard_snapshot_id": _text(
            scorecard.get(
                "scorecard_snapshot_id"
            )
        ),
        "source_scorecard_hash": _text(
            scorecard.get(
                "snapshot_hash"
            )
        ),
        "source_scorecard_integrity": (
            _text(
                flow_projection_scorecard_snapshot_integrity(
                    scorecard
                ).get("status")
            ).upper()
            if scorecard
            else "NONE"
        ),
        "primary_attribution": "",
        "secondary_attribution": "",
        "proposal_scope": "",
        "target_metric": "",
        "current_value": 0.0,
        "proposed_value": 0.0,
        "delta_abs": 0.0,
        "delta_pct": 0.0,
        "max_abs_delta_pct": float(
            max_parameter_delta_pct
        ),
        "proposal_detail": "",
        "latest_proposal": {},
        "proposal_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if review_state in {
        "",
        "RECALIBRATION_UPSTREAM_WAIT",
        "RECALIBRATION_PROOF_MATURING",
        "RECALIBRATION_SCORECARD_SOURCE_REQUIRED",
        "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW",
        "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW",
        "RECALIBRATION_ATTRIBUTION_REQUIRED",
    }:
        return {
            **base,
            "proposal_state": "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
            "proposal_guard": "HOLD_RECALIBRATION_CONTRACT",
        }

    if review_state == "RECALIBRATION_NOT_REQUIRED":
        return {
            **base,
            "proposal_state": "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
            "proposal_guard": "NO_RECALIBRATION_PROPOSAL",
        }

    if review_state == "RECALIBRATION_REBASE_FIRST":
        return {
            **base,
            "proposal_state": "RECALIBRATION_PROPOSAL_REBASE_FIRST",
            "proposal_guard": "HOLD_ASSUMPTION_DRIFT",
        }

    if review_state in {
        "RECALIBRATION_CONTRACT_SUPERSEDED",
        "RECALIBRATION_CONTRACT_INTEGRITY_REVIEW",
    }:
        return {
            **base,
            "proposal_state": "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
            "proposal_guard": "HOLD_RECALIBRATION_CONTRACT",
        }

    contract = (
        review.get(
            "latest_contract"
        )
        or {}
    )

    if (
        review_state
        != "RECALIBRATION_CONTRACT_LOCKED"
        or not contract
    ):
        return {
            **base,
            "proposal_state": "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
            "proposal_guard": "HOLD_RECALIBRATION_CONTRACT",
        }

    contract_integrity = _text(
        recalibration_review_snapshot_integrity(
            contract
        ).get("status")
    ).upper()

    base.update(
        {
            "source_recalibration_review_id":
                _text(
                    contract.get(
                        "recalibration_review_id"
                    )
                ),
            "source_recalibration_review_hash":
                _text(
                    contract.get(
                        "snapshot_hash"
                    )
                ),
            "source_recalibration_review_created_at":
                _text(
                    contract.get(
                        "created_at"
                    )
                ),
            "source_recalibration_review_integrity":
                contract_integrity,
            "primary_attribution":
                _text(
                    contract.get(
                        "primary_attribution"
                    )
                ).upper(),
            "secondary_attribution":
                _text(
                    contract.get(
                        "secondary_attribution"
                    )
                ).upper(),
        }
    )

    if (
        contract_integrity != "OK"
        or not _contract_source_valid(
            contract,
            scorecard,
        )
    ):
        return {
            **base,
            "proposal_state": "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW",
            "proposal_guard": "HOLD_PROPOSAL_INTEGRITY",
        }

    history = (
        pd.DataFrame()
        if proposal_snapshots is None
        else proposal_snapshots.copy()
    )
    latest = latest_recalibration_proposal_snapshot(
        history
    )

    if latest:
        integrity = recalibration_proposal_snapshot_integrity(
            latest
        )

        if _text(
            integrity.get("status")
        ).upper() != "OK":
            return {
                **base,
                "latest_proposal": latest,
                "proposal_state": "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW",
                "proposal_guard": "HOLD_PROPOSAL_INTEGRITY",
            }

        if _proposal_matches_contract(
            latest,
            contract,
        ):
            return {
                **base,
                "latest_proposal": latest,
                "proposal_scope": _text(
                    latest.get(
                        "proposal_scope"
                    )
                ),
                "target_metric": _text(
                    latest.get(
                        "target_metric"
                    )
                ),
                "current_value": _float(
                    latest.get(
                        "current_value"
                    )
                ),
                "proposed_value": _float(
                    latest.get(
                        "proposed_value"
                    )
                ),
                "delta_abs": _float(
                    latest.get(
                        "delta_abs"
                    )
                ),
                "delta_pct": _float(
                    latest.get(
                        "delta_pct"
                    )
                ),
                "proposal_detail": _text(
                    latest.get(
                        "proposal_detail"
                    )
                ),
                "proposal_state": "RECALIBRATION_PROPOSAL_LOCKED",
                "proposal_guard": "PROPOSAL_LOCKED_SHADOW_ONLY",
            }

        return {
            **base,
            "latest_proposal": latest,
            "proposal_state": "RECALIBRATION_PROPOSAL_SUPERSEDED",
            "proposal_guard": "HOLD_RECALIBRATION_CONTRACT",
        }

    primary = _text(
        contract.get(
            "primary_attribution"
        )
    ).upper()

    if primary == "PARAMETER":
        return {
            **base,
            "proposal_scope": "PARAMETER_SHADOW",
            "target_metric": "BASE_BURN_RATE",
            "current_value": _float(
                scorecard.get(
                    "base_burn_rate"
                )
            ),
            "proposal_state": "RECALIBRATION_PARAMETER_DELTA_REQUIRED",
            "proposal_guard": "HOLD_PARAMETER_PROPOSAL",
        }

    if primary == "MODEL":
        return {
            **base,
            "proposal_scope": "MODEL_SHADOW",
            "target_metric": "MODEL_SPECIFICATION",
            "proposal_state": "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED",
            "proposal_guard": "HOLD_MODEL_PROPOSAL",
        }

    if primary == "EXECUTION":
        return {
            **base,
            "proposal_state": "RECALIBRATION_EXECUTION_REMEDIATION_ONLY",
            "proposal_guard": "NO_MODEL_CHANGE",
        }

    if primary == "EXOGENOUS":
        return {
            **base,
            "proposal_state": "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY",
            "proposal_guard": "NO_MODEL_CHANGE",
        }

    return {
        **base,
        "proposal_state": "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW",
        "proposal_guard": "HOLD_PROPOSAL_INTEGRITY",
    }


def build_flow_recalibration_proposal_lock(
    proposal: dict,
    *,
    proposed_value: float | None = None,
    proposal_detail: str,
    shadow_only_confirmed: bool,
    no_live_parameter_change_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    prop = proposal or {}

    state = _text(
        prop.get("proposal_state")
    ).upper()

    if state not in {
        "RECALIBRATION_PARAMETER_DELTA_REQUIRED",
        "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED",
    }:
        raise ValueError(
            "Recalibration Proposal은 PARAMETER_DELTA_REQUIRED 또는 "
            "MODEL_SHADOW_SPEC_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    detail = _text(
        proposal_detail
    )

    min_detail = (
        20
        if state == "RECALIBRATION_PARAMETER_DELTA_REQUIRED"
        else 30
    )

    if len(detail) < min_detail:
        raise ValueError(
            f"Proposal detail을 {min_detail}자 이상 기록하세요."
        )

    confirmations = {
        "shadow_only_confirmed": bool(
            shadow_only_confirmed
        ),
        "no_live_parameter_change_confirmed": bool(
            no_live_parameter_change_confirmed
        ),
        "no_auto_capacity_confirmed": bool(
            no_auto_capacity_confirmed
        ),
        "no_execution_authorization_confirmed": bool(
            no_execution_authorization_confirmed
        ),
        "human_review_confirmed": bool(
            human_review_confirmed
        ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Recalibration Proposal Human Review 확인사항을 모두 검토해야 합니다."
        )

    current_value = _float(
        prop.get(
            "current_value"
        )
    )

    if state == "RECALIBRATION_PARAMETER_DELTA_REQUIRED":
        if current_value <= 0:
            raise ValueError(
                "현재 BASE_BURN_RATE가 0 이하라 parameter delta proposal을 만들 수 없습니다."
            )

        if proposed_value is None:
            raise ValueError(
                "Proposed BASE_BURN_RATE 값을 입력하세요."
            )

        proposed = float(
            proposed_value
        )

        if proposed <= 0:
            raise ValueError(
                "Proposed BASE_BURN_RATE는 0보다 커야 합니다."
            )

        delta_abs = (
            proposed
            - current_value
        )
        delta_pct = (
            delta_abs
            / abs(
                current_value
            )
        )
        max_abs_delta_pct = abs(
            _float(
                prop.get(
                    "max_abs_delta_pct"
                )
            )
        )

        if abs(
            delta_pct
        ) > max_abs_delta_pct:
            raise ValueError(
                f"Parameter delta가 허용 review bound "
                f"{max_abs_delta_pct:.0%}를 초과합니다."
            )

        scope = "PARAMETER_SHADOW"
        target_metric = "BASE_BURN_RATE"
        proposed_value_out = proposed

    else:
        scope = "MODEL_SHADOW"
        target_metric = "MODEL_SPECIFICATION"
        current_value = 0.0
        proposed_value_out = 0.0
        delta_abs = 0.0
        delta_pct = 0.0
        max_abs_delta_pct = 0.0

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        "proposal_state": "RECALIBRATION_PROPOSAL_LOCKED",
        "proposal_guard": "PROPOSAL_LOCKED_SHADOW_ONLY",
        "source_recalibration_review_id":
            _text(
                prop.get(
                    "source_recalibration_review_id"
                )
            ),
        "source_recalibration_review_hash":
            _text(
                prop.get(
                    "source_recalibration_review_hash"
                )
            ),
        "source_recalibration_review_created_at":
            _text(
                prop.get(
                    "source_recalibration_review_created_at"
                )
            ),
        "source_recalibration_review_integrity":
            _text(
                prop.get(
                    "source_recalibration_review_integrity"
                )
            ),
        "source_scorecard_snapshot_id":
            _text(
                prop.get(
                    "source_scorecard_snapshot_id"
                )
            ),
        "source_scorecard_hash":
            _text(
                prop.get(
                    "source_scorecard_hash"
                )
            ),
        "source_scorecard_integrity":
            _text(
                prop.get(
                    "source_scorecard_integrity"
                )
            ),
        "primary_attribution":
            _text(
                prop.get(
                    "primary_attribution"
                )
            ),
        "secondary_attribution":
            _text(
                prop.get(
                    "secondary_attribution"
                )
            ),
        "proposal_scope": scope,
        "target_metric": target_metric,
        "current_value": current_value,
        "proposed_value": proposed_value_out,
        "delta_abs": delta_abs,
        "delta_pct": delta_pct,
        "max_abs_delta_pct": max_abs_delta_pct,
        "proposal_detail": detail,
        **confirmations,
        "proposal_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(
        _proposal_payload(base)
    )

    return {
        "recalibration_proposal_id": (
            "ORP-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(
            note
        ),
        "snapshot_hash": snapshot_hash,
    }


def build_flow_recalibration_proposal_queue(
    proposal: dict | None,
) -> pd.DataFrame:
    prop = proposal or {}
    state = _text(
        prop.get(
            "proposal_state"
        )
    ).upper()

    mapping = {
        "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT": (
            "RP2",
            "WAIT",
            "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
            "Proof/Contract가 아직 proposal 단계에 도달하지 않음",
            "Qualified evidence와 Recalibration Contract가 자연스럽게 성숙할 때까지 대기",
        ),
        "RECALIBRATION_PROPOSAL_NOT_REQUIRED": (
            "RP3",
            "MONITOR",
            "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
            "현재 Scorecard/Contract는 recalibration proposal이 필요하지 않음",
            "추가 evidence 관찰",
        ),
        "RECALIBRATION_PROPOSAL_REBASE_FIRST": (
            "RP0",
            "REVIEW",
            "RECALIBRATION_PROPOSAL_REBASE_FIRST",
            "Capacity assumption drift가 model/parameter proposal보다 우선",
            "새 Calibration/Projection으로 rebase",
        ),
        "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED": (
            "RP1",
            "REVIEW",
            "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED",
            "MODEL attribution · live model change 없이 shadow spec proposal 필요",
            "Model shadow proposal detail과 Human confirmations 검토",
        ),
        "RECALIBRATION_PARAMETER_DELTA_REQUIRED": (
            "RP1",
            "REVIEW",
            "RECALIBRATION_PARAMETER_DELTA_REQUIRED",
            (
                f"PARAMETER attribution · current BASE_BURN_RATE "
                f"{_float(prop.get('current_value')):.4f}"
            ),
            "bounded shadow parameter proposal 검토",
        ),
        "RECALIBRATION_EXECUTION_REMEDIATION_ONLY": (
            "RP2",
            "REVIEW",
            "RECALIBRATION_EXECUTION_REMEDIATION_ONLY",
            "EXECUTION attribution · model/parameter change 금지",
            "Execution process remediation을 별도로 검토",
        ),
        "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY": (
            "RP2",
            "MONITOR",
            "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY",
            "EXOGENOUS attribution · model/parameter change 근거 부족",
            "새 evidence 관찰 / regime normalization 확인",
        ),
        "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW": (
            "RP0",
            "BLOCKED",
            "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW",
            "Contract / Scorecard / Proposal audit integrity mismatch",
            "source lineage와 immutable hash를 먼저 복구",
        ),
        "RECALIBRATION_PROPOSAL_SUPERSEDED": (
            "RP0",
            "REVIEW",
            "RECALIBRATION_PROPOSAL_SUPERSEDED",
            "새 Recalibration Contract가 생성되어 이전 Proposal이 stale",
            "현재 Contract 기준으로 Proposal을 다시 검토",
        ),
        "RECALIBRATION_PROPOSAL_LOCKED": (
            "RP3",
            "MONITOR",
            "RECALIBRATION_PROPOSAL_LOCKED",
            "shadow-only Recalibration Proposal이 잠김",
            "live model/parameter에는 적용하지 않고 shadow validation 단계 대기",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "RP0",
            "BLOCKED",
            "RECALIBRATION_PROPOSAL_UNKNOWN_STATE",
            state or "MISSING",
            "Proposal state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority": priority,
                "status": status,
                "issue": issue,
                "detail": detail,
                "next_action": next_action,
                "go_to": "Operations Control Tower",
            }
        ],
        columns=RECALIBRATION_PROPOSAL_QUEUE_COLS,
    )
