from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_recalibration_proposal import (
    recalibration_proposal_snapshot_integrity,
)


FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS = [
    "shadow_validation_plan_id",
    "created_at",
    "plan_state",
    "plan_guard",
    "source_proposal_id",
    "source_proposal_hash",
    "source_proposal_created_at",
    "source_proposal_integrity",
    "source_recalibration_review_id",
    "source_recalibration_review_hash",
    "source_scorecard_snapshot_id",
    "source_scorecard_hash",
    "primary_attribution",
    "proposal_scope",
    "target_metric",
    "evaluation_metric",
    "min_future_outcomes",
    "min_future_closed_intervals",
    "min_relative_error_improvement_pct",
    "max_relative_error_degradation_pct",
    "require_same_capacity",
    "require_no_assumption_drift",
    "plan_detail",
    "preregistration_confirmed",
    "shadow_only_confirmed",
    "no_live_apply_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "plan_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


SHADOW_VALIDATION_PLAN_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


SHADOW_VALIDATION_PLAN_STATES = {
    "SHADOW_VALIDATION_UPSTREAM_WAIT",
    "SHADOW_VALIDATION_NOT_REQUIRED",
    "SHADOW_VALIDATION_PROPOSAL_REQUIRED",
    "SHADOW_VALIDATION_PLAN_REQUIRED",
    "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW",
    "SHADOW_VALIDATION_PLAN_SUPERSEDED",
    "SHADOW_VALIDATION_PLAN_LOCKED",
}


PLAN_GUARD_BY_STATE = {
    "SHADOW_VALIDATION_UPSTREAM_WAIT": "HOLD_RECALIBRATION_PROPOSAL",
    "SHADOW_VALIDATION_NOT_REQUIRED": "NO_SHADOW_VALIDATION",
    "SHADOW_VALIDATION_PROPOSAL_REQUIRED": "HOLD_RECALIBRATION_PROPOSAL",
    "SHADOW_VALIDATION_PLAN_REQUIRED": "HOLD_VALIDATION_PLAN",
    "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW": "HOLD_VALIDATION_PLAN_INTEGRITY",
    "SHADOW_VALIDATION_PLAN_SUPERSEDED": "HOLD_VALIDATION_PLAN",
    "SHADOW_VALIDATION_PLAN_LOCKED": "PLAN_LOCKED_SHADOW_ONLY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _plan_payload(row: dict) -> dict:
    int_fields = {
        "min_future_outcomes",
        "min_future_closed_intervals",
    }
    float_fields = {
        "min_relative_error_improvement_pct",
        "max_relative_error_degradation_pct",
    }
    bool_fields = {
        "require_same_capacity",
        "require_no_assumption_drift",
        "preregistration_confirmed",
        "shadow_only_confirmed",
        "no_live_apply_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS:
        if col in {
            "shadow_validation_plan_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def shadow_validation_plan_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )
    stored = _text(
        item.get(
            "snapshot_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _plan_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_shadow_validation_plan_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _proposal_source(
    proposal: dict | None,
) -> dict:
    prop = proposal or {}

    latest = (
        prop.get(
            "latest_proposal"
        )
        or {}
    )

    if (
        _text(
            prop.get(
                "proposal_state"
            )
        ).upper()
        == "RECALIBRATION_PROPOSAL_LOCKED"
        and latest
    ):
        return latest

    return {}


def _plan_matches_proposal(
    plan: dict | None,
    proposal_source: dict | None,
) -> bool:
    row = plan or {}
    prop = proposal_source or {}

    if not row or not prop:
        return False

    if (
        _text(
            shadow_validation_plan_snapshot_integrity(
                row
            ).get(
                "status"
            )
        ).upper()
        != "OK"
    ):
        return False

    if (
        _text(
            recalibration_proposal_snapshot_integrity(
                prop
            ).get(
                "status"
            )
        ).upper()
        != "OK"
    ):
        return False

    return (
        _text(
            row.get(
                "source_proposal_id"
            )
        )
        == _text(
            prop.get(
                "recalibration_proposal_id"
            )
        )
        and _text(
            row.get(
                "source_proposal_hash"
            )
        )
        == _text(
            prop.get(
                "snapshot_hash"
            )
        )
    )


def build_flow_shadow_validation_plan(
    recalibration_proposal: dict | None,
    plan_snapshots: pd.DataFrame | None,
    *,
    default_min_future_outcomes: int = 3,
    default_min_future_closed_intervals: int = 2,
    default_min_relative_error_improvement_pct: float = 0.15,
    default_max_relative_error_degradation_pct: float = 0.10,
) -> dict:
    proposal = recalibration_proposal or {}
    state = _text(
        proposal.get(
            "proposal_state"
        )
    ).upper()

    base = {
        "source_proposal_id": "",
        "source_proposal_hash": "",
        "source_proposal_created_at": "",
        "source_proposal_integrity": "NONE",
        "source_recalibration_review_id": "",
        "source_recalibration_review_hash": "",
        "source_scorecard_snapshot_id": "",
        "source_scorecard_hash": "",
        "primary_attribution": _text(
            proposal.get(
                "primary_attribution"
            )
        ).upper(),
        "proposal_scope": _text(
            proposal.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            proposal.get(
                "target_metric"
            )
        ).upper(),
        "evaluation_metric": "BASE_ABS_ERROR_REDUCTION",
        "min_future_outcomes": max(
            3,
            _int(
                default_min_future_outcomes
            ),
        ),
        "min_future_closed_intervals": max(
            2,
            _int(
                default_min_future_closed_intervals
            ),
        ),
        "min_relative_error_improvement_pct": max(
            0.0,
            min(
                0.50,
                float(
                    default_min_relative_error_improvement_pct
                ),
            ),
        ),
        "max_relative_error_degradation_pct": max(
            0.0,
            min(
                0.25,
                float(
                    default_max_relative_error_degradation_pct
                ),
            ),
        ),
        "require_same_capacity": True,
        "require_no_assumption_drift": True,
        "plan_detail": "",
        "latest_plan": {},
        "plan_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if state in {
        "",
        "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
        "RECALIBRATION_PROPOSAL_REBASE_FIRST",
        "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW",
        "RECALIBRATION_PROPOSAL_SUPERSEDED",
    }:
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_UPSTREAM_WAIT",
            "plan_guard": "HOLD_RECALIBRATION_PROPOSAL",
        }

    if state in {
        "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
        "RECALIBRATION_EXECUTION_REMEDIATION_ONLY",
        "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY",
    }:
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_NOT_REQUIRED",
            "plan_guard": "NO_SHADOW_VALIDATION",
        }

    if state in {
        "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED",
        "RECALIBRATION_PARAMETER_DELTA_REQUIRED",
    }:
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_PROPOSAL_REQUIRED",
            "plan_guard": "HOLD_RECALIBRATION_PROPOSAL",
        }

    source = _proposal_source(
        proposal
    )

    if (
        state
        != "RECALIBRATION_PROPOSAL_LOCKED"
        or not source
    ):
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_UPSTREAM_WAIT",
            "plan_guard": "HOLD_RECALIBRATION_PROPOSAL",
        }

    proposal_integrity = _text(
        recalibration_proposal_snapshot_integrity(
            source
        ).get(
            "status"
        )
    ).upper()

    base.update(
        {
            "source_proposal_id":
                _text(
                    source.get(
                        "recalibration_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    source.get(
                        "snapshot_hash"
                    )
                ),
            "source_proposal_created_at":
                _text(
                    source.get(
                        "created_at"
                    )
                ),
            "source_proposal_integrity":
                proposal_integrity,
            "source_recalibration_review_id":
                _text(
                    source.get(
                        "source_recalibration_review_id"
                    )
                ),
            "source_recalibration_review_hash":
                _text(
                    source.get(
                        "source_recalibration_review_hash"
                    )
                ),
            "source_scorecard_snapshot_id":
                _text(
                    source.get(
                        "source_scorecard_snapshot_id"
                    )
                ),
            "source_scorecard_hash":
                _text(
                    source.get(
                        "source_scorecard_hash"
                    )
                ),
            "primary_attribution":
                _text(
                    source.get(
                        "primary_attribution"
                    )
                ).upper(),
            "proposal_scope":
                _text(
                    source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    source.get(
                        "target_metric"
                    )
                ).upper(),
        }
    )

    if proposal_integrity != "OK":
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW",
            "plan_guard": "HOLD_VALIDATION_PLAN_INTEGRITY",
        }

    history = (
        pd.DataFrame()
        if plan_snapshots is None
        else plan_snapshots.copy()
    )

    latest = latest_shadow_validation_plan_snapshot(
        history
    )

    if not latest:
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_PLAN_REQUIRED",
            "plan_guard": "HOLD_VALIDATION_PLAN",
        }

    base[
        "latest_plan"
    ] = latest

    latest_integrity = _text(
        shadow_validation_plan_snapshot_integrity(
            latest
        ).get(
            "status"
        )
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW",
            "plan_guard": "HOLD_VALIDATION_PLAN_INTEGRITY",
        }

    if not _plan_matches_proposal(
        latest,
        source,
    ):
        return {
            **base,
            "plan_state": "SHADOW_VALIDATION_PLAN_SUPERSEDED",
            "plan_guard": "HOLD_VALIDATION_PLAN",
        }

    return {
        **base,
        "plan_state": "SHADOW_VALIDATION_PLAN_LOCKED",
        "plan_guard": "PLAN_LOCKED_SHADOW_ONLY",
        "evaluation_metric": _text(
            latest.get(
                "evaluation_metric"
            )
        ),
        "min_future_outcomes": _int(
            latest.get(
                "min_future_outcomes"
            )
        ),
        "min_future_closed_intervals": _int(
            latest.get(
                "min_future_closed_intervals"
            )
        ),
        "min_relative_error_improvement_pct": _float(
            latest.get(
                "min_relative_error_improvement_pct"
            )
        ),
        "max_relative_error_degradation_pct": _float(
            latest.get(
                "max_relative_error_degradation_pct"
            )
        ),
        "require_same_capacity": _bool(
            latest.get(
                "require_same_capacity"
            )
        ),
        "require_no_assumption_drift": _bool(
            latest.get(
                "require_no_assumption_drift"
            )
        ),
        "plan_detail": _text(
            latest.get(
                "plan_detail"
            )
        ),
    }


def build_flow_shadow_validation_plan_lock(
    plan: dict,
    *,
    plan_detail: str,
    min_future_outcomes: int = 3,
    min_future_closed_intervals: int = 2,
    min_relative_error_improvement_pct: float = 0.15,
    max_relative_error_degradation_pct: float = 0.10,
    require_same_capacity: bool = True,
    require_no_assumption_drift: bool = True,
    preregistration_confirmed: bool,
    shadow_only_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = plan or {}

    if _text(
        current.get(
            "plan_state"
        )
    ).upper() != "SHADOW_VALIDATION_PLAN_REQUIRED":
        raise ValueError(
            "Shadow Validation Plan은 PLAN_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_proposal_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Recalibration Proposal integrity가 OK가 아닙니다."
        )

    detail = _text(
        plan_detail
    )
    if len(detail) < 30:
        raise ValueError(
            "Validation Plan detail을 30자 이상 기록하세요."
        )

    min_outcomes = int(
        min_future_outcomes
    )
    min_intervals = int(
        min_future_closed_intervals
    )
    improvement = float(
        min_relative_error_improvement_pct
    )
    degradation = float(
        max_relative_error_degradation_pct
    )

    if min_outcomes < 3:
        raise ValueError(
            "미래 qualified Outcome은 최소 3개가 필요합니다."
        )

    if min_intervals < 2:
        raise ValueError(
            "미래 closed-session interval은 최소 2개가 필요합니다."
        )

    if not (
        0.0
        <= improvement
        <= 0.50
    ):
        raise ValueError(
            "최소 상대 error 개선 기준은 0%~50% 범위여야 합니다."
        )

    if not (
        0.0
        <= degradation
        <= 0.25
    ):
        raise ValueError(
            "허용 상대 error 악화 기준은 0%~25% 범위여야 합니다."
        )

    confirmations = {
        "preregistration_confirmed":
            bool(
                preregistration_confirmed
            ),
        "shadow_only_confirmed":
            bool(
                shadow_only_confirmed
            ),
        "no_live_apply_confirmed":
            bool(
                no_live_apply_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Shadow Validation Plan Human Review 확인사항을 모두 검토해야 합니다."
        )

    if not (
        require_same_capacity
        and require_no_assumption_drift
    ):
        raise ValueError(
            "v1.38-dev1 Plan은 same-Capacity와 no-assumption-drift 조건을 모두 요구합니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        "plan_state": "SHADOW_VALIDATION_PLAN_LOCKED",
        "plan_guard": "PLAN_LOCKED_SHADOW_ONLY",
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "source_proposal_created_at":
            _text(
                current.get(
                    "source_proposal_created_at"
                )
            ),
        "source_proposal_integrity":
            "OK",
        "source_recalibration_review_id":
            _text(
                current.get(
                    "source_recalibration_review_id"
                )
            ),
        "source_recalibration_review_hash":
            _text(
                current.get(
                    "source_recalibration_review_hash"
                )
            ),
        "source_scorecard_snapshot_id":
            _text(
                current.get(
                    "source_scorecard_snapshot_id"
                )
            ),
        "source_scorecard_hash":
            _text(
                current.get(
                    "source_scorecard_hash"
                )
            ),
        "primary_attribution":
            _text(
                current.get(
                    "primary_attribution"
                )
            ),
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "evaluation_metric":
            "BASE_ABS_ERROR_REDUCTION",
        "min_future_outcomes":
            min_outcomes,
        "min_future_closed_intervals":
            min_intervals,
        "min_relative_error_improvement_pct":
            improvement,
        "max_relative_error_degradation_pct":
            degradation,
        "require_same_capacity":
            True,
        "require_no_assumption_drift":
            True,
        "plan_detail":
            detail,
        **confirmations,
        "plan_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _plan_payload(
            base
        )
    )

    return {
        "shadow_validation_plan_id": (
            "OSV-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_shadow_validation_plan_queue(
    plan: dict | None,
) -> pd.DataFrame:
    row = plan or {}
    state = _text(
        row.get(
            "plan_state"
        )
    ).upper()

    mapping = {
        "SHADOW_VALIDATION_UPSTREAM_WAIT": (
            "SV2",
            "WAIT",
            "SHADOW_VALIDATION_UPSTREAM_WAIT",
            "LOCKED Recalibration Proposal이 아직 없음",
            "Proof/Attribution/Proposal evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "SHADOW_VALIDATION_NOT_REQUIRED": (
            "SV3",
            "MONITOR",
            "SHADOW_VALIDATION_NOT_REQUIRED",
            "Execution/Exogenous 또는 no-proposal 상태로 shadow model validation이 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "SHADOW_VALIDATION_PROPOSAL_REQUIRED": (
            "SV2",
            "WAIT",
            "SHADOW_VALIDATION_PROPOSAL_REQUIRED",
            "MODEL/PARAMETER Proposal이 아직 LOCKED되지 않음",
            "shadow-only Recalibration Proposal Human Review 완료",
        ),
        "SHADOW_VALIDATION_PLAN_REQUIRED": (
            "SV1",
            "REVIEW",
            "SHADOW_VALIDATION_PLAN_REQUIRED",
            (
                f"scope {_text(row.get('proposal_scope')) or 'NONE'} · "
                f"future outcomes >= {_int(row.get('min_future_outcomes'))}"
            ),
            "미래 evidence가 생기기 전에 success/failure 기준을 사전등록",
        ),
        "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW": (
            "SV0",
            "BLOCKED",
            "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW",
            "Proposal 또는 Validation Plan immutable hash mismatch",
            "source Proposal / Plan audit integrity를 먼저 복구",
        ),
        "SHADOW_VALIDATION_PLAN_SUPERSEDED": (
            "SV0",
            "REVIEW",
            "SHADOW_VALIDATION_PLAN_SUPERSEDED",
            "새 LOCKED Proposal로 기존 Validation Plan이 stale",
            "현재 Proposal 기준으로 Validation Plan 재등록",
        ),
        "SHADOW_VALIDATION_PLAN_LOCKED": (
            "SV3",
            "MONITOR",
            "SHADOW_VALIDATION_PLAN_LOCKED",
            (
                f"metric {_text(row.get('evaluation_metric'))} · "
                f"future outcomes {_int(row.get('min_future_outcomes'))} · "
                f"min improvement {_float(row.get('min_relative_error_improvement_pct')):.0%}"
            ),
            "live apply 없이 미래 out-of-sample evidence 축적",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "SV0",
            "BLOCKED",
            "SHADOW_VALIDATION_UNKNOWN_STATE",
            state or "MISSING",
            "Shadow Validation state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            SHADOW_VALIDATION_PLAN_QUEUE_COLS,
    )
