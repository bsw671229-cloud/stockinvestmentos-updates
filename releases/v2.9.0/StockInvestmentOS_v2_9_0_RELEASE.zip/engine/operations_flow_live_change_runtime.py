from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_live_change_apply import (
    live_change_apply_snapshot_integrity,
)


FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS = [
    "live_change_runtime_event_id",
    "runtime_session_id",
    "created_at",
    "event_type",
    "runtime_state",
    "runtime_guard",
    "source_live_change_apply_id",
    "source_live_change_apply_hash",
    "source_live_change_apply_created_at",
    "source_live_change_apply_integrity",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "permit_scope_pct",
    "permit_session_budget",
    "permit_min_post_change_outcomes",
    "permit_max_relative_error_degradation_pct",
    "session_index",
    "sessions_used",
    "sessions_remaining",
    "activation_receipt_ref",
    "observed_pre_value",
    "observed_post_value",
    "kill_switch_trigger",
    "kill_switch_latched",
    "rollback_required",
    "baseline_restore_confirmed",
    "runtime_detail",
    "permit_source_reviewed",
    "baseline_freshness_confirmed",
    "candidate_artifact_verified",
    "canary_isolation_confirmed",
    "change_window_confirmed",
    "rollback_path_confirmed",
    "manual_external_activation_confirmed",
    "no_auto_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "live_change_runtime_permission",
    "live_change_runtime_authorization",
    "live_change_apply_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


LIVE_CHANGE_RUNTIME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


LIVE_CHANGE_RUNTIME_STATES = {
    "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT",
    "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
    "LIVE_CHANGE_RUNTIME_DEFERRED",
    "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
    "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
    "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
    "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY",
    "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
    "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
}


LIVE_CHANGE_RUNTIME_GUARD_BY_STATE = {
    "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT": "HOLD_MANUAL_CANARY_APPLY_PERMIT",
    "LIVE_CHANGE_RUNTIME_NOT_REQUIRED": "NO_LIVE_CHANGE_RUNTIME",
    "LIVE_CHANGE_RUNTIME_DEFERRED": "HOLD_LIVE_CHANGE_RUNTIME",
    "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED": "HOLD_LIVE_CHANGE_APPLY_SOURCE",
    "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW": "HOLD_LIVE_CHANGE_RUNTIME_INTEGRITY",
    "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION": "MANUAL_ACTIVATION_READY_NO_AUTO_APPLY",
    "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY": "MANUAL_CANARY_ACTIVE_ROLLBACK_ARMED",
    "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED": "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED": "LIVE_CHANGE_RUNTIME_BUDGET_EXHAUSTED",
    "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED": "HOLD_LIVE_CHANGE_RUNTIME_SOURCE",
}


LIVE_CHANGE_RUNTIME_EVENT_TYPES = {
    "ACTIVATE",
    "CLOSE",
    "KILL_SWITCH",
}


LIVE_CHANGE_RUNTIME_KILL_TRIGGERS = {
    "ERROR_DEGRADATION",
    "ASSUMPTION_DRIFT",
    "INTEGRITY_FAILURE",
    "BASELINE_DRIFT",
    "CANDIDATE_MISMATCH",
    "SOURCE_SUPERSESSION",
    "MANUAL_RISK_STOP",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _runtime_payload(row: dict) -> dict:
    int_fields = {
        "permit_session_budget",
        "permit_min_post_change_outcomes",
        "session_index",
        "sessions_used",
        "sessions_remaining",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "permit_scope_pct",
        "permit_max_relative_error_degradation_pct",
        "observed_pre_value",
        "observed_post_value",
    }

    bool_fields = {
        "kill_switch_latched",
        "rollback_required",
        "baseline_restore_confirmed",
        "permit_source_reviewed",
        "baseline_freshness_confirmed",
        "candidate_artifact_verified",
        "canary_isolation_confirmed",
        "change_window_confirmed",
        "rollback_path_confirmed",
        "manual_external_activation_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
        if col in {
            "live_change_runtime_event_id",
            "runtime_session_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def live_change_runtime_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _runtime_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_live_change_runtime_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _permit_source(
    apply: dict | None,
) -> dict:
    row = apply or {}

    if _text(
        row.get("apply_state")
    ).upper() != "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY":
        return {}

    if _text(
        row.get("live_change_apply_permission")
    ).upper() != "MANUAL_CANARY_APPLY_ONLY":
        return {}

    latest = row.get(
        "latest_apply"
    ) or {}

    if not latest:
        return {}

    if _text(
        live_change_apply_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get("live_change_apply_permission")
    ).upper() != "MANUAL_CANARY_APPLY_ONLY":
        return {}

    return latest


def _runtime_matches_permit(
    event: dict,
    permit: dict,
) -> bool:
    if not event or not permit:
        return False

    if _text(
        live_change_runtime_snapshot_integrity(
            event
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            event.get(
                "source_live_change_apply_id"
            )
        )
        == _text(
            permit.get(
                "live_change_apply_id"
            )
        )
        and _text(
            event.get(
                "source_live_change_apply_hash"
            )
        )
        == _text(
            permit.get(
                "snapshot_hash"
            )
        )
    )


def _normalized_history(
    snapshots: pd.DataFrame | None,
) -> pd.DataFrame:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    for col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return df[
            FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS
        ].copy()

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    return df.sort_values(
        "_ts"
    ).reset_index(
        drop=True
    )


def build_flow_live_change_runtime(
    live_change_apply: dict | None,
    runtime_snapshots: pd.DataFrame | None,
) -> dict:
    apply = live_change_apply or {}
    apply_state = _text(
        apply.get("apply_state")
    ).upper()

    base = {
        "source_live_change_apply_id": "",
        "source_live_change_apply_hash": "",
        "source_live_change_apply_created_at": "",
        "source_live_change_apply_integrity": "NONE",
        "source_live_change_design_id": _text(
            apply.get("source_live_change_design_id")
        ),
        "source_live_change_design_hash": _text(
            apply.get("source_live_change_design_hash")
        ),
        "source_proposal_id": _text(
            apply.get("source_proposal_id")
        ),
        "source_proposal_hash": _text(
            apply.get("source_proposal_hash")
        ),
        "proposal_scope": _text(
            apply.get("proposal_scope")
        ).upper(),
        "target_metric": _text(
            apply.get("target_metric")
        ).upper(),
        "change_mode": _text(
            apply.get("change_mode")
        ).upper(),
        "artifact_ref": _text(
            apply.get("artifact_ref")
        ),
        "baseline_value": _float(
            apply.get("baseline_value")
        ),
        "candidate_value": _float(
            apply.get("candidate_value")
        ),
        "rollback_target_value": _float(
            apply.get("rollback_target_value")
        ),
        "permit_scope_pct": _float(
            apply.get("permit_scope_pct")
        ),
        "permit_session_budget": _int(
            apply.get("permit_session_budget")
        ),
        "permit_min_post_change_outcomes": _int(
            apply.get("permit_min_post_change_outcomes")
        ),
        "permit_max_relative_error_degradation_pct": _float(
            apply.get(
                "permit_max_relative_error_degradation_pct"
            )
        ),
        "sessions_used": 0,
        "sessions_remaining": 0,
        "active_session_id": "",
        "session_index": 0,
        "activation_receipt_ref": "",
        "kill_switch_latched": False,
        "kill_switch_trigger": "",
        "rollback_required": False,
        "baseline_restore_confirmed": False,
        "latest_event": {},
        "live_change_runtime_permission": "NONE",
        "live_change_runtime_authorization": "NONE",
        "live_change_apply_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if apply_state in {
        "",
        "LIVE_CHANGE_APPLY_UPSTREAM_WAIT",
        "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
        "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
        "LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
        "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED",
    }:
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT",
            "runtime_guard": "HOLD_MANUAL_CANARY_APPLY_PERMIT",
        }

    if apply_state in {
        "LIVE_CHANGE_APPLY_NOT_REQUIRED",
        "LIVE_CHANGE_APPLY_REJECTED",
    }:
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
            "runtime_guard": "NO_LIVE_CHANGE_RUNTIME",
        }

    if apply_state == "LIVE_CHANGE_APPLY_DEFERRED":
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_DEFERRED",
            "runtime_guard": "HOLD_LIVE_CHANGE_RUNTIME",
        }

    permit = _permit_source(
        apply
    )

    if not permit:
        latest_apply = apply.get(
            "latest_apply"
        ) or {}

        if not latest_apply:
            return {
                **base,
                "runtime_state": "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
                "runtime_guard": "HOLD_LIVE_CHANGE_APPLY_SOURCE",
            }

        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard": "HOLD_LIVE_CHANGE_RUNTIME_INTEGRITY",
        }

    permit_integrity = _text(
        live_change_apply_snapshot_integrity(
            permit
        ).get("status")
    ).upper()

    budget = max(
        1,
        _int(
            permit.get(
                "permit_session_budget"
            )
        ),
    )

    base.update(
        {
            "source_live_change_apply_id":
                _text(
                    permit.get(
                        "live_change_apply_id"
                    )
                ),
            "source_live_change_apply_hash":
                _text(
                    permit.get(
                        "snapshot_hash"
                    )
                ),
            "source_live_change_apply_created_at":
                _text(
                    permit.get(
                        "created_at"
                    )
                ),
            "source_live_change_apply_integrity":
                permit_integrity,
            "source_live_change_design_id":
                _text(
                    permit.get(
                        "source_live_change_design_id"
                    )
                ),
            "source_live_change_design_hash":
                _text(
                    permit.get(
                        "source_live_change_design_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    permit.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    permit.get(
                        "source_proposal_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    permit.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    permit.get(
                        "target_metric"
                    )
                ).upper(),
            "change_mode":
                _text(
                    permit.get(
                        "change_mode"
                    )
                ).upper(),
            "artifact_ref":
                _text(
                    permit.get(
                        "artifact_ref"
                    )
                ),
            "baseline_value":
                _float(
                    permit.get(
                        "baseline_value"
                    )
                ),
            "candidate_value":
                _float(
                    permit.get(
                        "candidate_value"
                    )
                ),
            "rollback_target_value":
                _float(
                    permit.get(
                        "rollback_target_value"
                    )
                ),
            "permit_scope_pct":
                _float(
                    permit.get(
                        "permit_scope_pct"
                    )
                ),
            "permit_session_budget":
                budget,
            "permit_min_post_change_outcomes":
                _int(
                    permit.get(
                        "permit_min_post_change_outcomes"
                    )
                ),
            "permit_max_relative_error_degradation_pct":
                _float(
                    permit.get(
                        "permit_max_relative_error_degradation_pct"
                    )
                ),
            "sessions_remaining":
                budget,
            "live_change_runtime_permission":
                "MANUAL_CANARY_RUNTIME_ONLY",
        }
    )

    if permit_integrity != "OK":
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard": "HOLD_LIVE_CHANGE_RUNTIME_INTEGRITY",
        }

    history = _normalized_history(
        runtime_snapshots
    )

    if history.empty:
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
            "runtime_guard": "MANUAL_ACTIVATION_READY_NO_AUTO_APPLY",
        }

    mismatch_count = 0
    source_rows = []

    for _, row in history.iterrows():
        item = row.to_dict()

        if _text(
            live_change_runtime_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            mismatch_count += 1
            continue

        if _runtime_matches_permit(
            item,
            permit,
        ):
            source_rows.append(
                item
            )

    if mismatch_count > 0:
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard": "HOLD_LIVE_CHANGE_RUNTIME_INTEGRITY",
        }

    latest_global = latest_live_change_runtime_snapshot(
        history
    )

    if (
        latest_global
        and not _runtime_matches_permit(
            latest_global,
            permit,
        )
    ):
        return {
            **base,
            "latest_event":
                latest_global,
            "runtime_state": "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
            "runtime_guard": "HOLD_LIVE_CHANGE_RUNTIME_SOURCE",
        }

    if not source_rows:
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
            "runtime_guard": "MANUAL_ACTIVATION_READY_NO_AUTO_APPLY",
        }

    source_rows = sorted(
        source_rows,
        key=lambda item: pd.to_datetime(
            item.get("created_at"),
            errors="coerce",
            utc=True,
        ),
    )

    latest = source_rows[-1]

    opened_sessions = []
    for item in source_rows:
        session_id = _text(
            item.get("runtime_session_id")
        )
        event_type = _text(
            item.get("event_type")
        ).upper()

        if (
            event_type == "ACTIVATE"
            and session_id
            and session_id not in opened_sessions
        ):
            opened_sessions.append(
                session_id
            )

    used = len(
        opened_sessions
    )
    remaining = max(
        0,
        budget - used,
    )

    base.update(
        {
            "sessions_used":
                used,
            "sessions_remaining":
                remaining,
            "session_index":
                _int(
                    latest.get(
                        "session_index"
                    )
                ),
            "latest_event":
                latest,
            "activation_receipt_ref":
                _text(
                    latest.get(
                        "activation_receipt_ref"
                    )
                ),
            "kill_switch_latched":
                _bool(
                    latest.get(
                        "kill_switch_latched"
                    )
                ),
            "kill_switch_trigger":
                _text(
                    latest.get(
                        "kill_switch_trigger"
                    )
                ).upper(),
            "rollback_required":
                _bool(
                    latest.get(
                        "rollback_required"
                    )
                ),
            "baseline_restore_confirmed":
                _bool(
                    latest.get(
                        "baseline_restore_confirmed"
                    )
                ),
        }
    )

    event_type = _text(
        latest.get("event_type")
    ).upper()

    if event_type == "KILL_SWITCH":
        return {
            **base,
            "active_session_id":
                _text(
                    latest.get(
                        "runtime_session_id"
                    )
                ),
            "runtime_state": "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
            "runtime_guard": "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
        }

    if event_type == "ACTIVATE":
        return {
            **base,
            "active_session_id":
                _text(
                    latest.get(
                        "runtime_session_id"
                    )
                ),
            "runtime_state": "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY",
            "runtime_guard": "MANUAL_CANARY_ACTIVE_ROLLBACK_ARMED",
        }

    if used >= budget:
        return {
            **base,
            "runtime_state": "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            "runtime_guard": "LIVE_CHANGE_RUNTIME_BUDGET_EXHAUSTED",
        }

    return {
        **base,
        "runtime_state": "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
        "runtime_guard": "MANUAL_ACTIVATION_READY_NO_AUTO_APPLY",
    }


def _common_confirmations_ok(
    values: list[bool],
) -> None:
    if not all(
        bool(v)
        for v in values
    ):
        raise ValueError(
            "Live Change Runtime Human Review 확인사항을 모두 검토해야 합니다."
        )


def _build_event(
    runtime: dict,
    *,
    runtime_session_id: str,
    event_type: str,
    runtime_state: str,
    runtime_guard: str,
    session_index: int,
    sessions_used: int,
    sessions_remaining: int,
    activation_receipt_ref: str,
    observed_pre_value: float,
    observed_post_value: float,
    kill_switch_trigger: str,
    kill_switch_latched: bool,
    rollback_required: bool,
    baseline_restore_confirmed: bool,
    runtime_detail: str,
    permit_source_reviewed: bool,
    baseline_freshness_confirmed: bool,
    candidate_artifact_verified: bool,
    canary_isolation_confirmed: bool,
    change_window_confirmed: bool,
    rollback_path_confirmed: bool,
    manual_external_activation_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str,
    created_at: str,
) -> dict:
    base = {
        "event_type":
            event_type,
        "runtime_state":
            runtime_state,
        "runtime_guard":
            runtime_guard,
        "source_live_change_apply_id":
            _text(
                runtime.get(
                    "source_live_change_apply_id"
                )
            ),
        "source_live_change_apply_hash":
            _text(
                runtime.get(
                    "source_live_change_apply_hash"
                )
            ),
        "source_live_change_apply_created_at":
            _text(
                runtime.get(
                    "source_live_change_apply_created_at"
                )
            ),
        "source_live_change_apply_integrity":
            "OK",
        "source_live_change_design_id":
            _text(
                runtime.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                runtime.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                runtime.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                runtime.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            _text(
                runtime.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                runtime.get(
                    "target_metric"
                )
            ),
        "change_mode":
            _text(
                runtime.get(
                    "change_mode"
                )
            ),
        "artifact_ref":
            _text(
                runtime.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            _float(
                runtime.get(
                    "baseline_value"
                )
            ),
        "candidate_value":
            _float(
                runtime.get(
                    "candidate_value"
                )
            ),
        "rollback_target_value":
            _float(
                runtime.get(
                    "rollback_target_value"
                )
            ),
        "permit_scope_pct":
            _float(
                runtime.get(
                    "permit_scope_pct"
                )
            ),
        "permit_session_budget":
            _int(
                runtime.get(
                    "permit_session_budget"
                )
            ),
        "permit_min_post_change_outcomes":
            _int(
                runtime.get(
                    "permit_min_post_change_outcomes"
                )
            ),
        "permit_max_relative_error_degradation_pct":
            _float(
                runtime.get(
                    "permit_max_relative_error_degradation_pct"
                )
            ),
        "session_index":
            session_index,
        "sessions_used":
            sessions_used,
        "sessions_remaining":
            sessions_remaining,
        "activation_receipt_ref":
            _text(
                activation_receipt_ref
            ),
        "observed_pre_value":
            float(
                observed_pre_value
            ),
        "observed_post_value":
            float(
                observed_post_value
            ),
        "kill_switch_trigger":
            _text(
                kill_switch_trigger
            ).upper(),
        "kill_switch_latched":
            bool(
                kill_switch_latched
            ),
        "rollback_required":
            bool(
                rollback_required
            ),
        "baseline_restore_confirmed":
            bool(
                baseline_restore_confirmed
            ),
        "runtime_detail":
            _text(
                runtime_detail
            ),
        "permit_source_reviewed":
            bool(
                permit_source_reviewed
            ),
        "baseline_freshness_confirmed":
            bool(
                baseline_freshness_confirmed
            ),
        "candidate_artifact_verified":
            bool(
                candidate_artifact_verified
            ),
        "canary_isolation_confirmed":
            bool(
                canary_isolation_confirmed
            ),
        "change_window_confirmed":
            bool(
                change_window_confirmed
            ),
        "rollback_path_confirmed":
            bool(
                rollback_path_confirmed
            ),
        "manual_external_activation_confirmed":
            bool(
                manual_external_activation_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "live_change_runtime_permission":
            "MANUAL_CANARY_RUNTIME_ONLY",
        "live_change_runtime_authorization":
            "NONE",
        "live_change_apply_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _runtime_payload(
            base
        )
    )

    return {
        "live_change_runtime_event_id": (
            "LCR-"
            + pd.Timestamp(
                created_at
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "runtime_session_id":
            runtime_session_id,
        "created_at":
            created_at,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_live_change_runtime_activate(
    runtime: dict,
    *,
    activation_receipt_ref: str,
    observed_pre_value: float,
    observed_post_value: float,
    runtime_detail: str,
    permit_source_reviewed: bool,
    baseline_freshness_confirmed: bool,
    candidate_artifact_verified: bool,
    canary_isolation_confirmed: bool,
    change_window_confirmed: bool,
    rollback_path_confirmed: bool,
    manual_external_activation_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    if _text(
        current.get("runtime_state")
    ).upper() != "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION":
        raise ValueError(
            "Manual canary activation은 READY_FOR_MANUAL_ACTIVATION 상태에서만 기록할 수 있습니다."
        )

    if _text(
        current.get(
            "source_live_change_apply_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Manual Canary Apply Permit integrity가 OK가 아닙니다."
        )

    if _text(
        current.get(
            "live_change_runtime_permission"
        )
    ).upper() != "MANUAL_CANARY_RUNTIME_ONLY":
        raise ValueError(
            "MANUAL_CANARY_RUNTIME_ONLY permission이 없습니다."
        )

    if _int(
        current.get("sessions_remaining")
    ) <= 0:
        raise ValueError(
            "Live Change Runtime session budget이 남아 있지 않습니다."
        )

    receipt = _text(
        activation_receipt_ref
    )
    if len(receipt) < 8:
        raise ValueError(
            "외부 수동 activation receipt/reference를 8자 이상 기록하세요."
        )

    detail = _text(
        runtime_detail
    )
    if len(detail) < 50:
        raise ValueError(
            "Manual activation rationale을 50자 이상 기록하세요."
        )

    _common_confirmations_ok(
        [
            permit_source_reviewed,
            baseline_freshness_confirmed,
            candidate_artifact_verified,
            canary_isolation_confirmed,
            change_window_confirmed,
            rollback_path_confirmed,
            manual_external_activation_confirmed,
            no_auto_apply_confirmed,
            no_auto_recalibration_confirmed,
            no_auto_capacity_confirmed,
            no_execution_authorization_confirmed,
            human_review_confirmed,
        ]
    )

    baseline = _float(
        current.get("baseline_value")
    )
    candidate = _float(
        current.get("candidate_value")
    )
    rollback = _float(
        current.get("rollback_target_value")
    )
    pre = float(
        observed_pre_value
    )
    post = float(
        observed_post_value
    )

    if abs(
        rollback - baseline
    ) > 1e-12:
        raise ValueError(
            "Rollback target이 locked baseline과 일치하지 않습니다."
        )

    if _text(
        current.get("proposal_scope")
    ).upper() == "PARAMETER_SHADOW":
        if abs(
            pre - baseline
        ) > 1e-9:
            raise ValueError(
                "Activation 직전 observed value가 locked baseline과 일치하지 않습니다."
            )
        if abs(
            post - candidate
        ) > 1e-9:
            raise ValueError(
                "Activation 직후 observed value가 locked candidate와 일치하지 않습니다."
            )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    source_created = pd.to_datetime(
        current.get(
            "source_live_change_apply_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    activation_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_created)
        or pd.isna(activation_created)
        or activation_created <= source_created
    ):
        raise ValueError(
            "Manual activation event는 source Apply Permit 이후에 저장되어야 합니다."
        )

    session_index = _int(
        current.get("sessions_used")
    ) + 1
    budget = _int(
        current.get("permit_session_budget")
    )

    seed = (
        _text(
            current.get(
                "source_live_change_apply_id"
            )
        )
        + "|"
        + now
        + "|"
        + str(session_index)
    )

    session_id = (
        "LCS-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            seed.encode("utf-8")
        ).hexdigest()[:8]
    )

    return _build_event(
        current,
        runtime_session_id=session_id,
        event_type="ACTIVATE",
        runtime_state="LIVE_CHANGE_RUNTIME_ACTIVE_CANARY",
        runtime_guard="MANUAL_CANARY_ACTIVE_ROLLBACK_ARMED",
        session_index=session_index,
        sessions_used=session_index,
        sessions_remaining=max(
            0,
            budget - session_index,
        ),
        activation_receipt_ref=receipt,
        observed_pre_value=pre,
        observed_post_value=post,
        kill_switch_trigger="",
        kill_switch_latched=False,
        rollback_required=False,
        baseline_restore_confirmed=False,
        runtime_detail=detail,
        permit_source_reviewed=permit_source_reviewed,
        baseline_freshness_confirmed=baseline_freshness_confirmed,
        candidate_artifact_verified=candidate_artifact_verified,
        canary_isolation_confirmed=canary_isolation_confirmed,
        change_window_confirmed=change_window_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        manual_external_activation_confirmed=manual_external_activation_confirmed,
        no_auto_apply_confirmed=no_auto_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
        note=note,
        created_at=now,
    )


def build_flow_live_change_runtime_close(
    runtime: dict,
    *,
    observed_restored_value: float,
    runtime_detail: str,
    baseline_restore_confirmed: bool,
    permit_source_reviewed: bool,
    rollback_path_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    if _text(
        current.get("runtime_state")
    ).upper() != "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY":
        raise ValueError(
            "Live Change Runtime CLOSE는 ACTIVE_CANARY 상태에서만 가능합니다."
        )

    detail = _text(
        runtime_detail
    )
    if len(detail) < 40:
        raise ValueError(
            "Runtime CLOSE rationale을 40자 이상 기록하세요."
        )

    _common_confirmations_ok(
        [
            baseline_restore_confirmed,
            permit_source_reviewed,
            rollback_path_confirmed,
            no_auto_apply_confirmed,
            no_auto_recalibration_confirmed,
            no_auto_capacity_confirmed,
            no_execution_authorization_confirmed,
            human_review_confirmed,
        ]
    )

    baseline = _float(
        current.get("baseline_value")
    )
    restored = float(
        observed_restored_value
    )

    if abs(
        restored - baseline
    ) > 1e-9:
        raise ValueError(
            "Session CLOSE 시 observed restored value가 locked baseline과 일치하지 않습니다."
        )

    latest = current.get(
        "latest_event"
    ) or {}
    open_created = pd.to_datetime(
        latest.get("created_at"),
        errors="coerce",
        utc=True,
    )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    close_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(open_created)
        or pd.isna(close_created)
        or close_created <= open_created
    ):
        raise ValueError(
            "Runtime CLOSE는 ACTIVATE event 이후에 저장되어야 합니다."
        )

    used = _int(
        current.get("sessions_used")
    )
    remaining = _int(
        current.get("sessions_remaining")
    )

    next_state = (
        "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED"
        if remaining <= 0
        else "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION"
    )

    return _build_event(
        current,
        runtime_session_id=_text(
            current.get("active_session_id")
        ),
        event_type="CLOSE",
        runtime_state=next_state,
        runtime_guard=LIVE_CHANGE_RUNTIME_GUARD_BY_STATE[
            next_state
        ],
        session_index=_int(
            current.get("session_index")
        ),
        sessions_used=used,
        sessions_remaining=remaining,
        activation_receipt_ref=_text(
            current.get("activation_receipt_ref")
        ),
        observed_pre_value=_float(
            current.get("candidate_value")
        ),
        observed_post_value=restored,
        kill_switch_trigger="",
        kill_switch_latched=False,
        rollback_required=False,
        baseline_restore_confirmed=True,
        runtime_detail=detail,
        permit_source_reviewed=permit_source_reviewed,
        baseline_freshness_confirmed=True,
        candidate_artifact_verified=True,
        canary_isolation_confirmed=True,
        change_window_confirmed=True,
        rollback_path_confirmed=rollback_path_confirmed,
        manual_external_activation_confirmed=True,
        no_auto_apply_confirmed=no_auto_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
        note=note,
        created_at=now,
    )


def build_flow_live_change_runtime_kill_switch(
    runtime: dict,
    *,
    kill_switch_trigger: str,
    observed_restored_value: float,
    runtime_detail: str,
    rollback_initiated_confirmed: bool,
    permit_source_reviewed: bool,
    rollback_path_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    if _text(
        current.get("runtime_state")
    ).upper() != "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY":
        raise ValueError(
            "Kill Switch는 ACTIVE_CANARY 상태에서만 latch할 수 있습니다."
        )

    trigger = _text(
        kill_switch_trigger
    ).upper()

    if trigger not in LIVE_CHANGE_RUNTIME_KILL_TRIGGERS:
        raise ValueError(
            "Live Change Kill Switch trigger vocabulary가 유효하지 않습니다."
        )

    detail = _text(
        runtime_detail
    )
    if len(detail) < 50:
        raise ValueError(
            "Kill Switch / rollback rationale을 50자 이상 기록하세요."
        )

    _common_confirmations_ok(
        [
            rollback_initiated_confirmed,
            permit_source_reviewed,
            rollback_path_confirmed,
            no_auto_apply_confirmed,
            no_auto_recalibration_confirmed,
            no_auto_capacity_confirmed,
            no_execution_authorization_confirmed,
            human_review_confirmed,
        ]
    )

    baseline = _float(
        current.get("baseline_value")
    )
    restored = float(
        observed_restored_value
    )

    restored_ok = abs(
        restored - baseline
    ) <= 1e-9

    latest = current.get(
        "latest_event"
    ) or {}
    open_created = pd.to_datetime(
        latest.get("created_at"),
        errors="coerce",
        utc=True,
    )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    kill_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(open_created)
        or pd.isna(kill_created)
        or kill_created <= open_created
    ):
        raise ValueError(
            "Kill Switch event는 ACTIVATE event 이후에 저장되어야 합니다."
        )

    return _build_event(
        current,
        runtime_session_id=_text(
            current.get("active_session_id")
        ),
        event_type="KILL_SWITCH",
        runtime_state="LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
        runtime_guard="KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
        session_index=_int(
            current.get("session_index")
        ),
        sessions_used=_int(
            current.get("sessions_used")
        ),
        sessions_remaining=_int(
            current.get("sessions_remaining")
        ),
        activation_receipt_ref=_text(
            current.get("activation_receipt_ref")
        ),
        observed_pre_value=_float(
            current.get("candidate_value")
        ),
        observed_post_value=restored,
        kill_switch_trigger=trigger,
        kill_switch_latched=True,
        rollback_required=True,
        baseline_restore_confirmed=restored_ok,
        runtime_detail=detail,
        permit_source_reviewed=permit_source_reviewed,
        baseline_freshness_confirmed=True,
        candidate_artifact_verified=True,
        canary_isolation_confirmed=True,
        change_window_confirmed=True,
        rollback_path_confirmed=rollback_path_confirmed,
        manual_external_activation_confirmed=True,
        no_auto_apply_confirmed=no_auto_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
        note=note,
        created_at=now,
    )


def build_flow_live_change_runtime_queue(
    runtime: dict | None,
) -> pd.DataFrame:
    row = runtime or {}
    state = _text(
        row.get("runtime_state")
    ).upper()

    mapping = {
        "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT": (
            "LR2",
            "WAIT",
            "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT",
            "MANUAL_CANARY_APPLY_ONLY Permit이 아직 없음",
            "Live Change Design / Apply evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "LIVE_CHANGE_RUNTIME_NOT_REQUIRED": (
            "LR3",
            "MONITOR",
            "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
            "현재 Apply decision에서는 Live Change Runtime이 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "LIVE_CHANGE_RUNTIME_DEFERRED": (
            "LR2",
            "WAIT",
            "LIVE_CHANGE_RUNTIME_DEFERRED",
            "Human Apply decision = DEFER",
            "새 evidence/운영 조건 확인 후 재검토",
        ),
        "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED": (
            "LR1",
            "REVIEW",
            "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
            "Apply Permit state는 있으나 immutable source를 확인할 수 없음",
            "Live Change Apply audit을 먼저 확인",
        ),
        "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW": (
            "LR0",
            "BLOCKED",
            "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "Apply Permit 또는 Runtime event immutable hash mismatch",
            "Apply / Runtime source integrity를 먼저 복구",
        ),
        "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION": (
            "LR1",
            "REVIEW",
            "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION",
            (
                f"scope {float(row.get('permit_scope_pct',0)):.1%} · "
                f"sessions {row.get('sessions_used',0)}/"
                f"{row.get('permit_session_budget',0)} · "
                f"rollback {row.get('rollback_target_value',0)}"
            ),
            "외부 manual activation receipt와 baseline/candidate observed value를 확인 후 ACTIVATE 기록",
        ),
        "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY": (
            "LR0",
            "ACTIVE",
            "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY",
            (
                f"session {row.get('session_index',0)} · "
                f"remaining {row.get('sessions_remaining',0)} · "
                f"receipt {row.get('activation_receipt_ref','')}"
            ),
            "Canary observation 중 CLOSE 또는 KILL_SWITCH만 허용",
        ),
        "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED": (
            "LR0",
            "BLOCKED",
            "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
            (
                f"trigger {row.get('kill_switch_trigger','')} · "
                f"baseline restored {row.get('baseline_restore_confirmed',False)}"
            ),
            "재활성화 금지; rollback closure / post-mortem 우선",
        ),
        "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED": (
            "LR3",
            "MONITOR",
            "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            (
                f"sessions {row.get('sessions_used',0)}/"
                f"{row.get('permit_session_budget',0)} consumed"
            ),
            "추가 ACTIVATE 금지; post-change Outcome evaluation으로 이동",
        ),
        "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED": (
            "LR0",
            "REVIEW",
            "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
            "새 Apply Permit으로 기존 Runtime source가 stale",
            "현재 immutable Apply Permit 기준으로 새 Runtime cycle 검토",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "LR0",
            "BLOCKED",
            "LIVE_CHANGE_RUNTIME_UNKNOWN_STATE",
            state or "MISSING",
            "Live Change Runtime state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            LIVE_CHANGE_RUNTIME_QUEUE_COLS,
    )
