from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_shadow_adoption_review import (
    FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
    shadow_adoption_review_snapshot_integrity,
)
from engine.operations_flow_controlled_trial_design import (
    FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
    CONTROLLED_TRIAL_DESIGN_STATES,
    TRIAL_DESIGN_GUARD_BY_STATE,
    build_flow_controlled_trial_design,
    controlled_trial_design_snapshot_integrity,
    latest_controlled_trial_design_snapshot,
)


TRIAL_DESIGN_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

TRIAL_DESIGN_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V141_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )
        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v141_trial_design_context(
    *,
    v140_context: dict | None,
    controlled_trial_design_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v140_context or {}
    adoption = upstream.get("adoption") or {}

    design_df = _ensure_cols(
        controlled_trial_design_snapshots,
        FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
    )

    design = build_flow_controlled_trial_design(
        adoption,
        design_df,
        default_max_trial_scope_pct=0.10,
        default_max_trial_sessions=3,
        default_min_trial_outcomes=3,
        default_max_relative_error_degradation_pct=0.10,
    )

    latest_design = latest_controlled_trial_design_snapshot(
        design_df
    )

    latest_integrity = (
        _text(
            controlled_trial_design_snapshot_integrity(
                latest_design
            ).get("status")
        ).upper()
        if latest_design
        else "NONE"
    )

    return {
        "v140_context": upstream,
        "adoption": adoption,
        "adoption_review_snapshots": _ensure_cols(
            upstream.get(
                "shadow_adoption_review_snapshots"
            ),
            FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
        ),
        "controlled_trial_design_snapshots": design_df,
        "design": design,
        "design_integrity": _integrity_counts(
            design_df,
            controlled_trial_design_snapshot_integrity,
        ),
        "latest_design": latest_design,
        "latest_design_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _adoption_routing_ok(
    design: dict,
    adoption: dict,
) -> bool:
    design_state = _text(
        design.get("design_state")
    ).upper()
    adoption_state = _text(
        adoption.get("adoption_state")
    ).upper()

    if adoption_state == "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL":
        return design_state in {
            "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED",
            "TRIAL_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "TRIAL_DESIGN_REQUIRED",
            "TRIAL_DESIGN_SUPERSEDED",
            "TRIAL_DESIGN_LOCKED",
        }

    if adoption_state in {
        "ADOPTION_VALIDATION_FAILED",
        "ADOPTION_REJECTED",
        "ADOPTION_DEFERRED",
    }:
        return design_state == "TRIAL_DESIGN_NOT_REQUIRED"

    return design_state == "TRIAL_DESIGN_UPSTREAM_WAIT"


def _source_mapping_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    state = _text(
        design.get("design_state")
    ).upper()

    if state in {
        "TRIAL_DESIGN_UPSTREAM_WAIT",
        "TRIAL_DESIGN_NOT_REQUIRED",
    }:
        return True

    source_id = _text(
        design.get(
            "source_adoption_review_id"
        )
    )
    source_hash = _text(
        design.get(
            "source_adoption_review_hash"
        )
    )

    if not source_id or not source_hash:
        return state == "TRIAL_DESIGN_ADOPTION_SOURCE_REQUIRED"

    index, duplicates = _index_by_id(
        context.get(
            "adoption_review_snapshots"
        ),
        "shadow_adoption_review_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    if not parent:
        return False

    return (
        _text(
            shadow_adoption_review_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("decision")
        ).upper()
        == "ACCEPT_FOR_CONTROLLED_TRIAL"
        and _text(
            parent.get("adoption_state")
        ).upper()
        == "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL"
    )


def _locked_design_contract_ok(
    design: dict,
) -> bool:
    state = _text(
        design.get("design_state")
    ).upper()

    if state != "TRIAL_DESIGN_LOCKED":
        return True

    row = design.get(
        "latest_design"
    ) or {}

    if not row:
        return False

    if _text(
        controlled_trial_design_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    if _text(
        row.get("trial_mode")
    ).upper() != "SHADOW_CANARY_ONLY":
        return False

    scope = _float(
        row.get("max_trial_scope_pct")
    )
    sessions = _int(
        row.get("max_trial_sessions")
    )
    outcomes = _int(
        row.get("min_trial_outcomes")
    )
    degradation = _float(
        row.get(
            "max_relative_error_degradation_pct"
        )
    )

    if not (
        0.01 <= scope <= 0.10
        and 1 <= sessions <= 5
        and outcomes >= 3
        and 0.0 <= degradation <= 0.10
    ):
        return False

    required_flags = [
        "rollback_on_error_degradation",
        "rollback_on_assumption_drift",
        "rollback_on_integrity_failure",
        "rollback_on_source_supersession",
        "source_review_confirmed",
        "isolation_confirmed",
        "manual_start_required_confirmed",
        "rollback_path_confirmed",
        "no_live_apply_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            row.get(field)
        )
        for field in required_flags
    ):
        return False

    if len(
        _text(
            row.get("rollback_detail")
        )
    ) < 40:
        return False

    return True


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    state = _text(
        design.get("design_state")
    ).upper()
    latest = context.get(
        "latest_design"
    ) or {}

    if state == "TRIAL_DESIGN_LOCKED":
        source_ts = pd.to_datetime(
            design.get(
                "source_adoption_review_created_at"
            ),
            errors="coerce",
            utc=True,
        )
        design_ts = pd.to_datetime(
            latest.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )

        return (
            not pd.isna(source_ts)
            and not pd.isna(design_ts)
            and design_ts > source_ts
        )

    if state == "TRIAL_DESIGN_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(
                latest.get(
                    "source_adoption_review_id"
                )
            )
            != _text(
                design.get(
                    "source_adoption_review_id"
                )
            )
            or _text(
                latest.get(
                    "source_adoption_review_hash"
                )
            )
            != _text(
                design.get(
                    "source_adoption_review_hash"
                )
            )
        )

    return True


def _no_start_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("design") or {},
        context.get("latest_design") or {},
        context.get("adoption") or {},
    ]:
        for field in [
            "trial_design_authorization",
            "trial_start_authorization",
            "adoption_authorization",
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "controlled_trial_design_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "trial_design_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v141_trial_design_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    design = ctx.get("design") or {}
    adoption = ctx.get("adoption") or {}
    counts = ctx.get("design_integrity") or {}

    state = _text(
        design.get("design_state")
    ).upper()
    guard = _text(
        design.get("design_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Controlled Trial Design Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Design immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Design State / Guard Vocabulary",
            (
                state in CONTROLLED_TRIAL_DESIGN_STATES
                and guard
                == TRIAL_DESIGN_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {TRIAL_DESIGN_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Trial Design state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Adoption Decision → Trial Design State Invariant",
            _adoption_routing_ok(
                design,
                adoption,
            ),
            (
                f"adoption {_text(adoption.get('adoption_state')) or 'MISSING'} · "
                f"design {state or 'MISSING'}"
            ),
            "Adoption ACCEPT/REJECT/DEFER와 Trial Design state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Design → Adoption Source Mapping",
            _source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(design.get('source_adoption_review_id')) or 'NONE'} · "
                f"integrity {_text(design.get('source_adoption_review_integrity')) or 'NONE'}"
            ),
            "Trial Design source Adoption Review id/hash/integrity 확인",
        )
    )

    bound_ok = True

    if state == "TRIAL_DESIGN_LOCKED":
        bound_ok = (
            _text(
                design.get("trial_mode")
            ).upper()
            == "SHADOW_CANARY_ONLY"
            and 0.01
            <= _float(
                design.get(
                    "max_trial_scope_pct"
                )
            )
            <= 0.10
            and 1
            <= _int(
                design.get(
                    "max_trial_sessions"
                )
            )
            <= 5
            and _int(
                design.get(
                    "min_trial_outcomes"
                )
            )
            >= 3
            and 0.0
            <= _float(
                design.get(
                    "max_relative_error_degradation_pct"
                )
            )
            <= 0.10
        )

    checks.append(
        _technical_row(
            "Controlled Trial Canary Scope / Session / Outcome Bound Invariant",
            bound_ok,
            (
                f"state {state or 'MISSING'} · "
                f"mode {_text(design.get('trial_mode')) or 'NONE'} · "
                f"scope {_float(design.get('max_trial_scope_pct')):.1%} · "
                f"sessions {_int(design.get('max_trial_sessions'))} · "
                f"outcomes {_int(design.get('min_trial_outcomes'))}"
            ),
            "Canary scope/session/outcome/degradation hard bound 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Rollback / Human Design Contract Invariant",
            _locked_design_contract_ok(
                design
            ),
            (
                f"state {state or 'MISSING'} · "
                f"rollback detail "
                f"{len(_text(design.get('rollback_detail')))} chars"
            ),
            "LOCKED Design의 rollback triggers / manual-start / Human confirmations 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Design Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source created {_text(design.get('source_adoption_review_created_at')) or 'NONE'} · "
                f"latest design {_text((ctx.get('latest_design') or {}).get('controlled_trial_design_id')) or 'NONE'}"
            ),
            "Design 저장 순서와 새 Adoption source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial No-Start Authorization Invariant",
            _no_start_authorization_ok(
                ctx
            ),
            "NONE",
            "Trial Start/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "TRIAL_DESIGN_NOT_REQUIRED",
            "TRIAL_DESIGN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Design Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"mode {_text(design.get('trial_mode')) or 'NONE'} · "
                f"scope {_float(design.get('max_trial_scope_pct')):.1%}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 adoption/design wait는 Technical FAIL로 승격하지 않고 "
                    "prospective evidence와 Human decision을 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "design_state": state,
        "adoption_state": _text(
            adoption.get("adoption_state")
        ).upper(),
        "latest_trial_design_integrity":
            _text(
                ctx.get(
                    "latest_design_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_DESIGN_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v141_trial_design_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    design_df = _ensure_cols(
        ctx.get(
            "controlled_trial_design_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
    )
    adoption_df = _ensure_cols(
        ctx.get(
            "adoption_review_snapshots"
        ),
        FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        design_df,
        controlled_trial_design_snapshot_integrity,
    )

    adoption_index, adoption_duplicates = _index_by_id(
        adoption_df,
        "shadow_adoption_review_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in design_df.iterrows():
        item = row.to_dict()

        design_id = _text(
            item.get(
                "controlled_trial_design_id"
            )
        )

        if design_id:
            if design_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(design_id)

        if (
            _text(
                item.get("design_state")
            ).upper()
            != "TRIAL_DESIGN_LOCKED"
            or _text(
                item.get("design_guard")
            ).upper()
            != "TRIAL_DESIGN_LOCKED_NO_START"
            or _text(
                item.get("trial_mode")
            ).upper()
            != "SHADOW_CANARY_ONLY"
            or not (
                0.01
                <= _float(
                    item.get(
                        "max_trial_scope_pct"
                    )
                )
                <= 0.10
            )
            or not (
                1
                <= _int(
                    item.get(
                        "max_trial_sessions"
                    )
                )
                <= 5
            )
            or _int(
                item.get(
                    "min_trial_outcomes"
                )
            )
            < 3
            or not (
                0.0
                <= _float(
                    item.get(
                        "max_relative_error_degradation_pct"
                    )
                )
                <= 0.10
            )
        ):
            contract_violations += 1

        required_flags = [
            "rollback_on_error_degradation",
            "rollback_on_assumption_drift",
            "rollback_on_integrity_failure",
            "rollback_on_source_supersession",
            "source_review_confirmed",
            "isolation_confirmed",
            "manual_start_required_confirmed",
            "rollback_path_confirmed",
            "no_live_apply_confirmed",
            "no_auto_capacity_confirmed",
            "no_execution_authorization_confirmed",
            "human_review_confirmed",
        ]

        if (
            not all(
                _bool(
                    item.get(field)
                )
                for field in required_flags
            )
            or len(
                _text(
                    item.get(
                        "rollback_detail"
                    )
                )
            )
            < 40
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_adoption_review_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_adoption_review_hash"
            )
        )

        parent = adoption_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                shadow_adoption_review_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("decision")
            ).upper()
            != "ACCEPT_FOR_CONTROLLED_TRIAL"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )
            design_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(design_ts)
                or design_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "trial_design_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Controlled Trial Design Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Design immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Design Audit Contract / Rollback Invariant",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "LOCKED design canary bounds / rollback contract / confirmations 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Design Audit → Adoption ACCEPT Lineage",
            (
                lineage_violations == 0
                and adoption_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"adoption duplicate ids {adoption_duplicates}"
            ),
            "Design source Adoption ACCEPT audit id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Design Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate design ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Design audit identity uniqueness 및 Adoption audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Design Audit No-Start Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Trial Start/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("design") or {}).get(
            "design_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "TRIAL_DESIGN_NOT_REQUIRED",
            "TRIAL_DESIGN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Design Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current design {current_state or 'MISSING'} · "
                f"saved designs {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 ACCEPT_FOR_CONTROLLED_TRIAL source가 생긴 뒤 "
                    "canary scope/rollback contract가 필요할 때만 Design audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_DESIGN_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v141_release_readiness(
    *,
    v140_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    trial_design_release_gate: str,
    trial_design_audit_gate: str,
    trial_design_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.40 Shadow Adoption Human Decision Release Baseline",
            _text(
                v140_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v140_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Design Technical Release Gate",
            _text(
                trial_design_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Design Audit Integrity Gate",
            _text(
                trial_design_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            trial_design_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "CONTROLLED_TRIAL_DESIGN_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V141_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v141_integration_crosscheck(
    *,
    integration_consistency: str,
    trial_design_release_gate: str,
    trial_design_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Design Technical Gate",
            _text(
                trial_design_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Design Audit Gate",
            _text(
                trial_design_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_design_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V141_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v141_data_crosscheck(
    *,
    csv_fail_count: int,
    trial_design_release_gate: str,
    trial_design_audit_gate: str,
    latest_trial_design_integrity: str,
) -> dict:
    latest = _text(
        latest_trial_design_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Design Technical Gate",
            _text(
                trial_design_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Design Audit Gate",
            _text(
                trial_design_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Controlled Trial Design Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V141_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
