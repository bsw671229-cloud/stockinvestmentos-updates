from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    flow_projection_scorecard_snapshot_integrity,
)
from engine.operations_flow_recalibration_review import (
    FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
    recalibration_review_snapshot_integrity,
)
from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    RECALIBRATION_PROPOSAL_STATES,
    PROPOSAL_GUARD_BY_STATE,
    build_flow_recalibration_proposal,
    recalibration_proposal_snapshot_integrity,
    latest_recalibration_proposal_snapshot,
)


PROPOSAL_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

PROPOSAL_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V137_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


GUARD_BY_STATE = {
    "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT": "HOLD_RECALIBRATION_CONTRACT",
    "RECALIBRATION_PROPOSAL_NOT_REQUIRED": "NO_RECALIBRATION_PROPOSAL",
    "RECALIBRATION_PROPOSAL_REBASE_FIRST": "HOLD_ASSUMPTION_DRIFT",
    "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED": "HOLD_MODEL_PROPOSAL",
    "RECALIBRATION_PARAMETER_DELTA_REQUIRED": "HOLD_PARAMETER_PROPOSAL",
    "RECALIBRATION_EXECUTION_REMEDIATION_ONLY": "NO_MODEL_CHANGE",
    "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY": "NO_MODEL_CHANGE",
    "RECALIBRATION_PROPOSAL_INTEGRITY_REVIEW": "HOLD_PROPOSAL_INTEGRITY",
    "RECALIBRATION_PROPOSAL_SUPERSEDED": "HOLD_RECALIBRATION_CONTRACT",
    "RECALIBRATION_PROPOSAL_LOCKED": "PROPOSAL_LOCKED_SHADOW_ONLY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )
        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v137_proposal_context(
    *,
    v136_context: dict | None,
    recalibration_proposal_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v136_context or {}
    review = upstream.get("review") or {}
    latest_scorecard = upstream.get("latest_scorecard") or {}

    proposal_df = _ensure_cols(
        recalibration_proposal_snapshots,
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )

    proposal = build_flow_recalibration_proposal(
        review,
        latest_scorecard,
        proposal_df,
        max_parameter_delta_pct=0.50,
    )

    latest_proposal = latest_recalibration_proposal_snapshot(
        proposal_df
    )

    latest_integrity = (
        _text(
            recalibration_proposal_snapshot_integrity(
                latest_proposal
            ).get("status")
        ).upper()
        if latest_proposal
        else "NONE"
    )

    return {
        "v136_context": upstream,
        "review": review,
        "latest_scorecard": latest_scorecard,
        "scorecard_snapshots": _ensure_cols(
            upstream.get("scorecard_snapshots"),
            FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
        ),
        "recalibration_review_snapshots": _ensure_cols(
            upstream.get("recalibration_review_snapshots"),
            FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
        ),
        "recalibration_proposal_snapshots": proposal_df,
        "proposal": proposal,
        "proposal_integrity": _integrity_counts(
            proposal_df,
            recalibration_proposal_snapshot_integrity,
        ),
        "latest_proposal": latest_proposal,
        "latest_proposal_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _source_contract_matches(
    proposal: dict,
    review: dict,
) -> bool:
    state = _text(
        proposal.get("proposal_state")
    ).upper()

    no_source_states = {
        "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
        "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
        "RECALIBRATION_PROPOSAL_REBASE_FIRST",
    }

    if state in no_source_states:
        return (
            not _text(
                proposal.get(
                    "source_recalibration_review_id"
                )
            )
            and not _text(
                proposal.get(
                    "source_recalibration_review_hash"
                )
            )
        )

    contract = review.get(
        "latest_contract"
    ) or {}

    if not contract:
        return state in {
            "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
            "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
            "RECALIBRATION_PROPOSAL_REBASE_FIRST",
        }

    return (
        _text(
            proposal.get(
                "source_recalibration_review_id"
            )
        )
        == _text(
            contract.get(
                "recalibration_review_id"
            )
        )
        and _text(
            proposal.get(
                "source_recalibration_review_hash"
            )
        )
        == _text(
            contract.get(
                "snapshot_hash"
            )
        )
        and _text(
            recalibration_review_snapshot_integrity(
                contract
            ).get("status")
        ).upper()
        == "OK"
    )


def _scorecard_source_matches(
    proposal: dict,
    scorecard: dict,
) -> bool:
    state = _text(
        proposal.get("proposal_state")
    ).upper()

    if state in {
        "RECALIBRATION_PROPOSAL_UPSTREAM_WAIT",
        "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
        "RECALIBRATION_PROPOSAL_REBASE_FIRST",
    }:
        return True

    if not scorecard:
        return False

    return (
        _text(
            proposal.get(
                "source_scorecard_snapshot_id"
            )
        )
        == _text(
            scorecard.get(
                "scorecard_snapshot_id"
            )
        )
        and _text(
            proposal.get(
                "source_scorecard_hash"
            )
        )
        == _text(
            scorecard.get(
                "snapshot_hash"
            )
        )
        and _text(
            flow_projection_scorecard_snapshot_integrity(
                scorecard
            ).get("status")
        ).upper()
        == "OK"
    )


def _routing_invariant(
    proposal: dict,
) -> bool:
    state = _text(
        proposal.get("proposal_state")
    ).upper()
    guard = _text(
        proposal.get("proposal_guard")
    ).upper()
    primary = _text(
        proposal.get("primary_attribution")
    ).upper()
    scope = _text(
        proposal.get("proposal_scope")
    ).upper()
    target = _text(
        proposal.get("target_metric")
    ).upper()

    if state == "RECALIBRATION_MODEL_SHADOW_SPEC_REQUIRED":
        return (
            primary == "MODEL"
            and guard == "HOLD_MODEL_PROPOSAL"
            and scope == "MODEL_SHADOW"
            and target == "MODEL_SPECIFICATION"
        )

    if state == "RECALIBRATION_PARAMETER_DELTA_REQUIRED":
        return (
            primary == "PARAMETER"
            and guard == "HOLD_PARAMETER_PROPOSAL"
            and scope == "PARAMETER_SHADOW"
            and target == "BASE_BURN_RATE"
            and _float(
                proposal.get("current_value")
            ) > 0
        )

    if state == "RECALIBRATION_EXECUTION_REMEDIATION_ONLY":
        return (
            primary == "EXECUTION"
            and guard == "NO_MODEL_CHANGE"
            and not scope
            and not target
        )

    if state == "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY":
        return (
            primary == "EXOGENOUS"
            and guard == "NO_MODEL_CHANGE"
            and not scope
            and not target
        )

    if state == "RECALIBRATION_PROPOSAL_LOCKED":
        return (
            guard == "PROPOSAL_LOCKED_SHADOW_ONLY"
            and scope in {
                "MODEL_SHADOW",
                "PARAMETER_SHADOW",
            }
            and primary in {
                "MODEL",
                "PARAMETER",
            }
        )

    return True


def _locked_proposal_invariant(
    proposal: dict,
) -> bool:
    if _text(
        proposal.get("proposal_state")
    ).upper() != "RECALIBRATION_PROPOSAL_LOCKED":
        return True

    row = (
        proposal.get("latest_proposal")
        or proposal
    )

    if _text(
        recalibration_proposal_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    confirmations = [
        "shadow_only_confirmed",
        "no_live_parameter_change_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            row.get(field)
        )
        for field in confirmations
    ):
        return False

    scope = _text(
        row.get("proposal_scope")
    ).upper()

    if scope == "PARAMETER_SHADOW":
        current = _float(
            row.get("current_value")
        )
        proposed = _float(
            row.get("proposed_value")
        )
        delta_pct = _float(
            row.get("delta_pct")
        )
        bound = abs(
            _float(
                row.get(
                    "max_abs_delta_pct"
                )
            )
        )

        if (
            current <= 0
            or proposed <= 0
            or bound <= 0
            or abs(delta_pct) > bound + 1e-12
        ):
            return False

    elif scope == "MODEL_SHADOW":
        if _text(
            row.get("target_metric")
        ).upper() != "MODEL_SPECIFICATION":
            return False
    else:
        return False

    return all(
        _text(
            row.get(field)
        ).upper()
        in {"", "NONE"}
        for field in [
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]
    )


def build_v137_proposal_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    proposal = ctx.get("proposal") or {}
    review = ctx.get("review") or {}
    scorecard = ctx.get("latest_scorecard") or {}
    counts = ctx.get("proposal_integrity") or {}

    state = _text(
        proposal.get("proposal_state")
    ).upper()
    guard = _text(
        proposal.get("proposal_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Recalibration Proposal Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Recalibration Proposal audit immutable hash 확인",
        )
    )

    expected_guard = GUARD_BY_STATE.get(
        state,
        "",
    )
    vocabulary_ok = (
        state in RECALIBRATION_PROPOSAL_STATES
        and bool(expected_guard)
        and guard == expected_guard
    )

    checks.append(
        _technical_row(
            "Recalibration Proposal State / Guard Vocabulary",
            vocabulary_ok,
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {expected_guard or 'UNKNOWN'}"
            ),
            "Proposal state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Attribution / Proposal Scope Routing Invariant",
            _routing_invariant(
                proposal
            ),
            (
                f"state {state or 'MISSING'} · "
                f"attribution {_text(proposal.get('primary_attribution')) or 'NONE'} · "
                f"scope {_text(proposal.get('proposal_scope')) or 'NONE'} · "
                f"target {_text(proposal.get('target_metric')) or 'NONE'}"
            ),
            "MODEL/PARAMETER/EXECUTION/EXOGENOUS routing 확인",
        )
    )

    checks.append(
        _technical_row(
            "Proposal → Recalibration Contract Source Mapping",
            _source_contract_matches(
                proposal,
                review,
            ),
            (
                f"state {state or 'MISSING'} · "
                f"proposal contract "
                f"{_text(proposal.get('source_recalibration_review_id')) or 'NONE'} · "
                f"current contract "
                f"{_text((review.get('latest_contract') or {}).get('recalibration_review_id')) or 'NONE'}"
            ),
            "Proposal source Contract id/hash lineage 확인",
        )
    )

    checks.append(
        _technical_row(
            "Proposal → Scorecard Source Mapping",
            _scorecard_source_matches(
                proposal,
                scorecard,
            ),
            (
                f"state {state or 'MISSING'} · "
                f"proposal scorecard "
                f"{_text(proposal.get('source_scorecard_snapshot_id')) or 'NONE'} · "
                f"current scorecard "
                f"{_text(scorecard.get('scorecard_snapshot_id')) or 'NONE'}"
            ),
            "Proposal source Scorecard id/hash lineage 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Proposal / Parameter Bound Invariant",
            _locked_proposal_invariant(
                proposal
            ),
            (
                f"state {state or 'MISSING'} · "
                f"scope {_text(proposal.get('proposal_scope')) or 'NONE'} · "
                f"delta {_float(proposal.get('delta_pct')):.1%} · "
                f"bound {_float(proposal.get('max_abs_delta_pct')):.1%}"
            ),
            "LOCKED proposal의 shadow-only / parameter bound / confirmations 확인",
        )
    )

    latest = proposal.get(
        "latest_proposal"
    ) or {}

    if state == "RECALIBRATION_PROPOSAL_SUPERSEDED":
        supersession_ok = (
            bool(latest)
            and _text(
                recalibration_proposal_snapshot_integrity(
                    latest
                ).get("status")
            ).upper()
            == "OK"
            and not _source_contract_matches(
                latest,
                review,
            )
        )
    else:
        supersession_ok = True

    checks.append(
        _technical_row(
            "Recalibration Proposal Supersession Invariant",
            supersession_ok,
            (
                f"state {state or 'MISSING'} · "
                f"latest proposal "
                f"{_text(latest.get('recalibration_proposal_id')) or 'NONE'}"
            ),
            "새 Recalibration Contract에서 이전 Proposal 재사용 차단 확인",
        )
    )

    auth_violations = 0

    for item in [
        proposal,
        latest,
        review,
    ]:
        for field in [
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                auth_violations += 1

    history = ctx.get(
        "recalibration_proposal_snapshots"
    )
    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            auth_violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        ctx.get("execution_authorization")
    ).upper() != "NONE":
        auth_violations += 1

    checks.append(
        _technical_row(
            "Recalibration Proposal Authorization / No-Apply Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            "Proposal/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
            "RECALIBRATION_EXECUTION_REMEDIATION_ONLY",
            "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY",
            "RECALIBRATION_PROPOSAL_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Recalibration Proposal Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"attribution {_text(proposal.get('primary_attribution')) or 'NONE'} · "
                f"scope {_text(proposal.get('proposal_scope')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream/proposal/rebase wait는 Technical FAIL로 승격하지 않고 "
                    "Proof/Contract evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "proposal_state": state,
        "primary_attribution": _text(
            proposal.get("primary_attribution")
        ).upper(),
        "proposal_scope": _text(
            proposal.get("proposal_scope")
        ).upper(),
        "latest_recalibration_proposal_integrity":
            _text(
                ctx.get(
                    "latest_proposal_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=PROPOSAL_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v137_proposal_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    proposal_df = _ensure_cols(
        ctx.get(
            "recalibration_proposal_snapshots"
        ),
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )
    review_df = _ensure_cols(
        ctx.get(
            "recalibration_review_snapshots"
        ),
        FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
    )
    scorecard_df = _ensure_cols(
        ctx.get(
            "scorecard_snapshots"
        ),
        FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        proposal_df,
        recalibration_proposal_snapshot_integrity,
    )
    review_index, review_duplicates = _index_by_id(
        review_df,
        "recalibration_review_id",
    )
    scorecard_index, scorecard_duplicates = _index_by_id(
        scorecard_df,
        "scorecard_snapshot_id",
    )

    state_scope_violations = 0
    review_lineage_violations = 0
    scorecard_lineage_violations = 0
    identity_duplicates = 0
    auth_violations = 0

    seen_ids = set()

    for _, row in proposal_df.iterrows():
        item = row.to_dict()

        proposal_id = _text(
            item.get(
                "recalibration_proposal_id"
            )
        )
        if proposal_id:
            if proposal_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(proposal_id)

        if _text(
            item.get("proposal_state")
        ).upper() != "RECALIBRATION_PROPOSAL_LOCKED":
            state_scope_violations += 1

        if _text(
            item.get("proposal_guard")
        ).upper() != "PROPOSAL_LOCKED_SHADOW_ONLY":
            state_scope_violations += 1

        scope = _text(
            item.get("proposal_scope")
        ).upper()
        primary = _text(
            item.get("primary_attribution")
        ).upper()

        if (
            scope == "PARAMETER_SHADOW"
            and primary == "PARAMETER"
        ):
            current = _float(
                item.get("current_value")
            )
            proposed = _float(
                item.get("proposed_value")
            )
            delta_pct = _float(
                item.get("delta_pct")
            )
            bound = abs(
                _float(
                    item.get(
                        "max_abs_delta_pct"
                    )
                )
            )
            if (
                current <= 0
                or proposed <= 0
                or bound <= 0
                or abs(delta_pct) > bound + 1e-12
            ):
                state_scope_violations += 1

        elif not (
            scope == "MODEL_SHADOW"
            and primary == "MODEL"
            and _text(
                item.get("target_metric")
            ).upper()
            == "MODEL_SPECIFICATION"
        ):
            state_scope_violations += 1

        if not all(
            _bool(
                item.get(field)
            )
            for field in [
                "shadow_only_confirmed",
                "no_live_parameter_change_confirmed",
                "no_auto_capacity_confirmed",
                "no_execution_authorization_confirmed",
                "human_review_confirmed",
            ]
        ):
            state_scope_violations += 1

        review_id = _text(
            item.get(
                "source_recalibration_review_id"
            )
        )
        review_hash = _text(
            item.get(
                "source_recalibration_review_hash"
            )
        )
        review_parent = review_index.get(
            review_id
        )

        if (
            not review_parent
            or _text(
                recalibration_review_snapshot_integrity(
                    review_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                review_parent.get(
                    "snapshot_hash"
                )
            )
            != review_hash
        ):
            review_lineage_violations += 1

        scorecard_id = _text(
            item.get(
                "source_scorecard_snapshot_id"
            )
        )
        scorecard_hash = _text(
            item.get(
                "source_scorecard_hash"
            )
        )
        scorecard_parent = scorecard_index.get(
            scorecard_id
        )

        if (
            not scorecard_parent
            or _text(
                flow_projection_scorecard_snapshot_integrity(
                    scorecard_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                scorecard_parent.get(
                    "snapshot_hash"
                )
            )
            != scorecard_hash
        ):
            scorecard_lineage_violations += 1

        for field in [
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                auth_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Recalibration Proposal Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Proposal immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Proposal Audit State / Shadow Scope Invariant",
            state_scope_violations == 0,
            f"violations {state_scope_violations}",
            "LOCKED Proposal state/scope/bound/confirmations 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Proposal Audit → Contract Lineage",
            (
                review_lineage_violations == 0
                and review_duplicates == 0
            ),
            (
                f"violations {review_lineage_violations} · "
                f"contract duplicate ids {review_duplicates}"
            ),
            "Proposal source Recalibration Contract id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Proposal Audit → Scorecard Lineage",
            (
                scorecard_lineage_violations == 0
                and scorecard_duplicates == 0
            ),
            (
                f"violations {scorecard_lineage_violations} · "
                f"scorecard duplicate ids {scorecard_duplicates}"
            ),
            "Proposal source Scorecard id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Proposal Audit Identity / Authorization Invariant",
            (
                identity_duplicates == 0
                and auth_violations == 0
            ),
            (
                f"duplicate proposal ids {identity_duplicates} · "
                f"authorization violations {auth_violations}"
            ),
            "Proposal audit identity uniqueness와 Authorization NONE 확인",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("proposal") or {}).get(
            "proposal_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "RECALIBRATION_PROPOSAL_NOT_REQUIRED",
            "RECALIBRATION_EXECUTION_REMEDIATION_ONLY",
            "RECALIBRATION_EXOGENOUS_OBSERVE_ONLY",
            "RECALIBRATION_PROPOSAL_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Recalibration Proposal Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current proposal {current_state or 'MISSING'} · "
                f"saved proposals {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 Recalibration Contract가 LOCKED되고 MODEL/PARAMETER proposal이 필요할 때만 "
                    "Proposal audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=PROPOSAL_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v137_release_readiness(
    *,
    v136_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    proposal_release_gate: str,
    proposal_audit_gate: str,
    proposal_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(
        v136_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    proposal_gate = _text(
        proposal_release_gate
    ).upper()
    audit_gate = _text(
        proposal_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.36 Recalibration Human Review Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Recalibration Proposal Technical Release Gate",
            proposal_gate == "PASS",
            proposal_gate or "MISSING",
        ),
        _candidate_row(
            "Recalibration Proposal Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(
            proposal_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "RECALIBRATION_PROPOSAL_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V137_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v137_integration_crosscheck(
    *,
    integration_consistency: str,
    proposal_release_gate: str,
    proposal_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    proposal_gate = _text(
        proposal_release_gate
    ).upper()
    audit_gate = _text(
        proposal_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Recalibration Proposal Technical Gate",
            proposal_gate == "PASS",
            proposal_gate or "MISSING",
        ),
        _candidate_row(
            "Recalibration Proposal Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V137_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v137_data_crosscheck(
    *,
    csv_fail_count: int,
    proposal_release_gate: str,
    proposal_audit_gate: str,
    latest_proposal_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    proposal_gate = _text(
        proposal_release_gate
    ).upper()
    audit_gate = _text(
        proposal_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_proposal_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Recalibration Proposal Technical Gate",
            proposal_gate == "PASS",
            proposal_gate or "MISSING",
        ),
        _candidate_row(
            "Recalibration Proposal Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Recalibration Proposal Audit Integrity",
            latest_integrity in {"OK", "NONE"},
            latest_integrity or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V137_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
