from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)


FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS = [
    "scorecard_snapshot_id",
    "created_at",
    "source_projection_snapshot_id",
    "outcome_snapshots_total",
    "unique_evidence_endpoints",
    "eligible_outcomes",
    "invalid_outcome_count",
    "proof_clock_count",
    "proof_clock_target",
    "proof_clock_state",
    "error_regime",
    "scorecard_state",
    "latest_evaluation_state",
    "latest_recalibration_state",
    "latest_capacity_decision_state",
    "avg_abs_pct_error",
    "latest_abs_pct_error",
    "latest_signed_burn_error",
    "latest_realized_avg_burn",
    "base_burn_rate",
    "latest_current_groups",
    "latest_attention_groups",
    "latest_capacity",
    "latest_evidence_intervals",
    "capacity_override_review_gate",
    "override_review_approval_state",
    "override_review_ttl_intervals",
    "override_review_expires_after_evidence",
    "projection_authorization",
    "capacity_authorization",
    "capacity_override_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PROJECTION_SCORECARD_TABLE_COLS = [
    "created_at",
    "source_projection_snapshot_id",
    "evidence_end_trend_snapshot_id",
    "evidence_intervals",
    "evaluation_state",
    "recalibration_state",
    "capacity_decision_state",
    "realized_avg_net_burn",
    "base_burn_rate",
    "base_burn_error",
    "base_abs_pct_error",
    "current_groups",
    "attention_groups",
    "capacity",
    "capacity_drift_count",
]


PROJECTION_SCORECARD_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


PROOF_STATES = {
    "BASE_CLEARANCE_MISS_REVIEW",
    "MODEL_BREAK_REVIEW",
    "MODEL_ERROR_REVIEW",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _optional_float(value: Any) -> float | None:
    text = _text(value)
    if not text:
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def _round_optional(value: Any) -> float | None:
    out = _optional_float(value)
    if out is None:
        return None
    return round(out, 10)


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _validated_outcomes(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()

    if df.empty:
        return {
            "valid": pd.DataFrame(columns=FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS),
            "invalid_count": 0,
        }

    for col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid_rows = []
    invalid_count = 0

    for _, row in df.loc[df["_ts"].notna()].sort_values("_ts").iterrows():
        record = row.drop(labels=["_ts"]).to_dict()
        if flow_projection_outcome_snapshot_integrity(record).get("status") == "OK":
            valid_rows.append(record)
        else:
            invalid_count += 1

    return {
        "valid": pd.DataFrame(
            valid_rows,
            columns=FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
        ),
        "invalid_count": invalid_count,
    }


def _latest_projection_history(valid: pd.DataFrame) -> pd.DataFrame:
    if valid.empty:
        return valid.copy()

    tmp = valid.copy()
    tmp["_ts"] = pd.to_datetime(
        tmp["created_at"],
        errors="coerce",
        utc=True,
    )
    tmp = tmp.loc[tmp["_ts"].notna()].sort_values("_ts")

    if tmp.empty:
        return tmp.drop(columns=["_ts"], errors="ignore")

    latest_projection = _text(
        tmp.iloc[-1].get("source_projection_snapshot_id")
    )
    tmp = tmp.loc[
        tmp["source_projection_snapshot_id"]
        .fillna("")
        .astype(str)
        .str.strip()
        == latest_projection
    ].copy()

    # Multiple manual saves at the same evidence endpoint must not
    # advance a proof clock. Keep the newest immutable record only.
    endpoint = (
        tmp["evidence_end_trend_snapshot_id"]
        .fillna("")
        .astype(str)
        .str.strip()
    )
    fallback = (
        tmp["evidence_end_at"]
        .fillna("")
        .astype(str)
        .str.strip()
    )
    tmp["_endpoint_key"] = endpoint.where(endpoint != "", fallback)

    tmp = (
        tmp.sort_values("_ts")
        .drop_duplicates(
            subset=["_endpoint_key"],
            keep="last",
        )
        .sort_values("_ts")
    )

    return tmp.drop(
        columns=["_ts", "_endpoint_key"],
        errors="ignore",
    ).reset_index(drop=True)


def build_flow_projection_scorecard(
    outcome_snapshots: pd.DataFrame | None,
    *,
    min_outcome_evidence_intervals: int = 2,
    proof_clock_target: int = 3,
    broad_error_threshold: float = 0.50,
    override_review_ttl_intervals: int = 2,
) -> dict:
    checked = _validated_outcomes(outcome_snapshots)
    valid = checked["valid"]
    invalid_count = _int(checked["invalid_count"])
    latest_hist = _latest_projection_history(valid)

    empty_table = pd.DataFrame(columns=PROJECTION_SCORECARD_TABLE_COLS)

    if latest_hist.empty:
        return {
            "source_projection_snapshot_id": "",
            "outcome_snapshots_total": 0,
            "unique_evidence_endpoints": 0,
            "eligible_outcomes": 0,
            "invalid_outcome_count": invalid_count,
            "proof_clock_count": 0,
            "proof_clock_target": max(1, _int(proof_clock_target)),
            "proof_clock_state": "NOT_STARTED",
            "error_regime": "INSUFFICIENT_EVIDENCE",
            "scorecard_state": (
                "OUTCOME_INTEGRITY_REVIEW"
                if invalid_count > 0
                else "SCORECARD_HISTORY_REQUIRED"
            ),
            "latest_evaluation_state": "",
            "latest_recalibration_state": "",
            "latest_capacity_decision_state": "",
            "avg_abs_pct_error": None,
            "latest_abs_pct_error": None,
            "latest_signed_burn_error": None,
            "latest_realized_avg_burn": None,
            "base_burn_rate": None,
            "latest_current_groups": 0,
            "latest_attention_groups": 0,
            "latest_capacity": 0,
            "latest_evidence_intervals": 0,
            "capacity_override_review_gate": (
                "HOLD_INTEGRITY"
                if invalid_count > 0
                else "HOLD_EVIDENCE"
            ),
            "override_review_approval_state": "NOT_APPLICABLE",
            "override_review_ttl_intervals": 0,
            "override_review_expires_after_evidence": None,
            "scorecard_table": empty_table,
            "snapshot_eligible": False,
            "projection_authorization": "NONE",
            "capacity_authorization": "NONE",
            "capacity_override_authorization": "NONE",
            "execution_authorization": "NONE",
        }

    min_evidence = max(1, _int(min_outcome_evidence_intervals))
    proof_target = max(1, _int(proof_clock_target))
    threshold = max(0.0, float(broad_error_threshold))
    ttl = max(1, _int(override_review_ttl_intervals))

    latest = latest_hist.iloc[-1].to_dict()
    source_projection_id = _text(
        latest.get("source_projection_snapshot_id")
    )

    table = latest_hist.copy()
    table["evidence_intervals"] = pd.to_numeric(
        table["evidence_intervals"],
        errors="coerce",
    ).fillna(0).astype(int)

    eligible = table.loc[
        table["evidence_intervals"] >= min_evidence
    ].copy()

    table_view = pd.DataFrame(
        columns=PROJECTION_SCORECARD_TABLE_COLS
    )
    if not table.empty:
        table_view = table.copy()
        for col in PROJECTION_SCORECARD_TABLE_COLS:
            if col not in table_view.columns:
                table_view[col] = ""
        table_view = table_view[PROJECTION_SCORECARD_TABLE_COLS].reset_index(drop=True)

    latest_eval = _text(latest.get("evaluation_state")).upper()
    latest_recal = _text(latest.get("recalibration_state")).upper()
    latest_capacity_state = _text(
        latest.get("capacity_decision_state")
    ).upper()

    latest_abs_error = _optional_float(
        latest.get("base_abs_pct_error")
    )
    latest_signed_error = _optional_float(
        latest.get("base_burn_error")
    )
    latest_realized = _optional_float(
        latest.get("realized_avg_net_burn")
    )
    base_burn = _optional_float(
        latest.get("base_burn_rate")
    )

    abs_errors = [
        x
        for x in (
            _optional_float(v)
            for v in eligible.get("base_abs_pct_error", pd.Series(dtype=float)).tolist()
        )
        if x is not None
    ]
    avg_abs_error = (
        sum(abs_errors) / len(abs_errors)
        if abs_errors
        else None
    )

    proof_flags = []
    for _, row in eligible.iterrows():
        state = _text(row.get("evaluation_state")).upper()
        capacity_drift = _int(row.get("capacity_drift_count"))
        signed_error = _optional_float(row.get("base_burn_error"))
        abs_error = _optional_float(row.get("base_abs_pct_error"))

        qualifies = (
            state in PROOF_STATES
            and capacity_drift == 0
            and signed_error is not None
            and abs_error is not None
            and abs_error > threshold
        )
        proof_flags.append(bool(qualifies))

    proof_clock_count = 0
    for flag in reversed(proof_flags):
        if flag:
            proof_clock_count += 1
        else:
            break

    if proof_clock_count >= proof_target:
        proof_clock_state = "PROOF_MET_FOR_REVIEW"
    elif proof_clock_count > 0:
        proof_clock_state = "PROOF_MATURING"
    else:
        proof_clock_state = "NOT_STARTED"

    if invalid_count > 0:
        error_regime = "INTEGRITY_REVIEW"
    elif eligible.empty:
        error_regime = "INSUFFICIENT_EVIDENCE"
    elif latest_eval == "ASSUMPTION_DRIFT_REVIEW":
        error_regime = "ASSUMPTION_DRIFT"
    elif latest_eval == "MODEL_BREAK_REVIEW" or (
        latest_realized is not None
        and base_burn is not None
        and base_burn > 0
        and latest_realized <= 0
    ):
        error_regime = "MODEL_BREAK"
    else:
        recent = eligible.tail(proof_target).copy()
        signs = []
        large = []
        for _, row in recent.iterrows():
            signed = _optional_float(row.get("base_burn_error"))
            absolute = _optional_float(row.get("base_abs_pct_error"))
            if signed is None or absolute is None:
                continue
            signs.append(-1 if signed < 0 else (1 if signed > 0 else 0))
            large.append(absolute > threshold)

        if (
            len(signs) >= proof_target
            and all(large)
            and all(s < 0 for s in signs)
        ):
            error_regime = "PERSISTENT_OPTIMISTIC_BIAS"
        elif (
            len(signs) >= proof_target
            and all(large)
            and all(s > 0 for s in signs)
        ):
            error_regime = "PERSISTENT_CONSERVATIVE_BIAS"
        elif latest_abs_error is not None and latest_abs_error <= threshold:
            error_regime = "WITHIN_BAND"
        elif len(set(signs)) > 1 and any(large):
            error_regime = "MIXED_ERROR"
        else:
            error_regime = "SINGLE_ERROR_REVIEW"

    if invalid_count > 0:
        scorecard_state = "OUTCOME_INTEGRITY_REVIEW"
    elif eligible.empty:
        scorecard_state = "SCORECARD_EVIDENCE_MATURING"
    elif latest_eval == "ASSUMPTION_DRIFT_REVIEW":
        scorecard_state = "REBASE_REQUIRED"
    elif proof_clock_count >= proof_target:
        scorecard_state = "RECALIBRATION_PROOF_MET"
    elif proof_clock_count > 0:
        scorecard_state = "RECALIBRATION_PROOF_MATURING"
    else:
        scorecard_state = "MONITOR"

    if invalid_count > 0:
        override_gate = "HOLD_INTEGRITY"
    elif eligible.empty:
        override_gate = "HOLD_EVIDENCE"
    elif latest_eval == "ASSUMPTION_DRIFT_REVIEW":
        override_gate = "HOLD_ASSUMPTION_DRIFT"
    elif proof_clock_count < proof_target:
        override_gate = "HOLD_PROOF_CLOCK"
    elif (
        error_regime in {
            "MODEL_BREAK",
            "PERSISTENT_OPTIMISTIC_BIAS",
        }
        and latest_capacity_state
        == "REVIEW_CONSTRAINT_AFTER_RECALIBRATION"
    ):
        override_gate = "OPEN_FOR_HUMAN_REVIEW"
    elif proof_clock_count >= proof_target:
        override_gate = "RECALIBRATE_FIRST"
    else:
        override_gate = "NO_OVERRIDE_EVIDENCE"

    latest_evidence = _int(latest.get("evidence_intervals"))
    if override_gate == "OPEN_FOR_HUMAN_REVIEW":
        approval_state = "HUMAN_APPROVAL_REQUIRED"
        review_ttl = ttl
        expires_after = latest_evidence + ttl
    else:
        approval_state = "NOT_APPLICABLE"
        review_ttl = 0
        expires_after = None

    snapshot_eligible = (
        invalid_count == 0
        and len(latest_hist) > 0
    )

    return {
        "source_projection_snapshot_id": source_projection_id,
        "outcome_snapshots_total": int(len(valid)),
        "unique_evidence_endpoints": int(len(latest_hist)),
        "eligible_outcomes": int(len(eligible)),
        "invalid_outcome_count": invalid_count,
        "proof_clock_count": proof_clock_count,
        "proof_clock_target": proof_target,
        "proof_clock_state": proof_clock_state,
        "error_regime": error_regime,
        "scorecard_state": scorecard_state,
        "latest_evaluation_state": latest_eval,
        "latest_recalibration_state": latest_recal,
        "latest_capacity_decision_state": latest_capacity_state,
        "avg_abs_pct_error": avg_abs_error,
        "latest_abs_pct_error": latest_abs_error,
        "latest_signed_burn_error": latest_signed_error,
        "latest_realized_avg_burn": latest_realized,
        "base_burn_rate": base_burn,
        "latest_current_groups": _int(latest.get("current_groups")),
        "latest_attention_groups": _int(latest.get("attention_groups")),
        "latest_capacity": _int(latest.get("capacity")),
        "latest_evidence_intervals": latest_evidence,
        "capacity_override_review_gate": override_gate,
        "override_review_approval_state": approval_state,
        "override_review_ttl_intervals": review_ttl,
        "override_review_expires_after_evidence": expires_after,
        "scorecard_table": table_view,
        "snapshot_eligible": snapshot_eligible,
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "capacity_override_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def build_flow_projection_scorecard_queue(
    scorecard: dict | None,
) -> pd.DataFrame:
    sc = scorecard or {}
    state = _text(sc.get("scorecard_state")).upper()
    regime = _text(sc.get("error_regime")).upper()
    gate = _text(sc.get("capacity_override_review_gate")).upper()

    rows = []

    if state == "SCORECARD_HISTORY_REQUIRED":
        rows.append(
            {
                "priority": "PS1",
                "status": "WAIT",
                "issue": "PROJECTION_OUTCOME_HISTORY_REQUIRED",
                "detail": "저장된 Projection Outcome Snapshot 없음",
                "next_action": (
                    "History/Projection Guard를 강제로 열지 말고 실제 evidence가 생성된 뒤 Outcome Snapshot 축적"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "OUTCOME_INTEGRITY_REVIEW":
        rows.append(
            {
                "priority": "PS0",
                "status": "BLOCKED",
                "issue": "PROJECTION_SCORECARD_OUTCOME_INTEGRITY",
                "detail": (
                    f"invalid outcome snapshots "
                    f"{_int(sc.get('invalid_outcome_count'))}"
                ),
                "next_action": "Outcome Snapshot lineage/hash 복구 후 Scorecard 재평가",
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "SCORECARD_EVIDENCE_MATURING":
        rows.append(
            {
                "priority": "PS1",
                "status": "WAIT",
                "issue": "PROJECTION_SCORECARD_EVIDENCE_MATURING",
                "detail": (
                    f"eligible outcomes {_int(sc.get('eligible_outcomes'))}"
                ),
                "next_action": "실제 post-projection evidence와 Outcome Snapshot을 추가 축적",
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "REBASE_REQUIRED":
        rows.append(
            {
                "priority": "PS0",
                "status": "REVIEW",
                "issue": "PROJECTION_SCORECARD_REBASE_REQUIRED",
                "detail": "Capacity assumption drift가 model error보다 우선",
                "next_action": "새 Calibration/Projection으로 rebase 후 새로운 evidence clock 시작",
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "RECALIBRATION_PROOF_MATURING":
        rows.append(
            {
                "priority": "PS1",
                "status": "REVIEW",
                "issue": "RECALIBRATION_PROOF_CLOCK_MATURING",
                "detail": (
                    f"proof clock {sc.get('proof_clock_count',0)}/"
                    f"{sc.get('proof_clock_target',0)}"
                ),
                "next_action": "중복 저장으로 Clock을 늘리지 말고 새로운 evidence endpoint를 기다림",
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "RECALIBRATION_PROOF_MET":
        rows.append(
            {
                "priority": "PS0",
                "status": "REVIEW",
                "issue": "RECALIBRATION_PROOF_MET",
                "detail": (
                    f"{regime} · proof clock "
                    f"{sc.get('proof_clock_count',0)}/"
                    f"{sc.get('proof_clock_target',0)}"
                ),
                "next_action": "Model/Parameter/Execution/Exogenous 원인 분해 후 Recalibration 검토",
                "go_to": "Operations Control Tower",
            }
        )

    if gate == "OPEN_FOR_HUMAN_REVIEW":
        rows.append(
            {
                "priority": "PS0",
                "status": "REVIEW",
                "issue": "CAPACITY_OVERRIDE_REVIEW_GATE_OPEN",
                "detail": (
                    f"Human approval required · expires after evidence "
                    f"{sc.get('override_review_expires_after_evidence')}"
                ),
                "next_action": (
                    "Recalibration 완료 전 Capacity 변경 금지. "
                    "승인하더라도 별도 Override 승인·만료·범위 제한 필요"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif gate == "RECALIBRATE_FIRST":
        rows.append(
            {
                "priority": "PS1",
                "status": "HOLD",
                "issue": "CAPACITY_OVERRIDE_RECALIBRATE_FIRST",
                "detail": regime,
                "next_action": "Capacity 변경보다 Recalibration을 먼저 수행",
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        rows.append(
            {
                "priority": "PS2",
                "status": "MONITOR",
                "issue": "PROJECTION_SCORECARD_MONITOR",
                "detail": f"{state} · {regime} · {gate}",
                "next_action": "추가 evidence를 축적하며 자동 Capacity 변경 없이 모니터링",
                "go_to": "Operations Control Tower",
            }
        )

    order = {"PS0": 0, "PS1": 1, "PS2": 2}
    out = pd.DataFrame(rows, columns=PROJECTION_SCORECARD_QUEUE_COLS)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(["_p", "issue"])
        .drop(columns=["_p"])
        .reset_index(drop=True)
    )


def _snapshot_payload(scorecard: dict) -> dict:
    return {
        "source_projection_snapshot_id":
            _text(scorecard.get("source_projection_snapshot_id")),
        "outcome_snapshots_total":
            _int(scorecard.get("outcome_snapshots_total")),
        "unique_evidence_endpoints":
            _int(scorecard.get("unique_evidence_endpoints")),
        "eligible_outcomes":
            _int(scorecard.get("eligible_outcomes")),
        "invalid_outcome_count":
            _int(scorecard.get("invalid_outcome_count")),
        "proof_clock_count":
            _int(scorecard.get("proof_clock_count")),
        "proof_clock_target":
            _int(scorecard.get("proof_clock_target")),
        "proof_clock_state":
            _text(scorecard.get("proof_clock_state")),
        "error_regime":
            _text(scorecard.get("error_regime")),
        "scorecard_state":
            _text(scorecard.get("scorecard_state")),
        "latest_evaluation_state":
            _text(scorecard.get("latest_evaluation_state")),
        "latest_recalibration_state":
            _text(scorecard.get("latest_recalibration_state")),
        "latest_capacity_decision_state":
            _text(scorecard.get("latest_capacity_decision_state")),
        "avg_abs_pct_error":
            _round_optional(scorecard.get("avg_abs_pct_error")),
        "latest_abs_pct_error":
            _round_optional(scorecard.get("latest_abs_pct_error")),
        "latest_signed_burn_error":
            _round_optional(scorecard.get("latest_signed_burn_error")),
        "latest_realized_avg_burn":
            _round_optional(scorecard.get("latest_realized_avg_burn")),
        "base_burn_rate":
            _round_optional(scorecard.get("base_burn_rate")),
        "latest_current_groups":
            _int(scorecard.get("latest_current_groups")),
        "latest_attention_groups":
            _int(scorecard.get("latest_attention_groups")),
        "latest_capacity":
            _int(scorecard.get("latest_capacity")),
        "latest_evidence_intervals":
            _int(scorecard.get("latest_evidence_intervals")),
        "capacity_override_review_gate":
            _text(scorecard.get("capacity_override_review_gate")),
        "override_review_approval_state":
            _text(scorecard.get("override_review_approval_state")),
        "override_review_ttl_intervals":
            _int(scorecard.get("override_review_ttl_intervals")),
        "override_review_expires_after_evidence":
            (
                None
                if scorecard.get("override_review_expires_after_evidence") is None
                else _int(scorecard.get("override_review_expires_after_evidence"))
            ),
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "capacity_override_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def build_flow_projection_scorecard_snapshot(
    scorecard: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    if not bool(scorecard.get("snapshot_eligible")):
        raise ValueError(
            "Scorecard Snapshot은 integrity OK인 Outcome history가 1개 이상 필요합니다."
        )

    now = _text(created_at) or datetime.now().astimezone().isoformat()
    payload = _snapshot_payload(scorecard)
    snapshot_hash = _hash(payload)

    return {
        "scorecard_snapshot_id": (
            "FSC-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **payload,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_projection_scorecard_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "expected_hash": "",
            "actual_hash": "",
        }

    item = row.to_dict() if isinstance(row, pd.Series) else dict(row)
    actual = _text(item.get("snapshot_hash"))
    expected = _hash(_snapshot_payload(item))

    return {
        "status": (
            "OK"
            if actual and actual == expected
            else "MISMATCH"
        ),
        "expected_hash": expected,
        "actual_hash": actual,
    }


def latest_flow_projection_scorecard_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()
    if df.empty:
        return {}

    for col in FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    created = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[created.notna()].copy()
    if valid.empty:
        return {}

    valid["_created"] = created.loc[valid.index]
    row = (
        valid.sort_values("_created")
        .iloc[-1]
        .drop(labels=["_created"])
    )
    return row.to_dict()
