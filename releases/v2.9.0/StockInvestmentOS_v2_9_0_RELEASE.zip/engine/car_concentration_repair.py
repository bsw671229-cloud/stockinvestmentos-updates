from __future__ import annotations

from datetime import datetime
import json
from typing import Any

import pandas as pd


CAR_REPAIR_REVIEW_COLS = [
    "reviewed_at",
    "policy_cap",
    "current_direct_bear_loss",
    "current_top_car_share",
    "current_top_name",
    "post_direct_bear_loss",
    "post_top_car_share",
    "post_top_name",
    "total_trim_krw",
    "total_trim_weight",
    "cash_increase_krw",
    "donor_count",
    "repair_status",
    "liquidity_gate",
    "reconciliation_gate",
    "template",
    "plan_json",
    "note",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def direct_car_contributions(
    portfolio: pd.DataFrame | None,
    total_assets: float,
) -> pd.DataFrame:
    """
    Direct Bear Capital-at-Risk contribution table.

    CAR weight = position weight × plausible downside.
    Cash has zero CAR and is excluded from concentration shares.
    """
    cols = [
        "name",
        "ticker",
        "asset_type",
        "current_value_krw",
        "weight",
        "bear_downside",
        "car_weight",
        "direct_car_share",
    ]
    if portfolio is None or portfolio.empty:
        return pd.DataFrame(columns=cols)

    total = max(0.0, float(total_assets or 0.0))
    if total <= 0:
        return pd.DataFrame(columns=cols)

    p = portfolio.copy()
    for col in [
        "name",
        "ticker",
        "asset_type",
        "current_value_krw",
        "bear_downside",
    ]:
        if col not in p.columns:
            p[col] = ""

    p["name"] = p["name"].map(_text)
    p["ticker"] = p["ticker"].map(_text)
    p["asset_type"] = (
        p["asset_type"]
        .fillna("")
        .astype(str)
        .str.lower()
    )
    p["current_value_krw"] = pd.to_numeric(
        p["current_value_krw"],
        errors="coerce",
    ).fillna(0.0).clip(lower=0.0)
    p["bear_downside"] = pd.to_numeric(
        p["bear_downside"],
        errors="coerce",
    ).fillna(0.0).clip(lower=0.0, upper=1.0)

    cash_mask = (
        p["asset_type"].eq("cash")
        | p["name"].str.lower().isin(["cash", "현금"])
    )

    p = p.loc[~cash_mask].copy()
    if p.empty:
        return pd.DataFrame(columns=cols)

    p["weight"] = p["current_value_krw"] / total
    p["car_weight"] = (
        p["weight"]
        * p["bear_downside"]
    )

    total_car = float(
        p["car_weight"].sum()
    )
    p["direct_car_share"] = (
        p["car_weight"] / total_car
        if total_car > 0
        else 0.0
    )

    return (
        p[cols]
        .sort_values(
            ["direct_car_share", "current_value_krw"],
            ascending=[False, False],
        )
        .reset_index(drop=True)
    )


def car_concentration_state(
    contributions: pd.DataFrame | None,
    *,
    top_share_cap: float = 0.50,
) -> dict:
    if contributions is None or contributions.empty:
        return {
            "status": "PASS",
            "direct_bear_loss": 0.0,
            "top_car_share": 0.0,
            "top_name": "",
            "risk_hhi": 0.0,
            "breach_count": 0,
            "positive_risk_assets": 0,
        }

    df = contributions.copy()
    car = pd.to_numeric(
        df.get("car_weight"),
        errors="coerce",
    ).fillna(0.0).clip(lower=0.0)

    total_car = float(car.sum())
    if total_car <= 0:
        return {
            "status": "PASS",
            "direct_bear_loss": 0.0,
            "top_car_share": 0.0,
            "top_name": "",
            "risk_hhi": 0.0,
            "breach_count": 0,
            "positive_risk_assets": 0,
        }

    shares = car / total_car
    top_idx = shares.idxmax()
    top_share = float(shares.loc[top_idx])
    top_name = _text(
        df.loc[top_idx].get("name")
    )

    cap = max(0.0, min(1.0, float(top_share_cap)))
    breach_count = int(
        shares.gt(cap + 1e-12).sum()
    )
    hhi = float(
        (shares ** 2).sum()
    )

    return {
        "status": (
            "PASS"
            if breach_count == 0
            else "PRE_EXISTING_BREACH"
        ),
        "direct_bear_loss": total_car,
        "top_car_share": top_share,
        "top_name": top_name,
        "risk_hhi": hhi,
        "breach_count": breach_count,
        "positive_risk_assets": int(
            car.gt(0).sum()
        ),
    }


def _largest_feasible_final_car(
    car_values: list[float],
    cap: float,
) -> float:
    """
    Maximize final total CAR S' subject to x_i <= a_i and x_i <= cap*S'.

    This is a mathematical concentration-repair benchmark, not an execution
    recommendation.
    """
    vals = [
        max(0.0, float(x))
        for x in car_values
    ]
    total = sum(vals)
    if total <= 0:
        return 0.0

    cap = max(0.0, min(1.0, float(cap)))
    if cap >= 1.0:
        return total
    if cap <= 0.0:
        return 0.0

    def feasible(s: float) -> bool:
        capacity = sum(
            min(a, cap * s)
            for a in vals
        )
        return capacity + 1e-15 >= s

    # If current total is already feasible, no repair required.
    if feasible(total):
        return total

    lo = 0.0
    hi = total
    for _ in range(120):
        mid = (lo + hi) / 2.0
        if feasible(mid):
            lo = mid
        else:
            hi = mid

    return lo


def minimum_car_concentration_repair(
    contributions: pd.DataFrame | None,
    total_assets: float,
    *,
    top_share_cap: float = 0.50,
) -> dict:
    """
    Mathematical lower-bound repair benchmark.

    It trims CAR contributors to Cash until all remaining direct CAR shares
    are <= policy cap, while maximizing remaining total CAR.

    It ignores thesis, valuation, taxes, liquidity and execution constraints.
    """
    if contributions is None or contributions.empty:
        return {
            "status": "NO_RISK",
            "plan": pd.DataFrame(),
            "current_state": car_concentration_state(
                contributions,
                top_share_cap=top_share_cap,
            ),
            "post_state": car_concentration_state(
                contributions,
                top_share_cap=top_share_cap,
            ),
            "total_trim_krw": 0.0,
            "total_trim_weight": 0.0,
            "cash_increase_krw": 0.0,
            "donor_count": 0,
            "detail": "Direct CAR contributor가 없습니다.",
        }

    total = max(0.0, float(total_assets or 0.0))
    cap = max(0.0, min(1.0, float(top_share_cap)))

    df = contributions.copy()
    for col in [
        "current_value_krw",
        "bear_downside",
        "car_weight",
    ]:
        df[col] = pd.to_numeric(
            df[col],
            errors="coerce",
        ).fillna(0.0).clip(lower=0.0)

    current_state = car_concentration_state(
        df,
        top_share_cap=cap,
    )

    car_values = df["car_weight"].tolist()
    final_total_car = _largest_feasible_final_car(
        car_values,
        cap,
    )

    if current_state["status"] == "PASS":
        target_car = df["car_weight"].copy()
    elif final_total_car <= 1e-15:
        target_car = pd.Series(
            0.0,
            index=df.index,
        )
    else:
        target_car = df["car_weight"].map(
            lambda x: min(
                float(x),
                cap * final_total_car,
            )
        )

    trim_car = (
        df["car_weight"]
        - target_car
    ).clip(lower=0.0)

    trim_amounts = []
    for i, row in df.iterrows():
        downside = float(
            row["bear_downside"]
        )
        current_value = float(
            row["current_value_krw"]
        )
        car_reduction = float(
            trim_car.loc[i]
        )

        if (
            car_reduction <= 0
            or downside <= 0
            or total <= 0
        ):
            trim_value = 0.0
        else:
            trim_value = (
                car_reduction
                * total
                / downside
            )
            trim_value = min(
                current_value,
                max(
                    0.0,
                    trim_value,
                ),
            )

        trim_amounts.append(
            trim_value
        )

    plan = df[
        [
            "name",
            "ticker",
            "current_value_krw",
            "weight",
            "bear_downside",
            "car_weight",
            "direct_car_share",
        ]
    ].copy()

    plan["target_car_weight"] = target_car.values
    plan["trim_car_weight"] = trim_car.values
    plan["trim_amount_krw"] = trim_amounts
    plan["post_value_krw"] = (
        plan["current_value_krw"]
        - plan["trim_amount_krw"]
    ).clip(lower=0.0)
    plan["post_car_weight"] = (
        plan["post_value_krw"]
        / total
        * plan["bear_downside"]
        if total > 0
        else 0.0
    )

    post_total_car = float(
        plan["post_car_weight"].sum()
    )
    plan["post_car_share"] = (
        plan["post_car_weight"]
        / post_total_car
        if post_total_car > 0
        else 0.0
    )
    plan["trim_pct_of_position"] = (
        plan["trim_amount_krw"]
        / plan["current_value_krw"].replace(
            0.0,
            pd.NA,
        )
    ).fillna(0.0)

    post_contrib = plan[
        [
            "name",
            "ticker",
            "current_value_krw",
            "weight",
            "bear_downside",
            "post_car_weight",
            "post_car_share",
        ]
    ].copy()
    post_contrib = post_contrib.rename(
        columns={
            "post_car_weight": "car_weight",
            "post_car_share": "direct_car_share",
        }
    )
    post_contrib["current_value_krw"] = plan[
        "post_value_krw"
    ].values
    post_contrib["weight"] = (
        post_contrib["current_value_krw"]
        / total
        if total > 0
        else 0.0
    )

    post_state = car_concentration_state(
        post_contrib,
        top_share_cap=cap,
    )

    total_trim = float(
        plan["trim_amount_krw"].sum()
    )
    donor_count = int(
        plan["trim_amount_krw"]
        .gt(1e-9)
        .sum()
    )

    if current_state["status"] == "PASS":
        status = "NO_REPAIR_REQUIRED"
        detail = "현재 Top CAR Share가 policy cap 이내입니다."
    elif post_total_car <= 1e-15:
        status = "FULL_RISK_EXIT_BOUNDARY"
        detail = (
            "이 policy cap에서는 양(+)의 Direct CAR를 유지한 채 "
            "모든 CAR Share를 cap 이내로 만드는 해가 없습니다."
        )
    elif post_state["status"] == "PASS":
        status = "CAP_RESTORED"
        detail = (
            "수학적 lower-bound 기준으로 Top CAR Share cap이 복구됩니다. "
            "실행 전 Thesis/Valuation/Tax/Liquidity 검토가 필요합니다."
        )
    else:
        status = "REVIEW"
        detail = "수학적 benchmark가 cap을 완전히 복구하지 못했습니다."

    return {
        "status": status,
        "plan": plan,
        "current_state": current_state,
        "post_state": post_state,
        "total_trim_krw": total_trim,
        "total_trim_weight": (
            total_trim / total
            if total > 0
            else 0.0
        ),
        "cash_increase_krw": total_trim,
        "donor_count": donor_count,
        "detail": detail,
    }


def simulate_car_concentration_repair(
    portfolio: pd.DataFrame | None,
    total_assets: float,
    trim_plan: pd.DataFrame | None,
    *,
    top_share_cap: float = 0.50,
) -> dict:
    """
    User-edited CAR concentration repair simulation.

    All trim proceeds are assumed to move to Cash.
    """
    total = max(
        0.0,
        float(total_assets or 0.0),
    )
    contrib = direct_car_contributions(
        portfolio,
        total,
    )
    current_state = car_concentration_state(
        contrib,
        top_share_cap=top_share_cap,
    )

    if contrib.empty:
        return {
            "repair_status": "NO_RISK",
            "current_state": current_state,
            "post_state": current_state,
            "effective_plan": pd.DataFrame(),
            "total_trim_krw": 0.0,
            "total_trim_weight": 0.0,
            "cash_increase_krw": 0.0,
            "car_reduction": 0.0,
            "issues": [],
        }

    plan = contrib.copy()
    plan["requested_trim_krw"] = 0.0

    if trim_plan is not None and not trim_plan.empty:
        tp = trim_plan.copy()
        for col in [
            "name",
            "ticker",
            "trim_amount_krw",
        ]:
            if col not in tp.columns:
                tp[col] = ""

        tp["name"] = tp["name"].map(_text)
        tp["ticker"] = tp["ticker"].map(_text)
        tp["trim_amount_krw"] = pd.to_numeric(
            tp["trim_amount_krw"],
            errors="coerce",
        ).fillna(0.0).clip(lower=0.0)

        lookup = {}
        for _, row in tp.iterrows():
            key = (
                _text(row.get("name")),
                _text(row.get("ticker")),
            )
            lookup[key] = lookup.get(
                key,
                0.0,
            ) + float(
                row["trim_amount_krw"]
            )

        for i, row in plan.iterrows():
            key = (
                _text(row.get("name")),
                _text(row.get("ticker")),
            )
            plan.loc[
                i,
                "requested_trim_krw",
            ] = float(
                lookup.get(
                    key,
                    0.0,
                )
            )

    issues = []
    plan["effective_trim_krw"] = plan[
        [
            "requested_trim_krw",
            "current_value_krw",
        ]
    ].min(axis=1)

    over = (
        plan["requested_trim_krw"]
        - plan["current_value_krw"]
    ).gt(1e-9)
    if over.any():
        issues.append(
            "TRIM_CLAMPED_TO_CURRENT_VALUE"
        )

    plan["post_value_krw"] = (
        plan["current_value_krw"]
        - plan["effective_trim_krw"]
    ).clip(lower=0.0)
    plan["post_weight"] = (
        plan["post_value_krw"]
        / total
        if total > 0
        else 0.0
    )
    plan["post_car_weight"] = (
        plan["post_weight"]
        * plan["bear_downside"]
    )

    post_total_car = float(
        plan["post_car_weight"].sum()
    )
    plan["post_car_share"] = (
        plan["post_car_weight"]
        / post_total_car
        if post_total_car > 0
        else 0.0
    )
    plan["trim_pct_of_position"] = (
        plan["effective_trim_krw"]
        / plan["current_value_krw"].replace(
            0.0,
            pd.NA,
        )
    ).fillna(0.0)

    post_contrib = pd.DataFrame(
        {
            "name": plan["name"],
            "ticker": plan["ticker"],
            "asset_type": plan["asset_type"],
            "current_value_krw": plan["post_value_krw"],
            "weight": plan["post_weight"],
            "bear_downside": plan["bear_downside"],
            "car_weight": plan["post_car_weight"],
            "direct_car_share": plan["post_car_share"],
        }
    )

    post_state = car_concentration_state(
        post_contrib,
        top_share_cap=top_share_cap,
    )

    total_trim = float(
        plan["effective_trim_krw"].sum()
    )
    car_reduction = max(
        0.0,
        float(
            current_state["direct_bear_loss"]
            - post_state["direct_bear_loss"]
        ),
    )

    if (
        current_state["status"] == "PASS"
        and total_trim <= 1e-9
    ):
        repair_status = "NO_REPAIR_REQUIRED"
    elif post_state["status"] == "PASS":
        repair_status = "CAP_RESTORED"
    elif total_trim <= 1e-9:
        repair_status = "NO_CHANGE"
    else:
        repair_status = "PARTIAL_REPAIR"

    return {
        "repair_status": repair_status,
        "current_state": current_state,
        "post_state": post_state,
        "effective_plan": plan,
        "total_trim_krw": total_trim,
        "total_trim_weight": (
            total_trim / total
            if total > 0
            else 0.0
        ),
        "cash_increase_krw": total_trim,
        "car_reduction": car_reduction,
        "issues": issues,
    }


def car_repair_review_row(
    simulation: dict,
    *,
    policy_cap: float,
    liquidity_gate: str,
    reconciliation_gate: str,
    template: str,
    note: str = "",
) -> dict:
    plan = simulation.get(
        "effective_plan",
        pd.DataFrame(),
    )
    plan_json = "[]"

    if isinstance(
        plan,
        pd.DataFrame,
    ) and not plan.empty:
        cols = [
            c
            for c in [
                "name",
                "ticker",
                "current_value_krw",
                "effective_trim_krw",
                "post_value_krw",
                "bear_downside",
                "car_weight",
                "post_car_weight",
                "direct_car_share",
                "post_car_share",
            ]
            if c in plan.columns
        ]
        plan_json = json.dumps(
            plan[cols].to_dict(
                orient="records"
            ),
            ensure_ascii=False,
            default=str,
        )

    current = simulation.get(
        "current_state",
        {},
    )
    post = simulation.get(
        "post_state",
        {},
    )

    return {
        "reviewed_at": datetime.now().isoformat(),
        "policy_cap": float(
            policy_cap
        ),
        "current_direct_bear_loss": float(
            current.get(
                "direct_bear_loss",
                0.0,
            )
            or 0.0
        ),
        "current_top_car_share": float(
            current.get(
                "top_car_share",
                0.0,
            )
            or 0.0
        ),
        "current_top_name": _text(
            current.get(
                "top_name",
                "",
            )
        ),
        "post_direct_bear_loss": float(
            post.get(
                "direct_bear_loss",
                0.0,
            )
            or 0.0
        ),
        "post_top_car_share": float(
            post.get(
                "top_car_share",
                0.0,
            )
            or 0.0
        ),
        "post_top_name": _text(
            post.get(
                "top_name",
                "",
            )
        ),
        "total_trim_krw": float(
            simulation.get(
                "total_trim_krw",
                0.0,
            )
            or 0.0
        ),
        "total_trim_weight": float(
            simulation.get(
                "total_trim_weight",
                0.0,
            )
            or 0.0
        ),
        "cash_increase_krw": float(
            simulation.get(
                "cash_increase_krw",
                0.0,
            )
            or 0.0
        ),
        "donor_count": int(
            (
                plan.get(
                    "effective_trim_krw",
                    pd.Series(dtype=float),
                )
                .fillna(0.0)
                .gt(1e-9)
            ).sum()
        )
        if isinstance(
            plan,
            pd.DataFrame,
        )
        else 0,
        "repair_status": _text(
            simulation.get(
                "repair_status",
                "",
            )
        ),
        "liquidity_gate": _text(
            liquidity_gate
        ),
        "reconciliation_gate": _text(
            reconciliation_gate
        ),
        "template": _text(
            template
        ),
        "plan_json": plan_json,
        "note": _text(note),
    }


def benchmark_fraction_ladder(
    portfolio: pd.DataFrame | None,
    total_assets: float,
    benchmark_plan: pd.DataFrame | None,
    *,
    top_share_cap: float = 0.50,
    fractions: tuple[float, ...] = (
        0.0,
        0.25,
        0.50,
        0.75,
        1.00,
    ),
) -> pd.DataFrame:
    """
    Scale every positive benchmark trim by the same fraction.

    This is a diagnostic path from "no repair" to the mathematical benchmark.
    It is not a recommendation.
    """
    if benchmark_plan is None or benchmark_plan.empty:
        return pd.DataFrame()

    base = benchmark_plan.copy()
    if "trim_amount_krw" not in base.columns:
        return pd.DataFrame()

    rows = []
    for frac in fractions:
        f = max(0.0, min(1.0, float(frac)))

        scaled = base[
            ["name", "ticker", "trim_amount_krw"]
        ].copy()
        scaled["trim_amount_krw"] = (
            pd.to_numeric(
                scaled["trim_amount_krw"],
                errors="coerce",
            )
            .fillna(0.0)
            * f
        )

        sim = simulate_car_concentration_repair(
            portfolio,
            total_assets,
            scaled,
            top_share_cap=top_share_cap,
        )

        rows.append(
            {
                "benchmark_fraction": f,
                "total_trim_krw": sim["total_trim_krw"],
                "total_trim_weight": sim["total_trim_weight"],
                "post_direct_bear_loss": sim["post_state"]["direct_bear_loss"],
                "car_reduction": sim["car_reduction"],
                "post_top_car_share": sim["post_state"]["top_car_share"],
                "post_top_name": sim["post_state"]["top_name"],
                "repair_status": sim["repair_status"],
            }
        )

    return pd.DataFrame(rows)


def whole_quantity_trim_ladder(
    portfolio: pd.DataFrame | None,
    total_assets: float,
    target_name: str,
    *,
    top_share_cap: float = 0.50,
    max_rows: int = 60,
) -> pd.DataFrame:
    """
    Quantity-step execution reality based on current recorded quantity.

    For integer-like positions, enumerate whole quantity steps.
    For large quantities, sample the range while preserving the neighborhood
    around the continuous benchmark crossing.

    This is a diagnostic. Brokerage lot rules/fractional-trading support are
    not inferred.
    """
    if portfolio is None or portfolio.empty:
        return pd.DataFrame()

    p = portfolio.copy()
    for col in [
        "name",
        "ticker",
        "quantity",
        "current_value_krw",
    ]:
        if col not in p.columns:
            p[col] = ""

    hit = p.loc[
        p["name"].map(_text).eq(_text(target_name))
    ].copy()
    if hit.empty:
        return pd.DataFrame()

    row = hit.iloc[0].to_dict()
    quantity = _num(row.get("quantity"))
    current_value = _num(row.get("current_value_krw"))
    ticker = _text(row.get("ticker"))

    if (
        quantity is None
        or quantity <= 0
        or current_value is None
        or current_value <= 0
    ):
        return pd.DataFrame()

    whole_quantity = int(quantity)
    if abs(quantity - whole_quantity) > 1e-9:
        return pd.DataFrame()

    unit_value = current_value / whole_quantity
    if unit_value <= 0:
        return pd.DataFrame()

    contrib = direct_car_contributions(
        portfolio,
        total_assets,
    )
    benchmark = minimum_car_concentration_repair(
        contrib,
        total_assets,
        top_share_cap=top_share_cap,
    )
    benchmark_plan = benchmark.get(
        "plan",
        pd.DataFrame(),
    )

    continuous_trim = None
    if (
        isinstance(benchmark_plan, pd.DataFrame)
        and not benchmark_plan.empty
    ):
        bhit = benchmark_plan.loc[
            benchmark_plan["name"]
            .map(_text)
            .eq(_text(target_name))
        ]
        if not bhit.empty:
            continuous_trim = _num(
                bhit.iloc[0].get("trim_amount_krw")
            )

    steps = list(range(whole_quantity + 1))

    if len(steps) > int(max_rows):
        sampled = {0, whole_quantity}

        for frac in [
            0.10,
            0.25,
            0.50,
            0.75,
            0.90,
        ]:
            sampled.add(
                max(
                    0,
                    min(
                        whole_quantity,
                        int(round(whole_quantity * frac)),
                    ),
                )
            )

        if continuous_trim is not None:
            qstar = continuous_trim / unit_value
            center = int(qstar)
            for q in range(
                max(0, center - 3),
                min(whole_quantity, center + 4) + 1,
            ):
                sampled.add(q)

        steps = sorted(sampled)

    rows = []
    for trim_quantity in steps:
        trim_amount = trim_quantity * unit_value

        sim = simulate_car_concentration_repair(
            portfolio,
            total_assets,
            pd.DataFrame(
                [
                    {
                        "name": _text(target_name),
                        "ticker": ticker,
                        "trim_amount_krw": trim_amount,
                    }
                ]
            ),
            top_share_cap=top_share_cap,
        )

        rows.append(
            {
                "name": _text(target_name),
                "ticker": ticker,
                "current_quantity": whole_quantity,
                "unit_value_proxy_krw": unit_value,
                "trim_quantity": trim_quantity,
                "trim_amount_krw": trim_amount,
                "remaining_quantity": whole_quantity - trim_quantity,
                "post_direct_bear_loss": sim["post_state"]["direct_bear_loss"],
                "post_top_car_share": sim["post_state"]["top_car_share"],
                "post_top_name": sim["post_state"]["top_name"],
                "repair_status": sim["repair_status"],
                "within_policy_cap": (
                    sim["post_state"]["status"] == "PASS"
                ),
            }
        )

    return pd.DataFrame(rows)
