from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_permanent_change_design import (
    FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    permanent_change_design_snapshot_integrity,
)
from engine.operations_flow_permanent_change_apply import (
    FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    PERMANENT_CHANGE_APPLY_STATES,
    PERMANENT_CHANGE_APPLY_GUARD_BY_STATE,
    build_flow_permanent_change_apply,
    permanent_change_apply_snapshot_integrity,
    latest_permanent_change_apply_snapshot,
)


PERMANENT_CHANGE_APPLY_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

PERMANENT_CHANGE_APPLY_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V152_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


V151_RELEASE_ZIP_SHA256 = (
    "69ed8737b3e690d228d3efcd74638b76b4f19b87d11bd65a017c0ec9f486fb40"
)

V151_RELEASE_MANIFEST_FILE_SHA256 = (
    "bea218d939c5f838b47a1c2fc5356893f40037a9a14e7da69638cdf3d7dd86cd"
)

V151_RELEASE_NOTES_FILE_SHA256 = (
    "fc10c62c2fac5eb7cf228fc386c71ff076f8da9dccca17fa6252e1ae142df72d"
)

V151_BASELINE_PROVENANCE_REL = "release_baselines/v1_51_0.json"


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass

    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = (
        pd.DataFrame()
        if df is None
        else df.copy()
    )

    for col in cols:
        if col not in out.columns:
            out[col] = ""

    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1

        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def _sha256_path(
    path: Path,
) -> str:
    h = hashlib.sha256()

    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b"",
        ):
            h.update(chunk)

    return h.hexdigest()


def verify_v151_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(code_root).resolve()
    provenance_path = (
        root
        / V151_BASELINE_PROVENANCE_REL
    )

    record = {}
    record_ok = False
    record_detail = ""

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            record_detail = (
                f"{type(exc).__name__}: {exc}"
            )
        else:
            record_ok = (
                _text(
                    record.get("release_version")
                )
                == "v1.51.0"
                and _text(
                    record.get("release_zip_sha256")
                ).lower()
                == V151_RELEASE_ZIP_SHA256
                and _text(
                    record.get("manifest_file_sha256")
                ).lower()
                == V151_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get("release_notes_file_sha256")
                ).lower()
                == V151_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get("provenance_status")
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )

            record_detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    manifest_path = (
        root
        / "manifest_sha256.json"
    )

    notes_path = (
        root
        / "RELEASE_NOTES_v1_51_0.txt"
    )

    original_manifest_ok = (
        manifest_path.is_file()
        and _sha256_path(manifest_path)
        == V151_RELEASE_MANIFEST_FILE_SHA256
    )

    original_notes_ok = (
        notes_path.is_file()
        and _sha256_path(notes_path)
        == V151_RELEASE_NOTES_FILE_SHA256
    )

    original_artifacts_ok = (
        original_manifest_ok
        and original_notes_ok
    )

    verified = (
        record_ok
        or original_artifacts_ok
    )

    source = (
        "PROVENANCE_RECORD"
        if record_ok
        else (
            "ORIGINAL_V151_RELEASE_ARTIFACTS"
            if original_artifacts_ok
            else "NONE"
        )
    )

    return {
        "status": (
            "VERIFIED"
            if verified
            else "BLOCKED"
        ),
        "verified": verified,
        "source": source,
        "record_path": str(provenance_path),
        "record_detail": record_detail,
        "release_version": "v1.51.0",
        "release_zip_sha256":
            V151_RELEASE_ZIP_SHA256,
        "manifest_file_sha256":
            V151_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256":
            V151_RELEASE_NOTES_FILE_SHA256,
        "original_manifest_match":
            original_manifest_ok,
        "original_release_notes_match":
            original_notes_ok,
    }


def build_v152_permanent_change_apply_context(
    *,
    v151_context: dict | None,
    permanent_change_apply_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v151_context or {}
    design = upstream.get("design") or {}

    design_df = _ensure_cols(
        upstream.get(
            "permanent_change_design_snapshots"
        ),
        FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    apply_df = _ensure_cols(
        permanent_change_apply_snapshots,
        FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    apply = build_flow_permanent_change_apply(
        design,
        design_df,
        apply_df,
    )

    latest_apply = latest_permanent_change_apply_snapshot(
        apply_df
    )

    latest_integrity = (
        _text(
            permanent_change_apply_snapshot_integrity(
                latest_apply
            ).get("status")
        ).upper()
        if latest_apply
        else "NONE"
    )

    return {
        "v151_context": upstream,
        "design": design,
        "permanent_change_design_snapshots": design_df,
        "permanent_change_apply_snapshots": apply_df,
        "apply": apply,
        "apply_integrity": _integrity_counts(
            apply_df,
            permanent_change_apply_snapshot_integrity,
        ),
        "latest_apply": latest_apply,
        "latest_apply_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail": detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def _design_routing_ok(
    apply: dict,
    design: dict,
) -> bool:
    state = _text(
        apply.get("apply_state")
    ).upper()

    design_state = _text(
        design.get("design_state")
    ).upper()

    if design_state == "PERMANENT_CHANGE_DESIGN_NOT_REQUIRED":
        return (
            state
            == "PERMANENT_CHANGE_APPLY_NOT_REQUIRED"
        )

    if design_state == "PERMANENT_CHANGE_DESIGN_DEFERRED":
        return (
            state
            == "PERMANENT_CHANGE_APPLY_DEFERRED"
        )

    if design_state != "PERMANENT_CHANGE_DESIGN_LOCKED":
        return (
            state
            == "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT"
        )

    return state in {
        "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
        "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
        "PERMANENT_CHANGE_APPLY_REVIEW_REQUIRED",
        "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED",
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
        "PERMANENT_CHANGE_APPLY_REJECTED",
        "PERMANENT_CHANGE_APPLY_DEFERRED",
    }


def _design_source_mapping_ok(
    context: dict,
) -> bool:
    apply = context.get("apply") or {}
    state = _text(
        apply.get("apply_state")
    ).upper()

    source_id = _text(
        apply.get(
            "source_permanent_change_design_id"
        )
    )

    source_hash = _text(
        apply.get(
            "source_permanent_change_design_hash"
        )
    )

    if state in {
        "PERMANENT_CHANGE_APPLY_UPSTREAM_WAIT",
        "PERMANENT_CHANGE_APPLY_NOT_REQUIRED",
        "PERMANENT_CHANGE_APPLY_DEFERRED",
    }:
        if not source_id and not source_hash:
            return True

    if state == "PERMANENT_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED":
        return (
            not source_id
            and not source_hash
        )

    if (
        state
        == "PERMANENT_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW"
        and (not source_id or not source_hash)
    ):
        return True

    if not source_id or not source_hash:
        return False

    index, duplicates = _index_by_id(
        context.get(
            "permanent_change_design_snapshots"
        ),
        "permanent_change_design_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(source_id)

    return (
        bool(parent)
        and _text(
            permanent_change_design_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get(
                "permanent_change_design_permission"
            )
        ).upper()
        == "PERMANENT_DESIGN_LOCKED_NO_APPLY"
    )


def _stage1_contract_ok(
    apply: dict,
) -> bool:
    state = _text(
        apply.get("apply_state")
    ).upper()

    if state != (
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
    ):
        return True

    stage = _int(
        apply.get("permit_stage_number")
    )

    permit_scope = _float(
        apply.get("permit_scope_pct")
    )

    design_stage_scope = _float(
        apply.get("initial_stage_scope_pct")
    )

    target_scope = _float(
        apply.get("target_scope_pct")
    )

    activation_hours = _int(
        apply.get(
            "permit_activation_window_hours"
        )
    )

    permit_min_outcomes = _int(
        apply.get(
            "permit_min_post_change_outcomes"
        )
    )

    design_min_outcomes = _int(
        apply.get(
            "design_min_post_change_outcomes"
        )
    )

    permit_degradation = _float(
        apply.get(
            "permit_max_relative_error_degradation_pct"
        )
    )

    design_degradation = _float(
        apply.get(
            "design_max_relative_error_degradation_pct"
        )
    )

    permit_rollback = _int(
        apply.get(
            "permit_rollback_observation_hours"
        )
    )

    design_rollback = _int(
        apply.get(
            "design_rollback_observation_hours"
        )
    )

    return (
        stage == 1
        and 0 < permit_scope <= design_stage_scope
        and design_stage_scope <= 0.10
        and permit_scope <= target_scope
        and 1 <= activation_hours <= 168
        and permit_min_outcomes
        >= max(
            5,
            design_min_outcomes,
        )
        and abs(
            permit_degradation
            - design_degradation
        )
        <= 1e-12
        and permit_rollback
        >= max(
            24,
            design_rollback,
        )
    )


def _human_apply_contract_ok(
    apply: dict,
) -> bool:
    state = _text(
        apply.get("apply_state")
    ).upper()

    if state not in {
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
        "PERMANENT_CHANGE_APPLY_REJECTED",
        "PERMANENT_CHANGE_APPLY_DEFERRED",
    }:
        return True

    latest = apply.get(
        "latest_apply"
    ) or {}

    if not latest:
        return False

    confirmations = [
        "design_source_reviewed",
        "design_integrity_verified",
        "baseline_revalidated_confirmed",
        "candidate_artifact_verified",
        "stage1_scope_confirmed",
        "staged_rollout_isolation_confirmed",
        "change_window_reviewed",
        "rollback_ready_confirmed",
        "monitoring_ready_confirmed",
        "manual_external_apply_only_confirmed",
        "no_auto_stage_escalation_confirmed",
        "no_auto_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            latest.get(field)
        )
        for field in confirmations
    ):
        return False

    decision = _text(
        latest.get("apply_decision")
    ).upper()

    if state == (
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
    ):
        return (
            decision
            == "ISSUE_MANUAL_STAGE1_APPLY_PERMIT"
            and _text(
                latest.get(
                    "permanent_change_apply_permission"
                )
            ).upper()
            == "MANUAL_PERMANENT_STAGE1_APPLY_ONLY"
            and len(
                _text(
                    latest.get("apply_detail")
                )
            )
            >= 60
        )

    if state == "PERMANENT_CHANGE_APPLY_REJECTED":
        return (
            decision == "REJECT"
            and _text(
                latest.get(
                    "permanent_change_apply_permission"
                )
            ).upper()
            in {"", "NONE"}
        )

    return (
        decision == "DEFER"
        and _text(
            latest.get(
                "permanent_change_apply_permission"
            )
        ).upper()
        in {"", "NONE"}
    )


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    apply = context.get("apply") or {}
    latest = context.get(
        "latest_apply"
    ) or {}

    state = _text(
        apply.get("apply_state")
    ).upper()

    if not latest:
        return True

    source_ts = pd.to_datetime(
        apply.get(
            "source_permanent_change_design_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    apply_ts = pd.to_datetime(
        latest.get("created_at"),
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_ts)
        or pd.isna(apply_ts)
        or apply_ts <= source_ts
    ):
        return False

    if state == "PERMANENT_CHANGE_APPLY_SOURCE_SUPERSEDED":
        return (
            _text(
                latest.get(
                    "source_permanent_change_design_id"
                )
            )
            != _text(
                apply.get(
                    "source_permanent_change_design_id"
                )
            )
            or _text(
                latest.get(
                    "source_permanent_change_design_hash"
                )
            )
            != _text(
                apply.get(
                    "source_permanent_change_design_hash"
                )
            )
        )

    if state in {
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
        "PERMANENT_CHANGE_APPLY_REJECTED",
        "PERMANENT_CHANGE_APPLY_DEFERRED",
    }:
        return (
            _text(
                latest.get(
                    "source_permanent_change_design_id"
                )
            )
            == _text(
                apply.get(
                    "source_permanent_change_design_id"
                )
            )
            and _text(
                latest.get(
                    "source_permanent_change_design_hash"
                )
            )
            == _text(
                apply.get(
                    "source_permanent_change_design_hash"
                )
            )
        )

    return True


def _no_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("apply") or {},
        context.get("latest_apply") or {},
        context.get("design") or {},
    ]:
        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "permanent_change_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "permanent_change_apply_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (
                    ~values.isin(
                        ["", "NONE"]
                    )
                ).sum()
            )

    return (
        violations == 0
        and _text(
            context.get(
                "execution_authorization"
            )
        ).upper()
        == "NONE"
    )


def build_v152_permanent_change_apply_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    apply = ctx.get("apply") or {}
    design = ctx.get("design") or {}
    counts = ctx.get(
        "apply_integrity"
    ) or {}

    state = _text(
        apply.get("apply_state")
    ).upper()

    guard = _text(
        apply.get("apply_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Permanent Change Apply Snapshot Integrity",
            (
                _int(
                    counts.get("missing")
                )
                == 0
                and _int(
                    counts.get("mismatch")
                )
                == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Permanent Change Apply immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Change Apply State / Guard Vocabulary",
            (
                state
                in PERMANENT_CHANGE_APPLY_STATES
                and guard
                == PERMANENT_CHANGE_APPLY_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {PERMANENT_CHANGE_APPLY_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Permanent Change Apply state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Design → Apply State Invariant",
            _design_routing_ok(
                apply,
                design,
            ),
            (
                f"design {_text(design.get('design_state')) or 'MISSING'} · "
                f"apply {state or 'MISSING'}"
            ),
            "Permanent Design과 Apply state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Apply → Immutable Design Source Mapping",
            _design_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"design source {_text(apply.get('source_permanent_change_design_id')) or 'NONE'} · "
                f"integrity {_text(apply.get('source_permanent_change_design_integrity')) or 'NONE'}"
            ),
            "Apply source Design id/hash/integrity/permission 확인",
        )
    )

    checks.append(
        _technical_row(
            "Stage-1 Scope / Window / Inherited Risk Budget Invariant",
            _stage1_contract_ok(
                apply
            ),
            (
                f"state {state or 'MISSING'} · "
                f"stage {_int(apply.get('permit_stage_number'))} · "
                f"permit {_float(apply.get('permit_scope_pct')):.1%} · "
                f"design stage1 {_float(apply.get('initial_stage_scope_pct')):.1%} · "
                f"window {_int(apply.get('permit_activation_window_hours'))}h"
            ),
            "Stage-1 scope/window/outcome/degradation/rollback budget 확인",
        )
    )

    checks.append(
        _technical_row(
            "Human Apply / Manual External / No-Auto-Stage Contract",
            _human_apply_contract_ok(
                apply
            ),
            (
                f"state {state or 'MISSING'} · "
                f"decision {_text(apply.get('apply_decision')) or 'NONE'} · "
                f"permission {_text(apply.get('permanent_change_apply_permission')) or 'NONE'}"
            ),
            "Human confirmations, manual external apply only, no auto-stage escalation 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Apply Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(apply.get('source_permanent_change_design_created_at')) or 'NONE'} · "
                f"latest {_text((ctx.get('latest_apply') or {}).get('created_at')) or 'NONE'}"
            ),
            "Permanent Design 이후 Apply 저장 및 source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Apply No-Mutation / No-Execution Authorization Invariant",
            _no_authorization_ok(
                ctx
            ),
            "NONE",
            "Permanent Design/Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state in {
            "PERMANENT_CHANGE_APPLY_NOT_REQUIRED",
            "PERMANENT_CHANGE_APPLY_DEFERRED",
            "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
            "PERMANENT_CHANGE_APPLY_REJECTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Permanent Change Apply Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"decision {_text(apply.get('apply_decision')) or 'NONE'} · "
                f"permission {_text(apply.get('permanent_change_apply_permission')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream/source/apply-review/supersession 상태는 Technical FAIL로 승격하지 않고 "
                    "Permanent Design/Apply evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "apply_state": state,
        "design_state": _text(
            design.get("design_state")
        ).upper(),
        "latest_permanent_change_apply_integrity":
            _text(
                ctx.get("latest_apply_integrity")
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=
                PERMANENT_CHANGE_APPLY_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_apply_contract_ok(
    item: dict,
) -> bool:
    state = _text(
        item.get("apply_state")
    ).upper()

    guard = _text(
        item.get("apply_guard")
    ).upper()

    if (
        state not in {
            "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
            "PERMANENT_CHANGE_APPLY_REJECTED",
            "PERMANENT_CHANGE_APPLY_DEFERRED",
        }
        or guard
        != PERMANENT_CHANGE_APPLY_GUARD_BY_STATE.get(
            state,
            "",
        )
    ):
        return False

    confirmations = [
        "design_source_reviewed",
        "design_integrity_verified",
        "baseline_revalidated_confirmed",
        "candidate_artifact_verified",
        "stage1_scope_confirmed",
        "staged_rollout_isolation_confirmed",
        "change_window_reviewed",
        "rollback_ready_confirmed",
        "monitoring_ready_confirmed",
        "manual_external_apply_only_confirmed",
        "no_auto_stage_escalation_confirmed",
        "no_auto_permanent_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            item.get(field)
        )
        for field in confirmations
    ):
        return False

    if len(
        _text(
            item.get("apply_detail")
        )
    ) < 60:
        return False

    decision = _text(
        item.get("apply_decision")
    ).upper()

    permission = _text(
        item.get(
            "permanent_change_apply_permission"
        )
    ).upper()

    if state == (
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
    ):
        if (
            decision
            != "ISSUE_MANUAL_STAGE1_APPLY_PERMIT"
            or permission
            != "MANUAL_PERMANENT_STAGE1_APPLY_ONLY"
        ):
            return False

        if _int(
            item.get("permit_stage_number")
        ) != 1:
            return False

        permit_scope = _float(
            item.get("permit_scope_pct")
        )

        stage_scope = _float(
            item.get("initial_stage_scope_pct")
        )

        target_scope = _float(
            item.get("target_scope_pct")
        )

        if not (
            0 < permit_scope <= stage_scope
            and stage_scope <= 0.10
            and permit_scope <= target_scope
        ):
            return False

        if not (
            1
            <= _int(
                item.get(
                    "permit_activation_window_hours"
                )
            )
            <= 168
        ):
            return False

        if _int(
            item.get(
                "permit_min_post_change_outcomes"
            )
        ) < max(
            5,
            _int(
                item.get(
                    "design_min_post_change_outcomes"
                )
            ),
        ):
            return False

        if abs(
            _float(
                item.get(
                    "permit_max_relative_error_degradation_pct"
                )
            )
            - _float(
                item.get(
                    "design_max_relative_error_degradation_pct"
                )
            )
        ) > 1e-12:
            return False

        if _int(
            item.get(
                "permit_rollback_observation_hours"
            )
        ) < max(
            24,
            _int(
                item.get(
                    "design_rollback_observation_hours"
                )
            ),
        ):
            return False

    elif state == "PERMANENT_CHANGE_APPLY_REJECTED":
        if (
            decision != "REJECT"
            or permission not in {"", "NONE"}
        ):
            return False

    else:
        if (
            decision != "DEFER"
            or permission not in {"", "NONE"}
        ):
            return False

    return True


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail": detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def build_v152_permanent_change_apply_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    apply_df = _ensure_cols(
        ctx.get(
            "permanent_change_apply_snapshots"
        ),
        FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    design_df = _ensure_cols(
        ctx.get(
            "permanent_change_design_snapshots"
        ),
        FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        apply_df,
        permanent_change_apply_snapshot_integrity,
    )

    design_index, design_duplicates = _index_by_id(
        design_df,
        "permanent_change_design_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in apply_df.iterrows():
        item = row.to_dict()

        apply_id = _text(
            item.get(
                "permanent_change_apply_id"
            )
        )

        if apply_id:
            if apply_id in seen_ids:
                identity_duplicates += 1

            seen_ids.add(apply_id)

        if not _saved_apply_contract_ok(
            item
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_permanent_change_design_id"
            )
        )

        source_hash = _text(
            item.get(
                "source_permanent_change_design_hash"
            )
        )

        parent = design_index.get(source_id)

        if (
            not parent
            or _text(
                permanent_change_design_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get(
                    "permanent_change_design_permission"
                )
            ).upper()
            != "PERMANENT_DESIGN_LOCKED_NO_APPLY"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )

            apply_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(apply_ts)
                or apply_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Permanent Change Apply Audit Snapshot Integrity",
            (
                _int(
                    counts.get("missing")
                )
                == 0
                and _int(
                    counts.get("mismatch")
                )
                == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Permanent Change Apply immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Apply Audit Human Stage-1 Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "Human decision, stage-1 scope/window, manual-only, no-auto-stage contract 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Apply Audit → Design Lineage",
            (
                lineage_violations == 0
                and design_duplicates == 0
            ),
            (
                f"lineage violations {lineage_violations} · "
                f"design duplicate ids {design_duplicates}"
            ),
            "Apply source immutable Permanent Design id/hash/permission lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Apply Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate apply ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Apply audit identity uniqueness 및 Permanent Design 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Apply Audit No-Mutation Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else f"non-NONE sources {authorization_violations}"
            ),
            "Permanent Design/Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (
            ctx.get("apply")
            or {}
        ).get("apply_state")
    ).upper()

    operating_status = (
        "PASS"
        if current_state in {
            "PERMANENT_CHANGE_APPLY_NOT_REQUIRED",
            "PERMANENT_CHANGE_APPLY_DEFERRED",
            "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY",
            "PERMANENT_CHANGE_APPLY_REJECTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Permanent Change Apply Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current apply {current_state or 'MISSING'} · "
                f"saved apply decisions {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 Permanent Design LOCKED 이후 Human Apply decision이 필요할 때만 "
                    "immutable Apply history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=
                PERMANENT_CHANGE_APPLY_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v152_release_readiness(
    *,
    v151_release_status: str,
    v151_baseline_provenance: dict | None,
    integration_consistency: str,
    csv_fail_count: int,
    apply_release_gate: str,
    apply_audit_gate: str,
    work_ready_release_gate: str,
    apply_operating_status: str,
    audit_operating_status: str,
    work_ready_operating_status: str,
    execution_authorization: str,
) -> dict:
    provenance = (
        v151_baseline_provenance
        or {}
    )

    checks = [
        _candidate_row(
            "v1.51 Immutable Release Baseline Provenance",
            bool(
                provenance.get("verified")
            ),
            (
                f"{_text(provenance.get('status')) or 'MISSING'} · "
                f"source {_text(provenance.get('source')) or 'NONE'} · "
                f"dynamic-v1.51 {_text(v151_release_status).upper() or 'MISSING'}"
            ),
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Permanent Change Apply Technical Release Gate",
            _text(
                apply_release_gate
            ).upper()
            == "PASS",
            _text(
                apply_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Apply Audit Integrity Gate",
            _text(
                apply_audit_gate
            ).upper()
            == "PASS",
            _text(
                apply_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Software Update Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            apply_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "PERMANENT_CHANGE_APPLY_REVIEW"
        )

    if _text(
        work_ready_operating_status
    ).upper() != "PASS":
        operating_reviews.append(
            "WORK_READY_RELEASE_MANAGER_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V152_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v152_integration_crosscheck(
    *,
    integration_consistency: str,
    apply_release_gate: str,
    apply_audit_gate: str,
    work_ready_release_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Apply Technical Gate",
            _text(
                apply_release_gate
            ).upper()
            == "PASS",
            _text(
                apply_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Apply Audit Gate",
            _text(
                apply_audit_gate
            ).upper()
            == "PASS",
            _text(
                apply_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V152_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v152_data_crosscheck(
    *,
    csv_fail_count: int,
    apply_release_gate: str,
    apply_audit_gate: str,
    work_ready_release_gate: str,
    latest_apply_integrity: str,
) -> dict:
    latest = _text(
        latest_apply_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Permanent Change Apply Technical Gate",
            _text(
                apply_release_gate
            ).upper()
            == "PASS",
            _text(
                apply_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Apply Audit Gate",
            _text(
                apply_audit_gate
            ).upper()
            == "PASS",
            _text(
                apply_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Permanent Change Apply Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V152_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
