from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    flow_projection_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    latest_ready_flow_projection_snapshot,
)
from engine.operations_flow_projection_review import (
    FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    flow_projection_review_snapshot_integrity,
    latest_flow_projection_review_snapshot,
    build_flow_projection_review_context,
    latest_reviewed_projection_source,
)


PROJECTION_REVIEW_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V133_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


KNOWN_REVIEW_STATES = {
    "PROJECTION_REVIEW_SOURCE_REQUIRED",
    "PROJECTION_REVIEW_SOURCE_INTEGRITY_REVIEW",
    "PROJECTION_REVIEW_REQUIRED",
    "PROJECTION_REVIEW_AUDIT_INTEGRITY_REVIEW",
    "PROJECTION_REVIEW_SOURCE_SUPERSEDED",
    "PROJECTION_REVIEW_AUDIT_STATE_REVIEW",
    "PROJECTION_REVIEW_CONTRACT_INCOMPLETE",
    "PROJECTION_REVIEW_LOCKED",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE",
        "1",
        "YES",
        "Y",
        "T",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    source = pd.DataFrame() if df is None else df.copy()
    if source.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0
    for _, row in source.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _fail_count(
    counts: dict | None,
) -> int:
    c = counts or {}
    return (
        _int(c.get("missing"))
        + _int(c.get("mismatch"))
    )


def _index_by_id(
    df: pd.DataFrame,
    *,
    id_col: str,
) -> tuple[dict, int]:
    if df.empty or id_col not in df.columns:
        return {}, 0

    index = {}
    duplicates = 0
    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )
        if not item_id:
            continue
        if item_id in index:
            duplicates += 1
        index[item_id] = item
    return index, duplicates


def build_v133_review_context(
    *,
    projection_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
) -> dict:
    projection_df = _ensure_cols(
        projection_snapshots,
        FLOW_PROJECTION_SNAPSHOT_COLS,
    )
    review_df = _ensure_cols(
        review_snapshots,
        FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    )

    review = build_flow_projection_review_context(
        projection_df,
        review_df,
    )
    latest_projection = latest_ready_flow_projection_snapshot(
        projection_df
    )
    latest_review = latest_flow_projection_review_snapshot(
        review_df
    )
    outcome_source = latest_reviewed_projection_source(
        projection_df,
        review_df,
    )

    latest_review_integrity = (
        _text(
            flow_projection_review_snapshot_integrity(
                latest_review
            ).get("status")
        ).upper()
        if latest_review
        else "NONE"
    )

    return {
        "projection_snapshots": projection_df,
        "review_snapshots": review_df,
        "review": review,
        "latest_ready_projection": latest_projection,
        "latest_review": latest_review,
        "outcome_source": outcome_source,
        "review_integrity": _integrity_counts(
            review_df,
            flow_projection_review_snapshot_integrity,
        ),
        "latest_review_integrity": latest_review_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v133_review_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    review = ctx.get("review") or {}
    latest_projection = ctx.get("latest_ready_projection") or {}
    latest_review = ctx.get("latest_review") or {}
    outcome_source = ctx.get("outcome_source") or {}
    counts = ctx.get("review_integrity") or {}

    checks = []

    integrity_fail = _fail_count(counts)
    checks.append(
        _technical_row(
            "Projection Review Snapshot Integrity",
            integrity_fail == 0,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            (
                "operations_flow_projection_review_snapshots.csv "
                "immutable hash 확인"
            ),
        )
    )

    state = _text(
        review.get("review_state")
    ).upper()
    source_integrity = _text(
        review.get("source_projection_integrity")
    ).upper()
    source_current = bool(
        review.get("source_current")
    )
    review_locked = bool(
        review.get("review_locked")
    )

    vocabulary_ok = state in KNOWN_REVIEW_STATES
    checks.append(
        _technical_row(
            "Projection Review State / Lock Vocabulary",
            vocabulary_ok,
            (
                f"state {state or 'MISSING'} · "
                f"source integrity {source_integrity or 'MISSING'} · "
                f"current {source_current} · locked {review_locked}"
            ),
            "Projection Review state / lock vocabulary 확인",
        )
    )

    if state == "PROJECTION_REVIEW_SOURCE_REQUIRED":
        state_mapping_ok = (
            not latest_projection
            and source_integrity == "NONE"
            and not source_current
            and not review_locked
        )
    elif state == "PROJECTION_REVIEW_SOURCE_INTEGRITY_REVIEW":
        state_mapping_ok = (
            bool(latest_projection)
            and source_integrity != "OK"
            and not review_locked
        )
    elif state == "PROJECTION_REVIEW_REQUIRED":
        state_mapping_ok = (
            bool(latest_projection)
            and source_integrity == "OK"
            and source_current
            and not latest_review
            and not review_locked
        )
    elif state == "PROJECTION_REVIEW_LOCKED":
        state_mapping_ok = (
            bool(latest_projection)
            and bool(latest_review)
            and source_integrity == "OK"
            and source_current
            and review_locked
        )
    elif state == "PROJECTION_REVIEW_SOURCE_SUPERSEDED":
        state_mapping_ok = (
            bool(latest_projection)
            and bool(latest_review)
            and source_integrity == "OK"
            and not source_current
            and not review_locked
        )
    else:
        state_mapping_ok = (
            bool(latest_projection)
            and bool(latest_review)
            and not review_locked
        )

    # A corrupt READY Projection or corrupt Review audit is a technical fail,
    # not merely a valid state transition.
    source_health_ok = (
        state != "PROJECTION_REVIEW_SOURCE_INTEGRITY_REVIEW"
    )
    audit_health_ok = (
        state != "PROJECTION_REVIEW_AUDIT_INTEGRITY_REVIEW"
    )

    checks.append(
        _technical_row(
            "Projection Review Source / Lock Mapping",
            state_mapping_ok and source_health_ok and audit_health_ok,
            (
                f"state {state or 'MISSING'} · "
                f"ready source {bool(latest_projection)} · "
                f"review audit {bool(latest_review)} · "
                f"source current {source_current} · "
                f"locked {review_locked}"
            ),
            (
                "READY source / Review audit / current / lock mapping과 "
                "source/audit integrity 확인"
            ),
        )
    )

    if state == "PROJECTION_REVIEW_LOCKED":
        contract_ok = all(
            [
                _text(
                    latest_review.get("review_state")
                ).upper()
                == "PROJECTION_REVIEW_LOCKED",
                _bool(
                    latest_review.get("source_lineage_confirmed")
                ),
                _bool(
                    latest_review.get("scenario_semantics_confirmed")
                ),
                _bool(
                    latest_review.get("no_auto_capacity_confirmed")
                ),
                _bool(
                    latest_review.get(
                        "no_execution_authorization_confirmed"
                    )
                ),
                _bool(
                    latest_review.get("human_review_confirmed")
                ),
            ]
        )
    elif state in {
        "PROJECTION_REVIEW_CONTRACT_INCOMPLETE",
        "PROJECTION_REVIEW_AUDIT_STATE_REVIEW",
    }:
        contract_ok = False
    else:
        contract_ok = True

    checks.append(
        _technical_row(
            "Projection Human Review Contract Invariant",
            contract_ok,
            (
                f"state {state or 'MISSING'} · "
                f"latest audit {_text(ctx.get('latest_review_integrity')).upper() or 'NONE'}"
            ),
            (
                "LOCKED Review audit의 5개 Human Review confirmation과 "
                "state 확인"
            ),
        )
    )

    latest_projection_id = _text(
        latest_projection.get("projection_snapshot_id")
    )
    latest_review_source_id = _text(
        latest_review.get("source_projection_snapshot_id")
    )

    if state == "PROJECTION_REVIEW_LOCKED":
        supersession_ok = (
            latest_projection_id
            and latest_review_source_id
            and latest_projection_id
            == latest_review_source_id
        )
    elif state == "PROJECTION_REVIEW_SOURCE_SUPERSEDED":
        supersession_ok = (
            latest_projection_id
            and latest_review_source_id
            and latest_projection_id
            != latest_review_source_id
        )
    else:
        supersession_ok = True

    checks.append(
        _technical_row(
            "Projection Review Supersession Invariant",
            bool(supersession_ok),
            (
                f"state {state or 'MISSING'} · "
                f"latest projection {latest_projection_id or 'NONE'} · "
                f"review source {latest_review_source_id or 'NONE'}"
            ),
            (
                "새 READY Projection이 기존 Review Lock을 자동 supersede하는지 확인"
            ),
        )
    )

    outcome_source_id = _text(
        outcome_source.get("projection_snapshot_id")
    )

    if state == "PROJECTION_REVIEW_LOCKED":
        handoff_ok = (
            bool(outcome_source)
            and outcome_source_id
            == latest_projection_id
        )
    else:
        handoff_ok = not bool(outcome_source)

    checks.append(
        _technical_row(
            "Review Lock → Outcome Source Admission Invariant",
            handoff_ok,
            (
                f"review {state or 'MISSING'} · "
                f"outcome source {outcome_source_id or 'NONE'}"
            ),
            (
                "Outcome source는 latest READY Projection과 valid Review Lock이 "
                "동시에 있을 때만 허용"
            ),
        )
    )

    projection_df = ctx.get("projection_snapshots")
    projection_df = (
        projection_df
        if isinstance(projection_df, pd.DataFrame)
        else pd.DataFrame()
    )
    projection_index, projection_duplicates = _index_by_id(
        projection_df,
        id_col="projection_snapshot_id",
    )

    lineage_ok = projection_duplicates == 0

    if latest_review:
        source_id = _text(
            latest_review.get("source_projection_snapshot_id")
        )
        source_hash = _text(
            latest_review.get("source_projection_hash")
        )
        parent = projection_index.get(source_id)

        if (
            not source_id
            or parent is None
            or _text(
                flow_projection_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("projection_state")
            ).upper()
            != "READY_FOR_REVIEW"
        ):
            lineage_ok = False

    checks.append(
        _technical_row(
            "Projection Review Source Lineage Invariant",
            lineage_ok,
            (
                f"projection duplicates {projection_duplicates} · "
                f"latest review source {latest_review_source_id or 'NONE'}"
            ),
            "Review audit source projection id/hash parent lineage 확인",
        )
    )

    auth_violations = 0

    for item in [
        review,
        latest_review,
        outcome_source,
    ]:
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                auth_violations += 1

    review_df = ctx.get("review_snapshots")
    if (
        isinstance(review_df, pd.DataFrame)
        and not review_df.empty
    ):
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in review_df.columns:
                continue
            values = (
                review_df[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            auth_violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if (
        _text(
            ctx.get("execution_authorization")
        ).upper()
        != "NONE"
    ):
        auth_violations += 1

    checks.append(
        _technical_row(
            "Projection Review Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            (
                "Projection / Capacity / Execution Authorization을 NONE으로 유지"
            ),
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state == "PROJECTION_REVIEW_LOCKED"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Human Review Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"source current {source_current} · "
                f"locked {review_locked} · "
                f"outcome source {outcome_source_id or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream HOLD / source-required / Human Review wait는 "
                    "Technical FAIL로 승격하지 않음"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "review_state": state,
        "source_integrity": source_integrity,
        "source_current": source_current,
        "review_locked": review_locked,
        "outcome_source_available": bool(outcome_source),
        "latest_review_integrity": _text(
            ctx.get("latest_review_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=PROJECTION_REVIEW_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v133_review_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    review_df = ctx.get("review_snapshots")
    projection_df = ctx.get("projection_snapshots")

    review_df = (
        review_df
        if isinstance(review_df, pd.DataFrame)
        else pd.DataFrame()
    )
    projection_df = (
        projection_df
        if isinstance(projection_df, pd.DataFrame)
        else pd.DataFrame()
    )

    counts = ctx.get("review_integrity") or {}
    checks = []

    checks.append(
        _audit_row(
            "Projection Human Review Audit Snapshot Integrity",
            _fail_count(counts) == 0,
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Projection Review audit immutable hash 확인",
        )
    )

    contract_violations = 0
    vocabulary_violations = 0
    auth_violations = 0
    identity_duplicates = 0

    review_ids = set()

    for _, row in review_df.iterrows():
        item = row.to_dict()
        review_id = _text(
            item.get("review_snapshot_id")
        )
        if review_id:
            if review_id in review_ids:
                identity_duplicates += 1
            review_ids.add(review_id)

        if (
            _text(
                item.get("review_state")
            ).upper()
            != "PROJECTION_REVIEW_LOCKED"
            or _text(
                item.get("source_projection_integrity")
            ).upper()
            != "OK"
            or _text(
                item.get("source_projection_state")
            ).upper()
            != "READY_FOR_REVIEW"
        ):
            vocabulary_violations += 1

        if not all(
            [
                _bool(
                    item.get("source_lineage_confirmed")
                ),
                _bool(
                    item.get("scenario_semantics_confirmed")
                ),
                _bool(
                    item.get("no_auto_capacity_confirmed")
                ),
                _bool(
                    item.get(
                        "no_execution_authorization_confirmed"
                    )
                ),
                _bool(
                    item.get("human_review_confirmed")
                ),
            ]
        ):
            contract_violations += 1

        for field in [
            "projection_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                auth_violations += 1

    checks.append(
        _audit_row(
            "Projection Review Audit State / Contract",
            (
                vocabulary_violations == 0
                and contract_violations == 0
            ),
            (
                f"vocabulary violations {vocabulary_violations} · "
                f"contract violations {contract_violations}"
            ),
            (
                "저장 Review audit은 LOCKED/READY source/5개 confirmation을 "
                "모두 만족해야 함"
            ),
        )
    )

    projection_index, projection_duplicates = _index_by_id(
        projection_df,
        id_col="projection_snapshot_id",
    )

    lineage_violations = projection_duplicates

    for _, row in review_df.iterrows():
        item = row.to_dict()
        source_id = _text(
            item.get("source_projection_snapshot_id")
        )
        source_hash = _text(
            item.get("source_projection_hash")
        )
        parent = projection_index.get(source_id)

        if (
            not source_id
            or parent is None
            or _text(
                flow_projection_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("projection_state")
            ).upper()
            != "READY_FOR_REVIEW"
        ):
            lineage_violations += 1

    checks.append(
        _audit_row(
            "Projection Review Audit → Projection Source Lineage",
            lineage_violations == 0,
            (
                f"violations {lineage_violations} · "
                f"projection duplicates {projection_duplicates}"
            ),
            "Review audit source Projection id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Projection Review Audit Identity Invariant",
            identity_duplicates == 0,
            f"duplicate review ids {identity_duplicates}",
            "Review audit snapshot id 중복 확인",
        )
    )

    checks.append(
        _audit_row(
            "Projection Review Audit Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            (
                "Review audit의 Projection / Capacity / Execution Authorization을 "
                "NONE으로 유지"
            ),
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("review") or {}).get(
            "review_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state == "PROJECTION_REVIEW_LOCKED"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Human Review Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current review {current_state or 'MISSING'} · "
                f"saved audits {len(review_df)}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "Review proof가 실제로 필요한 READY Projection이 생길 때만 "
                    "Human Review Lock 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "latest_review_integrity": _text(
            ctx.get("latest_review_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=PROJECTION_REVIEW_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v133_release_readiness(
    *,
    v132_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    review_release_gate: str,
    review_audit_gate: str,
    review_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(
        v132_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    review_gate = _text(
        review_release_gate
    ).upper()
    audit_gate = _text(
        review_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.32 Projection Admission Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Human Review Technical Release Gate",
            review_gate == "PASS",
            review_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Human Review Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(
            review_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "PROJECTION_HUMAN_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V133_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v133_integration_crosscheck(
    *,
    integration_consistency: str,
    review_release_gate: str,
    review_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    review_gate = _text(
        review_release_gate
    ).upper()
    audit_gate = _text(
        review_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Projection Human Review Technical Gate",
            review_gate == "PASS",
            review_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Human Review Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V133_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v133_data_crosscheck(
    *,
    csv_fail_count: int,
    review_release_gate: str,
    review_audit_gate: str,
    latest_review_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    review_gate = _text(
        review_release_gate
    ).upper()
    audit_gate = _text(
        review_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_review_integrity
    ).upper()

    latest_ok = latest_integrity in {
        "OK",
        "NONE",
    }

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Human Review Technical Gate",
            review_gate == "PASS",
            review_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Human Review Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Projection Human Review Audit Integrity",
            latest_ok,
            latest_integrity or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V133_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
