from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import json

import pandas as pd


SCHEMA_GUARD_EXCLUDED_FILES = {
    "schema_baseline_locks.csv",
    "schema_migration_proposals.csv",
    "schema_contract_locks.csv",
    "schema_migration_proof_reviews.csv",
    "schema_refresh_approvals.csv",
    "operations_sessions.csv",
    "operations_carry_forward_snapshots.csv",
    "operations_recurrence_snapshots.csv",
    "operations_capacity_overrides.csv",
    "operations_sla_closure_snapshots.csv",
    "operations_flow_snapshots.csv",
    "operations_flow_trend_snapshots.csv",
    "operations_flow_calibration_snapshots.csv",
    "operations_flow_projection_snapshots.csv",
    "operations_flow_projection_outcome_snapshots.csv",
    "operations_flow_projection_scorecard_snapshots.csv",
    "operations_flow_evidence_snapshots.csv",
    "operations_flow_calibration_promotion_snapshots.csv",
    "operations_flow_projection_admission_snapshots.csv",
    "operations_flow_projection_review_snapshots.csv",
    "operations_flow_projection_outcome_evidence_snapshots.csv",
    "operations_flow_scorecard_input_snapshots.csv",
    "operations_flow_recalibration_review_snapshots.csv",
    "operations_flow_recalibration_proposal_snapshots.csv",
    "operations_flow_shadow_validation_plan_snapshots.csv",
    "operations_flow_shadow_validation_outcome_snapshots.csv",
    "operations_flow_shadow_adoption_review_snapshots.csv",
    "operations_flow_controlled_trial_design_snapshots.csv",
    "operations_flow_controlled_trial_start_snapshots.csv",
    "operations_flow_controlled_trial_runtime_snapshots.csv",
    "operations_flow_controlled_trial_outcome_snapshots.csv",
    "operations_flow_controlled_trial_closure_snapshots.csv",
    "operations_flow_live_change_design_snapshots.csv",
    "operations_flow_live_change_apply_snapshots.csv",
    "operations_flow_live_change_runtime_snapshots.csv",
    "operations_flow_live_change_outcome_snapshots.csv",
    "operations_flow_live_change_outcome_closure_snapshots.csv",
    "operations_flow_permanent_change_design_snapshots.csv",
    "operations_flow_permanent_change_apply_snapshots.csv",
    "operations_flow_permanent_change_runtime_events.csv",
}


SCHEMA_SCAN_COLS = [
    "file",
    "parse_status",
    "column_count",
    "duplicate_columns",
    "columns_json",
    "schema_hash",
]


SCHEMA_DIFF_COLS = [
    "file",
    "status",
    "migration_type",
    "baseline_columns",
    "current_columns",
    "added_columns",
    "missing_columns",
    "detail",
    "blocking",
]


SCHEMA_BASELINE_LOCK_COLS = [
    "schema_baseline_id",
    "created_at",
    "file_count",
    "total_columns",
    "schema_snapshot_json",
    "schema_snapshot_hash",
    "scan_integrity_status",
    "baseline_gate",
    "baseline_status",
    "schema_review_confirmed",
    "no_auto_migration_confirmed",
    "no_destructive_change_confirmed",
    "human_review_confirmed",
    "migration_authorization",
    "issues",
    "note",
    "record_hash",
]


SCHEMA_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "file",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _read_header(path: Path) -> tuple[str, list[str], list[str]]:
    try:
        header = pd.read_csv(
            path,
            nrows=0,
            dtype=str,
            keep_default_na=False,
        )
        columns = [
            str(c)
            for c in header.columns.tolist()
        ]
    except pd.errors.EmptyDataError:
        return (
            "EMPTY_FILE",
            [],
            [],
        )
    except Exception as exc:
        return (
            f"PARSE_FAIL:{type(exc).__name__}",
            [],
            [],
        )

    seen = set()
    duplicates = []

    for col in columns:
        if col in seen:
            duplicates.append(
                col
            )
        else:
            seen.add(
                col
            )

    return (
        "PASS",
        columns,
        duplicates,
    )


def inspect_csv_schemas(
    data_dir: str | Path,
    *,
    excluded_files: set[str] | None = None,
) -> pd.DataFrame:
    root = Path(
        data_dir
    )

    excluded = set(
        SCHEMA_GUARD_EXCLUDED_FILES
    )
    if excluded_files:
        excluded |= set(
            excluded_files
        )

    rows = []

    if not root.is_dir():
        return pd.DataFrame(
            columns=
            SCHEMA_SCAN_COLS
        )

    for path in sorted(
        root.glob(
            "*.csv"
        )
    ):
        if path.name in excluded:
            continue

        parse_status, columns, duplicates = _read_header(
            path
        )

        schema_hash = (
            _hash(
                {
                    "file":
                        path.name,
                    "columns":
                        columns,
                }
            )
            if parse_status == "PASS"
            else ""
        )

        rows.append(
            {
                "file":
                    path.name,
                "parse_status":
                    parse_status,
                "column_count":
                    len(
                        columns
                    ),
                "duplicate_columns":
                    " | ".join(
                        duplicates
                    ),
                "columns_json":
                    json.dumps(
                        columns,
                        ensure_ascii=False,
                        separators=(",", ":"),
                    ),
                "schema_hash":
                    schema_hash,
            }
        )

    return pd.DataFrame(
        rows,
        columns=
        SCHEMA_SCAN_COLS,
    )


def schema_scan_summary(
    scan: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame(
            columns=
            SCHEMA_SCAN_COLS
        )
        if scan is None
        else scan.copy()
    )

    if df.empty:
        return {
            "scan_integrity_status":
                "REVIEW",
            "file_count":
                0,
            "total_columns":
                0,
            "parse_fail":
                0,
            "duplicate_schema_files":
                0,
            "issues":
                [
                    "NO_CSV_SCHEMA_FILES"
                ],
        }

    parse_fail = int(
        df[
            "parse_status"
        ]
        .fillna("")
        .astype(str)
        .ne(
            "PASS"
        )
        .sum()
    )

    duplicate_files = int(
        df[
            "duplicate_columns"
        ]
        .fillna("")
        .astype(str)
        .str.strip()
        .ne(
            ""
        )
        .sum()
    )

    issues = []

    if parse_fail > 0:
        issues.append(
            "CSV_SCHEMA_PARSE_FAIL"
        )

    if duplicate_files > 0:
        issues.append(
            "DUPLICATE_COLUMN_NAMES"
        )

    return {
        "scan_integrity_status":
            (
                "PASS"
                if not issues
                else "BLOCKED"
            ),
        "file_count":
            int(
                len(
                    df
                )
            ),
        "total_columns":
            int(
                pd.to_numeric(
                    df[
                        "column_count"
                    ],
                    errors="coerce",
                )
                .fillna(
                    0
                )
                .sum()
            ),
        "parse_fail":
            parse_fail,
        "duplicate_schema_files":
            duplicate_files,
        "issues":
            issues,
    }


def build_schema_snapshot(
    scan: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame(
            columns=
            SCHEMA_SCAN_COLS
        )
        if scan is None
        else scan.copy()
    )

    snapshot = {}

    if not df.empty:
        for _, row in df.sort_values(
            "file"
        ).iterrows():
            if _text(
                row.get(
                    "parse_status"
                )
            ) != "PASS":
                continue

            try:
                columns = json.loads(
                    _text(
                        row.get(
                            "columns_json"
                        )
                    )
                    or "[]"
                )
            except Exception:
                columns = []

            snapshot[
                _text(
                    row.get(
                        "file"
                    )
                )
            ] = [
                str(
                    col
                )
                for col in columns
            ]

    return {
        "snapshot":
            snapshot,
        "snapshot_json":
            json.dumps(
                snapshot,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        "snapshot_hash":
            _hash(
                snapshot
            ),
    }


def _baseline_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "schema_review_confirmed",
        "no_auto_migration_confirmed",
        "no_destructive_change_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in SCHEMA_BASELINE_LOCK_COLS:
        if col == "record_hash":
            continue

        if col in bool_fields:
            payload[
                col
            ] = bool(
                _bool(
                    row.get(
                        col
                    )
                )
            )
        else:
            payload[
                col
            ] = _text(
                row.get(
                    col
                )
            )

    return payload


def schema_baseline_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status":
                "MISSING",
            "calculated_hash":
                "",
        }

    calculated = _hash(
        _baseline_payload(
            record
        )
    )

    return {
        "status":
            (
                "OK"
                if stored
                == calculated
                else "MISMATCH"
            ),
        "calculated_hash":
            calculated,
    }


def latest_schema_baseline(
    baselines: pd.DataFrame | None,
) -> dict:
    if (
        baselines is None
        or baselines.empty
    ):
        return {}

    df = baselines.copy()

    if "created_at" in df.columns:
        df[
            "_ts"
        ] = pd.to_datetime(
            df[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        df = df.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        df.iloc[
            0
        ]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def _parse_baseline_snapshot(
    baseline: dict | None,
) -> tuple[dict, list[str]]:
    record = baseline or {}
    issues = []

    if not record:
        return (
            {},
            [
                "SCHEMA_BASELINE_MISSING"
            ],
        )

    integrity = schema_baseline_integrity(
        record
    )

    if integrity[
        "status"
    ] != "OK":
        issues.append(
            "SCHEMA_BASELINE_HASH_INTEGRITY_FAILED"
        )

    raw = _text(
        record.get(
            "schema_snapshot_json"
        )
    )

    try:
        snapshot = json.loads(
            raw
        )
    except Exception:
        snapshot = {}
        issues.append(
            "SCHEMA_BASELINE_JSON_INVALID"
        )

    if not isinstance(
        snapshot,
        dict,
    ):
        snapshot = {}
        issues.append(
            "SCHEMA_BASELINE_JSON_INVALID"
        )

    return (
        snapshot,
        list(
            dict.fromkeys(
                issues
            )
        ),
    )


def compare_schema_to_baseline(
    scan: pd.DataFrame | None,
    baseline: dict | None,
) -> dict:
    scan_summary = schema_scan_summary(
        scan
    )
    current = build_schema_snapshot(
        scan
    )[
        "snapshot"
    ]
    baseline_snapshot, baseline_issues = _parse_baseline_snapshot(
        baseline
    )

    if not baseline:
        return {
            "schema_status":
                (
                    "BLOCKED"
                    if scan_summary[
                        "scan_integrity_status"
                    ]
                    != "PASS"
                    else "NO_BASELINE"
                ),
            "diff":
                pd.DataFrame(
                    columns=
                    SCHEMA_DIFF_COLS
                ),
            "added_files":
                0,
            "missing_files":
                0,
            "changed_files":
                0,
            "blocking_changes":
                0,
            "review_changes":
                0,
            "issues":
                list(
                    dict.fromkeys(
                        scan_summary[
                            "issues"
                        ]
                        + [
                            "SCHEMA_BASELINE_MISSING"
                        ]
                    )
                ),
        }

    if (
        scan_summary[
            "scan_integrity_status"
        ]
        != "PASS"
        or baseline_issues
    ):
        return {
            "schema_status":
                "BLOCKED",
            "diff":
                pd.DataFrame(
                    columns=
                    SCHEMA_DIFF_COLS
                ),
            "added_files":
                0,
            "missing_files":
                0,
            "changed_files":
                0,
            "blocking_changes":
                1,
            "review_changes":
                0,
            "issues":
                list(
                    dict.fromkeys(
                        scan_summary[
                            "issues"
                        ]
                        + baseline_issues
                    )
                ),
        }

    rows = []

    all_files = sorted(
        set(
            baseline_snapshot.keys()
        )
        | set(
            current.keys()
        )
    )

    for file_name in all_files:
        base_cols = baseline_snapshot.get(
            file_name
        )
        current_cols = current.get(
            file_name
        )

        if base_cols is None:
            status = "REVIEW"
            migration_type = "FILE_ADDED"
            added = current_cols or []
            missing = []
            detail = "new CSV file after baseline"
            blocking = "NO"

        elif current_cols is None:
            status = "BLOCKED"
            migration_type = "FILE_MISSING"
            added = []
            missing = base_cols or []
            detail = "baseline CSV file is missing"
            blocking = "YES"

        elif base_cols == current_cols:
            status = "PASS"
            migration_type = "CURRENT"
            added = []
            missing = []
            detail = "schema matches baseline"
            blocking = "NO"

        else:
            base_set = set(
                base_cols
            )
            current_set = set(
                current_cols
            )

            added = [
                col
                for col in current_cols
                if col not in base_set
            ]
            missing = [
                col
                for col in base_cols
                if col not in current_set
            ]

            if (
                not missing
                and added
            ):
                status = "REVIEW"
                migration_type = "ADDITIVE_COLUMNS"
                detail = "columns added after baseline"
                blocking = "NO"

            elif (
                not added
                and missing
            ):
                status = "BLOCKED"
                migration_type = "MISSING_COLUMNS"
                detail = "baseline columns are missing"
                blocking = "YES"

            elif (
                not added
                and not missing
            ):
                status = "REVIEW"
                migration_type = "COLUMN_ORDER_CHANGED"
                detail = "same columns, different order"
                blocking = "NO"

            else:
                status = "BLOCKED"
                migration_type = "BREAKING_SCHEMA"
                detail = "columns added and removed/renamed"
                blocking = "YES"

        rows.append(
            {
                "file":
                    file_name,
                "status":
                    status,
                "migration_type":
                    migration_type,
                "baseline_columns":
                    (
                        len(
                            base_cols
                        )
                        if base_cols
                        is not None
                        else 0
                    ),
                "current_columns":
                    (
                        len(
                            current_cols
                        )
                        if current_cols
                        is not None
                        else 0
                    ),
                "added_columns":
                    " | ".join(
                        added
                    ),
                "missing_columns":
                    " | ".join(
                        missing
                    ),
                "detail":
                    detail,
                "blocking":
                    blocking,
            }
        )

    diff = pd.DataFrame(
        rows,
        columns=
        SCHEMA_DIFF_COLS,
    )

    added_files = int(
        diff[
            "migration_type"
        ]
        .eq(
            "FILE_ADDED"
        )
        .sum()
    )
    missing_files = int(
        diff[
            "migration_type"
        ]
        .eq(
            "FILE_MISSING"
        )
        .sum()
    )
    changed_files = int(
        diff[
            "migration_type"
        ]
        .ne(
            "CURRENT"
        )
        .sum()
    )
    blocking_changes = int(
        diff[
            "status"
        ]
        .eq(
            "BLOCKED"
        )
        .sum()
    )
    review_changes = int(
        diff[
            "status"
        ]
        .eq(
            "REVIEW"
        )
        .sum()
    )

    if blocking_changes > 0:
        schema_status = "BLOCKED"
    elif review_changes > 0:
        schema_status = "REVIEW"
    else:
        schema_status = "CURRENT"

    issues = []

    if blocking_changes > 0:
        issues.append(
            "BLOCKING_SCHEMA_DRIFT"
        )

    if review_changes > 0:
        issues.append(
            "SCHEMA_CHANGE_REVIEW"
        )

    return {
        "schema_status":
            schema_status,
        "diff":
            diff,
        "added_files":
            added_files,
        "missing_files":
            missing_files,
        "changed_files":
            changed_files,
        "blocking_changes":
            blocking_changes,
        "review_changes":
            review_changes,
        "issues":
            issues,
    }


def build_schema_migration_dry_run(
    comparison: dict | None,
) -> pd.DataFrame:
    result = comparison or {}
    diff = result.get(
        "diff"
    )

    if (
        not isinstance(
            diff,
            pd.DataFrame,
        )
        or diff.empty
    ):
        return pd.DataFrame(
            columns=[
                "file",
                "migration_type",
                "dry_run_action",
                "risk",
                "auto_apply",
            ]
        )

    action_map = {
        "CURRENT":
            (
                "NO_CHANGE",
                "LOW",
            ),
        "FILE_ADDED":
            (
                "REVIEW_NEW_FILE_AND_OPTIONALLY_REFRESH_BASELINE",
                "LOW",
            ),
        "ADDITIVE_COLUMNS":
            (
                "REVIEW_ADDITIVE_COLUMNS_AND_OPTIONALLY_REFRESH_BASELINE",
                "LOW",
            ),
        "COLUMN_ORDER_CHANGED":
            (
                "VERIFY_READERS_ARE_NAME_BASED_BEFORE_BASELINE_REFRESH",
                "MEDIUM",
            ),
        "FILE_MISSING":
            (
                "RESTORE_OR_EXPLAIN_MISSING_FILE_BEFORE_ANY_MIGRATION",
                "HIGH",
            ),
        "MISSING_COLUMNS":
            (
                "RESTORE_MISSING_COLUMNS_OR_CREATE_EXPLICIT_MIGRATION_PLAN",
                "HIGH",
            ),
        "BREAKING_SCHEMA":
            (
                "REQUIRE_EXPLICIT_RENAME_TRANSFORM_MIGRATION_PLAN",
                "HIGH",
            ),
    }

    rows = []

    for _, row in diff.iterrows():
        migration_type = _text(
            row.get(
                "migration_type"
            )
        )
        action, risk = action_map.get(
            migration_type,
            (
                "HUMAN_REVIEW",
                "MEDIUM",
            ),
        )

        rows.append(
            {
                "file":
                    _text(
                        row.get(
                            "file"
                        )
                    ),
                "migration_type":
                    migration_type,
                "dry_run_action":
                    action,
                "risk":
                    risk,
                "auto_apply":
                    "NO",
            }
        )

    return pd.DataFrame(
        rows
    )


def validate_schema_baseline_lock(
    scan: pd.DataFrame | None,
    comparison: dict | None,
    existing_baseline: dict | None,
    *,
    schema_review_confirmed: bool,
    no_auto_migration_confirmed: bool,
    no_destructive_change_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    scan_summary = schema_scan_summary(
        scan
    )
    compare = comparison or {}
    existing = existing_baseline or {}
    issues = []

    if scan_summary[
        "scan_integrity_status"
    ] != "PASS":
        issues.append(
            "SCHEMA_SCAN_INTEGRITY_PASS_REQUIRED"
        )

    if _text(
        compare.get(
            "schema_status"
        )
    ).upper() == "BLOCKED":
        issues.append(
            "BLOCKING_SCHEMA_DRIFT_MUST_BE_RESOLVED"
        )

    if existing:
        current_snapshot_hash = build_schema_snapshot(
            scan
        )[
            "snapshot_hash"
        ]
        existing_snapshot_hash = _text(
            existing.get(
                "schema_snapshot_hash"
            )
        )

        existing_integrity = schema_baseline_integrity(
            existing
        )[
            "status"
        ]

        if (
            existing_integrity
            == "OK"
            and current_snapshot_hash
            == existing_snapshot_hash
        ):
            issues.append(
                "CURRENT_SCHEMA_ALREADY_LOCKED"
            )

    confirmations = [
        (
            schema_review_confirmed,
            "SCHEMA_REVIEW_CONFIRMATION_REQUIRED",
        ),
        (
            no_auto_migration_confirmed,
            "NO_AUTO_MIGRATION_CONFIRMATION_REQUIRED",
        ),
        (
            no_destructive_change_confirmed,
            "NO_DESTRUCTIVE_CHANGE_CONFIRMATION_REQUIRED",
        ),
        (
            human_review_confirmed,
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED",
        ),
    ]

    for passed, issue in confirmations:
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    blocking = [
        issue
        for issue in issues
        if issue
        != "CURRENT_SCHEMA_ALREADY_LOCKED"
    ]

    if (
        existing
        and "CURRENT_SCHEMA_ALREADY_LOCKED"
        in issues
        and not blocking
    ):
        gate = "REVIEW"
        status = "ALREADY_LOCKED"
    elif not issues:
        gate = "PASS"
        status = "SCHEMA_BASELINE_LOCKED"
    else:
        gate = "REVIEW"
        status = "DRAFT"

    return {
        "baseline_gate":
            gate,
        "baseline_status":
            status,
        "migration_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def build_schema_baseline_lock_record(
    scan: pd.DataFrame,
    validation: dict,
    *,
    schema_review_confirmed: bool,
    no_auto_migration_confirmed: bool,
    no_destructive_change_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    scan_summary = schema_scan_summary(
        scan
    )
    snapshot = build_schema_snapshot(
        scan
    )

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    baseline_id = (
        "SBL-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot[
            "snapshot_hash"
        ][
            :8
        ]
    )

    row = {
        "schema_baseline_id":
            baseline_id,
        "created_at":
            now,
        "file_count":
            scan_summary[
                "file_count"
            ],
        "total_columns":
            scan_summary[
                "total_columns"
            ],
        "schema_snapshot_json":
            snapshot[
                "snapshot_json"
            ],
        "schema_snapshot_hash":
            snapshot[
                "snapshot_hash"
            ],
        "scan_integrity_status":
            scan_summary[
                "scan_integrity_status"
            ],
        "baseline_gate":
            _text(
                validation.get(
                    "baseline_gate"
                )
            ),
        "baseline_status":
            _text(
                validation.get(
                    "baseline_status"
                )
            ),
        "schema_review_confirmed":
            bool(
                schema_review_confirmed
            ),
        "no_auto_migration_confirmed":
            bool(
                no_auto_migration_confirmed
            ),
        "no_destructive_change_confirmed":
            bool(
                no_destructive_change_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "migration_authorization":
            "NONE",
        "issues":
            " | ".join(
                validation.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _baseline_payload(
            row
        )
    )

    return row


def build_schema_review_queue(
    scan: pd.DataFrame | None,
    baseline: dict | None,
    comparison: dict | None,
) -> pd.DataFrame:
    scan_summary = schema_scan_summary(
        scan
    )
    compare = comparison or {}
    rows = []

    if scan_summary[
        "scan_integrity_status"
    ] != "PASS":
        for issue in scan_summary[
            "issues"
        ]:
            rows.append(
                {
                    "priority":
                        "SG0",
                    "status":
                        "BLOCKED",
                    "issue":
                        issue,
                    "file":
                        "",
                    "next_action":
                        "Save Center에서 CSV header/duplicate column 문제를 먼저 확인",
                    "go_to":
                        "Save Center",
                }
            )

    if baseline:
        integrity = schema_baseline_integrity(
            baseline
        )

        if integrity[
            "status"
        ] != "OK":
            rows.append(
                {
                    "priority":
                        "SG0",
                    "status":
                        "BLOCKED",
                    "issue":
                        "SCHEMA_BASELINE_HASH_INTEGRITY_FAILED",
                    "file":
                        "",
                    "next_action":
                        "Schema Baseline Lock immutable hash 무결성 확인",
                    "go_to":
                        "Save Center",
                }
            )
    else:
        rows.append(
            {
                "priority":
                    "SG1",
                "status":
                    "REVIEW",
                "issue":
                    "SCHEMA_BASELINE_MISSING",
                "file":
                    "",
                "next_action":
                    "현재 정상 CSV schema를 Human Review 후 Baseline Lock",
                "go_to":
                    "Save Center",
            }
        )

    diff = compare.get(
        "diff"
    )

    if (
        isinstance(
            diff,
            pd.DataFrame,
        )
        and not diff.empty
    ):
        changed = diff.loc[
            diff[
                "migration_type"
            ]
            .ne(
                "CURRENT"
            )
        ]

        for _, row in changed.iterrows():
            blocked = _text(
                row.get(
                    "status"
                )
            ).upper() == "BLOCKED"

            rows.append(
                {
                    "priority":
                        (
                            "SG0"
                            if blocked
                            else "SG2"
                        ),
                    "status":
                        (
                            "BLOCKED"
                            if blocked
                            else "REVIEW"
                        ),
                    "issue":
                        _text(
                            row.get(
                                "migration_type"
                            )
                        ),
                    "file":
                        _text(
                            row.get(
                                "file"
                            )
                        ),
                    "next_action":
                        (
                            "명시적 migration plan 없이 자동 변경하지 말고 원본 schema를 복구/검토"
                            if blocked
                            else "Additive/order change를 확인하고 필요 시 새 Baseline Lock"
                        ),
                    "go_to":
                        "Save Center",
                }
            )

    if not rows:
        return pd.DataFrame(
            columns=
            SCHEMA_QUEUE_COLS
        )

    order = {
        "SG0": 0,
        "SG1": 1,
        "SG2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out[
        "_p"
    ] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "file",
                "issue",
            ]
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            SCHEMA_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )
