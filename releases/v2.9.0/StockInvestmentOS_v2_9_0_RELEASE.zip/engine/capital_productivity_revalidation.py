from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.capital_productivity import (
    CAPITAL_PRODUCTIVITY_INPUT_COLS,
    normalize_capital_productivity_inputs,
    normalize_calibration_drafts,
)


REVALIDATION_COLS = [
    "revalidation_id",
    "reviewed_at",
    "name",
    "ticker",
    "kind",
    "provenance_type",
    "health_status_before",
    "current_review_due_date",
    "new_review_due_date",
    "days_extended",
    "forward_er",
    "risk_penalty",
    "hurdle_rate",
    "risk_adjusted_er",
    "hurdle_spread",
    "assumption_fingerprint",
    "approved_calibration_id",
    "calibration_hash_status",
    "reference_status",
    "input_match_status",
    "eligibility_status",
    "eligibility_reason",
    "review_basis",
    "same_horizon_confirmed",
    "current_reference_confirmed",
    "no_material_change_confirmed",
    "assumption_values_unchanged_confirmed",
    "human_confirmed",
    "governance_gate",
    "final_decision",
    "execution_authorization",
    "note",
    "hash_schema",
    "prior_revalidation_id",
    "prior_revalidation_hash",
    "content_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _stable_num(value: Any, places: int = 12) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _hash(payload: dict) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def assumption_fingerprint(
    input_row: dict | None,
) -> str:
    """
    Fingerprint only the economic assumption values.
    Review date / source note are intentionally excluded so a clean renewal
    does not look like an economic assumption change.
    """
    row = input_row or {}
    payload = {
        "name": _text(row.get("name")),
        "ticker": _text(row.get("ticker")),
        "kind": _text(row.get("kind")).upper(),
        "forward_er": _stable_num(row.get("forward_er")),
        "risk_penalty": _stable_num(row.get("risk_penalty")),
        "hurdle_rate": _stable_num(row.get("hurdle_rate")),
        "capacity_headroom_krw": _stable_num(
            row.get("capacity_headroom_krw"),
            places=2,
        ),
    }
    return _hash(payload)


def normalize_revalidations(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()

    out = df.copy()
    for col in REVALIDATION_COLS:
        if col not in out.columns:
            out[col] = ""

    numeric_cols = [
        "days_extended",
        "forward_er",
        "risk_penalty",
        "hurdle_rate",
        "risk_adjusted_er",
        "hurdle_spread",
    ]
    bool_cols = [
        "same_horizon_confirmed",
        "current_reference_confirmed",
        "no_material_change_confirmed",
        "assumption_values_unchanged_confirmed",
        "human_confirmed",
    ]

    for col in numeric_cols:
        out[col] = pd.to_numeric(
            out[col],
            errors="coerce",
        )
    for col in bool_cols:
        out[col] = out[col].map(_bool).astype(bool)

    for col in REVALIDATION_COLS:
        if col not in numeric_cols and col not in bool_cols:
            out[col] = out[col].map(_text).astype("object")

    return out[REVALIDATION_COLS].copy()


def _lookup_row(
    df: pd.DataFrame | None,
    name: str,
) -> dict:
    if df is None or df.empty:
        return {}
    if "name" not in df.columns:
        return {}

    hit = df.loc[
        df["name"].fillna("").astype(str).str.strip().eq(_text(name))
    ]
    if hit.empty:
        return {}
    return hit.iloc[-1].to_dict()


def _latest_approved_operating_draft(
    drafts: pd.DataFrame | None,
    name: str,
    ticker: str,
) -> dict:
    df = normalize_calibration_drafts(drafts)
    if df.empty:
        return {}

    hit = df.loc[
        df["name"].fillna("").astype(str).str.strip().eq(_text(name))
        & df["approval_status"].fillna("").astype(str).str.upper().eq("APPROVED")
        & df["purpose"].fillna("").astype(str).str.upper().eq("OPERATING_ASSUMPTION")
    ].copy()
    if hit.empty:
        return {}

    ticker_text = _text(ticker)
    if ticker_text:
        ticker_hit = hit.loc[
            hit["ticker"].fillna("").astype(str).str.strip().eq(ticker_text)
        ]
        if not ticker_hit.empty:
            hit = ticker_hit.copy()

    sort_key = pd.Series(
        pd.NaT,
        index=hit.index,
        dtype="datetime64[ns, UTC]",
    )
    for col in ["approved_at", "updated_at", "created_at"]:
        if col in hit.columns:
            sort_key = sort_key.fillna(
                pd.to_datetime(
                    hit[col],
                    errors="coerce",
                    utc=True,
                )
            )
    hit["_sort"] = sort_key
    hit = hit.sort_values(
        "_sort",
        ascending=False,
        na_position="last",
    )

    return hit.iloc[0].drop(
        labels=["_sort"],
        errors="ignore",
    ).to_dict()


def build_revalidation_context(
    universe: pd.DataFrame | None,
    health: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    target_name: str,
    *,
    today: date | None = None,
) -> dict:
    """
    Decide whether an existing reviewed assumption can be renewed without
    changing Forward ER / Risk Penalty / Hurdle.

    PASS or EXPIRED can be renewal-eligible when provenance integrity is clean.
    Drift / mismatch / unreviewed states require re-calibration or first review.
    """
    current_date = today or date.today()
    name = _text(target_name)

    input_row = _lookup_row(
        universe,
        name,
    )
    health_row = _lookup_row(
        health,
        name,
    )

    issues = []

    if not input_row:
        issues.append("ASSUMPTION_INPUT_NOT_FOUND")
    if not health_row:
        issues.append("ASSUMPTION_HEALTH_NOT_FOUND")

    provenance = _text(
        health_row.get("provenance_type")
    ).upper()
    health_status = _text(
        health_row.get("health_status")
    ).upper()

    if provenance == "UNREVIEWED":
        issues.append("FIRST_ASSUMPTION_REVIEW_REQUIRED")

    if health_status in {
        "REFERENCE_DRIFT",
        "INPUT_MISMATCH",
        "HASH_MISMATCH",
        "REVIEW",
    }:
        mapping = {
            "REFERENCE_DRIFT": "RECALIBRATION_REQUIRED_REFERENCE_DRIFT",
            "INPUT_MISMATCH": "ASSUMPTION_RECONCILIATION_REQUIRED",
            "HASH_MISMATCH": "CALIBRATION_INTEGRITY_REVIEW_REQUIRED",
            "REVIEW": "ASSUMPTION_REVIEW_INCOMPLETE",
        }
        issues.append(mapping[health_status])

    if health_status not in {"PASS", "EXPIRED"}:
        if health_status and not issues:
            issues.append("HEALTH_STATUS_NOT_REVALIDATABLE")

    calibration_id = _text(
        health_row.get("approved_calibration_id")
    )
    calibration_hash_status = _text(
        health_row.get("calibration_hash_status")
    ).upper()
    reference_status = _text(
        health_row.get("reference_status")
    ).upper()
    input_match_status = _text(
        health_row.get("input_match_status")
    ).upper()

    if provenance == "APPROVED_CALIBRATION":
        if not calibration_id:
            issues.append("APPROVED_CALIBRATION_ID_REQUIRED")
        if calibration_hash_status != "OK":
            issues.append("CALIBRATION_HASH_NOT_OK")
        if reference_status != "MATCH":
            issues.append("REFERENCE_MATCH_REQUIRED")
        if input_match_status != "MATCH":
            issues.append("APPROVED_INPUT_MATCH_REQUIRED")

        draft = _latest_approved_operating_draft(
            calibration_drafts,
            name,
            _text(input_row.get("ticker")),
        )
        if not draft:
            issues.append("APPROVED_OPERATING_DRAFT_NOT_FOUND")
    else:
        draft = {}

    reviewed = _bool(input_row.get("reviewed"))
    if not reviewed:
        issues.append("HUMAN_REVIEW_REQUIRED")

    current_due_ts = pd.to_datetime(
        input_row.get("review_due_date"),
        errors="coerce",
    )
    current_due = (
        None
        if pd.isna(current_due_ts)
        else current_due_ts.date()
    )
    days_to_due = (
        None
        if current_due is None
        else (current_due - current_date).days
    )

    fingerprint = (
        assumption_fingerprint(input_row)
        if input_row
        else ""
    )

    eligibility = (
        "PASS"
        if not issues
        else "BLOCKED"
    )

    if eligibility == "PASS":
        if health_status == "EXPIRED":
            eligibility_reason = "EXPIRED_BUT_REFERENCE_CLEAN"
        else:
            eligibility_reason = "CURRENT_ASSUMPTION_REFERENCE_CLEAN"
    else:
        eligibility_reason = " | ".join(
            list(dict.fromkeys(issues))
        )

    forward_er = _num(input_row.get("forward_er"))
    risk_penalty = _num(input_row.get("risk_penalty"))
    hurdle = _num(input_row.get("hurdle_rate"))
    risk_adjusted = (
        forward_er - risk_penalty
        if (
            forward_er is not None
            and risk_penalty is not None
        )
        else None
    )
    hurdle_spread = (
        risk_adjusted - hurdle
        if (
            risk_adjusted is not None
            and hurdle is not None
        )
        else None
    )

    return {
        "name": name,
        "ticker": _text(input_row.get("ticker")),
        "kind": _text(input_row.get("kind")).upper(),
        "provenance_type": provenance,
        "health_status": health_status,
        "reviewed": reviewed,
        "current_review_due_date": (
            current_due.isoformat()
            if current_due is not None
            else ""
        ),
        "days_to_due": days_to_due,
        "forward_er": forward_er,
        "risk_penalty": risk_penalty,
        "hurdle_rate": hurdle,
        "risk_adjusted_er": risk_adjusted,
        "hurdle_spread": hurdle_spread,
        "capacity_headroom_krw": _num(
            input_row.get("capacity_headroom_krw")
        ),
        "source": _text(input_row.get("source")),
        "note": _text(input_row.get("note")),
        "assumption_fingerprint": fingerprint,
        "approved_calibration_id": calibration_id,
        "calibration_hash_status": calibration_hash_status or "N/A",
        "reference_status": reference_status or "N/A",
        "input_match_status": input_match_status or "N/A",
        "latest_revalidation_id": _text(
            health_row.get("latest_revalidation_id")
        ),
        "revalidation_hash_status": _text(
            health_row.get("revalidation_hash_status")
        ) or "N/A",
        "revalidation_lineage_status": _text(
            health_row.get("revalidation_lineage_status")
        ) or "N/A",
        "eligibility_status": eligibility,
        "eligibility_reason": eligibility_reason,
        "execution_authorization": "NONE",
    }


def validate_revalidation(
    context: dict,
    *,
    new_review_due_date: date | str | None,
    review_basis: str,
    same_horizon_confirmed: bool,
    current_reference_confirmed: bool,
    no_material_change_confirmed: bool,
    assumption_values_unchanged_confirmed: bool,
    human_confirmed: bool,
    max_extension_days: int = 90,
    today: date | None = None,
) -> dict:
    current_date = today or date.today()
    ctx = context or {}
    issues = []

    if _text(
        ctx.get("eligibility_status")
    ).upper() != "PASS":
        issues.append("REVALIDATION_NOT_ELIGIBLE")

    if not _text(review_basis):
        issues.append("REVALIDATION_BASIS_REQUIRED")

    new_due = None
    try:
        if isinstance(new_review_due_date, date):
            new_due = new_review_due_date
        else:
            parsed = pd.to_datetime(
                new_review_due_date,
                errors="coerce",
            )
            if not pd.isna(parsed):
                new_due = parsed.date()
    except Exception:
        new_due = None

    if new_due is None:
        issues.append("NEW_REVIEW_DUE_DATE_REQUIRED")
    elif new_due <= current_date:
        issues.append("NEW_REVIEW_DUE_DATE_NOT_FUTURE")
    else:
        if (
            new_due - current_date
        ).days > int(max_extension_days):
            issues.append("NEW_REVIEW_DUE_BEYOND_POLICY_MAX")

    current_due_ts = pd.to_datetime(
        ctx.get("current_review_due_date"),
        errors="coerce",
    )
    current_due = (
        None
        if pd.isna(current_due_ts)
        else current_due_ts.date()
    )

    if (
        new_due is not None
        and current_due is not None
        and current_due >= current_date
        and new_due <= current_due
    ):
        issues.append("NEW_REVIEW_DUE_MUST_EXTEND_CURRENT_DUE")

    confirmations = {
        "SAME_HORIZON_CONFIRMATION_REQUIRED": same_horizon_confirmed,
        "CURRENT_REFERENCE_CONFIRMATION_REQUIRED": current_reference_confirmed,
        "NO_MATERIAL_CHANGE_CONFIRMATION_REQUIRED": no_material_change_confirmed,
        "ASSUMPTION_VALUES_UNCHANGED_CONFIRMATION_REQUIRED":
            assumption_values_unchanged_confirmed,
        "HUMAN_REVALIDATION_CONFIRMATION_REQUIRED": human_confirmed,
    }
    for issue, passed in confirmations.items():
        if not _bool(passed):
            issues.append(issue)

    gate = "PASS" if not issues else "REVIEW"

    return {
        "governance_gate": gate,
        "final_decision": (
            "ASSUMPTION REVALIDATION COMPLETE"
            if gate == "PASS"
            else "HUMAN REVIEW REQUIRED"
        ),
        "new_review_due_date": (
            new_due.isoformat()
            if new_due is not None
            else ""
        ),
        "max_extension_days": int(max_extension_days),
        "execution_authorization": "NONE",
        "issues": issues,
    }


def _legacy_v1_revalidation_payload(row: dict) -> dict:
    """Original dev3 hash payload for backward compatibility."""
    return {
        "name": _text(row.get("name")),
        "ticker": _text(row.get("ticker")),
        "provenance_type": _text(row.get("provenance_type")),
        "health_status_before": _text(row.get("health_status_before")),
        "current_review_due_date": _text(row.get("current_review_due_date")),
        "new_review_due_date": _text(row.get("new_review_due_date")),
        "assumption_fingerprint": _text(row.get("assumption_fingerprint")),
        "approved_calibration_id": _text(row.get("approved_calibration_id")),
        "review_basis": _text(row.get("review_basis")),
        "reviewed_at": _text(row.get("reviewed_at")),
    }


def _v2_revalidation_payload(row: dict) -> dict:
    """Immutable renewal content + previous-record link."""
    return {
        "hash_schema": "v2",
        "reviewed_at": _text(row.get("reviewed_at")),
        "name": _text(row.get("name")),
        "ticker": _text(row.get("ticker")),
        "kind": _text(row.get("kind")),
        "provenance_type": _text(row.get("provenance_type")),
        "health_status_before": _text(row.get("health_status_before")),
        "current_review_due_date": _text(row.get("current_review_due_date")),
        "new_review_due_date": _text(row.get("new_review_due_date")),
        "assumption_fingerprint": _text(row.get("assumption_fingerprint")),
        "approved_calibration_id": _text(row.get("approved_calibration_id")),
        "calibration_hash_status": _text(row.get("calibration_hash_status")),
        "reference_status": _text(row.get("reference_status")),
        "input_match_status": _text(row.get("input_match_status")),
        "eligibility_status": _text(row.get("eligibility_status")),
        "eligibility_reason": _text(row.get("eligibility_reason")),
        "review_basis": _text(row.get("review_basis")),
        "same_horizon_confirmed": bool(_bool(row.get("same_horizon_confirmed"))),
        "current_reference_confirmed": bool(_bool(row.get("current_reference_confirmed"))),
        "no_material_change_confirmed": bool(_bool(row.get("no_material_change_confirmed"))),
        "assumption_values_unchanged_confirmed":
            bool(_bool(row.get("assumption_values_unchanged_confirmed"))),
        "human_confirmed": bool(_bool(row.get("human_confirmed"))),
        "governance_gate": _text(row.get("governance_gate")),
        "final_decision": _text(row.get("final_decision")),
        "execution_authorization": _text(row.get("execution_authorization")),
        "note": _text(row.get("note")),
        "prior_revalidation_id": _text(row.get("prior_revalidation_id")),
        "prior_revalidation_hash": _text(row.get("prior_revalidation_hash")),
    }


def revalidation_record_integrity(row: dict | None) -> str:
    record = row or {}
    stored = _text(record.get("content_hash"))
    if not stored:
        return "MISSING"

    schema = _text(record.get("hash_schema")).lower()
    payload = (
        _v2_revalidation_payload(record)
        if schema == "v2"
        else _legacy_v1_revalidation_payload(record)
    )
    return "OK" if _hash(payload) == stored else "MISMATCH"


def _revalidation_rows_for_subject(
    revalidations: pd.DataFrame | None,
    name: str,
    ticker: str = "",
) -> pd.DataFrame:
    df = normalize_revalidations(revalidations)
    if df.empty:
        return df

    hit = df.loc[
        df["name"].fillna("").astype(str).str.strip().eq(_text(name))
        & df["governance_gate"].fillna("").astype(str).str.upper().eq("PASS")
    ].copy()

    ticker_text = _text(ticker)
    if ticker_text and not hit.empty:
        ticker_hit = hit.loc[
            hit["ticker"].fillna("").astype(str).str.strip().eq(ticker_text)
        ].copy()
        if not ticker_hit.empty:
            hit = ticker_hit

    if hit.empty:
        return hit

    hit["_sort"] = pd.to_datetime(
        hit["reviewed_at"],
        errors="coerce",
        utc=True,
    )
    return hit.sort_values("_sort", ascending=True, na_position="last")


def latest_revalidation_record(
    revalidations: pd.DataFrame | None,
    name: str,
    ticker: str = "",
) -> dict:
    hit = _revalidation_rows_for_subject(revalidations, name, ticker)
    if hit.empty:
        return {}
    return hit.iloc[-1].drop(labels=["_sort"], errors="ignore").to_dict()


def revalidation_lineage_integrity(
    revalidations: pd.DataFrame | None,
    name: str,
    ticker: str = "",
) -> dict:
    """
    Verify record hashes and v2 prior-record links.
    A valid dev3 legacy record can serve as the root of a later v2 chain.
    """
    hit = _revalidation_rows_for_subject(revalidations, name, ticker)
    if hit.empty:
        return {
            "status": "NO_RECORD",
            "record_count": 0,
            "latest_revalidation_id": "",
            "latest_hash_status": "N/A",
            "issues": [],
        }

    issues = []
    previous = None

    for _, srow in hit.iterrows():
        current = srow.drop(labels=["_sort"], errors="ignore").to_dict()
        integrity = revalidation_record_integrity(current)
        current_id = _text(current.get("revalidation_id"))

        if integrity != "OK":
            issues.append(f"REVALIDATION_HASH_MISMATCH:{current_id}")

        if _text(current.get("hash_schema")).lower() == "v2":
            prior_id = _text(current.get("prior_revalidation_id"))
            prior_hash = _text(current.get("prior_revalidation_hash"))

            if previous is None:
                if prior_id or prior_hash:
                    issues.append("REVALIDATION_LINEAGE_UNEXPECTED_PRIOR")
            else:
                if (
                    prior_id != _text(previous.get("revalidation_id"))
                    or prior_hash != _text(previous.get("content_hash"))
                ):
                    issues.append(
                        f"REVALIDATION_LINEAGE_PRIOR_MISMATCH:{current_id}"
                    )
        previous = current

    latest = previous or {}
    return {
        "status": "OK" if not issues else "MISMATCH",
        "record_count": int(len(hit)),
        "latest_revalidation_id": _text(latest.get("revalidation_id")),
        "latest_hash_status": (
            revalidation_record_integrity(latest)
            if latest
            else "N/A"
        ),
        "issues": issues,
    }


def post_revalidation_integrity(
    input_row: dict | None,
    revalidations: pd.DataFrame | None,
) -> dict:
    """
    Compare live Assumption against latest completed renewal record.
    """
    live = input_row or {}
    name = _text(live.get("name"))
    ticker = _text(live.get("ticker"))
    source = _text(live.get("source"))
    note = _text(live.get("note"))

    latest = latest_revalidation_record(revalidations, name, ticker)

    if not latest:
        marker = (
            "Assumption Revalidation" in source
            or "REVALIDATION_ID=" in note
        )
        return {
            "status": "REVALIDATION_RECORD_MISSING" if marker else "N/A",
            "latest_revalidation_id": "",
            "revalidation_hash_status": "N/A",
            "lineage_chain_status": "NO_RECORD",
            "issues": ["REVALIDATION_RECORD_MISSING"] if marker else [],
        }

    chain = revalidation_lineage_integrity(revalidations, name, ticker)
    latest_id = _text(latest.get("revalidation_id"))
    hash_status = revalidation_record_integrity(latest)

    if hash_status != "OK" or chain["status"] != "OK":
        return {
            "status": "REVALIDATION_HASH_MISMATCH",
            "latest_revalidation_id": latest_id,
            "revalidation_hash_status": hash_status,
            "lineage_chain_status": chain["status"],
            "issues": (
                ["REVALIDATION_HASH_MISMATCH"]
                + list(chain.get("issues", []))
            ),
        }

    issues = []
    if assumption_fingerprint(live) != _text(latest.get("assumption_fingerprint")):
        issues.append("POST_REVALIDATION_ASSUMPTION_FINGERPRINT_MISMATCH")

    live_due = pd.to_datetime(live.get("review_due_date"), errors="coerce")
    expected_due = pd.to_datetime(
        latest.get("new_review_due_date"),
        errors="coerce",
    )
    if (
        pd.isna(live_due)
        or pd.isna(expected_due)
        or live_due.date() != expected_due.date()
    ):
        issues.append("POST_REVALIDATION_REVIEW_DUE_MISMATCH")

    if (
        latest_id
        and latest_id not in source
        and latest_id not in note
    ):
        issues.append("POST_REVALIDATION_PROVENANCE_MISSING")

    return {
        "status": (
            "REVALIDATION_MATCH"
            if not issues
            else "POST_REVALIDATION_INPUT_MISMATCH"
        ),
        "latest_revalidation_id": latest_id,
        "revalidation_hash_status": hash_status,
        "lineage_chain_status": chain["status"],
        "issues": issues,
    }


def build_revalidation_record(
    context: dict,
    governance: dict,
    *,
    review_basis: str,
    same_horizon_confirmed: bool,
    current_reference_confirmed: bool,
    no_material_change_confirmed: bool,
    assumption_values_unchanged_confirmed: bool,
    human_confirmed: bool,
    note: str = "",
    reviewed_at: str | None = None,
    revalidation_history: pd.DataFrame | None = None,
) -> dict:
    ctx = context or {}
    gov = governance or {}

    now = _text(reviewed_at) or datetime.now().isoformat()
    current_due_ts = pd.to_datetime(
        ctx.get("current_review_due_date"),
        errors="coerce",
    )
    new_due_ts = pd.to_datetime(
        gov.get("new_review_due_date"),
        errors="coerce",
    )

    days_extended = None
    if not pd.isna(current_due_ts) and not pd.isna(new_due_ts):
        days_extended = (new_due_ts.date() - current_due_ts.date()).days

    prior = latest_revalidation_record(
        revalidation_history,
        _text(ctx.get("name")),
        _text(ctx.get("ticker")),
    )

    row = {
        "revalidation_id": "",
        "reviewed_at": now,
        "name": _text(ctx.get("name")),
        "ticker": _text(ctx.get("ticker")),
        "kind": _text(ctx.get("kind")),
        "provenance_type": _text(ctx.get("provenance_type")),
        "health_status_before": _text(ctx.get("health_status")),
        "current_review_due_date": _text(ctx.get("current_review_due_date")),
        "new_review_due_date": _text(gov.get("new_review_due_date")),
        "days_extended": days_extended,
        "forward_er": _num(ctx.get("forward_er")),
        "risk_penalty": _num(ctx.get("risk_penalty")),
        "hurdle_rate": _num(ctx.get("hurdle_rate")),
        "risk_adjusted_er": _num(ctx.get("risk_adjusted_er")),
        "hurdle_spread": _num(ctx.get("hurdle_spread")),
        "assumption_fingerprint": _text(ctx.get("assumption_fingerprint")),
        "approved_calibration_id": _text(ctx.get("approved_calibration_id")),
        "calibration_hash_status": _text(ctx.get("calibration_hash_status")),
        "reference_status": _text(ctx.get("reference_status")),
        "input_match_status": _text(ctx.get("input_match_status")),
        "eligibility_status": _text(ctx.get("eligibility_status")),
        "eligibility_reason": _text(ctx.get("eligibility_reason")),
        "review_basis": _text(review_basis),
        "same_horizon_confirmed": bool(same_horizon_confirmed),
        "current_reference_confirmed": bool(current_reference_confirmed),
        "no_material_change_confirmed": bool(no_material_change_confirmed),
        "assumption_values_unchanged_confirmed":
            bool(assumption_values_unchanged_confirmed),
        "human_confirmed": bool(human_confirmed),
        "governance_gate": _text(gov.get("governance_gate")),
        "final_decision": _text(gov.get("final_decision")),
        "execution_authorization": "NONE",
        "note": _text(note),
        "hash_schema": "v2",
        "prior_revalidation_id": _text(prior.get("revalidation_id")),
        "prior_revalidation_hash": _text(prior.get("content_hash")),
        "content_hash": "",
    }

    content_hash = _hash(_v2_revalidation_payload(row))
    stamp = pd.to_datetime(now, errors="coerce", utc=True)
    stamp_text = (
        datetime.now().strftime("%Y%m%dT%H%M%S")
        if pd.isna(stamp)
        else pd.Timestamp(stamp).strftime("%Y%m%dT%H%M%S")
    )
    row["revalidation_id"] = f"CPR-{stamp_text}-{content_hash[:10]}"
    row["content_hash"] = content_hash
    return row


def apply_revalidation(
    inputs: pd.DataFrame | None,
    context: dict,
    record: dict,
) -> tuple[pd.DataFrame, dict]:
    """
    Renew review clock only. Economic assumption values must match the reviewed
    fingerprint; Forward ER / Risk Penalty / Hurdle are never changed here.
    """
    current = normalize_capital_productivity_inputs(inputs)
    ctx = context or {}
    rec = record or {}

    name = _text(ctx.get("name"))
    hit = current.loc[
        current["name"].fillna("").astype(str).str.strip().eq(name)
    ].copy()
    if hit.empty:
        return current, {
            "status": "REVIEW",
            "issues": ["ASSUMPTION_INPUT_NOT_FOUND"],
        }

    idx = hit.index[-1]
    live = current.loc[idx].to_dict()

    issues = []

    if revalidation_record_integrity(rec) != "OK":
        issues.append("REVALIDATION_RECORD_HASH_NOT_OK")

    if assumption_fingerprint(live) != _text(
        ctx.get("assumption_fingerprint")
    ):
        issues.append("ASSUMPTION_VALUES_CHANGED_SINCE_REVALIDATION_REVIEW")

    if _text(rec.get("governance_gate")).upper() != "PASS":
        issues.append("REVALIDATION_GATE_NOT_PASS")

    new_due = pd.to_datetime(
        rec.get("new_review_due_date"),
        errors="coerce",
    )
    if pd.isna(new_due):
        issues.append("NEW_REVIEW_DUE_DATE_REQUIRED")

    if issues:
        return current, {
            "status": "REVIEW",
            "issues": issues,
        }

    # Only renewal metadata changes.
    current.loc[idx, "review_due_date"] = new_due
    current.loc[idx, "reviewed"] = True

    existing_source = _text(current.loc[idx, "source"])
    provenance = (
        "Assumption Revalidation"
        f" | ID:{_text(rec.get('revalidation_id'))}"
        f" | Due:{_text(rec.get('new_review_due_date'))}"
    )
    if provenance not in existing_source:
        current.loc[idx, "source"] = (
            existing_source
            + (" | " if existing_source else "")
            + provenance
        )

    existing_note = _text(current.loc[idx, "note"])
    note_text = (
        "ASSUMPTION_REVALIDATED_WITHOUT_VALUE_CHANGE;"
        f" REVALIDATION_ID={_text(rec.get('revalidation_id'))}"
    )
    current.loc[idx, "note"] = (
        existing_note
        + ("; " if existing_note else "")
        + note_text
    )
    current.loc[idx, "updated_at"] = datetime.now().isoformat()

    return normalize_capital_productivity_inputs(current), {
        "status": "PASS",
        "issues": [],
        "revalidation_id": _text(rec.get("revalidation_id")),
        "execution_authorization": "NONE",
    }
