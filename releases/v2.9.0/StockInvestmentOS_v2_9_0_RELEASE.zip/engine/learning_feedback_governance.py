from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.decision_learning_lineage import (
    decision_learning_lineage_integrity,
)


LEARNING_FEEDBACK_TARGETS = [
    "THESIS",
    "FORWARD_ER",
    "RISK_PENALTY",
    "HURDLE",
    "POSITION_SIZE",
    "PROCESS",
    "EVIDENCE_MONITOR",
    "NO_CHANGE",
]

LEARNING_FEEDBACK_DIRECTIONS = [
    "REVIEW_ONLY",
    "INCREASE",
    "DECREASE",
    "NO_CHANGE",
]

LEARNING_FEEDBACK_COLS = [
    "feedback_id",
    "created_at",
    "company",
    "source_learning_lineage_id",
    "source_learning_lineage_hash",
    "source_integrity_status",
    "source_learning_status",
    "packet_id",
    "fill_id",
    "decision_id",
    "outcome_review_id",
    "outcome_classification",
    "forecast_error_class",
    "process_adherence",
    "review_lane",
    "feedback_target",
    "change_direction",
    "proposed_delta",
    "review_due_date",
    "rationale",
    "expected_vs_actual_confirmed",
    "no_auto_apply_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "proposal_gate",
    "proposal_status",
    "next_gate",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _stable_num(
    value: Any,
    places: int = 12,
) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _error_review_lane(
    forecast_error_class: str,
) -> str:
    error = _text(
        forecast_error_class
    ).upper()

    if error == "MODEL":
        return "MODEL_REVIEW"
    if error == "PARAMETER":
        return "ASSUMPTION_REVALIDATION"
    if error == "EXECUTION":
        return "PROCESS_REVIEW"
    if error == "EXOGENOUS":
        return "EVIDENCE_REGIME_REVIEW"
    if error in {
        "NONE",
        "NO_ERROR",
        "NO ERROR",
        "N/A",
        "NA",
    }:
        return "NO_CHANGE_REVIEW"
    return "CLASSIFICATION_REVIEW"


def _target_next_gate(
    target: str,
) -> str:
    target = _text(
        target
    ).upper()

    if target in {
        "FORWARD_ER",
        "RISK_PENALTY",
        "HURDLE",
    }:
        return "ASSUMPTION_REVALIDATION"
    if target == "THESIS":
        return "THESIS_REVALIDATION"
    if target == "POSITION_SIZE":
        return "RISK_BUDGET_REVIEW"
    if target == "PROCESS":
        return "PROCESS_REVIEW"
    if target == "EVIDENCE_MONITOR":
        return "EVIDENCE_REVIEW"
    if target == "NO_CHANGE":
        return "NO_CHANGE_REVIEW"
    return "REVIEW_REQUIRED"


def learning_feedback_source_context(
    learning_lineage_row: dict | None,
) -> dict:
    row = learning_lineage_row or {}

    integrity = decision_learning_lineage_integrity(
        row
    )
    learning_status = _text(
        row.get(
            "learning_status"
        )
    ).upper()

    issues = []

    if integrity["status"] != "OK":
        issues.append(
            "LEARNING_LINEAGE_INTEGRITY_FAILED"
        )

    if learning_status != "LEARNING_COMPLETE":
        issues.append(
            "LEARNING_COMPLETE_REQUIRED"
        )

    if _text(
        row.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    forecast_error = _text(
        row.get(
            "forecast_error_class"
        )
    )
    process_adherence = _text(
        row.get(
            "process_adherence"
        )
    )
    outcome_classification = _text(
        row.get(
            "outcome_classification"
        )
    )

    if not forecast_error:
        issues.append(
            "FORECAST_ERROR_CLASS_REQUIRED"
        )
    if not process_adherence:
        issues.append(
            "PROCESS_ADHERENCE_REQUIRED"
        )
    if not outcome_classification:
        issues.append(
            "OUTCOME_CLASSIFICATION_REQUIRED"
        )

    return {
        "company": _text(
            row.get(
                "company"
            )
        ),
        "source_learning_lineage_id": _text(
            row.get(
                "learning_lineage_id"
            )
        ),
        "source_learning_lineage_hash": _text(
            row.get(
                "lineage_hash"
            )
        ),
        "source_integrity_status": integrity[
            "status"
        ],
        "source_learning_status": learning_status,
        "packet_id": _text(
            row.get(
                "packet_id"
            )
        ),
        "fill_id": _text(
            row.get(
                "fill_id"
            )
        ),
        "decision_id": _text(
            row.get(
                "decision_id"
            )
        ),
        "outcome_review_id": _text(
            row.get(
                "outcome_review_id"
            )
        ),
        "outcome_classification": outcome_classification,
        "forecast_error_class": forecast_error,
        "process_adherence": process_adherence,
        "review_lane": _error_review_lane(
            forecast_error
        ),
        "actual_outcome": _text(
            row.get(
                "actual_outcome"
            )
        ),
        "new_learning": _text(
            row.get(
                "new_learning"
            )
        ),
        "next_action": _text(
            row.get(
                "next_action"
            )
        ),
        "source_gate": (
            "PASS"
            if not issues
            else "REVIEW"
        ),
        "execution_authorization": "NONE",
        "issues": issues,
    }


def validate_learning_feedback_proposal(
    source_context: dict,
    *,
    feedback_target: str,
    change_direction: str,
    proposed_delta: float | None,
    review_due_date: str,
    rationale: str,
    expected_vs_actual_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    src = source_context or {}
    issues = []

    if _text(
        src.get(
            "source_gate"
        )
    ).upper() != "PASS":
        issues.append(
            "LEARNING_SOURCE_NOT_READY"
        )

    target = _text(
        feedback_target
    ).upper()
    direction = _text(
        change_direction
    ).upper()

    if target not in LEARNING_FEEDBACK_TARGETS:
        issues.append(
            "FEEDBACK_TARGET_REQUIRED"
        )

    if direction not in LEARNING_FEEDBACK_DIRECTIONS:
        issues.append(
            "CHANGE_DIRECTION_REQUIRED"
        )

    if not _text(
        review_due_date
    ):
        issues.append(
            "REVIEW_DUE_DATE_REQUIRED"
        )

    if not _text(
        rationale
    ):
        issues.append(
            "RATIONALE_REQUIRED"
        )

    numeric_targets = {
        "FORWARD_ER",
        "RISK_PENALTY",
        "HURDLE",
        "POSITION_SIZE",
    }

    delta = _num(
        proposed_delta
    )

    if (
        target in numeric_targets
        and direction in {
            "INCREASE",
            "DECREASE",
        }
    ):
        if (
            delta is None
            or delta <= 0
        ):
            issues.append(
                "POSITIVE_PROPOSED_DELTA_REQUIRED"
            )

    if (
        target == "NO_CHANGE"
        and direction
        not in {
            "NO_CHANGE",
            "REVIEW_ONLY",
        }
    ):
        issues.append(
            "NO_CHANGE_TARGET_DIRECTION_MISMATCH"
        )

    if (
        direction == "NO_CHANGE"
        and target
        != "NO_CHANGE"
    ):
        issues.append(
            "NO_CHANGE_DIRECTION_TARGET_MISMATCH"
        )

    confirmations = {
        "EXPECTED_VS_ACTUAL_CONFIRMATION_REQUIRED":
            expected_vs_actual_confirmed,
        "NO_AUTO_APPLY_CONFIRMATION_REQUIRED":
            no_auto_apply_confirmed,
        "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED":
            no_execution_authorization_confirmed,
        "HUMAN_REVIEW_CONFIRMATION_REQUIRED":
            human_review_confirmed,
    }

    for issue, passed in confirmations.items():
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    next_gate = _target_next_gate(
        target
    )

    return {
        "proposal_gate":
            "PASS"
            if not issues
            else "REVIEW",
        "proposal_status":
            "APPROVED_FOR_REVALIDATION"
            if not issues
            else "DRAFT",
        "next_gate":
            next_gate,
        "review_lane":
            _text(
                src.get(
                    "review_lane"
                )
            ),
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _record_payload(
    row: dict,
) -> dict:
    payload = {}
    bool_fields = {
        "expected_vs_actual_confirmed",
        "no_auto_apply_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }
    number_fields = {
        "proposed_delta",
    }

    for field in LEARNING_FEEDBACK_COLS:
        if field == "record_hash":
            continue
        if field in bool_fields:
            payload[field] = bool(
                _bool(
                    row.get(
                        field
                    )
                )
            )
        elif field in number_fields:
            payload[field] = _stable_num(
                row.get(
                    field
                )
            )
        else:
            payload[field] = _text(
                row.get(
                    field
                )
            )
    return payload


def build_learning_feedback_record(
    source_context: dict,
    proposal_review: dict,
    *,
    feedback_target: str,
    change_direction: str,
    proposed_delta: float | None,
    review_due_date: str,
    rationale: str,
    expected_vs_actual_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    src = source_context or {}
    review = proposal_review or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    source_id = _text(
        src.get(
            "source_learning_lineage_id"
        )
    )
    target = _text(
        feedback_target
    ).upper()

    feedback_id = (
        "LFB-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            (
                source_id
                + "|"
                + target
                + "|"
                + _text(
                    change_direction
                )
            ).encode(
                "utf-8"
            )
        ).hexdigest()[:8]
    )

    row = {
        "feedback_id": feedback_id,
        "created_at": now,
        "company": _text(
            src.get(
                "company"
            )
        ),
        "source_learning_lineage_id":
            source_id,
        "source_learning_lineage_hash":
            _text(
                src.get(
                    "source_learning_lineage_hash"
                )
            ),
        "source_integrity_status":
            _text(
                src.get(
                    "source_integrity_status"
                )
            ),
        "source_learning_status":
            _text(
                src.get(
                    "source_learning_status"
                )
            ),
        "packet_id": _text(
            src.get(
                "packet_id"
            )
        ),
        "fill_id": _text(
            src.get(
                "fill_id"
            )
        ),
        "decision_id": _text(
            src.get(
                "decision_id"
            )
        ),
        "outcome_review_id": _text(
            src.get(
                "outcome_review_id"
            )
        ),
        "outcome_classification":
            _text(
                src.get(
                    "outcome_classification"
                )
            ),
        "forecast_error_class":
            _text(
                src.get(
                    "forecast_error_class"
                )
            ),
        "process_adherence":
            _text(
                src.get(
                    "process_adherence"
                )
            ),
        "review_lane":
            _text(
                review.get(
                    "review_lane",
                    src.get(
                        "review_lane"
                    ),
                )
            ),
        "feedback_target":
            target,
        "change_direction":
            _text(
                change_direction
            ).upper(),
        "proposed_delta":
            _num(
                proposed_delta
            ),
        "review_due_date":
            _text(
                review_due_date
            ),
        "rationale":
            _text(
                rationale
            ),
        "expected_vs_actual_confirmed":
            bool(
                expected_vs_actual_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "proposal_gate":
            _text(
                review.get(
                    "proposal_gate"
                )
            ),
        "proposal_status":
            _text(
                review.get(
                    "proposal_status"
                )
            ),
        "next_gate":
            _text(
                review.get(
                    "next_gate"
                )
            ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                review.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _record_payload(
            row
        )
    )
    return row


def learning_feedback_record_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _record_payload(
            record
        )
    )

    return {
        "status":
            "OK"
            if stored
            == calculated
            else "MISMATCH",
        "calculated_hash":
            calculated,
    }
