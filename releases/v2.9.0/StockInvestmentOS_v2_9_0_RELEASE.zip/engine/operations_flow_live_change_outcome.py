from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_live_change_runtime import (
    FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS,
    live_change_runtime_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)


FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS = [
    "live_change_outcome_id",
    "created_at",
    "outcome_state",
    "outcome_guard",
    "source_live_change_apply_id",
    "source_live_change_apply_hash",
    "source_runtime_event_id",
    "source_runtime_event_hash",
    "source_runtime_state",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "permit_scope_pct",
    "permit_session_budget",
    "required_post_change_outcomes",
    "max_relative_error_degradation_pct",
    "completed_sessions",
    "eligible_post_change_outcomes",
    "outside_session_outcomes",
    "preactivation_projection_outcomes",
    "assumption_drift_outcomes",
    "candidate_drift_outcomes",
    "invalid_outcomes",
    "duplicate_outcomes",
    "baseline_mean_abs_error",
    "candidate_mean_abs_error",
    "relative_error_improvement_pct",
    "kill_switch_trigger",
    "rollback_required",
    "baseline_restore_confirmed",
    "evidence_outcome_ids_json",
    "evidence_outcome_hashes_json",
    "permanent_adoption_permission",
    "permanent_change_authorization",
    "live_change_outcome_authorization",
    "live_change_runtime_authorization",
    "live_change_apply_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


LIVE_CHANGE_OUTCOME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


LIVE_CHANGE_OUTCOME_STATES = {
    "LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT",
    "LIVE_CHANGE_OUTCOME_NOT_REQUIRED",
    "LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT",
    "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
    "LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED",
    "LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING",
    "LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
    "LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
}


LIVE_CHANGE_OUTCOME_GUARD_BY_STATE = {
    "LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT": "HOLD_LIVE_CHANGE_RUNTIME",
    "LIVE_CHANGE_OUTCOME_NOT_REQUIRED": "NO_LIVE_CHANGE_OUTCOME_REVIEW",
    "LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT": "HOLD_ACTIVE_LIVE_CHANGE_RUNTIME",
    "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW": "HOLD_LIVE_CHANGE_OUTCOME_INTEGRITY",
    "LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED": "HOLD_LIVE_CHANGE_MODEL_EVALUATOR",
    "LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING": "WAIT_POST_CHANGE_EVIDENCE",
    "LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED": "ROLLBACK_REQUIRED_KILL_SWITCH",
    "LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED": "ROLLBACK_REQUIRED_ASSUMPTION_DRIFT",
    "LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED": "ROLLBACK_REQUIRED_CANDIDATE_DRIFT",
    "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION": "PASS_NO_PERMANENT_ADOPTION",
    "LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED": "FAIL_ROLLBACK_REQUIRED",
    "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION": "INCONCLUSIVE_NO_PERMANENT_ADOPTION",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _outcome_payload(row: dict) -> dict:
    int_fields = {
        "permit_session_budget",
        "required_post_change_outcomes",
        "completed_sessions",
        "eligible_post_change_outcomes",
        "outside_session_outcomes",
        "preactivation_projection_outcomes",
        "assumption_drift_outcomes",
        "candidate_drift_outcomes",
        "invalid_outcomes",
        "duplicate_outcomes",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "permit_scope_pct",
        "max_relative_error_degradation_pct",
        "baseline_mean_abs_error",
        "candidate_mean_abs_error",
        "relative_error_improvement_pct",
    }

    bool_fields = {
        "rollback_required",
        "baseline_restore_confirmed",
    }

    payload = {}

    for col in FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS:
        if col in {
            "live_change_outcome_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def live_change_outcome_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _outcome_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_live_change_outcome_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _closed_runtime_windows(
    runtime: dict,
    runtime_snapshots: pd.DataFrame | None,
) -> dict:
    source_apply_id = _text(
        runtime.get(
            "source_live_change_apply_id"
        )
    )
    source_apply_hash = _text(
        runtime.get(
            "source_live_change_apply_hash"
        )
    )

    df = (
        pd.DataFrame()
        if runtime_snapshots is None
        else runtime_snapshots.copy()
    )

    for col in FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return {
            "windows": [],
            "invalid_count": 0,
            "unpaired_count": 0,
        }

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    current = df.loc[
        df["source_live_change_apply_id"]
        .fillna("")
        .astype(str)
        .eq(source_apply_id)
        & df["source_live_change_apply_hash"]
        .fillna("")
        .astype(str)
        .eq(source_apply_hash)
    ].copy()

    current = current.loc[
        current["_ts"].notna()
    ].sort_values("_ts")

    invalid_count = 0
    active = {}
    windows = []

    for _, row in current.iterrows():
        item = row.to_dict()

        if _text(
            live_change_runtime_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            invalid_count += 1
            continue

        event_type = _text(
            item.get("event_type")
        ).upper()
        session_id = _text(
            item.get("runtime_session_id")
        )
        ts = item["_ts"]

        if event_type == "ACTIVATE":
            if not session_id or session_id in active:
                invalid_count += 1
                continue

            active[session_id] = {
                "activate_at": ts,
                "activate_event_id": _text(
                    item.get(
                        "live_change_runtime_event_id"
                    )
                ),
                "activate_hash": _text(
                    item.get("snapshot_hash")
                ),
                "activation_receipt_ref": _text(
                    item.get("activation_receipt_ref")
                ),
            }

        elif event_type == "CLOSE":
            opened = active.pop(
                session_id,
                None,
            )

            if not opened:
                invalid_count += 1
                continue

            if not _bool(
                item.get(
                    "baseline_restore_confirmed"
                )
            ):
                invalid_count += 1
                continue

            windows.append(
                {
                    "runtime_session_id":
                        session_id,
                    "activate_at":
                        opened[
                            "activate_at"
                        ],
                    "close_at":
                        ts,
                    "activate_event_id":
                        opened[
                            "activate_event_id"
                        ],
                    "close_event_id":
                        _text(
                            item.get(
                                "live_change_runtime_event_id"
                            )
                        ),
                    "activation_receipt_ref":
                        opened[
                            "activation_receipt_ref"
                        ],
                }
            )

        elif event_type == "KILL_SWITCH":
            active.pop(
                session_id,
                None,
            )

    return {
        "windows": windows,
        "invalid_count": invalid_count,
        "unpaired_count": len(active),
    }


def build_flow_live_change_outcome(
    live_change_runtime: dict | None,
    runtime_snapshots: pd.DataFrame | None,
    qualified_outcomes: pd.DataFrame | None,
) -> dict:
    runtime = live_change_runtime or {}
    runtime_state = _text(
        runtime.get("runtime_state")
    ).upper()

    required_outcomes = max(
        3,
        _int(
            runtime.get(
                "permit_min_post_change_outcomes"
            )
        ),
    )

    max_degradation = max(
        0.0,
        _float(
            runtime.get(
                "permit_max_relative_error_degradation_pct"
            )
        ),
    )

    latest_runtime = runtime.get(
        "latest_event"
    ) or {}

    base = {
        "source_live_change_apply_id":
            _text(
                runtime.get(
                    "source_live_change_apply_id"
                )
            ),
        "source_live_change_apply_hash":
            _text(
                runtime.get(
                    "source_live_change_apply_hash"
                )
            ),
        "source_runtime_event_id":
            _text(
                latest_runtime.get(
                    "live_change_runtime_event_id"
                )
            ),
        "source_runtime_event_hash":
            _text(
                latest_runtime.get(
                    "snapshot_hash"
                )
            ),
        "source_runtime_state":
            runtime_state,
        "source_live_change_design_id":
            _text(
                runtime.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                runtime.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                runtime.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                runtime.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            _text(
                runtime.get(
                    "proposal_scope"
                )
            ).upper(),
        "target_metric":
            _text(
                runtime.get(
                    "target_metric"
                )
            ).upper(),
        "change_mode":
            _text(
                runtime.get(
                    "change_mode"
                )
            ).upper(),
        "artifact_ref":
            _text(
                runtime.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            _float(
                runtime.get(
                    "baseline_value"
                )
            ),
        "candidate_value":
            _float(
                runtime.get(
                    "candidate_value"
                )
            ),
        "rollback_target_value":
            _float(
                runtime.get(
                    "rollback_target_value"
                )
            ),
        "permit_scope_pct":
            _float(
                runtime.get(
                    "permit_scope_pct"
                )
            ),
        "permit_session_budget":
            _int(
                runtime.get(
                    "permit_session_budget"
                )
            ),
        "required_post_change_outcomes":
            required_outcomes,
        "max_relative_error_degradation_pct":
            max_degradation,
        "completed_sessions":
            0,
        "eligible_post_change_outcomes":
            0,
        "outside_session_outcomes":
            0,
        "preactivation_projection_outcomes":
            0,
        "assumption_drift_outcomes":
            0,
        "candidate_drift_outcomes":
            0,
        "invalid_outcomes":
            0,
        "duplicate_outcomes":
            0,
        "baseline_mean_abs_error":
            0.0,
        "candidate_mean_abs_error":
            0.0,
        "relative_error_improvement_pct":
            0.0,
        "kill_switch_trigger":
            _text(
                runtime.get(
                    "kill_switch_trigger"
                )
            ).upper(),
        "rollback_required":
            False,
        "baseline_restore_confirmed":
            _bool(
                runtime.get(
                    "baseline_restore_confirmed"
                )
            ),
        "evidence_outcome_ids_json":
            "[]",
        "evidence_outcome_hashes_json":
            "[]",
        "evidence_table":
            pd.DataFrame(),
        "permanent_adoption_permission":
            "NONE",
        "permanent_change_authorization":
            "NONE",
        "live_change_outcome_authorization":
            "NONE",
        "live_change_runtime_authorization":
            "NONE",
        "live_change_apply_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    if runtime_state in {
        "",
        "LIVE_CHANGE_RUNTIME_UPSTREAM_WAIT",
        "LIVE_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
    }:
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_RUNTIME",
        }

    if runtime_state in {
        "LIVE_CHANGE_RUNTIME_NOT_REQUIRED",
        "LIVE_CHANGE_RUNTIME_DEFERRED",
    }:
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_NOT_REQUIRED",
            "outcome_guard":
                "NO_LIVE_CHANGE_OUTCOME_REVIEW",
        }

    if runtime_state in {
        "LIVE_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "LIVE_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
    }:
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_OUTCOME_INTEGRITY",
        }

    windows_info = _closed_runtime_windows(
        runtime,
        runtime_snapshots,
    )

    base[
        "completed_sessions"
    ] = len(
        windows_info["windows"]
    )

    base[
        "invalid_outcomes"
    ] += _int(
        windows_info.get(
            "invalid_count"
        )
    )

    if windows_info["invalid_count"] > 0:
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_OUTCOME_INTEGRITY",
        }

    if runtime_state == "LIVE_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED":
        return {
            **base,
            "rollback_required":
                True,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
            "outcome_guard":
                "ROLLBACK_REQUIRED_KILL_SWITCH",
        }

    if runtime_state == "LIVE_CHANGE_RUNTIME_ACTIVE_CANARY":
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT",
            "outcome_guard":
                "HOLD_ACTIVE_LIVE_CHANGE_RUNTIME",
        }

    if (
        runtime_state
        == "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED"
        and not _bool(
            runtime.get(
                "baseline_restore_confirmed"
            )
        )
    ):
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_OUTCOME_INTEGRITY",
        }

    if base["proposal_scope"] == "MODEL_SHADOW":
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_MODEL_EVALUATOR",
        }

    if (
        base["proposal_scope"]
        != "PARAMETER_SHADOW"
        or base["target_metric"]
        != "BASE_BURN_RATE"
        or base["baseline_value"]
        <= 0
        or base["candidate_value"]
        <= 0
        or abs(
            base["rollback_target_value"]
            - base["baseline_value"]
        )
        > 1e-9
    ):
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_OUTCOME_INTEGRITY",
        }

    windows = windows_info["windows"]

    outcome_df = (
        pd.DataFrame()
        if qualified_outcomes is None
        else qualified_outcomes.copy()
    )

    for col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
        if col not in outcome_df.columns:
            outcome_df[col] = ""

    valid_by_key = {}
    invalid_outcomes = 0
    duplicate_outcomes = 0

    for _, row in outcome_df.iterrows():
        item = row.to_dict()

        if _text(
            flow_projection_outcome_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            invalid_outcomes += 1
            continue

        key = (
            _text(
                item.get(
                    "source_projection_snapshot_id"
                )
            ),
            _text(
                item.get(
                    "evidence_end_trend_snapshot_id"
                )
            ),
        )

        created = pd.to_datetime(
            item.get("created_at"),
            errors="coerce",
            utc=True,
        )

        previous = valid_by_key.get(key)

        if previous is not None:
            duplicate_outcomes += 1
            previous_created = pd.to_datetime(
                previous.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                not pd.isna(previous_created)
                and (
                    pd.isna(created)
                    or created <= previous_created
                )
            ):
                continue

        valid_by_key[key] = item

    base[
        "invalid_outcomes"
    ] += invalid_outcomes
    base[
        "duplicate_outcomes"
    ] = duplicate_outcomes

    if invalid_outcomes > 0:
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard":
                "HOLD_LIVE_CHANGE_OUTCOME_INTEGRITY",
        }

    rows = []
    outside_session = 0
    preactivation_projection = 0
    assumption_drift = 0
    candidate_drift = 0

    candidate_tolerance = max(
        1e-8,
        abs(
            base["candidate_value"]
        )
        * 1e-6,
    )

    for item in valid_by_key.values():
        evidence_end = pd.to_datetime(
            item.get("evidence_end_at"),
            errors="coerce",
            utc=True,
        )

        projection_created = pd.to_datetime(
            item.get(
                "source_projection_created_at"
            ),
            errors="coerce",
            utc=True,
        )

        matched_window = None

        if not pd.isna(evidence_end):
            for window in windows:
                if (
                    evidence_end
                    > window["activate_at"]
                    and evidence_end
                    <= window["close_at"]
                ):
                    matched_window = window
                    break

        if matched_window is None:
            outside_session += 1
            continue

        if (
            pd.isna(projection_created)
            or projection_created
            <= matched_window["activate_at"]
            or projection_created
            > matched_window["close_at"]
        ):
            preactivation_projection += 1
            continue

        capacity_drift = _int(
            item.get("capacity_drift_count")
        )

        evaluation_state = _text(
            item.get("evaluation_state")
        ).upper()

        recalibration_state = _text(
            item.get("recalibration_state")
        ).upper()

        if (
            capacity_drift > 0
            or evaluation_state
            == "ASSUMPTION_DRIFT_REVIEW"
            or recalibration_state
            == "REBASE_REQUIRED"
        ):
            assumption_drift += 1
            continue

        active_base_burn = _float(
            item.get("base_burn_rate")
        )

        if abs(
            active_base_burn
            - base["candidate_value"]
        ) > candidate_tolerance:
            candidate_drift += 1
            continue

        realized = _float(
            item.get(
                "realized_avg_net_burn"
            )
        )

        baseline_error = abs(
            realized
            - base["baseline_value"]
        )

        candidate_error = abs(
            realized
            - base["candidate_value"]
        )

        rows.append(
            {
                "runtime_session_id":
                    matched_window[
                        "runtime_session_id"
                    ],
                "activation_receipt_ref":
                    matched_window[
                        "activation_receipt_ref"
                    ],
                "outcome_snapshot_id":
                    _text(
                        item.get(
                            "outcome_snapshot_id"
                        )
                    ),
                "outcome_hash":
                    _text(
                        item.get(
                            "snapshot_hash"
                        )
                    ),
                "source_projection_snapshot_id":
                    _text(
                        item.get(
                            "source_projection_snapshot_id"
                        )
                    ),
                "evidence_end_at":
                    _text(
                        item.get(
                            "evidence_end_at"
                        )
                    ),
                "realized_avg_net_burn":
                    realized,
                "baseline_abs_error":
                    baseline_error,
                "candidate_abs_error":
                    candidate_error,
            }
        )

    evidence_table = pd.DataFrame(rows)

    base.update(
        {
            "eligible_post_change_outcomes":
                int(
                    len(
                        evidence_table
                    )
                ),
            "outside_session_outcomes":
                outside_session,
            "preactivation_projection_outcomes":
                preactivation_projection,
            "assumption_drift_outcomes":
                assumption_drift,
            "candidate_drift_outcomes":
                candidate_drift,
            "evidence_table":
                evidence_table,
            "evidence_outcome_ids_json":
                json.dumps(
                    (
                        evidence_table[
                            "outcome_snapshot_id"
                        ]
                        .astype(str)
                        .tolist()
                        if not evidence_table.empty
                        else []
                    ),
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            "evidence_outcome_hashes_json":
                json.dumps(
                    (
                        evidence_table[
                            "outcome_hash"
                        ]
                        .astype(str)
                        .tolist()
                        if not evidence_table.empty
                        else []
                    ),
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
        }
    )

    if assumption_drift > 0:
        return {
            **base,
            "rollback_required":
                True,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
            "outcome_guard":
                "ROLLBACK_REQUIRED_ASSUMPTION_DRIFT",
        }

    if candidate_drift > 0:
        return {
            **base,
            "rollback_required":
                True,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED",
            "outcome_guard":
                "ROLLBACK_REQUIRED_CANDIDATE_DRIFT",
        }

    if (
        runtime_state
        == "LIVE_CHANGE_RUNTIME_READY_FOR_MANUAL_ACTIVATION"
    ):
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING",
            "outcome_guard":
                "WAIT_POST_CHANGE_EVIDENCE",
        }

    if (
        runtime_state
        != "LIVE_CHANGE_RUNTIME_SESSION_BUDGET_EXHAUSTED"
    ):
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING",
            "outcome_guard":
                "WAIT_POST_CHANGE_EVIDENCE",
        }

    if (
        base["eligible_post_change_outcomes"]
        < base["required_post_change_outcomes"]
    ):
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
            "outcome_guard":
                "INCONCLUSIVE_NO_PERMANENT_ADOPTION",
        }

    baseline_mean = float(
        evidence_table[
            "baseline_abs_error"
        ].mean()
    )

    candidate_mean = float(
        evidence_table[
            "candidate_abs_error"
        ].mean()
    )

    base[
        "baseline_mean_abs_error"
    ] = baseline_mean
    base[
        "candidate_mean_abs_error"
    ] = candidate_mean

    if baseline_mean <= 1e-12:
        improvement = (
            0.0
            if candidate_mean <= 1e-12
            else -1.0
        )
    else:
        improvement = (
            baseline_mean
            - candidate_mean
        ) / baseline_mean

    base[
        "relative_error_improvement_pct"
    ] = improvement

    if improvement <= -base[
        "max_relative_error_degradation_pct"
    ]:
        return {
            **base,
            "rollback_required":
                True,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED",
            "outcome_guard":
                "FAIL_ROLLBACK_REQUIRED",
        }

    if improvement > 0.0:
        return {
            **base,
            "outcome_state":
                "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
            "outcome_guard":
                "PASS_NO_PERMANENT_ADOPTION",
        }

    return {
        **base,
        "outcome_state":
            "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
        "outcome_guard":
            "INCONCLUSIVE_NO_PERMANENT_ADOPTION",
    }


def build_flow_live_change_outcome_snapshot(
    outcome: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = outcome or {}

    state = _text(
        current.get("outcome_state")
    ).upper()

    if state not in LIVE_CHANGE_OUTCOME_STATES:
        raise ValueError(
            "Live Change Outcome state가 유효하지 않습니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        col: current.get(
            col,
            "",
        )
        for col in FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS
        if col not in {
            "live_change_outcome_id",
            "created_at",
            "note",
            "snapshot_hash",
        }
    }

    base[
        "permanent_adoption_permission"
    ] = "NONE"
    base[
        "permanent_change_authorization"
    ] = "NONE"
    base[
        "live_change_outcome_authorization"
    ] = "NONE"
    base[
        "live_change_runtime_authorization"
    ] = "NONE"
    base[
        "live_change_apply_authorization"
    ] = "NONE"
    base[
        "recalibration_authorization"
    ] = "NONE"
    base[
        "capacity_authorization"
    ] = "NONE"
    base[
        "execution_authorization"
    ] = "NONE"

    snapshot_hash = _hash(
        _outcome_payload(
            base
        )
    )

    return {
        "live_change_outcome_id": (
            "LCO-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_live_change_outcome_queue(
    outcome: dict | None,
) -> pd.DataFrame:
    row = outcome or {}

    state = _text(
        row.get("outcome_state")
    ).upper()

    mapping = {
        "LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT": (
            "LO2",
            "WAIT",
            "LIVE_CHANGE_OUTCOME_UPSTREAM_WAIT",
            "완료된 Live Change Runtime source가 아직 없음",
            "Apply / Runtime evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "LIVE_CHANGE_OUTCOME_NOT_REQUIRED": (
            "LO3",
            "MONITOR",
            "LIVE_CHANGE_OUTCOME_NOT_REQUIRED",
            "현재 Runtime source에서는 Live Change Outcome Review가 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT": (
            "LO1",
            "ACTIVE",
            "LIVE_CHANGE_OUTCOME_RUNTIME_ACTIVE_WAIT",
            "Manual Canary Runtime Session이 아직 ACTIVE",
            "CLOSE 또는 KILL_SWITCH 전에는 Outcome 결론 금지",
        ),
        "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW": (
            "LO0",
            "BLOCKED",
            "LIVE_CHANGE_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "Runtime / qualified Outcome source integrity mismatch",
            "immutable source audit과 lineage를 먼저 복구",
        ),
        "LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED": (
            "LO1",
            "REVIEW",
            "LIVE_CHANGE_OUTCOME_MODEL_EVALUATOR_REQUIRED",
            "MODEL_SHADOW executable post-change evaluator가 아직 없음",
            "모델 counterfactual evaluator 정의 전 permanent adoption 결론 금지",
        ),
        "LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING": (
            "LO2",
            "WAIT",
            "LIVE_CHANGE_OUTCOME_EVIDENCE_MATURING",
            (
                f"eligible {row.get('eligible_post_change_outcomes',0)}/"
                f"{row.get('required_post_change_outcomes',0)} · "
                f"sessions {row.get('completed_sessions',0)}/"
                f"{row.get('permit_session_budget',0)}"
            ),
            "사전 허용된 canary session budget 내에서 prospective post-change evidence 축적",
        ),
        "LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED": (
            "LO0",
            "BLOCKED",
            "LIVE_CHANGE_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
            f"kill trigger {row.get('kill_switch_trigger','')} · rollback required",
            "새 activation 금지; rollback closure와 post-mortem review 우선",
        ),
        "LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED": (
            "LO0",
            "BLOCKED",
            "LIVE_CHANGE_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
            f"assumption drift outcomes {row.get('assumption_drift_outcomes',0)}",
            "비교 중단; baseline 유지와 rollback closure 우선",
        ),
        "LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED": (
            "LO0",
            "BLOCKED",
            "LIVE_CHANGE_OUTCOME_CANDIDATE_DRIFT_ROLLBACK_REQUIRED",
            f"candidate drift outcomes {row.get('candidate_drift_outcomes',0)}",
            "locked candidate와 실제 Projection source 불일치; rollback/post-mortem 우선",
        ),
        "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION": (
            "LO3",
            "REVIEW",
            "LIVE_CHANGE_OUTCOME_PASS_NO_PERMANENT_ADOPTION",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "PASS는 permanent adoption이 아님; 별도 Human Live Change Outcome Closure 필요",
        ),
        "LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED": (
            "LO0",
            "BLOCKED",
            "LIVE_CHANGE_OUTCOME_FAIL_ROLLBACK_REQUIRED",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "Baseline 유지/복원 및 rollback closure/post-mortem 우선",
        ),
        "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION": (
            "LO2",
            "REVIEW",
            "LIVE_CHANGE_OUTCOME_INCONCLUSIVE_NO_PERMANENT_ADOPTION",
            (
                f"eligible {row.get('eligible_post_change_outcomes',0)}/"
                f"{row.get('required_post_change_outcomes',0)} · "
                f"improvement {float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "기준을 사후 변경하지 말고 새 canary cycle 또는 추가 evidence를 검토",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "LO0",
            "BLOCKED",
            "LIVE_CHANGE_OUTCOME_UNKNOWN_STATE",
            state or "MISSING",
            "Live Change Outcome state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            LIVE_CHANGE_OUTCOME_QUEUE_COLS,
    )
