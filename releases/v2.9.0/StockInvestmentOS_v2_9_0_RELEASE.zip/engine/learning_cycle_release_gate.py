from __future__ import annotations

from datetime import date
from typing import Any

import pandas as pd

from engine.decision_learning_lineage import (
    decision_learning_lineage_integrity,
)
from engine.learning_feedback_governance import (
    learning_feedback_record_integrity,
)
from engine.learning_feedback_revalidation_bridge import (
    feedback_revalidation_draft_integrity,
)
from engine.learning_feedback_change_lineage import (
    feedback_change_lineage_integrity,
)
from engine.learning_cycle_audit import (
    build_learning_cycle_coverage,
    build_learning_cycle_orphans,
    learning_cycle_audit_summary,
)


LEARNING_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _ensure_df(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    return (
        pd.DataFrame()
        if df is None
        else df.copy()
    )


def _record_integrity_counts(
    learning_lineages: pd.DataFrame,
    feedback_proposals: pd.DataFrame,
    bridge_drafts: pd.DataFrame,
    change_lineages: pd.DataFrame,
) -> dict:
    checks = [
        (
            "Learning Lineage",
            learning_lineages,
            decision_learning_lineage_integrity,
        ),
        (
            "Learning Feedback",
            feedback_proposals,
            learning_feedback_record_integrity,
        ),
        (
            "Revalidation Bridge",
            bridge_drafts,
            feedback_revalidation_draft_integrity,
        ),
        (
            "Change Lineage",
            change_lineages,
            feedback_change_lineage_integrity,
        ),
    ]

    total = 0
    ok = 0
    mismatch = 0
    missing = 0
    per_type = {}

    for name, df, fn in checks:
        type_total = 0
        type_ok = 0
        type_mismatch = 0
        type_missing = 0

        if not df.empty:
            for _, row in df.iterrows():
                type_total += 1
                result = fn(
                    row.to_dict()
                )
                status = _text(
                    result.get(
                        "status"
                    )
                ).upper()

                if status == "OK":
                    type_ok += 1
                elif status == "MISSING":
                    type_missing += 1
                else:
                    type_mismatch += 1

        total += type_total
        ok += type_ok
        mismatch += type_mismatch
        missing += type_missing

        per_type[name] = {
            "total": type_total,
            "ok": type_ok,
            "mismatch": type_mismatch,
            "missing": type_missing,
        }

    return {
        "total": total,
        "ok": ok,
        "mismatch": mismatch,
        "missing": missing,
        "per_type": per_type,
    }


def _execution_authorization_violations(
    frames: list[pd.DataFrame],
) -> int:
    violations = 0

    for df in frames:
        if (
            df.empty
            or "execution_authorization"
            not in df.columns
        ):
            continue

        auth = (
            df[
                "execution_authorization"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
        )

        # Existing governed records must explicitly preserve NONE.
        violations += int(
            auth.ne(
                "NONE"
            ).sum()
        )

    return violations


def build_learning_cycle_release_gate(
    learning_lineages: pd.DataFrame | None,
    feedback_proposals: pd.DataFrame | None,
    bridge_drafts: pd.DataFrame | None,
    change_lineages: pd.DataFrame | None,
    capital_productivity_inputs: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    revalidations: pd.DataFrame | None,
    *,
    today: date | None = None,
) -> dict:
    learning = _ensure_df(
        learning_lineages
    )
    feedback = _ensure_df(
        feedback_proposals
    )
    bridges = _ensure_df(
        bridge_drafts
    )
    closures = _ensure_df(
        change_lineages
    )

    coverage = build_learning_cycle_coverage(
        learning,
        feedback,
        bridges,
        closures,
        capital_productivity_inputs,
        calibration_drafts,
        revalidations,
        today=today,
    )
    orphans = build_learning_cycle_orphans(
        learning,
        feedback,
        bridges,
        closures,
    )
    cycle_summary = learning_cycle_audit_summary(
        coverage,
        orphans,
        learning,
    )

    integrity = _record_integrity_counts(
        learning,
        feedback,
        bridges,
        closures,
    )

    auth_violations = _execution_authorization_violations(
        [
            learning,
            feedback,
            bridges,
            closures,
        ]
    )

    technical_checks = []

    integrity_failures = (
        int(
            integrity[
                "mismatch"
            ]
        )
        + int(
            integrity[
                "missing"
            ]
        )
    )

    technical_checks.append(
        {
            "layer": "TECHNICAL",
            "check": "Learning Immutable Record Integrity",
            "status": (
                "PASS"
                if integrity_failures == 0
                else "FAIL"
            ),
            "detail": (
                f"records {integrity['total']} · OK {integrity['ok']} · "
                f"MISMATCH {integrity['mismatch']} · MISSING {integrity['missing']}"
            ),
            "action": (
                ""
                if integrity_failures == 0
                else "Hash mismatch / missing immutable record hash를 먼저 복구"
            ),
        }
    )

    orphan_count = int(
        len(
            orphans
        )
    )
    technical_checks.append(
        {
            "layer": "TECHNICAL",
            "check": "Learning Parent / Orphan Integrity",
            "status": (
                "PASS"
                if orphan_count == 0
                else "FAIL"
            ),
            "detail": (
                f"orphans / parent-hash issues {orphan_count}"
            ),
            "action": (
                ""
                if orphan_count == 0
                else "Review Queue 0C에서 missing parent / parent hash mismatch 확인"
            ),
        }
    )

    technical_checks.append(
        {
            "layer": "TECHNICAL",
            "check": "Learning Execution Authorization Invariant",
            "status": (
                "PASS"
                if auth_violations == 0
                else "FAIL"
            ),
            "detail": (
                f"non-NONE records {auth_violations}"
            ),
            "action": (
                ""
                if auth_violations == 0
                else "Learning cycle record의 Execution Authorization을 확인"
            ),
        }
    )

    technical_checks.append(
        {
            "layer": "TECHNICAL",
            "check": "Learning Cycle Integrity Summary",
            "status": (
                "PASS"
                if int(
                    cycle_summary.get(
                        "hash_or_integrity_issues",
                        0,
                    )
                ) == 0
                else "FAIL"
            ),
            "detail": (
                f"cycle status {cycle_summary.get('audit_status','')} · "
                f"integrity issues {cycle_summary.get('hash_or_integrity_issues',0)}"
            ),
            "action": (
                ""
                if int(
                    cycle_summary.get(
                        "hash_or_integrity_issues",
                        0,
                    )
                ) == 0
                else "Cycle integrity issue를 해결한 뒤 Release Gate를 다시 확인"
            ),
        }
    )

    technical_fail = sum(
        1
        for row in technical_checks
        if row[
            "status"
        ] == "FAIL"
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "FAIL"
    )

    cycle_status = _text(
        cycle_summary.get(
            "audit_status"
        )
    ).upper()

    if cycle_status in {
        "NO_CYCLES",
        "PASS",
    }:
        operating_status = "PASS"
    elif cycle_status == "OPEN_ITEMS":
        operating_status = "REVIEW"
    else:
        operating_status = "REVIEW"

    operating_detail = (
        f"Learning Complete {cycle_summary.get('learning_complete',0)} · "
        f"Feedback Missing {cycle_summary.get('feedback_missing',0)} · "
        f"Source Pending {cycle_summary.get('source_review_pending',0)} · "
        f"Closure Pending {cycle_summary.get('closure_pending',0)} · "
        f"More Evidence {cycle_summary.get('open_more_evidence',0)} · "
        f"Closed {cycle_summary.get('closed_source_reviewed',0)}"
    )

    operating_check = {
        "layer": "OPERATING",
        "check": "Learning Cycle Coverage",
        "status": operating_status,
        "detail": operating_detail,
        "action": (
            ""
            if operating_status == "PASS"
            else "Open cycle은 Review Queue 0A/0B/0C에서 due date와 evidence에 따라 추적"
        ),
    }

    checks = pd.DataFrame(
        technical_checks
        + [
            operating_check
        ],
        columns=
        LEARNING_RELEASE_CHECK_COLS,
    )

    return {
        "release_gate":
            release_gate,
        "technical_pass":
            int(
                (
                    checks[
                        "layer"
                    ].eq(
                        "TECHNICAL"
                    )
                    & checks[
                        "status"
                    ].eq(
                        "PASS"
                    )
                ).sum()
            ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "cycle_audit_status":
            cycle_status,
        "orphan_count":
            orphan_count,
        "record_integrity_failures":
            integrity_failures,
        "execution_authorization_violations":
            auth_violations,
        "checks":
            checks,
        "coverage":
            coverage,
        "orphans":
            orphans,
        "cycle_summary":
            cycle_summary,
        "execution_authorization":
            "NONE",
    }


def combined_release_readiness(
    *,
    stable_technical_gate: str,
    integration_consistency: str,
    csv_fail_count: int,
    learning_release_gate: str,
) -> dict:
    stable = _text(
        stable_technical_gate
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    learning = _text(
        learning_release_gate
    ).upper()
    csv_fail = int(
        csv_fail_count
        or 0
    )

    blockers = []

    if stable != "PASS":
        blockers.append(
            "STABILITY_TECHNICAL_NOT_PASS"
        )
    if integration != "PASS":
        blockers.append(
            "SYSTEM_INTEGRATION_NOT_PASS"
        )
    if csv_fail != 0:
        blockers.append(
            "SAVE_CENTER_CSV_FAIL"
        )
    if learning != "PASS":
        blockers.append(
            "LEARNING_CYCLE_RELEASE_GATE_NOT_PASS"
        )

    return {
        "status":
            "PASS"
            if not blockers
            else "BLOCKED",
        "blockers":
            blockers,
        "execution_authorization":
            "NONE",
    }
