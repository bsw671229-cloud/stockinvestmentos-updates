from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)
from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    flow_projection_scorecard_snapshot_integrity,
)
from engine.operations_flow_recalibration_proposal import (
    recalibration_proposal_snapshot_integrity,
)
from engine.operations_flow_shadow_validation_plan import (
    shadow_validation_plan_snapshot_integrity,
)


FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS = [
    "shadow_validation_outcome_id",
    "created_at",
    "validation_state",
    "validation_guard",
    "source_plan_id",
    "source_plan_hash",
    "source_plan_created_at",
    "source_plan_integrity",
    "source_proposal_id",
    "source_proposal_hash",
    "source_proposal_integrity",
    "source_scorecard_snapshot_id",
    "source_scorecard_hash",
    "source_scorecard_integrity",
    "proposal_scope",
    "target_metric",
    "expected_capacity",
    "baseline_value",
    "shadow_value",
    "qualified_outcome_records",
    "future_outcomes_seen",
    "eligible_outcomes",
    "immature_outcomes",
    "preplan_outcomes",
    "preplan_projection_outcomes",
    "assumption_drift_outcomes",
    "baseline_drift_outcomes",
    "invalid_outcomes",
    "duplicate_outcomes",
    "required_future_outcomes",
    "required_closed_intervals",
    "baseline_mean_abs_error",
    "shadow_mean_abs_error",
    "relative_error_improvement_pct",
    "min_relative_error_improvement_pct",
    "max_relative_error_degradation_pct",
    "evidence_outcome_ids_json",
    "evidence_outcome_hashes_json",
    "validation_authorization",
    "proposal_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


SHADOW_VALIDATION_OUTCOME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


SHADOW_VALIDATION_OUTCOME_STATES = {
    "SHADOW_EVAL_UPSTREAM_WAIT",
    "SHADOW_EVAL_NOT_REQUIRED",
    "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
    "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
    "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW",
    "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED",
    "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES",
    "SHADOW_EVAL_EVIDENCE_MATURING",
    "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW",
    "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW",
    "SHADOW_EVAL_BASELINE_DRIFT_REVIEW",
    "SHADOW_EVAL_PASS",
    "SHADOW_EVAL_FAIL",
    "SHADOW_EVAL_INCONCLUSIVE",
}


VALIDATION_GUARD_BY_STATE = {
    "SHADOW_EVAL_UPSTREAM_WAIT": "HOLD_VALIDATION_PLAN",
    "SHADOW_EVAL_NOT_REQUIRED": "NO_SHADOW_EVALUATION",
    "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW": "HOLD_VALIDATION_INTEGRITY",
    "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW": "HOLD_VALIDATION_INTEGRITY",
    "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW": "HOLD_VALIDATION_SOURCE",
    "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED": "HOLD_MODEL_EVALUATOR",
    "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES": "WAIT_OUT_OF_SAMPLE_EVIDENCE",
    "SHADOW_EVAL_EVIDENCE_MATURING": "WAIT_OUT_OF_SAMPLE_EVIDENCE",
    "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW": "HOLD_EVIDENCE_INTEGRITY",
    "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW": "HOLD_ASSUMPTION_DRIFT",
    "SHADOW_EVAL_BASELINE_DRIFT_REVIEW": "HOLD_BASELINE_DRIFT",
    "SHADOW_EVAL_PASS": "SHADOW_VALIDATION_PASS_NO_APPLY",
    "SHADOW_EVAL_FAIL": "SHADOW_VALIDATION_FAIL_NO_APPLY",
    "SHADOW_EVAL_INCONCLUSIVE": "SHADOW_VALIDATION_INCONCLUSIVE_NO_APPLY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _latest_locked_plan(
    plan: dict | None,
) -> dict:
    row = plan or {}

    if _text(
        row.get("plan_state")
    ).upper() != "SHADOW_VALIDATION_PLAN_LOCKED":
        return {}

    latest = row.get("latest_plan") or {}

    if not latest:
        return {}

    if _text(
        shadow_validation_plan_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    return latest


def _latest_locked_proposal(
    proposal: dict | None,
) -> dict:
    row = proposal or {}

    if _text(
        row.get("proposal_state")
    ).upper() != "RECALIBRATION_PROPOSAL_LOCKED":
        return {}

    latest = row.get("latest_proposal") or {}

    if not latest:
        return {}

    if _text(
        recalibration_proposal_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    return latest


def _scorecard_source(
    proposal_source: dict,
    scorecard_snapshots: pd.DataFrame | None,
) -> dict:
    if not proposal_source:
        return {}

    df = (
        pd.DataFrame()
        if scorecard_snapshots is None
        else scorecard_snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    source_id = _text(
        proposal_source.get(
            "source_scorecard_snapshot_id"
        )
    )
    source_hash = _text(
        proposal_source.get(
            "source_scorecard_hash"
        )
    )

    matches = df.loc[
        df["scorecard_snapshot_id"]
        .fillna("")
        .astype(str)
        .eq(source_id)
    ]

    if len(matches) != 1:
        return {}

    row = matches.iloc[0].to_dict()

    if _text(
        flow_projection_scorecard_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        row.get("snapshot_hash")
    ) != source_hash:
        return {}

    return row


def _outcome_payload(row: dict) -> dict:
    int_fields = {
        "expected_capacity",
        "qualified_outcome_records",
        "future_outcomes_seen",
        "eligible_outcomes",
        "immature_outcomes",
        "preplan_outcomes",
        "preplan_projection_outcomes",
        "assumption_drift_outcomes",
        "baseline_drift_outcomes",
        "invalid_outcomes",
        "duplicate_outcomes",
        "required_future_outcomes",
        "required_closed_intervals",
    }

    float_fields = {
        "baseline_value",
        "shadow_value",
        "baseline_mean_abs_error",
        "shadow_mean_abs_error",
        "relative_error_improvement_pct",
        "min_relative_error_improvement_pct",
        "max_relative_error_degradation_pct",
    }

    payload = {}

    for col in FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS:
        if col in {
            "shadow_validation_outcome_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def shadow_validation_outcome_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _outcome_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_shadow_validation_outcome_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def build_flow_shadow_validation_outcome(
    validation_plan: dict | None,
    recalibration_proposal: dict | None,
    scorecard_snapshots: pd.DataFrame | None,
    qualified_outcomes: pd.DataFrame | None,
) -> dict:
    plan_state = _text(
        (validation_plan or {}).get("plan_state")
    ).upper()

    base = {
        "source_plan_id": "",
        "source_plan_hash": "",
        "source_plan_created_at": "",
        "source_plan_integrity": "NONE",
        "source_proposal_id": "",
        "source_proposal_hash": "",
        "source_proposal_integrity": "NONE",
        "source_scorecard_snapshot_id": "",
        "source_scorecard_hash": "",
        "source_scorecard_integrity": "NONE",
        "proposal_scope": _text(
            (validation_plan or {}).get("proposal_scope")
        ).upper(),
        "target_metric": _text(
            (validation_plan or {}).get("target_metric")
        ).upper(),
        "expected_capacity": 0,
        "baseline_value": 0.0,
        "shadow_value": 0.0,
        "qualified_outcome_records": 0,
        "future_outcomes_seen": 0,
        "eligible_outcomes": 0,
        "immature_outcomes": 0,
        "preplan_outcomes": 0,
        "preplan_projection_outcomes": 0,
        "assumption_drift_outcomes": 0,
        "baseline_drift_outcomes": 0,
        "invalid_outcomes": 0,
        "duplicate_outcomes": 0,
        "required_future_outcomes": max(
            3,
            _int(
                (validation_plan or {}).get(
                    "min_future_outcomes"
                )
            ),
        ),
        "required_closed_intervals": max(
            2,
            _int(
                (validation_plan or {}).get(
                    "min_future_closed_intervals"
                )
            ),
        ),
        "baseline_mean_abs_error": 0.0,
        "shadow_mean_abs_error": 0.0,
        "relative_error_improvement_pct": 0.0,
        "min_relative_error_improvement_pct": _float(
            (validation_plan or {}).get(
                "min_relative_error_improvement_pct"
            )
        ),
        "max_relative_error_degradation_pct": _float(
            (validation_plan or {}).get(
                "max_relative_error_degradation_pct"
            )
        ),
        "evidence_outcome_ids_json": "[]",
        "evidence_outcome_hashes_json": "[]",
        "evidence_table": pd.DataFrame(),
        "validation_authorization": "NONE",
        "proposal_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if plan_state in {
        "",
        "SHADOW_VALIDATION_UPSTREAM_WAIT",
        "SHADOW_VALIDATION_PROPOSAL_REQUIRED",
        "SHADOW_VALIDATION_PLAN_REQUIRED",
        "SHADOW_VALIDATION_PLAN_SUPERSEDED",
    }:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_UPSTREAM_WAIT",
            "validation_guard": "HOLD_VALIDATION_PLAN",
        }

    if plan_state == "SHADOW_VALIDATION_NOT_REQUIRED":
        return {
            **base,
            "validation_state": "SHADOW_EVAL_NOT_REQUIRED",
            "validation_guard": "NO_SHADOW_EVALUATION",
        }

    if plan_state == "SHADOW_VALIDATION_PLAN_INTEGRITY_REVIEW":
        return {
            **base,
            "validation_state": "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    plan_source = _latest_locked_plan(
        validation_plan
    )

    if not plan_source:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    plan_integrity = _text(
        shadow_validation_plan_snapshot_integrity(
            plan_source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_plan_id": _text(
                plan_source.get(
                    "shadow_validation_plan_id"
                )
            ),
            "source_plan_hash": _text(
                plan_source.get(
                    "snapshot_hash"
                )
            ),
            "source_plan_created_at": _text(
                plan_source.get(
                    "created_at"
                )
            ),
            "source_plan_integrity": plan_integrity,
            "source_proposal_id": _text(
                plan_source.get(
                    "source_proposal_id"
                )
            ),
            "source_proposal_hash": _text(
                plan_source.get(
                    "source_proposal_hash"
                )
            ),
            "source_scorecard_snapshot_id": _text(
                plan_source.get(
                    "source_scorecard_snapshot_id"
                )
            ),
            "source_scorecard_hash": _text(
                plan_source.get(
                    "source_scorecard_hash"
                )
            ),
            "proposal_scope": _text(
                plan_source.get(
                    "proposal_scope"
                )
            ).upper(),
            "target_metric": _text(
                plan_source.get(
                    "target_metric"
                )
            ).upper(),
            "required_future_outcomes": max(
                3,
                _int(
                    plan_source.get(
                        "min_future_outcomes"
                    )
                ),
            ),
            "required_closed_intervals": max(
                2,
                _int(
                    plan_source.get(
                        "min_future_closed_intervals"
                    )
                ),
            ),
            "min_relative_error_improvement_pct": _float(
                plan_source.get(
                    "min_relative_error_improvement_pct"
                )
            ),
            "max_relative_error_degradation_pct": _float(
                plan_source.get(
                    "max_relative_error_degradation_pct"
                )
            ),
        }
    )

    proposal_source = _latest_locked_proposal(
        recalibration_proposal
    )

    if not proposal_source:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    proposal_integrity = _text(
        recalibration_proposal_snapshot_integrity(
            proposal_source
        ).get("status")
    ).upper()

    base[
        "source_proposal_integrity"
    ] = proposal_integrity

    if (
        proposal_integrity != "OK"
        or _text(
            proposal_source.get(
                "recalibration_proposal_id"
            )
        )
        != base["source_proposal_id"]
        or _text(
            proposal_source.get(
                "snapshot_hash"
            )
        )
        != base["source_proposal_hash"]
    ):
        return {
            **base,
            "validation_state": "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    base[
        "baseline_value"
    ] = _float(
        proposal_source.get(
            "current_value"
        )
    )
    base[
        "shadow_value"
    ] = _float(
        proposal_source.get(
            "proposed_value"
        )
    )

    scorecard_source = _scorecard_source(
        proposal_source,
        scorecard_snapshots,
    )

    if not scorecard_source:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW",
            "validation_guard": "HOLD_VALIDATION_SOURCE",
        }

    base[
        "source_scorecard_integrity"
    ] = "OK"
    base[
        "expected_capacity"
    ] = max(
        1,
        _int(
            scorecard_source.get(
                "latest_capacity"
            )
        ),
    )

    scope = base[
        "proposal_scope"
    ]

    if scope == "MODEL_SHADOW":
        return {
            **base,
            "validation_state": "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED",
            "validation_guard": "HOLD_MODEL_EVALUATOR",
        }

    if scope != "PARAMETER_SHADOW":
        return {
            **base,
            "validation_state": "SHADOW_EVAL_NOT_REQUIRED",
            "validation_guard": "NO_SHADOW_EVALUATION",
        }

    if (
        base["target_metric"]
        != "BASE_BURN_RATE"
        or base["baseline_value"] <= 0
        or base["shadow_value"] <= 0
    ):
        return {
            **base,
            "validation_state": "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    plan_ts = pd.to_datetime(
        base[
            "source_plan_created_at"
        ],
        errors="coerce",
        utc=True,
    )

    if pd.isna(
        plan_ts
    ):
        return {
            **base,
            "validation_state": "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_VALIDATION_INTEGRITY",
        }

    df = (
        pd.DataFrame()
        if qualified_outcomes is None
        else qualified_outcomes.copy()
    )

    for col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    base[
        "qualified_outcome_records"
    ] = int(
        len(
            df
        )
    )

    if df.empty:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES",
            "validation_guard": "WAIT_OUT_OF_SAMPLE_EVIDENCE",
        }

    rows = []
    invalid_count = 0
    preplan_count = 0
    preplan_projection_count = 0
    assumption_drift_count = 0
    baseline_drift_count = 0
    immature_count = 0
    duplicate_count = 0

    dedup = {}

    for _, row in df.iterrows():
        item = row.to_dict()

        if _text(
            flow_projection_outcome_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            invalid_count += 1
            continue

        outcome_ts = pd.to_datetime(
            item.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )
        projection_ts = pd.to_datetime(
            item.get(
                "source_projection_created_at"
            ),
            errors="coerce",
            utc=True,
        )

        if pd.isna(
            outcome_ts
        ) or pd.isna(
            projection_ts
        ):
            invalid_count += 1
            continue

        if outcome_ts <= plan_ts:
            preplan_count += 1
            continue

        if projection_ts <= plan_ts:
            preplan_projection_count += 1
            continue

        key = (
            _text(
                item.get(
                    "source_projection_snapshot_id"
                )
            ),
            _text(
                item.get(
                    "evidence_end_trend_snapshot_id"
                )
            ),
        )

        previous = dedup.get(
            key
        )

        if previous is not None:
            duplicate_count += 1

            prev_ts = pd.to_datetime(
                previous.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )

            if outcome_ts <= prev_ts:
                continue

        dedup[
            key
        ] = item

    future_records = list(
        dedup.values()
    )

    base[
        "future_outcomes_seen"
    ] = len(
        future_records
    )

    tolerance = max(
        1e-8,
        abs(
            base[
                "baseline_value"
            ]
        )
        * 1e-6,
    )

    for item in sorted(
        future_records,
        key=lambda x: pd.to_datetime(
            x.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        ),
    ):
        capacity = max(
            1,
            _int(
                item.get(
                    "capacity"
                )
            ),
        )
        capacity_drift = _int(
            item.get(
                "capacity_drift_count"
            )
        )
        evaluation_state = _text(
            item.get(
                "evaluation_state"
            )
        ).upper()

        if (
            capacity != base[
                "expected_capacity"
            ]
            or capacity_drift > 0
            or evaluation_state
            == "ASSUMPTION_DRIFT_REVIEW"
        ):
            assumption_drift_count += 1
            continue

        base_burn = _float(
            item.get(
                "base_burn_rate"
            )
        )

        if abs(
            base_burn
            - base[
                "baseline_value"
            ]
        ) > tolerance:
            baseline_drift_count += 1
            continue

        intervals = _int(
            item.get(
                "evidence_intervals"
            )
        )

        if intervals < base[
            "required_closed_intervals"
        ]:
            immature_count += 1
            continue

        realized = _float(
            item.get(
                "realized_avg_net_burn"
            )
        )

        baseline_error = abs(
            realized
            - base[
                "baseline_value"
            ]
        )
        shadow_error = abs(
            realized
            - base[
                "shadow_value"
            ]
        )

        rows.append(
            {
                "outcome_snapshot_id":
                    _text(
                        item.get(
                            "outcome_snapshot_id"
                        )
                    ),
                "outcome_hash":
                    _text(
                        item.get(
                            "snapshot_hash"
                        )
                    ),
                "created_at":
                    _text(
                        item.get(
                            "created_at"
                        )
                    ),
                "source_projection_snapshot_id":
                    _text(
                        item.get(
                            "source_projection_snapshot_id"
                        )
                    ),
                "evidence_end_trend_snapshot_id":
                    _text(
                        item.get(
                            "evidence_end_trend_snapshot_id"
                        )
                    ),
                "evidence_intervals":
                    intervals,
                "capacity":
                    capacity,
                "realized_avg_net_burn":
                    realized,
                "baseline_value":
                    base[
                        "baseline_value"
                    ],
                "shadow_value":
                    base[
                        "shadow_value"
                    ],
                "baseline_abs_error":
                    baseline_error,
                "shadow_abs_error":
                    shadow_error,
            }
        )

    evidence_table = pd.DataFrame(
        rows
    )

    base.update(
        {
            "eligible_outcomes":
                int(
                    len(
                        evidence_table
                    )
                ),
            "immature_outcomes":
                immature_count,
            "preplan_outcomes":
                preplan_count,
            "preplan_projection_outcomes":
                preplan_projection_count,
            "assumption_drift_outcomes":
                assumption_drift_count,
            "baseline_drift_outcomes":
                baseline_drift_count,
            "invalid_outcomes":
                invalid_count,
            "duplicate_outcomes":
                duplicate_count,
            "evidence_table":
                evidence_table,
            "evidence_outcome_ids_json":
                json.dumps(
                    (
                        evidence_table[
                            "outcome_snapshot_id"
                        ]
                        .astype(str)
                        .tolist()
                        if not evidence_table.empty
                        else []
                    ),
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            "evidence_outcome_hashes_json":
                json.dumps(
                    (
                        evidence_table[
                            "outcome_hash"
                        ]
                        .astype(str)
                        .tolist()
                        if not evidence_table.empty
                        else []
                    ),
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
        }
    )

    if invalid_count > 0:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW",
            "validation_guard": "HOLD_EVIDENCE_INTEGRITY",
        }

    if assumption_drift_count > 0:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW",
            "validation_guard": "HOLD_ASSUMPTION_DRIFT",
        }

    if baseline_drift_count > 0:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_BASELINE_DRIFT_REVIEW",
            "validation_guard": "HOLD_BASELINE_DRIFT",
        }

    if base[
        "future_outcomes_seen"
    ] == 0:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES",
            "validation_guard": "WAIT_OUT_OF_SAMPLE_EVIDENCE",
        }

    if base[
        "eligible_outcomes"
    ] < base[
        "required_future_outcomes"
    ]:
        return {
            **base,
            "validation_state": "SHADOW_EVAL_EVIDENCE_MATURING",
            "validation_guard": "WAIT_OUT_OF_SAMPLE_EVIDENCE",
        }

    baseline_mean = float(
        evidence_table[
            "baseline_abs_error"
        ].mean()
    )
    shadow_mean = float(
        evidence_table[
            "shadow_abs_error"
        ].mean()
    )

    base[
        "baseline_mean_abs_error"
    ] = baseline_mean
    base[
        "shadow_mean_abs_error"
    ] = shadow_mean

    if baseline_mean <= 1e-12:
        improvement = (
            0.0
            if shadow_mean <= 1e-12
            else -1.0
        )
    else:
        improvement = (
            baseline_mean
            - shadow_mean
        ) / baseline_mean

    base[
        "relative_error_improvement_pct"
    ] = improvement

    min_improvement = base[
        "min_relative_error_improvement_pct"
    ]
    max_degradation = base[
        "max_relative_error_degradation_pct"
    ]

    if improvement >= min_improvement:
        state = "SHADOW_EVAL_PASS"
        guard = "SHADOW_VALIDATION_PASS_NO_APPLY"
    elif improvement <= -max_degradation:
        state = "SHADOW_EVAL_FAIL"
        guard = "SHADOW_VALIDATION_FAIL_NO_APPLY"
    else:
        state = "SHADOW_EVAL_INCONCLUSIVE"
        guard = "SHADOW_VALIDATION_INCONCLUSIVE_NO_APPLY"

    return {
        **base,
        "validation_state":
            state,
        "validation_guard":
            guard,
    }


def build_flow_shadow_validation_outcome_snapshot(
    validation: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = validation or {}

    state = _text(
        current.get(
            "validation_state"
        )
    ).upper()

    if state not in SHADOW_VALIDATION_OUTCOME_STATES:
        raise ValueError(
            "Shadow Validation Outcome state가 유효하지 않습니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        col: current.get(
            col,
            "",
        )
        for col in FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS
        if col not in {
            "shadow_validation_outcome_id",
            "created_at",
            "note",
            "snapshot_hash",
        }
    }

    base[
        "validation_authorization"
    ] = "NONE"
    base[
        "proposal_authorization"
    ] = "NONE"
    base[
        "recalibration_authorization"
    ] = "NONE"
    base[
        "capacity_authorization"
    ] = "NONE"
    base[
        "execution_authorization"
    ] = "NONE"

    snapshot_hash = _hash(
        _outcome_payload(
            base
        )
    )

    return {
        "shadow_validation_outcome_id": (
            "OSO-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_shadow_validation_outcome_queue(
    validation: dict | None,
) -> pd.DataFrame:
    row = validation or {}

    state = _text(
        row.get(
            "validation_state"
        )
    ).upper()

    mapping = {
        "SHADOW_EVAL_UPSTREAM_WAIT": (
            "SO2",
            "WAIT",
            "SHADOW_EVAL_UPSTREAM_WAIT",
            "LOCKED Validation Plan이 아직 없음",
            "Proof/Contract/Proposal/Plan evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "SHADOW_EVAL_NOT_REQUIRED": (
            "SO3",
            "MONITOR",
            "SHADOW_EVAL_NOT_REQUIRED",
            "현재 Proposal scope에 정량 shadow evaluation이 필요하지 않음",
            "새 evidence를 계속 관찰",
        ),
        "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW": (
            "SO0",
            "BLOCKED",
            "SHADOW_EVAL_PLAN_INTEGRITY_REVIEW",
            "Validation Plan integrity mismatch",
            "Validation Plan audit integrity를 먼저 복구",
        ),
        "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW": (
            "SO0",
            "BLOCKED",
            "SHADOW_EVAL_PROPOSAL_INTEGRITY_REVIEW",
            "Proposal integrity/lineage mismatch",
            "LOCKED Proposal source integrity를 먼저 복구",
        ),
        "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW": (
            "SO0",
            "BLOCKED",
            "SHADOW_EVAL_SCORECARD_SOURCE_REVIEW",
            "Proposal source Scorecard lineage mismatch",
            "Scorecard source id/hash/integrity를 먼저 복구",
        ),
        "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED": (
            "SO1",
            "REVIEW",
            "SHADOW_EVAL_MODEL_EVALUATOR_REQUIRED",
            "MODEL_SHADOW은 실행 가능한 shadow evaluator가 아직 정의되지 않음",
            "모델 specification을 executable shadow evaluator로 별도 정의하기 전 성능 결론 금지",
        ),
        "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES": (
            "SO2",
            "WAIT",
            "SHADOW_EVAL_WAIT_FUTURE_OUTCOMES",
            "Plan 이후 eligible qualified Outcome이 아직 없음",
            "Plan 이후 새 Projection/Review/closed-session Outcome을 자연스럽게 축적",
        ),
        "SHADOW_EVAL_EVIDENCE_MATURING": (
            "SO2",
            "WAIT",
            "SHADOW_EVAL_EVIDENCE_MATURING",
            (
                f"eligible {row.get('eligible_outcomes',0)}/"
                f"{row.get('required_future_outcomes',0)} · "
                f"immature {row.get('immature_outcomes',0)}"
            ),
            "사전등록된 future Outcome 수가 충족될 때까지 대기",
        ),
        "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW": (
            "SO0",
            "BLOCKED",
            "SHADOW_EVAL_EVIDENCE_INTEGRITY_REVIEW",
            f"invalid future Outcome {row.get('invalid_outcomes',0)}",
            "Outcome immutable hash / lineage를 먼저 복구",
        ),
        "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW": (
            "SO0",
            "REVIEW",
            "SHADOW_EVAL_ASSUMPTION_DRIFT_REVIEW",
            f"assumption drift Outcomes {row.get('assumption_drift_outcomes',0)}",
            "동일 Capacity/no-assumption-drift 조건에서 새 Plan/Proposal cycle 검토",
        ),
        "SHADOW_EVAL_BASELINE_DRIFT_REVIEW": (
            "SO0",
            "REVIEW",
            "SHADOW_EVAL_BASELINE_DRIFT_REVIEW",
            f"baseline drift Outcomes {row.get('baseline_drift_outcomes',0)}",
            "live baseline drift 이후 기존 shadow comparison을 재사용하지 않음",
        ),
        "SHADOW_EVAL_PASS": (
            "SO3",
            "MONITOR",
            "SHADOW_EVAL_PASS",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "PASS는 shadow validation 결과일 뿐 live apply 금지; 별도 Human adoption gate 필요",
        ),
        "SHADOW_EVAL_FAIL": (
            "SO1",
            "REVIEW",
            "SHADOW_EVAL_FAIL",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "Proposal 폐기/재검토; live apply 금지",
        ),
        "SHADOW_EVAL_INCONCLUSIVE": (
            "SO2",
            "REVIEW",
            "SHADOW_EVAL_INCONCLUSIVE",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "사전등록 기준을 임의 변경하지 말고 새 Plan cycle 또는 추가 evidence 검토",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "SO0",
            "BLOCKED",
            "SHADOW_EVAL_UNKNOWN_STATE",
            state or "MISSING",
            "Shadow Evaluation state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            SHADOW_VALIDATION_OUTCOME_QUEUE_COLS,
    )
