from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_shadow_validation_outcome import (
    FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    SHADOW_VALIDATION_OUTCOME_STATES,
    VALIDATION_GUARD_BY_STATE,
    shadow_validation_outcome_snapshot_integrity,
)
from engine.operations_flow_shadow_adoption_review import (
    FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
    SHADOW_ADOPTION_STATES,
    ADOPTION_GUARD_BY_STATE,
    ADOPTION_DECISIONS,
    build_flow_shadow_adoption_review,
    shadow_adoption_review_snapshot_integrity,
    latest_shadow_adoption_review_snapshot,
)


ADOPTION_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

ADOPTION_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V140_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v140_adoption_context(
    *,
    v139_context: dict | None,
    shadow_validation_outcome_snapshots: pd.DataFrame | None,
    shadow_adoption_review_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v139_context or {}
    evaluation = upstream.get("evaluation") or {}

    evaluation_df = _ensure_cols(
        shadow_validation_outcome_snapshots,
        FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    )

    review_df = _ensure_cols(
        shadow_adoption_review_snapshots,
        FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
    )

    adoption = build_flow_shadow_adoption_review(
        evaluation,
        evaluation_df,
        review_df,
    )

    latest_review = latest_shadow_adoption_review_snapshot(
        review_df
    )

    latest_review_integrity = (
        _text(
            shadow_adoption_review_snapshot_integrity(
                latest_review
            ).get("status")
        ).upper()
        if latest_review
        else "NONE"
    )

    return {
        "v139_context": upstream,
        "evaluation": evaluation,
        "shadow_validation_outcome_snapshots": evaluation_df,
        "shadow_adoption_review_snapshots": review_df,
        "adoption": adoption,
        "adoption_integrity": _integrity_counts(
            review_df,
            shadow_adoption_review_snapshot_integrity,
        ),
        "latest_adoption_review": latest_review,
        "latest_adoption_review_integrity":
            latest_review_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _source_mapping_ok(ctx: dict) -> bool:
    adoption = ctx.get("adoption") or {}
    state = _text(
        adoption.get("adoption_state")
    ).upper()

    if state in {
        "ADOPTION_UPSTREAM_WAIT",
        "ADOPTION_VALIDATION_FAILED",
        "ADOPTION_VALIDATION_INCONCLUSIVE",
    }:
        return True

    source_id = _text(
        adoption.get(
            "source_validation_outcome_id"
        )
    )
    source_hash = _text(
        adoption.get(
            "source_validation_outcome_hash"
        )
    )

    if not source_id or not source_hash:
        return state == "ADOPTION_VALIDATION_AUDIT_REQUIRED"

    index, duplicates = _index_by_id(
        ctx.get("shadow_validation_outcome_snapshots"),
        "shadow_validation_outcome_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    if not parent:
        return False

    return (
        _text(
            shadow_validation_outcome_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("validation_state")
        ).upper()
        == "SHADOW_EVAL_PASS"
    )


def _decision_contract_ok(
    adoption: dict,
) -> bool:
    state = _text(
        adoption.get("adoption_state")
    ).upper()

    if state not in {
        "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
        "ADOPTION_REJECTED",
        "ADOPTION_DEFERRED",
    }:
        return True

    review = adoption.get(
        "latest_review"
    ) or {}

    if not review:
        return False

    if _text(
        shadow_adoption_review_snapshot_integrity(
            review
        ).get("status")
    ).upper() != "OK":
        return False

    decision = _text(
        review.get("decision")
    ).upper()

    if decision not in ADOPTION_DECISIONS:
        return False

    expected_state = {
        "ACCEPT_FOR_CONTROLLED_TRIAL":
            "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
        "REJECT":
            "ADOPTION_REJECTED",
        "DEFER":
            "ADOPTION_DEFERRED",
    }.get(
        decision
    )

    if state != expected_state:
        return False

    required = [
        "validation_evidence_reviewed",
        "risk_reversal_reviewed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            review.get(field)
        )
        for field in required
    ):
        return False

    if (
        decision
        == "ACCEPT_FOR_CONTROLLED_TRIAL"
        and not _bool(
            review.get(
                "controlled_trial_only_confirmed"
            )
        )
    ):
        return False

    if len(
        _text(
            review.get(
                "decision_detail"
            )
        )
    ) < 30:
        return False

    return True


def _time_order_ok(ctx: dict) -> bool:
    adoption = ctx.get("adoption") or {}
    state = _text(
        adoption.get("adoption_state")
    ).upper()

    if state not in {
        "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
        "ADOPTION_REJECTED",
        "ADOPTION_DEFERRED",
    }:
        return True

    review = adoption.get(
        "latest_review"
    ) or {}

    source_ts = pd.to_datetime(
        adoption.get(
            "source_validation_outcome_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    review_ts = pd.to_datetime(
        review.get(
            "created_at"
        ),
        errors="coerce",
        utc=True,
    )

    return (
        not pd.isna(source_ts)
        and not pd.isna(review_ts)
        and review_ts > source_ts
    )


def _supersession_ok(ctx: dict) -> bool:
    adoption = ctx.get("adoption") or {}
    state = _text(
        adoption.get("adoption_state")
    ).upper()

    if state != "ADOPTION_SOURCE_SUPERSEDED":
        return True

    latest_review = ctx.get(
        "latest_adoption_review"
    ) or {}

    if not latest_review:
        return True

    return (
        _text(
            latest_review.get(
                "source_validation_outcome_id"
            )
        )
        != _text(
            adoption.get(
                "source_validation_outcome_id"
            )
        )
        or _text(
            latest_review.get(
                "source_validation_outcome_hash"
            )
        )
        != _text(
            adoption.get(
                "source_validation_outcome_hash"
            )
        )
    )


def _no_live_apply_ok(ctx: dict) -> bool:
    violations = 0

    for item in [
        ctx.get("adoption") or {},
        ctx.get("latest_adoption_review") or {},
        ctx.get("evaluation") or {},
    ]:
        for field in [
            "adoption_authorization",
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = ctx.get(
        "shadow_adoption_review_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "adoption_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        ctx.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v140_adoption_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    adoption = ctx.get("adoption") or {}
    evaluation = ctx.get("evaluation") or {}
    counts = ctx.get("adoption_integrity") or {}

    state = _text(
        adoption.get("adoption_state")
    ).upper()
    guard = _text(
        adoption.get("adoption_guard")
    ).upper()
    evaluation_state = _text(
        evaluation.get("validation_state")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Shadow Adoption Review Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Shadow Adoption Review immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Adoption State / Guard Vocabulary",
            (
                state in SHADOW_ADOPTION_STATES
                and guard
                == ADOPTION_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {ADOPTION_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Adoption state/guard vocabulary 확인",
        )
    )

    if evaluation_state == "SHADOW_EVAL_PASS":
        routing_ok = state in {
            "ADOPTION_VALIDATION_AUDIT_REQUIRED",
            "ADOPTION_VALIDATION_INTEGRITY_REVIEW",
            "ADOPTION_SOURCE_SUPERSEDED",
            "ADOPTION_REVIEW_REQUIRED",
            "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
            "ADOPTION_REJECTED",
            "ADOPTION_DEFERRED",
        }
    elif evaluation_state == "SHADOW_EVAL_FAIL":
        routing_ok = (
            state
            == "ADOPTION_VALIDATION_FAILED"
        )
    elif evaluation_state == "SHADOW_EVAL_INCONCLUSIVE":
        routing_ok = (
            state
            == "ADOPTION_VALIDATION_INCONCLUSIVE"
        )
    else:
        routing_ok = (
            state
            == "ADOPTION_UPSTREAM_WAIT"
        )

    checks.append(
        _technical_row(
            "Shadow Evaluation → Adoption State Invariant",
            routing_ok,
            (
                f"evaluation {evaluation_state or 'MISSING'} · "
                f"adoption {state or 'MISSING'}"
            ),
            "PASS/FAIL/INCONCLUSIVE/upstream routing 확인",
        )
    )

    checks.append(
        _technical_row(
            "Adoption → Validation PASS Source Mapping",
            _source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(adoption.get('source_validation_outcome_id')) or 'NONE'} · "
                f"integrity {_text(adoption.get('source_validation_outcome_integrity')) or 'NONE'}"
            ),
            "Adoption source PASS audit id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Adoption Human Decision Contract Invariant",
            _decision_contract_ok(
                adoption
            ),
            (
                f"state {state or 'MISSING'} · "
                f"decision {_text(adoption.get('decision')) or 'NONE'}"
            ),
            "Human decision/rationale/confirmations 확인",
        )
    )

    checks.append(
        _technical_row(
            "Validation PASS → Adoption Review Time-order Invariant",
            _time_order_ok(
                ctx
            ),
            (
                f"source created "
                f"{_text(adoption.get('source_validation_outcome_created_at')) or 'NONE'} · "
                f"review created "
                f"{_text((adoption.get('latest_review') or {}).get('created_at')) or 'NONE'}"
            ),
            "Adoption Review가 PASS audit 이후 저장되었는지 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Adoption Source Supersession Invariant",
            _supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"current source {_text(adoption.get('source_validation_outcome_id')) or 'NONE'} · "
                f"latest review source "
                f"{_text((ctx.get('latest_adoption_review') or {}).get('source_validation_outcome_id')) or 'NONE'}"
            ),
            "새 PASS audit에서 이전 Human decision 재사용 차단 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Adoption No-Live-Apply Authorization Invariant",
            _no_live_apply_ok(
                ctx
            ),
            "NONE",
            "Adoption/Validation/Proposal/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "ADOPTION_VALIDATION_FAILED",
            "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
            "ADOPTION_REJECTED",
            "ADOPTION_DEFERRED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Shadow Adoption Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"evaluation {evaluation_state or 'MISSING'} · "
                f"decision {_text(adoption.get('decision')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 validation/adoption wait는 Technical FAIL로 승격하지 않고 "
                    "prospective evidence 및 Human Review를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "adoption_state": state,
        "evaluation_state": evaluation_state,
        "decision": _text(
            adoption.get("decision")
        ).upper(),
        "latest_shadow_adoption_integrity":
            _text(
                ctx.get(
                    "latest_adoption_review_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=ADOPTION_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v140_adoption_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    review_df = _ensure_cols(
        ctx.get(
            "shadow_adoption_review_snapshots"
        ),
        FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
    )
    evaluation_df = _ensure_cols(
        ctx.get(
            "shadow_validation_outcome_snapshots"
        ),
        FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        review_df,
        shadow_adoption_review_snapshot_integrity,
    )

    evaluation_index, evaluation_duplicates = _index_by_id(
        evaluation_df,
        "shadow_validation_outcome_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in review_df.iterrows():
        item = row.to_dict()

        review_id = _text(
            item.get(
                "shadow_adoption_review_id"
            )
        )

        if review_id:
            if review_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(review_id)

        state = _text(
            item.get(
                "adoption_state"
            )
        ).upper()
        decision = _text(
            item.get(
                "decision"
            )
        ).upper()

        expected_state = {
            "ACCEPT_FOR_CONTROLLED_TRIAL":
                "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
            "REJECT":
                "ADOPTION_REJECTED",
            "DEFER":
                "ADOPTION_DEFERRED",
        }.get(
            decision
        )

        required = [
            "validation_evidence_reviewed",
            "risk_reversal_reviewed",
            "no_live_apply_confirmed",
            "no_auto_recalibration_confirmed",
            "no_auto_capacity_confirmed",
            "no_execution_authorization_confirmed",
            "human_review_confirmed",
        ]

        if (
            decision not in ADOPTION_DECISIONS
            or state != expected_state
            or len(
                _text(
                    item.get(
                        "decision_detail"
                    )
                )
            ) < 30
            or not all(
                _bool(
                    item.get(field)
                )
                for field in required
            )
            or (
                decision == "ACCEPT_FOR_CONTROLLED_TRIAL"
                and not _bool(
                    item.get(
                        "controlled_trial_only_confirmed"
                    )
                )
            )
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_validation_outcome_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_validation_outcome_hash"
            )
        )

        parent = evaluation_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                shadow_validation_outcome_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get(
                    "snapshot_hash"
                )
            )
            != source_hash
            or _text(
                parent.get(
                    "validation_state"
                )
            ).upper()
            != "SHADOW_EVAL_PASS"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )
            review_ts = pd.to_datetime(
                item.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(review_ts)
                or review_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "adoption_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Shadow Adoption Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Shadow Adoption immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Adoption Audit State / Human Decision Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "decision/state/rationale/confirmations 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Adoption Audit → Validation PASS Lineage",
            (
                lineage_violations == 0
                and evaluation_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"validation duplicate ids {evaluation_duplicates}"
            ),
            "Adoption source Validation PASS audit id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Adoption Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate review ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Adoption audit identity uniqueness 및 PASS audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Shadow Adoption Audit Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Adoption/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("adoption") or {}).get(
            "adoption_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "ADOPTION_VALIDATION_FAILED",
            "ADOPTION_ACCEPTED_FOR_CONTROLLED_TRIAL",
            "ADOPTION_REJECTED",
            "ADOPTION_DEFERRED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Shadow Adoption Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current adoption {current_state or 'MISSING'} · "
                f"saved reviews {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 immutable SHADOW_EVAL_PASS audit 이후 Human Adoption decision이 필요할 때만 "
                    "Adoption audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=ADOPTION_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v140_release_readiness(
    *,
    v139_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    adoption_release_gate: str,
    adoption_audit_gate: str,
    adoption_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(
        v139_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    release_gate = _text(
        adoption_release_gate
    ).upper()
    audit_gate = _text(
        adoption_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.39 Shadow Validation Outcome Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Shadow Adoption Technical Release Gate",
            release_gate == "PASS",
            release_gate or "MISSING",
        ),
        _candidate_row(
            "Shadow Adoption Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(
            adoption_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "SHADOW_ADOPTION_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V140_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v140_integration_crosscheck(
    *,
    integration_consistency: str,
    adoption_release_gate: str,
    adoption_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Shadow Adoption Technical Gate",
            _text(
                adoption_release_gate
            ).upper()
            == "PASS",
            _text(
                adoption_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Shadow Adoption Audit Gate",
            _text(
                adoption_audit_gate
            ).upper()
            == "PASS",
            _text(
                adoption_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V140_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v140_data_crosscheck(
    *,
    csv_fail_count: int,
    adoption_release_gate: str,
    adoption_audit_gate: str,
    latest_adoption_integrity: str,
) -> dict:
    latest = _text(
        latest_adoption_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Shadow Adoption Technical Gate",
            _text(
                adoption_release_gate
            ).upper()
            == "PASS",
            _text(
                adoption_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Shadow Adoption Audit Gate",
            _text(
                adoption_audit_gate
            ).upper()
            == "PASS",
            _text(
                adoption_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Shadow Adoption Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V140_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
