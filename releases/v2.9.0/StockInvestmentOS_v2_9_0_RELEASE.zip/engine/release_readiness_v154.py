from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import urlparse
import hashlib
import json
import re

import pandas as pd

from updater.release_feed import (
    trusted_release_feed_status,
)
from updater.release_publisher import (
    publisher_status,
)
from updater.repository_deployer import (
    deployment_status,
)
from updater.release_manager import (
    ensure_runtime_dirs,
)


UPDATER2_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

UPDATER2_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V154_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


V153_RELEASE_ZIP_SHA256 = (
    "e572f5faf3ed8c3226a535cfa8952d338befc3b4e8198c374bdf4d88d7ddae97"
)

V153_RELEASE_MANIFEST_FILE_SHA256 = (
    "f8522daba02a2c12429eb1cec4eb7d0cb166d4bb8022adad18bdc4a94325e522"
)

V153_RELEASE_NOTES_FILE_SHA256 = (
    "6515a0d7a326097d52bfaec28689b76f6c7a0c48ac5fa47650062852afe90499"
)

V153_BASELINE_PROVENANCE_REL = "release_baselines/v1_53_0.json"


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
    }


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(
            float(value)
        )
    except Exception:
        return 0


def _sha256_path(
    path: Path,
) -> str:
    h = hashlib.sha256()

    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(
                1024 * 1024
            ),
            b"",
        ):
            h.update(chunk)

    return h.hexdigest()


def _read_json(
    path: Path,
) -> dict:
    if not path.is_file():
        return {}

    try:
        return json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {}


def _inside(
    child: Path,
    parent: Path,
) -> bool:
    try:
        Path(
            child
        ).resolve().relative_to(
            Path(
                parent
            ).resolve()
        )
        return True
    except Exception:
        return False


def _is_sha256(
    value: Any,
) -> bool:
    return bool(
        re.fullmatch(
            r"[0-9a-fA-F]{64}",
            _text(value),
        )
    )


def verify_v153_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(
        code_root
    ).resolve()

    provenance_path = (
        root
        / V153_BASELINE_PROVENANCE_REL
    )

    record = {}
    record_ok = False
    record_detail = ""

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            record_detail = (
                f"{type(exc).__name__}: {exc}"
            )
        else:
            record_ok = (
                _text(
                    record.get(
                        "release_version"
                    )
                )
                == "v1.53.0"
                and _text(
                    record.get(
                        "release_zip_sha256"
                    )
                ).lower()
                == V153_RELEASE_ZIP_SHA256
                and _text(
                    record.get(
                        "manifest_file_sha256"
                    )
                ).lower()
                == V153_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get(
                        "release_notes_file_sha256"
                    )
                ).lower()
                == V153_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get(
                        "provenance_status"
                    )
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )

            record_detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    manifest_path = (
        root
        / "manifest_sha256.json"
    )

    notes_path = (
        root
        / "RELEASE_NOTES_v1_53_0.txt"
    )

    original_manifest_ok = (
        manifest_path.is_file()
        and _sha256_path(
            manifest_path
        )
        == V153_RELEASE_MANIFEST_FILE_SHA256
    )

    original_notes_ok = (
        notes_path.is_file()
        and _sha256_path(
            notes_path
        )
        == V153_RELEASE_NOTES_FILE_SHA256
    )

    original_artifacts_ok = (
        original_manifest_ok
        and original_notes_ok
    )

    verified = (
        record_ok
        or original_artifacts_ok
    )

    source = (
        "PROVENANCE_RECORD"
        if record_ok
        else (
            "ORIGINAL_V153_RELEASE_ARTIFACTS"
            if original_artifacts_ok
            else "NONE"
        )
    )

    return {
        "status": (
            "VERIFIED"
            if verified
            else "BLOCKED"
        ),
        "verified":
            verified,
        "source":
            source,
        "record_path":
            str(
                provenance_path
            ),
        "record_detail":
            record_detail,
        "release_version":
            "v1.53.0",
        "release_zip_sha256":
            V153_RELEASE_ZIP_SHA256,
        "manifest_file_sha256":
            V153_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256":
            V153_RELEASE_NOTES_FILE_SHA256,
        "original_manifest_match":
            original_manifest_ok,
        "original_release_notes_match":
            original_notes_ok,
    }


def build_v154_updater2_context(
    code_root: str | Path,
) -> dict:
    root = Path(
        code_root
    ).resolve()

    dirs = ensure_runtime_dirs(
        root
    )

    policy_path = (
        root
        / "updater"
        / "SELF_UPDATE_POLICY.json"
    )

    policy = _read_json(
        policy_path
    )

    feed = trusted_release_feed_status(
        root
    )

    publisher = publisher_status(
        root
    )

    deployment = deployment_status(
        root
    )

    control_root = Path(
        dirs["control"]
    ).resolve()

    publisher_repo = Path(
        publisher.get(
            "repository_root"
        )
        or control_root
    ).resolve()

    deployment_repo = Path(
        deployment.get(
            "repository_root"
        )
        or control_root
    ).resolve()

    return {
        "root":
            str(root),
        "control_root":
            str(control_root),
        "policy_path":
            str(policy_path),
        "policy":
            policy,
        "feed":
            feed,
        "publisher":
            publisher,
        "deployment":
            deployment,
        "publisher_repository_inside_control":
            _inside(
                publisher_repo,
                control_root,
            ),
        "deployment_repository_inside_control":
            _inside(
                deployment_repo,
                control_root,
            ),
        "execution_authorization":
            "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer":
            "TECHNICAL",
        "check":
            check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail":
            detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def _policy_contract(
    context: dict,
) -> tuple[bool, str]:
    policy = (
        context.get(
            "policy"
        )
        or {}
    )

    feed_policy = (
        policy.get(
            "trusted_release_feed"
        )
        or {}
    )

    publisher_policy = (
        policy.get(
            "release_publisher"
        )
        or {}
    )

    deployment_policy = (
        policy.get(
            "static_https_deployment"
        )
        or {}
    )

    passed = (
        _text(
            feed_policy.get(
                "production_scheme"
            )
        ).lower()
        == "https"
        and _text(
            feed_policy.get(
                "host_pinning"
            )
        ).lower()
        == "required"
        and _text(
            feed_policy.get(
                "package_sha256"
            )
        ).lower()
        == "required"
        and _text(
            feed_policy.get(
                "validation_result_pass"
            )
        ).lower()
        == "required"
        and _text(
            feed_policy.get(
                "internal_manifest_verification"
            )
        ).lower()
        == "required"
        and _text(
            feed_policy.get(
                "managed_code_clean"
            )
        ).lower()
        == "required"
        and _text(
            feed_policy.get(
                "runtime_data_access"
            )
        ).lower()
        == "prohibited"
        and _text(
            feed_policy.get(
                "secrets_access"
            )
        ).lower()
        == "prohibited"
        and _text(
            publisher_policy.get(
                "repository_root_scope"
            )
        ).lower()
        == "work/control only"
        and _text(
            deployment_policy.get(
                "repository_root_scope"
            )
        ).lower()
        == "work/control only"
        and deployment_policy.get(
            "git_credentials_stored_by_app"
        )
        is False
    )

    detail = (
        f"feed scheme {_text(feed_policy.get('production_scheme')) or 'MISSING'} · "
        f"host pin {_text(feed_policy.get('host_pinning')) or 'MISSING'} · "
        f"publisher scope {_text(publisher_policy.get('repository_root_scope')) or 'MISSING'} · "
        f"deployment credentials stored {deployment_policy.get('git_credentials_stored_by_app')}"
    )

    return (
        passed,
        detail,
    )


def _feed_runtime_contract(
    context: dict,
) -> tuple[bool, str]:
    feed = (
        context.get(
            "feed"
        )
        or {}
    )

    status = _text(
        feed.get(
            "status"
        )
    ).upper()

    config = (
        feed.get(
            "config"
        )
        or {}
    )

    if status == "DISABLED":
        passed = (
            config.get(
                "enabled"
            )
            is False
            and config.get(
                "auto_sync"
            )
            is False
            and config.get(
                "allow_file_source"
            )
            is False
        )

        return (
            passed,
            (
                f"status {status} · enabled {config.get('enabled')} · "
                f"auto_sync {config.get('auto_sync')} · "
                f"allow_file_source {config.get('allow_file_source')}"
            ),
        )

    if status == "ENABLED":
        feed_url = _text(
            config.get(
                "feed_url"
            )
        )

        parsed = urlparse(
            feed_url
        )

        allowed_hosts = [
            _text(x).lower()
            for x in (
                config.get(
                    "allowed_hosts"
                )
                or []
            )
            if _text(x)
        ]

        passed = (
            parsed.scheme.lower()
            == "https"
            and bool(
                parsed.hostname
            )
            and parsed.hostname.lower()
            in allowed_hosts
            and config.get(
                "allow_file_source"
            )
            is False
        )

        return (
            passed,
            (
                f"status {status} · scheme {parsed.scheme or 'NONE'} · "
                f"host {parsed.hostname or 'NONE'} · "
                f"allowed {len(allowed_hosts)}"
            ),
        )

    return (
        False,
        f"unexpected Trusted Feed status {status or 'MISSING'}",
    )


def _feed_last_state_contract(
    context: dict,
) -> tuple[bool, str]:
    feed = (
        context.get(
            "feed"
        )
        or {}
    )

    state = (
        feed.get(
            "last_state"
        )
        or {}
    )

    if not state:
        return (
            True,
            "no feed state yet",
        )

    status = _text(
        state.get(
            "status"
        )
    ).upper()

    known = {
        "UPDATE_AVAILABLE",
        "UP_TO_DATE",
        "SYNCED_TO_INBOX",
        "BLOCKED",
        "DISABLED",
        "AUTO_SYNC_DISABLED",
        "NOT_DUE",
    }

    sha = _text(
        state.get(
            "package_sha256"
        )
    )

    sha_ok = (
        not sha
        or _is_sha256(
            sha
        )
    )

    passed = (
        status in known
        and sha_ok
        and state.get(
            "auto_approval_performed",
            False,
        )
        is False
        and state.get(
            "auto_apply_performed",
            False,
        )
        is False
        and _text(
            state.get(
                "execution_authorization",
                "NONE",
            )
        ).upper()
        == "NONE"
    )

    return (
        passed,
        (
            f"state {status or 'MISSING'} · sha {'OK' if sha_ok else 'BAD'} · "
            f"auto approval {state.get('auto_approval_performed',False)} · "
            f"auto apply {state.get('auto_apply_performed',False)}"
        ),
    )


def _publisher_contract(
    context: dict,
) -> tuple[bool, str]:
    publisher = (
        context.get(
            "publisher"
        )
        or {}
    )

    status = _text(
        publisher.get(
            "status"
        )
    ).upper()

    latest_version = _text(
        publisher.get(
            "latest_published_version"
        )
    )

    latest_sha = _text(
        publisher.get(
            "latest_package_sha256"
        )
    )

    if status == "NOT_INITIALIZED":
        passed = (
            context.get(
                "publisher_repository_inside_control"
            )
            is True
            and latest_version
            in {
                "",
                "-",
            }
            and latest_sha
            in {
                "",
                "-",
            }
        )

        return (
            passed,
            (
                f"status {status} · repository inside control "
                f"{context.get('publisher_repository_inside_control')}"
            ),
        )

    if status == "READY":
        passed = (
            context.get(
                "publisher_repository_inside_control"
            )
            is True
            and bool(
                latest_version
                and latest_version
                != "-"
            )
            and _is_sha256(
                latest_sha
            )
        )

        return (
            passed,
            (
                f"status {status} · latest {latest_version or 'NONE'} · "
                f"sha {'OK' if _is_sha256(latest_sha) else 'BAD'}"
            ),
        )

    return (
        False,
        f"unexpected Publisher status {status or 'MISSING'}",
    )


def _deployment_contract(
    context: dict,
) -> tuple[bool, str]:
    deployment = (
        context.get(
            "deployment"
        )
        or {}
    )

    status = _text(
        deployment.get(
            "status"
        )
    ).upper()

    credentials_stored = deployment.get(
        "credentials_stored_by_app"
    )

    passed = (
        status
        in {
            "DISABLED",
            "CONFIGURED",
            "CONNECTED",
        }
        and context.get(
            "deployment_repository_inside_control"
        )
        is True
        and credentials_stored
        is False
    )

    remote_url = _text(
        deployment.get(
            "remote_url"
        )
    )

    if (
        passed
        and status
        in {
            "CONFIGURED",
            "CONNECTED",
        }
        and remote_url
    ):
        parsed = urlparse(
            remote_url
        )

        if parsed.scheme.lower() == "https":
            passed = (
                parsed.username
                is None
                and parsed.password
                is None
            )

    return (
        passed,
        (
            f"status {status or 'MISSING'} · git available "
            f"{deployment.get('git_available')} · "
            f"repo inside control {context.get('deployment_repository_inside_control')} · "
            f"credentials stored {credentials_stored}"
        ),
    )


def _public_feed_contract(
    context: dict,
) -> tuple[bool, str]:
    deployment = (
        context.get(
            "deployment"
        )
        or {}
    )

    state = (
        deployment.get(
            "last_state"
        )
        or {}
    )

    if not state:
        return (
            True,
            "no deployment state yet",
        )

    status = _text(
        state.get(
            "status"
        )
    ).upper()

    feed_url = _text(
        state.get(
            "public_feed_url"
        )
    )

    feed_sha = _text(
        state.get(
            "public_feed_sha256"
        )
        or state.get(
            "feed_sha256"
        )
    )

    url_ok = True

    if feed_url:
        parsed = urlparse(
            feed_url
        )
        url_ok = (
            parsed.scheme.lower()
            == "https"
            and bool(
                parsed.hostname
            )
        )

    sha_ok = (
        not feed_sha
        or _is_sha256(
            feed_sha
        )
    )

    passed = (
        status
        in {
            "DEPLOYED_TO_GIT_REMOTE",
            "PUBLIC_FEED_VERIFIED",
            "CLIENT_FEED_BOOTSTRAPPED",
        }
        and url_ok
        and sha_ok
        and state.get(
            "credentials_stored_by_app",
            False,
        )
        is False
        and _text(
            state.get(
                "execution_authorization",
                "NONE",
            )
        ).upper()
        == "NONE"
    )

    return (
        passed,
        (
            f"state {status or 'MISSING'} · url {'OK' if url_ok else 'BAD'} · "
            f"sha {'OK' if sha_ok else 'BAD'}"
        ),
    )


def _scope_contract(
    context: dict,
) -> tuple[bool, str]:
    policy = (
        context.get(
            "policy"
        )
        or {}
    )

    feed_policy = (
        policy.get(
            "trusted_release_feed"
        )
        or {}
    )

    passed = (
        context.get(
            "publisher_repository_inside_control"
        )
        is True
        and context.get(
            "deployment_repository_inside_control"
        )
        is True
        and _text(
            feed_policy.get(
                "runtime_data_access"
            )
        ).lower()
        == "prohibited"
        and _text(
            feed_policy.get(
                "secrets_access"
            )
        ).lower()
        == "prohibited"
    )

    return (
        passed,
        (
            f"publisher repo in control {context.get('publisher_repository_inside_control')} · "
            f"deployment repo in control {context.get('deployment_repository_inside_control')} · "
            f"runtime-data {_text(feed_policy.get('runtime_data_access')) or 'MISSING'} · "
            f"secrets {_text(feed_policy.get('secrets_access')) or 'MISSING'}"
        ),
    )


def _no_auto_authorization_contract(
    context: dict,
) -> tuple[bool, str]:
    policy = (
        context.get(
            "policy"
        )
        or {}
    )

    feed_policy = (
        policy.get(
            "trusted_release_feed"
        )
        or {}
    )

    deployment_policy = (
        policy.get(
            "static_https_deployment"
        )
        or {}
    )

    passed = (
        feed_policy.get(
            "auto_approval"
        )
        is False
        and feed_policy.get(
            "auto_apply"
        )
        is False
        and deployment_policy.get(
            "auto_approval"
        )
        is False
        and deployment_policy.get(
            "auto_apply"
        )
        is False
        and _text(
            policy.get(
                "execution_authorization",
                "NONE",
            )
        ).upper()
        == "NONE"
        and _text(
            context.get(
                "execution_authorization"
            )
        ).upper()
        == "NONE"
    )

    return (
        passed,
        (
            f"feed auto approval {feed_policy.get('auto_approval')} · "
            f"feed auto apply {feed_policy.get('auto_apply')} · "
            f"deployment auto approval {deployment_policy.get('auto_approval')} · "
            f"deployment auto apply {deployment_policy.get('auto_apply')} · "
            "execution NONE"
        ),
    )


def build_v154_updater2_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    checks = []

    contracts = [
        (
            "Updater2 Policy / Trust Boundary Invariant",
            _policy_contract(
                ctx
            ),
            "SELF_UPDATE_POLICY의 HTTPS/host-pin/hash/validation/work-scope 정책 확인",
        ),
        (
            "Trusted Release Feed Safe Default / Host-Pin Invariant",
            _feed_runtime_contract(
                ctx
            ),
            "Trusted Feed disabled-safe-default 또는 HTTPS host pin 설정 확인",
        ),
        (
            "Trusted Feed Last-State / No-Auto-Apply Invariant",
            _feed_last_state_contract(
                ctx
            ),
            "Feed sync state와 auto approval/apply 금지 확인",
        ),
        (
            "Release Publisher Repository / Immutable Publication Invariant",
            _publisher_contract(
                ctx
            ),
            "Publisher repository scope와 published version/SHA 확인",
        ),
        (
            "Static Deployment Connector / Credential Safety Invariant",
            _deployment_contract(
                ctx
            ),
            "Git deployment repository/credential safety 확인",
        ),
        (
            "Public Feed Verification / Bootstrap Invariant",
            _public_feed_contract(
                ctx
            ),
            "Public feed HTTPS/SHA/bootstrap state 확인",
        ),
        (
            "Updater2 Work Scope / Protected Roots Invariant",
            _scope_contract(
                ctx
            ),
            "work/control scope 및 runtime-data/secrets 비접근 확인",
        ),
        (
            "Updater2 No-Auto-Approval / No-Auto-Apply / Execution Invariant",
            _no_auto_authorization_contract(
                ctx
            ),
            "Software update approval/apply 자동화 금지 및 Execution Authorization NONE 확인",
        ),
    ]

    for check, (
        passed,
        detail,
    ), action in contracts:
        checks.append(
            _technical_row(
                check,
                passed,
                detail,
                action,
            )
        )

    technical_fail = sum(
        1
        for row in checks
        if row[
            "status"
        ]
        == "FAIL"
    )

    feed_status = _text(
        (
            ctx.get(
                "feed"
            )
            or {}
        ).get(
            "status"
        )
    ).upper()

    publisher_status_value = _text(
        (
            ctx.get(
                "publisher"
            )
            or {}
        ).get(
            "status"
        )
    ).upper()

    deployment_status_value = _text(
        (
            ctx.get(
                "deployment"
            )
            or {}
        ).get(
            "status"
        )
    ).upper()

    infrastructure_ready = (
        feed_status
        == "ENABLED"
        and publisher_status_value
        == "READY"
        and deployment_status_value
        == "CONNECTED"
    )

    operating_status = (
        "PASS"
        if infrastructure_ready
        else "REVIEW"
    )

    checks.append(
        {
            "layer":
                "OPERATING",
            "check":
                "Updater2 Infrastructure Operating Stage",
            "status":
                operating_status,
            "detail": (
                f"feed {feed_status or 'MISSING'} · "
                f"publisher {publisher_status_value or 'MISSING'} · "
                f"deployment {deployment_status_value or 'MISSING'}"
            ),
            "action": (
                ""
                if operating_status
                == "PASS"
                else (
                    "Trusted Feed / Publisher / HTTPS Deployment 연결은 운영 설정 단계이며 "
                    "미설정 상태 자체는 Technical FAIL로 승격하지 않습니다."
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail
            == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row[
                    "layer"
                ]
                == "TECHNICAL"
                and row[
                    "status"
                ]
                == "PASS"
            )
        ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "feed_status":
            feed_status
            or "MISSING",
        "publisher_status":
            publisher_status_value
            or "MISSING",
        "deployment_status":
            deployment_status_value
            or "MISSING",
        "checks":
            pd.DataFrame(
                checks,
                columns=
                    UPDATER2_RELEASE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer":
            "TECHNICAL",
        "check":
            check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail":
            detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def build_v154_updater2_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    feed = (
        ctx.get(
            "feed"
        )
        or {}
    )

    publisher = (
        ctx.get(
            "publisher"
        )
        or {}
    )

    deployment = (
        ctx.get(
            "deployment"
        )
        or {}
    )

    feed_state = (
        feed.get(
            "last_state"
        )
        or {}
    )

    publisher_state = (
        publisher.get(
            "last_state"
        )
        or {}
    )

    deployment_state = (
        deployment.get(
            "last_state"
        )
        or {}
    )

    feed_ok = True
    feed_detail = "no feed audit state"

    if feed_state:
        status = _text(
            feed_state.get(
                "status"
            )
        ).upper()

        sha = _text(
            feed_state.get(
                "package_sha256"
            )
        )

        feed_ok = (
            status
            in {
                "UPDATE_AVAILABLE",
                "UP_TO_DATE",
                "SYNCED_TO_INBOX",
                "BLOCKED",
                "DISABLED",
                "AUTO_SYNC_DISABLED",
                "NOT_DUE",
            }
            and (
                not sha
                or _is_sha256(
                    sha
                )
            )
            and feed_state.get(
                "auto_approval_performed",
                False,
            )
            is False
            and feed_state.get(
                "auto_apply_performed",
                False,
            )
            is False
        )

        feed_detail = (
            f"state {status or 'MISSING'} · "
            f"package sha {'OK' if (not sha or _is_sha256(sha)) else 'BAD'}"
        )

    publisher_ok = True
    publisher_detail = "no publisher audit state"

    if publisher_state:
        status = _text(
            publisher_state.get(
                "status"
            )
        ).upper()

        package_sha = _text(
            publisher_state.get(
                "package_sha256"
            )
        )

        publisher_ok = (
            status
            == "PUBLISHED_LOCAL_REPOSITORY"
            and _is_sha256(
                package_sha
            )
            and publisher_state.get(
                "remote_upload_performed",
                False,
            )
            is False
            and _text(
                publisher_state.get(
                    "execution_authorization",
                    "NONE",
                )
            ).upper()
            == "NONE"
        )

        publisher_detail = (
            f"state {status or 'MISSING'} · "
            f"sha {'OK' if _is_sha256(package_sha) else 'BAD'} · "
            f"remote upload {publisher_state.get('remote_upload_performed',False)}"
        )

    deployment_ok = True
    deployment_detail = "no deployment audit state"

    if deployment_state:
        status = _text(
            deployment_state.get(
                "status"
            )
        ).upper()

        allowed = {
            "DEPLOYED_TO_GIT_REMOTE",
            "PUBLIC_FEED_VERIFIED",
            "CLIENT_FEED_BOOTSTRAPPED",
        }

        deployment_ok = (
            status
            in allowed
            and deployment_state.get(
                "credentials_stored_by_app",
                False,
            )
            is False
            and _text(
                deployment_state.get(
                    "execution_authorization",
                    "NONE",
                )
            ).upper()
            == "NONE"
        )

        deployment_detail = (
            f"state {status or 'MISSING'} · "
            f"credentials stored {deployment_state.get('credentials_stored_by_app',False)}"
        )

    identity_ok = True
    identity_detail = "no published/feed/deployment version to compare"

    versions = []

    for item, key in [
        (
            feed_state,
            "target_version",
        ),
        (
            publisher_state,
            "target_version",
        ),
        (
            deployment_state,
            "target_version",
        ),
    ]:
        value = _text(
            item.get(
                key
            )
            if item
            else ""
        )

        if value:
            versions.append(
                value
            )

    if versions:
        identity_ok = (
            len(
                set(
                    versions
                )
            )
            == 1
        )

        identity_detail = (
            "versions "
            + ",".join(
                versions
            )
        )

    no_auto_ok, no_auto_detail = (
        _no_auto_authorization_contract(
            ctx
        )
    )

    checks = [
        _audit_row(
            "Updater2 Audit Trusted Feed State Integrity",
            feed_ok,
            feed_detail,
            "Trusted Feed state/status/hash/no-auto-apply 기록 확인",
        ),
        _audit_row(
            "Updater2 Audit Publisher Provenance / Immutable SHA",
            publisher_ok,
            publisher_detail,
            "Publisher state/package SHA/remote-upload boundary 확인",
        ),
        _audit_row(
            "Updater2 Audit Deployment / Credential Boundary",
            deployment_ok,
            deployment_detail,
            "Deployment state 및 credential non-storage 확인",
        ),
        _audit_row(
            "Updater2 Audit Version / Lineage Consistency",
            identity_ok,
            identity_detail,
            "Feed/Publisher/Deployment target version lineage 확인",
        ),
        _audit_row(
            "Updater2 Audit No-Auto-Approval / No-Auto-Apply Authorization",
            no_auto_ok,
            no_auto_detail,
            "auto approval/apply 금지 및 Execution Authorization NONE 확인",
        ),
    ]

    technical_fail = sum(
        1
        for row in checks
        if row[
            "status"
        ]
        == "FAIL"
    )

    feed_status = _text(
        feed.get(
            "status"
        )
    ).upper()

    publisher_status_value = _text(
        publisher.get(
            "status"
        )
    ).upper()

    deployment_status_value = _text(
        deployment.get(
            "status"
        )
    ).upper()

    operating_status = (
        "PASS"
        if (
            feed_status
            == "ENABLED"
            and publisher_status_value
            == "READY"
            and deployment_status_value
            == "CONNECTED"
        )
        else "REVIEW"
    )

    checks.append(
        {
            "layer":
                "OPERATING",
            "check":
                "Updater2 Audit Operating Stage",
            "status":
                operating_status,
            "detail": (
                f"feed {feed_status or 'MISSING'} · "
                f"publisher {publisher_status_value or 'MISSING'} · "
                f"deployment {deployment_status_value or 'MISSING'}"
            ),
            "action": (
                ""
                if operating_status
                == "PASS"
                else (
                    "외부 Trusted Feed/Publisher/Deployment 연결은 운영 설정 단계로 분리합니다."
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail
            == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row[
                    "layer"
                ]
                == "TECHNICAL"
                and row[
                    "status"
                ]
                == "PASS"
            )
        ),
        "technical_fail":
            technical_fail,
        "operating_status":
            operating_status,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                    UPDATER2_AUDIT_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check":
            check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail":
            detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v154_release_readiness(
    *,
    v153_release_status: str,
    v153_baseline_provenance: dict | None,
    integration_consistency: str,
    csv_fail_count: int,
    updater2_release_gate: str,
    updater2_audit_gate: str,
    work_ready_release_gate: str,
    updater2_operating_status: str,
    audit_operating_status: str,
    work_ready_operating_status: str,
    execution_authorization: str,
) -> dict:
    provenance = (
        v153_baseline_provenance
        or {}
    )

    checks = [
        _candidate_row(
            "v1.53 Immutable Release Baseline Provenance",
            bool(
                provenance.get(
                    "verified"
                )
            ),
            (
                f"{_text(provenance.get('status')) or 'MISSING'} · "
                f"source {_text(provenance.get('source')) or 'NONE'} · "
                f"dynamic-v1.53 {_text(v153_release_status).upper() or 'MISSING'}"
            ),
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Updater2 Trusted Release Infrastructure Technical Gate",
            _text(
                updater2_release_gate
            ).upper()
            == "PASS",
            _text(
                updater2_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Updater2 Trusted Release Infrastructure Audit Gate",
            _text(
                updater2_audit_gate
            ).upper()
            == "PASS",
            _text(
                updater2_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Software Update Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ]
        != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            updater2_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "UPDATER2_INFRASTRUCTURE_REVIEW"
        )

    if _text(
        work_ready_operating_status
    ).upper() != "PASS":
        operating_reviews.append(
            "WORK_READY_RELEASE_MANAGER_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count":
            len(
                blockers
            ),
        "blockers":
            blockers,
        "operating_review_count":
            len(
                operating_reviews
            ),
        "operating_reviews":
            operating_reviews,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                    V154_CANDIDATE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v154_integration_crosscheck(
    *,
    integration_consistency: str,
    updater2_release_gate: str,
    updater2_audit_gate: str,
    work_ready_release_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Updater2 Technical Gate",
            _text(
                updater2_release_gate
            ).upper()
            == "PASS",
            _text(
                updater2_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Updater2 Audit Gate",
            _text(
                updater2_audit_gate
            ).upper()
            == "PASS",
            _text(
                updater2_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ]
        != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                    V154_CANDIDATE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }


def build_v154_data_crosscheck(
    *,
    csv_fail_count: int,
    updater2_release_gate: str,
    updater2_audit_gate: str,
    work_ready_release_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Updater2 Technical Gate",
            _text(
                updater2_release_gate
            ).upper()
            == "PASS",
            _text(
                updater2_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Updater2 Audit Gate",
            _text(
                updater2_audit_gate
            ).upper()
            == "PASS",
            _text(
                updater2_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row[
            "check"
        ]
        for row in checks
        if row[
            "status"
        ]
        != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count":
            len(
                blockers
            ),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                    V154_CANDIDATE_CHECK_COLS,
            ),
        "execution_authorization":
            "NONE",
    }
