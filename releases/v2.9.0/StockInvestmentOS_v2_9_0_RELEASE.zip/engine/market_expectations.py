from __future__ import annotations

import math
import json
from typing import Callable, Any

import pandas as pd


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if not math.isfinite(out):
        return None
    return out


def dcf_per_share(
    fcf0: float,
    growth: float,
    required_return: float,
    terminal_growth: float,
    years: int = 5,
) -> float | None:
    """
    Constant-growth per-share DCF.

    FCF0 is a normalized FCF/share at t=0.
    The model is intentionally simple and transparent for reverse-DCF work.
    """
    f0 = _num(fcf0)
    g = _num(growth)
    r = _num(required_return)
    tg = _num(terminal_growth)

    if (
        f0 is None
        or g is None
        or r is None
        or tg is None
        or years < 1
        or f0 <= 0
        or g <= -1.0
        or r <= tg
        or r <= -1.0
    ):
        return None

    pv = 0.0
    fcf = f0
    for year in range(1, int(years) + 1):
        fcf *= 1.0 + g
        pv += fcf / ((1.0 + r) ** year)

    terminal_value = fcf * (1.0 + tg) / (r - tg)
    pv += terminal_value / ((1.0 + r) ** int(years))
    return pv


def _bisect_monotonic(
    fn: Callable[[float], float | None],
    target: float,
    low: float,
    high: float,
    *,
    increasing: bool,
    max_iter: int = 140,
    tol: float = 1e-9,
) -> dict:
    target = float(target)
    flo = fn(low)
    fhi = fn(high)

    if flo is None or fhi is None:
        return {"value": None, "status": "INVALID_RANGE"}

    low_gap = flo - target
    high_gap = fhi - target

    if increasing:
        if low_gap > 0:
            return {"value": None, "status": "BELOW_RANGE"}
        if high_gap < 0:
            return {"value": None, "status": "ABOVE_RANGE"}
    else:
        if low_gap < 0:
            return {"value": None, "status": "BELOW_RANGE"}
        if high_gap > 0:
            return {"value": None, "status": "ABOVE_RANGE"}

    lo, hi = float(low), float(high)
    for _ in range(max_iter):
        mid = (lo + hi) / 2.0
        fmid = fn(mid)
        if fmid is None:
            return {"value": None, "status": "INVALID_MODEL"}
        gap = fmid - target

        if abs(gap) <= tol * max(1.0, abs(target)):
            return {"value": mid, "status": "SOLVED"}

        if increasing:
            if gap < 0:
                lo = mid
            else:
                hi = mid
        else:
            if gap > 0:
                lo = mid
            else:
                hi = mid

    return {"value": (lo + hi) / 2.0, "status": "SOLVED"}


def solve_implied_growth(
    price: float,
    fcf0: float,
    required_return: float,
    terminal_growth: float,
    years: int = 5,
    low: float = -0.90,
    high: float = 2.00,
) -> dict:
    p = _num(price)
    if p is None or p <= 0:
        return {"value": None, "status": "INVALID_PRICE"}

    return _bisect_monotonic(
        lambda g: dcf_per_share(
            fcf0,
            g,
            required_return,
            terminal_growth,
            years,
        ),
        p,
        low,
        high,
        increasing=True,
    )


def required_fcf_per_share(
    price: float,
    growth: float,
    required_return: float,
    terminal_growth: float,
    years: int = 5,
) -> dict:
    p = _num(price)
    if p is None or p <= 0:
        return {"value": None, "status": "INVALID_PRICE"}

    unit_value = dcf_per_share(
        1.0,
        growth,
        required_return,
        terminal_growth,
        years,
    )
    if unit_value is None or unit_value <= 0:
        return {"value": None, "status": "INVALID_MODEL"}

    return {"value": p / unit_value, "status": "SOLVED"}


def solve_implied_fcf_margin(
    price: float,
    normalized_revenue_per_share: float,
    revenue_growth: float,
    required_return: float,
    terminal_growth: float,
    years: int = 5,
) -> dict:
    revenue_ps = _num(normalized_revenue_per_share)
    if revenue_ps is None or revenue_ps <= 0:
        return {"value": None, "status": "REVENUE_PER_SHARE_REQUIRED"}

    required = required_fcf_per_share(
        price,
        revenue_growth,
        required_return,
        terminal_growth,
        years,
    )
    if required["value"] is None:
        return {"value": None, "status": required["status"]}

    return {
        "value": required["value"] / revenue_ps,
        "required_fcf_per_share": required["value"],
        "status": "SOLVED",
    }


def solve_implied_required_return(
    price: float,
    fcf0: float,
    growth: float,
    terminal_growth: float,
    years: int = 5,
    high: float = 1.00,
) -> dict:
    p = _num(price)
    tg = _num(terminal_growth)
    if p is None or p <= 0 or tg is None:
        return {"value": None, "status": "INVALID_INPUT"}

    low = max(tg + 0.0005, 0.0005)
    if low >= high:
        return {"value": None, "status": "INVALID_RANGE"}

    return _bisect_monotonic(
        lambda r: dcf_per_share(
            fcf0,
            growth,
            r,
            terminal_growth,
            years,
        ),
        p,
        low,
        high,
        increasing=False,
    )


def solve_implied_terminal_growth(
    price: float,
    fcf0: float,
    growth: float,
    required_return: float,
    years: int = 5,
    low: float = -0.20,
) -> dict:
    p = _num(price)
    r = _num(required_return)
    if p is None or p <= 0 or r is None:
        return {"value": None, "status": "INVALID_INPUT"}

    high = r - 0.0005
    if low >= high:
        return {"value": None, "status": "INVALID_RANGE"}

    return _bisect_monotonic(
        lambda tg: dcf_per_share(
            fcf0,
            growth,
            required_return,
            tg,
            years,
        ),
        p,
        low,
        high,
        increasing=True,
    )


def capital_intensity_translation(
    implied_growth: float | None,
    normalized_roic: float | None,
) -> dict:
    """
    Translate a growth expectation into a reinvestment requirement using
    g ~= ROIC x Reinvestment Rate.

    This is a consistency translation, not a DCF output or investment verdict.
    """
    g = _num(implied_growth)
    roic = _num(normalized_roic)

    if g is None:
        return {"value": None, "status": "IMPLIED_GROWTH_REQUIRED"}
    if roic is None or roic <= 0:
        return {"value": None, "status": "NORMALIZED_ROIC_REQUIRED"}

    return {
        "value": g / roic,
        "status": "SOLVED",
    }


def scenario_values(
    fcf0: float,
    scenario_table: pd.DataFrame,
    price: float,
    years: int = 5,
) -> tuple[pd.DataFrame, dict]:
    if scenario_table is None or scenario_table.empty:
        return pd.DataFrame(), {
            "probability_sum": 0.0,
            "probability_weighted_value": None,
            "probability_weighted_upside": None,
            "status": "EMPTY",
        }

    rows = []
    probability_sum = 0.0
    weighted_value = 0.0
    valid = True

    for _, row in scenario_table.iterrows():
        name = str(row.get("Scenario", "") or "").strip()
        growth = _num(row.get("FCF CAGR"))
        wacc = _num(row.get("WACC"))
        tg = _num(row.get("Terminal Growth"))
        probability = _num(row.get("Probability"))

        value = None
        status = "INVALID"
        if (
            growth is not None
            and wacc is not None
            and tg is not None
            and probability is not None
            and probability >= 0
            and wacc > tg
        ):
            value = dcf_per_share(
                fcf0,
                growth,
                wacc,
                tg,
                years,
            )
            status = "OK" if value is not None else "INVALID_MODEL"

        if probability is None or probability < 0:
            valid = False
            probability = 0.0

        probability_sum += probability
        if value is None:
            valid = False
        else:
            weighted_value += probability * value

        rows.append(
            {
                "Scenario": name,
                "FCF CAGR": growth,
                "WACC": wacc,
                "Terminal Growth": tg,
                "Probability": probability,
                "Value": value,
                "Upside": (
                    value / float(price) - 1.0
                    if value is not None and price and float(price) > 0
                    else None
                ),
                "Status": status,
            }
        )

    prob_ok = abs(probability_sum - 1.0) <= 1e-6
    status = "PASS" if valid and prob_ok else "REVIEW"

    return pd.DataFrame(rows), {
        "probability_sum": probability_sum,
        "probability_weighted_value": weighted_value if status == "PASS" else None,
        "probability_weighted_upside": (
            weighted_value / float(price) - 1.0
            if status == "PASS" and price and float(price) > 0
            else None
        ),
        "status": status,
    }


def sensitivity_matrix(
    fcf0: float,
    growth_values: list[float],
    required_return_values: list[float],
    terminal_growth: float,
    years: int = 5,
) -> pd.DataFrame:
    rows = []
    for growth in growth_values:
        row = {"FCF CAGR": growth}
        for required_return in required_return_values:
            label = f"WACC {required_return*100:.1f}%"
            row[label] = dcf_per_share(
                fcf0,
                growth,
                required_return,
                terminal_growth,
                years,
            )
        rows.append(row)
    return pd.DataFrame(rows)


def anchor_integrity_status(
    anchor_source: str,
    fcf_per_share: float | None,
    *,
    manual_confirmed: bool = False,
    fundamental_hash_status: str = "",
    fundamental_period: str = "",
    source_integrity_status: str = "",
    share_status: str = "",
) -> dict:
    """
    Classify whether the normalized FCF/share anchor is independent enough
    for reverse-DCF decision work.

    PASS:
      - manually supplied and explicitly source-confirmed
      - reviewed/hash-OK full-year Fundamental Snapshot

    DIAGNOSTIC_ONLY:
      - price-linked legacy Watchlist proxy
    """
    source = str(anchor_source or "").strip().upper()
    fcf = _num(fcf_per_share)
    period = str(fundamental_period or "").strip().upper()
    hash_status = str(fundamental_hash_status or "").strip().upper()

    if fcf is None or fcf <= 0:
        return {
            "status": "REVIEW",
            "reason": "NORMALIZED_FCF_PER_SHARE_REQUIRED",
            "decision_ready": False,
        }

    if source == "MANUAL_INDEPENDENT":
        if manual_confirmed:
            return {
                "status": "PASS",
                "reason": "MANUAL_SOURCE_CONFIRMED",
                "decision_ready": True,
            }
        return {
            "status": "REVIEW",
            "reason": "MANUAL_SOURCE_CONFIRMATION_REQUIRED",
            "decision_ready": False,
        }

    if source == "DART_FY_SOURCE":
        if period not in {"FY", "ANNUAL", "FULL_YEAR", "YEAR"}:
            return {
                "status": "REVIEW",
                "reason": "FULL_YEAR_SOURCE_REQUIRED",
                "decision_ready": False,
            }
        if str(source_integrity_status or "").strip().upper() != "PASS":
            return {
                "status": "REVIEW",
                "reason": "DART_EXTRACTION_PASS_REQUIRED",
                "decision_ready": False,
            }
        if str(share_status or "").strip().upper() != "PASS_PROXY":
            return {
                "status": "REVIEW",
                "reason": "DART_SHARE_SOURCE_PASS_REQUIRED",
                "decision_ready": False,
            }
        if not manual_confirmed:
            return {
                "status": "REVIEW",
                "reason": "FY_SOURCE_HUMAN_CONFIRMATION_REQUIRED",
                "decision_ready": False,
            }
        return {
            "status": "PASS",
            "reason": "REVIEWED_OPENDART_FULL_YEAR_SOURCE",
            "decision_ready": True,
        }

    if source == "FUNDAMENTAL_FY":
        if period not in {"FY", "ANNUAL", "FULL_YEAR", "YEAR"}:
            return {
                "status": "REVIEW",
                "reason": "FULL_YEAR_FUNDAMENTAL_REQUIRED",
                "decision_ready": False,
            }
        if hash_status != "OK":
            return {
                "status": "REVIEW",
                "reason": "FUNDAMENTAL_HASH_OK_REQUIRED",
                "decision_ready": False,
            }
        return {
            "status": "PASS",
            "reason": "REVIEWED_FULL_YEAR_FUNDAMENTAL",
            "decision_ready": True,
        }

    if source == "WATCHLIST_PRICE_LINKED":
        return {
            "status": "DIAGNOSTIC_ONLY",
            "reason": "PRICE_LINKED_ANCHOR_NOT_INDEPENDENTLY_PROVENANCED",
            "decision_ready": False,
        }

    return {
        "status": "REVIEW",
        "reason": "UNKNOWN_ANCHOR_SOURCE",
        "decision_ready": False,
    }


def break_even_fcf_table(
    price: float,
    growth_values: list[float],
    required_return: float,
    terminal_growth: float,
    years: int = 5,
    normalized_revenue_per_share: float | None = None,
) -> pd.DataFrame:
    rows = []
    revenue_ps = _num(normalized_revenue_per_share)

    for growth in growth_values:
        required = required_fcf_per_share(
            price,
            growth,
            required_return,
            terminal_growth,
            years,
        )
        required_fcf = required.get("value")
        required_margin = None
        if (
            required_fcf is not None
            and revenue_ps is not None
            and revenue_ps > 0
        ):
            required_margin = required_fcf / revenue_ps

        rows.append(
            {
                "FCF CAGR": float(growth),
                "Required FCF/share": required_fcf,
                "Required FCF Margin": required_margin,
                "Status": required.get("status"),
            }
        )
    return pd.DataFrame(rows)


def cap_gap(
    implied_growth: float | None,
    normalized_roic: float | None,
    fundamental_reinvestment_rate: float | None,
    *,
    zero_is_intentional: bool = False,
) -> dict:
    """
    Compare Market-implied CAP with a reviewed Fundamental CAP.

    A numeric 0 is commonly the UI default, so it is treated as "not supplied"
    unless the user explicitly confirms that zero is intentional.
    """
    translated = capital_intensity_translation(
        implied_growth,
        normalized_roic,
    )
    market_cap = translated.get("value")
    fundamental_cap = _num(fundamental_reinvestment_rate)

    if market_cap is None:
        return {
            "market_implied_cap": None,
            "fundamental_cap": fundamental_cap,
            "gap": None,
            "status": translated.get("status"),
        }

    if fundamental_cap is None:
        return {
            "market_implied_cap": market_cap,
            "fundamental_cap": None,
            "gap": None,
            "status": "FUNDAMENTAL_CAP_REQUIRED",
        }

    if fundamental_cap == 0 and not zero_is_intentional:
        return {
            "market_implied_cap": market_cap,
            "fundamental_cap": None,
            "gap": None,
            "status": "FUNDAMENTAL_CAP_ZERO_UNCONFIRMED",
        }

    if fundamental_cap < 0:
        return {
            "market_implied_cap": market_cap,
            "fundamental_cap": fundamental_cap,
            "gap": None,
            "status": "FUNDAMENTAL_CAP_INVALID",
        }

    return {
        "market_implied_cap": market_cap,
        "fundamental_cap": fundamental_cap,
        "gap": fundamental_cap - market_cap,
        "status": "SOLVED",
    }


def build_annual_source_anchor(
    financial_summary: dict,
    share_summary: dict,
    *,
    business_year: int | str,
    period: str = "FY",
) -> dict:
    """
    Build a full-year source-backed reverse-DCF reference from structured
    OpenDART extracts. No current market price is used.

    FCF/share uses the existing FCF proxy divided by distributed-share proxy.
    ROIC remains a proxy using the source-backed tax / invested-capital proxies.
    """
    summary = financial_summary or {}
    shares = share_summary or {}

    fcf = _num(summary.get("fcf_proxy"))
    revenue = _num(summary.get("revenue"))
    operating_profit = _num(summary.get("operating_profit"))
    tax_rate = _num(summary.get("effective_tax_rate_proxy"))
    invested_capital = _num(summary.get("invested_capital_proxy"))
    share_count = _num(shares.get("distributed_shares_proxy"))

    fcf_per_share = (
        fcf / share_count
        if fcf is not None and share_count is not None and share_count > 0
        else None
    )
    revenue_per_share = (
        revenue / share_count
        if revenue is not None and share_count is not None and share_count > 0
        else None
    )

    nopat = None
    roic = None
    if (
        operating_profit is not None
        and tax_rate is not None
        and 0 <= tax_rate <= 1
    ):
        nopat = operating_profit * (1.0 - tax_rate)

    if nopat is not None and invested_capital is not None and invested_capital > 0:
        roic = nopat / invested_capital

    extraction_status = str(
        summary.get("extraction_integrity_status", "") or ""
    ).strip().upper()
    share_status = str(
        shares.get("share_count_status", "") or ""
    ).strip().upper()

    ready = bool(
        str(period or "").strip().upper()
        in {"FY", "ANNUAL", "FULL_YEAR", "YEAR"}
        and extraction_status == "PASS"
        and share_status == "PASS_PROXY"
        and fcf_per_share is not None
        and fcf_per_share > 0
    )

    return {
        "business_year": str(business_year),
        "period": str(period or "").strip().upper(),
        "revenue": revenue,
        "operating_profit": operating_profit,
        "fcf_proxy": fcf,
        "share_count_proxy": share_count,
        "fcf_per_share": fcf_per_share,
        "revenue_per_share": revenue_per_share,
        "effective_tax_rate_proxy": tax_rate,
        "invested_capital_proxy": invested_capital,
        "roic_proxy": roic,
        "extraction_integrity_status": extraction_status,
        "share_status": share_status,
        "share_count_basis": str(
            shares.get("share_count_basis", "") or ""
        ),
        "ready": ready,
        "warning": (
            "FY FCF/share is an OpenDART FCF proxy / distributed-share proxy. "
            "It is independent of current price, but it is not automatically a "
            "cycle-normalized or owner-earnings measure."
        ),
    }


def expectation_pressure_summary(
    *,
    current_fcf_per_share: float | None,
    required_fcf_per_share: float | None,
    current_fcf_margin: float | None,
    required_fcf_margin: float | None,
    implied_growth: float | None,
    normalized_roic: float | None,
) -> dict:
    """
    Descriptive expectation-pressure diagnostics.

    No buy/sell verdict is produced.
    """
    current_fcf = _num(current_fcf_per_share)
    required_fcf = _num(required_fcf_per_share)
    current_margin = _num(current_fcf_margin)
    required_margin = _num(required_fcf_margin)
    growth = _num(implied_growth)
    roic = _num(normalized_roic)

    fcf_multiple = None
    if current_fcf is not None and current_fcf > 0 and required_fcf is not None:
        fcf_multiple = required_fcf / current_fcf

    margin_gap = None
    if current_margin is not None and required_margin is not None:
        margin_gap = required_margin - current_margin

    cap_translation = capital_intensity_translation(growth, roic)
    implied_cap = cap_translation.get("value")

    flags = []
    if fcf_multiple is not None and fcf_multiple > 1.0:
        flags.append("REQUIRED_FCF_ABOVE_ANCHOR")
    if margin_gap is not None and margin_gap > 0:
        flags.append("REQUIRED_MARGIN_ABOVE_ANCHOR")
    if implied_cap is not None and implied_cap > 1.0:
        flags.append("IMPLIED_CAP_ABOVE_100PCT")

    return {
        "required_fcf_multiple": fcf_multiple,
        "required_margin_gap": margin_gap,
        "implied_cap": implied_cap,
        "flags": flags,
        "status": "REVIEW" if flags else "PASS",
    }


def assumption_readiness(
    *,
    anchor_ready: bool,
    base_growth_confirmed: bool,
    revenue_confirmed: bool,
    roic_confirmed: bool,
    cap_confirmed: bool,
    cap_value: float | None,
    cap_zero_intentional: bool = False,
) -> pd.DataFrame:
    cap = _num(cap_value)
    cap_ready = bool(
        cap_confirmed
        and cap is not None
        and (
            cap > 0
            or (cap == 0 and cap_zero_intentional)
        )
    )

    return pd.DataFrame(
        [
            {
                "Assumption":"Independent FCF Anchor",
                "Ready":bool(anchor_ready),
            },
            {
                "Assumption":"Fundamental Base FCF CAGR",
                "Ready":bool(base_growth_confirmed),
            },
            {
                "Assumption":"Normalized Revenue/share",
                "Ready":bool(revenue_confirmed),
            },
            {
                "Assumption":"Long-run Normalized ROIC",
                "Ready":bool(roic_confirmed),
            },
            {
                "Assumption":"Fundamental CAP / Reinvestment",
                "Ready":cap_ready,
            },
        ]
    )


def scenario_driver_diagnostics(
    scenario_table: pd.DataFrame,
) -> tuple[pd.DataFrame, dict]:
    """
    Descriptive Growth-ROIC-CAP consistency diagnostics.

    Positive/zero growth:
      uses ROIC × CAP as a long-run consistency translation.

    Negative growth:
      does NOT infer a negative CAP. The scenario must instead state a
      human-reviewed Contraction Driver (e.g., volume/margin decline,
      asset rationalization, capital release, structural demand loss).

    No scenario ranking or winner is produced.
    """
    if scenario_table is None or scenario_table.empty:
        return pd.DataFrame(), {
            "complete": 0,
            "incomplete": 0,
            "growth_complete": 0,
            "contraction_complete": 0,
            "cap_above_100pct": 0,
            "wacc_tg_issues": 0,
        }

    rows = []
    complete = 0
    incomplete = 0
    growth_complete = 0
    contraction_complete = 0
    cap_above = 0
    wacc_tg_issues = 0

    for _, row in scenario_table.iterrows():
        name = str(row.get("Scenario", "") or "").strip()
        growth = _num(row.get("FCF CAGR"))
        roic = _num(row.get("Normalized ROIC"))
        cap = _num(row.get("Reinvestment Rate"))
        wacc = _num(row.get("WACC"))
        tg = _num(row.get("Terminal Growth"))
        contraction_driver = str(
            row.get("Contraction Driver", "") or ""
        ).strip()

        sustainable_growth = None
        growth_gap = None
        flags = []
        mode = "UNKNOWN"
        status = "INCOMPLETE"

        if growth is not None and growth < 0:
            mode = "CONTRACTION"
            flags.append("NEGATIVE_GROWTH_ROIC_CAP_NOT_USED")
            if contraction_driver:
                status = "COMPLETE_CONTRACTION"
                complete += 1
                contraction_complete += 1
            else:
                flags.append("CONTRACTION_DRIVER_REQUIRED")
                incomplete += 1
        else:
            mode = "GROWTH"
            if roic is not None and roic > 0 and cap is not None and cap >= 0:
                sustainable_growth = roic * cap
                if growth is not None:
                    growth_gap = growth - sustainable_growth
                status = "COMPLETE"
                complete += 1
                growth_complete += 1
            else:
                incomplete += 1
                flags.append("ROIC_CAP_INCOMPLETE")

            if cap is not None and cap > 1.0:
                flags.append("CAP_ABOVE_100PCT")
                cap_above += 1

            if roic is not None and roic <= 0:
                flags.append("ROIC_NONPOSITIVE")

        if wacc is not None and tg is not None and wacc <= tg:
            flags.append("WACC_LE_TERMINAL_GROWTH")
            wacc_tg_issues += 1

        rows.append(
            {
                "Scenario": name,
                "Mode": mode,
                "FCF CAGR": growth,
                "Normalized ROIC": roic,
                "Reinvestment Rate": cap,
                "Contraction Driver": contraction_driver,
                "ROIC × CAP": sustainable_growth,
                "Growth - ROIC×CAP": growth_gap,
                "WACC": wacc,
                "Terminal Growth": tg,
                "Flags": " | ".join(flags),
                "Status": status,
            }
        )

    return pd.DataFrame(rows), {
        "complete": complete,
        "incomplete": incomplete,
        "growth_complete": growth_complete,
        "contraction_complete": contraction_complete,
        "cap_above_100pct": cap_above,
        "wacc_tg_issues": wacc_tg_issues,
    }



def scenario_driver_seed(
    *,
    base_roic: float | None = None,
    base_cap: float | None = None,
    base_ready: bool = False,
) -> dict:
    """
    Provide only reviewed Base references. Bear/Bull/Tail are intentionally left
    blank so the user must state their own scenario-specific driver assumptions.
    """
    roic = _num(base_roic) if base_ready else None
    cap = _num(base_cap) if base_ready else None
    return {
        "base_roic": roic,
        "base_cap": cap,
    }


def scenario_governance_gate(
    scenario_input: pd.DataFrame,
    scenario_summary: dict,
    driver_table: pd.DataFrame,
) -> dict:
    """
    Human-review governance for Bull/Base/Bear/Tail.

    PASS requires:
    - valuation math/probability gate PASS
    - all four scenarios have ROIC/CAP driver inputs
    - each scenario has Trigger + Action Rule text
    - each scenario is explicitly Reviewed

    The gate controls decision-readiness only. It does not rank scenarios.
    """
    if scenario_input is None or scenario_input.empty:
        return {
            "status": "REVIEW",
            "valuation_math_ready": False,
            "driver_complete": 0,
            "driver_required": 0,
            "trigger_complete": 0,
            "action_complete": 0,
            "reviewed_complete": 0,
            "required_rows": 0,
            "issues": ["SCENARIO_TABLE_EMPTY"],
        }

    required_rows = int(len(scenario_input))
    issues = []

    valuation_math_ready = (
        str((scenario_summary or {}).get("status", "")).upper() == "PASS"
    )
    if not valuation_math_ready:
        issues.append("VALUATION_MATH_REVIEW")

    driver_complete = 0
    if driver_table is not None and not driver_table.empty:
        driver_complete = int(
            driver_table["Status"]
            .fillna("")
            .astype(str)
            .str.upper()
            .isin(["COMPLETE", "COMPLETE_CONTRACTION"])
            .sum()
        )
    if driver_complete < required_rows:
        issues.append("SCENARIO_DRIVER_INCOMPLETE")

    trigger_series = (
        scenario_input.get(
            "Trigger",
            pd.Series("", index=scenario_input.index, dtype=object),
        )
        .fillna("")
        .astype(str)
        .str.strip()
    )
    trigger_complete = int(trigger_series.ne("").sum())
    if trigger_complete < required_rows:
        issues.append("SCENARIO_TRIGGER_INCOMPLETE")

    action_series = (
        scenario_input.get(
            "Action Rule",
            pd.Series("", index=scenario_input.index, dtype=object),
        )
        .fillna("")
        .astype(str)
        .str.strip()
    )
    action_complete = int(action_series.ne("").sum())
    if action_complete < required_rows:
        issues.append("SCENARIO_ACTION_INCOMPLETE")

    reviewed_series = scenario_input.get(
        "Reviewed",
        pd.Series(False, index=scenario_input.index, dtype=bool),
    )
    reviewed_complete = int(
        reviewed_series.fillna(False).astype(bool).sum()
    )
    if reviewed_complete < required_rows:
        issues.append("SCENARIO_REVIEW_INCOMPLETE")

    status = "PASS" if not issues else "REVIEW"

    return {
        "status": status,
        "valuation_math_ready": valuation_math_ready,
        "driver_complete": driver_complete,
        "driver_required": required_rows,
        "trigger_complete": trigger_complete,
        "action_complete": action_complete,
        "reviewed_complete": reviewed_complete,
        "required_rows": required_rows,
        "issues": issues,
    }


def scenario_driver_requirements(
    scenario_table: pd.DataFrame,
) -> pd.DataFrame:
    """
    Input helper for scenario drivers.

    Positive/zero growth:
      - If ROIC is entered, required CAP = Growth / ROIC.
      - If CAP is entered, required ROIC = Growth / CAP.

    Negative growth:
      - Required CAP/ROIC is intentionally suppressed.
      - A Contraction Driver must be described instead.

    Nothing is auto-written back to the Scenario editor.
    """
    if scenario_table is None or scenario_table.empty:
        return pd.DataFrame()

    rows = []
    for _, row in scenario_table.iterrows():
        scenario = str(row.get("Scenario", "") or "").strip()
        growth = _num(row.get("FCF CAGR"))
        roic = _num(row.get("Normalized ROIC"))
        cap = _num(row.get("Reinvestment Rate"))
        contraction_driver = str(
            row.get("Contraction Driver", "") or ""
        ).strip()

        required_cap = None
        required_roic = None
        mode = "UNKNOWN"
        note = ""

        if growth is not None and growth < 0:
            mode = "CONTRACTION"
            note = (
                "Negative growth: ROIC×CAP 역산 미사용. "
                "Volume/Margin/Asset/Capital-release 등 Contraction Driver를 직접 기술."
            )
        else:
            mode = "GROWTH"
            if growth is not None and roic is not None and roic != 0:
                required_cap = growth / roic
            if growth is not None and cap is not None and cap != 0:
                required_roic = growth / cap

        rows.append(
            {
                "Scenario": scenario,
                "Mode": mode,
                "FCF CAGR": growth,
                "Entered ROIC": roic,
                "CAP required @ entered ROIC": required_cap,
                "Entered CAP": cap,
                "ROIC required @ entered CAP": required_roic,
                "Contraction Driver": contraction_driver,
                "Note": note,
            }
        )

    return pd.DataFrame(rows)



def scenario_template_text() -> pd.DataFrame:
    """
    Human-review writing templates only. No thresholds or investment decisions
    are filled automatically.
    """
    return pd.DataFrame(
        [
            {
                "Scenario":"Bear",
                "Contraction Driver Template":"예: Volume 감소 / Margin 압박 / 재고조정 / 고객수요 둔화 중 실제 근거가 있는 것",
                "Trigger Template":"핵심 KPI가 [하단 기준]을 [기간/횟수] 이탈 + 반대 Evidence 강화",
                "Action Template":"Add Freeze → Thesis/Valuation/Risk 재검토 → 다음 행동은 Human Review",
            },
            {
                "Scenario":"Base",
                "Contraction Driver Template":"",
                "Trigger Template":"핵심 KPI가 Base 범위 유지 + 예정된 Proof가 [기한] 내 확인",
                "Action Template":"Hold / Next Proof 대기 → 신규 Evidence 반영 후 재평가",
            },
            {
                "Scenario":"Bull",
                "Contraction Driver Template":"",
                "Trigger Template":"FCF/ROIC/Runway가 [상단 기준]을 [기간] 지속 + Evidence 강화",
                "Action Template":"Reverse DCF 재산정 → Risk Budget/Position Cap 안에서 Human Review",
            },
            {
                "Scenario":"Tail",
                "Contraction Driver Template":"예: 구조적 수요훼손 / 대규모 Margin 붕괴 / 자본회수·사업축소 / Liquidity stress 중 실제 근거",
                "Trigger Template":"Liquidity/Refinancing/Thesis 핵심 무효화 조건 발생",
                "Action Template":"Add Freeze → Survival/Liquidity 우선 → Risk reduction 여부 Human Review",
            },
        ]
    )


REVERSE_SCENARIO_DRAFT_COLS = [
    "company",
    "scenario",
    "fcf_cagr",
    "normalized_roic",
    "reinvestment_rate",
    "contraction_driver",
    "wacc",
    "terminal_growth",
    "probability",
    "trigger",
    "action_rule",
    "reviewed",
    "updated_at",
]

_SCENARIO_EDITOR_COLS = [
    "Scenario",
    "FCF CAGR",
    "Normalized ROIC",
    "Reinvestment Rate",
    "Contraction Driver",
    "WACC",
    "Terminal Growth",
    "Probability",
    "Trigger",
    "Action Rule",
    "Reviewed",
]


def _draft_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def normalize_reverse_scenario_drafts(
    df: pd.DataFrame | None,
) -> pd.DataFrame:
    if df is None:
        df = pd.DataFrame()
    out = df.copy()
    for col in REVERSE_SCENARIO_DRAFT_COLS:
        if col not in out.columns:
            out[col] = ""
    return out[REVERSE_SCENARIO_DRAFT_COLS].copy()


def scenario_editor_from_saved_draft(
    df: pd.DataFrame | None,
    company: str,
) -> tuple[pd.DataFrame, str]:
    drafts = normalize_reverse_scenario_drafts(df)
    if drafts.empty:
        return pd.DataFrame(columns=_SCENARIO_EDITOR_COLS), ""

    company_key = _draft_text(company)
    hit = drafts.loc[
        drafts["company"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(company_key)
    ].copy()
    if hit.empty:
        return pd.DataFrame(columns=_SCENARIO_EDITOR_COLS), ""

    hit["_updated_sort"] = pd.to_datetime(
        hit["updated_at"],
        errors="coerce",
        utc=True,
    )
    latest_time = hit["_updated_sort"].max()
    if pd.notna(latest_time):
        latest = hit.loc[
            hit["_updated_sort"].eq(latest_time)
        ].copy()
    else:
        latest = hit.copy()

    scenario_order = {
        "Bear": 0,
        "Base": 1,
        "Bull": 2,
        "Tail": 3,
    }
    latest["_scenario_order"] = (
        latest["scenario"]
        .fillna("")
        .astype(str)
        .map(scenario_order)
        .fillna(99)
    )
    latest = latest.sort_values("_scenario_order")

    rows = []
    for _, row in latest.iterrows():
        rows.append(
            {
                "Scenario": _draft_text(row.get("scenario")),
                "FCF CAGR": _num(row.get("fcf_cagr")),
                "Normalized ROIC": _num(row.get("normalized_roic")),
                "Reinvestment Rate": _num(row.get("reinvestment_rate")),
                "Contraction Driver": _draft_text(
                    row.get("contraction_driver")
                ),
                "WACC": _num(row.get("wacc")),
                "Terminal Growth": _num(row.get("terminal_growth")),
                "Probability": _num(row.get("probability")),
                "Trigger": _draft_text(row.get("trigger")),
                "Action Rule": _draft_text(row.get("action_rule")),
                "Reviewed": _draft_text(
                    row.get("reviewed")
                ).upper() in {
                    "TRUE", "1", "YES", "Y",
                },
            }
        )

    table = pd.DataFrame(rows)
    for col in _SCENARIO_EDITOR_COLS:
        if col not in table.columns:
            table[col] = None
    table = table[_SCENARIO_EDITOR_COLS]

    latest_stamp = (
        _draft_text(latest["updated_at"].iloc[0])
        if not latest.empty
        else ""
    )
    return table, latest_stamp


def upsert_reverse_scenario_draft(
    existing: pd.DataFrame | None,
    company: str,
    scenario_table: pd.DataFrame,
    updated_at: str,
) -> pd.DataFrame:
    drafts = normalize_reverse_scenario_drafts(existing)
    company_key = _draft_text(company)

    keep = drafts.loc[
        ~drafts["company"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(company_key)
    ].copy()

    rows = []
    if scenario_table is not None and not scenario_table.empty:
        for _, row in scenario_table.iterrows():
            rows.append(
                {
                    "company": company_key,
                    "scenario": _draft_text(row.get("Scenario")),
                    "fcf_cagr": _num(row.get("FCF CAGR")),
                    "normalized_roic": _num(row.get("Normalized ROIC")),
                    "reinvestment_rate": _num(row.get("Reinvestment Rate")),
                    "contraction_driver": _draft_text(
                        row.get("Contraction Driver")
                    ),
                    "wacc": _num(row.get("WACC")),
                    "terminal_growth": _num(row.get("Terminal Growth")),
                    "probability": _num(row.get("Probability")),
                    "trigger": _draft_text(row.get("Trigger")),
                    "action_rule": _draft_text(row.get("Action Rule")),
                    "reviewed": bool(row.get("Reviewed", False)),
                    "updated_at": _draft_text(updated_at),
                }
            )

    new_rows = normalize_reverse_scenario_drafts(
        pd.DataFrame(rows)
    )
    if keep.empty:
        return new_rows.reset_index(drop=True)
    if new_rows.empty:
        return keep.reset_index(drop=True)
    return pd.concat(
        [keep, new_rows],
        ignore_index=True,
    )[REVERSE_SCENARIO_DRAFT_COLS]


def delete_reverse_scenario_draft(
    existing: pd.DataFrame | None,
    company: str,
) -> tuple[pd.DataFrame, int]:
    drafts = normalize_reverse_scenario_drafts(existing)
    company_key = _draft_text(company)
    mask = (
        drafts["company"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(company_key)
    )
    removed = int(mask.sum())
    return drafts.loc[~mask].reset_index(drop=True), removed


def scenario_draft_fingerprint(
    scenario_table: pd.DataFrame | None,
) -> str:
    if scenario_table is None or scenario_table.empty:
        return ""

    table = scenario_table.copy()
    for col in _SCENARIO_EDITOR_COLS:
        if col not in table.columns:
            table[col] = None
    table = table[_SCENARIO_EDITOR_COLS]

    order = {"Bear": 0, "Base": 1, "Bull": 2, "Tail": 3}
    table["_order"] = (
        table["Scenario"]
        .fillna("")
        .astype(str)
        .map(order)
        .fillna(99)
    )
    table = table.sort_values("_order").drop(columns="_order")

    payload = []
    for _, row in table.iterrows():
        payload.append(
            {
                "Scenario": _draft_text(row.get("Scenario")),
                "FCF CAGR": _num(row.get("FCF CAGR")),
                "Normalized ROIC": _num(row.get("Normalized ROIC")),
                "Reinvestment Rate": _num(row.get("Reinvestment Rate")),
                "Contraction Driver": _draft_text(
                    row.get("Contraction Driver")
                ),
                "WACC": _num(row.get("WACC")),
                "Terminal Growth": _num(row.get("Terminal Growth")),
                "Probability": _num(row.get("Probability")),
                "Trigger": _draft_text(row.get("Trigger")),
                "Action Rule": _draft_text(row.get("Action Rule")),
                "Reviewed": bool(row.get("Reviewed", False)),
            }
        )

    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    )
    import hashlib
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def apply_scenario_template(
    scenario_table: pd.DataFrame,
    template_table: pd.DataFrame,
    scenario_name: str,
) -> pd.DataFrame:
    """
    Copy the writing template into one scenario row.

    Safety:
    - does NOT change Growth / ROIC / CAP / WACC / TG / Probability
    - does NOT set Reviewed=True
    - template text remains a draft that the user must edit/review
    """
    if scenario_table is None or scenario_table.empty:
        return pd.DataFrame()

    out = scenario_table.copy()
    scenario_key = str(scenario_name or "").strip()

    hit = template_table.loc[
        template_table["Scenario"]
        .fillna("")
        .astype(str)
        .eq(scenario_key)
    ]
    if hit.empty:
        return out

    template = hit.iloc[0].to_dict()
    mask = (
        out["Scenario"]
        .fillna("")
        .astype(str)
        .eq(scenario_key)
    )
    if not mask.any():
        return out

    contraction = str(
        template.get("Contraction Driver Template", "") or ""
    ).strip()
    trigger = str(
        template.get("Trigger Template", "") or ""
    ).strip()
    action = str(
        template.get("Action Template", "") or ""
    ).strip()

    if "Contraction Driver" not in out.columns:
        out["Contraction Driver"] = ""
    if "Trigger" not in out.columns:
        out["Trigger"] = ""
    if "Action Rule" not in out.columns:
        out["Action Rule"] = ""
    if "Reviewed" not in out.columns:
        out["Reviewed"] = False

    if contraction:
        out.loc[mask, "Contraction Driver"] = contraction
    out.loc[mask, "Trigger"] = trigger
    out.loc[mask, "Action Rule"] = action
    out.loc[mask, "Reviewed"] = False
    return out


def scenario_template_status(
    scenario_table: pd.DataFrame,
    template_table: pd.DataFrame,
    scenario_name: str,
) -> str:
    """
    EMPTY / TEMPLATE_APPLIED / USER_EDITED
    """
    if scenario_table is None or scenario_table.empty:
        return "EMPTY"

    scenario_key = str(scenario_name or "").strip()
    row_hit = scenario_table.loc[
        scenario_table["Scenario"]
        .fillna("")
        .astype(str)
        .eq(scenario_key)
    ]
    template_hit = template_table.loc[
        template_table["Scenario"]
        .fillna("")
        .astype(str)
        .eq(scenario_key)
    ]
    if row_hit.empty or template_hit.empty:
        return "EMPTY"

    row = row_hit.iloc[0].to_dict()
    template = template_hit.iloc[0].to_dict()

    contraction_template = str(
        template.get("Contraction Driver Template", "") or ""
    ).strip()
    trigger_template = str(
        template.get("Trigger Template", "") or ""
    ).strip()
    action_template = str(
        template.get("Action Template", "") or ""
    ).strip()

    current_contraction = str(
        row.get("Contraction Driver", "") or ""
    ).strip()
    current_trigger = str(
        row.get("Trigger", "") or ""
    ).strip()
    current_action = str(
        row.get("Action Rule", "") or ""
    ).strip()

    relevant_current = [
        current_trigger,
        current_action,
    ]
    relevant_template = [
        trigger_template,
        action_template,
    ]
    if contraction_template:
        relevant_current.insert(0, current_contraction)
        relevant_template.insert(0, contraction_template)

    if all(not x for x in relevant_current):
        return "EMPTY"

    if relevant_current == relevant_template:
        return "TEMPLATE_APPLIED"

    return "USER_EDITED"


def apply_scenario_text_inputs(
    scenario_table: pd.DataFrame,
    scenario_name: str,
    *,
    contraction_driver: str = "",
    trigger: str = "",
    action_rule: str = "",
) -> pd.DataFrame:
    """
    Apply editable Scenario text inputs to one row.

    Safety:
    - does not change Growth / ROIC / CAP / WACC / TG / Probability
    - does not set Reviewed=True
    """
    if scenario_table is None or scenario_table.empty:
        return pd.DataFrame()

    out = scenario_table.copy()
    scenario_key = str(scenario_name or "").strip()

    mask = (
        out["Scenario"]
        .fillna("")
        .astype(str)
        .eq(scenario_key)
    )
    if not mask.any():
        return out

    for col, value in [
        ("Contraction Driver", contraction_driver),
        ("Trigger", trigger),
        ("Action Rule", action_rule),
    ]:
        if col not in out.columns:
            out[col] = ""
        out.loc[mask, col] = str(value or "").strip()

    if "Reviewed" not in out.columns:
        out["Reviewed"] = False
    # Editing text invalidates prior review until the user reviews again.
    out.loc[mask, "Reviewed"] = False
    return out
