from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.pretrade_fill_lineage import (
    pretrade_fill_lineage_integrity,
    pretrade_posttrade_lineage_integrity,
)


DECISION_LEARNING_LINEAGE_COLS = [
    "learning_lineage_id",
    "created_at",
    "company",
    "packet_id",
    "packet_snapshot_hash",
    "fill_id",
    "fill_lineage_id",
    "fill_lineage_status",
    "fill_lineage_integrity",
    "posttrade_lineage_hash",
    "posttrade_lineage_integrity",
    "post_trade_audit_status",
    "decision_id",
    "decision_hash_snapshot",
    "decision_review_status",
    "decision_hash_status",
    "decision_date",
    "decision_type",
    "decision_action",
    "expected_outcome",
    "proof_date",
    "outcome_review_id",
    "outcome_hash_snapshot",
    "outcome_review_status",
    "outcome_hash_status",
    "outcome_link_status",
    "outcome_classification",
    "forecast_error_class",
    "process_adherence",
    "actual_outcome",
    "new_learning",
    "next_action",
    "learning_status",
    "issues",
    "execution_authorization",
    "human_review_confirmed",
    "note",
    "lineage_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _outcome_review_id(row: dict) -> str:
    for key in [
        "outcome_review_id",
        "review_id",
        "outcome_id",
    ]:
        value = _text(
            row.get(key)
        )
        if value:
            return value
    return ""


def evaluate_decision_learning_lineage(
    posttrade_lineage_row: dict | None,
    fill_lineage_row: dict | None,
    decision_row: dict | None,
    outcome_row: dict | None = None,
) -> dict:
    """
    Reconcile the immutable execution lineage with a Decision Journal 2.0
    decision and, when available, its Outcome Review.

    This is an audit/learning link only.
    It never changes Portfolio, Lifecycle, Add Freeze or execution authority.
    """
    post = posttrade_lineage_row or {}
    fill = fill_lineage_row or {}
    decision = decision_row or {}
    outcome = outcome_row or {}

    invalidation_issues = []
    review_issues = []

    post_integrity = pretrade_posttrade_lineage_integrity(
        post
    )
    fill_integrity = pretrade_fill_lineage_integrity(
        fill
    )

    if post_integrity["status"] != "OK":
        invalidation_issues.append(
            "POSTTRADE_LINEAGE_INTEGRITY_FAILED"
        )
    if fill_integrity["status"] != "OK":
        invalidation_issues.append(
            "FILL_LINEAGE_INTEGRITY_FAILED"
        )

    if _text(
        post.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        invalidation_issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    if _text(
        fill.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        invalidation_issues.append(
            "FILL_EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    packet_id = _text(
        post.get(
            "packet_id"
        )
    )
    fill_packet_id = _text(
        fill.get(
            "packet_id"
        )
    )
    if (
        packet_id
        and fill_packet_id
        and packet_id != fill_packet_id
    ):
        review_issues.append(
            "PACKET_ID_MISMATCH"
        )

    fill_id = _text(
        post.get(
            "fill_id"
        )
    )
    fill_fill_id = _text(
        fill.get(
            "fill_id"
        )
    )
    if (
        fill_id
        and fill_fill_id
        and fill_id != fill_fill_id
    ):
        review_issues.append(
            "FILL_ID_MISMATCH"
        )

    post_fill_lineage_id = _text(
        post.get(
            "fill_lineage_id"
        )
    )
    actual_fill_lineage_id = _text(
        fill.get(
            "lineage_id"
        )
    )
    if (
        post_fill_lineage_id
        and actual_fill_lineage_id
        and post_fill_lineage_id
        != actual_fill_lineage_id
    ):
        review_issues.append(
            "FILL_LINEAGE_ID_MISMATCH"
        )

    packet_snapshot_hash = _text(
        post.get(
            "packet_snapshot_hash"
        )
    )
    fill_packet_snapshot_hash = _text(
        fill.get(
            "packet_snapshot_hash"
        )
    )
    if (
        packet_snapshot_hash
        and fill_packet_snapshot_hash
        and packet_snapshot_hash
        != fill_packet_snapshot_hash
    ):
        review_issues.append(
            "PACKET_SNAPSHOT_HASH_MISMATCH"
        )

    company = _text(
        fill.get(
            "fill_name"
        )
    )
    decision_company = _text(
        decision.get(
            "company"
        )
    )
    if not company:
        review_issues.append(
            "FILL_COMPANY_REQUIRED"
        )
    if not decision_company:
        review_issues.append(
            "DECISION_COMPANY_REQUIRED"
        )
    elif company and company != decision_company:
        review_issues.append(
            "DECISION_COMPANY_MISMATCH"
        )

    decision_id = _text(
        decision.get(
            "decision_id"
        )
    )
    decision_hash = _text(
        decision.get(
            "content_hash"
        )
    )
    decision_status = _text(
        decision.get(
            "review_status"
        )
    ).upper()
    decision_hash_status = _text(
        decision.get(
            "hash_status"
        )
    ).upper()

    if not decision_id:
        review_issues.append(
            "APPROVED_DECISION_REQUIRED"
        )
    if decision_status != "APPROVED":
        review_issues.append(
            "DECISION_NOT_APPROVED"
        )
    if decision_hash_status != "OK":
        review_issues.append(
            "DECISION_HASH_NOT_OK"
        )
    if not decision_hash:
        review_issues.append(
            "DECISION_HASH_SNAPSHOT_REQUIRED"
        )

    has_outcome = bool(
        outcome
        and any(
            _text(
                outcome.get(key)
            )
            for key in [
                "decision_id",
                "review_id",
                "outcome_review_id",
                "outcome_id",
                "actual_outcome",
                "outcome_classification",
            ]
        )
    )

    outcome_review_id = ""
    outcome_hash = ""
    outcome_status = ""
    outcome_hash_status = ""
    outcome_link_status = ""
    outcome_classification = ""
    forecast_error_class = ""
    process_adherence = ""
    actual_outcome = ""
    new_learning = ""
    next_action = ""

    if has_outcome:
        outcome_review_id = _outcome_review_id(
            outcome
        )
        outcome_hash = _text(
            outcome.get(
                "content_hash"
            )
        )
        outcome_status = _text(
            outcome.get(
                "review_status"
            )
        ).upper()
        outcome_hash_status = _text(
            outcome.get(
                "hash_status"
            )
        ).upper()
        outcome_link_status = _text(
            outcome.get(
                "link_status"
            )
        ).upper()

        outcome_decision_id = _text(
            outcome.get(
                "decision_id"
            )
        )
        if (
            decision_id
            and outcome_decision_id
            and outcome_decision_id
            != decision_id
        ):
            review_issues.append(
                "OUTCOME_DECISION_ID_MISMATCH"
            )

        if outcome_status != "APPROVED":
            review_issues.append(
                "OUTCOME_NOT_APPROVED"
            )
        if outcome_hash_status != "OK":
            review_issues.append(
                "OUTCOME_HASH_NOT_OK"
            )
        if outcome_link_status != "MATCH":
            review_issues.append(
                "OUTCOME_DECISION_LINK_NOT_MATCH"
            )
        if not outcome_hash:
            review_issues.append(
                "OUTCOME_HASH_SNAPSHOT_REQUIRED"
            )

        outcome_classification = _text(
            outcome.get(
                "outcome_classification"
            )
        )
        forecast_error_class = _text(
            outcome.get(
                "forecast_error_class"
            )
        )
        process_adherence = _text(
            outcome.get(
                "process_adherence"
            )
        )
        actual_outcome = _text(
            outcome.get(
                "actual_outcome"
            )
        )
        new_learning = _text(
            outcome.get(
                "new_learning"
            )
        )
        next_action = _text(
            outcome.get(
                "next_action"
            )
        )

        if not outcome_classification:
            review_issues.append(
                "OUTCOME_CLASSIFICATION_REQUIRED"
            )
        if not forecast_error_class:
            review_issues.append(
                "FORECAST_ERROR_CLASS_REQUIRED"
            )
        if not process_adherence:
            review_issues.append(
                "PROCESS_ADHERENCE_REQUIRED"
            )

    invalidation_issues = list(
        dict.fromkeys(
            invalidation_issues
        )
    )
    review_issues = list(
        dict.fromkeys(
            review_issues
        )
    )

    if invalidation_issues:
        learning_status = "INVALIDATED"
        issues = (
            invalidation_issues
            + review_issues
        )
    elif review_issues:
        learning_status = "REVIEW"
        issues = review_issues
    elif has_outcome:
        learning_status = "LEARNING_COMPLETE"
        issues = []
    else:
        learning_status = "OUTCOME_PENDING"
        issues = []

    return {
        "company": company,
        "packet_id": packet_id,
        "packet_snapshot_hash":
            packet_snapshot_hash,
        "fill_id": fill_id,
        "fill_lineage_id":
            actual_fill_lineage_id,
        "fill_lineage_status": _text(
            fill.get(
                "lineage_status"
            )
        ),
        "fill_lineage_integrity":
            fill_integrity[
                "status"
            ],
        "posttrade_lineage_hash": _text(
            post.get(
                "lineage_hash"
            )
        ),
        "posttrade_lineage_integrity":
            post_integrity[
                "status"
            ],
        "post_trade_audit_status": _text(
            post.get(
                "post_trade_audit_status"
            )
        ),
        "decision_id": decision_id,
        "decision_hash_snapshot":
            decision_hash,
        "decision_review_status":
            decision_status,
        "decision_hash_status":
            decision_hash_status,
        "decision_date": _text(
            decision.get(
                "decision_date"
            )
        ),
        "decision_type": _text(
            decision.get(
                "decision_type"
            )
        ),
        "decision_action": _text(
            decision.get(
                "action"
            )
        ),
        "expected_outcome": _text(
            decision.get(
                "expected_outcome"
            )
        ),
        "proof_date": _text(
            decision.get(
                "proof_date"
            )
        ),
        "outcome_review_id":
            outcome_review_id,
        "outcome_hash_snapshot":
            outcome_hash,
        "outcome_review_status":
            outcome_status,
        "outcome_hash_status":
            outcome_hash_status,
        "outcome_link_status":
            outcome_link_status,
        "outcome_classification":
            outcome_classification,
        "forecast_error_class":
            forecast_error_class,
        "process_adherence":
            process_adherence,
        "actual_outcome":
            actual_outcome,
        "new_learning":
            new_learning,
        "next_action":
            next_action,
        "has_outcome": has_outcome,
        "learning_status":
            learning_status,
        "issues": issues,
        "execution_authorization":
            "NONE",
    }


def validate_learning_lineage_review(
    preview: dict,
    *,
    human_review_confirmed: bool,
) -> dict:
    p = preview or {}
    status = _text(
        p.get(
            "learning_status"
        )
    ).upper()

    issues = []
    if status in {
        "",
        "REVIEW",
        "INVALIDATED",
    }:
        issues.append(
            "LEARNING_LINEAGE_NOT_READY"
        )

    if not _bool(
        human_review_confirmed
    ):
        issues.append(
            "HUMAN_REVIEW_CONFIRMATION_REQUIRED"
        )

    return {
        "review_gate":
            "PASS"
            if not issues
            else "REVIEW",
        "save_status":
            status
            if not issues
            else "DRAFT",
        "issues":
            issues,
        "execution_authorization":
            "NONE",
    }


def _record_payload(
    row: dict,
) -> dict:
    payload = {}
    for field in [
        x
        for x in DECISION_LEARNING_LINEAGE_COLS
        if x != "lineage_hash"
    ]:
        if field == "human_review_confirmed":
            payload[field] = bool(
                _bool(
                    row.get(field)
                )
            )
        else:
            payload[field] = _text(
                row.get(field)
            )
    return payload


def build_decision_learning_lineage_record(
    preview: dict,
    review: dict,
    *,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    p = preview or {}
    r = review or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    packet_id = _text(
        p.get(
            "packet_id"
        )
    )
    decision_id = _text(
        p.get(
            "decision_id"
        )
    )

    lineage_id = (
        "DLN-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            (
                packet_id
                + "|"
                + decision_id
                + "|"
                + _text(
                    p.get(
                        "outcome_review_id"
                    )
                )
            ).encode(
                "utf-8"
            )
        ).hexdigest()[:8]
    )

    row = {
        "learning_lineage_id":
            lineage_id,
        "created_at":
            now,
        "company":
            _text(
                p.get(
                    "company"
                )
            ),
        "packet_id":
            packet_id,
        "packet_snapshot_hash":
            _text(
                p.get(
                    "packet_snapshot_hash"
                )
            ),
        "fill_id":
            _text(
                p.get(
                    "fill_id"
                )
            ),
        "fill_lineage_id":
            _text(
                p.get(
                    "fill_lineage_id"
                )
            ),
        "fill_lineage_status":
            _text(
                p.get(
                    "fill_lineage_status"
                )
            ),
        "fill_lineage_integrity":
            _text(
                p.get(
                    "fill_lineage_integrity"
                )
            ),
        "posttrade_lineage_hash":
            _text(
                p.get(
                    "posttrade_lineage_hash"
                )
            ),
        "posttrade_lineage_integrity":
            _text(
                p.get(
                    "posttrade_lineage_integrity"
                )
            ),
        "post_trade_audit_status":
            _text(
                p.get(
                    "post_trade_audit_status"
                )
            ),
        "decision_id":
            decision_id,
        "decision_hash_snapshot":
            _text(
                p.get(
                    "decision_hash_snapshot"
                )
            ),
        "decision_review_status":
            _text(
                p.get(
                    "decision_review_status"
                )
            ),
        "decision_hash_status":
            _text(
                p.get(
                    "decision_hash_status"
                )
            ),
        "decision_date":
            _text(
                p.get(
                    "decision_date"
                )
            ),
        "decision_type":
            _text(
                p.get(
                    "decision_type"
                )
            ),
        "decision_action":
            _text(
                p.get(
                    "decision_action"
                )
            ),
        "expected_outcome":
            _text(
                p.get(
                    "expected_outcome"
                )
            ),
        "proof_date":
            _text(
                p.get(
                    "proof_date"
                )
            ),
        "outcome_review_id":
            _text(
                p.get(
                    "outcome_review_id"
                )
            ),
        "outcome_hash_snapshot":
            _text(
                p.get(
                    "outcome_hash_snapshot"
                )
            ),
        "outcome_review_status":
            _text(
                p.get(
                    "outcome_review_status"
                )
            ),
        "outcome_hash_status":
            _text(
                p.get(
                    "outcome_hash_status"
                )
            ),
        "outcome_link_status":
            _text(
                p.get(
                    "outcome_link_status"
                )
            ),
        "outcome_classification":
            _text(
                p.get(
                    "outcome_classification"
                )
            ),
        "forecast_error_class":
            _text(
                p.get(
                    "forecast_error_class"
                )
            ),
        "process_adherence":
            _text(
                p.get(
                    "process_adherence"
                )
            ),
        "actual_outcome":
            _text(
                p.get(
                    "actual_outcome"
                )
            ),
        "new_learning":
            _text(
                p.get(
                    "new_learning"
                )
            ),
        "next_action":
            _text(
                p.get(
                    "next_action"
                )
            ),
        "learning_status":
            _text(
                r.get(
                    "save_status",
                    p.get(
                        "learning_status"
                    ),
                )
            ),
        "issues":
            " | ".join(
                p.get(
                    "issues",
                    [],
                )
            ),
        "execution_authorization":
            "NONE",
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "note":
            _text(
                note
            ),
        "lineage_hash":
            "",
    }

    row[
        "lineage_hash"
    ] = _hash(
        _record_payload(
            row
        )
    )
    return row


def decision_learning_lineage_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "lineage_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _record_payload(
            record
        )
    )
    return {
        "status":
            "OK"
            if stored
            == calculated
            else "MISMATCH",
        "calculated_hash":
            calculated,
    }
