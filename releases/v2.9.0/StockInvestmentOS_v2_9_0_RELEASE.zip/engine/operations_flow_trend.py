from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json
import math

import pandas as pd


FLOW_TREND_SNAPSHOT_COLS = [
    "trend_snapshot_id",
    "created_at",
    "current_group_count",
    "attention_group_count",
    "capacity",
    "group_root_map_json",
    "group_priority_map_json",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


ROOT_CAUSE_FLOW_COLS = [
    "root_cause",
    "previous_groups",
    "current_groups",
    "arrivals",
    "exits",
    "persisting",
    "net_change",
]


FLOW_TREND_HISTORY_COLS = [
    "period_end",
    "previous_groups",
    "current_groups",
    "arrivals",
    "exits",
    "persisting",
    "net_change",
    "attention_groups",
    "capacity",
]


FLOW_TREND_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _json_dict(value: Any) -> dict[str, str]:
    raw = _text(value)
    if not raw:
        return {}

    try:
        parsed = json.loads(raw)
    except Exception:
        return {}

    if not isinstance(parsed, dict):
        return {}

    out = {}
    for key, val in parsed.items():
        k = _text(key)
        v = _text(val)
        if k:
            out[k] = v

    return out


def _snapshot_payload(row: dict) -> dict:
    return {
        "current_group_count": _int(row.get("current_group_count")),
        "attention_group_count": _int(row.get("attention_group_count")),
        "capacity": _int(row.get("capacity")),
        "group_root_map_json": _text(row.get("group_root_map_json")),
        "group_priority_map_json": _text(row.get("group_priority_map_json")),
        "execution_authorization": _text(row.get("execution_authorization")),
    }


def flow_trend_snapshot_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(record.get("snapshot_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_snapshot_payload(record))

    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def build_group_maps(
    recurrence_table: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if recurrence_table is None
        else recurrence_table.copy()
    )

    root_map = {}
    priority_map = {}

    if not df.empty:
        for _, row in df.iterrows():
            group_id = _text(row.get("group_id"))
            if not group_id:
                continue

            root_map[group_id] = (
                _text(row.get("root_cause"))
                or "UNCLASSIFIED"
            )
            priority_map[group_id] = (
                _text(row.get("priority")).upper()
                or "UNCLASSIFIED"
            )

    attention_count = sum(
        1
        for group_id, priority in priority_map.items()
        if priority in {"RQ0", "RQ1"}
    )

    return {
        "root_map": root_map,
        "priority_map": priority_map,
        "group_count": len(root_map),
        "attention_count": attention_count,
    }


def build_flow_trend_snapshot(
    recurrence_table: pd.DataFrame | None,
    *,
    capacity: int = 5,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(created_at)
        or datetime.now().astimezone().isoformat()
    )

    maps = build_group_maps(
        recurrence_table
    )

    payload = {
        "current_group_count": maps["group_count"],
        "attention_group_count": maps["attention_count"],
        "capacity": max(1, _int(capacity)),
        "group_root_map_json": json.dumps(
            maps["root_map"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        "group_priority_map_json": json.dumps(
            maps["priority_map"],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(payload)

    return {
        "trend_snapshot_id": (
            "OFT-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **payload,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def valid_trend_history(
    snapshots: pd.DataFrame | None,
) -> dict:
    if snapshots is None or snapshots.empty:
        return {
            "valid": pd.DataFrame(
                columns=FLOW_TREND_SNAPSHOT_COLS
            ),
            "invalid_count": 0,
            "total_count": 0,
        }

    df = snapshots.copy()

    for col in FLOW_TREND_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    valid_rows = []
    invalid_count = 0

    for _, row in df.iterrows():
        record = row.to_dict()

        if flow_trend_snapshot_integrity(record)["status"] == "OK":
            valid_rows.append(record)
        else:
            invalid_count += 1

    valid = pd.DataFrame(
        valid_rows,
        columns=FLOW_TREND_SNAPSHOT_COLS,
    )

    if not valid.empty:
        valid["_ts"] = pd.to_datetime(
            valid["created_at"],
            errors="coerce",
            utc=True,
        )
        valid = (
            valid.sort_values(
                "_ts",
                ascending=True,
                na_position="last",
            )
            .drop(columns=["_ts"])
            .reset_index(drop=True)
        )

    return {
        "valid": valid,
        "invalid_count": invalid_count,
        "total_count": int(len(df)),
    }


def _compare_maps(
    previous_root_map: dict[str, str],
    current_root_map: dict[str, str],
) -> dict:
    prev_ids = set(previous_root_map.keys())
    cur_ids = set(current_root_map.keys())

    arrivals = cur_ids - prev_ids
    exits = prev_ids - cur_ids
    persisting = cur_ids & prev_ids

    causes = sorted(
        set(previous_root_map.values())
        | set(current_root_map.values())
    )

    rows = []

    for cause in causes:
        prev_groups = {
            group_id
            for group_id, root in previous_root_map.items()
            if root == cause
        }
        cur_groups = {
            group_id
            for group_id, root in current_root_map.items()
            if root == cause
        }

        cause_arrivals = {
            group_id
            for group_id in arrivals
            if current_root_map.get(group_id) == cause
        }
        cause_exits = {
            group_id
            for group_id in exits
            if previous_root_map.get(group_id) == cause
        }
        cause_persisting = {
            group_id
            for group_id in persisting
            if current_root_map.get(group_id) == cause
        }

        rows.append(
            {
                "root_cause": cause,
                "previous_groups": len(prev_groups),
                "current_groups": len(cur_groups),
                "arrivals": len(cause_arrivals),
                "exits": len(cause_exits),
                "persisting": len(cause_persisting),
                "net_change": len(cur_groups) - len(prev_groups),
            }
        )

    return {
        "arrivals": arrivals,
        "exits": exits,
        "persisting": persisting,
        "root_cause_flow": pd.DataFrame(
            rows,
            columns=ROOT_CAUSE_FLOW_COLS,
        ),
    }


def build_flow_trend(
    recurrence_table: pd.DataFrame | None,
    snapshots: pd.DataFrame | None,
    *,
    capacity: int = 5,
    forecast_min_snapshots: int = 3,
    history_window: int = 5,
) -> dict:
    maps = build_group_maps(
        recurrence_table
    )
    current_root_map = maps["root_map"]
    current_priority_map = maps["priority_map"]

    history_info = valid_trend_history(
        snapshots
    )
    history = history_info["valid"]

    if history.empty:
        return {
            "trend_state": "BASELINE_REQUIRED",
            "history_snapshots": 0,
            "invalid_snapshots": history_info["invalid_count"],
            "current_groups": maps["group_count"],
            "attention_groups": maps["attention_count"],
            "arrivals": maps["group_count"],
            "exits": 0,
            "persisting": 0,
            "net_change": 0,
            "root_cause_flow": pd.DataFrame(
                columns=ROOT_CAUSE_FLOW_COLS
            ),
            "history_table": pd.DataFrame(
                columns=FLOW_TREND_HISTORY_COLS
            ),
            "avg_arrivals_per_interval": 0.0,
            "avg_exits_per_interval": 0.0,
            "avg_net_burn_per_interval": 0.0,
            "forecast_state": "INSUFFICIENT_HISTORY",
            "estimated_clearance_intervals": None,
            "capacity": max(1, _int(capacity)),
            "capacity_pressure": (
                maps["attention_count"]
                / max(1, _int(capacity))
            ),
            "execution_authorization": "NONE",
        }

    previous = history.iloc[-1].to_dict()
    previous_root_map = _json_dict(
        previous.get("group_root_map_json")
    )

    comparison = _compare_maps(
        previous_root_map,
        current_root_map,
    )

    arrivals = len(comparison["arrivals"])
    exits = len(comparison["exits"])
    persisting = len(comparison["persisting"])
    previous_count = len(previous_root_map)
    current_count = len(current_root_map)
    net_change = current_count - previous_count

    if arrivals == 0 and exits == 0:
        trend_state = "STALLED"
    elif exits > arrivals and net_change < 0:
        trend_state = "IMPROVING"
    elif arrivals > exits and net_change > 0:
        trend_state = "GROWING"
    else:
        trend_state = "MIXED"

    # Build exact pairwise history from stored snapshots.
    history_rows = []

    if len(history) >= 2:
        for idx in range(1, len(history)):
            prev_row = history.iloc[idx - 1].to_dict()
            cur_row = history.iloc[idx].to_dict()

            prev_map = _json_dict(
                prev_row.get("group_root_map_json")
            )
            cur_map = _json_dict(
                cur_row.get("group_root_map_json")
            )
            cmp = _compare_maps(
                prev_map,
                cur_map,
            )

            history_rows.append(
                {
                    "period_end": _text(
                        cur_row.get("created_at")
                    ),
                    "previous_groups": len(prev_map),
                    "current_groups": len(cur_map),
                    "arrivals": len(cmp["arrivals"]),
                    "exits": len(cmp["exits"]),
                    "persisting": len(cmp["persisting"]),
                    "net_change": len(cur_map) - len(prev_map),
                    "attention_groups": _int(
                        cur_row.get("attention_group_count")
                    ),
                    "capacity": _int(
                        cur_row.get("capacity")
                    ),
                }
            )

    # Add current live interval versus the latest stored snapshot.
    history_rows.append(
        {
            "period_end": "LIVE",
            "previous_groups": previous_count,
            "current_groups": current_count,
            "arrivals": arrivals,
            "exits": exits,
            "persisting": persisting,
            "net_change": net_change,
            "attention_groups": maps["attention_count"],
            "capacity": max(1, _int(capacity)),
        }
    )

    history_table = pd.DataFrame(
        history_rows,
        columns=FLOW_TREND_HISTORY_COLS,
    )

    recent = history_table.tail(
        max(1, _int(history_window))
    )

    avg_arrivals = float(
        pd.to_numeric(
            recent["arrivals"],
            errors="coerce",
        ).fillna(0).mean()
    )
    avg_exits = float(
        pd.to_numeric(
            recent["exits"],
            errors="coerce",
        ).fillna(0).mean()
    )
    avg_net_burn = avg_exits - avg_arrivals

    # Need at least N stored snapshots. Live state alone does not count as a saved observation.
    if len(history) < max(2, _int(forecast_min_snapshots)):
        forecast_state = "INSUFFICIENT_HISTORY"
        clearance_intervals = None
    elif current_count == 0:
        forecast_state = "ALREADY_CLEAR"
        clearance_intervals = 0.0
    elif avg_net_burn > 0:
        forecast_state = "PROJECTED_BURN_DOWN"
        clearance_intervals = float(
            math.ceil(
                current_count / avg_net_burn
            )
        )
    else:
        forecast_state = "NO_CLEARING_TREND"
        clearance_intervals = None

    return {
        "trend_state": trend_state,
        "history_snapshots": int(len(history)),
        "invalid_snapshots": history_info["invalid_count"],
        "current_groups": current_count,
        "attention_groups": maps["attention_count"],
        "arrivals": arrivals,
        "exits": exits,
        "persisting": persisting,
        "net_change": net_change,
        "root_cause_flow": comparison["root_cause_flow"],
        "history_table": history_table,
        "avg_arrivals_per_interval": avg_arrivals,
        "avg_exits_per_interval": avg_exits,
        "avg_net_burn_per_interval": avg_net_burn,
        "forecast_state": forecast_state,
        "estimated_clearance_intervals": clearance_intervals,
        "capacity": max(1, _int(capacity)),
        "capacity_pressure": (
            maps["attention_count"]
            / max(1, _int(capacity))
        ),
        "execution_authorization": "NONE",
    }


def build_flow_trend_queue(
    trend: dict | None,
) -> pd.DataFrame:
    result = trend or {}
    rows = []

    if _int(result.get("invalid_snapshots")) > 0:
        rows.append(
            {
                "priority": "FT0",
                "status": "BLOCKED",
                "issue": "FLOW_TREND_SNAPSHOT_INTEGRITY",
                "detail": (
                    f"invalid snapshots "
                    f"{_int(result.get('invalid_snapshots'))}"
                ),
                "next_action": "Trend Snapshot immutable hash를 먼저 확인",
                "go_to": "Operations Control Tower",
            }
        )

    trend_state = _text(
        result.get("trend_state")
    ).upper()

    if trend_state == "GROWING":
        rows.append(
            {
                "priority": "FT1",
                "status": "REVIEW",
                "issue": "FLOW_TREND_GROWING",
                "detail": (
                    f"arrivals {_int(result.get('arrivals'))} · "
                    f"exits {_int(result.get('exits'))} · "
                    f"net {_int(result.get('net_change')):+d}"
                ),
                "next_action": "Root Cause별 Arrival이 Exit보다 많은 원인을 검토",
                "go_to": "Review Queue",
            }
        )
    elif trend_state == "STALLED":
        rows.append(
            {
                "priority": "FT2",
                "status": "REVIEW",
                "issue": "FLOW_TREND_STALLED",
                "detail": (
                    f"persisting {_int(result.get('persisting'))} · "
                    "arrival 0 · exit 0"
                ),
                "next_action": "지속 그룹의 원본 Review와 미해결 Root Cause를 확인",
                "go_to": "Review Queue",
            }
        )

    forecast_state = _text(
        result.get("forecast_state")
    ).upper()

    if forecast_state == "NO_CLEARING_TREND":
        rows.append(
            {
                "priority": "FT1",
                "status": "REVIEW",
                "issue": "NO_CLEARING_THROUGHPUT_TREND",
                "detail": (
                    f"avg arrivals {result.get('avg_arrivals_per_interval',0):.2f} · "
                    f"avg exits {result.get('avg_exits_per_interval',0):.2f}"
                ),
                "next_action": "Snapshot 구간당 Exit가 Arrival을 초과하는지 운영 흐름을 재검토",
                "go_to": "Operations Control Tower",
            }
        )

    if _float(result.get("capacity_pressure")) > 1.0:
        rows.append(
            {
                "priority": "FT2",
                "status": "REVIEW",
                "issue": "FLOW_CAPACITY_PRESSURE_ABOVE_1X",
                "detail": (
                    f"{_float(result.get('capacity_pressure')):.2f}x"
                ),
                "next_action": "RQ0/RQ1 우선 Worklist와 Carry-forward를 검토",
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=FLOW_TREND_QUEUE_COLS
        )

    order = {
        "FT0": 0,
        "FT1": 1,
        "FT2": 2,
    }

    out = pd.DataFrame(rows)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(
            ["_p", "issue"]
        )
        .drop(columns=["_p"])[FLOW_TREND_QUEUE_COLS]
        .reset_index(drop=True)
    )
