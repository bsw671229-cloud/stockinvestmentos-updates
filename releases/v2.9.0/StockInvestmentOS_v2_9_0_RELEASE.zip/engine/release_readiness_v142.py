from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_controlled_trial_design import (
    FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
    controlled_trial_design_snapshot_integrity,
)
from engine.operations_flow_controlled_trial_start import (
    FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
    CONTROLLED_TRIAL_START_STATES,
    TRIAL_START_GUARD_BY_STATE,
    TRIAL_START_DECISIONS,
    build_flow_controlled_trial_start,
    controlled_trial_start_snapshot_integrity,
    latest_controlled_trial_start_snapshot,
)


TRIAL_START_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

TRIAL_START_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V142_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v142_trial_start_context(
    *,
    v141_context: dict | None,
    controlled_trial_start_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v141_context or {}
    design = upstream.get("design") or {}

    start_df = _ensure_cols(
        controlled_trial_start_snapshots,
        FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
    )

    start = build_flow_controlled_trial_start(
        design,
        start_df,
    )

    latest_start = latest_controlled_trial_start_snapshot(
        start_df
    )

    latest_integrity = (
        _text(
            controlled_trial_start_snapshot_integrity(
                latest_start
            ).get("status")
        ).upper()
        if latest_start
        else "NONE"
    )

    return {
        "v141_context": upstream,
        "design": design,
        "controlled_trial_design_snapshots": _ensure_cols(
            upstream.get(
                "controlled_trial_design_snapshots"
            ),
            FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
        ),
        "controlled_trial_start_snapshots": start_df,
        "start": start,
        "start_integrity": _integrity_counts(
            start_df,
            controlled_trial_start_snapshot_integrity,
        ),
        "latest_start": latest_start,
        "latest_start_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _design_routing_ok(
    start: dict,
    design: dict,
) -> bool:
    start_state = _text(
        start.get("start_state")
    ).upper()
    design_state = _text(
        design.get("design_state")
    ).upper()

    if design_state == "TRIAL_DESIGN_LOCKED":
        return start_state in {
            "TRIAL_START_DESIGN_SOURCE_REQUIRED",
            "TRIAL_START_SOURCE_INTEGRITY_REVIEW",
            "TRIAL_START_REVIEW_REQUIRED",
            "TRIAL_START_SOURCE_SUPERSEDED",
            "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
            "TRIAL_START_REJECTED",
            "TRIAL_START_DEFERRED",
        }

    if design_state == "TRIAL_DESIGN_NOT_REQUIRED":
        return start_state == "TRIAL_START_NOT_REQUIRED"

    return start_state == "TRIAL_START_UPSTREAM_WAIT"


def _design_source_mapping_ok(
    context: dict,
) -> bool:
    start = context.get("start") or {}
    state = _text(
        start.get("start_state")
    ).upper()

    if state in {
        "TRIAL_START_UPSTREAM_WAIT",
        "TRIAL_START_NOT_REQUIRED",
    }:
        return True

    source_id = _text(
        start.get(
            "source_trial_design_id"
        )
    )
    source_hash = _text(
        start.get(
            "source_trial_design_hash"
        )
    )

    if not source_id or not source_hash:
        return state == "TRIAL_START_DESIGN_SOURCE_REQUIRED"

    index, duplicates = _index_by_id(
        context.get(
            "controlled_trial_design_snapshots"
        ),
        "controlled_trial_design_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    if not parent:
        return False

    return (
        _text(
            controlled_trial_design_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("design_state")
        ).upper()
        == "TRIAL_DESIGN_LOCKED"
    )


def _permit_bound_ok(
    start: dict,
) -> bool:
    state = _text(
        start.get("start_state")
    ).upper()

    if state != "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY":
        return True

    return (
        _text(
            start.get(
                "shadow_trial_permission"
            )
        ).upper()
        == "SHADOW_CANARY_ONLY"
        and 0.01
        <= _float(
            start.get(
                "permit_scope_pct"
            )
        )
        <= min(
            0.10,
            _float(
                start.get(
                    "design_max_scope_pct"
                )
            ),
        )
        and 1
        <= _int(
            start.get(
                "permit_session_budget"
            )
        )
        <= _int(
            start.get(
                "design_session_cap"
            )
        )
        and _int(
            start.get(
                "permit_min_trial_outcomes"
            )
        )
        == _int(
            start.get(
                "design_min_trial_outcomes"
            )
        )
        and abs(
            _float(
                start.get(
                    "permit_max_relative_error_degradation_pct"
                )
            )
            - _float(
                start.get(
                    "design_max_relative_error_degradation_pct"
                )
            )
        )
        <= 1e-12
    )


def _human_start_contract_ok(
    start: dict,
) -> bool:
    state = _text(
        start.get("start_state")
    ).upper()

    if state not in {
        "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
        "TRIAL_START_REJECTED",
        "TRIAL_START_DEFERRED",
    }:
        return True

    row = start.get(
        "latest_start"
    ) or {}

    if not row:
        return False

    if _text(
        controlled_trial_start_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    decision = _text(
        row.get("start_decision")
    ).upper()

    expected = {
        "ISSUE_SHADOW_TRIAL_PERMIT":
            "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
        "REJECT":
            "TRIAL_START_REJECTED",
        "DEFER":
            "TRIAL_START_DEFERRED",
    }.get(
        decision
    )

    if state != expected:
        return False

    if decision not in TRIAL_START_DECISIONS:
        return False

    required = [
        "design_source_reviewed",
        "isolation_rechecked",
        "kill_switch_ready_confirmed",
        "rollback_ready_confirmed",
        "manual_start_confirmed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            row.get(field)
        )
        for field in required
    ):
        return False

    if len(
        _text(
            row.get(
                "start_detail"
            )
        )
    ) < 40:
        return False

    if decision == "ISSUE_SHADOW_TRIAL_PERMIT":
        return (
            _text(
                row.get(
                    "shadow_trial_permission"
                )
            ).upper()
            == "SHADOW_CANARY_ONLY"
        )

    return (
        _text(
            row.get(
                "shadow_trial_permission"
            )
        ).upper()
        in {"", "NONE"}
    )


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    start = context.get("start") or {}
    state = _text(
        start.get("start_state")
    ).upper()

    latest = context.get(
        "latest_start"
    ) or {}

    if state in {
        "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
        "TRIAL_START_REJECTED",
        "TRIAL_START_DEFERRED",
    }:
        source_ts = pd.to_datetime(
            start.get(
                "source_trial_design_created_at"
            ),
            errors="coerce",
            utc=True,
        )
        start_ts = pd.to_datetime(
            latest.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )

        return (
            not pd.isna(source_ts)
            and not pd.isna(start_ts)
            and start_ts > source_ts
        )

    if state == "TRIAL_START_SOURCE_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(
                latest.get(
                    "source_trial_design_id"
                )
            )
            != _text(
                start.get(
                    "source_trial_design_id"
                )
            )
            or _text(
                latest.get(
                    "source_trial_design_hash"
                )
            )
            != _text(
                start.get(
                    "source_trial_design_hash"
                )
            )
        )

    return True


def _no_execution_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("start") or {},
        context.get("latest_start") or {},
        context.get("design") or {},
    ]:
        for field in [
            "trial_start_authorization",
            "trial_design_authorization",
            "adoption_authorization",
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "controlled_trial_start_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v142_trial_start_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    start = ctx.get("start") or {}
    design = ctx.get("design") or {}
    counts = ctx.get("start_integrity") or {}

    state = _text(
        start.get("start_state")
    ).upper()
    guard = _text(
        start.get("start_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Controlled Trial Start Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Start immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Start State / Guard Vocabulary",
            (
                state in CONTROLLED_TRIAL_START_STATES
                and guard
                == TRIAL_START_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {TRIAL_START_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Trial Start state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Design → Trial Start State Invariant",
            _design_routing_ok(
                start,
                design,
            ),
            (
                f"design {_text(design.get('design_state')) or 'MISSING'} · "
                f"start {state or 'MISSING'}"
            ),
            "Trial Design LOCK/WAIT/NOT_REQUIRED와 Start state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Start → Controlled Trial Design Source Mapping",
            _design_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(start.get('source_trial_design_id')) or 'NONE'} · "
                f"integrity {_text(start.get('source_trial_design_integrity')) or 'NONE'}"
            ),
            "Trial Start source Design id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Shadow Trial Permit Scope / Session / Outcome Inheritance Invariant",
            _permit_bound_ok(
                start
            ),
            (
                f"state {state or 'MISSING'} · "
                f"scope {_float(start.get('permit_scope_pct')):.1%}/"
                f"{_float(start.get('design_max_scope_pct')):.1%} · "
                f"sessions {_int(start.get('permit_session_budget'))}/"
                f"{_int(start.get('design_session_cap'))}"
            ),
            "Permit가 locked Design scope/session/outcome/degradation bound를 초과하지 않는지 확인",
        )
    )

    checks.append(
        _technical_row(
            "Kill-Switch / Rollback / Human Start Contract Invariant",
            _human_start_contract_ok(
                start
            ),
            (
                f"state {state or 'MISSING'} · "
                f"decision {_text(start.get('start_decision')) or 'NONE'} · "
                f"permission {_text(start.get('shadow_trial_permission')) or 'NONE'}"
            ),
            "Kill switch / rollback readiness / Human Start confirmations 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Start Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source created {_text(start.get('source_trial_design_created_at')) or 'NONE'} · "
                f"latest start {_text((ctx.get('latest_start') or {}).get('controlled_trial_start_id')) or 'NONE'}"
            ),
            "Start Review 저장 순서와 새 Design source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial No-Live-Execution Authorization Invariant",
            _no_execution_authorization_ok(
                ctx
            ),
            "NONE",
            "Trial Start/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "TRIAL_START_NOT_REQUIRED",
            "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
            "TRIAL_START_REJECTED",
            "TRIAL_START_DEFERRED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Start Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"permission {_text(start.get('shadow_trial_permission')) or 'NONE'} · "
                f"scope {_float(start.get('permit_scope_pct')):.1%}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 design/start wait는 Technical FAIL로 승격하지 않고 "
                    "Human decision 및 source evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "start_state": state,
        "design_state": _text(
            design.get("design_state")
        ).upper(),
        "latest_trial_start_integrity":
            _text(
                ctx.get(
                    "latest_start_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_START_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v142_trial_start_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    start_df = _ensure_cols(
        ctx.get(
            "controlled_trial_start_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
    )

    design_df = _ensure_cols(
        ctx.get(
            "controlled_trial_design_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        start_df,
        controlled_trial_start_snapshot_integrity,
    )

    design_index, design_duplicates = _index_by_id(
        design_df,
        "controlled_trial_design_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in start_df.iterrows():
        item = row.to_dict()

        start_id = _text(
            item.get(
                "controlled_trial_start_id"
            )
        )

        if start_id:
            if start_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(start_id)

        decision = _text(
            item.get(
                "start_decision"
            )
        ).upper()
        state = _text(
            item.get(
                "start_state"
            )
        ).upper()

        expected_state = {
            "ISSUE_SHADOW_TRIAL_PERMIT":
                "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
            "REJECT":
                "TRIAL_START_REJECTED",
            "DEFER":
                "TRIAL_START_DEFERRED",
        }.get(
            decision
        )

        required_flags = [
            "design_source_reviewed",
            "isolation_rechecked",
            "kill_switch_ready_confirmed",
            "rollback_ready_confirmed",
            "manual_start_confirmed",
            "no_live_apply_confirmed",
            "no_auto_recalibration_confirmed",
            "no_auto_capacity_confirmed",
            "no_execution_authorization_confirmed",
            "human_review_confirmed",
        ]

        if (
            decision not in TRIAL_START_DECISIONS
            or state != expected_state
            or len(
                _text(
                    item.get(
                        "start_detail"
                    )
                )
            ) < 40
            or not all(
                _bool(
                    item.get(field)
                )
                for field in required_flags
            )
        ):
            contract_violations += 1

        if decision == "ISSUE_SHADOW_TRIAL_PERMIT":
            if not (
                _text(
                    item.get(
                        "shadow_trial_permission"
                    )
                ).upper()
                == "SHADOW_CANARY_ONLY"
                and 0.01
                <= _float(
                    item.get(
                        "permit_scope_pct"
                    )
                )
                <= min(
                    0.10,
                    _float(
                        item.get(
                            "design_max_scope_pct"
                        )
                    ),
                )
                and 1
                <= _int(
                    item.get(
                        "permit_session_budget"
                    )
                )
                <= _int(
                    item.get(
                        "design_session_cap"
                    )
                )
            ):
                contract_violations += 1
        else:
            if (
                _text(
                    item.get(
                        "shadow_trial_permission"
                    )
                ).upper()
                not in {"", "NONE"}
            ):
                contract_violations += 1

        source_id = _text(
            item.get(
                "source_trial_design_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_trial_design_hash"
            )
        )

        parent = design_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                controlled_trial_design_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get(
                    "snapshot_hash"
                )
            )
            != source_hash
            or _text(
                parent.get(
                    "design_state"
                )
            ).upper()
            != "TRIAL_DESIGN_LOCKED"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )
            start_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(start_ts)
                or start_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Controlled Trial Start Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Start immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Start Audit Decision / Kill-Switch Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "Start decision / permit bound / kill-switch / rollback confirmations 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Start Audit → Design Lineage",
            (
                lineage_violations == 0
                and design_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"design duplicate ids {design_duplicates}"
            ),
            "Start source Trial Design id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Start Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate start ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Start audit identity uniqueness 및 Design audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Start Audit No-Live-Execution Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Trial Start/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("start") or {}).get(
            "start_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "TRIAL_START_NOT_REQUIRED",
            "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY",
            "TRIAL_START_REJECTED",
            "TRIAL_START_DEFERRED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Start Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current start {current_state or 'MISSING'} · "
                f"saved starts {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 TRIAL_DESIGN_LOCKED source가 생긴 뒤 "
                    "kill-switch/rollback readiness Human Review가 필요할 때만 Start audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_START_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v142_release_readiness(
    *,
    v141_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    trial_start_release_gate: str,
    trial_start_audit_gate: str,
    trial_start_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.41 Controlled Trial Design Release Baseline",
            _text(
                v141_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v141_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Start Technical Release Gate",
            _text(
                trial_start_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_start_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Start Audit Integrity Gate",
            _text(
                trial_start_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_start_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            trial_start_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "CONTROLLED_TRIAL_START_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V142_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v142_integration_crosscheck(
    *,
    integration_consistency: str,
    trial_start_release_gate: str,
    trial_start_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Start Technical Gate",
            _text(
                trial_start_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_start_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Start Audit Gate",
            _text(
                trial_start_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_start_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V142_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v142_data_crosscheck(
    *,
    csv_fail_count: int,
    trial_start_release_gate: str,
    trial_start_audit_gate: str,
    latest_trial_start_integrity: str,
) -> dict:
    latest = _text(
        latest_trial_start_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(
                csv_fail_count
            )
            == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Start Technical Gate",
            _text(
                trial_start_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_start_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Start Audit Gate",
            _text(
                trial_start_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_start_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Controlled Trial Start Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V142_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
