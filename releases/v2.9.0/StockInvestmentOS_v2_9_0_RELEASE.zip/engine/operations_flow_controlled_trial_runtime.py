from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_controlled_trial_start import (
    controlled_trial_start_snapshot_integrity,
)


FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS = [
    "controlled_trial_runtime_event_id",
    "runtime_session_id",
    "created_at",
    "event_type",
    "runtime_state",
    "runtime_guard",
    "source_trial_start_id",
    "source_trial_start_hash",
    "source_trial_start_created_at",
    "source_trial_start_integrity",
    "source_trial_design_id",
    "source_trial_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "trial_mode",
    "permit_scope_pct",
    "permit_session_budget",
    "permit_min_trial_outcomes",
    "permit_max_relative_error_degradation_pct",
    "session_index",
    "sessions_used",
    "sessions_remaining",
    "kill_switch_trigger",
    "kill_switch_latched",
    "rollback_required",
    "runtime_detail",
    "permit_source_reviewed",
    "shadow_isolation_confirmed",
    "kill_switch_path_confirmed",
    "rollback_path_confirmed",
    "no_live_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "shadow_trial_permission",
    "trial_runtime_authorization",
    "trial_start_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


CONTROLLED_TRIAL_RUNTIME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


CONTROLLED_TRIAL_RUNTIME_STATES = {
    "TRIAL_RUNTIME_UPSTREAM_WAIT",
    "TRIAL_RUNTIME_NOT_REQUIRED",
    "TRIAL_RUNTIME_DEFERRED",
    "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
    "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
    "TRIAL_RUNTIME_READY",
    "TRIAL_RUNTIME_ACTIVE",
    "TRIAL_RUNTIME_KILL_SWITCHED",
    "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
    "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
}


TRIAL_RUNTIME_GUARD_BY_STATE = {
    "TRIAL_RUNTIME_UPSTREAM_WAIT": "HOLD_SHADOW_TRIAL_PERMIT",
    "TRIAL_RUNTIME_NOT_REQUIRED": "NO_SHADOW_TRIAL_RUNTIME",
    "TRIAL_RUNTIME_DEFERRED": "HOLD_SHADOW_TRIAL_RUNTIME",
    "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED": "HOLD_TRIAL_PERMIT_SOURCE",
    "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW": "HOLD_TRIAL_RUNTIME_INTEGRITY",
    "TRIAL_RUNTIME_READY": "SHADOW_RUNTIME_READY_NO_EXECUTION",
    "TRIAL_RUNTIME_ACTIVE": "SHADOW_RUNTIME_ACTIVE_NO_EXECUTION",
    "TRIAL_RUNTIME_KILL_SWITCHED": "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
    "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED": "SHADOW_RUNTIME_BUDGET_EXHAUSTED",
    "TRIAL_RUNTIME_SOURCE_SUPERSEDED": "HOLD_TRIAL_RUNTIME_SOURCE",
}


TRIAL_RUNTIME_EVENT_TYPES = {
    "OPEN",
    "CLOSE",
    "KILL_SWITCH",
}


KILL_SWITCH_TRIGGERS = {
    "ERROR_DEGRADATION",
    "ASSUMPTION_DRIFT",
    "INTEGRITY_FAILURE",
    "SOURCE_SUPERSESSION",
    "MANUAL_RISK_STOP",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _runtime_payload(row: dict) -> dict:
    int_fields = {
        "permit_session_budget",
        "permit_min_trial_outcomes",
        "session_index",
        "sessions_used",
        "sessions_remaining",
    }

    float_fields = {
        "permit_scope_pct",
        "permit_max_relative_error_degradation_pct",
    }

    bool_fields = {
        "kill_switch_latched",
        "rollback_required",
        "permit_source_reviewed",
        "shadow_isolation_confirmed",
        "kill_switch_path_confirmed",
        "rollback_path_confirmed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
        if col in {
            "controlled_trial_runtime_event_id",
            "runtime_session_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def controlled_trial_runtime_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get(
            "snapshot_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _runtime_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_controlled_trial_runtime_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _permit_source(
    start: dict | None,
) -> dict:
    row = start or {}

    if _text(
        row.get(
            "start_state"
        )
    ).upper() != "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY":
        return {}

    latest = row.get(
        "latest_start"
    ) or {}

    if not latest:
        return {}

    if _text(
        controlled_trial_start_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get(
            "shadow_trial_permission"
        )
    ).upper() != "SHADOW_CANARY_ONLY":
        return {}

    return latest


def _runtime_matches_permit(
    event: dict | None,
    permit_source: dict | None,
) -> bool:
    row = event or {}
    permit = permit_source or {}

    if not row or not permit:
        return False

    if _text(
        controlled_trial_runtime_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            row.get(
                "source_trial_start_id"
            )
        )
        == _text(
            permit.get(
                "controlled_trial_start_id"
            )
        )
        and _text(
            row.get(
                "source_trial_start_hash"
            )
        )
        == _text(
            permit.get(
                "snapshot_hash"
            )
        )
    )


def _normalized_runtime_history(
    snapshots: pd.DataFrame | None,
) -> pd.DataFrame:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    for col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return df[
            FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS
        ].copy()

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    return df.sort_values(
        "_ts"
    ).reset_index(
        drop=True
    )


def build_flow_controlled_trial_runtime(
    controlled_trial_start: dict | None,
    runtime_snapshots: pd.DataFrame | None,
) -> dict:
    start = controlled_trial_start or {}
    start_state = _text(
        start.get(
            "start_state"
        )
    ).upper()

    base = {
        "source_trial_start_id": "",
        "source_trial_start_hash": "",
        "source_trial_start_created_at": "",
        "source_trial_start_integrity": "NONE",
        "source_trial_design_id": _text(
            start.get(
                "source_trial_design_id"
            )
        ),
        "source_trial_design_hash": _text(
            start.get(
                "source_trial_design_hash"
            )
        ),
        "source_proposal_id": _text(
            start.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            start.get(
                "source_proposal_hash"
            )
        ),
        "proposal_scope": _text(
            start.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            start.get(
                "target_metric"
            )
        ).upper(),
        "trial_mode": _text(
            start.get(
                "trial_mode"
            )
        ).upper() or "SHADOW_CANARY_ONLY",
        "permit_scope_pct": _float(
            start.get(
                "permit_scope_pct"
            )
        ),
        "permit_session_budget": _int(
            start.get(
                "permit_session_budget"
            )
        ),
        "permit_min_trial_outcomes": _int(
            start.get(
                "permit_min_trial_outcomes"
            )
        ),
        "permit_max_relative_error_degradation_pct": _float(
            start.get(
                "permit_max_relative_error_degradation_pct"
            )
        ),
        "sessions_used": 0,
        "sessions_remaining": 0,
        "active_session_id": "",
        "session_index": 0,
        "kill_switch_latched": False,
        "kill_switch_trigger": "",
        "rollback_required": False,
        "latest_event": {},
        "shadow_trial_permission": "NONE",
        "trial_runtime_authorization": "NONE",
        "trial_start_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if start_state in {
        "",
        "TRIAL_START_UPSTREAM_WAIT",
        "TRIAL_START_DESIGN_SOURCE_REQUIRED",
        "TRIAL_START_SOURCE_INTEGRITY_REVIEW",
        "TRIAL_START_REVIEW_REQUIRED",
        "TRIAL_START_SOURCE_SUPERSEDED",
    }:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_UPSTREAM_WAIT",
            "runtime_guard": "HOLD_SHADOW_TRIAL_PERMIT",
        }

    if start_state in {
        "TRIAL_START_NOT_REQUIRED",
        "TRIAL_START_REJECTED",
    }:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_NOT_REQUIRED",
            "runtime_guard": "NO_SHADOW_TRIAL_RUNTIME",
        }

    if start_state == "TRIAL_START_DEFERRED":
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_DEFERRED",
            "runtime_guard": "HOLD_SHADOW_TRIAL_RUNTIME",
        }

    permit = _permit_source(
        start
    )

    if not permit:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
            "runtime_guard": "HOLD_TRIAL_PERMIT_SOURCE",
        }

    permit_integrity = _text(
        controlled_trial_start_snapshot_integrity(
            permit
        ).get("status")
    ).upper()

    budget = max(
        1,
        _int(
            permit.get(
                "permit_session_budget"
            )
        ),
    )

    base.update(
        {
            "source_trial_start_id":
                _text(
                    permit.get(
                        "controlled_trial_start_id"
                    )
                ),
            "source_trial_start_hash":
                _text(
                    permit.get(
                        "snapshot_hash"
                    )
                ),
            "source_trial_start_created_at":
                _text(
                    permit.get(
                        "created_at"
                    )
                ),
            "source_trial_start_integrity":
                permit_integrity,
            "source_trial_design_id":
                _text(
                    permit.get(
                        "source_trial_design_id"
                    )
                ),
            "source_trial_design_hash":
                _text(
                    permit.get(
                        "source_trial_design_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    permit.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    permit.get(
                        "source_proposal_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    permit.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    permit.get(
                        "target_metric"
                    )
                ).upper(),
            "trial_mode":
                _text(
                    permit.get(
                        "trial_mode"
                    )
                ).upper(),
            "permit_scope_pct":
                _float(
                    permit.get(
                        "permit_scope_pct"
                    )
                ),
            "permit_session_budget":
                budget,
            "permit_min_trial_outcomes":
                _int(
                    permit.get(
                        "permit_min_trial_outcomes"
                    )
                ),
            "permit_max_relative_error_degradation_pct":
                _float(
                    permit.get(
                        "permit_max_relative_error_degradation_pct"
                    )
                ),
            "sessions_remaining":
                budget,
            "shadow_trial_permission":
                "SHADOW_CANARY_ONLY",
        }
    )

    if permit_integrity != "OK":
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard": "HOLD_TRIAL_RUNTIME_INTEGRITY",
        }

    history = _normalized_runtime_history(
        runtime_snapshots
    )

    if history.empty:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_READY",
            "runtime_guard": "SHADOW_RUNTIME_READY_NO_EXECUTION",
        }

    mismatch_count = 0
    source_rows = []

    for _, row in history.iterrows():
        item = row.to_dict()

        if _text(
            controlled_trial_runtime_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            mismatch_count += 1
            continue

        if _runtime_matches_permit(
            item,
            permit,
        ):
            source_rows.append(
                item
            )

    if mismatch_count > 0:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard": "HOLD_TRIAL_RUNTIME_INTEGRITY",
        }

    latest_global = latest_controlled_trial_runtime_snapshot(
        history
    )

    if (
        latest_global
        and not _runtime_matches_permit(
            latest_global,
            permit,
        )
    ):
        return {
            **base,
            "latest_event":
                latest_global,
            "runtime_state": "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
            "runtime_guard": "HOLD_TRIAL_RUNTIME_SOURCE",
        }

    if not source_rows:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_READY",
            "runtime_guard": "SHADOW_RUNTIME_READY_NO_EXECUTION",
        }

    source_rows = sorted(
        source_rows,
        key=lambda item: pd.to_datetime(
            item.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        ),
    )

    latest = source_rows[-1]

    opened_sessions = []
    session_latest = {}

    for item in source_rows:
        session_id = _text(
            item.get(
                "runtime_session_id"
            )
        )
        event_type = _text(
            item.get(
                "event_type"
            )
        ).upper()

        if session_id:
            session_latest[
                session_id
            ] = item

        if (
            event_type == "OPEN"
            and session_id
            and session_id not in opened_sessions
        ):
            opened_sessions.append(
                session_id
            )

    sessions_used = len(
        opened_sessions
    )
    sessions_remaining = max(
        0,
        budget - sessions_used,
    )

    latest_event_type = _text(
        latest.get(
            "event_type"
        )
    ).upper()

    base.update(
        {
            "sessions_used":
                sessions_used,
            "sessions_remaining":
                sessions_remaining,
            "session_index":
                _int(
                    latest.get(
                        "session_index"
                    )
                ),
            "latest_event":
                latest,
            "kill_switch_latched":
                _bool(
                    latest.get(
                        "kill_switch_latched"
                    )
                ),
            "kill_switch_trigger":
                _text(
                    latest.get(
                        "kill_switch_trigger"
                    )
                ).upper(),
            "rollback_required":
                _bool(
                    latest.get(
                        "rollback_required"
                    )
                ),
        }
    )

    if latest_event_type == "KILL_SWITCH":
        return {
            **base,
            "active_session_id":
                _text(
                    latest.get(
                        "runtime_session_id"
                    )
                ),
            "runtime_state": "TRIAL_RUNTIME_KILL_SWITCHED",
            "runtime_guard": "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
        }

    if latest_event_type == "OPEN":
        return {
            **base,
            "active_session_id":
                _text(
                    latest.get(
                        "runtime_session_id"
                    )
                ),
            "runtime_state": "TRIAL_RUNTIME_ACTIVE",
            "runtime_guard": "SHADOW_RUNTIME_ACTIVE_NO_EXECUTION",
        }

    if sessions_used >= budget:
        return {
            **base,
            "runtime_state": "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            "runtime_guard": "SHADOW_RUNTIME_BUDGET_EXHAUSTED",
        }

    return {
        **base,
        "runtime_state": "TRIAL_RUNTIME_READY",
        "runtime_guard": "SHADOW_RUNTIME_READY_NO_EXECUTION",
    }


def _base_event(
    runtime: dict,
    *,
    runtime_session_id: str,
    event_type: str,
    runtime_state: str,
    runtime_guard: str,
    session_index: int,
    sessions_used: int,
    sessions_remaining: int,
    kill_switch_trigger: str,
    kill_switch_latched: bool,
    rollback_required: bool,
    runtime_detail: str,
    permit_source_reviewed: bool,
    shadow_isolation_confirmed: bool,
    kill_switch_path_confirmed: bool,
    rollback_path_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str,
    created_at: str,
) -> dict:
    base = {
        "event_type":
            event_type,
        "runtime_state":
            runtime_state,
        "runtime_guard":
            runtime_guard,
        "source_trial_start_id":
            _text(
                runtime.get(
                    "source_trial_start_id"
                )
            ),
        "source_trial_start_hash":
            _text(
                runtime.get(
                    "source_trial_start_hash"
                )
            ),
        "source_trial_start_created_at":
            _text(
                runtime.get(
                    "source_trial_start_created_at"
                )
            ),
        "source_trial_start_integrity":
            "OK",
        "source_trial_design_id":
            _text(
                runtime.get(
                    "source_trial_design_id"
                )
            ),
        "source_trial_design_hash":
            _text(
                runtime.get(
                    "source_trial_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                runtime.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                runtime.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            _text(
                runtime.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                runtime.get(
                    "target_metric"
                )
            ),
        "trial_mode":
            "SHADOW_CANARY_ONLY",
        "permit_scope_pct":
            _float(
                runtime.get(
                    "permit_scope_pct"
                )
            ),
        "permit_session_budget":
            _int(
                runtime.get(
                    "permit_session_budget"
                )
            ),
        "permit_min_trial_outcomes":
            _int(
                runtime.get(
                    "permit_min_trial_outcomes"
                )
            ),
        "permit_max_relative_error_degradation_pct":
            _float(
                runtime.get(
                    "permit_max_relative_error_degradation_pct"
                )
            ),
        "session_index":
            session_index,
        "sessions_used":
            sessions_used,
        "sessions_remaining":
            sessions_remaining,
        "kill_switch_trigger":
            _text(
                kill_switch_trigger
            ).upper(),
        "kill_switch_latched":
            bool(
                kill_switch_latched
            ),
        "rollback_required":
            bool(
                rollback_required
            ),
        "runtime_detail":
            _text(
                runtime_detail
            ),
        "permit_source_reviewed":
            bool(
                permit_source_reviewed
            ),
        "shadow_isolation_confirmed":
            bool(
                shadow_isolation_confirmed
            ),
        "kill_switch_path_confirmed":
            bool(
                kill_switch_path_confirmed
            ),
        "rollback_path_confirmed":
            bool(
                rollback_path_confirmed
            ),
        "no_live_apply_confirmed":
            bool(
                no_live_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "shadow_trial_permission":
            "SHADOW_CANARY_ONLY",
        "trial_runtime_authorization":
            "NONE",
        "trial_start_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _runtime_payload(
            base
        )
    )

    return {
        "controlled_trial_runtime_event_id": (
            "OTR-"
            + pd.Timestamp(
                created_at
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "runtime_session_id":
            runtime_session_id,
        "created_at":
            created_at,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def _validate_common_confirmations(
    *,
    permit_source_reviewed: bool,
    shadow_isolation_confirmed: bool,
    kill_switch_path_confirmed: bool,
    rollback_path_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> None:
    confirmations = [
        permit_source_reviewed,
        shadow_isolation_confirmed,
        kill_switch_path_confirmed,
        rollback_path_confirmed,
        no_live_apply_confirmed,
        no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed,
        no_execution_authorization_confirmed,
        human_review_confirmed,
    ]

    if not all(
        bool(x)
        for x in confirmations
    ):
        raise ValueError(
            "Shadow Trial Runtime Human Review 확인사항을 모두 검토해야 합니다."
        )


def build_flow_controlled_trial_runtime_open(
    runtime: dict,
    *,
    runtime_detail: str,
    permit_source_reviewed: bool,
    shadow_isolation_confirmed: bool,
    kill_switch_path_confirmed: bool,
    rollback_path_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    if _text(
        current.get(
            "runtime_state"
        )
    ).upper() != "TRIAL_RUNTIME_READY":
        raise ValueError(
            "Shadow Trial Runtime Session은 TRIAL_RUNTIME_READY 상태에서만 열 수 있습니다."
        )

    if _text(
        current.get(
            "source_trial_start_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Shadow Trial Permit integrity가 OK가 아닙니다."
        )

    if _text(
        current.get(
            "shadow_trial_permission"
        )
    ).upper() != "SHADOW_CANARY_ONLY":
        raise ValueError(
            "SHADOW_CANARY_ONLY permission이 없습니다."
        )

    if _int(
        current.get(
            "sessions_remaining"
        )
    ) <= 0:
        raise ValueError(
            "Shadow Trial session budget이 남아 있지 않습니다."
        )

    detail = _text(
        runtime_detail
    )

    if len(
        detail
    ) < 30:
        raise ValueError(
            "Runtime open rationale을 30자 이상 기록하세요."
        )

    _validate_common_confirmations(
        permit_source_reviewed=permit_source_reviewed,
        shadow_isolation_confirmed=shadow_isolation_confirmed,
        kill_switch_path_confirmed=kill_switch_path_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        no_live_apply_confirmed=no_live_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
    )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    permit_created = pd.to_datetime(
        current.get(
            "source_trial_start_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    event_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            permit_created
        )
        or pd.isna(
            event_created
        )
        or event_created <= permit_created
    ):
        raise ValueError(
            "Runtime OPEN은 source Shadow Trial Permit 이후에 저장되어야 합니다."
        )

    session_index = _int(
        current.get(
            "sessions_used"
        )
    ) + 1
    budget = _int(
        current.get(
            "permit_session_budget"
        )
    )
    sessions_used = session_index
    sessions_remaining = max(
        0,
        budget - sessions_used,
    )

    session_seed = (
        _text(
            current.get(
                "source_trial_start_id"
            )
        )
        + "|"
        + now
        + "|"
        + str(
            session_index
        )
    )
    session_id = (
        "RTS-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            session_seed.encode(
                "utf-8"
            )
        ).hexdigest()[:8]
    )

    return _base_event(
        current,
        runtime_session_id=session_id,
        event_type="OPEN",
        runtime_state="TRIAL_RUNTIME_ACTIVE",
        runtime_guard="SHADOW_RUNTIME_ACTIVE_NO_EXECUTION",
        session_index=session_index,
        sessions_used=sessions_used,
        sessions_remaining=sessions_remaining,
        kill_switch_trigger="",
        kill_switch_latched=False,
        rollback_required=False,
        runtime_detail=detail,
        permit_source_reviewed=permit_source_reviewed,
        shadow_isolation_confirmed=shadow_isolation_confirmed,
        kill_switch_path_confirmed=kill_switch_path_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        no_live_apply_confirmed=no_live_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
        note=note,
        created_at=now,
    )


def build_flow_controlled_trial_runtime_close(
    runtime: dict,
    *,
    runtime_detail: str,
    permit_source_reviewed: bool,
    shadow_isolation_confirmed: bool,
    kill_switch_path_confirmed: bool,
    rollback_path_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    if _text(
        current.get(
            "runtime_state"
        )
    ).upper() != "TRIAL_RUNTIME_ACTIVE":
        raise ValueError(
            "Shadow Trial Runtime CLOSE는 TRIAL_RUNTIME_ACTIVE 상태에서만 가능합니다."
        )

    detail = _text(
        runtime_detail
    )

    if len(
        detail
    ) < 30:
        raise ValueError(
            "Runtime close rationale을 30자 이상 기록하세요."
        )

    _validate_common_confirmations(
        permit_source_reviewed=permit_source_reviewed,
        shadow_isolation_confirmed=shadow_isolation_confirmed,
        kill_switch_path_confirmed=kill_switch_path_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        no_live_apply_confirmed=no_live_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
    )

    latest = current.get(
        "latest_event"
    ) or {}

    open_created = pd.to_datetime(
        latest.get(
            "created_at"
        ),
        errors="coerce",
        utc=True,
    )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    close_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            open_created
        )
        or pd.isna(
            close_created
        )
        or close_created <= open_created
    ):
        raise ValueError(
            "Runtime CLOSE는 OPEN event 이후에 저장되어야 합니다."
        )

    used = _int(
        current.get(
            "sessions_used"
        )
    )
    remaining = _int(
        current.get(
            "sessions_remaining"
        )
    )

    next_state = (
        "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED"
        if remaining <= 0
        else "TRIAL_RUNTIME_READY"
    )

    next_guard = TRIAL_RUNTIME_GUARD_BY_STATE[
        next_state
    ]

    return _base_event(
        current,
        runtime_session_id=_text(
            current.get(
                "active_session_id"
            )
        ),
        event_type="CLOSE",
        runtime_state=next_state,
        runtime_guard=next_guard,
        session_index=_int(
            current.get(
                "session_index"
            )
        ),
        sessions_used=used,
        sessions_remaining=remaining,
        kill_switch_trigger="",
        kill_switch_latched=False,
        rollback_required=False,
        runtime_detail=detail,
        permit_source_reviewed=permit_source_reviewed,
        shadow_isolation_confirmed=shadow_isolation_confirmed,
        kill_switch_path_confirmed=kill_switch_path_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        no_live_apply_confirmed=no_live_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
        note=note,
        created_at=now,
    )


def build_flow_controlled_trial_runtime_kill_switch(
    runtime: dict,
    *,
    kill_switch_trigger: str,
    runtime_detail: str,
    permit_source_reviewed: bool,
    shadow_isolation_confirmed: bool,
    kill_switch_path_confirmed: bool,
    rollback_path_confirmed: bool,
    no_live_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    if _text(
        current.get(
            "runtime_state"
        )
    ).upper() != "TRIAL_RUNTIME_ACTIVE":
        raise ValueError(
            "Kill Switch는 TRIAL_RUNTIME_ACTIVE 상태에서만 latch할 수 있습니다."
        )

    trigger = _text(
        kill_switch_trigger
    ).upper()

    if trigger not in KILL_SWITCH_TRIGGERS:
        raise ValueError(
            "Kill Switch trigger vocabulary가 유효하지 않습니다."
        )

    detail = _text(
        runtime_detail
    )

    if len(
        detail
    ) < 40:
        raise ValueError(
            "Kill Switch / rollback rationale을 40자 이상 기록하세요."
        )

    _validate_common_confirmations(
        permit_source_reviewed=permit_source_reviewed,
        shadow_isolation_confirmed=shadow_isolation_confirmed,
        kill_switch_path_confirmed=kill_switch_path_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        no_live_apply_confirmed=no_live_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
    )

    latest = current.get(
        "latest_event"
    ) or {}

    open_created = pd.to_datetime(
        latest.get(
            "created_at"
        ),
        errors="coerce",
        utc=True,
    )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    kill_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            open_created
        )
        or pd.isna(
            kill_created
        )
        or kill_created <= open_created
    ):
        raise ValueError(
            "Kill Switch event는 Runtime OPEN 이후에 저장되어야 합니다."
        )

    return _base_event(
        current,
        runtime_session_id=_text(
            current.get(
                "active_session_id"
            )
        ),
        event_type="KILL_SWITCH",
        runtime_state="TRIAL_RUNTIME_KILL_SWITCHED",
        runtime_guard="KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
        session_index=_int(
            current.get(
                "session_index"
            )
        ),
        sessions_used=_int(
            current.get(
                "sessions_used"
            )
        ),
        sessions_remaining=_int(
            current.get(
                "sessions_remaining"
            )
        ),
        kill_switch_trigger=trigger,
        kill_switch_latched=True,
        rollback_required=True,
        runtime_detail=detail,
        permit_source_reviewed=permit_source_reviewed,
        shadow_isolation_confirmed=shadow_isolation_confirmed,
        kill_switch_path_confirmed=kill_switch_path_confirmed,
        rollback_path_confirmed=rollback_path_confirmed,
        no_live_apply_confirmed=no_live_apply_confirmed,
        no_auto_recalibration_confirmed=no_auto_recalibration_confirmed,
        no_auto_capacity_confirmed=no_auto_capacity_confirmed,
        no_execution_authorization_confirmed=no_execution_authorization_confirmed,
        human_review_confirmed=human_review_confirmed,
        note=note,
        created_at=now,
    )


def build_flow_controlled_trial_runtime_queue(
    runtime: dict | None,
) -> pd.DataFrame:
    row = runtime or {}
    state = _text(
        row.get(
            "runtime_state"
        )
    ).upper()

    mapping = {
        "TRIAL_RUNTIME_UPSTREAM_WAIT": (
            "TR1",
            "WAIT",
            "TRIAL_RUNTIME_UPSTREAM_WAIT",
            "SHADOW_CANARY_ONLY Start Permit이 아직 없음",
            "Trial Design / Human Start evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "TRIAL_RUNTIME_NOT_REQUIRED": (
            "TR3",
            "MONITOR",
            "TRIAL_RUNTIME_NOT_REQUIRED",
            "현재 Start decision에서는 Shadow Runtime이 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "TRIAL_RUNTIME_DEFERRED": (
            "TR2",
            "WAIT",
            "TRIAL_RUNTIME_DEFERRED",
            "Human Trial Start decision = DEFER",
            "새 evidence/운영 조건 확인 후 재검토",
        ),
        "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED": (
            "TR0",
            "REVIEW",
            "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
            "Permit state는 있으나 immutable Start source를 확인할 수 없음",
            "Controlled Trial Start audit을 먼저 확인",
        ),
        "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW": (
            "TR0",
            "BLOCKED",
            "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "Permit 또는 Runtime event immutable hash mismatch",
            "Start / Runtime audit integrity를 먼저 복구",
        ),
        "TRIAL_RUNTIME_READY": (
            "TR1",
            "REVIEW",
            "TRIAL_RUNTIME_READY",
            (
                f"sessions used {row.get('sessions_used',0)}/"
                f"{row.get('permit_session_budget',0)} · "
                f"scope {float(row.get('permit_scope_pct',0)):.1%}"
            ),
            "Human Review 후 shadow-only Runtime Session OPEN",
        ),
        "TRIAL_RUNTIME_ACTIVE": (
            "TR0",
            "ACTIVE",
            "TRIAL_RUNTIME_ACTIVE",
            (
                f"session {row.get('session_index',0)} · "
                f"remaining {row.get('sessions_remaining',0)}"
            ),
            "Kill switch/rollback readiness를 유지하며 CLOSE 또는 KILL_SWITCH 결정",
        ),
        "TRIAL_RUNTIME_KILL_SWITCHED": (
            "TR0",
            "BLOCKED",
            "TRIAL_RUNTIME_KILL_SWITCHED",
            (
                f"trigger {row.get('kill_switch_trigger','')} · "
                "rollback required"
            ),
            "Runtime 재개 금지; rollback evidence와 post-mortem review 우선",
        ),
        "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED": (
            "TR3",
            "MONITOR",
            "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            (
                f"session budget {row.get('sessions_used',0)}/"
                f"{row.get('permit_session_budget',0)} consumed"
            ),
            "추가 Runtime OPEN 금지; 별도 Trial Outcome Review로 이동",
        ),
        "TRIAL_RUNTIME_SOURCE_SUPERSEDED": (
            "TR0",
            "REVIEW",
            "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
            "새 Start Permit으로 기존 Runtime source가 stale",
            "현재 Permit 기준으로 새 Runtime cycle 검토",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "TR0",
            "BLOCKED",
            "TRIAL_RUNTIME_UNKNOWN_STATE",
            state or "MISSING",
            "Controlled Trial Runtime state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            CONTROLLED_TRIAL_RUNTIME_QUEUE_COLS,
    )
