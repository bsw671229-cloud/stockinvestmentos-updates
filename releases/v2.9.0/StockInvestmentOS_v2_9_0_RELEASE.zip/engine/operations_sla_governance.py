from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any
import hashlib
import json

import pandas as pd


CAPACITY_OVERRIDE_COLS = [
    "override_id",
    "created_at",
    "effective_date",
    "expiry_date",
    "base_capacity",
    "requested_capacity",
    "incremental_capacity",
    "reason",
    "evidence",
    "max_duration_days",
    "sla_breach_groups",
    "persistent_groups",
    "chronic_groups",
    "deferred_groups",
    "human_review_confirmed",
    "no_auto_apply_confirmed",
    "no_execution_authorization_confirmed",
    "override_gate",
    "override_status",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


SLA_CLOSURE_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "sla_state",
    "sla_breach_groups",
    "persistent_groups",
    "chronic_groups",
    "selected_groups",
    "deferred_groups",
    "base_capacity",
    "effective_capacity",
    "active_override_id",
    "active_override_integrity",
    "override_expiry_date",
    "root_cause_top",
    "technical_gate",
    "technical_fail",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


SLA_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


SLA_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {"TRUE", "1", "YES", "Y", "PASS"}


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _parse_date(value: Any):
    raw = _text(value)
    if not raw:
        return None
    ts = pd.to_datetime(raw, errors="coerce")
    if pd.isna(ts):
        return None
    return ts.date()


def _override_payload(row: dict) -> dict:
    bool_fields = {
        "human_review_confirmed",
        "no_auto_apply_confirmed",
        "no_execution_authorization_confirmed",
    }

    payload = {}
    for col in CAPACITY_OVERRIDE_COLS:
        if col == "record_hash":
            continue
        if col in bool_fields:
            payload[col] = bool(_bool(row.get(col)))
        else:
            payload[col] = _text(row.get(col))
    return payload


def capacity_override_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(record.get("record_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_override_payload(record))
    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def validate_capacity_override(
    diagnostics: dict | None,
    rebalance: dict | None,
    *,
    base_capacity: int,
    requested_capacity: int,
    reason: str,
    evidence: str,
    duration_days: int,
    human_review_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
) -> dict:
    diag = diagnostics or {}
    reb = rebalance or {}
    issues = []

    base = max(1, _int(base_capacity))
    requested = max(1, _int(requested_capacity))
    duration = max(1, _int(duration_days))

    if requested <= base:
        issues.append("REQUESTED_CAPACITY_MUST_EXCEED_BASE")

    if requested > 10:
        issues.append("REQUESTED_CAPACITY_ABOVE_HARD_CAP_10")

    if duration > 14:
        issues.append("OVERRIDE_DURATION_ABOVE_14_DAYS")

    if (
        _int(diag.get("sla_breach_groups")) == 0
        and _int(diag.get("persistent_groups")) == 0
        and _int(diag.get("chronic_groups")) == 0
        and _int(reb.get("deferred_groups")) == 0
    ):
        issues.append("NO_OPERATING_PRESSURE_FOR_OVERRIDE")

    if not _text(reason):
        issues.append("OVERRIDE_REASON_REQUIRED")

    if not _text(evidence):
        issues.append("OVERRIDE_EVIDENCE_REQUIRED")

    if not _bool(human_review_confirmed):
        issues.append("HUMAN_REVIEW_CONFIRMATION_REQUIRED")

    if not _bool(no_auto_apply_confirmed):
        issues.append("NO_AUTO_APPLY_CONFIRMATION_REQUIRED")

    if not _bool(no_execution_authorization_confirmed):
        issues.append("NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED")

    gate = "PASS" if not issues else "REVIEW"

    return {
        "override_gate": gate,
        "override_status": (
            "APPROVED_FOR_OPERATING_USE"
            if gate == "PASS"
            else "DRAFT"
        ),
        "base_capacity": base,
        "requested_capacity": requested,
        "incremental_capacity": max(0, requested - base),
        "duration_days": duration,
        "execution_authorization": "NONE",
        "issues": list(dict.fromkeys(issues)),
    }


def build_capacity_override_record(
    diagnostics: dict,
    rebalance: dict,
    validation: dict,
    *,
    reason: str,
    evidence: str,
    human_review_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(created_at)
        or datetime.now().astimezone().isoformat()
    )
    effective = pd.Timestamp(now).date()
    duration = _int(validation.get("duration_days"))
    expiry = effective + timedelta(days=max(1, duration))

    seed = {
        "created_at": now,
        "base_capacity": validation.get("base_capacity"),
        "requested_capacity": validation.get("requested_capacity"),
        "reason": _text(reason),
    }

    override_id = (
        "OCO-"
        + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
        + "-"
        + _hash(seed)[:8]
    )

    row = {
        "override_id": override_id,
        "created_at": now,
        "effective_date": effective.isoformat(),
        "expiry_date": expiry.isoformat(),
        "base_capacity": _int(validation.get("base_capacity")),
        "requested_capacity": _int(validation.get("requested_capacity")),
        "incremental_capacity": _int(validation.get("incremental_capacity")),
        "reason": _text(reason),
        "evidence": _text(evidence),
        "max_duration_days": duration,
        "sla_breach_groups": _int(diagnostics.get("sla_breach_groups")),
        "persistent_groups": _int(diagnostics.get("persistent_groups")),
        "chronic_groups": _int(diagnostics.get("chronic_groups")),
        "deferred_groups": _int(rebalance.get("deferred_groups")),
        "human_review_confirmed": bool(human_review_confirmed),
        "no_auto_apply_confirmed": bool(no_auto_apply_confirmed),
        "no_execution_authorization_confirmed": bool(
            no_execution_authorization_confirmed
        ),
        "override_gate": _text(validation.get("override_gate")),
        "override_status": _text(validation.get("override_status")),
        "execution_authorization": "NONE",
        "issues": " | ".join(validation.get("issues", [])),
        "note": _text(note),
        "record_hash": "",
    }

    row["record_hash"] = _hash(_override_payload(row))
    return row


def latest_active_override(
    overrides: pd.DataFrame | None,
    *,
    today: date | str | None = None,
) -> dict:
    if overrides is None or overrides.empty:
        return {}

    df = overrides.copy()

    for col in CAPACITY_OVERRIDE_COLS:
        if col not in df.columns:
            df[col] = ""

    if today is None:
        today_date = date.today()
    elif isinstance(today, date):
        today_date = today
    else:
        parsed = pd.to_datetime(today, errors="coerce")
        today_date = parsed.date() if pd.notna(parsed) else date.today()

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    df = df.sort_values(
        "_ts",
        ascending=False,
        na_position="last",
    )

    for _, row in df.iterrows():
        record = row.drop(labels=["_ts"], errors="ignore").to_dict()

        if capacity_override_integrity(record)["status"] != "OK":
            continue

        if _text(record.get("override_status")).upper() != (
            "APPROVED_FOR_OPERATING_USE"
        ):
            continue

        effective = _parse_date(record.get("effective_date"))
        expiry = _parse_date(record.get("expiry_date"))

        if effective is None or expiry is None:
            continue

        if effective <= today_date <= expiry:
            return record

    return {}


def effective_capacity(
    base_capacity: int,
    active_override: dict | None,
) -> dict:
    base = max(1, _int(base_capacity))
    override = active_override or {}

    if not override:
        return {
            "effective_capacity": base,
            "override_status": "NONE",
            "override_id": "",
            "override_integrity": "NONE",
            "expiry_date": "",
        }

    integrity = capacity_override_integrity(override)["status"]

    if integrity != "OK":
        return {
            "effective_capacity": base,
            "override_status": "INTEGRITY_REVIEW",
            "override_id": _text(override.get("override_id")),
            "override_integrity": integrity,
            "expiry_date": _text(override.get("expiry_date")),
        }

    return {
        "effective_capacity": max(
            base,
            _int(override.get("requested_capacity")),
        ),
        "override_status": _text(override.get("override_status")).upper(),
        "override_id": _text(override.get("override_id")),
        "override_integrity": integrity,
        "expiry_date": _text(override.get("expiry_date")),
    }


def build_sla_closure_state(
    diagnostics: dict | None,
    rebalance: dict | None,
    effective_capacity_state: dict | None,
) -> dict:
    diag = diagnostics or {}
    reb = rebalance or {}
    cap = effective_capacity_state or {}

    sla_breach = _int(diag.get("sla_breach_groups"))
    persistent = _int(diag.get("persistent_groups"))
    chronic = _int(diag.get("chronic_groups"))
    deferred = _int(reb.get("deferred_groups"))
    effective_cap = _int(cap.get("effective_capacity"))

    if chronic > 0:
        state = "CHRONIC_REVIEW"
    elif sla_breach > 0:
        state = "SLA_REVIEW"
    elif persistent > 0:
        state = "PERSISTENT_REVIEW"
    elif deferred > 0:
        state = "CAPACITY_REVIEW"
    else:
        state = "CLEAR"

    return {
        "sla_state": state,
        "sla_breach_groups": sla_breach,
        "persistent_groups": persistent,
        "chronic_groups": chronic,
        "selected_groups": _int(reb.get("selected_groups")),
        "deferred_groups": deferred,
        "effective_capacity": effective_cap,
        "execution_authorization": "NONE",
    }


def build_sla_release_gate(
    diagnostics: dict | None,
    rebalance: dict | None,
    active_override: dict | None,
    effective_capacity_state: dict | None,
) -> dict:
    diag = diagnostics or {}
    reb = rebalance or {}
    override = active_override or {}
    cap = effective_capacity_state or {}

    checks = []

    def technical(check, passed, detail, action):
        checks.append(
            {
                "layer": "TECHNICAL",
                "check": check,
                "status": "PASS" if passed else "FAIL",
                "detail": detail,
                "action": "" if passed else action,
            }
        )

    technical(
        "Recurrence Diagnostics Availability",
        isinstance(diag.get("table"), pd.DataFrame),
        (
            f"groups {_int(diag.get('recurring_groups'))} recurring · "
            f"persistent {_int(diag.get('persistent_groups'))} · "
            f"chronic {_int(diag.get('chronic_groups'))}"
        ),
        "Carry-forward recurrence diagnostics를 다시 계산",
    )

    technical(
        "Capacity Rebalance Plan Availability",
        isinstance(reb.get("worklist"), pd.DataFrame),
        (
            f"selected {_int(reb.get('selected_groups'))} · "
            f"deferred {_int(reb.get('deferred_groups'))} · "
            f"base capacity {_int(reb.get('session_capacity'))}"
        ),
        "Capacity Rebalance Plan을 다시 계산",
    )

    override_integrity = (
        capacity_override_integrity(override)["status"]
        if override
        else "NONE"
    )
    technical(
        "Capacity Override Integrity",
        override_integrity in {"OK", "NONE"},
        override_integrity,
        "Capacity Override immutable hash 확인",
    )

    technical(
        "Capacity Override Hard Cap",
        _int(cap.get("effective_capacity")) <= 10,
        f"effective capacity {_int(cap.get('effective_capacity'))}",
        "Session Capacity hard cap 10 이하로 복구",
    )

    technical(
        "Operations Execution Authorization Invariant",
        True,
        "NONE",
        "",
    )

    technical_fail = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL" and row["status"] == "FAIL"
    )

    release_gate = "PASS" if technical_fail == 0 else "BLOCKED"

    state = build_sla_closure_state(
        diag,
        reb,
        cap,
    )

    operating_status = (
        "PASS"
        if state["sla_state"] == "CLEAR"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Operating SLA / Recurrence Closure",
            "status": operating_status,
            "detail": (
                f"{state['sla_state']} · "
                f"SLA breach {state['sla_breach_groups']} · "
                f"persistent {state['persistent_groups']} · "
                f"chronic {state['chronic_groups']} · "
                f"deferred {state['deferred_groups']}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else "원본 Review 사유를 해소하거나 다음 Session으로 명시적 Carry-forward"
            ),
        }
    )

    return {
        "release_gate": release_gate,
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL" and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "sla_state": state["sla_state"],
        "checks": pd.DataFrame(
            checks,
            columns=SLA_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_sla_queue(
    sla_gate: dict | None,
    active_override: dict | None,
) -> pd.DataFrame:
    gate = sla_gate or {}
    override = active_override or {}
    rows = []

    if _text(gate.get("release_gate")).upper() != "PASS":
        rows.append(
            {
                "priority": "SG0",
                "status": "BLOCKED",
                "issue": "OPERATING_SLA_TECHNICAL_GATE_BLOCKED",
                "next_action": "Override / Rebalance / Diagnostics integrity를 먼저 확인",
                "go_to": "Operations Control Tower",
            }
        )

    state = _text(gate.get("sla_state")).upper()

    if state == "CHRONIC_REVIEW":
        rows.append(
            {
                "priority": "SG1",
                "status": "REVIEW",
                "issue": "CHRONIC_CARRY_FORWARD_REVIEW",
                "next_action": "반복 Root Cause와 원본 Review 사유를 우선 해소",
                "go_to": "Review Queue",
            }
        )
    elif state == "SLA_REVIEW":
        rows.append(
            {
                "priority": "SG1",
                "status": "REVIEW",
                "issue": "OPERATING_SLA_REVIEW",
                "next_action": "SLA breach group을 이번 Session 최상단에서 검토",
                "go_to": "Review Queue",
            }
        )
    elif state in {"PERSISTENT_REVIEW", "CAPACITY_REVIEW"}:
        rows.append(
            {
                "priority": "SG2",
                "status": "REVIEW",
                "issue": state,
                "next_action": "Capacity 5 기준 Worklist 우선순위와 Carry-forward를 검토",
                "go_to": "Operations Control Tower",
            }
        )

    if override:
        rows.append(
            {
                "priority": "SG2",
                "status": "REVIEW",
                "issue": "ACTIVE_CAPACITY_OVERRIDE",
                "next_action": (
                    f"Override {_text(override.get('override_id'))} · "
                    f"expiry {_text(override.get('expiry_date'))} 재검토"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        return pd.DataFrame(columns=SLA_QUEUE_COLS)

    order = {"SG0": 0, "SG1": 1, "SG2": 2}
    out = pd.DataFrame(rows)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(["_p", "issue"])
        .drop(columns=["_p"])[SLA_QUEUE_COLS]
        .reset_index(drop=True)
    )


def build_sla_closure_snapshot(
    diagnostics: dict,
    rebalance: dict,
    sla_gate: dict,
    active_override: dict,
    effective_capacity_state: dict,
    *,
    base_capacity: int,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(created_at)
        or datetime.now().astimezone().isoformat()
    )

    payload = {
        "sla_state": _text(sla_gate.get("sla_state")),
        "sla_breach_groups": _int(diagnostics.get("sla_breach_groups")),
        "persistent_groups": _int(diagnostics.get("persistent_groups")),
        "chronic_groups": _int(diagnostics.get("chronic_groups")),
        "selected_groups": _int(rebalance.get("selected_groups")),
        "deferred_groups": _int(rebalance.get("deferred_groups")),
        "base_capacity": max(1, _int(base_capacity)),
        "effective_capacity": _int(
            effective_capacity_state.get("effective_capacity")
        ),
        "active_override_id": _text(active_override.get("override_id")),
        "active_override_integrity": (
            capacity_override_integrity(active_override)["status"]
            if active_override
            else "NONE"
        ),
        "override_expiry_date": _text(active_override.get("expiry_date")),
        "root_cause_top": _text(diagnostics.get("top_root_cause")),
        "technical_gate": _text(sla_gate.get("release_gate")),
        "technical_fail": _int(sla_gate.get("technical_fail")),
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(payload)

    return {
        "snapshot_id": (
            "OSL-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **payload,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }
