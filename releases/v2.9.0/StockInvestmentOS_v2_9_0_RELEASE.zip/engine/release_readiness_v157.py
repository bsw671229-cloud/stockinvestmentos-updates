from __future__ import annotations

from pathlib import Path
from typing import Any
import json

from updater.safe_update_orchestrator import (
    safe_update_orchestrator_status,
)


V156_RELEASE_ZIP_SHA256 = (
    "cc12527b14ee0f7dd31c49dcad6bdab309006f4d37a361536d1463d18b9609ab"
)
V156_RELEASE_MANIFEST_FILE_SHA256 = (
    "c72e55821102451eed34d76d9422d66c4dd56576a8d9970c2fa5cc00f3b2b0d4"
)
V156_RELEASE_NOTES_FILE_SHA256 = (
    "f6017b452a886916b47e384304f45cfa6fc648c896f189af31c983693c3513e8"
)
V156_BASELINE_PROVENANCE_REL = "release_baselines/v1_56_0.json"


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def verify_v156_release_baseline_provenance(
    code_root: str | Path,
) -> dict[str, Any]:
    root = Path(code_root).resolve()
    path = root / V156_BASELINE_PROVENANCE_REL

    try:
        record = json.loads(
            path.read_text(encoding="utf-8")
        )
    except Exception as exc:
        return {
            "status": "BLOCKED",
            "verified": False,
            "record_path": str(path),
            "record_detail": f"{type(exc).__name__}: {exc}",
        }

    ok = (
        _text(record.get("release_version")) == "v1.56.0"
        and _text(record.get("release_zip_sha256")).lower()
        == V156_RELEASE_ZIP_SHA256
        and _text(record.get("manifest_file_sha256")).lower()
        == V156_RELEASE_MANIFEST_FILE_SHA256
        and _text(record.get("release_notes_file_sha256")).lower()
        == V156_RELEASE_NOTES_FILE_SHA256
        and _text(record.get("provenance_status")).upper()
        == "VERIFIED_RELEASE_BASELINE"
    )

    return {
        "status": "VERIFIED" if ok else "BLOCKED",
        "verified": ok,
        "record_path": str(path),
        "record_detail": (
            "exact provenance record"
            if ok
            else "provenance record fields mismatch"
        ),
        "release_version": "v1.56.0",
    }


def build_v157_orchestrator_context(
    code_root: str | Path,
) -> dict[str, Any]:
    root = Path(code_root).resolve()
    return {
        "root": str(root),
        "orchestrator": safe_update_orchestrator_status(root),
        "execution_authorization": "NONE",
    }


def build_v157_orchestrator_technical_gate(
    context: dict[str, Any],
) -> dict[str, Any]:
    status = context.get("orchestrator") or {}

    rows = [
        {
            "check": "Managed Code Clean",
            "status": "PASS" if status.get("managed_code_clean") else "FAIL",
            "detail": str(status.get("managed_code_clean")),
        },
        {
            "check": "Deployment Connector",
            "status": "PASS" if status.get("deployment_status") == "CONNECTED" else "REVIEW",
            "detail": str(status.get("deployment_status")),
        },
        {
            "check": "Auto Approval Boundary",
            "status": "PASS" if status.get("auto_approval") is False else "FAIL",
            "detail": str(status.get("auto_approval")),
        },
        {
            "check": "Auto Apply Boundary",
            "status": "PASS" if status.get("auto_apply") is False else "FAIL",
            "detail": str(status.get("auto_apply")),
        },
        {
            "check": "Execution Authorization Boundary",
            "status": "PASS" if status.get("execution_authorization") == "NONE" else "FAIL",
            "detail": str(status.get("execution_authorization")),
        },
    ]

    fail = sum(1 for row in rows if row["status"] == "FAIL")
    review = sum(1 for row in rows if row["status"] == "REVIEW")
    passed = sum(1 for row in rows if row["status"] == "PASS")

    return {
        "release_gate": "PASS" if fail == 0 else "BLOCKED",
        "technical_pass": passed,
        "technical_review": review,
        "technical_fail": fail,
        "checks": rows,
        "execution_authorization": "NONE",
    }


def build_v157_release_readiness(
    *,
    baseline_provenance: dict[str, Any],
    orchestrator_gate: dict[str, Any],
) -> dict[str, Any]:
    blockers = []

    if baseline_provenance.get("status") != "VERIFIED":
        blockers.append("v1.56.0 immutable release baseline not verified.")

    if orchestrator_gate.get("release_gate") != "PASS":
        blockers.append("Safe Update Orchestrator technical gate is blocked.")

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "operating_review_count": int(
            orchestrator_gate.get("technical_review", 0)
        ),
        "blockers": blockers,
        "execution_authorization": "NONE",
    }
