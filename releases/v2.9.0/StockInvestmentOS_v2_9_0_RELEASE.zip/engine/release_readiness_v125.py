from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from engine.schema_evolution_guard import (
    inspect_csv_schemas,
    schema_scan_summary,
    latest_schema_baseline,
    schema_baseline_integrity,
    compare_schema_to_baseline,
)
from engine.schema_migration_contract import (
    build_schema_compatibility_matrix,
    latest_schema_contract,
    schema_contract_integrity,
    assess_schema_contract,
    schema_migration_proposal_integrity,
)
from engine.schema_migration_proof import (
    build_schema_contract_drift,
    build_compatibility_closure,
    migration_proof_integrity,
)
from engine.schema_refresh_closure import (
    build_schema_refresh_closure,
    schema_refresh_approval_integrity,
)


SCHEMA_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


V125_RELEASE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _ensure_df(df: pd.DataFrame | None) -> pd.DataFrame:
    return pd.DataFrame() if df is None else df.copy()


def _latest_integrity(
    row: dict | None,
    fn,
) -> str:
    if not row:
        return "MISSING"
    return _text(
        fn(row).get("status")
    ).upper()


def _record_integrity_counts(
    df: pd.DataFrame,
    fn,
) -> dict:
    total = 0
    ok = 0
    mismatch = 0
    missing = 0

    if not df.empty:
        for _, row in df.iterrows():
            total += 1
            status = _text(
                fn(row.to_dict()).get("status")
            ).upper()

            if status == "OK":
                ok += 1
            elif status == "MISSING":
                missing += 1
            else:
                mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "mismatch": mismatch,
        "missing": missing,
    }


def _authorization_violations(
    frames: list[pd.DataFrame],
) -> int:
    violations = 0

    for df in frames:
        if df.empty or "migration_authorization" not in df.columns:
            continue

        auth = (
            df["migration_authorization"]
            .fillna("")
            .astype(str)
            .str.strip()
            .str.upper()
        )

        violations += int(
            auth.ne("NONE").sum()
        )

    return violations


def build_schema_governance_context(
    *,
    data_dir: str | Path,
    baselines: pd.DataFrame | None,
    contracts: pd.DataFrame | None,
    proposals: pd.DataFrame | None,
    proofs: pd.DataFrame | None,
    approvals: pd.DataFrame | None,
) -> dict:
    baseline_df = _ensure_df(baselines)
    contract_df = _ensure_df(contracts)
    proposal_df = _ensure_df(proposals)
    proof_df = _ensure_df(proofs)
    approval_df = _ensure_df(approvals)

    scan = inspect_csv_schemas(
        data_dir
    )
    scan_summary = schema_scan_summary(
        scan
    )

    baseline = latest_schema_baseline(
        baseline_df
    )
    baseline_integrity = _latest_integrity(
        baseline,
        schema_baseline_integrity,
    )

    comparison = compare_schema_to_baseline(
        scan,
        baseline,
    )

    compatibility = build_schema_compatibility_matrix(
        comparison
    )

    contract = latest_schema_contract(
        contract_df
    )
    contract_integrity = _latest_integrity(
        contract,
        schema_contract_integrity,
    )
    contract_assessment = assess_schema_contract(
        contract,
        baseline,
        comparison,
    )

    contract_drift = build_schema_contract_drift(
        contract,
        baseline,
        comparison,
        compatibility,
    )

    compatibility_closure = build_compatibility_closure(
        comparison,
        contract_drift,
        proposal_df,
        proof_df,
        scan,
    )

    refresh_closure = build_schema_refresh_closure(
        scan,
        compatibility_closure,
        approval_df,
        baseline_df,
        contract_df,
    )

    proposal_integrity = _record_integrity_counts(
        proposal_df,
        schema_migration_proposal_integrity,
    )
    proof_integrity = _record_integrity_counts(
        proof_df,
        migration_proof_integrity,
    )
    approval_integrity = _record_integrity_counts(
        approval_df,
        schema_refresh_approval_integrity,
    )

    lineage_integrity_failures = (
        proposal_integrity["mismatch"]
        + proposal_integrity["missing"]
        + proof_integrity["mismatch"]
        + proof_integrity["missing"]
        + approval_integrity["mismatch"]
        + approval_integrity["missing"]
    )

    auth_violations = _authorization_violations(
        [
            baseline_df,
            contract_df,
            proposal_df,
            proof_df,
            approval_df,
        ]
    )

    return {
        "scan":
            scan,
        "scan_summary":
            scan_summary,
        "baseline":
            baseline,
        "baseline_integrity":
            baseline_integrity,
        "comparison":
            comparison,
        "compatibility":
            compatibility,
        "contract":
            contract,
        "contract_integrity":
            contract_integrity,
        "contract_assessment":
            contract_assessment,
        "contract_drift":
            contract_drift,
        "compatibility_closure":
            compatibility_closure,
        "refresh_closure":
            refresh_closure,
        "proposal_integrity":
            proposal_integrity,
        "proof_integrity":
            proof_integrity,
        "approval_integrity":
            approval_integrity,
        "lineage_integrity_failures":
            int(lineage_integrity_failures),
        "authorization_violations":
            int(auth_violations),
        "migration_authorization":
            "NONE",
    }


def build_schema_governance_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    scan_summary = ctx.get("scan_summary") or {}
    comparison = ctx.get("comparison") or {}
    compatibility = ctx.get("compatibility") or {}
    contract_assessment = ctx.get("contract_assessment") or {}
    contract_drift = ctx.get("contract_drift") or {}
    compatibility_closure = ctx.get("compatibility_closure") or {}
    refresh_closure = ctx.get("refresh_closure") or {}

    checks = []

    def technical(
        check: str,
        passed: bool,
        detail: str,
        action: str,
    ):
        checks.append(
            {
                "layer":
                    "TECHNICAL",
                "check":
                    check,
                "status":
                    "PASS" if passed else "FAIL",
                "detail":
                    detail,
                "action":
                    "" if passed else action,
            }
        )

    scan_status = _text(
        scan_summary.get("scan_integrity_status")
    ).upper()

    technical(
        "CSV Schema Scan Integrity",
        scan_status == "PASS",
        (
            f"{scan_status or 'MISSING'} · "
            f"parse fail {_int(scan_summary.get('parse_fail'))} · "
            f"duplicate schema files "
            f"{_int(scan_summary.get('duplicate_schema_files'))}"
        ),
        "Save Center 1I에서 CSV header/duplicate column 문제를 먼저 해결",
    )

    baseline_integrity = _text(
        ctx.get("baseline_integrity")
    ).upper()

    technical(
        "Schema Baseline Lock Integrity",
        baseline_integrity == "OK",
        baseline_integrity or "MISSING",
        "Save Center 1I에서 Schema Baseline Lock 존재/Hash 무결성 확인",
    )

    schema_status = _text(
        comparison.get("schema_status")
    ).upper()

    technical(
        "Current Schema vs Baseline",
        schema_status == "CURRENT",
        (
            f"{schema_status or 'MISSING'} · "
            f"changed {_int(comparison.get('changed_files'))} · "
            f"blocking {_int(comparison.get('blocking_changes'))}"
        ),
        "Schema drift를 Proposal/Proof/Refresh 절차로 닫거나 원본 Schema를 복구",
    )

    compatibility_status = _text(
        compatibility.get("compatibility_status")
    ).upper()

    technical(
        "Reader / Writer Compatibility Matrix",
        compatibility_status == "PASS",
        (
            f"{compatibility_status or 'MISSING'} · "
            f"review {_int(compatibility.get('review_files'))} · "
            f"blocked {_int(compatibility.get('blocked_files'))}"
        ),
        "Save Center 1J Compatibility Matrix에서 Reader/Writer 영향 검토",
    )

    contract_status = _text(
        contract_assessment.get("contract_status")
    ).upper()
    contract_integrity = _text(
        ctx.get("contract_integrity")
    ).upper()

    technical(
        "Reader-Writer Contract Lock",
        (
            contract_status == "CURRENT"
            and contract_integrity == "OK"
        ),
        (
            f"{contract_status or 'MISSING'} · "
            f"integrity {contract_integrity or 'MISSING'}"
        ),
        "Save Center 1J에서 현재 Baseline 기준 Reader-Writer Contract Lock 확인",
    )

    drift_status = _text(
        contract_drift.get("contract_drift_status")
    ).upper()

    technical(
        "Schema Contract Drift",
        drift_status == "CURRENT",
        drift_status or "MISSING",
        "Save Center 1K에서 Contract Drift / Migration Proof / Closure 확인",
    )

    lineage_failures = _int(
        ctx.get("lineage_integrity_failures")
    )

    proposal_counts = ctx.get("proposal_integrity") or {}
    proof_counts = ctx.get("proof_integrity") or {}
    approval_counts = ctx.get("approval_integrity") or {}

    technical(
        "Schema Migration Lineage Integrity",
        lineage_failures == 0,
        (
            f"failures {lineage_failures} · "
            f"proposal {proposal_counts.get('total',0)} · "
            f"proof {proof_counts.get('total',0)} · "
            f"refresh approval {approval_counts.get('total',0)}"
        ),
        "Proposal / Proof / Refresh Approval immutable hash 무결성 확인",
    )

    auth_violations = _int(
        ctx.get("authorization_violations")
    )

    technical(
        "Migration Authorization Invariant",
        auth_violations == 0,
        (
            "NONE"
            if auth_violations == 0
            else f"non-NONE records {auth_violations}"
        ),
        "Schema governance record의 Migration Authorization을 NONE으로 유지",
    )

    technical_fail = sum(
        1
        for row in checks
        if (
            row["layer"] == "TECHNICAL"
            and row["status"] == "FAIL"
        )
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    closure_status = _text(
        compatibility_closure.get("closure_status")
    ).upper()
    refresh_status = _text(
        refresh_closure.get("refresh_status")
    ).upper()

    operating_pass = (
        closure_status == "NO_CHANGE"
        and refresh_status == "NOT_REQUIRED"
    )

    checks.append(
        {
            "layer":
                "OPERATING",
            "check":
                "Schema Migration / Refresh Closure",
            "status":
                "PASS" if operating_pass else "REVIEW",
            "detail":
                (
                    f"compatibility closure "
                    f"{closure_status or 'MISSING'} · "
                    f"refresh {refresh_status or 'MISSING'}"
                ),
            "action":
                (
                    ""
                    if operating_pass
                    else "Save Center 1K/1L에서 Migration Proof / Refresh / Re-lock 진행상태 추적"
                ),
        }
    )

    return {
        "release_gate":
            release_gate,
        "technical_pass":
            sum(
                1
                for row in checks
                if (
                    row["layer"] == "TECHNICAL"
                    and row["status"] == "PASS"
                )
            ),
        "technical_fail":
            technical_fail,
        "operating_status":
            "PASS" if operating_pass else "REVIEW",
        "schema_status":
            schema_status,
        "compatibility_status":
            compatibility_status,
        "contract_status":
            contract_status,
        "contract_drift_status":
            drift_status,
        "closure_status":
            closure_status,
        "refresh_status":
            refresh_status,
        "lineage_integrity_failures":
            lineage_failures,
        "authorization_violations":
            auth_violations,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                SCHEMA_RELEASE_CHECK_COLS,
            ),
        "migration_authorization":
            "NONE",
    }


def _row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check":
            check,
        "status":
            "PASS" if passed else "BLOCKED",
        "detail":
            detail,
        "blocking":
            "NO" if passed else "YES",
    }


def build_v125_release_readiness(
    *,
    v124_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    schema_release_gate: str,
    schema_operating_status: str,
    migration_authorization: str,
) -> dict:
    v124 = _text(v124_release_status).upper()
    integration = _text(integration_consistency).upper()
    schema_release = _text(schema_release_gate).upper()
    schema_operating = _text(schema_operating_status).upper()
    migration_auth = _text(migration_authorization).upper()
    csv_fail = _int(csv_fail_count)

    checks = [
        _row(
            "v1.24 Resilience Baseline",
            v124 == "READY_FOR_RELEASE_REVIEW",
            v124 or "MISSING",
        ),
        _row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Schema Governance Technical Release Gate",
            schema_release == "PASS",
            schema_release or "MISSING",
        ),
        _row(
            "Migration Authorization Invariant",
            migration_auth == "NONE",
            migration_auth or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if schema_operating and schema_operating != "PASS":
        operating_reviews.append(
            "SCHEMA_OPERATING_REVIEW"
        )

    return {
        "status":
            (
                "READY_FOR_RELEASE_REVIEW"
                if not blockers
                else "BLOCKED"
            ),
        "blocking_count":
            len(blockers),
        "blockers":
            blockers,
        "operating_review_count":
            len(operating_reviews),
        "operating_reviews":
            operating_reviews,
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V125_RELEASE_CHECK_COLS,
            ),
        "migration_authorization":
            "NONE",
    }


def build_v125_integration_crosscheck(
    *,
    integration_consistency: str,
    schema_release_gate: str,
    contract_drift_status: str,
) -> dict:
    integration = _text(integration_consistency).upper()
    schema_release = _text(schema_release_gate).upper()
    drift = _text(contract_drift_status).upper()

    checks = [
        _row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _row(
            "Schema Governance Technical Release Gate",
            schema_release == "PASS",
            schema_release or "MISSING",
        ),
        _row(
            "Reader-Writer Contract Drift",
            drift == "CURRENT",
            drift or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status":
            "PASS" if not blockers else "BLOCKED",
        "blocking_count":
            len(blockers),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V125_RELEASE_CHECK_COLS,
            ),
        "migration_authorization":
            "NONE",
    }


def build_v125_data_crosscheck(
    *,
    csv_fail_count: int,
    schema_release_gate: str,
    baseline_integrity: str,
    contract_integrity: str,
) -> dict:
    csv_fail = _int(csv_fail_count)
    schema_release = _text(schema_release_gate).upper()
    baseline = _text(baseline_integrity).upper()
    contract = _text(contract_integrity).upper()

    checks = [
        _row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _row(
            "Schema Governance Release Data Gate",
            schema_release == "PASS",
            schema_release or "MISSING",
        ),
        _row(
            "Schema Baseline Lock Integrity",
            baseline == "OK",
            baseline or "MISSING",
        ),
        _row(
            "Reader-Writer Contract Lock Integrity",
            contract == "OK",
            contract or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status":
            "PASS" if not blockers else "BLOCKED",
        "blocking_count":
            len(blockers),
        "checks":
            pd.DataFrame(
                checks,
                columns=
                V125_RELEASE_CHECK_COLS,
            ),
        "migration_authorization":
            "NONE",
    }
