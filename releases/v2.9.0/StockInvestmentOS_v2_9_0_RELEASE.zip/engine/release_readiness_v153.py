from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_permanent_change_apply import (
    FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    permanent_change_apply_snapshot_integrity,
)
from engine.operations_flow_permanent_change_runtime import (
    FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS,
    PERMANENT_CHANGE_RUNTIME_STATES,
    PERMANENT_CHANGE_RUNTIME_GUARD_BY_STATE,
    PERMANENT_CHANGE_KILL_TRIGGERS,
    build_flow_permanent_change_runtime,
    permanent_change_runtime_event_integrity,
    latest_permanent_change_runtime_event,
)


PERMANENT_CHANGE_RUNTIME_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

PERMANENT_CHANGE_RUNTIME_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V153_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


V152_RELEASE_ZIP_SHA256 = (
    "e9d77c8ab15fe4f72952244828c26bd6b7896bd1660be2491e08520406c626c1"
)

V152_RELEASE_MANIFEST_FILE_SHA256 = (
    "8738c9aa59524346ba55d7978cfba17259dfd3332d8b35779d7f55d6a7b9f097"
)

V152_RELEASE_NOTES_FILE_SHA256 = (
    "4db66c008a2159eaff97023656660e7e5287e91f3939e59d18c0dc869a7d53bc"
)

V152_BASELINE_PROVENANCE_REL = "release_baselines/v1_52_0.json"


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass

    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = (
        pd.DataFrame()
        if df is None
        else df.copy()
    )

    for col in cols:
        if col not in out.columns:
            out[col] = ""

    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1

        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def _sha256_path(
    path: Path,
) -> str:
    h = hashlib.sha256()

    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b"",
        ):
            h.update(chunk)

    return h.hexdigest()


def verify_v152_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(
        code_root
    ).resolve()

    provenance_path = (
        root
        / V152_BASELINE_PROVENANCE_REL
    )

    record = {}
    record_ok = False
    record_detail = ""

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            record_detail = (
                f"{type(exc).__name__}: {exc}"
            )
        else:
            record_ok = (
                _text(
                    record.get("release_version")
                )
                == "v1.52.0"
                and _text(
                    record.get("release_zip_sha256")
                ).lower()
                == V152_RELEASE_ZIP_SHA256
                and _text(
                    record.get("manifest_file_sha256")
                ).lower()
                == V152_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get("release_notes_file_sha256")
                ).lower()
                == V152_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get("provenance_status")
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )

            record_detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    manifest_path = (
        root
        / "manifest_sha256.json"
    )

    notes_path = (
        root
        / "RELEASE_NOTES_v1_52_0.txt"
    )

    original_manifest_ok = (
        manifest_path.is_file()
        and _sha256_path(
            manifest_path
        )
        == V152_RELEASE_MANIFEST_FILE_SHA256
    )

    original_notes_ok = (
        notes_path.is_file()
        and _sha256_path(
            notes_path
        )
        == V152_RELEASE_NOTES_FILE_SHA256
    )

    original_artifacts_ok = (
        original_manifest_ok
        and original_notes_ok
    )

    verified = (
        record_ok
        or original_artifacts_ok
    )

    source = (
        "PROVENANCE_RECORD"
        if record_ok
        else (
            "ORIGINAL_V152_RELEASE_ARTIFACTS"
            if original_artifacts_ok
            else "NONE"
        )
    )

    return {
        "status": (
            "VERIFIED"
            if verified
            else "BLOCKED"
        ),
        "verified": verified,
        "source": source,
        "record_path": str(
            provenance_path
        ),
        "record_detail": record_detail,
        "release_version": "v1.52.0",
        "release_zip_sha256":
            V152_RELEASE_ZIP_SHA256,
        "manifest_file_sha256":
            V152_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256":
            V152_RELEASE_NOTES_FILE_SHA256,
        "original_manifest_match":
            original_manifest_ok,
        "original_release_notes_match":
            original_notes_ok,
    }


def build_v153_permanent_change_runtime_context(
    *,
    v152_context: dict | None,
    permanent_change_runtime_events: pd.DataFrame | None,
) -> dict:
    upstream = v152_context or {}
    apply = upstream.get("apply") or {}

    apply_df = _ensure_cols(
        upstream.get(
            "permanent_change_apply_snapshots"
        ),
        FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    runtime_df = _ensure_cols(
        permanent_change_runtime_events,
        FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS,
    )

    runtime = build_flow_permanent_change_runtime(
        apply,
        apply_df,
        runtime_df,
    )

    latest_runtime = latest_permanent_change_runtime_event(
        runtime_df
    )

    latest_integrity = (
        _text(
            permanent_change_runtime_event_integrity(
                latest_runtime
            ).get("status")
        ).upper()
        if latest_runtime
        else "NONE"
    )

    return {
        "v152_context": upstream,
        "apply": apply,
        "permanent_change_apply_snapshots": apply_df,
        "permanent_change_runtime_events": runtime_df,
        "runtime": runtime,
        "runtime_integrity": _integrity_counts(
            runtime_df,
            permanent_change_runtime_event_integrity,
        ),
        "latest_runtime": latest_runtime,
        "latest_runtime_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail": detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def _apply_routing_ok(
    runtime: dict,
    apply: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    apply_state = _text(
        apply.get("apply_state")
    ).upper()

    if apply_state == "PERMANENT_CHANGE_APPLY_NOT_REQUIRED":
        return (
            state
            == "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED"
        )

    if apply_state in {
        "PERMANENT_CHANGE_APPLY_DEFERRED",
        "PERMANENT_CHANGE_APPLY_REJECTED",
    }:
        return (
            state
            == "PERMANENT_CHANGE_RUNTIME_DEFERRED"
        )

    if apply_state != (
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
    ):
        return (
            state
            == "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT"
        )

    return state in {
        "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION",
        "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
        "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
        "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
    }


def _apply_source_mapping_ok(
    context: dict,
) -> bool:
    runtime = context.get("runtime") or {}
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    source_id = _text(
        runtime.get(
            "source_permanent_change_apply_id"
        )
    )

    source_hash = _text(
        runtime.get(
            "source_permanent_change_apply_hash"
        )
    )

    if state in {
        "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT",
        "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_DEFERRED",
    }:
        return (
            not source_id
            and not source_hash
        )

    if state == "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED":
        return (
            not source_id
            and not source_hash
        )

    if (
        state
        == "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW"
        and (not source_id or not source_hash)
    ):
        return True

    if not source_id or not source_hash:
        return False

    index, duplicates = _index_by_id(
        context.get(
            "permanent_change_apply_snapshots"
        ),
        "permanent_change_apply_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    return (
        bool(parent)
        and _text(
            permanent_change_apply_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("apply_decision")
        ).upper()
        == "ISSUE_MANUAL_STAGE1_APPLY_PERMIT"
        and _text(
            parent.get(
                "permanent_change_apply_permission"
            )
        ).upper()
        == "MANUAL_PERMANENT_STAGE1_APPLY_ONLY"
    )


def _activation_contract_ok(
    runtime: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if state not in {
        "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
        "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
    }:
        return True

    latest = runtime.get(
        "latest_runtime_event"
    ) or {}

    if not latest:
        return False

    if state == "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1":
        if _text(
            latest.get("runtime_event")
        ).upper() != "ACTIVATE":
            return False

        required = [
            "external_manual_activation_confirmed",
            "source_permit_reviewed",
            "baseline_observation_confirmed",
            "candidate_observation_confirmed",
            "scope_isolation_confirmed",
            "monitoring_active_confirmed",
            "no_auto_stage_escalation_confirmed",
            "no_auto_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        if not all(
            _bool(
                latest.get(field)
            )
            for field in required
        ):
            return False

        if len(
            _text(
                latest.get(
                    "activation_receipt_ref"
                )
            )
        ) < 8:
            return False

        if _text(
            runtime.get("proposal_scope")
        ).upper() == "PARAMETER_SHADOW":
            if abs(
                _float(
                    latest.get(
                        "observed_pre_value"
                    )
                )
                - _float(
                    runtime.get(
                        "baseline_value"
                    )
                )
            ) > 1e-9:
                return False

            if abs(
                _float(
                    latest.get(
                        "observed_post_value"
                    )
                )
                - _float(
                    runtime.get(
                        "candidate_value"
                    )
                )
            ) > 1e-9:
                return False

        return (
            _text(
                latest.get(
                    "permanent_change_runtime_permission"
                )
            ).upper()
            == "MANUAL_PERMANENT_STAGE1_RUNTIME_ONLY"
        )

    return True


def _runtime_transition_contract_ok(
    runtime: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    latest = runtime.get(
        "latest_runtime_event"
    ) or {}

    if state in {
        "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT",
        "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_DEFERRED",
        "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION",
        "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
    }:
        return True

    if not latest:
        return False

    event = _text(
        latest.get("runtime_event")
    ).upper()

    if state == "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1":
        return event == "ACTIVATE"

    if state == "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED":
        return (
            event == "CLOSE"
            and _bool(
                latest.get(
                    "scope_isolation_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "monitoring_active_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "no_auto_stage_escalation_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "no_auto_permanent_apply_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "human_review_confirmed"
                )
            )
            and (
                _text(
                    runtime.get("proposal_scope")
                ).upper()
                != "PARAMETER_SHADOW"
                or abs(
                    _float(
                        latest.get(
                            "observed_current_value"
                        )
                    )
                    - _float(
                        runtime.get(
                            "candidate_value"
                        )
                    )
                )
                <= 1e-9
            )
        )

    if state == "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED":
        return (
            event == "KILL_SWITCH"
            and _text(
                latest.get(
                    "kill_switch_trigger"
                )
            ).upper()
            in PERMANENT_CHANGE_KILL_TRIGGERS
            and _bool(
                latest.get(
                    "monitoring_active_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "rollback_initiated_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "no_auto_stage_escalation_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "no_auto_permanent_apply_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "human_review_confirmed"
                )
            )
        )

    if state == "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED":
        return (
            event == "ROLLBACK_CONFIRM"
            and _bool(
                latest.get(
                    "rollback_completed_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "baseline_restore_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "no_auto_stage_escalation_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "no_auto_permanent_apply_confirmed"
                )
            )
            and _bool(
                latest.get(
                    "human_review_confirmed"
                )
            )
            and abs(
                _float(
                    latest.get(
                        "observed_restored_value"
                    )
                )
                - _float(
                    runtime.get(
                        "rollback_target_value"
                    )
                )
            )
            <= 1e-9
        )

    return False


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    runtime = context.get("runtime") or {}
    latest = context.get(
        "latest_runtime"
    ) or {}

    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if not latest:
        return True

    source_ts = pd.to_datetime(
        runtime.get(
            "source_permanent_change_apply_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    event_ts = pd.to_datetime(
        latest.get("created_at"),
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_ts)
        or pd.isna(event_ts)
        or event_ts <= source_ts
    ):
        return False

    if state == "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED":
        return (
            _text(
                latest.get(
                    "source_permanent_change_apply_id"
                )
            )
            != _text(
                runtime.get(
                    "source_permanent_change_apply_id"
                )
            )
            or _text(
                latest.get(
                    "source_permanent_change_apply_hash"
                )
            )
            != _text(
                runtime.get(
                    "source_permanent_change_apply_hash"
                )
            )
        )

    if state in {
        "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
        "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
        "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
    }:
        return (
            _text(
                latest.get(
                    "source_permanent_change_apply_id"
                )
            )
            == _text(
                runtime.get(
                    "source_permanent_change_apply_id"
                )
            )
            and _text(
                latest.get(
                    "source_permanent_change_apply_hash"
                )
            )
            == _text(
                runtime.get(
                    "source_permanent_change_apply_hash"
                )
            )
        )

    return True


def _no_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("runtime") or {},
        context.get("latest_runtime") or {},
        context.get("apply") or {},
    ]:
        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "permanent_change_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "permanent_change_runtime_events"
    )

    if (
        isinstance(
            history,
            pd.DataFrame,
        )
        and not history.empty
    ):
        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (
                    ~values.isin(
                        ["", "NONE"]
                    )
                ).sum()
            )

    return (
        violations == 0
        and _text(
            context.get(
                "execution_authorization"
            )
        ).upper()
        == "NONE"
    )


def build_v153_permanent_change_runtime_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    runtime = ctx.get("runtime") or {}
    apply = ctx.get("apply") or {}
    counts = ctx.get(
        "runtime_integrity"
    ) or {}

    state = _text(
        runtime.get("runtime_state")
    ).upper()

    guard = _text(
        runtime.get("runtime_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Permanent Change Runtime Snapshot Integrity",
            (
                _int(
                    counts.get("missing")
                )
                == 0
                and _int(
                    counts.get("mismatch")
                )
                == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Permanent Change Runtime immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Change Runtime State / Guard Vocabulary",
            (
                state
                in PERMANENT_CHANGE_RUNTIME_STATES
                and guard
                == PERMANENT_CHANGE_RUNTIME_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {PERMANENT_CHANGE_RUNTIME_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Permanent Change Runtime state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Apply → Runtime State Invariant",
            _apply_routing_ok(
                runtime,
                apply,
            ),
            (
                f"apply {_text(apply.get('apply_state')) or 'MISSING'} · "
                f"runtime {state or 'MISSING'}"
            ),
            "Permanent Apply와 Runtime state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Runtime → Immutable Apply Permit Source Mapping",
            _apply_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"apply source {_text(runtime.get('source_permanent_change_apply_id')) or 'NONE'} · "
                f"integrity {_text(runtime.get('source_permanent_change_apply_integrity')) or 'NONE'}"
            ),
            "Runtime source Apply Permit id/hash/integrity/permission 확인",
        )
    )

    checks.append(
        _technical_row(
            "External Activation Receipt / Baseline / Candidate Invariant",
            _activation_contract_ok(
                runtime
            ),
            (
                f"state {state or 'MISSING'} · "
                f"receipt {_text(runtime.get('activation_receipt_ref')) or 'NONE'} · "
                f"pre {_float(runtime.get('observed_pre_value')):.4f} · "
                f"post {_float(runtime.get('observed_post_value')):.4f}"
            ),
            "External manual activation receipt와 observed baseline/candidate evidence 확인",
        )
    )

    checks.append(
        _technical_row(
            "Runtime Event / Close / Kill-Switch / Rollback Invariant",
            _runtime_transition_contract_ok(
                runtime
            ),
            (
                f"state {state or 'MISSING'} · "
                f"event {_text(runtime.get('runtime_event')) or 'NONE'} · "
                f"trigger {_text(runtime.get('kill_switch_trigger')) or 'NONE'} · "
                f"rollback required {bool(runtime.get('rollback_required'))}"
            ),
            "ACTIVATE/CLOSE/KILL_SWITCH/ROLLBACK_CONFIRM contract 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Runtime Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(runtime.get('source_permanent_change_apply_created_at')) or 'NONE'} · "
                f"latest {_text((ctx.get('latest_runtime') or {}).get('created_at')) or 'NONE'}"
            ),
            "Apply Permit 이후 Runtime 저장 및 source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Permanent Runtime No-Mutation / No-Execution Authorization Invariant",
            _no_authorization_ok(
                ctx
            ),
            "NONE",
            "Permanent Design/Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state in {
            "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
            "PERMANENT_CHANGE_RUNTIME_DEFERRED",
            "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
            "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Permanent Change Runtime Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"event {_text(runtime.get('runtime_event')) or 'NONE'} · "
                f"permission {_text(runtime.get('permanent_change_runtime_permission')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 upstream/activation/active/kill/supersession 상태는 Technical FAIL로 승격하지 않고 "
                    "Permanent Apply/Runtime evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "runtime_state": state,
        "apply_state": _text(
            apply.get("apply_state")
        ).upper(),
        "latest_permanent_change_runtime_integrity":
            _text(
                ctx.get(
                    "latest_runtime_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=
                PERMANENT_CHANGE_RUNTIME_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_runtime_contract_ok(
    item: dict,
) -> bool:
    event = _text(
        item.get("runtime_event")
    ).upper()

    state = _text(
        item.get("runtime_state")
    ).upper()

    guard = _text(
        item.get("runtime_guard")
    ).upper()

    expected_state = {
        "ACTIVATE":
            "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
        "CLOSE":
            "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
        "KILL_SWITCH":
            "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
        "ROLLBACK_CONFIRM":
            "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
    }.get(event)

    if (
        expected_state is None
        or state != expected_state
        or guard
        != PERMANENT_CHANGE_RUNTIME_GUARD_BY_STATE.get(
            state,
            "",
        )
    ):
        return False

    if len(
        _text(
            item.get("runtime_detail")
        )
    ) < 60:
        return False

    if event == "ACTIVATE":
        required = [
            "external_manual_activation_confirmed",
            "source_permit_reviewed",
            "baseline_observation_confirmed",
            "candidate_observation_confirmed",
            "scope_isolation_confirmed",
            "monitoring_active_confirmed",
            "no_auto_stage_escalation_confirmed",
            "no_auto_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        if not all(
            _bool(
                item.get(field)
            )
            for field in required
        ):
            return False

        if len(
            _text(
                item.get(
                    "activation_receipt_ref"
                )
            )
        ) < 8:
            return False

        if _text(
            item.get("proposal_scope")
        ).upper() == "PARAMETER_SHADOW":
            if abs(
                _float(
                    item.get(
                        "observed_pre_value"
                    )
                )
                - _float(
                    item.get(
                        "baseline_value"
                    )
                )
            ) > 1e-9:
                return False

            if abs(
                _float(
                    item.get(
                        "observed_post_value"
                    )
                )
                - _float(
                    item.get(
                        "candidate_value"
                    )
                )
            ) > 1e-9:
                return False

        return (
            _text(
                item.get(
                    "permanent_change_runtime_permission"
                )
            ).upper()
            == "MANUAL_PERMANENT_STAGE1_RUNTIME_ONLY"
        )

    if event == "CLOSE":
        return (
            _bool(
                item.get(
                    "scope_isolation_confirmed"
                )
            )
            and _bool(
                item.get(
                    "monitoring_active_confirmed"
                )
            )
            and _bool(
                item.get(
                    "no_auto_stage_escalation_confirmed"
                )
            )
            and _bool(
                item.get(
                    "no_auto_permanent_apply_confirmed"
                )
            )
            and _bool(
                item.get(
                    "human_review_confirmed"
                )
            )
            and (
                _text(
                    item.get("proposal_scope")
                ).upper()
                != "PARAMETER_SHADOW"
                or abs(
                    _float(
                        item.get(
                            "observed_current_value"
                        )
                    )
                    - _float(
                        item.get(
                            "candidate_value"
                        )
                    )
                )
                <= 1e-9
            )
        )

    if event == "KILL_SWITCH":
        return (
            _text(
                item.get(
                    "kill_switch_trigger"
                )
            ).upper()
            in PERMANENT_CHANGE_KILL_TRIGGERS
            and _bool(
                item.get(
                    "monitoring_active_confirmed"
                )
            )
            and _bool(
                item.get(
                    "rollback_initiated_confirmed"
                )
            )
            and _bool(
                item.get(
                    "no_auto_stage_escalation_confirmed"
                )
            )
            and _bool(
                item.get(
                    "no_auto_permanent_apply_confirmed"
                )
            )
            and _bool(
                item.get(
                    "human_review_confirmed"
                )
            )
        )

    return (
        _bool(
            item.get(
                "rollback_completed_confirmed"
            )
        )
        and _bool(
            item.get(
                "baseline_restore_confirmed"
            )
        )
        and _bool(
            item.get(
                "no_auto_stage_escalation_confirmed"
            )
        )
        and _bool(
            item.get(
                "no_auto_permanent_apply_confirmed"
            )
        )
        and _bool(
            item.get(
                "human_review_confirmed"
            )
        )
        and abs(
            _float(
                item.get(
                    "observed_restored_value"
                )
            )
            - _float(
                item.get(
                    "rollback_target_value"
                )
            )
        )
        <= 1e-9
    )


def _event_sequence_violations(
    runtime_df: pd.DataFrame,
) -> int:
    if runtime_df.empty:
        return 0

    df = runtime_df.copy()
    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    violations = int(
        df["_ts"].isna().sum()
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values(
        "_ts"
    )

    for _, group in valid.groupby(
        "source_permanent_change_apply_id",
        dropna=False,
    ):
        phase = "READY"

        for _, row in group.iterrows():
            event = _text(
                row.get("runtime_event")
            ).upper()

            if event == "ACTIVATE":
                if phase != "READY":
                    violations += 1
                phase = "ACTIVE"

            elif event == "CLOSE":
                if phase != "ACTIVE":
                    violations += 1
                phase = "CLOSED"

            elif event == "KILL_SWITCH":
                if phase != "ACTIVE":
                    violations += 1
                phase = "KILLED"

            elif event == "ROLLBACK_CONFIRM":
                if phase != "KILLED":
                    violations += 1
                phase = "ROLLED_BACK"

            else:
                violations += 1

    return violations


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": (
            "PASS"
            if passed
            else "FAIL"
        ),
        "detail": detail,
        "action": (
            ""
            if passed
            else action
        ),
    }


def build_v153_permanent_change_runtime_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    runtime_df = _ensure_cols(
        ctx.get(
            "permanent_change_runtime_events"
        ),
        FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS,
    )

    apply_df = _ensure_cols(
        ctx.get(
            "permanent_change_apply_snapshots"
        ),
        FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        runtime_df,
        permanent_change_runtime_event_integrity,
    )

    apply_index, apply_duplicates = _index_by_id(
        apply_df,
        "permanent_change_apply_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in runtime_df.iterrows():
        item = row.to_dict()

        runtime_id = _text(
            item.get(
                "permanent_change_runtime_event_id"
            )
        )

        if runtime_id:
            if runtime_id in seen_ids:
                identity_duplicates += 1

            seen_ids.add(
                runtime_id
            )

        if not _saved_runtime_contract_ok(
            item
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_permanent_change_apply_id"
            )
        )

        source_hash = _text(
            item.get(
                "source_permanent_change_apply_hash"
            )
        )

        parent = apply_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                permanent_change_apply_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("apply_decision")
            ).upper()
            != "ISSUE_MANUAL_STAGE1_APPLY_PERMIT"
            or _text(
                parent.get(
                    "permanent_change_apply_permission"
                )
            ).upper()
            != "MANUAL_PERMANENT_STAGE1_APPLY_ONLY"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )

            runtime_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(runtime_ts)
                or runtime_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "permanent_change_design_authorization",
            "permanent_change_apply_authorization",
            "permanent_change_runtime_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    sequence_violations = _event_sequence_violations(
        runtime_df
    )

    checks = []

    checks.append(
        _audit_row(
            "Permanent Change Runtime Audit Snapshot Integrity",
            (
                _int(
                    counts.get("missing")
                )
                == 0
                and _int(
                    counts.get("mismatch")
                )
                == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Permanent Change Runtime immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Runtime Audit Event / Rollback Contract",
            (
                contract_violations == 0
                and sequence_violations == 0
            ),
            (
                f"contract violations {contract_violations} · "
                f"sequence violations {sequence_violations}"
            ),
            "ACTIVATE/CLOSE/KILL_SWITCH/ROLLBACK_CONFIRM contract 및 event 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Runtime Audit → Apply Permit Lineage",
            (
                lineage_violations == 0
                and apply_duplicates == 0
            ),
            (
                f"lineage violations {lineage_violations} · "
                f"apply duplicate ids {apply_duplicates}"
            ),
            "Runtime source immutable Apply Permit id/hash/decision/permission lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Runtime Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate runtime ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Runtime audit identity uniqueness 및 Apply Permit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Permanent Change Runtime Audit No-Mutation Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else f"non-NONE sources {authorization_violations}"
            ),
            "Permanent Design/Apply/Runtime/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (
            ctx.get("runtime")
            or {}
        ).get("runtime_state")
    ).upper()

    operating_status = (
        "PASS"
        if current_state in {
            "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
            "PERMANENT_CHANGE_RUNTIME_DEFERRED",
            "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
            "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Permanent Change Runtime Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current runtime {current_state or 'MISSING'} · "
                f"saved events {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 Stage-1 Permit 이후 manual activation/runtime event가 필요할 때만 "
                    "immutable Runtime history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=
                PERMANENT_CHANGE_RUNTIME_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": (
            "PASS"
            if passed
            else "BLOCKED"
        ),
        "detail": detail,
        "blocking": (
            "NO"
            if passed
            else "YES"
        ),
    }


def build_v153_release_readiness(
    *,
    v152_release_status: str,
    v152_baseline_provenance: dict | None,
    integration_consistency: str,
    csv_fail_count: int,
    runtime_release_gate: str,
    runtime_audit_gate: str,
    work_ready_release_gate: str,
    runtime_operating_status: str,
    audit_operating_status: str,
    work_ready_operating_status: str,
    execution_authorization: str,
) -> dict:
    provenance = (
        v152_baseline_provenance
        or {}
    )

    checks = [
        _candidate_row(
            "v1.52 Immutable Release Baseline Provenance",
            bool(
                provenance.get("verified")
            ),
            (
                f"{_text(provenance.get('status')) or 'MISSING'} · "
                f"source {_text(provenance.get('source')) or 'NONE'} · "
                f"dynamic-v1.52 {_text(v152_release_status).upper() or 'MISSING'}"
            ),
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Permanent Change Runtime Technical Release Gate",
            _text(
                runtime_release_gate
            ).upper()
            == "PASS",
            _text(
                runtime_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Runtime Audit Integrity Gate",
            _text(
                runtime_audit_gate
            ).upper()
            == "PASS",
            _text(
                runtime_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Software Update Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            runtime_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "PERMANENT_CHANGE_RUNTIME_REVIEW"
        )

    if _text(
        work_ready_operating_status
    ).upper() != "PASS":
        operating_reviews.append(
            "WORK_READY_RELEASE_MANAGER_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V153_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v153_integration_crosscheck(
    *,
    integration_consistency: str,
    runtime_release_gate: str,
    runtime_audit_gate: str,
    work_ready_release_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Runtime Technical Gate",
            _text(
                runtime_release_gate
            ).upper()
            == "PASS",
            _text(
                runtime_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Runtime Audit Gate",
            _text(
                runtime_audit_gate
            ).upper()
            == "PASS",
            _text(
                runtime_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V153_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v153_data_crosscheck(
    *,
    csv_fail_count: int,
    runtime_release_gate: str,
    runtime_audit_gate: str,
    work_ready_release_gate: str,
    latest_runtime_integrity: str,
) -> dict:
    latest = _text(
        latest_runtime_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Permanent Change Runtime Technical Gate",
            _text(
                runtime_release_gate
            ).upper()
            == "PASS",
            _text(
                runtime_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Permanent Change Runtime Audit Gate",
            _text(
                runtime_audit_gate
            ).upper()
            == "PASS",
            _text(
                runtime_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Work-ready Safety Gate",
            _text(
                work_ready_release_gate
            ).upper()
            == "PASS",
            _text(
                work_ready_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Permanent Change Runtime Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V153_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
