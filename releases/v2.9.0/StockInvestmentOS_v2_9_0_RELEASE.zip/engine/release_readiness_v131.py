from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_calibration_promotion import (
    FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS,
    flow_calibration_promotion_snapshot_integrity,
    latest_flow_calibration_promotion_snapshot,
)


PROMOTION_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

PROMOTION_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V131_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


KNOWN_PROMOTION_STATES = {
    "PROMOTION_INTEGRITY_REVIEW",
    "PROMOTION_EVIDENCE_MATURING",
    "PROMOTION_NO_CLEARING",
    "PROMOTION_ADVERSE_INTERVAL_REVIEW",
    "PROMOTION_MIXED_BURN",
    "PROMOTION_READY",
}

KNOWN_PROMOTION_GUARDS = {
    "HOLD_INTEGRITY",
    "HOLD_PROMOTION_PROOF",
    "HOLD_NO_CLEARING",
    "HOLD_PROMOTION_STABILITY",
    "ALLOW_PROJECTION_REVIEW",
}

KNOWN_EFFECTIVE_GUARDS = {
    "HOLD_INTEGRITY",
    "HOLD_HISTORY",
    "HOLD_CLOSED_SESSION",
    "HOLD_NO_CLEARING",
    "HOLD_MIXED",
    "HOLD_PROMOTION_PROOF",
    "HOLD_PROMOTION_STABILITY",
    "ALLOW_PROJECTION_REVIEW",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    source = pd.DataFrame() if df is None else df.copy()
    if source.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0
    for _, row in source.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _fail_count(counts: dict | None) -> int:
    c = counts or {}
    return _int(c.get("missing")) + _int(c.get("mismatch"))


def build_v131_promotion_context(
    *,
    flow_context: dict | None,
    promotion_snapshots: pd.DataFrame | None,
) -> dict:
    flow_ctx = flow_context or {}
    calibration = flow_ctx.get("calibration") or {}
    evidence = flow_ctx.get("evidence_quality") or {}
    promotion = flow_ctx.get("calibration_promotion") or {}

    promotion_df = _ensure_cols(
        promotion_snapshots,
        FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS,
    )
    latest = latest_flow_calibration_promotion_snapshot(
        promotion_df
    )
    latest_integrity = (
        _text(
            flow_calibration_promotion_snapshot_integrity(
                latest
            ).get("status")
        ).upper()
        if latest
        else "NONE"
    )

    return {
        "flow_context": flow_ctx,
        "calibration": calibration,
        "evidence": evidence,
        "promotion": promotion,
        "promotion_snapshots": promotion_df,
        "promotion_integrity": _integrity_counts(
            promotion_df,
            flow_calibration_promotion_snapshot_integrity,
        ),
        "latest_promotion": latest,
        "latest_promotion_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _expected_promotion_guard(
    state: str,
) -> str:
    mapping = {
        "PROMOTION_INTEGRITY_REVIEW": "HOLD_INTEGRITY",
        "PROMOTION_EVIDENCE_MATURING": "HOLD_PROMOTION_PROOF",
        "PROMOTION_NO_CLEARING": "HOLD_NO_CLEARING",
        "PROMOTION_ADVERSE_INTERVAL_REVIEW": "HOLD_PROMOTION_STABILITY",
        "PROMOTION_MIXED_BURN": "HOLD_PROMOTION_STABILITY",
        "PROMOTION_READY": "ALLOW_PROJECTION_REVIEW",
    }
    return mapping.get(state, "")


def _promotion_state_coherent(
    promotion: dict | None,
) -> bool:
    promo = promotion or {}
    state = _text(promo.get("promotion_state")).upper()
    guard = _text(promo.get("promotion_guard")).upper()

    if state not in KNOWN_PROMOTION_STATES:
        return False
    if guard != _expected_promotion_guard(state):
        return False

    observed = _int(promo.get("observed_intervals"))
    target = max(1, _int(promo.get("target_intervals")))
    negative = _int(promo.get("negative_burn_intervals"))
    max_negative = max(0, _int(promo.get("max_negative_intervals")))
    ratio = _float(promo.get("positive_burn_ratio"))
    min_ratio = _float(promo.get("min_positive_burn_ratio"))
    avg = _float(promo.get("avg_net_burn_per_interval"))

    if state == "PROMOTION_EVIDENCE_MATURING":
        return observed < target
    if state == "PROMOTION_NO_CLEARING":
        return observed >= target and avg <= 0
    if state == "PROMOTION_ADVERSE_INTERVAL_REVIEW":
        return observed >= target and avg > 0 and negative > max_negative
    if state == "PROMOTION_MIXED_BURN":
        return (
            observed >= target
            and avg > 0
            and negative <= max_negative
            and ratio < min_ratio
        )
    if state == "PROMOTION_READY":
        return (
            observed >= target
            and avg > 0
            and negative <= max_negative
            and ratio >= min_ratio
        )
    # Integrity review is allowed when upstream alignment/integrity has already
    # forced a hold. The technical alignment checks below decide whether the
    # current live context is internally consistent.
    return True


def _non_relaxation_ok(
    promotion: dict | None,
) -> bool:
    promo = promotion or {}
    raw_guard = _text(
        promo.get("raw_projection_guard")
    ).upper()
    promotion_guard = _text(
        promo.get("promotion_guard")
    ).upper()
    effective = _text(
        promo.get("effective_projection_guard")
    ).upper()

    if not raw_guard or not effective:
        return False

    if raw_guard == "ALLOW_PROJECTION_REVIEW":
        return effective == promotion_guard

    return effective == raw_guard


def build_v131_promotion_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    calibration = ctx.get("calibration") or {}
    evidence = ctx.get("evidence") or {}
    promotion = ctx.get("promotion") or {}
    integrity = ctx.get("promotion_integrity") or {}

    checks = []

    integrity_fail = _fail_count(integrity)
    checks.append(
        _technical_row(
            "Calibration Promotion Snapshot Integrity",
            integrity_fail == 0,
            (
                f"records {_int(integrity.get('total'))} · "
                f"OK {_int(integrity.get('ok'))} · "
                f"MISSING {_int(integrity.get('missing'))} · "
                f"MISMATCH {_int(integrity.get('mismatch'))}"
            ),
            "operations_flow_calibration_promotion_snapshots.csv immutable hash 확인",
        )
    )

    cal_state = _text(
        calibration.get("calibration_state")
    ).upper()
    promo_cal_state = _text(
        promotion.get("calibration_state")
    ).upper()
    raw_guard = _text(
        calibration.get("calibration_raw_projection_guard")
    ).upper() or _text(
        promotion.get("raw_projection_guard")
    ).upper()
    promo_raw_guard = _text(
        promotion.get("raw_projection_guard")
    ).upper()
    observed = _int(calibration.get("observed_intervals"))
    promo_observed = _int(promotion.get("observed_intervals"))

    calibration_alignment_ok = (
        cal_state == promo_cal_state
        and raw_guard == promo_raw_guard
        and observed == promo_observed
    )
    checks.append(
        _technical_row(
            "Promotion ↔ Calibration Alignment",
            calibration_alignment_ok,
            (
                f"calibration {cal_state or 'MISSING'} · "
                f"promotion calibration {promo_cal_state or 'MISSING'} · "
                f"raw guard {raw_guard or 'MISSING'}/{promo_raw_guard or 'MISSING'} · "
                f"intervals {observed}/{promo_observed}"
            ),
            "Calibration state/raw guard/observed intervals와 Promotion 입력값 정렬 확인",
        )
    )

    ev_state = _text(evidence.get("evidence_state")).upper()
    promo_ev_state = _text(
        promotion.get("evidence_state")
    ).upper()
    window_state = _text(
        evidence.get("evidence_window_state")
    ).upper()
    promo_window = _text(
        promotion.get("evidence_window_state")
    ).upper()
    qualified = _int(evidence.get("qualified_endpoints"))
    promo_qualified = _int(
        promotion.get("qualified_endpoints")
    )

    evidence_alignment_ok = (
        ev_state == promo_ev_state
        and window_state == promo_window
        and qualified == promo_qualified
    )
    checks.append(
        _technical_row(
            "Promotion ↔ Evidence Window Alignment",
            evidence_alignment_ok,
            (
                f"evidence {ev_state or 'MISSING'} · "
                f"promotion evidence {promo_ev_state or 'MISSING'} · "
                f"window {window_state or 'MISSING'}/{promo_window or 'MISSING'} · "
                f"qualified {qualified}/{promo_qualified}"
            ),
            "Recent evidence window와 Promotion source alignment 확인",
        )
    )

    state = _text(
        promotion.get("promotion_state")
    ).upper()
    guard = _text(
        promotion.get("promotion_guard")
    ).upper()
    state_coherent = _promotion_state_coherent(
        promotion
    )
    checks.append(
        _technical_row(
            "Calibration Promotion Decision Invariant",
            state_coherent,
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"intervals {_int(promotion.get('observed_intervals'))}/"
                f"{_int(promotion.get('target_intervals'))} · "
                f"positive {_float(promotion.get('positive_burn_ratio')):.1%} · "
                f"negative {_int(promotion.get('negative_burn_intervals'))}"
            ),
            "Promotion state/guard와 interval/burn 조건 mapping 확인",
        )
    )

    effective = _text(
        promotion.get("effective_projection_guard")
    ).upper()
    cal_effective = _text(
        calibration.get("projection_guard")
    ).upper()
    non_relaxation = (
        _non_relaxation_ok(promotion)
        and effective == cal_effective
        and effective in KNOWN_EFFECTIVE_GUARDS
    )
    checks.append(
        _technical_row(
            "Projection Admission Non-Relaxation Invariant",
            non_relaxation,
            (
                f"raw {promo_raw_guard or 'MISSING'} · "
                f"promotion {guard or 'MISSING'} · "
                f"effective {effective or 'MISSING'} · "
                f"calibration effective {cal_effective or 'MISSING'}"
            ),
            "Promotion이 기존 HOLD를 ALLOW로 완화하지 않는지 확인",
        )
    )

    target = max(
        1,
        _int(promotion.get("target_intervals")),
    )
    promo_intervals = _int(
        promotion.get("observed_intervals")
    )
    negative = _int(
        promotion.get("negative_burn_intervals")
    )
    ratio = _float(
        promotion.get("positive_burn_ratio")
    )
    avg = _float(
        promotion.get("avg_net_burn_per_interval")
    )

    promotion_ready_safety = True
    if state == "PROMOTION_READY":
        promotion_ready_safety = (
            promo_intervals >= target
            and negative <= _int(
                promotion.get("max_negative_intervals")
            )
            and ratio >= _float(
                promotion.get("min_positive_burn_ratio")
            )
            and avg > 0
            and effective == "ALLOW_PROJECTION_REVIEW"
        )

    checks.append(
        _technical_row(
            "Promotion READY Admission Safety Invariant",
            promotion_ready_safety,
            (
                f"state {state or 'MISSING'} · "
                f"intervals {promo_intervals}/{target} · "
                f"avg burn {avg:.2f} · "
                f"positive {ratio:.1%} · "
                f"negative {negative} · "
                f"effective {effective or 'MISSING'}"
            ),
            "PROMOTION_READY가 proof/stability 조건을 모두 충족하는지 확인",
        )
    )

    auth_values = []
    for source in [promotion, calibration]:
        for field in [
            "projection_authorization",
            "execution_authorization",
        ]:
            if field in source:
                auth_values.append(
                    _text(source.get(field)).upper()
                )
    auth_values.append(
        _text(ctx.get("execution_authorization")).upper()
    )
    auth_ok = all(
        value in {"", "NONE"}
        for value in auth_values
    )
    checks.append(
        _technical_row(
            "Calibration Promotion Authorization Invariant",
            auth_ok,
            "NONE" if auth_ok else "non-NONE authorization detected",
            "Projection / Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if (
            state == "PROMOTION_READY"
            and effective == "ALLOW_PROJECTION_REVIEW"
        )
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Calibration Promotion Operating State",
            "status": operating_status,
            "detail": (
                f"promotion {state or 'MISSING'} · "
                f"effective {effective or 'MISSING'} · "
                f"intervals {promo_intervals}/{target}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "PROMOTION_EVIDENCE_MATURING / HOLD 상태는 정상 Operating Review로 유지"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL"
            and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "promotion_state": state,
        "promotion_guard": guard,
        "effective_projection_guard": effective,
        "observed_intervals": promo_intervals,
        "target_intervals": target,
        "latest_promotion_integrity": _text(
            ctx.get("latest_promotion_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=PROMOTION_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v131_promotion_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    df = ctx.get("promotion_snapshots")
    source = (
        pd.DataFrame()
        if not isinstance(df, pd.DataFrame)
        else df.copy()
    )

    integrity = ctx.get("promotion_integrity") or {}
    integrity_ok = _fail_count(integrity) == 0

    state_guard_violations = 0
    non_relaxation_violations = 0
    authorization_violations = 0

    for _, row in source.iterrows():
        item = row.to_dict()
        if (
            flow_calibration_promotion_snapshot_integrity(
                item
            ).get("status")
            != "OK"
        ):
            continue

        state = _text(item.get("promotion_state")).upper()
        guard = _text(item.get("promotion_guard")).upper()
        if (
            state not in KNOWN_PROMOTION_STATES
            or guard != _expected_promotion_guard(state)
        ):
            state_guard_violations += 1

        if not _non_relaxation_ok(item):
            non_relaxation_violations += 1

        for field in [
            "projection_authorization",
            "execution_authorization",
        ]:
            if _text(item.get(field)).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = [
        _audit_row(
            "Promotion Audit Snapshot Integrity",
            integrity_ok,
            (
                f"records {_int(integrity.get('total'))} · "
                f"OK {_int(integrity.get('ok'))} · "
                f"MISSING {_int(integrity.get('missing'))} · "
                f"MISMATCH {_int(integrity.get('mismatch'))}"
            ),
            "Promotion audit immutable hash 확인",
        ),
        _audit_row(
            "Promotion Audit State / Guard Vocabulary",
            state_guard_violations == 0,
            f"violations {state_guard_violations}",
            "저장 Promotion state/guard mapping 확인",
        ),
        _audit_row(
            "Promotion Audit Non-Relaxation",
            non_relaxation_violations == 0,
            f"violations {non_relaxation_violations}",
            "저장 Promotion이 Raw HOLD를 ALLOW로 완화하지 않았는지 확인",
        ),
        _audit_row(
            "Promotion Audit Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else f"violations {authorization_violations}"
            ),
            "저장 Promotion audit의 Projection/Execution Authorization을 NONE으로 유지",
        ),
    ]

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("promotion") or {}).get("promotion_state")
    ).upper()
    operating_status = (
        "PASS"
        if current_state == "PROMOTION_READY"
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Promotion Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current promotion {current_state or 'MISSING'} · "
                f"saved audits {_int(integrity.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else "Promotion proof가 성숙할 때까지 audit history를 필요 시 저장"
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL"
            and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=PROMOTION_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v131_release_readiness(
    *,
    v130_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    promotion_release_gate: str,
    promotion_audit_gate: str,
    promotion_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(v130_release_status).upper()
    integration = _text(integration_consistency).upper()
    csv_fail = _int(csv_fail_count)
    promotion_gate = _text(promotion_release_gate).upper()
    audit_gate = _text(promotion_audit_gate).upper()
    execution = _text(execution_authorization).upper()

    checks = [
        _candidate_row(
            "v1.30 Flow Evidence Qualification Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Calibration Promotion Technical Release Gate",
            promotion_gate == "PASS",
            promotion_gate or "MISSING",
        ),
        _candidate_row(
            "Calibration Promotion Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(promotion_operating_status).upper() != "PASS"
        or _text(audit_operating_status).upper() != "PASS"
    ):
        operating_reviews.append(
            "CALIBRATION_PROMOTION_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(operating_reviews),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V131_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v131_integration_crosscheck(
    *,
    integration_consistency: str,
    promotion_release_gate: str,
    promotion_audit_gate: str,
) -> dict:
    integration = _text(integration_consistency).upper()
    promotion_gate = _text(promotion_release_gate).upper()
    audit_gate = _text(promotion_audit_gate).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Calibration Promotion Technical Gate",
            promotion_gate == "PASS",
            promotion_gate or "MISSING",
        ),
        _candidate_row(
            "Calibration Promotion Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V131_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v131_data_crosscheck(
    *,
    csv_fail_count: int,
    promotion_release_gate: str,
    promotion_audit_gate: str,
    latest_promotion_integrity: str,
) -> dict:
    csv_fail = _int(csv_fail_count)
    promotion_gate = _text(promotion_release_gate).upper()
    audit_gate = _text(promotion_audit_gate).upper()
    latest = _text(latest_promotion_integrity).upper()

    latest_ok = latest in {"OK", "NONE"}

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Calibration Promotion Technical Gate",
            promotion_gate == "PASS",
            promotion_gate or "MISSING",
        ),
        _candidate_row(
            "Calibration Promotion Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Calibration Promotion Snapshot Integrity",
            latest_ok,
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V131_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
