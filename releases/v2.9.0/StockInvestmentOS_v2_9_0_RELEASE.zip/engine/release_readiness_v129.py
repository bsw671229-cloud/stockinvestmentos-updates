from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_calibration import (
    FLOW_CALIBRATION_SNAPSHOT_COLS,
    flow_calibration_snapshot_integrity,
)
from engine.operations_flow_trend import (
    FLOW_TREND_SNAPSHOT_COLS,
    flow_trend_snapshot_integrity,
)
from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    build_flow_projection,
    flow_projection_snapshot_integrity,
    latest_flow_projection_snapshot,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    build_flow_projection_outcome,
    flow_projection_outcome_snapshot_integrity,
    latest_flow_projection_outcome_snapshot,
    latest_ready_flow_projection_snapshot,
)
from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    build_flow_projection_scorecard,
    flow_projection_scorecard_snapshot_integrity,
    latest_flow_projection_scorecard_snapshot,
)


PROJECTION_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

PROJECTION_LINEAGE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V129_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


KNOWN_PROJECTION_STATES = {
    "SOURCE_CALIBRATION_REQUIRED",
    "SOURCE_CALIBRATION_INTEGRITY_REVIEW",
    "SOURCE_CALIBRATION_DRIFT_REVIEW",
    "HOLD_HISTORY",
    "HOLD_CALIBRATION",
    "HOLD_NO_CLEARING",
    "HOLD_MIXED",
    "HOLD_INTEGRITY",
    "HOLD_PROMOTION_PROOF",
    "HOLD_PROMOTION_STABILITY",
    "HOLD_ADMISSION_SOURCE",
    "READY_FOR_REVIEW",
}

KNOWN_OUTCOME_STATES = {
    "PROJECTION_SOURCE_REQUIRED",
    "SOURCE_PROJECTION_INTEGRITY_REVIEW",
    "SOURCE_PROJECTION_NOT_READY",
    "EVIDENCE_INTEGRITY_REVIEW",
    "OUTCOME_EVIDENCE_INTEGRITY_REVIEW",
    "OUTCOME_ANTI_HINDSIGHT_REVIEW",
    "OUTCOME_EVIDENCE_GAP_REVIEW",
    "WAIT_EVIDENCE",
    "EVIDENCE_MATURING",
    "ASSUMPTION_DRIFT_REVIEW",
    "BASE_CLEARANCE_MISS_REVIEW",
    "MODEL_BREAK_REVIEW",
    "MODEL_ERROR_REVIEW",
    "CLEARED_REVIEW",
    "WITHIN_REVIEW_BAND",
}

KNOWN_SCORECARD_STATES = {
    "SCORECARD_HISTORY_REQUIRED",
    "OUTCOME_INTEGRITY_REVIEW",
    "SCORECARD_EVIDENCE_MATURING",
    "REBASE_REQUIRED",
    "RECALIBRATION_PROOF_MET",
    "RECALIBRATION_PROOF_MATURING",
    "MONITOR",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = 0
    ok = 0
    missing = 0
    mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()
        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _fail_count(counts: dict | None) -> int:
    c = counts or {}
    return _int(c.get("missing")) + _int(c.get("mismatch"))


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _latest_integrity(
    latest: dict | None,
    integrity_fn,
) -> str:
    if not latest:
        return "NONE"
    return _text(
        integrity_fn(latest).get("status")
    ).upper() or "MISSING"


def build_v129_projection_context(
    *,
    flow_context: dict | None,
    trend_snapshots: pd.DataFrame | None,
    calibration_snapshots: pd.DataFrame | None,
    projection_snapshots: pd.DataFrame | None,
    outcome_snapshots: pd.DataFrame | None,
    scorecard_snapshots: pd.DataFrame | None,
) -> dict:
    flow_ctx = flow_context or {}
    calibration = flow_ctx.get("calibration") or {}
    source_calibration = flow_ctx.get("latest_calibration") or {}

    projection_df = _ensure_cols(
        projection_snapshots,
        FLOW_PROJECTION_SNAPSHOT_COLS,
    )
    outcome_df = _ensure_cols(
        outcome_snapshots,
        FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    )
    scorecard_df = _ensure_cols(
        scorecard_snapshots,
        FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    )

    current_projection = build_flow_projection(
        calibration,
        source_calibration,
    )

    ready_projection = latest_ready_flow_projection_snapshot(
        projection_df
    )
    current_outcome = build_flow_projection_outcome(
        ready_projection,
        trend_snapshots,
        min_evaluation_intervals=2,
        max_evaluation_intervals=20,
        relative_error_threshold=0.50,
    )
    current_scorecard = build_flow_projection_scorecard(
        outcome_df,
        min_outcome_evidence_intervals=2,
        proof_clock_target=3,
        broad_error_threshold=0.50,
        override_review_ttl_intervals=2,
    )

    latest_projection = latest_flow_projection_snapshot(
        projection_df
    )
    latest_outcome = latest_flow_projection_outcome_snapshot(
        outcome_df
    )
    latest_scorecard = latest_flow_projection_scorecard_snapshot(
        scorecard_df
    )

    return {
        "flow_context": flow_ctx,
        "trend_snapshots": _ensure_cols(
            trend_snapshots,
            FLOW_TREND_SNAPSHOT_COLS,
        ),
        "calibration_snapshots": _ensure_cols(
            calibration_snapshots,
            FLOW_CALIBRATION_SNAPSHOT_COLS,
        ),
        "projection_snapshots": projection_df,
        "outcome_snapshots": outcome_df,
        "scorecard_snapshots": scorecard_df,
        "current_projection": current_projection,
        "current_outcome": current_outcome,
        "current_scorecard": current_scorecard,
        "latest_projection": latest_projection,
        "latest_outcome": latest_outcome,
        "latest_scorecard": latest_scorecard,
        "projection_integrity": _integrity_counts(
            projection_df,
            flow_projection_snapshot_integrity,
        ),
        "outcome_integrity": _integrity_counts(
            outcome_df,
            flow_projection_outcome_snapshot_integrity,
        ),
        "scorecard_integrity": _integrity_counts(
            scorecard_df,
            flow_projection_scorecard_snapshot_integrity,
        ),
        "latest_projection_integrity": _latest_integrity(
            latest_projection,
            flow_projection_snapshot_integrity,
        ),
        "latest_outcome_integrity": _latest_integrity(
            latest_outcome,
            flow_projection_outcome_snapshot_integrity,
        ),
        "latest_scorecard_integrity": _latest_integrity(
            latest_scorecard,
            flow_projection_scorecard_snapshot_integrity,
        ),
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v129_projection_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    projection_counts = ctx.get("projection_integrity") or {}
    outcome_counts = ctx.get("outcome_integrity") or {}
    scorecard_counts = ctx.get("scorecard_integrity") or {}

    projection = ctx.get("current_projection") or {}
    outcome = ctx.get("current_outcome") or {}
    scorecard = ctx.get("current_scorecard") or {}

    checks = []

    projection_fail = _fail_count(projection_counts)
    checks.append(
        _technical_row(
            "Flow Projection Snapshot Integrity",
            projection_fail == 0,
            (
                f"records {_int(projection_counts.get('total'))} · "
                f"OK {_int(projection_counts.get('ok'))} · "
                f"MISSING {_int(projection_counts.get('missing'))} · "
                f"MISMATCH {_int(projection_counts.get('mismatch'))}"
            ),
            "operations_flow_projection_snapshots.csv immutable hash 확인",
        )
    )

    outcome_fail = _fail_count(outcome_counts)
    checks.append(
        _technical_row(
            "Projection Outcome Snapshot Integrity",
            outcome_fail == 0,
            (
                f"records {_int(outcome_counts.get('total'))} · "
                f"OK {_int(outcome_counts.get('ok'))} · "
                f"MISSING {_int(outcome_counts.get('missing'))} · "
                f"MISMATCH {_int(outcome_counts.get('mismatch'))}"
            ),
            "operations_flow_projection_outcome_snapshots.csv immutable hash 확인",
        )
    )

    scorecard_fail = _fail_count(scorecard_counts)
    checks.append(
        _technical_row(
            "Projection Scorecard Snapshot Integrity",
            scorecard_fail == 0,
            (
                f"records {_int(scorecard_counts.get('total'))} · "
                f"OK {_int(scorecard_counts.get('ok'))} · "
                f"MISSING {_int(scorecard_counts.get('missing'))} · "
                f"MISMATCH {_int(scorecard_counts.get('mismatch'))}"
            ),
            "operations_flow_projection_scorecard_snapshots.csv immutable hash 확인",
        )
    )

    p_state = _text(projection.get("projection_state")).upper()
    p_fresh = _text(projection.get("source_freshness")).upper()
    p_source_integrity = _text(
        projection.get("source_calibration_integrity")
    ).upper()
    p_guard = _text(projection.get("projection_guard")).upper()

    if p_state == "READY_FOR_REVIEW":
        projection_safe = (
            p_fresh == "CURRENT"
            and p_source_integrity == "OK"
            and p_guard == "ALLOW_PROJECTION_REVIEW"
        )
    elif p_fresh != "CURRENT":
        projection_safe = p_state != "READY_FOR_REVIEW"
    else:
        projection_safe = p_state in KNOWN_PROJECTION_STATES

    checks.append(
        _technical_row(
            "Projection Source / Guard Safety Invariant",
            projection_safe,
            (
                f"state {p_state or 'MISSING'} · "
                f"freshness {p_fresh or 'MISSING'} · "
                f"source integrity {p_source_integrity or 'MISSING'} · "
                f"guard {p_guard or 'MISSING'}"
            ),
            "Calibration source freshness / Projection Guard / Projection State 연결 확인",
        )
    )

    o_state = _text(outcome.get("evaluation_state")).upper()
    o_intervals = _int(outcome.get("evidence_intervals"))
    o_source_integrity = _text(
        outcome.get("source_projection_integrity")
    ).upper()

    if bool(outcome.get("snapshot_eligible")):
        outcome_safe = (
            o_source_integrity == "OK"
            and o_intervals > 0
            and o_state in KNOWN_OUTCOME_STATES
        )
    else:
        outcome_safe = o_state in KNOWN_OUTCOME_STATES

    checks.append(
        _technical_row(
            "Projection Outcome Evidence Safety Invariant",
            outcome_safe,
            (
                f"state {o_state or 'MISSING'} · "
                f"evidence {o_intervals} · "
                f"source integrity {o_source_integrity or 'MISSING'}"
            ),
            "READY Projection lineage와 Outcome evidence eligibility 연결 확인",
        )
    )

    s_state = _text(scorecard.get("scorecard_state")).upper()
    proof_count = _int(scorecard.get("proof_clock_count"))
    proof_target = max(1, _int(scorecard.get("proof_clock_target")))
    unique_evidence = _int(scorecard.get("unique_evidence_endpoints"))
    override_gate = _text(
        scorecard.get("capacity_override_review_gate")
    ).upper()
    approval = _text(
        scorecard.get("override_review_approval_state")
    ).upper()

    proof_ok = proof_count <= unique_evidence
    if override_gate == "OPEN_FOR_HUMAN_REVIEW":
        proof_ok = (
            proof_ok
            and proof_count >= proof_target
            and approval == "HUMAN_APPROVAL_REQUIRED"
        )

    checks.append(
        _technical_row(
            "Proof Clock / Override Review Gate Invariant",
            proof_ok,
            (
                f"scorecard {s_state or 'MISSING'} · "
                f"proof {proof_count}/{proof_target} · "
                f"unique evidence {unique_evidence} · "
                f"override {override_gate or 'MISSING'} · "
                f"approval {approval or 'MISSING'}"
            ),
            "중복 evidence 방지와 Override Gate proof/approval 조건 확인",
        )
    )

    known_states = (
        p_state in KNOWN_PROJECTION_STATES
        and o_state in KNOWN_OUTCOME_STATES
        and s_state in KNOWN_SCORECARD_STATES
    )
    checks.append(
        _technical_row(
            "Projection Governance State Vocabulary Invariant",
            known_states,
            (
                f"projection {p_state or 'MISSING'} · "
                f"outcome {o_state or 'MISSING'} · "
                f"scorecard {s_state or 'MISSING'}"
            ),
            "알 수 없는 Projection/Outcome/Scorecard 상태값 확인",
        )
    )

    auth_violations = 0

    live_sources = [
        projection,
        outcome,
        scorecard,
    ]
    for item in live_sources:
        for field in [
            "projection_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "execution_authorization",
        ]:
            if field in item and _text(item.get(field)).upper() not in {"", "NONE"}:
                auth_violations += 1

    data_sources = [
        ctx.get("projection_snapshots"),
        ctx.get("outcome_snapshots"),
        ctx.get("scorecard_snapshots"),
    ]
    auth_fields = [
        "projection_authorization",
        "capacity_authorization",
        "capacity_override_authorization",
        "execution_authorization",
    ]
    for df in data_sources:
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue
        for field in auth_fields:
            if field not in df.columns:
                continue
            values = (
                df[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            auth_violations += int((~values.isin(["", "NONE"])).sum())

    if _text(ctx.get("execution_authorization")).upper() != "NONE":
        auth_violations += 1

    checks.append(
        _technical_row(
            "Projection Governance Authorization Invariant",
            auth_violations == 0,
            "NONE" if auth_violations == 0 else f"non-NONE sources {auth_violations}",
            "Projection / Capacity / Override / Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    healthy_operating = (
        p_state == "READY_FOR_REVIEW"
        and o_state in {"WITHIN_REVIEW_BAND", "CLEARED_REVIEW"}
        and s_state == "MONITOR"
    )
    operating_status = "PASS" if healthy_operating else "REVIEW"

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Governance Operating State",
            "status": operating_status,
            "detail": (
                f"projection {p_state or 'MISSING'} · "
                f"outcome {o_state or 'MISSING'} · "
                f"scorecard {s_state or 'MISSING'} · "
                f"proof {proof_count}/{proof_target} · "
                f"override {override_gate or 'MISSING'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 WAIT/HOLD 상태는 Technical FAIL로 승격하지 말고 "
                    "실제 Flow evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": "PASS" if technical_fail == 0 else "BLOCKED",
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL" and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "projection_state": p_state,
        "outcome_state": o_state,
        "scorecard_state": s_state,
        "proof_clock": f"{proof_count}/{proof_target}",
        "override_review_gate": override_gate,
        "latest_projection_integrity": _text(
            ctx.get("latest_projection_integrity")
        ).upper() or "NONE",
        "latest_outcome_integrity": _text(
            ctx.get("latest_outcome_integrity")
        ).upper() or "NONE",
        "latest_scorecard_integrity": _text(
            ctx.get("latest_scorecard_integrity")
        ).upper() or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=PROJECTION_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _index_by_id(
    df: pd.DataFrame,
    *,
    id_col: str,
) -> tuple[dict, int]:
    if df.empty or id_col not in df.columns:
        return {}, 0

    index = {}
    duplicates = 0
    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))
        if not item_id:
            continue
        if item_id in index:
            duplicates += 1
        index[item_id] = item
    return index, duplicates


def _lineage_result(
    *,
    checked: int,
    missing: int,
    mismatch: int,
    duplicate: int = 0,
) -> dict:
    return {
        "checked": checked,
        "missing": missing,
        "mismatch": mismatch,
        "duplicate": duplicate,
        "passed": (
            missing == 0
            and mismatch == 0
            and duplicate == 0
        ),
    }


def _projection_calibration_lineage(ctx: dict) -> dict:
    projections = ctx.get("projection_snapshots")
    calibrations = ctx.get("calibration_snapshots")

    projection_df = (
        projections if isinstance(projections, pd.DataFrame) else pd.DataFrame()
    )
    calibration_df = (
        calibrations if isinstance(calibrations, pd.DataFrame) else pd.DataFrame()
    )

    cal_index, duplicate = _index_by_id(
        calibration_df,
        id_col="calibration_snapshot_id",
    )

    checked = 0
    missing = 0
    mismatch = 0

    for _, row in projection_df.iterrows():
        item = row.to_dict()
        checked += 1
        source_id = _text(item.get("source_calibration_snapshot_id"))
        source_hash = _text(item.get("source_calibration_hash"))
        parent = cal_index.get(source_id)

        if not source_id or parent is None:
            missing += 1
            continue

        parent_integrity = _text(
            flow_calibration_snapshot_integrity(parent).get("status")
        ).upper()
        if (
            parent_integrity != "OK"
            or _text(parent.get("snapshot_hash")) != source_hash
        ):
            mismatch += 1

    return _lineage_result(
        checked=checked,
        missing=missing,
        mismatch=mismatch,
        duplicate=duplicate,
    )


def _outcome_projection_lineage(ctx: dict) -> dict:
    outcomes = ctx.get("outcome_snapshots")
    projections = ctx.get("projection_snapshots")

    outcome_df = outcomes if isinstance(outcomes, pd.DataFrame) else pd.DataFrame()
    projection_df = projections if isinstance(projections, pd.DataFrame) else pd.DataFrame()

    proj_index, duplicate = _index_by_id(
        projection_df,
        id_col="projection_snapshot_id",
    )

    checked = 0
    missing = 0
    mismatch = 0

    for _, row in outcome_df.iterrows():
        item = row.to_dict()
        checked += 1
        source_id = _text(item.get("source_projection_snapshot_id"))
        source_hash = _text(item.get("source_projection_hash"))
        parent = proj_index.get(source_id)

        if not source_id or parent is None:
            missing += 1
            continue

        parent_integrity = _text(
            flow_projection_snapshot_integrity(parent).get("status")
        ).upper()
        if (
            parent_integrity != "OK"
            or _text(parent.get("snapshot_hash")) != source_hash
        ):
            mismatch += 1

    return _lineage_result(
        checked=checked,
        missing=missing,
        mismatch=mismatch,
        duplicate=duplicate,
    )


def _outcome_trend_lineage(ctx: dict) -> dict:
    outcomes = ctx.get("outcome_snapshots")
    trends = ctx.get("trend_snapshots")

    outcome_df = outcomes if isinstance(outcomes, pd.DataFrame) else pd.DataFrame()
    trend_df = trends if isinstance(trends, pd.DataFrame) else pd.DataFrame()

    trend_index, duplicate = _index_by_id(
        trend_df,
        id_col="trend_snapshot_id",
    )

    checked = 0
    missing = 0
    mismatch = 0

    for _, row in outcome_df.iterrows():
        item = row.to_dict()
        checked += 1
        source_id = _text(item.get("evidence_end_trend_snapshot_id"))
        source_hash = _text(item.get("evidence_end_trend_hash"))
        parent = trend_index.get(source_id)

        if not source_id or parent is None:
            missing += 1
            continue

        parent_integrity = _text(
            flow_trend_snapshot_integrity(parent).get("status")
        ).upper()
        if (
            parent_integrity != "OK"
            or _text(parent.get("snapshot_hash")) != source_hash
        ):
            mismatch += 1

    return _lineage_result(
        checked=checked,
        missing=missing,
        mismatch=mismatch,
        duplicate=duplicate,
    )


def _scorecard_projection_lineage(ctx: dict) -> dict:
    scorecards = ctx.get("scorecard_snapshots")
    projections = ctx.get("projection_snapshots")

    scorecard_df = scorecards if isinstance(scorecards, pd.DataFrame) else pd.DataFrame()
    projection_df = projections if isinstance(projections, pd.DataFrame) else pd.DataFrame()

    proj_index, duplicate = _index_by_id(
        projection_df,
        id_col="projection_snapshot_id",
    )

    checked = 0
    missing = 0
    mismatch = 0

    for _, row in scorecard_df.iterrows():
        item = row.to_dict()
        checked += 1
        source_id = _text(item.get("source_projection_snapshot_id"))
        parent = proj_index.get(source_id)

        if not source_id or parent is None:
            missing += 1
            continue

        if _text(
            flow_projection_snapshot_integrity(parent).get("status")
        ).upper() != "OK":
            mismatch += 1

    return _lineage_result(
        checked=checked,
        missing=missing,
        mismatch=mismatch,
        duplicate=duplicate,
    )


def _scorecard_outcome_lineage(ctx: dict) -> dict:
    scorecards = ctx.get("scorecard_snapshots")
    outcomes = ctx.get("outcome_snapshots")

    scorecard_df = scorecards if isinstance(scorecards, pd.DataFrame) else pd.DataFrame()
    outcome_df = outcomes if isinstance(outcomes, pd.DataFrame) else pd.DataFrame()

    valid_outcome_projection_ids = set()
    for _, row in outcome_df.iterrows():
        item = row.to_dict()
        if _text(
            flow_projection_outcome_snapshot_integrity(item).get("status")
        ).upper() == "OK":
            source_id = _text(item.get("source_projection_snapshot_id"))
            if source_id:
                valid_outcome_projection_ids.add(source_id)

    checked = 0
    missing = 0
    mismatch = 0

    for _, row in scorecard_df.iterrows():
        item = row.to_dict()
        checked += 1
        source_id = _text(item.get("source_projection_snapshot_id"))

        if not source_id:
            missing += 1
            continue

        if source_id not in valid_outcome_projection_ids:
            mismatch += 1

    return _lineage_result(
        checked=checked,
        missing=missing,
        mismatch=mismatch,
        duplicate=0,
    )


def _lineage_row(
    check: str,
    result: dict,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if result.get("passed") else "FAIL",
        "detail": (
            f"checked {_int(result.get('checked'))} · "
            f"missing {_int(result.get('missing'))} · "
            f"mismatch {_int(result.get('mismatch'))} · "
            f"duplicate {_int(result.get('duplicate'))}"
        ),
        "action": "" if result.get("passed") else action,
    }


def build_v129_projection_lineage_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    p_to_c = _projection_calibration_lineage(ctx)
    o_to_p = _outcome_projection_lineage(ctx)
    o_to_t = _outcome_trend_lineage(ctx)
    s_to_p = _scorecard_projection_lineage(ctx)
    s_to_o = _scorecard_outcome_lineage(ctx)

    checks = [
        _lineage_row(
            "Projection → Calibration Snapshot Lineage",
            p_to_c,
            "Projection source_calibration id/hash와 Calibration Snapshot 확인",
        ),
        _lineage_row(
            "Outcome → Projection Snapshot Lineage",
            o_to_p,
            "Outcome source_projection id/hash와 Projection Snapshot 확인",
        ),
        _lineage_row(
            "Outcome → Trend Evidence Endpoint Lineage",
            o_to_t,
            "Outcome evidence_end trend id/hash와 Trend Snapshot 확인",
        ),
        _lineage_row(
            "Scorecard → Projection Snapshot Lineage",
            s_to_p,
            "Scorecard source_projection id와 Projection Snapshot 확인",
        ),
        _lineage_row(
            "Scorecard → Outcome Evidence Availability",
            s_to_o,
            "Scorecard source Projection에 대응하는 valid Outcome history 확인",
        ),
    ]

    technical_fail = sum(
        1 for row in checks if row["status"] == "FAIL"
    )

    projection = ctx.get("current_projection") or {}
    outcome = ctx.get("current_outcome") or {}
    scorecard = ctx.get("current_scorecard") or {}

    p_state = _text(projection.get("projection_state")).upper()
    o_state = _text(outcome.get("evaluation_state")).upper()
    s_state = _text(scorecard.get("scorecard_state")).upper()

    operating_status = (
        "PASS"
        if (
            p_state == "READY_FOR_REVIEW"
            and o_state in {"WITHIN_REVIEW_BAND", "CLEARED_REVIEW"}
            and s_state == "MONITOR"
        )
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Projection Lineage Operating Stage",
            "status": operating_status,
            "detail": (
                f"projection {p_state or 'MISSING'} · "
                f"outcome {o_state or 'MISSING'} · "
                f"scorecard {s_state or 'MISSING'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "HOLD_HISTORY / SOURCE_REQUIRED / HISTORY_REQUIRED 같은 정상 대기 상태는 "
                    "lineage Technical FAIL로 취급하지 않음"
                )
            ),
        }
    )

    return {
        "release_gate": "PASS" if technical_fail == 0 else "BLOCKED",
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL" and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=PROJECTION_LINEAGE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v129_release_readiness(
    *,
    v128_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    projection_release_gate: str,
    lineage_release_gate: str,
    projection_operating_status: str,
    lineage_operating_status: str,
    execution_authorization: str,
) -> dict:
    v128 = _text(v128_release_status).upper()
    integration = _text(integration_consistency).upper()
    projection_gate = _text(projection_release_gate).upper()
    lineage_gate = _text(lineage_release_gate).upper()
    execution = _text(execution_authorization).upper()
    csv_fail = _int(csv_fail_count)

    checks = [
        _candidate_row(
            "v1.28 Flow Release Baseline",
            v128 == "READY_FOR_RELEASE_REVIEW",
            v128 or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Governance Technical Release Gate",
            projection_gate == "PASS",
            projection_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Lineage Integrity Gate",
            lineage_gate == "PASS",
            lineage_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(projection_operating_status).upper() != "PASS"
        or _text(lineage_operating_status).upper() != "PASS"
    ):
        operating_reviews.append(
            "PROJECTION_GOVERNANCE_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(operating_reviews),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V129_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v129_integration_crosscheck(
    *,
    integration_consistency: str,
    projection_release_gate: str,
    lineage_release_gate: str,
) -> dict:
    integration = _text(integration_consistency).upper()
    projection_gate = _text(projection_release_gate).upper()
    lineage_gate = _text(lineage_release_gate).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Projection Governance Technical Gate",
            projection_gate == "PASS",
            projection_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Lineage Integrity Gate",
            lineage_gate == "PASS",
            lineage_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V129_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v129_data_crosscheck(
    *,
    csv_fail_count: int,
    projection_release_gate: str,
    lineage_release_gate: str,
    latest_projection_integrity: str,
    latest_outcome_integrity: str,
    latest_scorecard_integrity: str,
) -> dict:
    csv_fail = _int(csv_fail_count)
    projection_gate = _text(projection_release_gate).upper()
    lineage_gate = _text(lineage_release_gate).upper()
    latest_projection = _text(latest_projection_integrity).upper()
    latest_outcome = _text(latest_outcome_integrity).upper()
    latest_scorecard = _text(latest_scorecard_integrity).upper()

    latest_ok = (
        latest_projection in {"OK", "NONE"}
        and latest_outcome in {"OK", "NONE"}
        and latest_scorecard in {"OK", "NONE"}
    )

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Projection Governance Technical Gate",
            projection_gate == "PASS",
            projection_gate or "MISSING",
        ),
        _candidate_row(
            "Projection Lineage Integrity Gate",
            lineage_gate == "PASS",
            lineage_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Projection Governance Snapshot Integrity",
            latest_ok,
            (
                f"projection {latest_projection or 'MISSING'} · "
                f"outcome {latest_outcome or 'MISSING'} · "
                f"scorecard {latest_scorecard or 'MISSING'}"
            ),
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V129_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
