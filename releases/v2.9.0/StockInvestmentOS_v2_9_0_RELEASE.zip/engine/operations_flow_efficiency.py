from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


FLOW_SNAPSHOT_COLS = [
    "flow_snapshot_id",
    "created_at",
    "current_group_count",
    "current_attention_count",
    "new_groups",
    "persisting_groups",
    "exited_groups",
    "attention_new",
    "attention_persisting",
    "attention_exited",
    "backlog_delta",
    "attention_delta",
    "queue_exit_rate",
    "persistence_rate",
    "burn_down_status",
    "capacity",
    "capacity_pressure",
    "current_group_ids_json",
    "current_attention_ids_json",
    "root_cause_counts_json",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


FLOW_DETAIL_COLS = [
    "group_id",
    "flow_status",
    "priority",
    "category",
    "root_cause",
    "item_count",
    "subject_count",
    "age_days",
    "closed_sessions_seen",
    "sla_status",
    "go_to",
]


FLOW_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _json_list(value: Any) -> list[str]:
    raw = _text(value)
    if not raw:
        return []

    try:
        parsed = json.loads(raw)
    except Exception:
        return []

    if not isinstance(parsed, list):
        return []

    out = []
    for item in parsed:
        text = _text(item)
        if text and text not in out:
            out.append(text)
    return out


def _json_dict(value: Any) -> dict:
    raw = _text(value)
    if not raw:
        return {}

    try:
        parsed = json.loads(raw)
    except Exception:
        return {}

    return parsed if isinstance(parsed, dict) else {}


def _snapshot_payload(row: dict) -> dict:
    return {
        "current_group_count": _int(row.get("current_group_count")),
        "current_attention_count": _int(row.get("current_attention_count")),
        "new_groups": _int(row.get("new_groups")),
        "persisting_groups": _int(row.get("persisting_groups")),
        "exited_groups": _int(row.get("exited_groups")),
        "attention_new": _int(row.get("attention_new")),
        "attention_persisting": _int(row.get("attention_persisting")),
        "attention_exited": _int(row.get("attention_exited")),
        "backlog_delta": _int(row.get("backlog_delta")),
        "attention_delta": _int(row.get("attention_delta")),
        "queue_exit_rate": round(_float(row.get("queue_exit_rate")), 10),
        "persistence_rate": round(_float(row.get("persistence_rate")), 10),
        "burn_down_status": _text(row.get("burn_down_status")),
        "capacity": _int(row.get("capacity")),
        "capacity_pressure": round(_float(row.get("capacity_pressure")), 10),
        "current_group_ids_json": _text(row.get("current_group_ids_json")),
        "current_attention_ids_json": _text(row.get("current_attention_ids_json")),
        "root_cause_counts_json": _text(row.get("root_cause_counts_json")),
        "execution_authorization": _text(row.get("execution_authorization")),
    }


def flow_snapshot_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(record.get("snapshot_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_snapshot_payload(record))

    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def latest_flow_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    if snapshots is None or snapshots.empty:
        return {}

    df = snapshots.copy()

    if "created_at" in df.columns:
        df["_ts"] = pd.to_datetime(
            df["created_at"],
            errors="coerce",
            utc=True,
        )
        df = df.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        df.iloc[0]
        .drop(
            labels=["_ts"],
            errors="ignore",
        )
        .to_dict()
    )


def build_flow_diagnostics(
    recurrence_table: pd.DataFrame | None,
    previous_snapshot: dict | None,
    *,
    capacity: int = 5,
) -> dict:
    df = (
        pd.DataFrame()
        if recurrence_table is None
        else recurrence_table.copy()
    )
    prev = previous_snapshot or {}

    required = [
        "group_id",
        "priority",
        "category",
        "root_cause",
        "item_count",
        "subject_count",
        "age_days",
        "closed_sessions_seen",
        "sla_status",
        "go_to",
    ]

    for col in required:
        if col not in df.columns:
            df[col] = ""

    current_ids = []
    current_attention_ids = []

    if not df.empty:
        for group_id in df["group_id"].tolist():
            text = _text(group_id)
            if text and text not in current_ids:
                current_ids.append(text)

        attention_mask = (
            df["priority"]
            .fillna("")
            .astype(str)
            .str.upper()
            .isin(["RQ0", "RQ1"])
        )

        for group_id in df.loc[
            attention_mask,
            "group_id",
        ].tolist():
            text = _text(group_id)
            if text and text not in current_attention_ids:
                current_attention_ids.append(text)

    prev_ids = _json_list(
        prev.get("current_group_ids_json")
    )
    prev_attention_ids = _json_list(
        prev.get("current_attention_ids_json")
    )

    current_set = set(current_ids)
    prev_set = set(prev_ids)
    current_attention_set = set(current_attention_ids)
    prev_attention_set = set(prev_attention_ids)

    if not prev:
        new_set = set(current_ids)
        persisting_set = set()
        exited_set = set()
        attention_new_set = set(current_attention_ids)
        attention_persisting_set = set()
        attention_exited_set = set()
        burn_down_status = "FIRST_SNAPSHOT"
        backlog_delta = 0
        attention_delta = 0
        queue_exit_rate = 0.0
        persistence_rate = 0.0
    else:
        new_set = current_set - prev_set
        persisting_set = current_set & prev_set
        exited_set = prev_set - current_set

        attention_new_set = current_attention_set - prev_attention_set
        attention_persisting_set = current_attention_set & prev_attention_set
        attention_exited_set = prev_attention_set - current_attention_set

        backlog_delta = len(current_set) - len(prev_set)
        attention_delta = len(current_attention_set) - len(prev_attention_set)

        queue_exit_rate = (
            len(exited_set) / len(prev_set)
            if prev_set
            else 0.0
        )
        persistence_rate = (
            len(persisting_set) / len(prev_set)
            if prev_set
            else 0.0
        )

        if backlog_delta < 0 and len(exited_set) > len(new_set):
            burn_down_status = "IMPROVING"
        elif backlog_delta > 0 and len(new_set) > len(exited_set):
            burn_down_status = "GROWING"
        elif (
            backlog_delta == 0
            and len(new_set) == 0
            and len(exited_set) == 0
        ):
            burn_down_status = "STALLED"
        else:
            burn_down_status = "MIXED"

    root_cause_counts = {}
    if not df.empty:
        for cause, part in df.groupby(
            "root_cause",
            dropna=False,
        ):
            key = _text(cause) or "UNCLASSIFIED"
            root_cause_counts[key] = int(len(part))

    detail_rows = []

    if not df.empty:
        for _, row in df.iterrows():
            group_id = _text(row.get("group_id"))

            if not prev:
                flow_status = "NEW_BASELINE"
            elif group_id in new_set:
                flow_status = "NEW"
            elif group_id in persisting_set:
                flow_status = "PERSISTING"
            else:
                flow_status = "CURRENT"

            detail_rows.append(
                {
                    "group_id": group_id,
                    "flow_status": flow_status,
                    "priority": _text(row.get("priority")),
                    "category": _text(row.get("category")),
                    "root_cause": _text(row.get("root_cause")),
                    "item_count": _int(row.get("item_count")),
                    "subject_count": _int(row.get("subject_count")),
                    "age_days": _int(row.get("age_days")),
                    "closed_sessions_seen": _int(
                        row.get("closed_sessions_seen")
                    ),
                    "sla_status": _text(row.get("sla_status")),
                    "go_to": _text(row.get("go_to")),
                }
            )

    # Include exited groups as audit rows even though they are no longer in current queue.
    for group_id in sorted(exited_set):
        detail_rows.append(
            {
                "group_id": group_id,
                "flow_status": "EXITED_CURRENT_QUEUE",
                "priority": "",
                "category": "",
                "root_cause": "",
                "item_count": 0,
                "subject_count": 0,
                "age_days": 0,
                "closed_sessions_seen": 0,
                "sla_status": "",
                "go_to": "",
            }
        )

    capacity_value = max(1, _int(capacity))
    capacity_pressure = (
        len(current_attention_ids) / capacity_value
    )

    return {
        "current_group_count": len(current_ids),
        "current_attention_count": len(current_attention_ids),
        "new_groups": len(new_set),
        "persisting_groups": len(persisting_set),
        "exited_groups": len(exited_set),
        "attention_new": len(attention_new_set),
        "attention_persisting": len(attention_persisting_set),
        "attention_exited": len(attention_exited_set),
        "backlog_delta": backlog_delta,
        "attention_delta": attention_delta,
        "queue_exit_rate": float(queue_exit_rate),
        "persistence_rate": float(persistence_rate),
        "burn_down_status": burn_down_status,
        "capacity": capacity_value,
        "capacity_pressure": float(capacity_pressure),
        "current_group_ids": current_ids,
        "current_attention_ids": current_attention_ids,
        "root_cause_counts": root_cause_counts,
        "details": pd.DataFrame(
            detail_rows,
            columns=FLOW_DETAIL_COLS,
        ),
        "previous_snapshot_integrity": (
            flow_snapshot_integrity(prev)["status"]
            if prev
            else "NONE"
        ),
        "execution_authorization": "NONE",
    }


def build_flow_queue(
    diagnostics: dict | None,
) -> pd.DataFrame:
    result = diagnostics or {}
    rows = []

    previous_integrity = _text(
        result.get("previous_snapshot_integrity")
    ).upper()

    if previous_integrity not in {"OK", "NONE"}:
        rows.append(
            {
                "priority": "FL0",
                "status": "BLOCKED",
                "issue": "PREVIOUS_FLOW_SNAPSHOT_INTEGRITY",
                "detail": previous_integrity,
                "next_action": "이전 Operations Flow Snapshot hash를 먼저 확인",
                "go_to": "Operations Control Tower",
            }
        )

    burn = _text(
        result.get("burn_down_status")
    ).upper()

    if burn == "GROWING":
        rows.append(
            {
                "priority": "FL1",
                "status": "REVIEW",
                "issue": "BACKLOG_GROWING",
                "detail": (
                    f"delta {_int(result.get('backlog_delta'))} · "
                    f"new {_int(result.get('new_groups'))} · "
                    f"exited {_int(result.get('exited_groups'))}"
                ),
                "next_action": "새 유입이 Queue Exit보다 많은 원인을 Root Cause별로 검토",
                "go_to": "Review Queue",
            }
        )
    elif burn == "STALLED" and _int(result.get("current_group_count")) > 0:
        rows.append(
            {
                "priority": "FL2",
                "status": "REVIEW",
                "issue": "BACKLOG_STALLED",
                "detail": (
                    f"current {_int(result.get('current_group_count'))} · "
                    "new 0 · exited 0"
                ),
                "next_action": "반복되는 Action Group의 원본 Review를 우선 검토",
                "go_to": "Review Queue",
            }
        )

    if _int(result.get("attention_delta")) > 0:
        rows.append(
            {
                "priority": "FL1",
                "status": "REVIEW",
                "issue": "ATTENTION_BACKLOG_GROWING",
                "detail": (
                    f"attention delta +{_int(result.get('attention_delta'))}"
                ),
                "next_action": "RQ0/RQ1 신규 유입과 Exit를 먼저 확인",
                "go_to": "Operations Control Tower",
            }
        )

    if _float(result.get("capacity_pressure")) > 1.0:
        rows.append(
            {
                "priority": "FL2",
                "status": "REVIEW",
                "issue": "CAPACITY_PRESSURE_ABOVE_1X",
                "detail": (
                    f"attention {_int(result.get('current_attention_count'))} / "
                    f"capacity {_int(result.get('capacity'))} = "
                    f"{_float(result.get('capacity_pressure')):.2f}x"
                ),
                "next_action": "Session Worklist 5개 우선순위와 Carry-forward를 검토",
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=FLOW_QUEUE_COLS
        )

    order = {
        "FL0": 0,
        "FL1": 1,
        "FL2": 2,
    }

    out = pd.DataFrame(rows)
    out["_p"] = out["priority"].map(order).fillna(9)

    return (
        out.sort_values(
            ["_p", "issue"]
        )
        .drop(columns=["_p"])[FLOW_QUEUE_COLS]
        .reset_index(drop=True)
    )


def build_flow_snapshot(
    diagnostics: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(created_at)
        or datetime.now().astimezone().isoformat()
    )

    payload = {
        "current_group_count": _int(
            diagnostics.get("current_group_count")
        ),
        "current_attention_count": _int(
            diagnostics.get("current_attention_count")
        ),
        "new_groups": _int(
            diagnostics.get("new_groups")
        ),
        "persisting_groups": _int(
            diagnostics.get("persisting_groups")
        ),
        "exited_groups": _int(
            diagnostics.get("exited_groups")
        ),
        "attention_new": _int(
            diagnostics.get("attention_new")
        ),
        "attention_persisting": _int(
            diagnostics.get("attention_persisting")
        ),
        "attention_exited": _int(
            diagnostics.get("attention_exited")
        ),
        "backlog_delta": _int(
            diagnostics.get("backlog_delta")
        ),
        "attention_delta": _int(
            diagnostics.get("attention_delta")
        ),
        "queue_exit_rate": round(
            _float(diagnostics.get("queue_exit_rate")),
            10,
        ),
        "persistence_rate": round(
            _float(diagnostics.get("persistence_rate")),
            10,
        ),
        "burn_down_status": _text(
            diagnostics.get("burn_down_status")
        ),
        "capacity": _int(
            diagnostics.get("capacity")
        ),
        "capacity_pressure": round(
            _float(diagnostics.get("capacity_pressure")),
            10,
        ),
        "current_group_ids_json": json.dumps(
            diagnostics.get("current_group_ids", []),
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "current_attention_ids_json": json.dumps(
            diagnostics.get("current_attention_ids", []),
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "root_cause_counts_json": json.dumps(
            diagnostics.get("root_cause_counts", {}),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(payload)

    return {
        "flow_snapshot_id": (
            "OFL-"
            + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **payload,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }
