from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json
import math

import pandas as pd

from engine.operations_flow_calibration import (
    flow_calibration_snapshot_integrity,
)


FLOW_PROJECTION_SNAPSHOT_COLS = [
    "projection_snapshot_id",
    "created_at",
    "source_calibration_snapshot_id",
    "source_calibration_hash",
    "source_calibration_integrity",
    "source_freshness",
    "source_mismatch_count",
    "current_groups",
    "attention_groups",
    "capacity",
    "observed_intervals",
    "positive_burn_ratio",
    "base_burn_rate",
    "stress_burn_rate",
    "zero_arrival_burn_rate",
    "base_clearance_intervals",
    "stress_clearance_intervals",
    "zero_arrival_clearance_intervals",
    "calibration_state",
    "projection_guard",
    "projection_state",
    "projection_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]

PROJECTION_SCENARIO_COLS = [
    "scenario",
    "burn_rate_per_interval",
    "clearance_intervals",
    "assumption",
    "interpretation",
]

PROJECTION_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


_COMPARE_INT_FIELDS = [
    "saved_trend_snapshots",
    "invalid_trend_snapshots",
    "observed_intervals",
    "current_groups",
    "attention_groups",
    "capacity",
    "positive_burn_intervals",
    "zero_burn_intervals",
    "negative_burn_intervals",
]

_COMPARE_FLOAT_FIELDS = [
    "avg_arrivals_per_interval",
    "avg_exits_per_interval",
    "avg_net_burn_per_interval",
    "positive_burn_ratio",
    "exit_per_capacity",
    "attention_pressure",
    "backlog_pressure",
    "root_cause_concentration",
]

_COMPARE_TEXT_FIELDS = [
    "top_root_cause",
    "calibration_state",
    "projection_guard",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _optional_float(value: Any) -> float | None:
    text = _text(value)
    if not text:
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def _round_optional(value: Any) -> float | None:
    out = _optional_float(value)
    if out is None:
        return None
    return round(out, 10)


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _clearance_intervals(
    group_count: int,
    burn_rate: float,
) -> int | None:
    groups = max(0, int(group_count))
    rate = float(burn_rate)

    if groups == 0:
        return 0

    if rate <= 0:
        return None

    return int(
        math.ceil(
            float(groups) / rate
        )
    )


def calibration_source_freshness(
    calibration: dict | None,
    source_snapshot: dict | None,
    *,
    float_tolerance: float = 1e-8,
) -> dict:
    current = calibration or {}
    source = source_snapshot or {}

    if not source:
        return {
            "status": "MISSING",
            "source_integrity": "NONE",
            "mismatches": [],
            "mismatch_count": 0,
        }

    integrity = flow_calibration_snapshot_integrity(
        source
    )
    integrity_status = _text(
        integrity.get("status")
    ).upper()

    if integrity_status != "OK":
        return {
            "status": "INVALID",
            "source_integrity": integrity_status or "INVALID",
            "mismatches": ["snapshot_hash"],
            "mismatch_count": 1,
        }

    mismatches = []

    for field in _COMPARE_INT_FIELDS:
        if _int(current.get(field)) != _int(source.get(field)):
            mismatches.append(field)

    for field in _COMPARE_FLOAT_FIELDS:
        left = _float(current.get(field))
        right = _float(source.get(field))
        if abs(left - right) > float(float_tolerance):
            mismatches.append(field)

    for field in _COMPARE_TEXT_FIELDS:
        if _text(current.get(field)) != _text(source.get(field)):
            mismatches.append(field)

    return {
        "status": "CURRENT" if not mismatches else "DRIFTED",
        "source_integrity": "OK",
        "mismatches": mismatches,
        "mismatch_count": len(mismatches),
    }


def build_flow_projection(
    calibration: dict | None,
    source_calibration_snapshot: dict | None,
    *,
    stress_burn_haircut: float = 0.50,
    admission: dict | None = None,
) -> dict:
    current = calibration or {}
    source = source_calibration_snapshot or {}

    freshness = calibration_source_freshness(
        current,
        source,
    )

    source_integrity = _text(
        freshness.get(
            "source_integrity"
        )
    ).upper()
    source_freshness = _text(
        freshness.get(
            "status"
        )
    ).upper()

    admission_state = _text(
        (admission or {}).get(
            "admission_state"
        )
    ).upper()

    calibration_state = _text(
        current.get(
            "calibration_state"
        )
    ).upper()
    projection_guard = _text(
        current.get(
            "projection_guard"
        )
    ).upper()

    current_groups = _int(
        current.get(
            "current_groups"
        )
    )
    attention_groups = _int(
        current.get(
            "attention_groups"
        )
    )
    capacity = max(
        1,
        _int(
            current.get(
                "capacity"
            )
        ),
    )
    observed_intervals = _int(
        current.get(
            "observed_intervals"
        )
    )
    positive_burn_ratio = _float(
        current.get(
            "positive_burn_ratio"
        )
    )
    base_burn_rate = _float(
        current.get(
            "avg_net_burn_per_interval"
        )
    )
    zero_arrival_burn_rate = max(
        0.0,
        _float(
            current.get(
                "avg_exits_per_interval"
            )
        ),
    )

    haircut = min(
        1.0,
        max(
            0.0,
            float(
                stress_burn_haircut
            ),
        ),
    )
    stress_burn_rate = max(
        0.0,
        base_burn_rate * haircut,
    )

    if source_freshness == "MISSING":
        projection_state = "SOURCE_CALIBRATION_REQUIRED"
        effective_guard = "HOLD_SOURCE"
    elif source_freshness == "INVALID":
        projection_state = "SOURCE_CALIBRATION_INTEGRITY_REVIEW"
        effective_guard = "HOLD_SOURCE_INTEGRITY"
    elif source_freshness == "DRIFTED":
        projection_state = "SOURCE_CALIBRATION_DRIFT_REVIEW"
        effective_guard = "HOLD_SOURCE_DRIFT"
    elif (
        admission_state
        and admission_state
        not in {
            "ADMISSION_UPSTREAM_HOLD",
            "ADMISSION_READY_FOR_REVIEW",
        }
    ):
        projection_state = "HOLD_ADMISSION_SOURCE"
        effective_guard = "HOLD_ADMISSION_SOURCE"
    elif projection_guard != "ALLOW_PROJECTION_REVIEW":
        projection_state = projection_guard or "HOLD_CALIBRATION"
        effective_guard = projection_guard or "HOLD_CALIBRATION"
    elif base_burn_rate <= 0:
        projection_state = "HOLD_NO_CLEARING"
        effective_guard = "HOLD_NO_CLEARING"
    else:
        projection_state = "READY_FOR_REVIEW"
        effective_guard = "ALLOW_PROJECTION_REVIEW"

    scenario_rows = []
    if projection_state == "READY_FOR_REVIEW":
        scenarios = [
            {
                "scenario": "STRESS_HALF_OBSERVED_BURN",
                "burn_rate_per_interval": stress_burn_rate,
                "assumption": (
                    "observed average net burn에 50% haircut을 적용한 "
                    "민감도 시나리오"
                ),
                "interpretation": (
                    "보수적 운영 민감도이며 통계적 신뢰구간이나 보장이 아님"
                ),
            },
            {
                "scenario": "BASE_OBSERVED_BURN",
                "burn_rate_per_interval": base_burn_rate,
                "assumption": (
                    "검증된 Calibration의 평균 Exit-Arrival net burn을 "
                    "단순 연장"
                ),
                "interpretation": (
                    "현재 관측 평균의 기계적 연장이며 미래 성과 보장이 아님"
                ),
            },
            {
                "scenario": "ZERO_ARRIVAL_MECHANICAL",
                "burn_rate_per_interval": zero_arrival_burn_rate,
                "assumption": (
                    "신규 Arrival이 0이고 현재 평균 Exit 속도만 유지된다는 "
                    "기계적 상한 시나리오"
                ),
                "interpretation": (
                    "낙관적 운영 경계값이며 실제 Arrival 0을 예상한다는 뜻이 아님"
                ),
            },
        ]

        for row in scenarios:
            rate = float(
                row[
                    "burn_rate_per_interval"
                ]
            )
            scenario_rows.append(
                {
                    **row,
                    "clearance_intervals":
                        _clearance_intervals(
                            current_groups,
                            rate,
                        ),
                }
            )

    scenario_table = pd.DataFrame(
        scenario_rows,
        columns=PROJECTION_SCENARIO_COLS,
    )

    base_clearance = (
        _clearance_intervals(
            current_groups,
            base_burn_rate,
        )
        if projection_state == "READY_FOR_REVIEW"
        else None
    )
    stress_clearance = (
        _clearance_intervals(
            current_groups,
            stress_burn_rate,
        )
        if projection_state == "READY_FOR_REVIEW"
        else None
    )
    zero_arrival_clearance = (
        _clearance_intervals(
            current_groups,
            zero_arrival_burn_rate,
        )
        if projection_state == "READY_FOR_REVIEW"
        else None
    )

    snapshot_eligible = (
        source_freshness == "CURRENT"
        and source_integrity == "OK"
    )

    return {
        "source_calibration_snapshot_id":
            _text(
                source.get(
                    "calibration_snapshot_id"
                )
            ),
        "source_calibration_hash":
            _text(
                source.get(
                    "snapshot_hash"
                )
            ),
        "source_calibration_integrity":
            source_integrity,
        "source_freshness":
            source_freshness,
        "source_mismatches":
            list(
                freshness.get(
                    "mismatches",
                    [],
                )
            ),
        "source_mismatch_count":
            _int(
                freshness.get(
                    "mismatch_count"
                )
            ),
        "current_groups":
            current_groups,
        "attention_groups":
            attention_groups,
        "capacity":
            capacity,
        "observed_intervals":
            observed_intervals,
        "positive_burn_ratio":
            positive_burn_ratio,
        "base_burn_rate":
            base_burn_rate,
        "stress_burn_rate":
            stress_burn_rate,
        "zero_arrival_burn_rate":
            zero_arrival_burn_rate,
        "base_clearance_intervals":
            base_clearance,
        "stress_clearance_intervals":
            stress_clearance,
        "zero_arrival_clearance_intervals":
            zero_arrival_clearance,
        "calibration_state":
            calibration_state,
        "projection_guard":
            effective_guard,
        "projection_state":
            projection_state,
        "scenario_table":
            scenario_table,
        "snapshot_eligible":
            snapshot_eligible,
        "projection_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }


def build_flow_projection_queue(
    projection: dict | None,
) -> pd.DataFrame:
    result = projection or {}
    state = _text(
        result.get(
            "projection_state"
        )
    ).upper()

    rows = []

    if state == "SOURCE_CALIBRATION_INTEGRITY_REVIEW":
        rows.append(
            {
                "priority": "FP0",
                "status": "BLOCKED",
                "issue": "FLOW_PROJECTION_SOURCE_INTEGRITY",
                "detail": "saved Calibration Snapshot hash mismatch",
                "next_action": (
                    "Operations Control Tower 1H에서 Calibration Snapshot "
                    "integrity를 먼저 확인"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "SOURCE_CALIBRATION_DRIFT_REVIEW":
        mismatches = result.get(
            "source_mismatches",
            [],
        )
        rows.append(
            {
                "priority": "FP0",
                "status": "BLOCKED",
                "issue": "FLOW_PROJECTION_SOURCE_DRIFT",
                "detail": (
                    "live vs saved calibration drift · "
                    + ", ".join(
                        str(x)
                        for x in mismatches[:6]
                    )
                ),
                "next_action": (
                    "현재 Calibration을 다시 검토하고 새 Calibration Snapshot을 저장"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "SOURCE_CALIBRATION_REQUIRED":
        rows.append(
            {
                "priority": "FP1",
                "status": "REVIEW",
                "issue": "FLOW_PROJECTION_SOURCE_REQUIRED",
                "detail": "verified Calibration Snapshot 없음",
                "next_action": (
                    "Operations Control Tower 1H에서 현재 Calibration Snapshot을 저장"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state.startswith("HOLD_"):
        rows.append(
            {
                "priority": "FP1",
                "status": "REVIEW",
                "issue": "FLOW_PROJECTION_GUARD_HOLD",
                "detail": state,
                "next_action": (
                    "Projection Guard 해제 조건을 억지로 변경하지 말고 실제 Flow history를 추가 축적"
                ),
                "go_to": "Operations Control Tower",
            }
        )
    elif state == "READY_FOR_REVIEW":
        rows.append(
            {
                "priority": "FP2",
                "status": "REVIEW",
                "issue": "FLOW_PROJECTION_REVIEW_READY",
                "detail": (
                    f"base clearance "
                    f"{_text(result.get('base_clearance_intervals')) or '-'} intervals"
                ),
                "next_action": (
                    "Stress/Base/Zero-arrival 시나리오와 원본 Root Cause를 Human Review"
                ),
                "go_to": "Operations Control Tower",
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=PROJECTION_QUEUE_COLS
        )

    order = {
        "FP0": 0,
        "FP1": 1,
        "FP2": 2,
    }
    out = pd.DataFrame(
        rows,
        columns=PROJECTION_QUEUE_COLS,
    )
    out["_p"] = out["priority"].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            ["_p", "issue"]
        )
        .drop(
            columns=["_p"]
        )
        .reset_index(
            drop=True
        )
    )


def _snapshot_payload(
    row: dict,
) -> dict:
    return {
        "source_calibration_snapshot_id":
            _text(
                row.get(
                    "source_calibration_snapshot_id"
                )
            ),
        "source_calibration_hash":
            _text(
                row.get(
                    "source_calibration_hash"
                )
            ),
        "source_calibration_integrity":
            _text(
                row.get(
                    "source_calibration_integrity"
                )
            ),
        "source_freshness":
            _text(
                row.get(
                    "source_freshness"
                )
            ),
        "source_mismatch_count":
            _int(
                row.get(
                    "source_mismatch_count"
                )
            ),
        "current_groups":
            _int(
                row.get(
                    "current_groups"
                )
            ),
        "attention_groups":
            _int(
                row.get(
                    "attention_groups"
                )
            ),
        "capacity":
            _int(
                row.get(
                    "capacity"
                )
            ),
        "observed_intervals":
            _int(
                row.get(
                    "observed_intervals"
                )
            ),
        "positive_burn_ratio":
            round(
                _float(
                    row.get(
                        "positive_burn_ratio"
                    )
                ),
                10,
            ),
        "base_burn_rate":
            round(
                _float(
                    row.get(
                        "base_burn_rate"
                    )
                ),
                10,
            ),
        "stress_burn_rate":
            round(
                _float(
                    row.get(
                        "stress_burn_rate"
                    )
                ),
                10,
            ),
        "zero_arrival_burn_rate":
            round(
                _float(
                    row.get(
                        "zero_arrival_burn_rate"
                    )
                ),
                10,
            ),
        "base_clearance_intervals":
            _round_optional(
                row.get(
                    "base_clearance_intervals"
                )
            ),
        "stress_clearance_intervals":
            _round_optional(
                row.get(
                    "stress_clearance_intervals"
                )
            ),
        "zero_arrival_clearance_intervals":
            _round_optional(
                row.get(
                    "zero_arrival_clearance_intervals"
                )
            ),
        "calibration_state":
            _text(
                row.get(
                    "calibration_state"
                )
            ),
        "projection_guard":
            _text(
                row.get(
                    "projection_guard"
                )
            ),
        "projection_state":
            _text(
                row.get(
                    "projection_state"
                )
            ),
        "projection_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }


def flow_projection_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "expected_hash": "",
            "actual_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(
            row,
            pd.Series,
        )
        else dict(
            row
        )
    )

    actual = _text(
        item.get(
            "snapshot_hash"
        )
    )
    expected = _hash(
        _snapshot_payload(
            item
        )
    )

    return {
        "status":
            (
                "OK"
                if actual
                and actual == expected
                else "MISMATCH"
            ),
        "expected_hash":
            expected,
        "actual_hash":
            actual,
    }


def latest_flow_projection_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PROJECTION_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    created = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        created.notna()
    ].copy()

    if valid.empty:
        return {}

    valid["_created"] = created.loc[
        valid.index
    ]

    row = (
        valid.sort_values(
            "_created"
        )
        .iloc[-1]
        .drop(
            labels=[
                "_created"
            ]
        )
    )

    return row.to_dict()


def build_flow_projection_snapshot(
    projection: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    if not bool(
        projection.get(
            "snapshot_eligible"
        )
    ):
        raise ValueError(
            "Projection Snapshot은 CURRENT + integrity OK인 "
            "Calibration source에서만 저장할 수 있습니다."
        )

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    payload = _snapshot_payload(
        projection
    )
    snapshot_hash = _hash(
        payload
    )

    return {
        "projection_snapshot_id":
            (
                "OFP-"
                + pd.Timestamp(
                    now
                ).strftime(
                    "%Y%m%dT%H%M%S"
                )
                + "-"
                + snapshot_hash[:8]
            ),
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
