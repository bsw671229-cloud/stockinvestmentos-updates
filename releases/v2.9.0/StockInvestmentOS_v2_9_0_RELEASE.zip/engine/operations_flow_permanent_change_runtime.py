from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_permanent_change_apply import (
    permanent_change_apply_snapshot_integrity,
    latest_permanent_change_apply_snapshot,
)


FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS = [
    "permanent_change_runtime_event_id",
    "created_at",
    "runtime_event",
    "runtime_state",
    "runtime_guard",
    "source_permanent_change_apply_id",
    "source_permanent_change_apply_hash",
    "source_permanent_change_apply_created_at",
    "source_permanent_change_apply_integrity",
    "source_permanent_change_design_id",
    "source_permanent_change_design_hash",
    "source_live_change_closure_id",
    "source_live_change_closure_hash",
    "source_live_change_outcome_id",
    "source_live_change_outcome_hash",
    "source_runtime_event_id",
    "source_runtime_event_hash",
    "source_live_change_apply_id",
    "source_live_change_apply_hash",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "permanent_change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "permit_stage_number",
    "permit_scope_pct",
    "permit_activation_window_hours",
    "permit_min_post_change_outcomes",
    "permit_max_relative_error_degradation_pct",
    "permit_rollback_observation_hours",
    "activation_receipt_ref",
    "observed_pre_value",
    "observed_post_value",
    "observed_current_value",
    "observed_restored_value",
    "kill_switch_trigger",
    "runtime_detail",
    "external_manual_activation_confirmed",
    "source_permit_reviewed",
    "baseline_observation_confirmed",
    "candidate_observation_confirmed",
    "scope_isolation_confirmed",
    "monitoring_active_confirmed",
    "no_auto_stage_escalation_confirmed",
    "no_auto_permanent_apply_confirmed",
    "rollback_initiated_confirmed",
    "rollback_completed_confirmed",
    "baseline_restore_confirmed",
    "human_review_confirmed",
    "permanent_change_runtime_permission",
    "permanent_change_design_authorization",
    "permanent_change_apply_authorization",
    "permanent_change_runtime_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


PERMANENT_CHANGE_RUNTIME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


PERMANENT_CHANGE_RUNTIME_STATES = {
    "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT",
    "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
    "PERMANENT_CHANGE_RUNTIME_DEFERRED",
    "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
    "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
    "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION",
    "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
    "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
    "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
    "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
    "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
}


PERMANENT_CHANGE_RUNTIME_GUARD_BY_STATE = {
    "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT":
        "HOLD_PERMANENT_CHANGE_APPLY",
    "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED":
        "NO_PERMANENT_CHANGE_RUNTIME",
    "PERMANENT_CHANGE_RUNTIME_DEFERRED":
        "HOLD_PERMANENT_CHANGE_RUNTIME",
    "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED":
        "HOLD_PERMANENT_CHANGE_APPLY_SOURCE",
    "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW":
        "HOLD_PERMANENT_CHANGE_RUNTIME_INTEGRITY",
    "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION":
        "MANUAL_STAGE1_ACTIVATION_READY_NO_AUTO_APPLY",
    "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1":
        "MANUAL_STAGE1_ACTIVE_ROLLBACK_ARMED",
    "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED":
        "STAGE1_CLOSED_NO_AUTO_STAGE2",
    "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED":
        "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
    "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED":
        "ROLLBACK_CONFIRMED_NO_REACTIVATION",
    "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED":
        "HOLD_PERMANENT_CHANGE_RUNTIME_SOURCE",
}


PERMANENT_CHANGE_RUNTIME_EVENTS = {
    "ACTIVATE",
    "CLOSE",
    "KILL_SWITCH",
    "ROLLBACK_CONFIRM",
}


PERMANENT_CHANGE_KILL_TRIGGERS = {
    "ERROR_DEGRADATION",
    "ASSUMPTION_DRIFT",
    "INTEGRITY_FAILURE",
    "BASELINE_DRIFT",
    "CANDIDATE_MISMATCH",
    "SCOPE_ISOLATION_FAILURE",
    "SOURCE_SUPERSESSION",
    "MANUAL_RISK_STOP",
}


def _text(value: Any) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass

    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass

    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )

    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _runtime_payload(
    row: dict,
) -> dict:
    int_fields = {
        "permit_stage_number",
        "permit_activation_window_hours",
        "permit_min_post_change_outcomes",
        "permit_rollback_observation_hours",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "permit_scope_pct",
        "permit_max_relative_error_degradation_pct",
        "observed_pre_value",
        "observed_post_value",
        "observed_current_value",
        "observed_restored_value",
    }

    bool_fields = {
        "external_manual_activation_confirmed",
        "source_permit_reviewed",
        "baseline_observation_confirmed",
        "candidate_observation_confirmed",
        "scope_isolation_confirmed",
        "monitoring_active_confirmed",
        "no_auto_stage_escalation_confirmed",
        "no_auto_permanent_apply_confirmed",
        "rollback_initiated_confirmed",
        "rollback_completed_confirmed",
        "baseline_restore_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
        if col in {
            "permanent_change_runtime_event_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def permanent_change_runtime_event_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(
            row,
            pd.Series,
        )
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _runtime_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_permanent_change_runtime_event(
    events: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if events is None
        else events.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values(
        "_ts"
    )

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _permit_source(
    permanent_change_apply: dict | None,
) -> dict:
    apply = permanent_change_apply or {}

    if _text(
        apply.get("apply_state")
    ).upper() != (
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
    ):
        return {}

    if _text(
        apply.get(
            "permanent_change_apply_permission"
        )
    ).upper() != "MANUAL_PERMANENT_STAGE1_APPLY_ONLY":
        return {}

    latest = apply.get(
        "latest_apply"
    ) or {}

    if not latest:
        return {}

    if _text(
        permanent_change_apply_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get("apply_decision")
    ).upper() != "ISSUE_MANUAL_STAGE1_APPLY_PERMIT":
        return {}

    if _text(
        latest.get(
            "permanent_change_apply_permission"
        )
    ).upper() != "MANUAL_PERMANENT_STAGE1_APPLY_ONLY":
        return {}

    return latest


def _event_matches_permit(
    event: dict,
    permit: dict,
) -> bool:
    if not event or not permit:
        return False

    if _text(
        permanent_change_runtime_event_integrity(
            event
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            event.get(
                "source_permanent_change_apply_id"
            )
        )
        == _text(
            permit.get(
                "permanent_change_apply_id"
            )
        )
        and _text(
            event.get(
                "source_permanent_change_apply_hash"
            )
        )
        == _text(
            permit.get(
                "snapshot_hash"
            )
        )
    )


def build_flow_permanent_change_runtime(
    permanent_change_apply: dict | None,
    apply_snapshots: pd.DataFrame | None,
    runtime_events: pd.DataFrame | None,
) -> dict:
    apply = permanent_change_apply or {}

    apply_state = _text(
        apply.get("apply_state")
    ).upper()

    base = {
        "runtime_event": "",
        "source_permanent_change_apply_id": "",
        "source_permanent_change_apply_hash": "",
        "source_permanent_change_apply_created_at": "",
        "source_permanent_change_apply_integrity": "NONE",
        "source_permanent_change_design_id": _text(
            apply.get(
                "source_permanent_change_design_id"
            )
        ),
        "source_permanent_change_design_hash": _text(
            apply.get(
                "source_permanent_change_design_hash"
            )
        ),
        "source_live_change_closure_id": _text(
            apply.get(
                "source_live_change_closure_id"
            )
        ),
        "source_live_change_closure_hash": _text(
            apply.get(
                "source_live_change_closure_hash"
            )
        ),
        "source_live_change_outcome_id": _text(
            apply.get(
                "source_live_change_outcome_id"
            )
        ),
        "source_live_change_outcome_hash": _text(
            apply.get(
                "source_live_change_outcome_hash"
            )
        ),
        "source_runtime_event_id": _text(
            apply.get(
                "source_runtime_event_id"
            )
        ),
        "source_runtime_event_hash": _text(
            apply.get(
                "source_runtime_event_hash"
            )
        ),
        "source_live_change_apply_id": _text(
            apply.get(
                "source_live_change_apply_id"
            )
        ),
        "source_live_change_apply_hash": _text(
            apply.get(
                "source_live_change_apply_hash"
            )
        ),
        "source_live_change_design_id": _text(
            apply.get(
                "source_live_change_design_id"
            )
        ),
        "source_live_change_design_hash": _text(
            apply.get(
                "source_live_change_design_hash"
            )
        ),
        "source_proposal_id": _text(
            apply.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            apply.get(
                "source_proposal_hash"
            )
        ),
        "proposal_scope": _text(
            apply.get("proposal_scope")
        ).upper(),
        "target_metric": _text(
            apply.get("target_metric")
        ).upper(),
        "permanent_change_mode": _text(
            apply.get(
                "permanent_change_mode"
            )
        ).upper(),
        "artifact_ref": _text(
            apply.get("artifact_ref")
        ),
        "baseline_value": _float(
            apply.get("baseline_value")
        ),
        "candidate_value": _float(
            apply.get("candidate_value")
        ),
        "rollback_target_value": _float(
            apply.get("rollback_target_value")
        ),
        "permit_stage_number": _int(
            apply.get("permit_stage_number")
        ),
        "permit_scope_pct": _float(
            apply.get("permit_scope_pct")
        ),
        "permit_activation_window_hours": _int(
            apply.get(
                "permit_activation_window_hours"
            )
        ),
        "permit_min_post_change_outcomes": _int(
            apply.get(
                "permit_min_post_change_outcomes"
            )
        ),
        "permit_max_relative_error_degradation_pct": _float(
            apply.get(
                "permit_max_relative_error_degradation_pct"
            )
        ),
        "permit_rollback_observation_hours": _int(
            apply.get(
                "permit_rollback_observation_hours"
            )
        ),
        "activation_receipt_ref": "",
        "observed_pre_value": 0.0,
        "observed_post_value": 0.0,
        "observed_current_value": 0.0,
        "observed_restored_value": 0.0,
        "kill_switch_trigger": "",
        "runtime_detail": "",
        "latest_runtime_event": {},
        "rollback_required": False,
        "rollback_confirmed": False,
        "permanent_change_runtime_permission": "NONE",
        "permanent_change_design_authorization": "NONE",
        "permanent_change_apply_authorization": "NONE",
        "permanent_change_runtime_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if apply_state == "PERMANENT_CHANGE_APPLY_NOT_REQUIRED":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
            "runtime_guard":
                "NO_PERMANENT_CHANGE_RUNTIME",
        }

    if apply_state in {
        "PERMANENT_CHANGE_APPLY_DEFERRED",
        "PERMANENT_CHANGE_APPLY_REJECTED",
    }:
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_DEFERRED",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_RUNTIME",
        }

    if apply_state != (
        "PERMANENT_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_STAGE1_ONLY"
    ):
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_APPLY",
        }

    permit = _permit_source(
        apply
    )

    if not permit:
        history = (
            pd.DataFrame()
            if apply_snapshots is None
            else apply_snapshots.copy()
        )

        latest = latest_permanent_change_apply_snapshot(
            history
        )

        if not latest:
            return {
                **base,
                "runtime_state":
                    "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
                "runtime_guard":
                    "HOLD_PERMANENT_CHANGE_APPLY_SOURCE",
            }

        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_RUNTIME_INTEGRITY",
        }

    source_integrity = _text(
        permanent_change_apply_snapshot_integrity(
            permit
        ).get("status")
    ).upper()

    base.update(
        {
            "source_permanent_change_apply_id":
                _text(
                    permit.get(
                        "permanent_change_apply_id"
                    )
                ),
            "source_permanent_change_apply_hash":
                _text(
                    permit.get(
                        "snapshot_hash"
                    )
                ),
            "source_permanent_change_apply_created_at":
                _text(
                    permit.get(
                        "created_at"
                    )
                ),
            "source_permanent_change_apply_integrity":
                source_integrity,
            "source_permanent_change_design_id":
                _text(
                    permit.get(
                        "source_permanent_change_design_id"
                    )
                ),
            "source_permanent_change_design_hash":
                _text(
                    permit.get(
                        "source_permanent_change_design_hash"
                    )
                ),
            "source_live_change_closure_id":
                _text(
                    permit.get(
                        "source_live_change_closure_id"
                    )
                ),
            "source_live_change_closure_hash":
                _text(
                    permit.get(
                        "source_live_change_closure_hash"
                    )
                ),
            "source_live_change_outcome_id":
                _text(
                    permit.get(
                        "source_live_change_outcome_id"
                    )
                ),
            "source_live_change_outcome_hash":
                _text(
                    permit.get(
                        "source_live_change_outcome_hash"
                    )
                ),
            "source_runtime_event_id":
                _text(
                    permit.get(
                        "source_runtime_event_id"
                    )
                ),
            "source_runtime_event_hash":
                _text(
                    permit.get(
                        "source_runtime_event_hash"
                    )
                ),
            "source_live_change_apply_id":
                _text(
                    permit.get(
                        "source_live_change_apply_id"
                    )
                ),
            "source_live_change_apply_hash":
                _text(
                    permit.get(
                        "source_live_change_apply_hash"
                    )
                ),
            "source_live_change_design_id":
                _text(
                    permit.get(
                        "source_live_change_design_id"
                    )
                ),
            "source_live_change_design_hash":
                _text(
                    permit.get(
                        "source_live_change_design_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    permit.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    permit.get(
                        "source_proposal_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    permit.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    permit.get(
                        "target_metric"
                    )
                ).upper(),
            "permanent_change_mode":
                _text(
                    permit.get(
                        "permanent_change_mode"
                    )
                ).upper(),
            "artifact_ref":
                _text(
                    permit.get(
                        "artifact_ref"
                    )
                ),
            "baseline_value":
                _float(
                    permit.get(
                        "baseline_value"
                    )
                ),
            "candidate_value":
                _float(
                    permit.get(
                        "candidate_value"
                    )
                ),
            "rollback_target_value":
                _float(
                    permit.get(
                        "rollback_target_value"
                    )
                ),
            "permit_stage_number":
                _int(
                    permit.get(
                        "permit_stage_number"
                    )
                ),
            "permit_scope_pct":
                _float(
                    permit.get(
                        "permit_scope_pct"
                    )
                ),
            "permit_activation_window_hours":
                _int(
                    permit.get(
                        "permit_activation_window_hours"
                    )
                ),
            "permit_min_post_change_outcomes":
                _int(
                    permit.get(
                        "permit_min_post_change_outcomes"
                    )
                ),
            "permit_max_relative_error_degradation_pct":
                _float(
                    permit.get(
                        "permit_max_relative_error_degradation_pct"
                    )
                ),
            "permit_rollback_observation_hours":
                _int(
                    permit.get(
                        "permit_rollback_observation_hours"
                    )
                ),
        }
    )

    if source_integrity != "OK":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_RUNTIME_INTEGRITY",
        }

    if _text(
        permit.get(
            "permanent_change_apply_permission"
        )
    ).upper() != "MANUAL_PERMANENT_STAGE1_APPLY_ONLY":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_RUNTIME_INTEGRITY",
        }

    events = (
        pd.DataFrame()
        if runtime_events is None
        else runtime_events.copy()
    )

    latest_event = latest_permanent_change_runtime_event(
        events
    )

    if not latest_event:
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION",
            "runtime_guard":
                "MANUAL_STAGE1_ACTIVATION_READY_NO_AUTO_APPLY",
            "permanent_change_runtime_permission":
                "MANUAL_PERMANENT_STAGE1_RUNTIME_ONLY",
        }

    base["latest_runtime_event"] = latest_event

    latest_integrity = _text(
        permanent_change_runtime_event_integrity(
            latest_event
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_RUNTIME_INTEGRITY",
        }

    if not _event_matches_permit(
        latest_event,
        permit,
    ):
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
            "runtime_guard":
                "HOLD_PERMANENT_CHANGE_RUNTIME_SOURCE",
        }

    event = _text(
        latest_event.get(
            "runtime_event"
        )
    ).upper()

    base.update(
        {
            "runtime_event":
                event,
            "activation_receipt_ref":
                _text(
                    latest_event.get(
                        "activation_receipt_ref"
                    )
                ),
            "observed_pre_value":
                _float(
                    latest_event.get(
                        "observed_pre_value"
                    )
                ),
            "observed_post_value":
                _float(
                    latest_event.get(
                        "observed_post_value"
                    )
                ),
            "observed_current_value":
                _float(
                    latest_event.get(
                        "observed_current_value"
                    )
                ),
            "observed_restored_value":
                _float(
                    latest_event.get(
                        "observed_restored_value"
                    )
                ),
            "kill_switch_trigger":
                _text(
                    latest_event.get(
                        "kill_switch_trigger"
                    )
                ).upper(),
            "runtime_detail":
                _text(
                    latest_event.get(
                        "runtime_detail"
                    )
                ),
            "permanent_change_runtime_permission":
                _text(
                    latest_event.get(
                        "permanent_change_runtime_permission"
                    )
                ).upper()
                or "NONE",
        }
    )

    if event == "ACTIVATE":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
            "runtime_guard":
                "MANUAL_STAGE1_ACTIVE_ROLLBACK_ARMED",
            "rollback_required":
                False,
            "rollback_confirmed":
                False,
        }

    if event == "CLOSE":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
            "runtime_guard":
                "STAGE1_CLOSED_NO_AUTO_STAGE2",
            "rollback_required":
                False,
            "rollback_confirmed":
                False,
        }

    if event == "KILL_SWITCH":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
            "runtime_guard":
                "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED",
            "rollback_required":
                True,
            "rollback_confirmed":
                False,
        }

    if event == "ROLLBACK_CONFIRM":
        return {
            **base,
            "runtime_state":
                "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
            "runtime_guard":
                "ROLLBACK_CONFIRMED_NO_REACTIVATION",
            "rollback_required":
                False,
            "rollback_confirmed":
                True,
        }

    return {
        **base,
        "runtime_state":
            "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "runtime_guard":
            "HOLD_PERMANENT_CHANGE_RUNTIME_INTEGRITY",
    }


def build_flow_permanent_change_runtime_event(
    runtime: dict,
    *,
    runtime_event: str,
    activation_receipt_ref: str = "",
    observed_pre_value: float = 0.0,
    observed_post_value: float = 0.0,
    observed_current_value: float = 0.0,
    observed_restored_value: float = 0.0,
    kill_switch_trigger: str = "",
    runtime_detail: str = "",
    external_manual_activation_confirmed: bool = False,
    source_permit_reviewed: bool = False,
    baseline_observation_confirmed: bool = False,
    candidate_observation_confirmed: bool = False,
    scope_isolation_confirmed: bool = False,
    monitoring_active_confirmed: bool = False,
    no_auto_stage_escalation_confirmed: bool = False,
    no_auto_permanent_apply_confirmed: bool = False,
    rollback_initiated_confirmed: bool = False,
    rollback_completed_confirmed: bool = False,
    baseline_restore_confirmed: bool = False,
    human_review_confirmed: bool = False,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = runtime or {}

    event = _text(
        runtime_event
    ).upper()

    if event not in PERMANENT_CHANGE_RUNTIME_EVENTS:
        raise ValueError(
            "Permanent Change Runtime event vocabulary가 유효하지 않습니다."
        )

    current_state = _text(
        current.get(
            "runtime_state"
        )
    ).upper()

    allowed = {
        "ACTIVATE":
            "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION",
        "CLOSE":
            "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
        "KILL_SWITCH":
            "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
        "ROLLBACK_CONFIRM":
            "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
    }

    if current_state != allowed[event]:
        raise ValueError(
            f"{event}는 현재 runtime state에서 저장할 수 없습니다."
        )

    if _text(
        current.get(
            "source_permanent_change_apply_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Permanent Change Apply integrity가 OK가 아닙니다."
        )

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    source_ts = pd.to_datetime(
        current.get(
            "source_permanent_change_apply_created_at"
        ),
        errors="coerce",
        utc=True,
    )

    event_ts = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_ts)
        or pd.isna(event_ts)
        or event_ts <= source_ts
    ):
        raise ValueError(
            "Permanent Runtime event는 source Apply Permit 이후에 저장되어야 합니다."
        )

    proposal_scope = _text(
        current.get(
            "proposal_scope"
        )
    ).upper()

    baseline = _float(
        current.get(
            "baseline_value"
        )
    )

    candidate = _float(
        current.get(
            "candidate_value"
        )
    )

    rollback_target = _float(
        current.get(
            "rollback_target_value"
        )
    )

    receipt = _text(
        activation_receipt_ref
    )

    detail = _text(
        runtime_detail
    )

    pre = float(
        observed_pre_value
    )

    post = float(
        observed_post_value
    )

    current_observed = float(
        observed_current_value
    )

    restored = float(
        observed_restored_value
    )

    trigger = _text(
        kill_switch_trigger
    ).upper()

    confirmations = {
        "external_manual_activation_confirmed":
            bool(
                external_manual_activation_confirmed
            ),
        "source_permit_reviewed":
            bool(
                source_permit_reviewed
            ),
        "baseline_observation_confirmed":
            bool(
                baseline_observation_confirmed
            ),
        "candidate_observation_confirmed":
            bool(
                candidate_observation_confirmed
            ),
        "scope_isolation_confirmed":
            bool(
                scope_isolation_confirmed
            ),
        "monitoring_active_confirmed":
            bool(
                monitoring_active_confirmed
            ),
        "no_auto_stage_escalation_confirmed":
            bool(
                no_auto_stage_escalation_confirmed
            ),
        "no_auto_permanent_apply_confirmed":
            bool(
                no_auto_permanent_apply_confirmed
            ),
        "rollback_initiated_confirmed":
            bool(
                rollback_initiated_confirmed
            ),
        "rollback_completed_confirmed":
            bool(
                rollback_completed_confirmed
            ),
        "baseline_restore_confirmed":
            bool(
                baseline_restore_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if event == "ACTIVATE":
        required = [
            "external_manual_activation_confirmed",
            "source_permit_reviewed",
            "baseline_observation_confirmed",
            "candidate_observation_confirmed",
            "scope_isolation_confirmed",
            "monitoring_active_confirmed",
            "no_auto_stage_escalation_confirmed",
            "no_auto_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        if not all(
            confirmations[field]
            for field in required
        ):
            raise ValueError(
                "ACTIVATE Human Review 확인사항을 모두 검토해야 합니다."
            )

        if len(receipt) < 8:
            raise ValueError(
                "외부 수동 activation receipt/reference를 8자 이상 기록하세요."
            )

        if len(detail) < 60:
            raise ValueError(
                "Stage-1 activation rationale/evidence를 60자 이상 기록하세요."
            )

        if proposal_scope == "PARAMETER_SHADOW":
            if abs(
                pre - baseline
            ) > 1e-9:
                raise ValueError(
                    "Observed pre-activation value가 locked baseline과 일치하지 않습니다."
                )

            if abs(
                post - candidate
            ) > 1e-9:
                raise ValueError(
                    "Observed post-activation value가 locked candidate와 일치하지 않습니다."
                )

        elif proposal_scope == "MODEL_SHADOW":
            if len(
                _text(
                    current.get(
                        "artifact_ref"
                    )
                )
            ) < 10:
                raise ValueError(
                    "MODEL_SHADOW activation에는 검증 가능한 artifact reference가 필요합니다."
                )

        else:
            raise ValueError(
                "지원하지 않는 Permanent Runtime proposal scope입니다."
            )

        state = (
            "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1"
        )
        guard = (
            "MANUAL_STAGE1_ACTIVE_ROLLBACK_ARMED"
        )
        permission = (
            "MANUAL_PERMANENT_STAGE1_RUNTIME_ONLY"
        )

    elif event == "CLOSE":
        required = [
            "scope_isolation_confirmed",
            "monitoring_active_confirmed",
            "no_auto_stage_escalation_confirmed",
            "no_auto_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        if not all(
            confirmations[field]
            for field in required
        ):
            raise ValueError(
                "CLOSE Human Review 확인사항을 모두 검토해야 합니다."
            )

        if len(detail) < 60:
            raise ValueError(
                "Stage-1 close/outcome-review handoff rationale을 60자 이상 기록하세요."
            )

        if (
            proposal_scope == "PARAMETER_SHADOW"
            and abs(
                current_observed
                - candidate
            )
            > 1e-9
        ):
            raise ValueError(
                "Stage-1 CLOSE 시 observed current value가 candidate와 일치하지 않습니다."
            )

        state = (
            "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED"
        )
        guard = (
            "STAGE1_CLOSED_NO_AUTO_STAGE2"
        )
        permission = (
            "PERMANENT_STAGE1_OUTCOME_REVIEW_ONLY"
        )

    elif event == "KILL_SWITCH":
        required = [
            "monitoring_active_confirmed",
            "rollback_initiated_confirmed",
            "no_auto_stage_escalation_confirmed",
            "no_auto_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        if not all(
            confirmations[field]
            for field in required
        ):
            raise ValueError(
                "KILL_SWITCH Human Review 확인사항을 모두 검토해야 합니다."
            )

        if trigger not in PERMANENT_CHANGE_KILL_TRIGGERS:
            raise ValueError(
                "Kill-Switch trigger vocabulary가 유효하지 않습니다."
            )

        if len(detail) < 60:
            raise ValueError(
                "Kill-Switch / rollback-initiation rationale을 60자 이상 기록하세요."
            )

        state = (
            "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED"
        )
        guard = (
            "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED"
        )
        permission = "NONE"

    else:
        required = [
            "rollback_completed_confirmed",
            "baseline_restore_confirmed",
            "no_auto_stage_escalation_confirmed",
            "no_auto_permanent_apply_confirmed",
            "human_review_confirmed",
        ]

        if not all(
            confirmations[field]
            for field in required
        ):
            raise ValueError(
                "ROLLBACK_CONFIRM Human Review 확인사항을 모두 검토해야 합니다."
            )

        if len(detail) < 60:
            raise ValueError(
                "Rollback completion / baseline restoration evidence를 60자 이상 기록하세요."
            )

        if abs(
            restored - rollback_target
        ) > 1e-9:
            raise ValueError(
                "Observed restored value가 locked rollback target과 일치하지 않습니다."
            )

        state = (
            "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED"
        )
        guard = (
            "ROLLBACK_CONFIRMED_NO_REACTIVATION"
        )
        permission = "NONE"

    base = {
        "runtime_event":
            event,
        "runtime_state":
            state,
        "runtime_guard":
            guard,
        "source_permanent_change_apply_id":
            _text(
                current.get(
                    "source_permanent_change_apply_id"
                )
            ),
        "source_permanent_change_apply_hash":
            _text(
                current.get(
                    "source_permanent_change_apply_hash"
                )
            ),
        "source_permanent_change_apply_created_at":
            _text(
                current.get(
                    "source_permanent_change_apply_created_at"
                )
            ),
        "source_permanent_change_apply_integrity":
            "OK",
        "source_permanent_change_design_id":
            _text(
                current.get(
                    "source_permanent_change_design_id"
                )
            ),
        "source_permanent_change_design_hash":
            _text(
                current.get(
                    "source_permanent_change_design_hash"
                )
            ),
        "source_live_change_closure_id":
            _text(
                current.get(
                    "source_live_change_closure_id"
                )
            ),
        "source_live_change_closure_hash":
            _text(
                current.get(
                    "source_live_change_closure_hash"
                )
            ),
        "source_live_change_outcome_id":
            _text(
                current.get(
                    "source_live_change_outcome_id"
                )
            ),
        "source_live_change_outcome_hash":
            _text(
                current.get(
                    "source_live_change_outcome_hash"
                )
            ),
        "source_runtime_event_id":
            _text(
                current.get(
                    "source_runtime_event_id"
                )
            ),
        "source_runtime_event_hash":
            _text(
                current.get(
                    "source_runtime_event_hash"
                )
            ),
        "source_live_change_apply_id":
            _text(
                current.get(
                    "source_live_change_apply_id"
                )
            ),
        "source_live_change_apply_hash":
            _text(
                current.get(
                    "source_live_change_apply_hash"
                )
            ),
        "source_live_change_design_id":
            _text(
                current.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                current.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            proposal_scope,
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "permanent_change_mode":
            _text(
                current.get(
                    "permanent_change_mode"
                )
            ),
        "artifact_ref":
            _text(
                current.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            baseline,
        "candidate_value":
            candidate,
        "rollback_target_value":
            rollback_target,
        "permit_stage_number":
            _int(
                current.get(
                    "permit_stage_number"
                )
            ),
        "permit_scope_pct":
            _float(
                current.get(
                    "permit_scope_pct"
                )
            ),
        "permit_activation_window_hours":
            _int(
                current.get(
                    "permit_activation_window_hours"
                )
            ),
        "permit_min_post_change_outcomes":
            _int(
                current.get(
                    "permit_min_post_change_outcomes"
                )
            ),
        "permit_max_relative_error_degradation_pct":
            _float(
                current.get(
                    "permit_max_relative_error_degradation_pct"
                )
            ),
        "permit_rollback_observation_hours":
            _int(
                current.get(
                    "permit_rollback_observation_hours"
                )
            ),
        "activation_receipt_ref":
            receipt,
        "observed_pre_value":
            pre,
        "observed_post_value":
            post,
        "observed_current_value":
            current_observed,
        "observed_restored_value":
            restored,
        "kill_switch_trigger":
            trigger,
        "runtime_detail":
            detail,
        **confirmations,
        "permanent_change_runtime_permission":
            permission,
        "permanent_change_design_authorization":
            "NONE",
        "permanent_change_apply_authorization":
            "NONE",
        "permanent_change_runtime_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _runtime_payload(
            base
        )
    )

    return {
        "permanent_change_runtime_event_id": (
            "PCR-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[
                :8
            ]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_permanent_change_runtime_queue(
    runtime: dict | None,
) -> pd.DataFrame:
    row = runtime or {}

    state = _text(
        row.get("runtime_state")
    ).upper()

    mapping = {
        "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT": (
            "PR2",
            "WAIT",
            "PERMANENT_CHANGE_RUNTIME_UPSTREAM_WAIT",
            "Manual Stage-1 Apply Permit이 아직 없음",
            "Permanent Design / Apply evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED": (
            "PR3",
            "MONITOR",
            "PERMANENT_CHANGE_RUNTIME_NOT_REQUIRED",
            "현재 Apply source에서는 Runtime이 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "PERMANENT_CHANGE_RUNTIME_DEFERRED": (
            "PR2",
            "WAIT",
            "PERMANENT_CHANGE_RUNTIME_DEFERRED",
            "Permanent Apply decision이 DEFER/REJECT 상태",
            "새 Design/Apply evidence까지 대기",
        ),
        "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED": (
            "PR1",
            "REVIEW",
            "PERMANENT_CHANGE_RUNTIME_APPLY_SOURCE_REQUIRED",
            "Permit 상태이나 immutable Apply source가 없음",
            "Permanent Change Apply snapshot을 먼저 확인",
        ),
        "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW": (
            "PR0",
            "BLOCKED",
            "PERMANENT_CHANGE_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "Apply Permit 또는 Runtime event integrity mismatch",
            "immutable source lineage를 먼저 복구",
        ),
        "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION": (
            "PR1",
            "REVIEW",
            "PERMANENT_CHANGE_RUNTIME_READY_FOR_MANUAL_STAGE1_ACTIVATION",
            (
                f"stage {int(row.get('permit_stage_number',0))} · "
                f"scope {float(row.get('permit_scope_pct',0)):.1%} · "
                f"window {int(row.get('permit_activation_window_hours',0))}h"
            ),
            "외부 수동 activation receipt와 observed pre/post evidence를 검증 후 ACTIVATE 기록",
        ),
        "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1": (
            "PR0",
            "ACTIVE",
            "PERMANENT_CHANGE_RUNTIME_ACTIVE_STAGE1",
            (
                f"stage1 {float(row.get('permit_scope_pct',0)):.1%} active · "
                f"rollback armed · receipt {row.get('activation_receipt_ref','')}"
            ),
            "모니터링 후 CLOSE 또는 Kill-Switch; 자동 Stage-2 escalation 금지",
        ),
        "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED": (
            "PR1",
            "REVIEW",
            "PERMANENT_CHANGE_RUNTIME_STAGE1_CLOSED_OUTCOME_REVIEW_REQUIRED",
            "Stage-1 runtime 종료 · 다음 stage 자동 확대 금지",
            "별도 Stage-1 Outcome Review evidence를 축적",
        ),
        "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED": (
            "PR0",
            "BLOCKED",
            "PERMANENT_CHANGE_RUNTIME_KILL_SWITCHED_ROLLBACK_REQUIRED",
            f"trigger {row.get('kill_switch_trigger','')}",
            "외부 수동 rollback 완료 후 baseline restore evidence로 ROLLBACK_CONFIRM",
        ),
        "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED": (
            "PR3",
            "MONITOR",
            "PERMANENT_CHANGE_RUNTIME_ROLLBACK_CONFIRMED",
            "rollback 완료 / baseline restore 확인",
            "새 Permanent Design/Apply Review 없이 재활성화 금지",
        ),
        "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED": (
            "PR0",
            "REVIEW",
            "PERMANENT_CHANGE_RUNTIME_SOURCE_SUPERSEDED",
            "새 Apply Permit으로 기존 Runtime event가 stale",
            "현재 Apply Permit 기준으로 Runtime Review 재수행",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "PR0",
            "BLOCKED",
            "PERMANENT_CHANGE_RUNTIME_UNKNOWN_STATE",
            state or "MISSING",
            "Permanent Change Runtime state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            PERMANENT_CHANGE_RUNTIME_QUEUE_COLS,
    )
