from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_trend import (
    FLOW_TREND_SNAPSHOT_COLS,
    flow_trend_snapshot_integrity,
)
from engine.operations_flow_evidence_quality import (
    build_flow_evidence_quality,
)
from engine.operations_flow_projection_review import (
    build_flow_projection_review_context,
    latest_flow_projection_review_snapshot,
    latest_reviewed_projection_source,
    flow_projection_review_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    build_flow_projection_outcome,
)


FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS = [
    "outcome_evidence_snapshot_id",
    "created_at",
    "window_state",
    "tracking_guard",
    "review_state",
    "review_snapshot_id",
    "review_snapshot_hash",
    "review_locked_at",
    "source_projection_snapshot_id",
    "source_projection_hash",
    "source_projection_created_at",
    "source_capacity",
    "prelock_contamination_count",
    "post_lock_closed_sessions",
    "qualified_post_lock_endpoints",
    "eligible_endpoints",
    "closed_session_gap_count",
    "capacity_drift_endpoints",
    "invalid_post_lock_trend_count",
    "same_session_superseded",
    "latest_endpoint_id",
    "latest_endpoint_hash",
    "endpoint_ids_json",
    "endpoint_hashes_json",
    "endpoint_dates_json",
    "projection_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


OUTCOME_EVIDENCE_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _empty_trend() -> pd.DataFrame:
    return pd.DataFrame(columns=FLOW_TREND_SNAPSHOT_COLS)


def _valid_trend_history(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = pd.DataFrame() if snapshots is None else snapshots.copy()

    for col in FLOW_TREND_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return {
            "valid": _empty_trend(),
            "invalid": pd.DataFrame(columns=FLOW_TREND_SNAPSHOT_COLS),
        }

    valid_rows = []
    invalid_rows = []

    for _, row in df.iterrows():
        record = row.to_dict()
        if (
            flow_trend_snapshot_integrity(record).get("status")
            == "OK"
        ):
            valid_rows.append(record)
        else:
            invalid_rows.append(record)

    valid = pd.DataFrame(
        valid_rows,
        columns=FLOW_TREND_SNAPSHOT_COLS,
    )
    invalid = pd.DataFrame(
        invalid_rows,
        columns=FLOW_TREND_SNAPSHOT_COLS,
    )

    for frame in [valid, invalid]:
        if not frame.empty:
            frame["_ts"] = pd.to_datetime(
                frame["created_at"],
                errors="coerce",
                utc=True,
            )

    if not valid.empty:
        valid = (
            valid.loc[valid["_ts"].notna()]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    if not invalid.empty:
        invalid = (
            invalid.loc[invalid["_ts"].notna()]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    return {
        "valid": valid,
        "invalid": invalid,
    }


def _review_state_to_window_state(
    review_state: str,
) -> tuple[str, str]:
    state = _text(review_state).upper()

    if state == "PROJECTION_REVIEW_SOURCE_REQUIRED":
        return (
            "OUTCOME_REVIEW_SOURCE_REQUIRED",
            "HOLD_REVIEW_SOURCE",
        )
    if state in {
        "PROJECTION_REVIEW_REQUIRED",
        "PROJECTION_REVIEW_CONTRACT_INCOMPLETE",
    }:
        return (
            "OUTCOME_REVIEW_LOCK_REQUIRED",
            "HOLD_REVIEW_LOCK",
        )
    if state == "PROJECTION_REVIEW_SOURCE_SUPERSEDED":
        return (
            "OUTCOME_REVIEW_SOURCE_SUPERSEDED",
            "HOLD_REVIEW_SUPERSEDED",
        )
    if state in {
        "PROJECTION_REVIEW_SOURCE_INTEGRITY_REVIEW",
        "PROJECTION_REVIEW_AUDIT_INTEGRITY_REVIEW",
        "PROJECTION_REVIEW_AUDIT_STATE_REVIEW",
    }:
        return (
            "OUTCOME_REVIEW_INTEGRITY_REVIEW",
            "HOLD_INTEGRITY",
        )

    return (
        "OUTCOME_REVIEW_LOCK_REQUIRED",
        "HOLD_REVIEW_LOCK",
    )


def build_flow_projection_outcome_evidence_window(
    projection_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
    trend_snapshots: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    *,
    min_evaluation_endpoints: int = 2,
    max_evaluation_endpoints: int = 20,
) -> dict:
    review_context = build_flow_projection_review_context(
        projection_snapshots,
        review_snapshots,
    )
    review_state = _text(
        review_context.get("review_state")
    ).upper()

    source = latest_reviewed_projection_source(
        projection_snapshots,
        review_snapshots,
    )
    latest_review = latest_flow_projection_review_snapshot(
        review_snapshots
    )

    base = {
        "review_state": review_state,
        "review_snapshot_id": _text(
            latest_review.get("review_snapshot_id")
        )
        if latest_review
        else "",
        "review_snapshot_hash": _text(
            latest_review.get("snapshot_hash")
        )
        if latest_review
        else "",
        "review_locked_at": _text(
            latest_review.get("created_at")
        )
        if latest_review
        else "",
        "source_projection_snapshot_id": _text(
            source.get("projection_snapshot_id")
        ),
        "source_projection_hash": _text(
            source.get("snapshot_hash")
        ),
        "source_projection_created_at": _text(
            source.get("created_at")
        ),
        "source_capacity": _int(
            source.get("capacity")
        ),
        "prelock_contamination_count": 0,
        "post_lock_closed_sessions": 0,
        "qualified_post_lock_endpoints": 0,
        "eligible_endpoints": 0,
        "closed_session_gap_count": 0,
        "capacity_drift_endpoints": 0,
        "invalid_post_lock_trend_count": 0,
        "same_session_superseded": 0,
        "latest_endpoint_id": "",
        "latest_endpoint_hash": "",
        "endpoint_ids": [],
        "endpoint_hashes": [],
        "endpoint_dates": [],
        "eligible_trend_history": _empty_trend(),
        "endpoint_table": pd.DataFrame(),
        "post_lock_boundary_table": pd.DataFrame(),
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if review_state != "PROJECTION_REVIEW_LOCKED" or not source:
        state, guard = _review_state_to_window_state(
            review_state
        )
        return {
            **base,
            "window_state": state,
            "tracking_guard": guard,
        }

    if (
        not latest_review
        or _text(
            flow_projection_review_snapshot_integrity(
                latest_review
            ).get("status")
        ).upper()
        != "OK"
    ):
        return {
            **base,
            "window_state": "OUTCOME_REVIEW_INTEGRITY_REVIEW",
            "tracking_guard": "HOLD_INTEGRITY",
        }

    source_ts = pd.to_datetime(
        source.get("created_at"),
        errors="coerce",
        utc=True,
    )
    lock_ts = pd.to_datetime(
        latest_review.get("created_at"),
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(source_ts)
        or pd.isna(lock_ts)
        or lock_ts < source_ts
    ):
        return {
            **base,
            "window_state": "OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW",
            "tracking_guard": "HOLD_INTEGRITY",
        }

    trend_info = _valid_trend_history(
        trend_snapshots
    )
    valid_trend = trend_info["valid"]
    invalid_trend = trend_info["invalid"]

    prelock = (
        _empty_trend()
        if valid_trend.empty
        else valid_trend.loc[
            valid_trend["_ts"].gt(source_ts)
            & valid_trend["_ts"].le(lock_ts)
        ].copy()
    )

    invalid_post = (
        pd.DataFrame()
        if invalid_trend.empty
        else invalid_trend.loc[
            invalid_trend["_ts"].gt(lock_ts)
        ].copy()
    )

    base["prelock_contamination_count"] = int(
        len(prelock)
    )
    base["invalid_post_lock_trend_count"] = int(
        len(invalid_post)
    )

    if len(prelock) > 0:
        return {
            **base,
            "window_state": "OUTCOME_ANTI_HINDSIGHT_REVIEW",
            "tracking_guard": "HOLD_ANTI_HINDSIGHT",
        }

    if len(invalid_post) > 0:
        return {
            **base,
            "window_state": "OUTCOME_EVIDENCE_INTEGRITY_REVIEW",
            "tracking_guard": "HOLD_INTEGRITY",
        }

    quality = build_flow_evidence_quality(
        trend_snapshots,
        sessions,
        min_qualified_endpoints=1,
    )

    boundary = quality.get("boundary_table")
    boundary = (
        pd.DataFrame()
        if not isinstance(boundary, pd.DataFrame)
        else boundary.copy()
    )

    all_endpoints = quality.get(
        "all_qualified_endpoint_table"
    )
    all_endpoints = (
        pd.DataFrame()
        if not isinstance(all_endpoints, pd.DataFrame)
        else all_endpoints.copy()
    )

    if boundary.empty:
        return {
            **base,
            "window_state": "OUTCOME_WAIT_CLOSED_SESSION",
            "tracking_guard": "HOLD_CLOSED_SESSION",
        }

    boundary["_close_ts"] = pd.to_datetime(
        boundary["close_created_at"],
        errors="coerce",
        utc=True,
    )
    boundary["_trend_ts"] = pd.to_datetime(
        boundary["selected_trend_created_at"],
        errors="coerce",
        utc=True,
    )

    post_lock = (
        boundary.loc[
            boundary["_close_ts"].notna()
            & boundary["_close_ts"].gt(lock_ts)
        ]
        .sort_values("_close_ts")
        .reset_index(drop=True)
    )

    base["post_lock_closed_sessions"] = int(
        len(post_lock)
    )
    base["post_lock_boundary_table"] = (
        post_lock.drop(
            columns=["_close_ts", "_trend_ts"],
            errors="ignore",
        )
    )

    if post_lock.empty:
        return {
            **base,
            "window_state": "OUTCOME_WAIT_CLOSED_SESSION",
            "tracking_guard": "HOLD_CLOSED_SESSION",
        }

    eligible_boundary = post_lock.loc[
        post_lock["boundary_status"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("QUALIFIED")
        & post_lock["_trend_ts"].notna()
        & post_lock["_trend_ts"].gt(lock_ts)
    ].copy()

    gap_count = int(
        len(post_lock) - len(eligible_boundary)
    )

    base["qualified_post_lock_endpoints"] = int(
        len(eligible_boundary)
    )
    base["closed_session_gap_count"] = gap_count

    # Outcome evaluation cannot bridge an incomplete closed session.
    # Once there is a post-lock evidence gap, a fresh Projection/Review cycle
    # is required before model-error conclusions resume.
    if gap_count > 0:
        return {
            **base,
            "window_state": "OUTCOME_EVIDENCE_GAP_REVIEW",
            "tracking_guard": "HOLD_EVIDENCE_GAP",
        }

    endpoint_ids = (
        eligible_boundary[
            "selected_trend_snapshot_id"
        ]
        .fillna("")
        .astype(str)
        .str.strip()
        .tolist()
    )
    endpoint_ids = [
        item
        for item in endpoint_ids
        if item
    ]

    if all_endpoints.empty or not endpoint_ids:
        return {
            **base,
            "window_state": "OUTCOME_WAIT_CLOSED_SESSION",
            "tracking_guard": "HOLD_CLOSED_SESSION",
        }

    selected = (
        all_endpoints.loc[
            all_endpoints["trend_snapshot_id"]
            .fillna("")
            .astype(str)
            .isin(endpoint_ids)
        ]
        .copy()
    )

    selected["_close_ts"] = pd.to_datetime(
        selected["close_created_at"],
        errors="coerce",
        utc=True,
    )
    selected = (
        selected.loc[selected["_close_ts"].notna()]
        .sort_values("_close_ts")
        .reset_index(drop=True)
    )

    limit = max(
        0,
        _int(max_evaluation_endpoints),
    )
    if limit > 0 and len(selected) > limit:
        selected = selected.iloc[:limit].copy()

    selected_ids = (
        selected["trend_snapshot_id"]
        .fillna("")
        .astype(str)
        .str.strip()
        .tolist()
    )
    selected_ids = [
        item
        for item in selected_ids
        if item
    ]

    if valid_trend.empty or not selected_ids:
        eligible_history = _empty_trend()
    else:
        eligible_history = (
            valid_trend.loc[
                valid_trend["trend_snapshot_id"]
                .fillna("")
                .astype(str)
                .isin(selected_ids)
            ]
            .sort_values("_ts")
            [FLOW_TREND_SNAPSHOT_COLS]
            .reset_index(drop=True)
        )

    eligible_count = int(
        len(eligible_history)
    )
    source_capacity = max(
        1,
        _int(source.get("capacity")),
    )
    capacity_drift = int(
        (
            pd.to_numeric(
                selected.get(
                    "capacity",
                    pd.Series(dtype=float),
                ),
                errors="coerce",
            ).fillna(0).astype(int)
            != source_capacity
        ).sum()
    )

    base["eligible_endpoints"] = eligible_count
    base["capacity_drift_endpoints"] = capacity_drift
    base["same_session_superseded"] = _int(
        quality.get("same_day_superseded")
    )
    base["eligible_trend_history"] = eligible_history
    base["endpoint_table"] = (
        selected.drop(
            columns=["_close_ts"],
            errors="ignore",
        )
    )
    base["endpoint_ids"] = selected_ids
    base["endpoint_hashes"] = (
        selected["snapshot_hash"]
        .fillna("")
        .astype(str)
        .tolist()
    )
    base["endpoint_dates"] = (
        selected["session_date"]
        .fillna("")
        .astype(str)
        .tolist()
    )

    if not selected.empty:
        base["latest_endpoint_id"] = _text(
            selected.iloc[-1].get(
                "trend_snapshot_id"
            )
        )
        base["latest_endpoint_hash"] = _text(
            selected.iloc[-1].get(
                "snapshot_hash"
            )
        )

    min_endpoints = max(
        1,
        _int(min_evaluation_endpoints),
    )

    if eligible_count < min_endpoints:
        state = "OUTCOME_EVIDENCE_MATURING"
    else:
        state = "OUTCOME_EVIDENCE_READY"

    return {
        **base,
        "window_state": state,
        "tracking_guard": "ALLOW_OUTCOME_TRACKING",
    }


def apply_flow_projection_outcome_evidence_guard(
    outcome: dict | None,
    evidence_window: dict | None,
) -> dict:
    result = dict(outcome or {})
    window = evidence_window or {}

    state = _text(
        window.get("window_state")
    ).upper()
    guard = _text(
        window.get("tracking_guard")
    ).upper()

    result["outcome_evidence_state"] = state
    result["outcome_evidence_guard"] = guard
    result["outcome_review_snapshot_id"] = _text(
        window.get("review_snapshot_id")
    )
    result["qualified_closed_session_endpoints"] = _int(
        window.get("eligible_endpoints")
    )
    result["prelock_contamination_count"] = _int(
        window.get("prelock_contamination_count")
    )
    result["closed_session_gap_count"] = _int(
        window.get("closed_session_gap_count")
    )

    blocking_map = {
        "OUTCOME_ANTI_HINDSIGHT_REVIEW":
            "OUTCOME_ANTI_HINDSIGHT_REVIEW",
        "OUTCOME_EVIDENCE_GAP_REVIEW":
            "OUTCOME_EVIDENCE_GAP_REVIEW",
        "OUTCOME_EVIDENCE_INTEGRITY_REVIEW":
            "OUTCOME_EVIDENCE_INTEGRITY_REVIEW",
        "OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW":
            "OUTCOME_EVIDENCE_INTEGRITY_REVIEW",
    }

    if state in blocking_map:
        result["evaluation_state"] = blocking_map[state]
        result["recalibration_state"] = "HOLD_OUTCOME_EVIDENCE"
        result["capacity_decision_state"] = "HOLD_OUTCOME_EVIDENCE"
        result["snapshot_eligible"] = False

    return result


def build_guarded_flow_projection_outcome(
    projection_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
    trend_snapshots: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    *,
    min_evaluation_endpoints: int = 2,
    max_evaluation_endpoints: int = 20,
    relative_error_threshold: float = 0.50,
) -> dict:
    window = build_flow_projection_outcome_evidence_window(
        projection_snapshots,
        review_snapshots,
        trend_snapshots,
        sessions,
        min_evaluation_endpoints=min_evaluation_endpoints,
        max_evaluation_endpoints=max_evaluation_endpoints,
    )

    source = latest_reviewed_projection_source(
        projection_snapshots,
        review_snapshots,
    )

    if (
        _text(
            window.get("tracking_guard")
        ).upper()
        == "ALLOW_OUTCOME_TRACKING"
    ):
        history = window.get(
            "eligible_trend_history"
        )
    else:
        history = _empty_trend()

    outcome = build_flow_projection_outcome(
        source,
        history,
        min_evaluation_intervals=min_evaluation_endpoints,
        max_evaluation_intervals=max_evaluation_endpoints,
        relative_error_threshold=relative_error_threshold,
    )
    outcome = apply_flow_projection_outcome_evidence_guard(
        outcome,
        window,
    )

    return {
        "window": window,
        "outcome": outcome,
    }


def build_flow_projection_outcome_evidence_queue(
    window: dict | None,
) -> pd.DataFrame:
    item = window or {}
    state = _text(
        item.get("window_state")
    ).upper()

    mapping = {
        "OUTCOME_REVIEW_SOURCE_REQUIRED": (
            "OE2",
            "WAIT",
            "OUTCOME_REVIEW_SOURCE_REQUIRED",
            "Human Review LOCKED READY Projection source 없음",
            "Projection/Evidence 조건이 성숙한 뒤 Human Review Lock을 완료",
        ),
        "OUTCOME_REVIEW_LOCK_REQUIRED": (
            "OE1",
            "REVIEW",
            "OUTCOME_REVIEW_LOCK_REQUIRED",
            "READY Projection은 있으나 Human Review Lock이 없음",
            "1I-R에서 Human Review Contract를 검토",
        ),
        "OUTCOME_REVIEW_SOURCE_SUPERSEDED": (
            "OE1",
            "REVIEW",
            "OUTCOME_REVIEW_SOURCE_SUPERSEDED",
            "새 READY Projection이 기존 Review Lock을 supersede",
            "최신 Projection을 다시 Human Review",
        ),
        "OUTCOME_REVIEW_INTEGRITY_REVIEW": (
            "OE0",
            "BLOCKED",
            "OUTCOME_REVIEW_INTEGRITY",
            "Projection Review source/audit integrity 검토 필요",
            "Review source/audit hash와 lineage를 복구",
        ),
        "OUTCOME_REVIEW_TIME_INTEGRITY_REVIEW": (
            "OE0",
            "BLOCKED",
            "OUTCOME_REVIEW_TIME_INTEGRITY",
            "Projection/Review timestamp ordering 비정상",
            "Projection 및 Review audit timestamp를 확인",
        ),
        "OUTCOME_ANTI_HINDSIGHT_REVIEW": (
            "OE0",
            "BLOCKED",
            "OUTCOME_ANTI_HINDSIGHT_REVIEW",
            (
                f"Projection 생성 후 Review Lock 전에 Trend Snapshot "
                f"{_int(item.get('prelock_contamination_count'))}개 존재"
            ),
            "새 Projection을 생성한 뒤 미래 evidence 관측 전에 Human Review Lock",
        ),
        "OUTCOME_WAIT_CLOSED_SESSION": (
            "OE1",
            "WAIT",
            "OUTCOME_WAIT_CLOSED_SESSION",
            "Review Lock 이후 정상 closed-session endpoint 없음",
            "실제 Session OPEN → Trend Snapshot → CLOSE 순서로 evidence 축적",
        ),
        "OUTCOME_EVIDENCE_GAP_REVIEW": (
            "OE0",
            "REVIEW",
            "OUTCOME_EVIDENCE_GAP_REVIEW",
            (
                f"post-lock closed sessions "
                f"{_int(item.get('post_lock_closed_sessions'))} · "
                f"gaps {_int(item.get('closed_session_gap_count'))}"
            ),
            "불완전 session gap을 건너뛰지 말고 새 Projection/Review cycle로 rebase",
        ),
        "OUTCOME_EVIDENCE_INTEGRITY_REVIEW": (
            "OE0",
            "BLOCKED",
            "OUTCOME_EVIDENCE_INTEGRITY_REVIEW",
            (
                f"invalid post-lock trend "
                f"{_int(item.get('invalid_post_lock_trend_count'))}"
            ),
            "post-lock Trend Snapshot integrity를 먼저 복구",
        ),
        "OUTCOME_EVIDENCE_MATURING": (
            "OE1",
            "WAIT",
            "OUTCOME_EVIDENCE_MATURING",
            (
                f"eligible endpoints "
                f"{_int(item.get('eligible_endpoints'))}"
            ),
            "추가 closed-session evidence를 자연스럽게 축적",
        ),
        "OUTCOME_EVIDENCE_READY": (
            "OE3",
            "MONITOR",
            "OUTCOME_EVIDENCE_READY",
            (
                f"eligible endpoints "
                f"{_int(item.get('eligible_endpoints'))} · "
                f"capacity drift {_int(item.get('capacity_drift_endpoints'))}"
            ),
            "Outcome error attribution을 모니터링. 자동 Capacity 변경 없음",
        ),
    }

    values = mapping.get(
        state,
        (
            "OE0",
            "BLOCKED",
            "OUTCOME_EVIDENCE_UNKNOWN_STATE",
            state or "MISSING",
            "Outcome evidence state vocabulary 확인",
        ),
    )

    row = {
        "priority": values[0],
        "status": values[1],
        "issue": values[2],
        "detail": values[3],
        "next_action": values[4],
        "go_to": "Operations Control Tower",
    }

    return pd.DataFrame(
        [row],
        columns=OUTCOME_EVIDENCE_QUEUE_COLS,
    )


def _snapshot_payload(
    row: dict,
) -> dict:
    int_fields = {
        "source_capacity",
        "prelock_contamination_count",
        "post_lock_closed_sessions",
        "qualified_post_lock_endpoints",
        "eligible_endpoints",
        "closed_session_gap_count",
        "capacity_drift_endpoints",
        "invalid_post_lock_trend_count",
        "same_session_superseded",
    }

    payload = {}

    for col in FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS:
        if col in {
            "outcome_evidence_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def build_flow_projection_outcome_evidence_snapshot(
    window: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    item = window or {}
    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        "window_state": _text(
            item.get("window_state")
        ),
        "tracking_guard": _text(
            item.get("tracking_guard")
        ),
        "review_state": _text(
            item.get("review_state")
        ),
        "review_snapshot_id": _text(
            item.get("review_snapshot_id")
        ),
        "review_snapshot_hash": _text(
            item.get("review_snapshot_hash")
        ),
        "review_locked_at": _text(
            item.get("review_locked_at")
        ),
        "source_projection_snapshot_id": _text(
            item.get("source_projection_snapshot_id")
        ),
        "source_projection_hash": _text(
            item.get("source_projection_hash")
        ),
        "source_projection_created_at": _text(
            item.get("source_projection_created_at")
        ),
        "source_capacity": _int(
            item.get("source_capacity")
        ),
        "prelock_contamination_count": _int(
            item.get("prelock_contamination_count")
        ),
        "post_lock_closed_sessions": _int(
            item.get("post_lock_closed_sessions")
        ),
        "qualified_post_lock_endpoints": _int(
            item.get("qualified_post_lock_endpoints")
        ),
        "eligible_endpoints": _int(
            item.get("eligible_endpoints")
        ),
        "closed_session_gap_count": _int(
            item.get("closed_session_gap_count")
        ),
        "capacity_drift_endpoints": _int(
            item.get("capacity_drift_endpoints")
        ),
        "invalid_post_lock_trend_count": _int(
            item.get("invalid_post_lock_trend_count")
        ),
        "same_session_superseded": _int(
            item.get("same_session_superseded")
        ),
        "latest_endpoint_id": _text(
            item.get("latest_endpoint_id")
        ),
        "latest_endpoint_hash": _text(
            item.get("latest_endpoint_hash")
        ),
        "endpoint_ids_json": json.dumps(
            item.get("endpoint_ids", []),
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "endpoint_hashes_json": json.dumps(
            item.get("endpoint_hashes", []),
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "endpoint_dates_json": json.dumps(
            item.get("endpoint_dates", []),
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(
        _snapshot_payload(base)
    )

    return {
        "outcome_evidence_snapshot_id": (
            "OEF-"
            + pd.Timestamp(now).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_projection_outcome_evidence_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )
    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _snapshot_payload(item)
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_flow_projection_outcome_evidence_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )
