from __future__ import annotations

from typing import Any

import pandas as pd

from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    flow_projection_scorecard_snapshot_integrity,
    latest_flow_projection_scorecard_snapshot,
)
from engine.operations_flow_recalibration_review import (
    ATTRIBUTION_VALUES,
    FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
    RECALIBRATION_STATES,
    build_flow_recalibration_review,
    recalibration_review_snapshot_integrity,
    latest_recalibration_review_snapshot,
)


RECALIBRATION_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

RECALIBRATION_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V136_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


REVIEW_GUARD_BY_STATE = {
    "RECALIBRATION_UPSTREAM_WAIT": "HOLD_PROOF_CLOCK",
    "RECALIBRATION_NOT_REQUIRED": "NO_RECALIBRATION_ACTION",
    "RECALIBRATION_REBASE_FIRST": "HOLD_ASSUMPTION_DRIFT",
    "RECALIBRATION_PROOF_MATURING": "HOLD_PROOF_CLOCK",
    "RECALIBRATION_SCORECARD_SOURCE_REQUIRED": "HOLD_SCORECARD_SOURCE",
    "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW": "HOLD_SCORECARD_SOURCE",
    "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW": "HOLD_SCORECARD_SOURCE",
    "RECALIBRATION_ATTRIBUTION_REQUIRED": "HUMAN_ATTRIBUTION_REQUIRED",
    "RECALIBRATION_CONTRACT_LOCKED": "CONTRACT_LOCKED",
    "RECALIBRATION_CONTRACT_SUPERSEDED": "HOLD_SCORECARD_SOURCE",
    "RECALIBRATION_CONTRACT_INTEGRITY_REVIEW": "HOLD_CONTRACT_INTEGRITY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = 0
    ok = 0
    missing = 0
    mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicate = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )
        if not item_id:
            continue

        if item_id in index:
            duplicate += 1

        index[item_id] = item

    return index, duplicate


def build_v136_recalibration_context(
    *,
    v135_context: dict | None,
    scorecard_snapshots: pd.DataFrame | None,
    recalibration_review_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v135_context or {}
    scorecard = upstream.get("scorecard") or {}

    scorecard_df = _ensure_cols(
        scorecard_snapshots,
        FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    )
    review_df = _ensure_cols(
        recalibration_review_snapshots,
        FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
    )

    latest_scorecard = latest_flow_projection_scorecard_snapshot(
        scorecard_df
    )

    review = build_flow_recalibration_review(
        scorecard,
        latest_scorecard,
        review_df,
    )

    latest_review = latest_recalibration_review_snapshot(
        review_df
    )
    latest_review_integrity = (
        _text(
            recalibration_review_snapshot_integrity(
                latest_review
            ).get("status")
        ).upper()
        if latest_review
        else "NONE"
    )

    return {
        "v135_context": upstream,
        "scorecard": scorecard,
        "scorecard_snapshots": scorecard_df,
        "recalibration_review_snapshots": review_df,
        "latest_scorecard": latest_scorecard,
        "review": review,
        "review_integrity": _integrity_counts(
            review_df,
            recalibration_review_snapshot_integrity,
        ),
        "latest_review": latest_review,
        "latest_review_integrity": latest_review_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _current_contract_complete(
    review: dict,
) -> bool:
    if _text(
        review.get("review_state")
    ).upper() != "RECALIBRATION_CONTRACT_LOCKED":
        return True

    contract = review.get("latest_contract") or {}

    if _text(
        recalibration_review_snapshot_integrity(
            contract
        ).get("status")
    ).upper() != "OK":
        return False

    confirmations = [
        "source_review_confirmed",
        "alternatives_reviewed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            contract.get(field)
        )
        for field in confirmations
    ):
        return False

    if _text(
        contract.get("primary_attribution")
    ).upper() not in ATTRIBUTION_VALUES:
        return False

    if len(
        _text(
            contract.get("attribution_detail")
        )
    ) < 10:
        return False

    if _int(
        contract.get("source_proof_clock_count")
    ) < max(
        1,
        _int(
            contract.get("source_proof_clock_target")
        ),
    ):
        return False

    for field in [
        "recalibration_authorization",
        "capacity_authorization",
        "execution_authorization",
    ]:
        if _text(
            contract.get(field)
        ).upper() not in {"", "NONE"}:
            return False

    return True


def build_v136_recalibration_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    review = ctx.get("review") or {}
    scorecard = ctx.get("scorecard") or {}
    counts = ctx.get("review_integrity") or {}

    state = _text(
        review.get("review_state")
    ).upper()
    guard = _text(
        review.get("review_guard")
    ).upper()
    scorecard_state = _text(
        scorecard.get("scorecard_state")
    ).upper()
    error_regime = _text(
        scorecard.get("error_regime")
    ).upper()
    freshness = _text(
        review.get("source_scorecard_freshness")
    ).upper()
    source_integrity = _text(
        review.get("source_scorecard_integrity")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Recalibration Review Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Recalibration Review audit immutable hash 확인",
        )
    )

    expected_guard = REVIEW_GUARD_BY_STATE.get(
        state,
        "",
    )
    vocabulary_ok = (
        state in RECALIBRATION_STATES
        and bool(expected_guard)
        and guard == expected_guard
    )

    checks.append(
        _technical_row(
            "Recalibration Review State / Guard Vocabulary",
            vocabulary_ok,
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {expected_guard or 'UNKNOWN'}"
            ),
            "Recalibration state/guard vocabulary 확인",
        )
    )

    no_source_states = {
        "RECALIBRATION_UPSTREAM_WAIT",
        "RECALIBRATION_NOT_REQUIRED",
        "RECALIBRATION_REBASE_FIRST",
        "RECALIBRATION_PROOF_MATURING",
    }

    if state in no_source_states:
        source_ok = freshness == "NOT_REQUIRED"
    elif state == "RECALIBRATION_SCORECARD_SOURCE_REQUIRED":
        source_ok = freshness == "MISSING"
    elif state == "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW":
        source_ok = freshness == "INVALID"
    elif state == "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW":
        source_ok = freshness == "DRIFTED"
    else:
        source_ok = (
            freshness == "CURRENT"
            and source_integrity == "OK"
        )

    checks.append(
        _technical_row(
            "Recalibration Scorecard Source / Freshness Mapping",
            source_ok,
            (
                f"state {state or 'MISSING'} · "
                f"freshness {freshness or 'MISSING'} · "
                f"integrity {source_integrity or 'MISSING'}"
            ),
            "Proof-met 상태의 Scorecard source CURRENT/integrity 매핑 확인",
        )
    )

    if scorecard_state in {
        "",
        "SCORECARD_HISTORY_REQUIRED",
        "SCORECARD_EVIDENCE_MATURING",
    }:
        proof_mapping_ok = (
            state == "RECALIBRATION_UPSTREAM_WAIT"
        )
    elif scorecard_state == "MONITOR":
        proof_mapping_ok = (
            state == "RECALIBRATION_NOT_REQUIRED"
        )
    elif scorecard_state == "REBASE_REQUIRED":
        proof_mapping_ok = (
            state == "RECALIBRATION_REBASE_FIRST"
        )
    elif scorecard_state == "RECALIBRATION_PROOF_MATURING":
        proof_mapping_ok = (
            state == "RECALIBRATION_PROOF_MATURING"
        )
    elif scorecard_state == "RECALIBRATION_PROOF_MET":
        proof_mapping_ok = state in {
            "RECALIBRATION_SCORECARD_SOURCE_REQUIRED",
            "RECALIBRATION_SCORECARD_SOURCE_INTEGRITY_REVIEW",
            "RECALIBRATION_SCORECARD_SOURCE_DRIFT_REVIEW",
            "RECALIBRATION_ATTRIBUTION_REQUIRED",
            "RECALIBRATION_CONTRACT_LOCKED",
            "RECALIBRATION_CONTRACT_SUPERSEDED",
            "RECALIBRATION_CONTRACT_INTEGRITY_REVIEW",
        }
    else:
        proof_mapping_ok = False

    checks.append(
        _technical_row(
            "Scorecard / Recalibration Review State Invariant",
            proof_mapping_ok,
            (
                f"scorecard {scorecard_state or 'MISSING'} · "
                f"review {state or 'MISSING'} · "
                f"proof {_int(review.get('proof_clock_count'))}/"
                f"{_int(review.get('proof_clock_target'))}"
            ),
            "Scorecard state와 Recalibration Review state 연결 확인",
        )
    )

    rebase_ok = not (
        (
            scorecard_state == "REBASE_REQUIRED"
            or error_regime == "ASSUMPTION_DRIFT"
        )
        and state
        not in {
            "RECALIBRATION_REBASE_FIRST",
            "RECALIBRATION_UPSTREAM_WAIT",
        }
    )

    checks.append(
        _technical_row(
            "Assumption Drift / Rebase-First Invariant",
            rebase_ok,
            (
                f"scorecard {scorecard_state or 'MISSING'} · "
                f"regime {error_regime or 'MISSING'} · "
                f"review {state or 'MISSING'}"
            ),
            "Capacity assumption drift를 Model/Parameter error보다 먼저 rebase 처리",
        )
    )

    latest_contract = review.get(
        "latest_contract"
    ) or {}

    checks.append(
        _technical_row(
            "Recalibration Human Contract Invariant",
            _current_contract_complete(
                review
            ),
            (
                f"state {state or 'MISSING'} · "
                f"contract "
                f"{_text(latest_contract.get('recalibration_review_id')) or 'NONE'}"
            ),
            "LOCKED Contract의 attribution/confirmations/proof/authorization 확인",
        )
    )

    if state == "RECALIBRATION_CONTRACT_LOCKED":
        supersession_ok = (
            _text(
                latest_contract.get(
                    "source_scorecard_snapshot_id"
                )
            )
            == _text(
                review.get(
                    "source_scorecard_snapshot_id"
                )
            )
            and _text(
                latest_contract.get(
                    "source_scorecard_hash"
                )
            )
            == _text(
                review.get(
                    "source_scorecard_hash"
                )
            )
        )
    elif state == "RECALIBRATION_CONTRACT_SUPERSEDED":
        supersession_ok = (
            _text(
                latest_contract.get(
                    "review_state"
                )
            ).upper()
            == "RECALIBRATION_CONTRACT_LOCKED"
            and (
                _text(
                    latest_contract.get(
                        "source_scorecard_snapshot_id"
                    )
                )
                != _text(
                    review.get(
                        "source_scorecard_snapshot_id"
                    )
                )
                or _text(
                    latest_contract.get(
                        "source_scorecard_hash"
                    )
                )
                != _text(
                    review.get(
                        "source_scorecard_hash"
                    )
                )
            )
        )
    else:
        supersession_ok = True

    checks.append(
        _technical_row(
            "Recalibration Contract Supersession Invariant",
            supersession_ok,
            (
                f"state {state or 'MISSING'} · "
                f"current source "
                f"{_text(review.get('source_scorecard_snapshot_id')) or 'NONE'} · "
                f"contract source "
                f"{_text(latest_contract.get('source_scorecard_snapshot_id')) or 'NONE'}"
            ),
            "새 Scorecard source에서 기존 Contract 재사용 차단 확인",
        )
    )

    auth_violations = 0

    for item in [
        review,
        latest_contract,
        scorecard,
    ]:
        for field in [
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                auth_violations += 1

    history = ctx.get(
        "recalibration_review_snapshots"
    )
    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            auth_violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        ctx.get("execution_authorization")
    ).upper() != "NONE":
        auth_violations += 1

    checks.append(
        _technical_row(
            "Recalibration Review Authorization Invariant",
            auth_violations == 0,
            (
                "NONE"
                if auth_violations == 0
                else f"non-NONE sources {auth_violations}"
            ),
            "Recalibration / Capacity / Projection / Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "RECALIBRATION_NOT_REQUIRED",
            "RECALIBRATION_CONTRACT_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Recalibration Human Review Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"scorecard {scorecard_state or 'MISSING'} · "
                f"regime {error_regime or 'MISSING'} · "
                f"proof {_int(review.get('proof_clock_count'))}/"
                f"{_int(review.get('proof_clock_target'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 proof/source/attribution wait는 Technical FAIL로 승격하지 않고 "
                    "qualified Outcome/Scorecard evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "review_state": state,
        "scorecard_state": scorecard_state,
        "error_regime": error_regime,
        "proof_clock": (
            f"{_int(review.get('proof_clock_count'))}/"
            f"{_int(review.get('proof_clock_target'))}"
        ),
        "latest_recalibration_review_integrity":
            _text(
                ctx.get(
                    "latest_review_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=RECALIBRATION_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v136_recalibration_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    review_df = _ensure_cols(
        ctx.get(
            "recalibration_review_snapshots"
        ),
        FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
    )
    scorecard_df = _ensure_cols(
        ctx.get(
            "scorecard_snapshots"
        ),
        FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        review_df,
        recalibration_review_snapshot_integrity,
    )

    scorecard_index, scorecard_duplicates = _index_by_id(
        scorecard_df,
        "scorecard_snapshot_id",
    )

    state_contract_violations = 0
    scorecard_lineage_violations = 0
    identity_duplicates = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in review_df.iterrows():
        item = row.to_dict()

        review_id = _text(
            item.get(
                "recalibration_review_id"
            )
        )
        if review_id:
            if review_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(review_id)

        if _text(
            item.get("review_state")
        ).upper() != "RECALIBRATION_CONTRACT_LOCKED":
            state_contract_violations += 1

        primary = _text(
            item.get(
                "primary_attribution"
            )
        ).upper()

        if (
            primary not in ATTRIBUTION_VALUES
            or len(
                _text(
                    item.get(
                        "attribution_detail"
                    )
                )
            ) < 10
            or not all(
                _bool(
                    item.get(field)
                )
                for field in [
                    "source_review_confirmed",
                    "alternatives_reviewed",
                    "no_auto_recalibration_confirmed",
                    "no_auto_capacity_confirmed",
                    "no_execution_authorization_confirmed",
                    "human_review_confirmed",
                ]
            )
        ):
            state_contract_violations += 1

        source_id = _text(
            item.get(
                "source_scorecard_snapshot_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_scorecard_hash"
            )
        )
        parent = scorecard_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                flow_projection_scorecard_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get(
                    "snapshot_hash"
                )
            )
            != source_hash
        ):
            scorecard_lineage_violations += 1

        for field in [
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Recalibration Contract Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Recalibration Contract immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Contract State / Human Review Invariant",
            state_contract_violations == 0,
            (
                f"contract violations "
                f"{state_contract_violations}"
            ),
            "LOCKED contract attribution/detail/confirmations 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Contract → Scorecard Source Lineage",
            (
                scorecard_lineage_violations == 0
                and scorecard_duplicates == 0
            ),
            (
                f"violations {scorecard_lineage_violations} · "
                f"scorecard duplicate ids {scorecard_duplicates}"
            ),
            "Contract source Scorecard id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Contract Audit Identity Invariant",
            identity_duplicates == 0,
            (
                f"duplicate review ids "
                f"{identity_duplicates}"
            ),
            "recalibration_review_id uniqueness 확인",
        )
    )

    checks.append(
        _audit_row(
            "Recalibration Contract Audit Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Recalibration / Capacity / Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("review") or {}).get(
            "review_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "RECALIBRATION_NOT_REQUIRED",
            "RECALIBRATION_CONTRACT_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Recalibration Contract Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current review {current_state or 'MISSING'} · "
                f"saved contracts {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 Proof Clock이 충족되고 attribution review가 필요할 때만 "
                    "Contract audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=RECALIBRATION_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v136_release_readiness(
    *,
    v135_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    recalibration_release_gate: str,
    recalibration_audit_gate: str,
    recalibration_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    baseline = _text(
        v135_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    review_gate = _text(
        recalibration_release_gate
    ).upper()
    audit_gate = _text(
        recalibration_audit_gate
    ).upper()
    execution = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.35 Scorecard Input Qualification Release Baseline",
            baseline == "READY_FOR_RELEASE_REVIEW",
            baseline or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Recalibration Human Review Technical Release Gate",
            review_gate == "PASS",
            review_gate or "MISSING",
        ),
        _candidate_row(
            "Recalibration Human Review Audit Integrity Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            execution == "NONE",
            execution or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if (
        _text(
            recalibration_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "RECALIBRATION_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews":
            operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V136_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v136_integration_crosscheck(
    *,
    integration_consistency: str,
    recalibration_release_gate: str,
    recalibration_audit_gate: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    review_gate = _text(
        recalibration_release_gate
    ).upper()
    audit_gate = _text(
        recalibration_audit_gate
    ).upper()

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Recalibration Human Review Technical Gate",
            review_gate == "PASS",
            review_gate or "MISSING",
        ),
        _candidate_row(
            "Recalibration Human Review Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V136_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v136_data_crosscheck(
    *,
    csv_fail_count: int,
    recalibration_release_gate: str,
    recalibration_audit_gate: str,
    latest_recalibration_review_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    review_gate = _text(
        recalibration_release_gate
    ).upper()
    audit_gate = _text(
        recalibration_audit_gate
    ).upper()
    latest_integrity = _text(
        latest_recalibration_review_integrity
    ).upper()

    latest_ok = (
        latest_integrity
        in {"OK", "NONE"}
    )

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Recalibration Human Review Technical Gate",
            review_gate == "PASS",
            review_gate or "MISSING",
        ),
        _candidate_row(
            "Recalibration Human Review Audit Gate",
            audit_gate == "PASS",
            audit_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Recalibration Review Audit Integrity",
            latest_ok,
            latest_integrity or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(
            blockers
        ),
        "checks": pd.DataFrame(
            checks,
            columns=V136_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
