from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_controlled_trial_closure import (
    FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    controlled_trial_closure_snapshot_integrity,
)
from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    recalibration_proposal_snapshot_integrity,
)
from engine.operations_flow_live_change_design import (
    FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    LIVE_CHANGE_DESIGN_STATES,
    LIVE_CHANGE_DESIGN_GUARD_BY_STATE,
    build_flow_live_change_design,
    live_change_design_snapshot_integrity,
    latest_live_change_design_snapshot,
)


LIVE_CHANGE_DESIGN_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

LIVE_CHANGE_DESIGN_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V146_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v146_live_change_design_context(
    *,
    v145_context: dict | None,
    recalibration_proposal_snapshots: pd.DataFrame | None,
    live_change_design_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v145_context or {}
    closure = upstream.get("closure") or {}

    closure_df = _ensure_cols(
        upstream.get(
            "controlled_trial_closure_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    )

    proposal_df = _ensure_cols(
        recalibration_proposal_snapshots,
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )

    design_df = _ensure_cols(
        live_change_design_snapshots,
        FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    design = build_flow_live_change_design(
        closure,
        closure_df,
        proposal_df,
        design_df,
    )

    latest_design = latest_live_change_design_snapshot(
        design_df
    )

    latest_integrity = (
        _text(
            live_change_design_snapshot_integrity(
                latest_design
            ).get("status")
        ).upper()
        if latest_design
        else "NONE"
    )

    return {
        "v145_context": upstream,
        "closure": closure,
        "controlled_trial_closure_snapshots": closure_df,
        "recalibration_proposal_snapshots": proposal_df,
        "live_change_design_snapshots": design_df,
        "design": design,
        "design_integrity": _integrity_counts(
            design_df,
            live_change_design_snapshot_integrity,
        ),
        "latest_design": latest_design,
        "latest_design_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _closure_routing_ok(
    design: dict,
    closure: dict,
) -> bool:
    design_state = _text(
        design.get("design_state")
    ).upper()
    closure_state = _text(
        closure.get("closure_state")
    ).upper()

    if closure_state == "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW":
        return design_state in {
            "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
            "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW",
            "LIVE_CHANGE_DESIGN_REQUIRED",
            "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED",
            "LIVE_CHANGE_DESIGN_LOCKED",
        }

    if closure_state in {
        "TRIAL_CLOSURE_REJECTED",
        "TRIAL_CLOSURE_ROLLBACK_CLOSED",
        "TRIAL_CLOSURE_NOT_REQUIRED",
    }:
        return design_state == "LIVE_CHANGE_DESIGN_NOT_REQUIRED"

    if closure_state == "TRIAL_CLOSURE_DEFERRED":
        return design_state == "LIVE_CHANGE_DESIGN_DEFERRED"

    return design_state == "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT"


def _closure_source_mapping_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    state = _text(
        design.get("design_state")
    ).upper()

    if state in {
        "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT",
        "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
        "LIVE_CHANGE_DESIGN_DEFERRED",
    }:
        return True

    source_id = _text(
        design.get(
            "source_trial_closure_id"
        )
    )
    source_hash = _text(
        design.get(
            "source_trial_closure_hash"
        )
    )

    if not source_id or not source_hash:
        return state in {
            "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
            "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
        }

    index, duplicates = _index_by_id(
        context.get(
            "controlled_trial_closure_snapshots"
        ),
        "controlled_trial_closure_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    return (
        bool(parent)
        and _text(
            controlled_trial_closure_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("decision")
        ).upper()
        == "ACCEPT_FOR_LIVE_CHANGE_REVIEW"
        and _text(
            parent.get(
                "live_change_review_permission"
            )
        ).upper()
        == "DESIGN_REVIEW_ONLY"
    )


def _proposal_source_mapping_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    state = _text(
        design.get("design_state")
    ).upper()

    if state in {
        "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT",
        "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
        "LIVE_CHANGE_DESIGN_DEFERRED",
        "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
        "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
    }:
        return True

    source_id = _text(
        design.get(
            "source_proposal_id"
        )
    )
    source_hash = _text(
        design.get(
            "source_proposal_hash"
        )
    )

    if not source_id or not source_hash:
        return state == "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW"

    index, duplicates = _index_by_id(
        context.get(
            "recalibration_proposal_snapshots"
        ),
        "recalibration_proposal_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    return (
        bool(parent)
        and _text(
            recalibration_proposal_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("proposal_state")
        ).upper()
        == "RECALIBRATION_PROPOSAL_LOCKED"
    )


def _locked_design_contract_ok(
    design: dict,
) -> bool:
    state = _text(
        design.get("design_state")
    ).upper()

    if state != "LIVE_CHANGE_DESIGN_LOCKED":
        return True

    row = design.get(
        "latest_design"
    ) or {}

    if not row:
        return False

    if _text(
        live_change_design_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    scope = _float(
        row.get("max_live_scope_pct")
    )
    sessions = _int(
        row.get("max_live_sessions")
    )
    outcomes = _int(
        row.get("min_post_change_outcomes")
    )
    degradation = _float(
        row.get(
            "max_relative_error_degradation_pct"
        )
    )

    if not (
        0.01 <= scope <= 0.05
        and 1 <= sessions <= 3
        and outcomes >= 3
        and 0.0 <= degradation <= 0.05
    ):
        return False

    baseline = _float(
        row.get("baseline_value")
    )
    candidate = _float(
        row.get("candidate_value")
    )
    rollback = _float(
        row.get("rollback_target_value")
    )

    if abs(
        rollback - baseline
    ) > 1e-12:
        return False

    proposal_scope = _text(
        row.get("proposal_scope")
    ).upper()

    change_mode = _text(
        row.get("change_mode")
    ).upper()

    if proposal_scope == "PARAMETER_SHADOW":
        if change_mode != "PARAMETER_CANARY_PLAN":
            return False
        if abs(candidate - baseline) <= 1e-12:
            return False

    if proposal_scope == "MODEL_SHADOW":
        if change_mode != "MODEL_CANARY_PLAN":
            return False
        if len(
            _text(
                row.get("artifact_ref")
            )
        ) < 10:
            return False

    if len(
        _text(
            row.get("design_detail")
        )
    ) < 50:
        return False

    if len(
        _text(
            row.get("rollback_detail")
        )
    ) < 50:
        return False

    required_flags = [
        "source_reviewed",
        "baseline_version_locked_confirmed",
        "canary_isolation_confirmed",
        "manual_apply_gate_required_confirmed",
        "rollback_path_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            row.get(field)
        )
        for field in required_flags
    ):
        return False

    return (
        _text(
            row.get(
                "live_change_review_permission"
            )
        ).upper()
        == "DESIGN_REVIEW_ONLY"
        and _text(
            row.get(
                "live_change_design_permission"
            )
        ).upper()
        == "DESIGN_LOCKED_NO_APPLY"
    )


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    design = context.get("design") or {}
    state = _text(
        design.get("design_state")
    ).upper()
    latest = context.get(
        "latest_design"
    ) or {}

    if state == "LIVE_CHANGE_DESIGN_LOCKED":
        closure_ts = pd.to_datetime(
            design.get(
                "source_trial_closure_created_at"
            ),
            errors="coerce",
            utc=True,
        )
        design_ts = pd.to_datetime(
            latest.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )

        return (
            not pd.isna(closure_ts)
            and not pd.isna(design_ts)
            and design_ts > closure_ts
        )

    if state == "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(
                latest.get(
                    "source_trial_closure_id"
                )
            )
            != _text(
                design.get(
                    "source_trial_closure_id"
                )
            )
            or _text(
                latest.get(
                    "source_trial_closure_hash"
                )
            )
            != _text(
                design.get(
                    "source_trial_closure_hash"
                )
            )
            or _text(
                latest.get(
                    "source_proposal_id"
                )
            )
            != _text(
                design.get(
                    "source_proposal_id"
                )
            )
            or _text(
                latest.get(
                    "source_proposal_hash"
                )
            )
            != _text(
                design.get(
                    "source_proposal_hash"
                )
            )
        )

    return True


def _no_live_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("design") or {},
        context.get("latest_design") or {},
        context.get("closure") or {},
    ]:
        for field in [
            "live_change_design_authorization",
            "live_change_apply_authorization",
            "trial_closure_authorization",
            "live_change_review_authorization",
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "trial_design_authorization",
            "adoption_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "live_change_design_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "live_change_design_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v146_live_change_design_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    design = ctx.get("design") or {}
    closure = ctx.get("closure") or {}
    counts = ctx.get("design_integrity") or {}

    state = _text(
        design.get("design_state")
    ).upper()
    guard = _text(
        design.get("design_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Live Change Design Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Design immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Design State / Guard Vocabulary",
            (
                state in LIVE_CHANGE_DESIGN_STATES
                and guard
                == LIVE_CHANGE_DESIGN_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {LIVE_CHANGE_DESIGN_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Live Change Design state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Closure → Live Change Design State Invariant",
            _closure_routing_ok(
                design,
                closure,
            ),
            (
                f"closure {_text(closure.get('closure_state')) or 'MISSING'} · "
                f"design {state or 'MISSING'}"
            ),
            "Trial Closure ACCEPT/REJECT/DEFER/ROLLBACK과 Design state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Design → Trial Closure Source Mapping",
            _closure_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"closure {_text(design.get('source_trial_closure_id')) or 'NONE'} · "
                f"integrity {_text(design.get('source_trial_closure_integrity')) or 'NONE'}"
            ),
            "Design source immutable Trial Closure id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Design → Locked Proposal Source Mapping",
            _proposal_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"proposal {_text(design.get('source_proposal_id')) or 'NONE'} · "
                f"integrity {_text(design.get('source_proposal_integrity')) or 'NONE'}"
            ),
            "Design source locked Proposal id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Canary / Baseline / Rollback Contract Invariant",
            _locked_design_contract_ok(
                design
            ),
            (
                f"state {state or 'MISSING'} · "
                f"scope {_float(design.get('max_live_scope_pct')):.1%} · "
                f"sessions {_int(design.get('max_live_sessions'))} · "
                f"baseline {_float(design.get('baseline_value')):.4f} · "
                f"candidate {_float(design.get('candidate_value')):.4f} · "
                f"rollback {_float(design.get('rollback_target_value')):.4f}"
            ),
            "Canary hard bounds, baseline lock, rollback target, Human design contract 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Design Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"closure created {_text(design.get('source_trial_closure_created_at')) or 'NONE'} · "
                f"latest design {_text((ctx.get('latest_design') or {}).get('live_change_design_id')) or 'NONE'}"
            ),
            "Design 저장 순서와 새 Closure/Proposal source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Live Change Design No-Live-Apply Authorization Invariant",
            _no_live_authorization_ok(
                ctx
            ),
            "NONE",
            "Design/Apply/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
            "LIVE_CHANGE_DESIGN_DEFERRED",
            "LIVE_CHANGE_DESIGN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Design Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"mode {_text(design.get('change_mode')) or 'NONE'} · "
                f"permission {_text(design.get('live_change_design_permission')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 closure/design wait는 Technical FAIL로 승격하지 않고 "
                    "immutable source 및 Human design evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "design_state": state,
        "closure_state": _text(
            closure.get("closure_state")
        ).upper(),
        "latest_live_change_design_integrity":
            _text(
                ctx.get(
                    "latest_design_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_DESIGN_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_design_contract_ok(
    item: dict,
) -> bool:
    if _text(
        item.get("design_state")
    ).upper() != "LIVE_CHANGE_DESIGN_LOCKED":
        return False

    if _text(
        item.get("design_guard")
    ).upper() != "LIVE_CHANGE_DESIGN_LOCKED_NO_APPLY":
        return False

    scope = _float(
        item.get("max_live_scope_pct")
    )
    sessions = _int(
        item.get("max_live_sessions")
    )
    outcomes = _int(
        item.get("min_post_change_outcomes")
    )
    degradation = _float(
        item.get(
            "max_relative_error_degradation_pct"
        )
    )

    if not (
        0.01 <= scope <= 0.05
        and 1 <= sessions <= 3
        and outcomes >= 3
        and 0.0 <= degradation <= 0.05
    ):
        return False

    baseline = _float(
        item.get("baseline_value")
    )
    candidate = _float(
        item.get("candidate_value")
    )
    rollback = _float(
        item.get("rollback_target_value")
    )

    if abs(
        rollback - baseline
    ) > 1e-12:
        return False

    proposal_scope = _text(
        item.get("proposal_scope")
    ).upper()
    mode = _text(
        item.get("change_mode")
    ).upper()

    if proposal_scope == "PARAMETER_SHADOW":
        if (
            mode != "PARAMETER_CANARY_PLAN"
            or abs(
                candidate - baseline
            ) <= 1e-12
        ):
            return False

    if proposal_scope == "MODEL_SHADOW":
        if (
            mode != "MODEL_CANARY_PLAN"
            or len(
                _text(
                    item.get("artifact_ref")
                )
            ) < 10
        ):
            return False

    if len(
        _text(
            item.get("design_detail")
        )
    ) < 50:
        return False

    if len(
        _text(
            item.get("rollback_detail")
        )
    ) < 50:
        return False

    required_flags = [
        "source_reviewed",
        "baseline_version_locked_confirmed",
        "canary_isolation_confirmed",
        "manual_apply_gate_required_confirmed",
        "rollback_path_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    return (
        all(
            _bool(
                item.get(field)
            )
            for field in required_flags
        )
        and _text(
            item.get(
                "live_change_review_permission"
            )
        ).upper()
        == "DESIGN_REVIEW_ONLY"
        and _text(
            item.get(
                "live_change_design_permission"
            )
        ).upper()
        == "DESIGN_LOCKED_NO_APPLY"
    )


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v146_live_change_design_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    design_df = _ensure_cols(
        ctx.get(
            "live_change_design_snapshots"
        ),
        FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    )

    closure_df = _ensure_cols(
        ctx.get(
            "controlled_trial_closure_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    )

    proposal_df = _ensure_cols(
        ctx.get(
            "recalibration_proposal_snapshots"
        ),
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        design_df,
        live_change_design_snapshot_integrity,
    )

    closure_index, closure_duplicates = _index_by_id(
        closure_df,
        "controlled_trial_closure_id",
    )

    proposal_index, proposal_duplicates = _index_by_id(
        proposal_df,
        "recalibration_proposal_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in design_df.iterrows():
        item = row.to_dict()

        design_id = _text(
            item.get(
                "live_change_design_id"
            )
        )

        if design_id:
            if design_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(design_id)

        if not _saved_design_contract_ok(
            item
        ):
            contract_violations += 1

        closure_id = _text(
            item.get(
                "source_trial_closure_id"
            )
        )
        closure_hash = _text(
            item.get(
                "source_trial_closure_hash"
            )
        )
        closure_parent = closure_index.get(
            closure_id
        )

        if (
            not closure_parent
            or _text(
                controlled_trial_closure_snapshot_integrity(
                    closure_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                closure_parent.get(
                    "snapshot_hash"
                )
            )
            != closure_hash
            or _text(
                closure_parent.get(
                    "decision"
                )
            ).upper()
            != "ACCEPT_FOR_LIVE_CHANGE_REVIEW"
            or _text(
                closure_parent.get(
                    "live_change_review_permission"
                )
            ).upper()
            != "DESIGN_REVIEW_ONLY"
        ):
            lineage_violations += 1
        else:
            closure_ts = pd.to_datetime(
                closure_parent.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )
            design_ts = pd.to_datetime(
                item.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(closure_ts)
                or pd.isna(design_ts)
                or design_ts <= closure_ts
            ):
                time_order_violations += 1

        proposal_id = _text(
            item.get(
                "source_proposal_id"
            )
        )
        proposal_hash = _text(
            item.get(
                "source_proposal_hash"
            )
        )
        proposal_parent = proposal_index.get(
            proposal_id
        )

        if (
            not proposal_parent
            or _text(
                recalibration_proposal_snapshot_integrity(
                    proposal_parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                proposal_parent.get(
                    "snapshot_hash"
                )
            )
            != proposal_hash
            or _text(
                proposal_parent.get(
                    "proposal_state"
                )
            ).upper()
            != "RECALIBRATION_PROPOSAL_LOCKED"
        ):
            lineage_violations += 1

        for field in [
            "live_change_design_authorization",
            "live_change_apply_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Live Change Design Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Live Change Design immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Design Audit Canary / Baseline / Rollback Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "Canary bounds, baseline lock, rollback target, Human design contract 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Design Audit → Closure / Proposal Lineage",
            (
                lineage_violations == 0
                and closure_duplicates == 0
                and proposal_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"closure duplicate ids {closure_duplicates} · "
                f"proposal duplicate ids {proposal_duplicates}"
            ),
            "Design source accepted Closure 및 locked Proposal id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Design Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate design ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Design audit identity uniqueness 및 Closure audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Live Change Design Audit No-Live-Apply Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Design/Apply/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("design") or {}).get(
            "design_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
            "LIVE_CHANGE_DESIGN_DEFERRED",
            "LIVE_CHANGE_DESIGN_LOCKED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Live Change Design Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current design {current_state or 'MISSING'} · "
                f"saved designs {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 immutable ACCEPT_FOR_LIVE_CHANGE_REVIEW Closure 이후 "
                    "baseline/candidate/rollback Design이 필요할 때만 audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=LIVE_CHANGE_DESIGN_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v146_release_readiness(
    *,
    v145_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    live_change_design_release_gate: str,
    live_change_design_audit_gate: str,
    live_change_design_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.45 Controlled Trial Closure Release Baseline",
            _text(
                v145_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v145_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Live Change Design Technical Release Gate",
            _text(
                live_change_design_release_gate
            ).upper()
            == "PASS",
            _text(
                live_change_design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Design Audit Integrity Gate",
            _text(
                live_change_design_audit_gate
            ).upper()
            == "PASS",
            _text(
                live_change_design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            live_change_design_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "LIVE_CHANGE_DESIGN_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V146_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v146_integration_crosscheck(
    *,
    integration_consistency: str,
    live_change_design_release_gate: str,
    live_change_design_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Design Technical Gate",
            _text(
                live_change_design_release_gate
            ).upper()
            == "PASS",
            _text(
                live_change_design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Design Audit Gate",
            _text(
                live_change_design_audit_gate
            ).upper()
            == "PASS",
            _text(
                live_change_design_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V146_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v146_data_crosscheck(
    *,
    csv_fail_count: int,
    live_change_design_release_gate: str,
    live_change_design_audit_gate: str,
    latest_live_change_design_integrity: str,
) -> dict:
    latest = _text(
        latest_live_change_design_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Live Change Design Technical Gate",
            _text(
                live_change_design_release_gate
            ).upper()
            == "PASS",
            _text(
                live_change_design_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Live Change Design Audit Gate",
            _text(
                live_change_design_audit_gate
            ).upper()
            == "PASS",
            _text(
                live_change_design_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Live Change Design Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V146_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
