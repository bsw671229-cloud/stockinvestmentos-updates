from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_controlled_trial_closure import (
    controlled_trial_closure_snapshot_integrity,
    latest_controlled_trial_closure_snapshot,
)
from engine.operations_flow_recalibration_proposal import (
    recalibration_proposal_snapshot_integrity,
)


FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS = [
    "live_change_design_id",
    "created_at",
    "design_state",
    "design_guard",
    "source_trial_closure_id",
    "source_trial_closure_hash",
    "source_trial_closure_created_at",
    "source_trial_closure_integrity",
    "source_trial_outcome_id",
    "source_trial_outcome_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "source_proposal_integrity",
    "closure_decision",
    "live_change_review_permission",
    "proposal_scope",
    "target_metric",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "change_mode",
    "max_live_scope_pct",
    "max_live_sessions",
    "min_post_change_outcomes",
    "max_relative_error_degradation_pct",
    "artifact_ref",
    "design_detail",
    "rollback_detail",
    "source_reviewed",
    "baseline_version_locked_confirmed",
    "canary_isolation_confirmed",
    "manual_apply_gate_required_confirmed",
    "rollback_path_confirmed",
    "no_auto_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "live_change_design_permission",
    "live_change_design_authorization",
    "live_change_apply_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


LIVE_CHANGE_DESIGN_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


LIVE_CHANGE_DESIGN_STATES = {
    "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT",
    "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
    "LIVE_CHANGE_DESIGN_DEFERRED",
    "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
    "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
    "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW",
    "LIVE_CHANGE_DESIGN_REQUIRED",
    "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED",
    "LIVE_CHANGE_DESIGN_LOCKED",
}


LIVE_CHANGE_DESIGN_GUARD_BY_STATE = {
    "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT": "HOLD_TRIAL_CLOSURE",
    "LIVE_CHANGE_DESIGN_NOT_REQUIRED": "NO_LIVE_CHANGE_DESIGN",
    "LIVE_CHANGE_DESIGN_DEFERRED": "HOLD_LIVE_CHANGE_DESIGN",
    "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED": "HOLD_TRIAL_CLOSURE_SOURCE",
    "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW": "HOLD_LIVE_CHANGE_DESIGN_INTEGRITY",
    "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW": "HOLD_LIVE_CHANGE_PROPOSAL_SOURCE",
    "LIVE_CHANGE_DESIGN_REQUIRED": "HUMAN_LIVE_CHANGE_DESIGN_REQUIRED",
    "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED": "HOLD_LIVE_CHANGE_DESIGN_SOURCE",
    "LIVE_CHANGE_DESIGN_LOCKED": "LIVE_CHANGE_DESIGN_LOCKED_NO_APPLY",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _design_payload(row: dict) -> dict:
    int_fields = {
        "max_live_sessions",
        "min_post_change_outcomes",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "max_live_scope_pct",
        "max_relative_error_degradation_pct",
    }

    bool_fields = {
        "source_reviewed",
        "baseline_version_locked_confirmed",
        "canary_isolation_confirmed",
        "manual_apply_gate_required_confirmed",
        "rollback_path_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS:
        if col in {
            "live_change_design_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def live_change_design_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _design_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_live_change_design_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )


def _accepted_closure_source(
    closure: dict | None,
) -> dict:
    row = closure or {}

    if _text(
        row.get("closure_state")
    ).upper() != "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW":
        return {}

    if _text(
        row.get("live_change_review_permission")
    ).upper() != "DESIGN_REVIEW_ONLY":
        return {}

    latest = row.get(
        "latest_closure"
    ) or {}

    if not latest:
        return {}

    if _text(
        controlled_trial_closure_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get("decision")
    ).upper() != "ACCEPT_FOR_LIVE_CHANGE_REVIEW":
        return {}

    if _text(
        latest.get("live_change_review_permission")
    ).upper() != "DESIGN_REVIEW_ONLY":
        return {}

    return latest


def _proposal_source(
    closure_source: dict,
    proposal_snapshots: pd.DataFrame | None,
) -> dict:
    if not closure_source:
        return {}

    df = (
        pd.DataFrame()
        if proposal_snapshots is None
        else proposal_snapshots.copy()
    )

    if df.empty:
        return {}

    source_id = _text(
        closure_source.get(
            "source_proposal_id"
        )
    )
    source_hash = _text(
        closure_source.get(
            "source_proposal_hash"
        )
    )

    if not source_id or not source_hash:
        return {}

    if "recalibration_proposal_id" not in df.columns:
        return {}

    matches = df.loc[
        df["recalibration_proposal_id"]
        .fillna("")
        .astype(str)
        .eq(source_id)
    ]

    if len(matches) != 1:
        return {}

    row = matches.iloc[0].to_dict()

    if _text(
        recalibration_proposal_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        row.get("snapshot_hash")
    ) != source_hash:
        return {}

    if _text(
        row.get("proposal_state")
    ).upper() != "RECALIBRATION_PROPOSAL_LOCKED":
        return {}

    return row


def _design_matches_sources(
    design: dict,
    closure_source: dict,
    proposal_source: dict,
) -> bool:
    if not design or not closure_source or not proposal_source:
        return False

    if _text(
        live_change_design_snapshot_integrity(
            design
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            design.get(
                "source_trial_closure_id"
            )
        )
        == _text(
            closure_source.get(
                "controlled_trial_closure_id"
            )
        )
        and _text(
            design.get(
                "source_trial_closure_hash"
            )
        )
        == _text(
            closure_source.get(
                "snapshot_hash"
            )
        )
        and _text(
            design.get(
                "source_proposal_id"
            )
        )
        == _text(
            proposal_source.get(
                "recalibration_proposal_id"
            )
        )
        and _text(
            design.get(
                "source_proposal_hash"
            )
        )
        == _text(
            proposal_source.get(
                "snapshot_hash"
            )
        )
    )


def _default_change_mode(
    proposal_scope: str,
) -> str:
    scope = _text(
        proposal_scope
    ).upper()

    if scope == "PARAMETER_SHADOW":
        return "PARAMETER_CANARY_PLAN"

    if scope == "MODEL_SHADOW":
        return "MODEL_CANARY_PLAN"

    return "CANARY_DESIGN_ONLY"


def build_flow_live_change_design(
    controlled_trial_closure: dict | None,
    closure_snapshots: pd.DataFrame | None,
    proposal_snapshots: pd.DataFrame | None,
    design_snapshots: pd.DataFrame | None,
) -> dict:
    closure = controlled_trial_closure or {}
    closure_state = _text(
        closure.get("closure_state")
    ).upper()

    base = {
        "source_trial_closure_id": "",
        "source_trial_closure_hash": "",
        "source_trial_closure_created_at": "",
        "source_trial_closure_integrity": "NONE",
        "source_trial_outcome_id": _text(
            closure.get(
                "source_trial_outcome_id"
            )
        ),
        "source_trial_outcome_hash": _text(
            closure.get(
                "source_trial_outcome_hash"
            )
        ),
        "source_proposal_id": _text(
            closure.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            closure.get(
                "source_proposal_hash"
            )
        ),
        "source_proposal_integrity": "NONE",
        "closure_decision": _text(
            closure.get("decision")
        ).upper(),
        "live_change_review_permission": _text(
            closure.get(
                "live_change_review_permission"
            )
        ).upper() or "NONE",
        "proposal_scope": _text(
            closure.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            closure.get(
                "target_metric"
            )
        ).upper(),
        "baseline_value": 0.0,
        "candidate_value": 0.0,
        "rollback_target_value": 0.0,
        "change_mode": _default_change_mode(
            closure.get(
                "proposal_scope"
            )
        ),
        "max_live_scope_pct": 0.05,
        "max_live_sessions": 2,
        "min_post_change_outcomes": 3,
        "max_relative_error_degradation_pct": 0.05,
        "artifact_ref": "",
        "design_detail": "",
        "rollback_detail": "",
        "latest_design": {},
        "live_change_design_permission": "NONE",
        "live_change_design_authorization": "NONE",
        "live_change_apply_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if closure_state in {
        "TRIAL_CLOSURE_REJECTED",
        "TRIAL_CLOSURE_ROLLBACK_CLOSED",
        "TRIAL_CLOSURE_NOT_REQUIRED",
    }:
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
            "design_guard": "NO_LIVE_CHANGE_DESIGN",
        }

    if closure_state == "TRIAL_CLOSURE_DEFERRED":
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_DEFERRED",
            "design_guard": "HOLD_LIVE_CHANGE_DESIGN",
        }

    if closure_state != "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW":
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT",
            "design_guard": "HOLD_TRIAL_CLOSURE",
        }

    if _text(
        closure.get(
            "live_change_review_permission"
        )
    ).upper() != "DESIGN_REVIEW_ONLY":
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard": "HOLD_LIVE_CHANGE_DESIGN_INTEGRITY",
        }

    closure_source = _accepted_closure_source(
        closure
    )

    if not closure_source:
        history = (
            pd.DataFrame()
            if closure_snapshots is None
            else closure_snapshots.copy()
        )

        latest = latest_controlled_trial_closure_snapshot(
            history
        )

        if not latest:
            return {
                **base,
                "design_state": "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
                "design_guard": "HOLD_TRIAL_CLOSURE_SOURCE",
            }

        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard": "HOLD_LIVE_CHANGE_DESIGN_INTEGRITY",
        }

    closure_integrity = _text(
        controlled_trial_closure_snapshot_integrity(
            closure_source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_trial_closure_id":
                _text(
                    closure_source.get(
                        "controlled_trial_closure_id"
                    )
                ),
            "source_trial_closure_hash":
                _text(
                    closure_source.get(
                        "snapshot_hash"
                    )
                ),
            "source_trial_closure_created_at":
                _text(
                    closure_source.get(
                        "created_at"
                    )
                ),
            "source_trial_closure_integrity":
                closure_integrity,
            "source_trial_outcome_id":
                _text(
                    closure_source.get(
                        "source_trial_outcome_id"
                    )
                ),
            "source_trial_outcome_hash":
                _text(
                    closure_source.get(
                        "source_trial_outcome_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    closure_source.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    closure_source.get(
                        "source_proposal_hash"
                    )
                ),
            "closure_decision":
                _text(
                    closure_source.get(
                        "decision"
                    )
                ).upper(),
            "live_change_review_permission":
                _text(
                    closure_source.get(
                        "live_change_review_permission"
                    )
                ).upper(),
            "proposal_scope":
                _text(
                    closure_source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    closure_source.get(
                        "target_metric"
                    )
                ).upper(),
            "change_mode":
                _default_change_mode(
                    closure_source.get(
                        "proposal_scope"
                    )
                ),
        }
    )

    if closure_integrity != "OK":
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard": "HOLD_LIVE_CHANGE_DESIGN_INTEGRITY",
        }

    proposal_source = _proposal_source(
        closure_source,
        proposal_snapshots,
    )

    if not proposal_source:
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW",
            "design_guard": "HOLD_LIVE_CHANGE_PROPOSAL_SOURCE",
        }

    proposal_integrity = _text(
        recalibration_proposal_snapshot_integrity(
            proposal_source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_proposal_integrity":
                proposal_integrity,
            "baseline_value":
                _float(
                    proposal_source.get(
                        "current_value"
                    )
                ),
            "candidate_value":
                _float(
                    proposal_source.get(
                        "proposed_value"
                    )
                ),
            "rollback_target_value":
                _float(
                    proposal_source.get(
                        "current_value"
                    )
                ),
        }
    )

    design_history = (
        pd.DataFrame()
        if design_snapshots is None
        else design_snapshots.copy()
    )

    latest_design = latest_live_change_design_snapshot(
        design_history
    )

    if not latest_design:
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_REQUIRED",
            "design_guard": "HUMAN_LIVE_CHANGE_DESIGN_REQUIRED",
        }

    base[
        "latest_design"
    ] = latest_design

    latest_integrity = _text(
        live_change_design_snapshot_integrity(
            latest_design
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "design_guard": "HOLD_LIVE_CHANGE_DESIGN_INTEGRITY",
        }

    if not _design_matches_sources(
        latest_design,
        closure_source,
        proposal_source,
    ):
        return {
            **base,
            "design_state": "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED",
            "design_guard": "HOLD_LIVE_CHANGE_DESIGN_SOURCE",
        }

    return {
        **base,
        "design_state":
            "LIVE_CHANGE_DESIGN_LOCKED",
        "design_guard":
            "LIVE_CHANGE_DESIGN_LOCKED_NO_APPLY",
        "change_mode":
            _text(
                latest_design.get(
                    "change_mode"
                )
            ).upper(),
        "max_live_scope_pct":
            _float(
                latest_design.get(
                    "max_live_scope_pct"
                )
            ),
        "max_live_sessions":
            _int(
                latest_design.get(
                    "max_live_sessions"
                )
            ),
        "min_post_change_outcomes":
            _int(
                latest_design.get(
                    "min_post_change_outcomes"
                )
            ),
        "max_relative_error_degradation_pct":
            _float(
                latest_design.get(
                    "max_relative_error_degradation_pct"
                )
            ),
        "artifact_ref":
            _text(
                latest_design.get(
                    "artifact_ref"
                )
            ),
        "design_detail":
            _text(
                latest_design.get(
                    "design_detail"
                )
            ),
        "rollback_detail":
            _text(
                latest_design.get(
                    "rollback_detail"
                )
            ),
        "live_change_design_permission":
            _text(
                latest_design.get(
                    "live_change_design_permission"
                )
            ).upper() or "NONE",
    }


def build_flow_live_change_design_lock(
    design: dict,
    *,
    max_live_scope_pct: float,
    max_live_sessions: int,
    min_post_change_outcomes: int,
    max_relative_error_degradation_pct: float,
    artifact_ref: str,
    design_detail: str,
    rollback_detail: str,
    source_reviewed: bool,
    baseline_version_locked_confirmed: bool,
    canary_isolation_confirmed: bool,
    manual_apply_gate_required_confirmed: bool,
    rollback_path_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = design or {}

    if _text(
        current.get(
            "design_state"
        )
    ).upper() != "LIVE_CHANGE_DESIGN_REQUIRED":
        raise ValueError(
            "Live Change Design은 LIVE_CHANGE_DESIGN_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_trial_closure_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Trial Closure integrity가 OK가 아닙니다."
        )

    if _text(
        current.get(
            "source_proposal_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Recalibration Proposal integrity가 OK가 아닙니다."
        )

    if _text(
        current.get(
            "closure_decision"
        )
    ).upper() != "ACCEPT_FOR_LIVE_CHANGE_REVIEW":
        raise ValueError(
            "ACCEPT_FOR_LIVE_CHANGE_REVIEW Closure source만 Live Change Design을 만들 수 있습니다."
        )

    if _text(
        current.get(
            "live_change_review_permission"
        )
    ).upper() != "DESIGN_REVIEW_ONLY":
        raise ValueError(
            "DESIGN_REVIEW_ONLY permission이 없습니다."
        )

    scope = float(
        max_live_scope_pct
    )
    sessions = int(
        max_live_sessions
    )
    outcomes = int(
        min_post_change_outcomes
    )
    degradation = float(
        max_relative_error_degradation_pct
    )

    if not (
        0.01
        <= scope
        <= 0.05
    ):
        raise ValueError(
            "Live Change design scope는 1% 이상 5% 이하여야 합니다."
        )

    if not (
        1
        <= sessions
        <= 3
    ):
        raise ValueError(
            "Live Change design session cap은 1 이상 3 이하여야 합니다."
        )

    if outcomes < 3:
        raise ValueError(
            "Post-change qualified Outcome은 최소 3개가 필요합니다."
        )

    if not (
        0.0
        <= degradation
        <= 0.05
    ):
        raise ValueError(
            "허용 상대오차 악화 한도는 0% 이상 5% 이하여야 합니다."
        )

    detail = _text(
        design_detail
    )
    rollback = _text(
        rollback_detail
    )

    if len(detail) < 50:
        raise ValueError(
            "Live Change Design detail을 50자 이상 기록하세요."
        )

    if len(rollback) < 50:
        raise ValueError(
            "Rollback Plan detail을 50자 이상 기록하세요."
        )

    proposal_scope = _text(
        current.get(
            "proposal_scope"
        )
    ).upper()

    artifact = _text(
        artifact_ref
    )

    if (
        proposal_scope == "MODEL_SHADOW"
        and len(artifact) < 10
    ):
        raise ValueError(
            "MODEL_SHADOW Live Change Design에는 versioned model artifact reference가 필요합니다."
        )

    if (
        proposal_scope == "PARAMETER_SHADOW"
        and not artifact
    ):
        artifact = (
            "PARAMETER:"
            + _text(
                current.get(
                    "target_metric"
                )
            )
        )

    confirmations = {
        "source_reviewed":
            bool(
                source_reviewed
            ),
        "baseline_version_locked_confirmed":
            bool(
                baseline_version_locked_confirmed
            ),
        "canary_isolation_confirmed":
            bool(
                canary_isolation_confirmed
            ),
        "manual_apply_gate_required_confirmed":
            bool(
                manual_apply_gate_required_confirmed
            ),
        "rollback_path_confirmed":
            bool(
                rollback_path_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Live Change Design Human Review 확인사항을 모두 검토해야 합니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    closure_created = pd.to_datetime(
        current.get(
            "source_trial_closure_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    design_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            closure_created
        )
        or pd.isna(
            design_created
        )
        or design_created <= closure_created
    ):
        raise ValueError(
            "Live Change Design은 source Trial Closure audit 이후에 저장되어야 합니다."
        )

    baseline = _float(
        current.get(
            "baseline_value"
        )
    )
    candidate = _float(
        current.get(
            "candidate_value"
        )
    )

    if (
        proposal_scope == "PARAMETER_SHADOW"
        and abs(
            candidate - baseline
        ) <= 1e-12
    ):
        raise ValueError(
            "PARAMETER_SHADOW candidate 값이 baseline과 동일합니다."
        )

    base = {
        "design_state":
            "LIVE_CHANGE_DESIGN_LOCKED",
        "design_guard":
            "LIVE_CHANGE_DESIGN_LOCKED_NO_APPLY",
        "source_trial_closure_id":
            _text(
                current.get(
                    "source_trial_closure_id"
                )
            ),
        "source_trial_closure_hash":
            _text(
                current.get(
                    "source_trial_closure_hash"
                )
            ),
        "source_trial_closure_created_at":
            _text(
                current.get(
                    "source_trial_closure_created_at"
                )
            ),
        "source_trial_closure_integrity":
            "OK",
        "source_trial_outcome_id":
            _text(
                current.get(
                    "source_trial_outcome_id"
                )
            ),
        "source_trial_outcome_hash":
            _text(
                current.get(
                    "source_trial_outcome_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "source_proposal_integrity":
            "OK",
        "closure_decision":
            "ACCEPT_FOR_LIVE_CHANGE_REVIEW",
        "live_change_review_permission":
            "DESIGN_REVIEW_ONLY",
        "proposal_scope":
            proposal_scope,
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "baseline_value":
            baseline,
        "candidate_value":
            candidate,
        "rollback_target_value":
            baseline,
        "change_mode":
            _default_change_mode(
                proposal_scope
            ),
        "max_live_scope_pct":
            scope,
        "max_live_sessions":
            sessions,
        "min_post_change_outcomes":
            outcomes,
        "max_relative_error_degradation_pct":
            degradation,
        "artifact_ref":
            artifact,
        "design_detail":
            detail,
        "rollback_detail":
            rollback,
        **confirmations,
        "live_change_design_permission":
            "DESIGN_LOCKED_NO_APPLY",
        "live_change_design_authorization":
            "NONE",
        "live_change_apply_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _design_payload(
            base
        )
    )

    return {
        "live_change_design_id": (
            "LCD-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_live_change_design_queue(
    design: dict | None,
) -> pd.DataFrame:
    row = design or {}
    state = _text(
        row.get(
            "design_state"
        )
    ).upper()

    mapping = {
        "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT": (
            "LC2",
            "WAIT",
            "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT",
            "ACCEPT_FOR_LIVE_CHANGE_REVIEW Trial Closure가 아직 없음",
            "Trial Outcome / Closure evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "LIVE_CHANGE_DESIGN_NOT_REQUIRED": (
            "LC3",
            "MONITOR",
            "LIVE_CHANGE_DESIGN_NOT_REQUIRED",
            "현재 Trial Closure decision에서는 Live Change Design이 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "LIVE_CHANGE_DESIGN_DEFERRED": (
            "LC2",
            "WAIT",
            "LIVE_CHANGE_DESIGN_DEFERRED",
            "Human Trial Closure decision = DEFER",
            "새 evidence 또는 새 trial cycle 이후 재검토",
        ),
        "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED": (
            "LC1",
            "REVIEW",
            "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
            "Accepted Closure state는 있으나 immutable Closure source가 없음",
            "Controlled Trial Closure audit을 먼저 확인",
        ),
        "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW": (
            "LC0",
            "BLOCKED",
            "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
            "Trial Closure 또는 Live Change Design immutable hash mismatch",
            "Closure / Design source integrity를 먼저 복구",
        ),
        "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW": (
            "LC0",
            "BLOCKED",
            "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW",
            "원본 locked Recalibration Proposal source를 확인할 수 없음",
            "Proposal id/hash/integrity를 먼저 복구",
        ),
        "LIVE_CHANGE_DESIGN_REQUIRED": (
            "LC1",
            "REVIEW",
            "LIVE_CHANGE_DESIGN_REQUIRED",
            (
                f"scope <= {float(row.get('max_live_scope_pct',0)):.1%} · "
                f"sessions <= {row.get('max_live_sessions',0)} · "
                f"candidate {row.get('candidate_value',0)}"
            ),
            "Baseline lock / canary isolation / rollback plan을 사전등록",
        ),
        "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED": (
            "LC0",
            "REVIEW",
            "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED",
            "새 Trial Closure/Proposal source로 기존 Live Change Design이 stale",
            "현재 immutable source 기준으로 Design 재수행",
        ),
        "LIVE_CHANGE_DESIGN_LOCKED": (
            "LC3",
            "MONITOR",
            "LIVE_CHANGE_DESIGN_LOCKED",
            (
                f"{row.get('change_mode','')} · "
                f"scope {float(row.get('max_live_scope_pct',0)):.1%} · "
                f"rollback target {row.get('rollback_target_value',0)}"
            ),
            "live apply 금지; 별도 Human Live Change Apply Gate 필요",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "LC0",
            "BLOCKED",
            "LIVE_CHANGE_DESIGN_UNKNOWN_STATE",
            state or "MISSING",
            "Live Change Design state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            LIVE_CHANGE_DESIGN_QUEUE_COLS,
    )
