"""Basic LIVE KRX regular-session guard; no scheduling or order transmission."""
from datetime import datetime, time, timedelta, timezone
from connectors.kis_broker import BrokerError

KST = timezone(timedelta(hours=9))


def _utcnow():
    return datetime.now(timezone.utc)


def _window_at(now):
    if now.tzinfo is None or now.utcoffset() is None:
        raise BrokerError('거래시간을 확인할 수 없습니다. 주문을 준비하거나 전송하지 않습니다')
    local = now.astimezone(KST)
    if local.weekday() >= 5:
        raise BrokerError('국내 실전 주문: 주말에는 주문을 준비하거나 전송하지 않습니다. 조회 전용 점검은 가능합니다')
    if not time(9) <= local.time() < time(15, 30):
        raise BrokerError('국내 실전 주문: 기본 정규장 시간(한국시간 09:00~15:30) 밖입니다. 예약주문으로 접수하지 않습니다')
    return local


def _window():
    return _window_at(_utcnow())


def session_snapshot(calendar=None, *, now=None):
    """Local display only. Never queries, authorizes, or prepares an order."""
    current = _utcnow() if now is None else now
    result = {'checked_at': None, 'date': None, 'window': 'UNKNOWN',
              'calendar': 'UNCONFIRMED', 'status': 'CHECK_REQUIRED',
              'message': '한국시간을 확인할 수 없습니다. 주문 준비가 불가합니다.'}
    if not isinstance(current, datetime) or current.tzinfo is None or current.utcoffset() is None:
        return result
    local = current.astimezone(KST)
    day = local.strftime('%Y%m%d')
    result.update(checked_at=local.isoformat(), date=day)
    try:
        _window_at(current)
        result['window'] = 'REGULAR'
    except BrokerError:
        result['window'] = 'WEEKEND' if local.weekday() >= 5 else 'OUTSIDE_REGULAR'
    if isinstance(calendar, dict) and calendar.get('date') == day:
        if calendar.get('status') == 'CHECK_REQUIRED':
            result['calendar'] = 'ERROR'
        elif calendar.get('status') == 'PASS' and type(calendar.get('open')) is bool:
            try:
                checked = datetime.fromisoformat(calendar['checked_at'])
                valid = (checked.tzinfo is not None and checked.utcoffset() is not None
                         and checked <= current and checked.astimezone(KST).strftime('%Y%m%d') == day)
            except (KeyError, TypeError, ValueError, OverflowError):
                valid = False
            if valid:
                result['calendar'] = 'OPEN' if calendar['open'] else 'CLOSED'
    if result['window'] == 'WEEKEND':
        result.update(status='BLOCKED_WEEKEND', message='주문 준비 불가 · 주말입니다. 조회 전용 점검은 실행할 수 있습니다.')
    elif result['window'] == 'OUTSIDE_REGULAR':
        result.update(status='BLOCKED_TIME', message='주문 준비 불가 · 기본 정규장 시간(한국시간 09:00~15:30) 밖입니다.')
    elif result['calendar'] == 'CLOSED':
        result.update(status='BLOCKED_CLOSED_DAY', message='주문 준비 불가 · 증권사 응답상 오늘은 개장일이 아닙니다.')
    elif result['calendar'] == 'OPEN':
        result.update(status='BASIC_CONDITIONS_MET', message='기본 거래시간·개장일 조건 확인됨 · 주문 전체 조건은 준비·전송 직전에 다시 점검합니다.')
    elif result['calendar'] == 'ERROR':
        result.update(message='개장일 확인 실패 · 주문 준비가 불가합니다. 2분 후 개장일 조회를 다시 시도해 주세요.')
    else:
        result.update(status='CALENDAR_UNCONFIRMED', message='개장일 미확인 · 주문 준비 전에 증권사의 개장일 확인이 필요합니다.')
    return result


def check_kr_order_session(client, order):
    """Calendar availability is mandatory; never infer opening from a quote."""
    if order['market'] != 'KR' or client.credentials.mode != 'LIVE':
        return {'status': 'NOT_APPLICABLE'}
    before = _window()
    day = before.strftime('%Y%m%d')
    try:
        result = client.kr_open_day(day)
    except BrokerError:
        raise
    except Exception:
        raise BrokerError('국내 개장일을 확인하지 못했습니다. 주문을 준비하거나 전송하지 않습니다') from None
    if not isinstance(result, dict) or result.get('date') != day or type(result.get('open')) is not bool:
        raise BrokerError('국내 개장일 응답을 확인하지 못했습니다. 주문을 준비하거나 전송하지 않습니다')
    if not result['open']:
        raise BrokerError('국내 실전 주문: 증권사 조회 결과 오늘은 개장일이 아닙니다. 조회 전용 점검은 가능합니다')
    after = _window()
    if after.date() != before.date():
        raise BrokerError('거래일이 바뀌었습니다. 주문을 다시 점검하세요')
    return {'status': 'PASS', 'date': day, 'checked_at': after.isoformat(), 'scope': 'LIVE_KR_BASIC_REGULAR'}
