from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.decision_learning_lineage import (
    decision_learning_lineage_integrity,
)
from engine.learning_feedback_governance import (
    learning_feedback_record_integrity,
)
from engine.learning_feedback_revalidation_bridge import (
    feedback_revalidation_draft_integrity,
)
from engine.learning_feedback_change_lineage import (
    build_feedback_change_context,
    feedback_change_lineage_integrity,
    latest_feedback_closure_record,
)


ASSUMPTION_TARGETS = {
    "FORWARD_ER",
    "RISK_PENALTY",
    "HURDLE",
}


LEARNING_CYCLE_COVERAGE_COLS = [
    "priority",
    "bucket",
    "due_date",
    "days_to_due",
    "company",
    "learning_lineage_id",
    "learning_integrity",
    "feedback_id",
    "feedback_target",
    "feedback_status",
    "feedback_integrity",
    "bridge_id",
    "bridge_status",
    "bridge_integrity",
    "source_review_status",
    "source_review_id",
    "proposal_outcome",
    "closure_status",
    "closure_integrity",
    "cycle_status",
    "issue",
    "next_action",
    "go_to",
]


LEARNING_CYCLE_ORPHAN_COLS = [
    "severity",
    "orphan_type",
    "record_type",
    "record_id",
    "subject",
    "missing_parent_type",
    "missing_parent_id",
    "hash_snapshot_status",
    "issue",
    "next_action",
    "go_to",
]


LEARNING_CYCLE_AUDIT_SNAPSHOT_COLS = [
    "audit_id",
    "created_at",
    "audit_status",
    "learning_complete",
    "learning_integrity_issues",
    "feedback_covered",
    "feedback_missing",
    "assumption_feedback",
    "bridge_ready",
    "source_review_pending",
    "closure_pending",
    "open_more_evidence",
    "closed_source_reviewed",
    "external_route",
    "orphan_count",
    "hash_or_integrity_issues",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _timestamp(value: Any) -> pd.Timestamp | None:
    ts = pd.to_datetime(
        value,
        errors="coerce",
        utc=True,
    )
    if pd.isna(ts):
        return None
    return pd.Timestamp(ts)


def _latest_by_time(
    df: pd.DataFrame,
    timestamp_col: str,
) -> dict:
    if df is None or df.empty:
        return {}

    work = df.copy()
    if timestamp_col not in work.columns:
        return work.iloc[-1].to_dict()

    work["_ts"] = pd.to_datetime(
        work[timestamp_col],
        errors="coerce",
        utc=True,
    )
    work = work.sort_values(
        "_ts",
        ascending=False,
        na_position="last",
    )
    return (
        work.iloc[0]
        .drop(
            labels=["_ts"],
            errors="ignore",
        )
        .to_dict()
    )


def _bucket_for_due(
    due_value: Any,
    current_date: date,
) -> tuple[str, int | None]:
    parsed = pd.to_datetime(
        due_value,
        errors="coerce",
    )
    if pd.isna(parsed):
        return "NO DATE", None

    due = parsed.date()
    days = (
        due
        - current_date
    ).days

    if days < 0:
        return "OVERDUE", days
    if days == 0:
        return "TODAY", days
    if days <= 7:
        return "NEXT 7 DAYS", days
    if days <= 30:
        return "NEXT 30 DAYS", days
    return "FUTURE", days


def _ensure_cols(
    df: pd.DataFrame | None,
    columns: list[str],
) -> pd.DataFrame:
    out = (
        pd.DataFrame()
        if df is None
        else df.copy()
    )
    for col in columns:
        if col not in out.columns:
            out[col] = ""
    return out


def _duplicate_orphans(
    df: pd.DataFrame,
    *,
    id_col: str,
    record_type: str,
    subject_col: str = "company",
) -> list[dict]:
    rows = []
    if df.empty or id_col not in df.columns:
        return rows

    ids = (
        df[id_col]
        .fillna("")
        .astype(str)
        .str.strip()
    )
    counts = ids[
        ids.ne("")
    ].value_counts()

    for record_id, count in counts.items():
        if int(count) <= 1:
            continue

        hit = df.loc[
            ids.eq(
                record_id
            )
        ]
        subject = (
            _text(
                hit.iloc[-1].get(
                    subject_col
                )
            )
            if not hit.empty
            else ""
        )

        rows.append(
            {
                "severity": "LC0",
                "orphan_type":
                    "DUPLICATE_ID",
                "record_type":
                    record_type,
                "record_id":
                    record_id,
                "subject":
                    subject,
                "missing_parent_type":
                    "",
                "missing_parent_id":
                    "",
                "hash_snapshot_status":
                    "REVIEW",
                "issue":
                    f"{record_type} ID가 {int(count)}개 존재",
                "next_action":
                    "Append-only ID collision 여부와 Hash를 확인",
                "go_to":
                    "Review Queue",
            }
        )

    return rows


def _orphan_row(
    *,
    orphan_type: str,
    record_type: str,
    record_id: str,
    subject: str,
    missing_parent_type: str,
    missing_parent_id: str,
    hash_snapshot_status: str,
    issue: str,
    next_action: str,
    go_to: str,
) -> dict:
    return {
        "severity": "LC0",
        "orphan_type":
            orphan_type,
        "record_type":
            record_type,
        "record_id":
            record_id,
        "subject":
            subject,
        "missing_parent_type":
            missing_parent_type,
        "missing_parent_id":
            missing_parent_id,
        "hash_snapshot_status":
            hash_snapshot_status,
        "issue":
            issue,
        "next_action":
            next_action,
        "go_to":
            go_to,
    }


def build_learning_cycle_orphans(
    learning_lineages: pd.DataFrame | None,
    feedback_proposals: pd.DataFrame | None,
    bridge_drafts: pd.DataFrame | None,
    change_lineages: pd.DataFrame | None,
) -> pd.DataFrame:
    learning = _ensure_cols(
        learning_lineages,
        [
            "learning_lineage_id",
            "company",
            "lineage_hash",
        ],
    )
    feedback = _ensure_cols(
        feedback_proposals,
        [
            "feedback_id",
            "company",
            "source_learning_lineage_id",
            "source_learning_lineage_hash",
            "record_hash",
        ],
    )
    bridges = _ensure_cols(
        bridge_drafts,
        [
            "bridge_id",
            "company",
            "feedback_id",
            "feedback_record_hash",
            "record_hash",
        ],
    )
    closures = _ensure_cols(
        change_lineages,
        [
            "change_lineage_id",
            "company",
            "feedback_id",
            "feedback_record_hash",
            "bridge_id",
            "bridge_record_hash",
            "record_hash",
        ],
    )

    rows = []

    rows += _duplicate_orphans(
        learning,
        id_col="learning_lineage_id",
        record_type="Learning Lineage",
    )
    rows += _duplicate_orphans(
        feedback,
        id_col="feedback_id",
        record_type="Learning Feedback",
    )
    rows += _duplicate_orphans(
        bridges,
        id_col="bridge_id",
        record_type="Revalidation Bridge",
    )
    rows += _duplicate_orphans(
        closures,
        id_col="change_lineage_id",
        record_type="Change Lineage",
    )

    learning_map = {}
    for _, row in learning.iterrows():
        rid = _text(
            row.get(
                "learning_lineage_id"
            )
        )
        if rid:
            learning_map[rid] = row.to_dict()

    feedback_map = {}
    for _, row in feedback.iterrows():
        rid = _text(
            row.get(
                "feedback_id"
            )
        )
        if rid:
            feedback_map[rid] = row.to_dict()

    bridge_map = {}
    for _, row in bridges.iterrows():
        rid = _text(
            row.get(
                "bridge_id"
            )
        )
        if rid:
            bridge_map[rid] = row.to_dict()

    for _, row in feedback.iterrows():
        item = row.to_dict()
        rid = _text(
            item.get(
                "feedback_id"
            )
        )
        parent_id = _text(
            item.get(
                "source_learning_lineage_id"
            )
        )
        subject = _text(
            item.get(
                "company"
            )
        )

        if not parent_id or parent_id not in learning_map:
            rows.append(
                _orphan_row(
                    orphan_type="ORPHAN_FEEDBACK_SOURCE",
                    record_type="Learning Feedback",
                    record_id=rid,
                    subject=subject,
                    missing_parent_type="Learning Lineage",
                    missing_parent_id=parent_id,
                    hash_snapshot_status="MISSING_PARENT",
                    issue="Feedback가 존재하지만 source Learning Lineage를 찾을 수 없음",
                    next_action="Decision Journal의 Learning Lineage 원본과 Feedback source ID 확인",
                    go_to="Decision Journal",
                )
            )
            continue

        parent = learning_map[
            parent_id
        ]
        snapshot_hash = _text(
            item.get(
                "source_learning_lineage_hash"
            )
        )
        actual_hash = _text(
            parent.get(
                "lineage_hash"
            )
        )

        if (
            snapshot_hash
            and actual_hash
            and snapshot_hash
            != actual_hash
        ):
            rows.append(
                _orphan_row(
                    orphan_type="FEEDBACK_SOURCE_HASH_MISMATCH",
                    record_type="Learning Feedback",
                    record_id=rid,
                    subject=subject,
                    missing_parent_type="Learning Lineage",
                    missing_parent_id=parent_id,
                    hash_snapshot_status="MISMATCH",
                    issue="Feedback가 잠근 source Learning Lineage Hash와 현재 원본 Hash가 다름",
                    next_action="Learning Lineage / Feedback 변조 또는 잘못된 연결 여부 확인",
                    go_to="Decision Journal",
                )
            )

    for _, row in bridges.iterrows():
        item = row.to_dict()
        rid = _text(
            item.get(
                "bridge_id"
            )
        )
        parent_id = _text(
            item.get(
                "feedback_id"
            )
        )
        subject = _text(
            item.get(
                "company"
            )
        )

        if not parent_id or parent_id not in feedback_map:
            rows.append(
                _orphan_row(
                    orphan_type="ORPHAN_BRIDGE_FEEDBACK",
                    record_type="Revalidation Bridge",
                    record_id=rid,
                    subject=subject,
                    missing_parent_type="Learning Feedback",
                    missing_parent_id=parent_id,
                    hash_snapshot_status="MISSING_PARENT",
                    issue="Bridge Draft가 존재하지만 Learning Feedback 원본을 찾을 수 없음",
                    next_action="Learning Feedback Proposal과 Bridge feedback_id 확인",
                    go_to="Capital Productivity",
                )
            )
            continue

        parent = feedback_map[
            parent_id
        ]
        snapshot_hash = _text(
            item.get(
                "feedback_record_hash"
            )
        )
        actual_hash = _text(
            parent.get(
                "record_hash"
            )
        )

        if (
            snapshot_hash
            and actual_hash
            and snapshot_hash
            != actual_hash
        ):
            rows.append(
                _orphan_row(
                    orphan_type="BRIDGE_FEEDBACK_HASH_MISMATCH",
                    record_type="Revalidation Bridge",
                    record_id=rid,
                    subject=subject,
                    missing_parent_type="Learning Feedback",
                    missing_parent_id=parent_id,
                    hash_snapshot_status="MISMATCH",
                    issue="Bridge가 잠근 Feedback Hash와 현재 Feedback 원본 Hash가 다름",
                    next_action="Bridge / Feedback 연결 무결성 확인",
                    go_to="Capital Productivity",
                )
            )

    for _, row in closures.iterrows():
        item = row.to_dict()
        rid = _text(
            item.get(
                "change_lineage_id"
            )
        )
        feedback_id = _text(
            item.get(
                "feedback_id"
            )
        )
        bridge_id = _text(
            item.get(
                "bridge_id"
            )
        )
        subject = _text(
            item.get(
                "company"
            )
        )

        if (
            not feedback_id
            or feedback_id
            not in feedback_map
        ):
            rows.append(
                _orphan_row(
                    orphan_type="ORPHAN_CLOSURE_FEEDBACK",
                    record_type="Change Lineage",
                    record_id=rid,
                    subject=subject,
                    missing_parent_type="Learning Feedback",
                    missing_parent_id=feedback_id,
                    hash_snapshot_status="MISSING_PARENT",
                    issue="Change Lineage가 존재하지만 Feedback 원본을 찾을 수 없음",
                    next_action="Closure feedback_id와 Feedback Proposal 원본 확인",
                    go_to="Capital Productivity",
                )
            )
        else:
            parent = feedback_map[
                feedback_id
            ]
            snapshot_hash = _text(
                item.get(
                    "feedback_record_hash"
                )
            )
            actual_hash = _text(
                parent.get(
                    "record_hash"
                )
            )
            if (
                snapshot_hash
                and actual_hash
                and snapshot_hash
                != actual_hash
            ):
                rows.append(
                    _orphan_row(
                        orphan_type="CLOSURE_FEEDBACK_HASH_MISMATCH",
                        record_type="Change Lineage",
                        record_id=rid,
                        subject=subject,
                        missing_parent_type="Learning Feedback",
                        missing_parent_id=feedback_id,
                        hash_snapshot_status="MISMATCH",
                        issue="Change Lineage가 잠근 Feedback Hash와 원본 Hash가 다름",
                        next_action="Closure / Feedback 연결 무결성 확인",
                        go_to="Capital Productivity",
                    )
                )

        if (
            not bridge_id
            or bridge_id
            not in bridge_map
        ):
            rows.append(
                _orphan_row(
                    orphan_type="ORPHAN_CLOSURE_BRIDGE",
                    record_type="Change Lineage",
                    record_id=rid,
                    subject=subject,
                    missing_parent_type="Revalidation Bridge",
                    missing_parent_id=bridge_id,
                    hash_snapshot_status="MISSING_PARENT",
                    issue="Change Lineage가 존재하지만 Bridge Draft 원본을 찾을 수 없음",
                    next_action="Closure bridge_id와 Revalidation Draft 원본 확인",
                    go_to="Capital Productivity",
                )
            )
        else:
            parent = bridge_map[
                bridge_id
            ]
            snapshot_hash = _text(
                item.get(
                    "bridge_record_hash"
                )
            )
            actual_hash = _text(
                parent.get(
                    "record_hash"
                )
            )
            if (
                snapshot_hash
                and actual_hash
                and snapshot_hash
                != actual_hash
            ):
                rows.append(
                    _orphan_row(
                        orphan_type="CLOSURE_BRIDGE_HASH_MISMATCH",
                        record_type="Change Lineage",
                        record_id=rid,
                        subject=subject,
                        missing_parent_type="Revalidation Bridge",
                        missing_parent_id=bridge_id,
                        hash_snapshot_status="MISMATCH",
                        issue="Change Lineage가 잠근 Bridge Hash와 원본 Hash가 다름",
                        next_action="Closure / Bridge 연결 무결성 확인",
                        go_to="Capital Productivity",
                    )
                )

    if not rows:
        return pd.DataFrame(
            columns=
            LEARNING_CYCLE_ORPHAN_COLS
        )

    return pd.DataFrame(
        rows
    )[
        LEARNING_CYCLE_ORPHAN_COLS
    ].reset_index(
        drop=True
    )


def build_learning_cycle_coverage(
    learning_lineages: pd.DataFrame | None,
    feedback_proposals: pd.DataFrame | None,
    bridge_drafts: pd.DataFrame | None,
    change_lineages: pd.DataFrame | None,
    capital_productivity_inputs: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    revalidations: pd.DataFrame | None,
    *,
    today: date | None = None,
) -> pd.DataFrame:
    current_date = today or date.today()

    learning = _ensure_cols(
        learning_lineages,
        [
            "learning_lineage_id",
            "created_at",
            "company",
            "learning_status",
            "lineage_hash",
        ],
    )
    feedback = _ensure_cols(
        feedback_proposals,
        [
            "feedback_id",
            "created_at",
            "company",
            "source_learning_lineage_id",
            "feedback_target",
            "proposal_status",
            "review_due_date",
            "record_hash",
        ],
    )
    bridges = _ensure_cols(
        bridge_drafts,
        [
            "bridge_id",
            "created_at",
            "feedback_id",
            "company",
            "draft_status",
            "record_hash",
        ],
    )
    closures = _ensure_cols(
        change_lineages,
        [
            "change_lineage_id",
            "created_at",
            "feedback_id",
            "bridge_id",
            "closure_status",
            "record_hash",
        ],
    )

    completed = learning.loc[
        learning[
            "learning_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "LEARNING_COMPLETE"
        )
    ].copy()

    if completed.empty:
        return pd.DataFrame(
            columns=
            LEARNING_CYCLE_COVERAGE_COLS
        )

    rows = []

    for _, learn_row in completed.iterrows():
        learn = learn_row.to_dict()
        learning_id = _text(
            learn.get(
                "learning_lineage_id"
            )
        )
        company = _text(
            learn.get(
                "company"
            )
        )
        learning_integrity = (
            decision_learning_lineage_integrity(
                learn
            )[
                "status"
            ]
        )

        linked_feedback = feedback.loc[
            feedback[
                "source_learning_lineage_id"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(
                learning_id
            )
        ].copy()

        if linked_feedback.empty:
            rows.append(
                {
                    "priority": "LC1",
                    "bucket": "NO DATE",
                    "due_date": "",
                    "days_to_due": None,
                    "company": company,
                    "learning_lineage_id":
                        learning_id,
                    "learning_integrity":
                        learning_integrity,
                    "feedback_id": "",
                    "feedback_target": "",
                    "feedback_status": "MISSING",
                    "feedback_integrity": "",
                    "bridge_id": "",
                    "bridge_status": "",
                    "bridge_integrity": "",
                    "source_review_status": "",
                    "source_review_id": "",
                    "proposal_outcome": "",
                    "closure_status": "",
                    "closure_integrity": "",
                    "cycle_status":
                        (
                            "INTEGRITY_REVIEW"
                            if learning_integrity
                            != "OK"
                            else "FEEDBACK_MISSING"
                        ),
                    "issue":
                        (
                            "LEARNING_LINEAGE_INTEGRITY_FAILED"
                            if learning_integrity
                            != "OK"
                            else "LEARNING_COMPLETE_WITHOUT_FEEDBACK"
                        ),
                    "next_action":
                        "Decision Journal → Learning Feedback에서 학습 반영 여부를 명시",
                    "go_to":
                        "Decision Journal",
                }
            )
            continue

        linked_feedback[
            "_ts"
        ] = pd.to_datetime(
            linked_feedback[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        linked_feedback = linked_feedback.sort_values(
            "_ts",
            ascending=True,
            na_position="last",
        ).drop(
            columns=[
                "_ts"
            ]
        )

        for _, fb_row in linked_feedback.iterrows():
            fb = fb_row.to_dict()
            feedback_id = _text(
                fb.get(
                    "feedback_id"
                )
            )
            target = _text(
                fb.get(
                    "feedback_target"
                )
            ).upper()
            feedback_status = _text(
                fb.get(
                    "proposal_status"
                )
            ).upper()
            feedback_integrity = (
                learning_feedback_record_integrity(
                    fb
                )[
                    "status"
                ]
            )

            due_date = _text(
                fb.get(
                    "review_due_date"
                )
            )
            bucket, days = _bucket_for_due(
                due_date,
                current_date,
            )

            base = {
                "bucket":
                    bucket,
                "due_date":
                    due_date,
                "days_to_due":
                    days,
                "company":
                    company,
                "learning_lineage_id":
                    learning_id,
                "learning_integrity":
                    learning_integrity,
                "feedback_id":
                    feedback_id,
                "feedback_target":
                    target,
                "feedback_status":
                    feedback_status,
                "feedback_integrity":
                    feedback_integrity,
                "bridge_id":
                    "",
                "bridge_status":
                    "",
                "bridge_integrity":
                    "",
                "source_review_status":
                    "",
                "source_review_id":
                    "",
                "proposal_outcome":
                    "",
                "closure_status":
                    "",
                "closure_integrity":
                    "",
            }

            if (
                learning_integrity
                != "OK"
                or feedback_integrity
                != "OK"
            ):
                rows.append(
                    {
                        **base,
                        "priority": "LC0",
                        "cycle_status":
                            "INTEGRITY_REVIEW",
                        "issue":
                            "LEARNING_OR_FEEDBACK_INTEGRITY_FAILED",
                        "next_action":
                            "Learning Lineage / Feedback Hash 무결성 확인",
                        "go_to":
                            "Decision Journal",
                    }
                )
                continue

            if (
                feedback_status
                != "APPROVED_FOR_REVALIDATION"
            ):
                rows.append(
                    {
                        **base,
                        "priority": "LC1",
                        "cycle_status":
                            "FEEDBACK_REVIEW",
                        "issue":
                            "FEEDBACK_NOT_APPROVED_FOR_REVALIDATION",
                        "next_action":
                            "Learning Feedback Human Review 완료",
                        "go_to":
                            "Decision Journal",
                    }
                )
                continue

            if target not in ASSUMPTION_TARGETS:
                rows.append(
                    {
                        **base,
                        "priority": "LC5",
                        "cycle_status":
                            "EXTERNAL_ROUTE",
                        "issue":
                            "NON_ASSUMPTION_TARGET_ROUTED_OUTSIDE_CAPITAL_PRODUCTIVITY",
                        "next_action":
                            "Target별 원본 Review 화면에서 후속 조치",
                        "go_to":
                            "Review Queue",
                    }
                )
                continue

            linked_bridges = bridges.loc[
                bridges[
                    "feedback_id"
                ]
                .fillna("")
                .astype(str)
                .str.strip()
                .eq(
                    feedback_id
                )
            ].copy()

            if linked_bridges.empty:
                rows.append(
                    {
                        **base,
                        "priority": "LC1",
                        "cycle_status":
                            "BRIDGE_MISSING",
                        "issue":
                            "APPROVED_FEEDBACK_WITHOUT_REVALIDATION_DRAFT",
                        "next_action":
                            "Capital Productivity 1F에서 Revalidation Draft 생성",
                        "go_to":
                            "Capital Productivity",
                    }
                )
                continue

            bridge = _latest_by_time(
                linked_bridges,
                "created_at",
            )
            bridge_id = _text(
                bridge.get(
                    "bridge_id"
                )
            )
            bridge_status = _text(
                bridge.get(
                    "draft_status"
                )
            ).upper()
            bridge_integrity = (
                feedback_revalidation_draft_integrity(
                    bridge
                )[
                    "status"
                ]
            )

            base.update(
                {
                    "bridge_id":
                        bridge_id,
                    "bridge_status":
                        bridge_status,
                    "bridge_integrity":
                        bridge_integrity,
                }
            )

            if bridge_integrity != "OK":
                rows.append(
                    {
                        **base,
                        "priority": "LC0",
                        "cycle_status":
                            "INTEGRITY_REVIEW",
                        "issue":
                            "BRIDGE_DRAFT_INTEGRITY_FAILED",
                        "next_action":
                            "Revalidation Draft Hash 무결성 확인",
                        "go_to":
                            "Capital Productivity",
                    }
                )
                continue

            if (
                bridge_status
                != "READY_FOR_SOURCE_REVIEW"
            ):
                rows.append(
                    {
                        **base,
                        "priority": "LC1",
                        "cycle_status":
                            "BRIDGE_REVIEW",
                        "issue":
                            "REVALIDATION_DRAFT_NOT_READY",
                        "next_action":
                            "Capital Productivity 1F Bridge Human Review 완료",
                        "go_to":
                            "Capital Productivity",
                    }
                )
                continue

            change_context = build_feedback_change_context(
                bridge,
                fb,
                capital_productivity_inputs,
                calibration_drafts,
                revalidations,
            )

            base.update(
                {
                    "source_review_status":
                        change_context[
                            "closure_readiness"
                        ],
                    "source_review_id":
                        change_context[
                            "source_review_id"
                        ],
                    "proposal_outcome":
                        change_context[
                            "proposal_outcome"
                        ],
                }
            )

            latest_closure = latest_feedback_closure_record(
                closures,
                feedback_id,
            )

            if not latest_closure:
                if (
                    change_context[
                        "closure_readiness"
                    ]
                    == "SOURCE_REVIEW_PENDING"
                ):
                    rows.append(
                        {
                            **base,
                            "priority": "LC2",
                            "cycle_status":
                                "SOURCE_REVIEW_PENDING",
                            "issue":
                                "SOURCE_REVIEW_NOT_FOUND_AFTER_BRIDGE",
                            "next_action":
                                "Calibration/Revalidation 원본 Human Review 완료",
                            "go_to":
                                "Capital Productivity",
                        }
                    )
                elif (
                    change_context[
                        "closure_readiness"
                    ]
                    == "READY_FOR_CLOSURE"
                ):
                    rows.append(
                        {
                            **base,
                            "priority": "LC3",
                            "cycle_status":
                                "CLOSURE_PENDING",
                            "issue":
                                "SOURCE_REVIEW_COMPLETE_CLOSURE_PENDING",
                            "next_action":
                                "Capital Productivity 1G에서 Feedback Closure 검토",
                            "go_to":
                                "Capital Productivity",
                        }
                    )
                else:
                    rows.append(
                        {
                            **base,
                            "priority": "LC0",
                            "cycle_status":
                                "INTEGRITY_REVIEW",
                            "issue":
                                " | ".join(
                                    change_context[
                                        "issues"
                                    ]
                                ),
                            "next_action":
                                "Source Review / Live Register / Hash 일치 확인",
                            "go_to":
                                "Capital Productivity",
                        }
                    )
                continue

            closure_integrity = (
                feedback_change_lineage_integrity(
                    latest_closure
                )[
                    "status"
                ]
            )
            closure_status = _text(
                latest_closure.get(
                    "closure_status"
                )
            ).upper()

            base.update(
                {
                    "closure_status":
                        closure_status,
                    "closure_integrity":
                        closure_integrity,
                }
            )

            if closure_integrity != "OK":
                rows.append(
                    {
                        **base,
                        "priority": "LC0",
                        "cycle_status":
                            "INTEGRITY_REVIEW",
                        "issue":
                            "CHANGE_LINEAGE_INTEGRITY_FAILED",
                        "next_action":
                            "Learning Feedback Change Lineage Hash 확인",
                        "go_to":
                            "Capital Productivity",
                    }
                )
            elif (
                closure_status
                == "CLOSED_SOURCE_REVIEWED"
            ):
                rows.append(
                    {
                        **base,
                        "priority": "LC6",
                        "cycle_status":
                            "CLOSED",
                        "issue":
                            "",
                        "next_action":
                            "다음 Proof / Evidence까지 append-only 기록 유지",
                        "go_to":
                            "Decision Journal",
                    }
                )
            elif (
                closure_status
                == "OPEN_MORE_EVIDENCE"
            ):
                rows.append(
                    {
                        **base,
                        "priority": "LC4",
                        "cycle_status":
                            "OPEN_MORE_EVIDENCE",
                        "issue":
                            "HUMAN_REQUESTED_MORE_EVIDENCE",
                        "next_action":
                            "새 Evidence / Proof 이후 Closure 재검토",
                        "go_to":
                            "Capital Productivity",
                    }
                )
            else:
                rows.append(
                    {
                        **base,
                        "priority": "LC3",
                        "cycle_status":
                            "CLOSURE_REVIEW",
                        "issue":
                            "LATEST_CLOSURE_NOT_FINAL",
                        "next_action":
                            "Capital Productivity 1G Closure 상태 재검토",
                        "go_to":
                            "Capital Productivity",
                    }
                )

    if not rows:
        return pd.DataFrame(
            columns=
            LEARNING_CYCLE_COVERAGE_COLS
        )

    out = pd.DataFrame(
        rows
    )

    p_order = {
        "LC0": 0,
        "LC1": 1,
        "LC2": 2,
        "LC3": 3,
        "LC4": 4,
        "LC5": 5,
        "LC6": 6,
    }
    b_order = {
        "OVERDUE": 0,
        "TODAY": 1,
        "NEXT 7 DAYS": 2,
        "NEXT 30 DAYS": 3,
        "FUTURE": 4,
        "NO DATE": 5,
    }

    out["_p"] = out[
        "priority"
    ].map(
        p_order
    ).fillna(
        9
    )
    out["_b"] = out[
        "bucket"
    ].map(
        b_order
    ).fillna(
        9
    )

    out = out.sort_values(
        [
            "_p",
            "_b",
            "due_date",
            "company",
            "feedback_id",
        ],
        ascending=[
            True,
            True,
            True,
            True,
            True,
        ],
        na_position="last",
    ).drop(
        columns=[
            "_p",
            "_b",
        ]
    )

    return out[
        LEARNING_CYCLE_COVERAGE_COLS
    ].reset_index(
        drop=True
    )


def learning_cycle_audit_summary(
    coverage: pd.DataFrame | None,
    orphans: pd.DataFrame | None,
    learning_lineages: pd.DataFrame | None = None,
) -> dict:
    cov = (
        pd.DataFrame()
        if coverage is None
        else coverage.copy()
    )
    orphan_df = (
        pd.DataFrame()
        if orphans is None
        else orphans.copy()
    )

    learning_complete = 0
    learning_integrity_issues = 0

    if (
        learning_lineages is not None
        and not learning_lineages.empty
    ):
        ldf = learning_lineages.copy()
        if "learning_status" not in ldf.columns:
            ldf[
                "learning_status"
            ] = ""
        complete = ldf.loc[
            ldf[
                "learning_status"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq(
                "LEARNING_COMPLETE"
            )
        ]
        learning_complete = int(
            len(
                complete
            )
        )
        for _, row in complete.iterrows():
            if decision_learning_lineage_integrity(
                row.to_dict()
            )[
                "status"
            ] != "OK":
                learning_integrity_issues += 1

    if cov.empty:
        statuses = pd.Series(
            dtype=str
        )
    else:
        statuses = (
            cov[
                "cycle_status"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
        )

    feedback_covered = 0
    if not cov.empty:
        feedback_covered = int(
            cov.loc[
                cov[
                    "feedback_id"
                ]
                .fillna("")
                .astype(str)
                .str.strip()
                .ne("")
            ][
                "learning_lineage_id"
            ]
            .nunique()
        )

    feedback_missing = int(
        statuses.eq(
            "FEEDBACK_MISSING"
        ).sum()
    )
    assumption_feedback = int(
        (
            cov[
                "feedback_target"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .isin(
                ASSUMPTION_TARGETS
            )
            & cov[
                "feedback_status"
            ]
            .fillna("")
            .astype(str)
            .str.upper()
            .eq(
                "APPROVED_FOR_REVALIDATION"
            )
        ).sum()
    ) if not cov.empty else 0

    bridge_ready = int(
        cov[
            "bridge_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "READY_FOR_SOURCE_REVIEW"
        ).sum()
    ) if not cov.empty else 0

    integrity_orphans = int(
        len(
            orphan_df
        )
    )
    integrity_cycle = int(
        statuses.eq(
            "INTEGRITY_REVIEW"
        ).sum()
    )

    pending_count = int(
        statuses.isin(
            [
                "FEEDBACK_MISSING",
                "FEEDBACK_REVIEW",
                "BRIDGE_MISSING",
                "BRIDGE_REVIEW",
                "SOURCE_REVIEW_PENDING",
                "CLOSURE_PENDING",
                "CLOSURE_REVIEW",
                "OPEN_MORE_EVIDENCE",
            ]
        ).sum()
    )

    if (
        learning_integrity_issues
        + integrity_orphans
        + integrity_cycle
        > 0
    ):
        audit_status = "INTEGRITY_REVIEW"
    elif learning_complete == 0:
        audit_status = "NO_CYCLES"
    elif pending_count > 0:
        audit_status = "OPEN_ITEMS"
    else:
        audit_status = "PASS"

    return {
        "audit_status":
            audit_status,
        "learning_complete":
            learning_complete,
        "learning_integrity_issues":
            learning_integrity_issues,
        "feedback_covered":
            feedback_covered,
        "feedback_missing":
            feedback_missing,
        "assumption_feedback":
            assumption_feedback,
        "bridge_ready":
            bridge_ready,
        "source_review_pending":
            int(
                statuses.eq(
                    "SOURCE_REVIEW_PENDING"
                ).sum()
            ),
        "closure_pending":
            int(
                statuses.isin(
                    [
                        "CLOSURE_PENDING",
                        "CLOSURE_REVIEW",
                    ]
                ).sum()
            ),
        "open_more_evidence":
            int(
                statuses.eq(
                    "OPEN_MORE_EVIDENCE"
                ).sum()
            ),
        "closed_source_reviewed":
            int(
                statuses.eq(
                    "CLOSED"
                ).sum()
            ),
        "external_route":
            int(
                statuses.eq(
                    "EXTERNAL_ROUTE"
                ).sum()
            ),
        "orphan_count":
            integrity_orphans,
        "hash_or_integrity_issues":
            (
                learning_integrity_issues
                + integrity_cycle
                + integrity_orphans
            ),
        "execution_authorization":
            "NONE",
    }


def build_learning_cycle_audit_snapshot(
    summary: dict,
    coverage: pd.DataFrame | None,
    orphans: pd.DataFrame | None,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    coverage_payload = (
        []
        if coverage is None
        or coverage.empty
        else coverage.fillna(
            ""
        ).to_dict(
            orient="records"
        )
    )
    orphan_payload = (
        []
        if orphans is None
        or orphans.empty
        else orphans.fillna(
            ""
        ).to_dict(
            orient="records"
        )
    )

    snapshot_payload = {
        "summary":
            summary,
        "coverage":
            coverage_payload,
        "orphans":
            orphan_payload,
    }
    snapshot_hash = _hash(
        snapshot_payload
    )

    audit_id = (
        "LCA-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + snapshot_hash[:8]
    )

    row = {
        "audit_id":
            audit_id,
        "created_at":
            now,
        "audit_status":
            _text(
                summary.get(
                    "audit_status"
                )
            ),
        "learning_complete":
            int(
                summary.get(
                    "learning_complete",
                    0,
                )
            ),
        "learning_integrity_issues":
            int(
                summary.get(
                    "learning_integrity_issues",
                    0,
                )
            ),
        "feedback_covered":
            int(
                summary.get(
                    "feedback_covered",
                    0,
                )
            ),
        "feedback_missing":
            int(
                summary.get(
                    "feedback_missing",
                    0,
                )
            ),
        "assumption_feedback":
            int(
                summary.get(
                    "assumption_feedback",
                    0,
                )
            ),
        "bridge_ready":
            int(
                summary.get(
                    "bridge_ready",
                    0,
                )
            ),
        "source_review_pending":
            int(
                summary.get(
                    "source_review_pending",
                    0,
                )
            ),
        "closure_pending":
            int(
                summary.get(
                    "closure_pending",
                    0,
                )
            ),
        "open_more_evidence":
            int(
                summary.get(
                    "open_more_evidence",
                    0,
                )
            ),
        "closed_source_reviewed":
            int(
                summary.get(
                    "closed_source_reviewed",
                    0,
                )
            ),
        "external_route":
            int(
                summary.get(
                    "external_route",
                    0,
                )
            ),
        "orphan_count":
            int(
                summary.get(
                    "orphan_count",
                    0,
                )
            ),
        "hash_or_integrity_issues":
            int(
                summary.get(
                    "hash_or_integrity_issues",
                    0,
                )
            ),
        "execution_authorization":
            "NONE",
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
    return row
