from __future__ import annotations

from datetime import date, datetime
from typing import Any

import pandas as pd


RISK_REPAIR_OVERRIDE_COLS = [
    "reviewed_at",
    "handoff_source",
    "donor",
    "recipient",
    "migration_amount_krw",
    "economic_switching_gate",
    "risk_repair_eligibility",
    "eligibility_reason",
    "car_delta",
    "net_switching_gap",
    "migration_hurdle",
    "donor_lifecycle",
    "reconciliation_gate",
    "donor_liquidity_gate",
    "risk_repair_reason",
    "thesis_lifecycle_confirmed",
    "valuation_confirmed",
    "cost_confirmed",
    "liquidity_reconciliation_confirmed",
    "risk_purpose_confirmed",
    "human_confirmed",
    "review_due_date",
    "expiry_gate",
    "governance_gate",
    "final_decision",
    "execution_authorization",
    "note",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    if pd.isna(out):
        return None
    return out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE",
        "1",
        "YES",
        "Y",
        "PASS",
    }


def risk_repair_eligibility(
    review: dict | None,
    *,
    recipient_kind: str,
    donor_lifecycle: str,
    reconciliation_gate: str,
    donor_liquidity_gate: str,
    factor_risk_repair_gate: str = "N/A",
) -> dict:
    """
    Eligibility is not approval.

    PASS only means the current case may use the separate Risk Repair
    governance path even if the economic switching gap is blocked.
    """
    r = review or {}

    decision_status = _text(
        r.get("decision_status")
    ).upper()
    donor_capacity = _text(
        r.get("donor_capacity_gate")
    ).upper()
    cash_reserve = _text(
        r.get("cash_reserve_gate")
    ).upper()
    car_delta = _num(
        r.get("car_delta")
    )
    recipient = _text(
        recipient_kind
    ).upper()
    lifecycle = _text(
        donor_lifecycle
    ).upper()
    reconciliation = _text(
        reconciliation_gate
    ).upper()
    liquidity = _text(
        donor_liquidity_gate
    ).upper()
    factor_gate = _text(
        factor_risk_repair_gate
    ).upper()

    hard_failures = []
    reviews = []

    if recipient != "CASH":
        hard_failures.append(
            "RECIPIENT_NOT_CASH"
        )

    if car_delta is None or car_delta >= 0:
        hard_failures.append(
            "CAR_RELIEF_NOT_POSITIVE"
        )

    if donor_capacity != "PASS":
        hard_failures.append(
            "DONOR_CAPACITY_NOT_PASS"
        )

    if cash_reserve != "PASS":
        hard_failures.append(
            "CASH_RESERVE_NOT_PASS"
        )

    if reconciliation != "PASS":
        hard_failures.append(
            "RECONCILIATION_NOT_PASS"
        )

    if liquidity == "REVIEW":
        reviews.append(
            "DONOR_LIQUIDITY_REVIEW"
        )
    elif liquidity == "TIGHT":
        reviews.append(
            "DONOR_LIQUIDITY_TIGHT"
        )
    elif liquidity != "PASS":
        reviews.append(
            "DONOR_LIQUIDITY_NOT_PASS"
        )

    lifecycle_ok = lifecycle in {
        "TRIM",
        "EXIT",
    }
    factor_ok = factor_gate == "PASS"

    if not lifecycle_ok and not factor_ok:
        reviews.append(
            "NO_TRIM_EXIT_OR_FACTOR_REPAIR_GATE"
        )

    explicit_risk_repair_status = (
        "RISK REPAIR"
        in decision_status
    )

    if not explicit_risk_repair_status:
        reviews.append(
            "MIGRATION_STATUS_NOT_RISK_REPAIR"
        )

    if hard_failures:
        status = "BLOCKED"
        reason = " | ".join(
            hard_failures
            + reviews
        )
    elif reviews:
        status = "REVIEW"
        reason = " | ".join(
            reviews
        )
    else:
        status = "PASS"
        reason = "RISK_REPAIR_PATH_ELIGIBLE"

    return {
        "status": status,
        "reason": reason,
        "car_delta": (
            car_delta
            if car_delta is not None
            else 0.0
        ),
        "decision_status": decision_status,
        "lifecycle_ok": lifecycle_ok,
        "factor_repair_ok": factor_ok,
        "hard_failures": hard_failures,
        "reviews": reviews,
    }


def risk_repair_governance_gate(
    *,
    eligibility_status: str,
    economic_switching_gate: str,
    risk_repair_reason: str,
    thesis_lifecycle_confirmed: bool,
    valuation_confirmed: bool,
    cost_confirmed: bool,
    liquidity_reconciliation_confirmed: bool,
    risk_purpose_confirmed: bool,
    human_confirmed: bool,
    review_due_date: date | str | None,
    max_review_days: int = 90,
    today: date | None = None,
) -> dict:
    """
    Stronger governance for an override-like Risk Repair path.

    A PASS governance gate creates a review record only.
    It never authorizes execution.
    """
    current_date = today or date.today()

    try:
        if isinstance(
            review_due_date,
            date,
        ):
            due = review_due_date
        else:
            due = pd.to_datetime(
                review_due_date,
                errors="coerce",
            )
            due = (
                None
                if pd.isna(due)
                else due.date()
            )
    except Exception:
        due = None

    expiry_gate = "REVIEW"
    expiry_reason = "REVIEW_DUE_DATE_REQUIRED"

    if due is not None:
        days = (
            due
            - current_date
        ).days

        if days < 0:
            expiry_gate = "EXPIRED"
            expiry_reason = "REVIEW_DATE_EXPIRED"
        elif days == 0:
            expiry_gate = "REVIEW"
            expiry_reason = "REVIEW_DATE_NOT_FUTURE"
        elif days > int(
            max_review_days
        ):
            expiry_gate = "REVIEW"
            expiry_reason = "REVIEW_DATE_BEYOND_POLICY_MAX"
        else:
            expiry_gate = "PASS"
            expiry_reason = "REVIEW_DATE_VALID"

    missing = []

    if _text(
        eligibility_status
    ).upper() != "PASS":
        missing.append(
            "RISK_REPAIR_ELIGIBILITY_NOT_PASS"
        )

    if not _text(
        risk_repair_reason
    ):
        missing.append(
            "RISK_REPAIR_REASON_REQUIRED"
        )

    confirmations = {
        "THESIS_LIFECYCLE_REVIEW_REQUIRED":
            _bool(
                thesis_lifecycle_confirmed
            ),
        "VALUATION_REVIEW_REQUIRED":
            _bool(
                valuation_confirmed
            ),
        "COST_REVIEW_REQUIRED":
            _bool(
                cost_confirmed
            ),
        "LIQUIDITY_RECONCILIATION_REVIEW_REQUIRED":
            _bool(
                liquidity_reconciliation_confirmed
            ),
        "RISK_PURPOSE_CONFIRMATION_REQUIRED":
            _bool(
                risk_purpose_confirmed
            ),
        "HUMAN_FINAL_CONFIRMATION_REQUIRED":
            _bool(
                human_confirmed
            ),
    }

    for issue, passed in confirmations.items():
        if not passed:
            missing.append(
                issue
            )

    if expiry_gate != "PASS":
        missing.append(
            expiry_reason
        )

    governance_gate = (
        "PASS"
        if not missing
        else "REVIEW"
    )

    economic_gate = _text(
        economic_switching_gate
    ).upper() or "REVIEW"

    if governance_gate == "PASS":
        final_decision = (
            "GOVERNANCE REVIEW COMPLETE"
        )
    else:
        final_decision = (
            "HUMAN REVIEW REQUIRED"
        )

    return {
        "economic_switching_gate": economic_gate,
        "governance_gate": governance_gate,
        "final_decision": final_decision,
        "execution_authorization": "NONE",
        "expiry_gate": expiry_gate,
        "expiry_reason": expiry_reason,
        "review_due_date": (
            due.isoformat()
            if due is not None
            else ""
        ),
        "missing": missing,
    }


def risk_repair_override_record(
    *,
    handoff_source: str,
    donor: str,
    recipient: str,
    migration_amount_krw: float,
    review: dict,
    eligibility: dict,
    governance: dict,
    donor_lifecycle: str,
    reconciliation_gate: str,
    donor_liquidity_gate: str,
    risk_repair_reason: str,
    thesis_lifecycle_confirmed: bool,
    valuation_confirmed: bool,
    cost_confirmed: bool,
    liquidity_reconciliation_confirmed: bool,
    risk_purpose_confirmed: bool,
    human_confirmed: bool,
    note: str = "",
) -> dict:
    return {
        "reviewed_at":
            datetime.now().isoformat(),
        "handoff_source":
            _text(handoff_source),
        "donor":
            _text(donor),
        "recipient":
            _text(recipient),
        "migration_amount_krw":
            float(
                _num(
                    migration_amount_krw
                )
                or 0.0
            ),
        "economic_switching_gate":
            _text(
                governance.get(
                    "economic_switching_gate"
                )
            ),
        "risk_repair_eligibility":
            _text(
                eligibility.get(
                    "status"
                )
            ),
        "eligibility_reason":
            _text(
                eligibility.get(
                    "reason"
                )
            ),
        "car_delta":
            float(
                _num(
                    review.get(
                        "car_delta"
                    )
                )
                or 0.0
            ),
        "net_switching_gap":
            float(
                _num(
                    review.get(
                        "net_switching_gap"
                    )
                )
                or 0.0
            ),
        "migration_hurdle":
            float(
                _num(
                    review.get(
                        "migration_hurdle"
                    )
                )
                or 0.0
            ),
        "donor_lifecycle":
            _text(
                donor_lifecycle
            ),
        "reconciliation_gate":
            _text(
                reconciliation_gate
            ),
        "donor_liquidity_gate":
            _text(
                donor_liquidity_gate
            ),
        "risk_repair_reason":
            _text(
                risk_repair_reason
            ),
        "thesis_lifecycle_confirmed":
            bool(
                thesis_lifecycle_confirmed
            ),
        "valuation_confirmed":
            bool(
                valuation_confirmed
            ),
        "cost_confirmed":
            bool(
                cost_confirmed
            ),
        "liquidity_reconciliation_confirmed":
            bool(
                liquidity_reconciliation_confirmed
            ),
        "risk_purpose_confirmed":
            bool(
                risk_purpose_confirmed
            ),
        "human_confirmed":
            bool(
                human_confirmed
            ),
        "review_due_date":
            _text(
                governance.get(
                    "review_due_date"
                )
            ),
        "expiry_gate":
            _text(
                governance.get(
                    "expiry_gate"
                )
            ),
        "governance_gate":
            _text(
                governance.get(
                    "governance_gate"
                )
            ),
        "final_decision":
            _text(
                governance.get(
                    "final_decision"
                )
            ),
        "execution_authorization":
            _text(
                governance.get(
                    "execution_authorization"
                )
            ),
        "note":
            _text(note),
    }
