from __future__ import annotations

from datetime import date
from typing import Any
import hashlib
import json

import pandas as pd

from engine.review_queue_compression import (
    compress_review_queue,
)
from engine.operations_carry_forward import (
    build_carry_forward_aging,
)
from engine.operations_recurrence import (
    build_recurrence_diagnostics,
    build_capacity_rebalance_plan,
)
from engine.operations_sla_governance import (
    capacity_override_integrity,
    latest_active_override,
    effective_capacity,
    build_sla_release_gate,
)


V127_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]


V127_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _snapshot_payload(row: dict) -> dict:
    return {
        "sla_state":
            _text(row.get("sla_state")),
        "sla_breach_groups":
            _int(row.get("sla_breach_groups")),
        "persistent_groups":
            _int(row.get("persistent_groups")),
        "chronic_groups":
            _int(row.get("chronic_groups")),
        "selected_groups":
            _int(row.get("selected_groups")),
        "deferred_groups":
            _int(row.get("deferred_groups")),
        "base_capacity":
            _int(row.get("base_capacity")),
        "effective_capacity":
            _int(row.get("effective_capacity")),
        "active_override_id":
            _text(row.get("active_override_id")),
        "active_override_integrity":
            _text(row.get("active_override_integrity")),
        "override_expiry_date":
            _text(row.get("override_expiry_date")),
        "root_cause_top":
            _text(row.get("root_cause_top")),
        "technical_gate":
            _text(row.get("technical_gate")),
        "technical_fail":
            _int(row.get("technical_fail")),
        "execution_authorization":
            _text(row.get("execution_authorization")),
    }


def sla_closure_snapshot_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(record.get("snapshot_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _snapshot_payload(record)
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_sla_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    if snapshots is None or snapshots.empty:
        return {}

    df = snapshots.copy()

    if "created_at" in df.columns:
        df["_ts"] = pd.to_datetime(
            df["created_at"],
            errors="coerce",
            utc=True,
        )
        df = df.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        df.iloc[0]
        .drop(
            labels=["_ts"],
            errors="ignore",
        )
        .to_dict()
    )


def _record_integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = 0
    ok = 0
    missing = 0
    mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def build_v127_operating_context(
    *,
    review_queue: pd.DataFrame | None,
    sessions: pd.DataFrame | None,
    overrides: pd.DataFrame | None,
    sla_snapshots: pd.DataFrame | None,
    today: date | str | None = None,
    session_capacity: int = 5,
) -> dict:
    compression = compress_review_queue(
        review_queue
    )

    carry_forward = build_carry_forward_aging(
        compression[
            "groups"
        ],
        sessions,
        today=today,
    )

    recurrence = build_recurrence_diagnostics(
        carry_forward[
            "table"
        ]
    )

    rebalance = build_capacity_rebalance_plan(
        recurrence,
        session_capacity=session_capacity,
    )

    active_override = latest_active_override(
        overrides,
        today=today,
    )

    capacity_state = effective_capacity(
        session_capacity,
        active_override,
    )

    sla_gate = build_sla_release_gate(
        recurrence,
        rebalance,
        active_override,
        capacity_state,
    )

    latest_snapshot = latest_sla_snapshot(
        sla_snapshots
    )
    latest_snapshot_integrity = (
        sla_closure_snapshot_integrity(
            latest_snapshot
        )[
            "status"
        ]
        if latest_snapshot
        else "NONE"
    )

    override_integrity = _record_integrity_counts(
        overrides,
        capacity_override_integrity,
    )

    snapshot_integrity = _record_integrity_counts(
        sla_snapshots,
        sla_closure_snapshot_integrity,
    )

    return {
        "compression":
            compression,
        "carry_forward":
            carry_forward,
        "recurrence":
            recurrence,
        "rebalance":
            rebalance,
        "active_override":
            active_override,
        "capacity_state":
            capacity_state,
        "sla_gate":
            sla_gate,
        "latest_snapshot":
            latest_snapshot,
        "latest_snapshot_integrity":
            latest_snapshot_integrity,
        "override_integrity":
            override_integrity,
        "snapshot_integrity":
            snapshot_integrity,
        "execution_authorization":
            "NONE",
    }


def build_v127_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    compression = ctx.get("compression") or {}
    carry = ctx.get("carry_forward") or {}
    recurrence = ctx.get("recurrence") or {}
    rebalance = ctx.get("rebalance") or {}
    cap_state = ctx.get("capacity_state") or {}
    live_sla = ctx.get("sla_gate") or {}
    override_counts = ctx.get("override_integrity") or {}
    snapshot_counts = ctx.get("snapshot_integrity") or {}

    checks = []

    def technical(check, passed, detail, action):
        checks.append(
            {
                "layer": "TECHNICAL",
                "check": check,
                "status": "PASS" if passed else "FAIL",
                "detail": detail,
                "action": "" if passed else action,
            }
        )

    live_gate = _text(
        live_sla.get("release_gate")
    ).upper()

    technical(
        "Live Operating SLA Technical Gate",
        live_gate == "PASS",
        (
            f"{live_gate or 'MISSING'} · "
            f"state {_text(live_sla.get('sla_state')) or 'MISSING'}"
        ),
        "Operations Control Tower 1E의 SLA Technical Gate를 먼저 복구",
    )

    action_groups = _int(
        compression.get("action_groups")
    )
    recurrence_table = recurrence.get("table")
    recurrence_groups = (
        int(len(recurrence_table))
        if isinstance(recurrence_table, pd.DataFrame)
        else -1
    )
    selected = _int(
        rebalance.get("selected_groups")
    )
    deferred = _int(
        rebalance.get("deferred_groups")
    )

    consistency_ok = (
        recurrence_groups == action_groups
        and selected + deferred == action_groups
    )

    technical(
        "Carry-forward / Recurrence / Rebalance Consistency",
        consistency_ok,
        (
            f"action groups {action_groups} · "
            f"recurrence groups {recurrence_groups} · "
            f"selected {selected} · deferred {deferred}"
        ),
        "Compression → Carry-forward → Recurrence → Rebalance group count 연결 확인",
    )

    override_fail = (
        _int(override_counts.get("missing"))
        + _int(override_counts.get("mismatch"))
    )

    technical(
        "Capacity Override Immutable Record Integrity",
        override_fail == 0,
        (
            f"records {_int(override_counts.get('total'))} · "
            f"OK {_int(override_counts.get('ok'))} · "
            f"MISSING {_int(override_counts.get('missing'))} · "
            f"MISMATCH {_int(override_counts.get('mismatch'))}"
        ),
        "operations_capacity_overrides.csv immutable hash 확인",
    )

    snapshot_fail = (
        _int(snapshot_counts.get("missing"))
        + _int(snapshot_counts.get("mismatch"))
    )

    technical(
        "Operating SLA Closure Snapshot Integrity",
        snapshot_fail == 0,
        (
            f"records {_int(snapshot_counts.get('total'))} · "
            f"OK {_int(snapshot_counts.get('ok'))} · "
            f"MISSING {_int(snapshot_counts.get('missing'))} · "
            f"MISMATCH {_int(snapshot_counts.get('mismatch'))}"
        ),
        "operations_sla_closure_snapshots.csv snapshot hash 확인",
    )

    effective_cap = _int(
        cap_state.get("effective_capacity")
    )

    technical(
        "Effective Session Capacity Hard Cap",
        1 <= effective_cap <= 10,
        f"effective capacity {effective_cap}",
        "Effective Session Capacity를 1~10 범위로 복구",
    )

    auth_violations = 0

    for key in [
        "execution_authorization",
    ]:
        if _text(ctx.get(key)).upper() != "NONE":
            auth_violations += 1

    for df, column in [
        (
            ctx.get("latest_snapshot"),
            "execution_authorization",
        ),
        (
            ctx.get("active_override"),
            "execution_authorization",
        ),
    ]:
        if isinstance(df, dict) and df:
            if _text(df.get(column)).upper() != "NONE":
                auth_violations += 1

    technical(
        "Operations Execution Authorization Invariant",
        auth_violations == 0,
        (
            "NONE"
            if auth_violations == 0
            else f"non-NONE sources {auth_violations}"
        ),
        "Operations governance의 Execution Authorization을 NONE으로 유지",
    )

    technical_fail = sum(
        1
        for row in checks
        if row["layer"] == "TECHNICAL"
        and row["status"] == "FAIL"
    )

    release_gate = (
        "PASS"
        if technical_fail == 0
        else "BLOCKED"
    )

    operating_status = _text(
        live_sla.get("operating_status")
    ).upper() or "REVIEW"

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Carry-forward / SLA Operating State",
            "status": operating_status,
            "detail": (
                f"{_text(live_sla.get('sla_state')) or 'MISSING'} · "
                f"SLA breach {_int(recurrence.get('sla_breach_groups'))} · "
                f"persistent {_int(recurrence.get('persistent_groups'))} · "
                f"chronic {_int(recurrence.get('chronic_groups'))} · "
                f"deferred {deferred}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else "원본 Review 사유와 Carry-forward 우선순위를 계속 검토"
            ),
        }
    )

    return {
        "release_gate": release_gate,
        "technical_pass": sum(
            1
            for row in checks
            if row["layer"] == "TECHNICAL"
            and row["status"] == "PASS"
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "sla_state": _text(live_sla.get("sla_state")),
        "effective_capacity": effective_cap,
        "latest_snapshot_integrity":
            _text(ctx.get("latest_snapshot_integrity")),
        "checks": pd.DataFrame(
            checks,
            columns=V127_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v127_release_readiness(
    *,
    v126_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    sla_release_gate: str,
    sla_operating_status: str,
    execution_authorization: str,
) -> dict:
    v126 = _text(
        v126_release_status
    ).upper()
    integration = _text(
        integration_consistency
    ).upper()
    sla_gate = _text(
        sla_release_gate
    ).upper()
    sla_operating = _text(
        sla_operating_status
    ).upper()
    exec_auth = _text(
        execution_authorization
    ).upper()
    csv_fail = _int(
        csv_fail_count
    )

    checks = [
        _candidate_row(
            "v1.26 Daily Operations Baseline",
            v126 == "READY_FOR_RELEASE_REVIEW",
            v126 or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Carry-forward / SLA Technical Release Gate",
            sla_gate == "PASS",
            sla_gate or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            exec_auth == "NONE",
            exec_auth or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []
    if sla_operating and sla_operating != "PASS":
        operating_reviews.append(
            "CARRY_FORWARD_SLA_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V127_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v127_integration_crosscheck(
    *,
    integration_consistency: str,
    sla_release_gate: str,
    snapshot_integrity: str,
) -> dict:
    integration = _text(
        integration_consistency
    ).upper()
    sla_gate = _text(
        sla_release_gate
    ).upper()
    snapshot = _text(
        snapshot_integrity
    ).upper()

    snapshot_ok = snapshot in {
        "OK",
        "NONE",
    }

    checks = [
        _candidate_row(
            "System Integration Consistency",
            integration == "PASS",
            integration or "MISSING",
        ),
        _candidate_row(
            "Carry-forward / SLA Technical Release Gate",
            sla_gate == "PASS",
            sla_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Operating SLA Closure Snapshot Integrity",
            snapshot_ok,
            snapshot or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V127_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v127_data_crosscheck(
    *,
    csv_fail_count: int,
    sla_release_gate: str,
    snapshot_integrity: str,
) -> dict:
    csv_fail = _int(
        csv_fail_count
    )
    sla_gate = _text(
        sla_release_gate
    ).upper()
    snapshot = _text(
        snapshot_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            csv_fail == 0,
            f"CSV FAIL {csv_fail}",
        ),
        _candidate_row(
            "Carry-forward / SLA Release Data Gate",
            sla_gate == "PASS",
            sla_gate or "MISSING",
        ),
        _candidate_row(
            "Latest Operating SLA Closure Snapshot Integrity",
            snapshot in {"OK", "NONE"},
            snapshot or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": (
            "PASS"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V127_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
