from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_controlled_trial_runtime import (
    FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    controlled_trial_runtime_snapshot_integrity,
)
from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    recalibration_proposal_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)


FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS = [
    "controlled_trial_outcome_id",
    "created_at",
    "outcome_state",
    "outcome_guard",
    "source_trial_start_id",
    "source_trial_start_hash",
    "source_runtime_event_id",
    "source_runtime_event_hash",
    "source_runtime_state",
    "source_proposal_id",
    "source_proposal_hash",
    "source_proposal_integrity",
    "proposal_scope",
    "target_metric",
    "baseline_value",
    "shadow_value",
    "permit_scope_pct",
    "permit_session_budget",
    "required_trial_outcomes",
    "max_relative_error_degradation_pct",
    "completed_sessions",
    "eligible_trial_outcomes",
    "outside_session_outcomes",
    "preopen_projection_outcomes",
    "assumption_drift_outcomes",
    "baseline_drift_outcomes",
    "invalid_outcomes",
    "duplicate_outcomes",
    "baseline_mean_abs_error",
    "shadow_mean_abs_error",
    "relative_error_improvement_pct",
    "kill_switch_trigger",
    "rollback_required",
    "evidence_outcome_ids_json",
    "evidence_outcome_hashes_json",
    "trial_outcome_authorization",
    "trial_runtime_authorization",
    "trial_start_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


CONTROLLED_TRIAL_OUTCOME_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


CONTROLLED_TRIAL_OUTCOME_STATES = {
    "TRIAL_OUTCOME_UPSTREAM_WAIT",
    "TRIAL_OUTCOME_NOT_REQUIRED",
    "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT",
    "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
    "TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED",
    "TRIAL_OUTCOME_EVIDENCE_MATURING",
    "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_PASS_NO_PROMOTION",
    "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
}


TRIAL_OUTCOME_GUARD_BY_STATE = {
    "TRIAL_OUTCOME_UPSTREAM_WAIT": "HOLD_TRIAL_RUNTIME",
    "TRIAL_OUTCOME_NOT_REQUIRED": "NO_TRIAL_OUTCOME_REVIEW",
    "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT": "HOLD_ACTIVE_RUNTIME",
    "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW": "HOLD_TRIAL_OUTCOME_INTEGRITY",
    "TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED": "HOLD_MODEL_TRIAL_EVALUATOR",
    "TRIAL_OUTCOME_EVIDENCE_MATURING": "WAIT_TRIAL_EVIDENCE",
    "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED": "ROLLBACK_REQUIRED_KILL_SWITCH",
    "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED": "ROLLBACK_REQUIRED_ASSUMPTION_DRIFT",
    "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED": "ROLLBACK_REQUIRED_BASELINE_DRIFT",
    "TRIAL_OUTCOME_PASS_NO_PROMOTION": "TRIAL_PASS_NO_PROMOTION",
    "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED": "TRIAL_FAIL_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION": "TRIAL_INCONCLUSIVE_NO_PROMOTION",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _outcome_payload(row: dict) -> dict:
    int_fields = {
        "permit_session_budget",
        "required_trial_outcomes",
        "completed_sessions",
        "eligible_trial_outcomes",
        "outside_session_outcomes",
        "preopen_projection_outcomes",
        "assumption_drift_outcomes",
        "baseline_drift_outcomes",
        "invalid_outcomes",
        "duplicate_outcomes",
    }

    float_fields = {
        "baseline_value",
        "shadow_value",
        "permit_scope_pct",
        "max_relative_error_degradation_pct",
        "baseline_mean_abs_error",
        "shadow_mean_abs_error",
        "relative_error_improvement_pct",
    }

    bool_fields = {
        "rollback_required",
    }

    payload = {}

    for col in FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS:
        if col in {
            "controlled_trial_outcome_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def controlled_trial_outcome_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get(
            "snapshot_hash"
        )
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _outcome_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_controlled_trial_outcome_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _proposal_source(
    runtime: dict,
    proposal_snapshots: pd.DataFrame | None,
) -> dict:
    proposal_id = _text(
        runtime.get(
            "source_proposal_id"
        )
    )
    proposal_hash = _text(
        runtime.get(
            "source_proposal_hash"
        )
    )

    if not proposal_id or not proposal_hash:
        return {}

    df = (
        pd.DataFrame()
        if proposal_snapshots is None
        else proposal_snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    matches = df.loc[
        df["recalibration_proposal_id"]
        .fillna("")
        .astype(str)
        .eq(proposal_id)
    ]

    if len(matches) != 1:
        return {}

    row = matches.iloc[0].to_dict()

    if _text(
        recalibration_proposal_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        row.get("snapshot_hash")
    ) != proposal_hash:
        return {}

    if _text(
        row.get("proposal_state")
    ).upper() != "RECALIBRATION_PROPOSAL_LOCKED":
        return {}

    return row


def _closed_session_windows(
    runtime: dict,
    runtime_snapshots: pd.DataFrame | None,
) -> dict:
    source_start_id = _text(
        runtime.get(
            "source_trial_start_id"
        )
    )
    source_start_hash = _text(
        runtime.get(
            "source_trial_start_hash"
        )
    )

    df = (
        pd.DataFrame()
        if runtime_snapshots is None
        else runtime_snapshots.copy()
    )

    for col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    if df.empty:
        return {
            "windows": [],
            "invalid_count": 0,
            "unpaired_count": 0,
        }

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    current = df.loc[
        df["source_trial_start_id"]
        .fillna("")
        .astype(str)
        .eq(source_start_id)
        & df["source_trial_start_hash"]
        .fillna("")
        .astype(str)
        .eq(source_start_hash)
    ].copy()

    current = current.loc[
        current["_ts"].notna()
    ].sort_values("_ts")

    invalid_count = 0
    active = {}
    windows = []
    unpaired_count = 0

    for _, row in current.iterrows():
        item = row.to_dict()

        if _text(
            controlled_trial_runtime_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            invalid_count += 1
            continue

        event_type = _text(
            item.get(
                "event_type"
            )
        ).upper()
        session_id = _text(
            item.get(
                "runtime_session_id"
            )
        )
        ts = item["_ts"]

        if event_type == "OPEN":
            if not session_id or session_id in active:
                invalid_count += 1
                continue
            active[session_id] = {
                "open_at": ts,
                "open_event_id": _text(
                    item.get(
                        "controlled_trial_runtime_event_id"
                    )
                ),
                "open_hash": _text(
                    item.get(
                        "snapshot_hash"
                    )
                ),
            }

        elif event_type == "CLOSE":
            opened = active.pop(
                session_id,
                None,
            )
            if not opened:
                invalid_count += 1
                continue

            windows.append(
                {
                    "runtime_session_id":
                        session_id,
                    "open_at":
                        opened[
                            "open_at"
                        ],
                    "close_at":
                        ts,
                    "open_event_id":
                        opened[
                            "open_event_id"
                        ],
                    "close_event_id":
                        _text(
                            item.get(
                                "controlled_trial_runtime_event_id"
                            )
                        ),
                }
            )

        elif event_type == "KILL_SWITCH":
            active.pop(
                session_id,
                None,
            )

    unpaired_count = len(
        active
    )

    return {
        "windows": windows,
        "invalid_count": invalid_count,
        "unpaired_count": unpaired_count,
    }


def build_flow_controlled_trial_outcome(
    controlled_trial_runtime: dict | None,
    runtime_snapshots: pd.DataFrame | None,
    proposal_snapshots: pd.DataFrame | None,
    qualified_outcomes: pd.DataFrame | None,
) -> dict:
    runtime = controlled_trial_runtime or {}
    runtime_state = _text(
        runtime.get(
            "runtime_state"
        )
    ).upper()

    required_outcomes = max(
        3,
        _int(
            runtime.get(
                "permit_min_trial_outcomes"
            )
        ),
    )
    max_degradation = max(
        0.0,
        _float(
            runtime.get(
                "permit_max_relative_error_degradation_pct"
            )
        ),
    )

    latest_runtime = runtime.get(
        "latest_event"
    ) or {}

    base = {
        "source_trial_start_id": _text(
            runtime.get(
                "source_trial_start_id"
            )
        ),
        "source_trial_start_hash": _text(
            runtime.get(
                "source_trial_start_hash"
            )
        ),
        "source_runtime_event_id": _text(
            latest_runtime.get(
                "controlled_trial_runtime_event_id"
            )
        ),
        "source_runtime_event_hash": _text(
            latest_runtime.get(
                "snapshot_hash"
            )
        ),
        "source_runtime_state": runtime_state,
        "source_proposal_id": _text(
            runtime.get(
                "source_proposal_id"
            )
        ),
        "source_proposal_hash": _text(
            runtime.get(
                "source_proposal_hash"
            )
        ),
        "source_proposal_integrity": "NONE",
        "proposal_scope": _text(
            runtime.get(
                "proposal_scope"
            )
        ).upper(),
        "target_metric": _text(
            runtime.get(
                "target_metric"
            )
        ).upper(),
        "baseline_value": 0.0,
        "shadow_value": 0.0,
        "permit_scope_pct": _float(
            runtime.get(
                "permit_scope_pct"
            )
        ),
        "permit_session_budget": _int(
            runtime.get(
                "permit_session_budget"
            )
        ),
        "required_trial_outcomes": required_outcomes,
        "max_relative_error_degradation_pct": max_degradation,
        "completed_sessions": 0,
        "eligible_trial_outcomes": 0,
        "outside_session_outcomes": 0,
        "preopen_projection_outcomes": 0,
        "assumption_drift_outcomes": 0,
        "baseline_drift_outcomes": 0,
        "invalid_outcomes": 0,
        "duplicate_outcomes": 0,
        "baseline_mean_abs_error": 0.0,
        "shadow_mean_abs_error": 0.0,
        "relative_error_improvement_pct": 0.0,
        "kill_switch_trigger": _text(
            runtime.get(
                "kill_switch_trigger"
            )
        ).upper(),
        "rollback_required": False,
        "evidence_outcome_ids_json": "[]",
        "evidence_outcome_hashes_json": "[]",
        "evidence_table": pd.DataFrame(),
        "trial_outcome_authorization": "NONE",
        "trial_runtime_authorization": "NONE",
        "trial_start_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if runtime_state in {
        "",
        "TRIAL_RUNTIME_UPSTREAM_WAIT",
        "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
    }:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_UPSTREAM_WAIT",
            "outcome_guard": "HOLD_TRIAL_RUNTIME",
        }

    if runtime_state in {
        "TRIAL_RUNTIME_NOT_REQUIRED",
        "TRIAL_RUNTIME_DEFERRED",
    }:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_NOT_REQUIRED",
            "outcome_guard": "NO_TRIAL_OUTCOME_REVIEW",
        }

    if runtime_state in {
        "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
    }:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard": "HOLD_TRIAL_OUTCOME_INTEGRITY",
        }

    windows_info = _closed_session_windows(
        runtime,
        runtime_snapshots,
    )

    base[
        "completed_sessions"
    ] = len(
        windows_info[
            "windows"
        ]
    )
    base[
        "invalid_outcomes"
    ] += _int(
        windows_info.get(
            "invalid_count"
        )
    )

    if (
        windows_info[
            "invalid_count"
        ] > 0
    ):
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard": "HOLD_TRIAL_OUTCOME_INTEGRITY",
        }

    if runtime_state == "TRIAL_RUNTIME_KILL_SWITCHED":
        return {
            **base,
            "rollback_required": True,
            "outcome_state": "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
            "outcome_guard": "ROLLBACK_REQUIRED_KILL_SWITCH",
        }

    if runtime_state == "TRIAL_RUNTIME_ACTIVE":
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT",
            "outcome_guard": "HOLD_ACTIVE_RUNTIME",
        }

    proposal = _proposal_source(
        runtime,
        proposal_snapshots,
    )

    if not proposal:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard": "HOLD_TRIAL_OUTCOME_INTEGRITY",
        }

    base[
        "source_proposal_integrity"
    ] = "OK"
    base[
        "proposal_scope"
    ] = _text(
        proposal.get(
            "proposal_scope"
        )
    ).upper()
    base[
        "target_metric"
    ] = _text(
        proposal.get(
            "target_metric"
        )
    ).upper()
    base[
        "baseline_value"
    ] = _float(
        proposal.get(
            "current_value"
        )
    )
    base[
        "shadow_value"
    ] = _float(
        proposal.get(
            "proposed_value"
        )
    )

    if base[
        "proposal_scope"
    ] == "MODEL_SHADOW":
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED",
            "outcome_guard": "HOLD_MODEL_TRIAL_EVALUATOR",
        }

    if (
        base[
            "proposal_scope"
        ]
        != "PARAMETER_SHADOW"
        or base[
            "target_metric"
        ]
        != "BASE_BURN_RATE"
        or base[
            "baseline_value"
        ]
        <= 0
        or base[
            "shadow_value"
        ]
        <= 0
    ):
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard": "HOLD_TRIAL_OUTCOME_INTEGRITY",
        }

    windows = windows_info[
        "windows"
    ]

    outcome_df = (
        pd.DataFrame()
        if qualified_outcomes is None
        else qualified_outcomes.copy()
    )

    for col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS:
        if col not in outcome_df.columns:
            outcome_df[col] = ""

    valid_by_key = {}
    invalid_outcomes = 0
    duplicate_outcomes = 0

    for _, row in outcome_df.iterrows():
        item = row.to_dict()

        if _text(
            flow_projection_outcome_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            invalid_outcomes += 1
            continue

        key = (
            _text(
                item.get(
                    "source_projection_snapshot_id"
                )
            ),
            _text(
                item.get(
                    "evidence_end_trend_snapshot_id"
                )
            ),
        )

        created = pd.to_datetime(
            item.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )

        previous = valid_by_key.get(
            key
        )

        if previous is not None:
            duplicate_outcomes += 1
            previous_created = pd.to_datetime(
                previous.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )
            if (
                not pd.isna(
                    previous_created
                )
                and (
                    pd.isna(
                        created
                    )
                    or created <= previous_created
                )
            ):
                continue

        valid_by_key[
            key
        ] = item

    base[
        "invalid_outcomes"
    ] += invalid_outcomes
    base[
        "duplicate_outcomes"
    ] = duplicate_outcomes

    if invalid_outcomes > 0:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "outcome_guard": "HOLD_TRIAL_OUTCOME_INTEGRITY",
        }

    rows = []
    outside_session = 0
    preopen_projection = 0
    assumption_drift = 0
    baseline_drift = 0

    tolerance = max(
        1e-8,
        abs(
            base[
                "baseline_value"
            ]
        )
        * 1e-6,
    )

    for item in valid_by_key.values():
        evidence_end = pd.to_datetime(
            item.get(
                "evidence_end_at"
            ),
            errors="coerce",
            utc=True,
        )
        projection_created = pd.to_datetime(
            item.get(
                "source_projection_created_at"
            ),
            errors="coerce",
            utc=True,
        )

        matched_window = None

        if not pd.isna(
            evidence_end
        ):
            for window in windows:
                if (
                    evidence_end
                    > window[
                        "open_at"
                    ]
                    and evidence_end
                    <= window[
                        "close_at"
                    ]
                ):
                    matched_window = window
                    break

        if matched_window is None:
            outside_session += 1
            continue

        if (
            pd.isna(
                projection_created
            )
            or projection_created
            <= matched_window[
                "open_at"
            ]
            or projection_created
            > matched_window[
                "close_at"
            ]
        ):
            preopen_projection += 1
            continue

        capacity_drift = _int(
            item.get(
                "capacity_drift_count"
            )
        )
        evaluation_state = _text(
            item.get(
                "evaluation_state"
            )
        ).upper()
        recalibration_state = _text(
            item.get(
                "recalibration_state"
            )
        ).upper()

        if (
            capacity_drift > 0
            or evaluation_state
            == "ASSUMPTION_DRIFT_REVIEW"
            or recalibration_state
            == "REBASE_REQUIRED"
        ):
            assumption_drift += 1
            continue

        base_burn = _float(
            item.get(
                "base_burn_rate"
            )
        )

        if abs(
            base_burn
            - base[
                "baseline_value"
            ]
        ) > tolerance:
            baseline_drift += 1
            continue

        realized = _float(
            item.get(
                "realized_avg_net_burn"
            )
        )

        baseline_error = abs(
            realized
            - base[
                "baseline_value"
            ]
        )
        shadow_error = abs(
            realized
            - base[
                "shadow_value"
            ]
        )

        rows.append(
            {
                "runtime_session_id":
                    matched_window[
                        "runtime_session_id"
                    ],
                "outcome_snapshot_id":
                    _text(
                        item.get(
                            "outcome_snapshot_id"
                        )
                    ),
                "outcome_hash":
                    _text(
                        item.get(
                            "snapshot_hash"
                        )
                    ),
                "source_projection_snapshot_id":
                    _text(
                        item.get(
                            "source_projection_snapshot_id"
                        )
                    ),
                "evidence_end_at":
                    _text(
                        item.get(
                            "evidence_end_at"
                        )
                    ),
                "realized_avg_net_burn":
                    realized,
                "baseline_abs_error":
                    baseline_error,
                "shadow_abs_error":
                    shadow_error,
            }
        )

    evidence_table = pd.DataFrame(
        rows
    )

    base.update(
        {
            "eligible_trial_outcomes":
                int(
                    len(
                        evidence_table
                    )
                ),
            "outside_session_outcomes":
                outside_session,
            "preopen_projection_outcomes":
                preopen_projection,
            "assumption_drift_outcomes":
                assumption_drift,
            "baseline_drift_outcomes":
                baseline_drift,
            "evidence_table":
                evidence_table,
            "evidence_outcome_ids_json":
                json.dumps(
                    (
                        evidence_table[
                            "outcome_snapshot_id"
                        ]
                        .astype(str)
                        .tolist()
                        if not evidence_table.empty
                        else []
                    ),
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            "evidence_outcome_hashes_json":
                json.dumps(
                    (
                        evidence_table[
                            "outcome_hash"
                        ]
                        .astype(str)
                        .tolist()
                        if not evidence_table.empty
                        else []
                    ),
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
        }
    )

    if assumption_drift > 0:
        return {
            **base,
            "rollback_required": True,
            "outcome_state": "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
            "outcome_guard": "ROLLBACK_REQUIRED_ASSUMPTION_DRIFT",
        }

    if baseline_drift > 0:
        return {
            **base,
            "rollback_required": True,
            "outcome_state": "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED",
            "outcome_guard": "ROLLBACK_REQUIRED_BASELINE_DRIFT",
        }

    if runtime_state == "TRIAL_RUNTIME_READY":
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_EVIDENCE_MATURING",
            "outcome_guard": "WAIT_TRIAL_EVIDENCE",
        }

    if runtime_state != "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED":
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_EVIDENCE_MATURING",
            "outcome_guard": "WAIT_TRIAL_EVIDENCE",
        }

    if base[
        "eligible_trial_outcomes"
    ] < base[
        "required_trial_outcomes"
    ]:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
            "outcome_guard": "TRIAL_INCONCLUSIVE_NO_PROMOTION",
        }

    baseline_mean = float(
        evidence_table[
            "baseline_abs_error"
        ].mean()
    )
    shadow_mean = float(
        evidence_table[
            "shadow_abs_error"
        ].mean()
    )

    base[
        "baseline_mean_abs_error"
    ] = baseline_mean
    base[
        "shadow_mean_abs_error"
    ] = shadow_mean

    if baseline_mean <= 1e-12:
        improvement = (
            0.0
            if shadow_mean <= 1e-12
            else -1.0
        )
    else:
        improvement = (
            baseline_mean
            - shadow_mean
        ) / baseline_mean

    base[
        "relative_error_improvement_pct"
    ] = improvement

    if improvement <= -base[
        "max_relative_error_degradation_pct"
    ]:
        return {
            **base,
            "rollback_required": True,
            "outcome_state": "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED",
            "outcome_guard": "TRIAL_FAIL_ROLLBACK_REQUIRED",
        }

    if improvement > 0.0:
        return {
            **base,
            "outcome_state": "TRIAL_OUTCOME_PASS_NO_PROMOTION",
            "outcome_guard": "TRIAL_PASS_NO_PROMOTION",
        }

    return {
        **base,
        "outcome_state": "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
        "outcome_guard": "TRIAL_INCONCLUSIVE_NO_PROMOTION",
    }


def build_flow_controlled_trial_outcome_snapshot(
    outcome: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = outcome or {}

    state = _text(
        current.get(
            "outcome_state"
        )
    ).upper()

    if state not in CONTROLLED_TRIAL_OUTCOME_STATES:
        raise ValueError(
            "Controlled Trial Outcome state가 유효하지 않습니다."
        )

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        col: current.get(
            col,
            "",
        )
        for col in FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS
        if col not in {
            "controlled_trial_outcome_id",
            "created_at",
            "note",
            "snapshot_hash",
        }
    }

    base[
        "trial_outcome_authorization"
    ] = "NONE"
    base[
        "trial_runtime_authorization"
    ] = "NONE"
    base[
        "trial_start_authorization"
    ] = "NONE"
    base[
        "recalibration_authorization"
    ] = "NONE"
    base[
        "capacity_authorization"
    ] = "NONE"
    base[
        "execution_authorization"
    ] = "NONE"

    snapshot_hash = _hash(
        _outcome_payload(
            base
        )
    )

    return {
        "controlled_trial_outcome_id": (
            "OTO-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_controlled_trial_outcome_queue(
    outcome: dict | None,
) -> pd.DataFrame:
    row = outcome or {}
    state = _text(
        row.get(
            "outcome_state"
        )
    ).upper()

    mapping = {
        "TRIAL_OUTCOME_UPSTREAM_WAIT": (
            "TO2",
            "WAIT",
            "TRIAL_OUTCOME_UPSTREAM_WAIT",
            "완료된 Shadow Runtime source가 아직 없음",
            "Trial Start / Runtime evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "TRIAL_OUTCOME_NOT_REQUIRED": (
            "TO3",
            "MONITOR",
            "TRIAL_OUTCOME_NOT_REQUIRED",
            "현재 Runtime source에서는 Trial Outcome Review가 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT": (
            "TO1",
            "ACTIVE",
            "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT",
            "Shadow Runtime Session이 아직 ACTIVE",
            "CLOSE 또는 KILL_SWITCH 결정 전 Outcome 결론 금지",
        ),
        "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW": (
            "TO0",
            "BLOCKED",
            "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "Runtime / Proposal / Outcome source integrity mismatch",
            "immutable source audit과 lineage를 먼저 복구",
        ),
        "TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED": (
            "TO1",
            "REVIEW",
            "TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED",
            "MODEL_SHADOW executable trial evaluator가 아직 없음",
            "모델 counterfactual evaluator 정의 전 Trial 성능 결론 금지",
        ),
        "TRIAL_OUTCOME_EVIDENCE_MATURING": (
            "TO2",
            "WAIT",
            "TRIAL_OUTCOME_EVIDENCE_MATURING",
            (
                f"eligible {row.get('eligible_trial_outcomes',0)}/"
                f"{row.get('required_trial_outcomes',0)} · "
                f"sessions {row.get('completed_sessions',0)}/"
                f"{row.get('permit_session_budget',0)}"
            ),
            "사전 허용된 session budget 내에서 prospective trial evidence 축적",
        ),
        "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED": (
            "TO0",
            "BLOCKED",
            "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
            f"kill trigger {row.get('kill_switch_trigger','')} · rollback required",
            "새 trial 금지; rollback closure와 post-mortem review 우선",
        ),
        "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED": (
            "TO0",
            "BLOCKED",
            "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
            f"assumption drift outcomes {row.get('assumption_drift_outcomes',0)}",
            "Trial comparison 중단; rollback closure와 새 baseline 검토",
        ),
        "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED": (
            "TO0",
            "BLOCKED",
            "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED",
            f"baseline drift outcomes {row.get('baseline_drift_outcomes',0)}",
            "기존 Trial comparison 재사용 금지; rollback closure 후 새 cycle",
        ),
        "TRIAL_OUTCOME_PASS_NO_PROMOTION": (
            "TO3",
            "REVIEW",
            "TRIAL_OUTCOME_PASS_NO_PROMOTION",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "PASS는 live promotion이 아님; 별도 Trial Outcome Human Review 필요",
        ),
        "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED": (
            "TO0",
            "BLOCKED",
            "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED",
            (
                f"relative error improvement "
                f"{float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "Rollback closure와 proposal rejection/post-mortem 우선",
        ),
        "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION": (
            "TO2",
            "REVIEW",
            "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
            (
                f"eligible {row.get('eligible_trial_outcomes',0)}/"
                f"{row.get('required_trial_outcomes',0)} · "
                f"improvement {float(row.get('relative_error_improvement_pct',0)):.1%}"
            ),
            "기준을 사후 변경하지 말고 새 Trial cycle 또는 추가 evidence 검토",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "TO0",
            "BLOCKED",
            "TRIAL_OUTCOME_UNKNOWN_STATE",
            state or "MISSING",
            "Controlled Trial Outcome state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            CONTROLLED_TRIAL_OUTCOME_QUEUE_COLS,
    )
