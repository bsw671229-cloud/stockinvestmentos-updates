from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_controlled_trial_start import (
    FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
    controlled_trial_start_snapshot_integrity,
)
from engine.operations_flow_controlled_trial_runtime import (
    FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    CONTROLLED_TRIAL_RUNTIME_STATES,
    TRIAL_RUNTIME_GUARD_BY_STATE,
    TRIAL_RUNTIME_EVENT_TYPES,
    KILL_SWITCH_TRIGGERS,
    build_flow_controlled_trial_runtime,
    controlled_trial_runtime_snapshot_integrity,
    latest_controlled_trial_runtime_snapshot,
)


TRIAL_RUNTIME_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

TRIAL_RUNTIME_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V143_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v143_trial_runtime_context(
    *,
    v142_context: dict | None,
    controlled_trial_runtime_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v142_context or {}
    start = upstream.get("start") or {}

    runtime_df = _ensure_cols(
        controlled_trial_runtime_snapshots,
        FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    )

    runtime = build_flow_controlled_trial_runtime(
        start,
        runtime_df,
    )

    latest_runtime = latest_controlled_trial_runtime_snapshot(
        runtime_df
    )

    latest_integrity = (
        _text(
            controlled_trial_runtime_snapshot_integrity(
                latest_runtime
            ).get("status")
        ).upper()
        if latest_runtime
        else "NONE"
    )

    return {
        "v142_context": upstream,
        "start": start,
        "controlled_trial_start_snapshots": _ensure_cols(
            upstream.get("controlled_trial_start_snapshots"),
            FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
        ),
        "controlled_trial_runtime_snapshots": runtime_df,
        "runtime": runtime,
        "runtime_integrity": _integrity_counts(
            runtime_df,
            controlled_trial_runtime_snapshot_integrity,
        ),
        "latest_runtime": latest_runtime,
        "latest_runtime_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _start_routing_ok(
    runtime: dict,
    start: dict,
) -> bool:
    runtime_state = _text(
        runtime.get("runtime_state")
    ).upper()
    start_state = _text(
        start.get("start_state")
    ).upper()

    if start_state == "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY":
        return runtime_state in {
            "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
            "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
            "TRIAL_RUNTIME_READY",
            "TRIAL_RUNTIME_ACTIVE",
            "TRIAL_RUNTIME_KILL_SWITCHED",
            "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
            "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
        }

    if start_state in {
        "TRIAL_START_NOT_REQUIRED",
        "TRIAL_START_REJECTED",
    }:
        return runtime_state == "TRIAL_RUNTIME_NOT_REQUIRED"

    if start_state == "TRIAL_START_DEFERRED":
        return runtime_state == "TRIAL_RUNTIME_DEFERRED"

    return runtime_state == "TRIAL_RUNTIME_UPSTREAM_WAIT"


def _start_source_mapping_ok(
    context: dict,
) -> bool:
    runtime = context.get("runtime") or {}
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if state in {
        "TRIAL_RUNTIME_UPSTREAM_WAIT",
        "TRIAL_RUNTIME_NOT_REQUIRED",
        "TRIAL_RUNTIME_DEFERRED",
    }:
        return True

    source_id = _text(
        runtime.get("source_trial_start_id")
    )
    source_hash = _text(
        runtime.get("source_trial_start_hash")
    )

    if not source_id or not source_hash:
        return state == "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED"

    index, duplicates = _index_by_id(
        context.get("controlled_trial_start_snapshots"),
        "controlled_trial_start_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(source_id)

    if not parent:
        return False

    return (
        _text(
            controlled_trial_start_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(parent.get("snapshot_hash")) == source_hash
        and _text(parent.get("start_state")).upper()
        == "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY"
        and _text(parent.get("shadow_trial_permission")).upper()
        == "SHADOW_CANARY_ONLY"
    )


def _session_budget_state_ok(
    runtime: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    budget = _int(
        runtime.get("permit_session_budget")
    )
    used = _int(
        runtime.get("sessions_used")
    )
    remaining = _int(
        runtime.get("sessions_remaining")
    )

    if state in {
        "TRIAL_RUNTIME_UPSTREAM_WAIT",
        "TRIAL_RUNTIME_NOT_REQUIRED",
        "TRIAL_RUNTIME_DEFERRED",
        "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
        "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
    }:
        return True

    if budget <= 0:
        return False

    if used < 0 or used > budget:
        return False

    if remaining != max(0, budget - used):
        return False

    if state == "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED":
        return used >= budget and remaining == 0

    if state == "TRIAL_RUNTIME_ACTIVE":
        return (
            bool(_text(runtime.get("active_session_id")))
            and 1 <= _int(runtime.get("session_index")) <= budget
        )

    if state == "TRIAL_RUNTIME_READY":
        return used < budget and remaining > 0

    if state == "TRIAL_RUNTIME_KILL_SWITCHED":
        return bool(_text(runtime.get("active_session_id")))

    return True


def _kill_switch_contract_ok(
    runtime: dict,
) -> bool:
    state = _text(
        runtime.get("runtime_state")
    ).upper()

    if state != "TRIAL_RUNTIME_KILL_SWITCHED":
        return True

    latest = runtime.get("latest_event") or {}

    return (
        _text(latest.get("event_type")).upper()
        == "KILL_SWITCH"
        and _text(latest.get("kill_switch_trigger")).upper()
        in KILL_SWITCH_TRIGGERS
        and _bool(latest.get("kill_switch_latched"))
        and _bool(latest.get("rollback_required"))
        and _text(runtime.get("runtime_guard")).upper()
        == "KILL_SWITCH_LATCHED_ROLLBACK_REQUIRED"
    )


def _event_state_machine_ok(
    context: dict,
) -> bool:
    df = context.get(
        "controlled_trial_runtime_snapshots"
    )

    if not isinstance(df, pd.DataFrame) or df.empty:
        return True

    history = df.copy()

    for col in FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS:
        if col not in history.columns:
            history[col] = ""

    history["_ts"] = pd.to_datetime(
        history["created_at"],
        errors="coerce",
        utc=True,
    )

    if history["_ts"].isna().any():
        return False

    history = history.sort_values("_ts")

    active_sessions = set()
    closed_sessions = set()
    killed = False
    last_ts = None

    for _, row in history.iterrows():
        item = row.to_dict()

        if _text(
            controlled_trial_runtime_snapshot_integrity(
                item
            ).get("status")
        ).upper() != "OK":
            return False

        ts = item["_ts"]
        if last_ts is not None and ts <= last_ts:
            return False
        last_ts = ts

        event_type = _text(item.get("event_type")).upper()
        session_id = _text(item.get("runtime_session_id"))

        if event_type not in TRIAL_RUNTIME_EVENT_TYPES:
            return False

        if event_type == "OPEN":
            if killed or not session_id:
                return False
            if active_sessions:
                return False
            if session_id in closed_sessions:
                return False
            active_sessions.add(session_id)

        elif event_type == "CLOSE":
            if killed or session_id not in active_sessions:
                return False
            active_sessions.remove(session_id)
            closed_sessions.add(session_id)

        elif event_type == "KILL_SWITCH":
            if killed or session_id not in active_sessions:
                return False
            if not _bool(item.get("kill_switch_latched")):
                return False
            if not _bool(item.get("rollback_required")):
                return False
            if _text(item.get("kill_switch_trigger")).upper() not in KILL_SWITCH_TRIGGERS:
                return False
            active_sessions.remove(session_id)
            killed = True

    return True


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    runtime = context.get("runtime") or {}
    state = _text(
        runtime.get("runtime_state")
    ).upper()
    latest = context.get("latest_runtime") or {}

    if state in {
        "TRIAL_RUNTIME_ACTIVE",
        "TRIAL_RUNTIME_KILL_SWITCHED",
        "TRIAL_RUNTIME_READY",
        "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
    } and latest:
        source_ts = pd.to_datetime(
            runtime.get("source_trial_start_created_at"),
            errors="coerce",
            utc=True,
        )
        runtime_ts = pd.to_datetime(
            latest.get("created_at"),
            errors="coerce",
            utc=True,
        )

        if pd.isna(source_ts) or pd.isna(runtime_ts):
            return False

        if runtime_ts <= source_ts:
            return False

    if state == "TRIAL_RUNTIME_SOURCE_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(latest.get("source_trial_start_id"))
            != _text(runtime.get("source_trial_start_id"))
            or _text(latest.get("source_trial_start_hash"))
            != _text(runtime.get("source_trial_start_hash"))
        )

    return True


def _no_execution_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("runtime") or {},
        context.get("latest_runtime") or {},
        context.get("start") or {},
    ]:
        for field in [
            "trial_runtime_authorization",
            "trial_start_authorization",
            "trial_design_authorization",
            "adoption_authorization",
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(item.get(field)).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "controlled_trial_runtime_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "trial_runtime_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v143_trial_runtime_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    runtime = ctx.get("runtime") or {}
    start = ctx.get("start") or {}
    counts = ctx.get("runtime_integrity") or {}

    state = _text(
        runtime.get("runtime_state")
    ).upper()
    guard = _text(
        runtime.get("runtime_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Controlled Trial Runtime Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Runtime immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Runtime State / Guard Vocabulary",
            (
                state in CONTROLLED_TRIAL_RUNTIME_STATES
                and guard
                == TRIAL_RUNTIME_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {TRIAL_RUNTIME_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Runtime state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Start → Runtime State Invariant",
            _start_routing_ok(
                runtime,
                start,
            ),
            (
                f"start {_text(start.get('start_state')) or 'MISSING'} · "
                f"runtime {state or 'MISSING'}"
            ),
            "Start Permit/Reject/Defer와 Runtime state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Runtime → Shadow Trial Permit Source Mapping",
            _start_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"permit {_text(runtime.get('source_trial_start_id')) or 'NONE'} · "
                f"integrity {_text(runtime.get('source_trial_start_integrity')) or 'NONE'}"
            ),
            "Runtime source Start Permit id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Runtime Session Budget / Active Session Invariant",
            _session_budget_state_ok(
                runtime
            ),
            (
                f"state {state or 'MISSING'} · "
                f"sessions {_int(runtime.get('sessions_used'))}/"
                f"{_int(runtime.get('permit_session_budget'))} · "
                f"remaining {_int(runtime.get('sessions_remaining'))}"
            ),
            "Session budget, remaining count, active session 상태 확인",
        )
    )

    checks.append(
        _technical_row(
            "Runtime Event State Machine / Kill-Switch Latch Invariant",
            (
                _event_state_machine_ok(
                    ctx
                )
                and _kill_switch_contract_ok(
                    runtime
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"kill {_bool(runtime.get('kill_switch_latched'))} · "
                f"trigger {_text(runtime.get('kill_switch_trigger')) or 'NONE'}"
            ),
            "OPEN/CLOSE/KILL_SWITCH 순서와 latch/rollback contract 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Runtime Time-order / Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"permit created {_text(runtime.get('source_trial_start_created_at')) or 'NONE'} · "
                f"latest runtime {_text((ctx.get('latest_runtime') or {}).get('controlled_trial_runtime_event_id')) or 'NONE'}"
            ),
            "Runtime 저장 순서와 새 Start Permit supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Runtime No-Live-Execution Authorization Invariant",
            _no_execution_authorization_ok(
                ctx
            ),
            "NONE",
            "Runtime/Start/Recalibration/Capacity/Projection/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state in {
            "TRIAL_RUNTIME_NOT_REQUIRED",
            "TRIAL_RUNTIME_DEFERRED",
            "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Runtime Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"permission {_text(runtime.get('shadow_trial_permission')) or 'NONE'} · "
                f"sessions {_int(runtime.get('sessions_used'))}/"
                f"{_int(runtime.get('permit_session_budget'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 runtime wait/ready/active/kill-switch 상태는 Technical FAIL로 승격하지 않고 "
                    "Human Review와 rollback evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "runtime_state": state,
        "start_state": _text(
            start.get("start_state")
        ).upper(),
        "latest_trial_runtime_integrity":
            _text(
                ctx.get(
                    "latest_runtime_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_RUNTIME_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v143_trial_runtime_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    runtime_df = _ensure_cols(
        ctx.get(
            "controlled_trial_runtime_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    )

    start_df = _ensure_cols(
        ctx.get(
            "controlled_trial_start_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        runtime_df,
        controlled_trial_runtime_snapshot_integrity,
    )

    start_index, start_duplicates = _index_by_id(
        start_df,
        "controlled_trial_start_id",
    )

    event_contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_event_ids = set()
    seen_open_sessions = set()
    latest_event_by_session = {}

    ordered = runtime_df.copy()

    if not ordered.empty:
        ordered["_ts"] = pd.to_datetime(
            ordered["created_at"],
            errors="coerce",
            utc=True,
        )
        ordered = ordered.sort_values("_ts")

    for _, row in ordered.iterrows():
        item = row.to_dict()

        event_id = _text(
            item.get(
                "controlled_trial_runtime_event_id"
            )
        )

        if event_id:
            if event_id in seen_event_ids:
                identity_duplicates += 1
            seen_event_ids.add(event_id)

        event_type = _text(
            item.get("event_type")
        ).upper()
        state = _text(
            item.get("runtime_state")
        ).upper()
        session_id = _text(
            item.get("runtime_session_id")
        )

        expected_state = {
            "OPEN": "TRIAL_RUNTIME_ACTIVE",
            "KILL_SWITCH": "TRIAL_RUNTIME_KILL_SWITCHED",
        }.get(event_type)

        if event_type == "CLOSE":
            expected_state = state

        if (
            event_type not in TRIAL_RUNTIME_EVENT_TYPES
            or state not in CONTROLLED_TRIAL_RUNTIME_STATES
            or _text(
                item.get("runtime_guard")
            ).upper()
            != TRIAL_RUNTIME_GUARD_BY_STATE.get(
                state,
                "",
            )
        ):
            event_contract_violations += 1

        if event_type == "OPEN":
            if (
                not session_id
                or session_id in seen_open_sessions
                or state != "TRIAL_RUNTIME_ACTIVE"
            ):
                event_contract_violations += 1
            seen_open_sessions.add(session_id)

        elif event_type == "CLOSE":
            previous = latest_event_by_session.get(
                session_id
            )
            if (
                not session_id
                or not previous
                or _text(
                    previous.get("event_type")
                ).upper()
                != "OPEN"
                or state not in {
                    "TRIAL_RUNTIME_READY",
                    "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
                }
            ):
                event_contract_violations += 1

        elif event_type == "KILL_SWITCH":
            previous = latest_event_by_session.get(
                session_id
            )
            if (
                not session_id
                or not previous
                or _text(
                    previous.get("event_type")
                ).upper()
                != "OPEN"
                or state
                != "TRIAL_RUNTIME_KILL_SWITCHED"
                or _text(
                    item.get("kill_switch_trigger")
                ).upper()
                not in KILL_SWITCH_TRIGGERS
                or not _bool(
                    item.get("kill_switch_latched")
                )
                or not _bool(
                    item.get("rollback_required")
                )
            ):
                event_contract_violations += 1

        if session_id:
            latest_event_by_session[
                session_id
            ] = item

        source_id = _text(
            item.get(
                "source_trial_start_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_trial_start_hash"
            )
        )

        parent = start_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                controlled_trial_start_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get("snapshot_hash")
            )
            != source_hash
            or _text(
                parent.get("start_state")
            ).upper()
            != "TRIAL_START_PERMIT_ISSUED_SHADOW_ONLY"
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get("created_at"),
                errors="coerce",
                utc=True,
            )
            event_ts = pd.to_datetime(
                item.get("created_at"),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(event_ts)
                or event_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "trial_runtime_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Controlled Trial Runtime Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Runtime immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Runtime Audit Event / Kill-Switch Contract",
            event_contract_violations == 0,
            f"event contract violations {event_contract_violations}",
            "OPEN/CLOSE/KILL_SWITCH event contract와 latch/rollback 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Runtime Audit → Start Permit Lineage",
            (
                lineage_violations == 0
                and start_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"start duplicate ids {start_duplicates}"
            ),
            "Runtime source Start Permit id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Runtime Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate runtime ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Runtime audit identity uniqueness 및 Permit 이후 event 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Runtime Audit No-Live-Execution Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Runtime/Start/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("runtime") or {}).get(
            "runtime_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state in {
            "TRIAL_RUNTIME_NOT_REQUIRED",
            "TRIAL_RUNTIME_DEFERRED",
            "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Runtime Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current runtime {current_state or 'MISSING'} · "
                f"saved events {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 SHADOW_CANARY_ONLY permit 이후 Runtime OPEN/CLOSE/KILL evidence가 생길 때만 "
                    "Runtime audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_RUNTIME_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v143_release_readiness(
    *,
    v142_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    trial_runtime_release_gate: str,
    trial_runtime_audit_gate: str,
    trial_runtime_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.42 Controlled Trial Start Release Baseline",
            _text(
                v142_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v142_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Runtime Technical Release Gate",
            _text(
                trial_runtime_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_runtime_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Runtime Audit Integrity Gate",
            _text(
                trial_runtime_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_runtime_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            trial_runtime_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "CONTROLLED_TRIAL_RUNTIME_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V143_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v143_integration_crosscheck(
    *,
    integration_consistency: str,
    trial_runtime_release_gate: str,
    trial_runtime_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Runtime Technical Gate",
            _text(
                trial_runtime_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_runtime_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Runtime Audit Gate",
            _text(
                trial_runtime_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_runtime_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V143_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v143_data_crosscheck(
    *,
    csv_fail_count: int,
    trial_runtime_release_gate: str,
    trial_runtime_audit_gate: str,
    latest_trial_runtime_integrity: str,
) -> dict:
    latest = _text(
        latest_trial_runtime_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Runtime Technical Gate",
            _text(
                trial_runtime_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_runtime_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Runtime Audit Gate",
            _text(
                trial_runtime_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_runtime_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Controlled Trial Runtime Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V143_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
