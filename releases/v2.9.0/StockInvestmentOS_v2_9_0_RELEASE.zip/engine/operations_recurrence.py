from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd


RECURRENCE_TABLE_COLS = [
    "group_id",
    "priority",
    "category",
    "root_cause",
    "go_to",
    "status",
    "item_count",
    "subject_count",
    "age_days",
    "closed_sessions_seen",
    "recurrence_status",
    "sla_status",
    "sample_subjects",
    "sample_issues",
    "next_action",
]


ROOT_CAUSE_SUMMARY_COLS = [
    "root_cause",
    "group_count",
    "item_count",
    "subject_count",
    "sla_breach_groups",
    "persistent_groups",
    "chronic_groups",
    "max_closed_sessions_seen",
    "max_age_days",
    "sample_categories",
    "sample_routes",
]


REBALANCED_WORKLIST_COLS = [
    "slot",
    "selection_status",
    "selection_reason",
    "priority",
    "recurrence_status",
    "sla_status",
    "root_cause",
    "category",
    "item_count",
    "subject_count",
    "age_days",
    "closed_sessions_seen",
    "sample_subjects",
    "sample_issues",
    "go_to",
    "group_id",
]


RECURRENCE_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "group_id",
    "root_cause",
    "category",
    "age_days",
    "closed_sessions_seen",
    "next_action",
    "go_to",
]


RECURRENCE_SNAPSHOT_COLS = [
    "snapshot_id",
    "created_at",
    "recurring_groups",
    "persistent_groups",
    "chronic_groups",
    "sla_breach_groups",
    "selected_groups",
    "deferred_groups",
    "session_capacity",
    "top_root_cause",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _root_cause(
    category: str,
    go_to: str,
    status: str,
    issue: str,
) -> str:
    hay = " | ".join(
        [
            _text(category),
            _text(go_to),
            _text(status),
            _text(issue),
        ]
    ).upper()

    rules = [
        (
            "INTEGRITY / DATA",
            [
                "INTEGRITY",
                "HASH",
                "MISMATCH",
                "DATA QUALITY",
                "RECONCILIATION",
                "SAVE CENTER",
            ],
        ),
        (
            "PORTFOLIO / FACTOR RISK",
            [
                "FACTOR",
                "BREACH",
                "PORTFOLIO RISK",
                "CONCENTRATION",
                "RISK REPAIR",
            ],
        ),
        (
            "PRIMARY SOURCE / EVIDENCE",
            [
                "PRIMARY SOURCE",
                "EVIDENCE",
                "DART",
                "SOURCE",
            ],
        ),
        (
            "ASSUMPTION / VALUATION",
            [
                "ASSUMPTION",
                "CAPITAL PRODUCTIVITY",
                "VALUATION",
                "REVALIDATION",
            ],
        ),
        (
            "KPI / THESIS",
            [
                "KPI",
                "THESIS",
                "PROOF CLOCK",
                "MONITOR",
            ],
        ),
        (
            "EXECUTION / PROCESS",
            [
                "EXECUTION",
                "FILL",
                "POST-TRADE",
                "PROCESS",
            ],
        ),
    ]

    for cause, tokens in rules:
        if any(
            token in hay
            for token in tokens
        ):
            return cause

    return "OTHER / ROUTINE"


def _recurrence_status(
    closed_sessions_seen: int,
) -> str:
    count = max(
        0,
        _int(
            closed_sessions_seen
        ),
    )

    if count >= 5:
        return "CHRONIC"

    if count >= 3:
        return "PERSISTENT"

    if count >= 1:
        return "REPEATED"

    return "FIRST_SEEN"


def build_recurrence_diagnostics(
    carry_forward_table: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if carry_forward_table is None
        else carry_forward_table.copy()
    )

    if df.empty:
        return {
            "table":
                pd.DataFrame(
                    columns=
                    RECURRENCE_TABLE_COLS
                ),
            "root_cause_summary":
                pd.DataFrame(
                    columns=
                    ROOT_CAUSE_SUMMARY_COLS
                ),
            "recurring_groups":
                0,
            "persistent_groups":
                0,
            "chronic_groups":
                0,
            "sla_breach_groups":
                0,
            "top_root_cause":
                "",
            "execution_authorization":
                "NONE",
        }

    required = [
        "group_id",
        "priority",
        "category",
        "go_to",
        "status",
        "item_count",
        "subject_count",
        "age_days",
        "closed_sessions_seen",
        "sla_status",
        "sample_subjects",
        "sample_issues",
        "next_action",
    ]

    for col in required:
        if col not in df.columns:
            df[col] = ""

    rows = []

    for _, row in df.iterrows():
        cause = _root_cause(
            row.get(
                "category"
            ),
            row.get(
                "go_to"
            ),
            row.get(
                "status"
            ),
            row.get(
                "sample_issues"
            ),
        )

        recurrence = _recurrence_status(
            row.get(
                "closed_sessions_seen"
            )
        )

        rows.append(
            {
                "group_id":
                    _text(
                        row.get(
                            "group_id"
                        )
                    ),
                "priority":
                    _text(
                        row.get(
                            "priority"
                        )
                    ).upper(),
                "category":
                    _text(
                        row.get(
                            "category"
                        )
                    ),
                "root_cause":
                    cause,
                "go_to":
                    _text(
                        row.get(
                            "go_to"
                        )
                    ),
                "status":
                    _text(
                        row.get(
                            "status"
                        )
                    ),
                "item_count":
                    _int(
                        row.get(
                            "item_count"
                        )
                    ),
                "subject_count":
                    _int(
                        row.get(
                            "subject_count"
                        )
                    ),
                "age_days":
                    _int(
                        row.get(
                            "age_days"
                        )
                    ),
                "closed_sessions_seen":
                    _int(
                        row.get(
                            "closed_sessions_seen"
                        )
                    ),
                "recurrence_status":
                    recurrence,
                "sla_status":
                    _text(
                        row.get(
                            "sla_status"
                        )
                    ).upper(),
                "sample_subjects":
                    _text(
                        row.get(
                            "sample_subjects"
                        )
                    ),
                "sample_issues":
                    _text(
                        row.get(
                            "sample_issues"
                        )
                    ),
                "next_action":
                    _text(
                        row.get(
                            "next_action"
                        )
                    ),
            }
        )

    out = pd.DataFrame(
        rows,
        columns=
        RECURRENCE_TABLE_COLS,
    )

    rec_order = {
        "CHRONIC": 0,
        "PERSISTENT": 1,
        "REPEATED": 2,
        "FIRST_SEEN": 3,
    }
    priority_order = {
        "RQ0": 0,
        "RQ1": 1,
        "RQ2": 2,
        "RQ3": 3,
        "RQ4": 4,
    }

    out["_sla"] = out[
        "sla_status"
    ].eq(
        "BREACH"
    ).map(
        {
            True: 0,
            False: 1,
        }
    )
    out["_rec"] = out[
        "recurrence_status"
    ].map(
        rec_order
    ).fillna(
        9
    )
    out["_pri"] = out[
        "priority"
    ].map(
        priority_order
    ).fillna(
        9
    )

    out = (
        out.sort_values(
            [
                "_sla",
                "_rec",
                "_pri",
                "closed_sessions_seen",
                "age_days",
                "item_count",
            ],
            ascending=[
                True,
                True,
                True,
                False,
                False,
                False,
            ],
        )
        .drop(
            columns=[
                "_sla",
                "_rec",
                "_pri",
            ]
        )
        .reset_index(
            drop=True
        )
    )

    summary_rows = []

    for cause, part in out.groupby(
        "root_cause",
        sort=False,
    ):
        categories = []
        for item in part[
            "category"
        ].tolist():
            text = _text(
                item
            )
            if text and text not in categories:
                categories.append(
                    text
                )

        routes = []
        for item in part[
            "go_to"
        ].tolist():
            text = _text(
                item
            )
            if text and text not in routes:
                routes.append(
                    text
                )

        summary_rows.append(
            {
                "root_cause":
                    cause,
                "group_count":
                    int(
                        len(
                            part
                        )
                    ),
                "item_count":
                    int(
                        part[
                            "item_count"
                        ]
                        .astype(int)
                        .sum()
                    ),
                "subject_count":
                    int(
                        part[
                            "subject_count"
                        ]
                        .astype(int)
                        .sum()
                    ),
                "sla_breach_groups":
                    int(
                        part[
                            "sla_status"
                        ]
                        .eq(
                            "BREACH"
                        )
                        .sum()
                    ),
                "persistent_groups":
                    int(
                        part[
                            "recurrence_status"
                        ]
                        .isin(
                            [
                                "PERSISTENT",
                                "CHRONIC",
                            ]
                        )
                        .sum()
                    ),
                "chronic_groups":
                    int(
                        part[
                            "recurrence_status"
                        ]
                        .eq(
                            "CHRONIC"
                        )
                        .sum()
                    ),
                "max_closed_sessions_seen":
                    int(
                        part[
                            "closed_sessions_seen"
                        ]
                        .astype(int)
                        .max()
                    ),
                "max_age_days":
                    int(
                        part[
                            "age_days"
                        ]
                        .astype(int)
                        .max()
                    ),
                "sample_categories":
                    " | ".join(
                        categories[
                            :3
                        ]
                    ),
                "sample_routes":
                    " | ".join(
                        routes[
                            :3
                        ]
                    ),
            }
        )

    root_summary = pd.DataFrame(
        summary_rows,
        columns=
        ROOT_CAUSE_SUMMARY_COLS,
    )

    if not root_summary.empty:
        root_summary = root_summary.sort_values(
            [
                "sla_breach_groups",
                "persistent_groups",
                "group_count",
                "item_count",
            ],
            ascending=[
                False,
                False,
                False,
                False,
            ],
        ).reset_index(
            drop=True
        )

        top_root = _text(
            root_summary.iloc[
                0
            ][
                "root_cause"
            ]
        )
    else:
        top_root = ""

    return {
        "table":
            out,
        "root_cause_summary":
            root_summary,
        "recurring_groups":
            int(
                out[
                    "closed_sessions_seen"
                ]
                .astype(int)
                .gt(
                    0
                )
                .sum()
            ),
        "persistent_groups":
            int(
                out[
                    "recurrence_status"
                ]
                .isin(
                    [
                        "PERSISTENT",
                        "CHRONIC",
                    ]
                )
                .sum()
            ),
        "chronic_groups":
            int(
                out[
                    "recurrence_status"
                ]
                .eq(
                    "CHRONIC"
                )
                .sum()
            ),
        "sla_breach_groups":
            int(
                out[
                    "sla_status"
                ]
                .eq(
                    "BREACH"
                )
                .sum()
            ),
        "top_root_cause":
            top_root,
        "execution_authorization":
            "NONE",
    }


def _selection_reason(
    row: pd.Series,
) -> str:
    if _text(
        row.get(
            "sla_status"
        )
    ).upper() == "BREACH":
        return "SLA_BREACH"

    recurrence = _text(
        row.get(
            "recurrence_status"
        )
    ).upper()

    if recurrence == "CHRONIC":
        return "CHRONIC"

    if recurrence == "PERSISTENT":
        return "PERSISTENT"

    priority = _text(
        row.get(
            "priority"
        )
    ).upper()

    if priority == "RQ0":
        return "RQ0_IMMEDIATE"

    if priority == "RQ1":
        return "TODAY_NOW"

    return "PRIORITY_ORDER"


def build_capacity_rebalance_plan(
    diagnostics: dict | None,
    *,
    session_capacity: int = 5,
) -> dict:
    result = diagnostics or {}
    table = result.get(
        "table"
    )

    if (
        not isinstance(
            table,
            pd.DataFrame,
        )
        or table.empty
    ):
        return {
            "worklist":
                pd.DataFrame(
                    columns=
                    REBALANCED_WORKLIST_COLS
                ),
            "selected_groups":
                0,
            "deferred_groups":
                0,
            "session_capacity":
                max(
                    1,
                    _int(
                        session_capacity
                    ),
                ),
            "execution_authorization":
                "NONE",
        }

    capacity = max(
        1,
        _int(
            session_capacity
        ),
    )

    rows = []

    for rank, (_, row) in enumerate(
        table.iterrows(),
        start=1,
    ):
        selected = rank <= capacity

        rows.append(
            {
                "slot":
                    (
                        rank
                        if selected
                        else ""
                    ),
                "selection_status":
                    (
                        "SELECT_THIS_SESSION"
                        if selected
                        else "CARRY_FORWARD"
                    ),
                "selection_reason":
                    _selection_reason(
                        row
                    ),
                "priority":
                    _text(
                        row.get(
                            "priority"
                        )
                    ),
                "recurrence_status":
                    _text(
                        row.get(
                            "recurrence_status"
                        )
                    ),
                "sla_status":
                    _text(
                        row.get(
                            "sla_status"
                        )
                    ),
                "root_cause":
                    _text(
                        row.get(
                            "root_cause"
                        )
                    ),
                "category":
                    _text(
                        row.get(
                            "category"
                        )
                    ),
                "item_count":
                    _int(
                        row.get(
                            "item_count"
                        )
                    ),
                "subject_count":
                    _int(
                        row.get(
                            "subject_count"
                        )
                    ),
                "age_days":
                    _int(
                        row.get(
                            "age_days"
                        )
                    ),
                "closed_sessions_seen":
                    _int(
                        row.get(
                            "closed_sessions_seen"
                        )
                    ),
                "sample_subjects":
                    _text(
                        row.get(
                            "sample_subjects"
                        )
                    ),
                "sample_issues":
                    _text(
                        row.get(
                            "sample_issues"
                        )
                    ),
                "go_to":
                    _text(
                        row.get(
                            "go_to"
                        )
                    ),
                "group_id":
                    _text(
                        row.get(
                            "group_id"
                        )
                    ),
            }
        )

    worklist = pd.DataFrame(
        rows,
        columns=
        REBALANCED_WORKLIST_COLS,
    )

    selected_groups = int(
        worklist[
            "selection_status"
        ]
        .eq(
            "SELECT_THIS_SESSION"
        )
        .sum()
    )

    return {
        "worklist":
            worklist,
        "selected_groups":
            selected_groups,
        "deferred_groups":
            int(
                len(
                    worklist
                )
                - selected_groups
            ),
        "session_capacity":
            capacity,
        "execution_authorization":
            "NONE",
    }


def build_recurrence_queue(
    diagnostics: dict | None,
    rebalance: dict | None,
) -> pd.DataFrame:
    diag = diagnostics or {}
    reb = rebalance or {}
    table = diag.get(
        "table"
    )
    rows = []

    if (
        isinstance(
            table,
            pd.DataFrame,
        )
        and not table.empty
    ):
        for _, row in table.iterrows():
            sla = _text(
                row.get(
                    "sla_status"
                )
            ).upper()
            rec = _text(
                row.get(
                    "recurrence_status"
                )
            ).upper()

            if sla == "BREACH":
                priority = "CR0"
                issue = "CARRY_FORWARD_SLA_BREACH"
            elif rec == "CHRONIC":
                priority = "CR0"
                issue = "CARRY_FORWARD_CHRONIC"
            elif rec == "PERSISTENT":
                priority = "CR1"
                issue = "CARRY_FORWARD_PERSISTENT"
            else:
                continue

            rows.append(
                {
                    "priority":
                        priority,
                    "status":
                        "REVIEW",
                    "issue":
                        issue,
                    "group_id":
                        _text(
                            row.get(
                                "group_id"
                            )
                        ),
                    "root_cause":
                        _text(
                            row.get(
                                "root_cause"
                            )
                        ),
                    "category":
                        _text(
                            row.get(
                                "category"
                            )
                        ),
                    "age_days":
                        _int(
                            row.get(
                                "age_days"
                            )
                        ),
                    "closed_sessions_seen":
                        _int(
                            row.get(
                                "closed_sessions_seen"
                            )
                        ),
                    "next_action":
                        (
                            _text(
                                row.get(
                                    "next_action"
                                )
                            )
                            or "원본 Review 사유와 반복 원인을 재검토"
                        ),
                    "go_to":
                        _text(
                            row.get(
                                "go_to"
                            )
                        )
                        or "Review Queue",
                }
            )

    worklist = reb.get(
        "worklist"
    )

    if (
        isinstance(
            worklist,
            pd.DataFrame,
        )
        and not worklist.empty
    ):
        deferred = worklist.loc[
            worklist[
                "selection_status"
            ]
            .eq(
                "CARRY_FORWARD"
            )
            & worklist[
                "priority"
            ]
            .isin(
                [
                    "RQ0",
                    "RQ1",
                ]
            )
        ]

        for _, row in deferred.iterrows():
            rows.append(
                {
                    "priority":
                        "CR2",
                    "status":
                        "REVIEW",
                    "issue":
                        "HIGH_PRIORITY_DEFERRED_BY_CAPACITY",
                    "group_id":
                        _text(
                            row.get(
                                "group_id"
                            )
                        ),
                    "root_cause":
                        _text(
                            row.get(
                                "root_cause"
                            )
                        ),
                    "category":
                        _text(
                            row.get(
                                "category"
                            )
                        ),
                    "age_days":
                        _int(
                            row.get(
                                "age_days"
                            )
                        ),
                    "closed_sessions_seen":
                        _int(
                            row.get(
                                "closed_sessions_seen"
                            )
                        ),
                    "next_action":
                        "다음 Session 최상단으로 Carry-forward하고 원본 Review를 자동 완료하지 않음",
                    "go_to":
                        _text(
                            row.get(
                                "go_to"
                            )
                        )
                        or "Operations Control Tower",
                }
            )

    if not rows:
        return pd.DataFrame(
            columns=
            RECURRENCE_QUEUE_COLS
        )

    order = {
        "CR0": 0,
        "CR1": 1,
        "CR2": 2,
    }

    out = pd.DataFrame(
        rows
    )
    out["_p"] = out[
        "priority"
    ].map(
        order
    ).fillna(
        9
    )

    return (
        out.sort_values(
            [
                "_p",
                "closed_sessions_seen",
                "age_days",
                "category",
            ],
            ascending=[
                True,
                False,
                False,
                True,
            ],
        )
        .drop(
            columns=[
                "_p"
            ]
        )[
            RECURRENCE_QUEUE_COLS
        ]
        .reset_index(
            drop=True
        )
    )


def build_recurrence_snapshot(
    diagnostics: dict,
    rebalance: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    payload = {
        "recurring_groups":
            _int(
                diagnostics.get(
                    "recurring_groups"
                )
            ),
        "persistent_groups":
            _int(
                diagnostics.get(
                    "persistent_groups"
                )
            ),
        "chronic_groups":
            _int(
                diagnostics.get(
                    "chronic_groups"
                )
            ),
        "sla_breach_groups":
            _int(
                diagnostics.get(
                    "sla_breach_groups"
                )
            ),
        "selected_groups":
            _int(
                rebalance.get(
                    "selected_groups"
                )
            ),
        "deferred_groups":
            _int(
                rebalance.get(
                    "deferred_groups"
                )
            ),
        "session_capacity":
            _int(
                rebalance.get(
                    "session_capacity"
                )
            ),
        "top_root_cause":
            _text(
                diagnostics.get(
                    "top_root_cause"
                )
            ),
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        payload
    )

    return {
        "snapshot_id":
            (
                "ORR-"
                + pd.Timestamp(
                    now
                ).strftime(
                    "%Y%m%dT%H%M%S"
                )
                + "-"
                + snapshot_hash[:8]
            ),
        "created_at":
            now,
        **payload,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }
