from __future__ import annotations

from typing import Any
import pandas as pd

from engine.operations_flow_controlled_trial_outcome import (
    FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    controlled_trial_outcome_snapshot_integrity,
)
from engine.operations_flow_controlled_trial_closure import (
    FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    CONTROLLED_TRIAL_CLOSURE_STATES,
    TRIAL_CLOSURE_GUARD_BY_STATE,
    TRIAL_CLOSURE_DECISIONS,
    ROLLBACK_OUTCOME_STATES,
    TERMINAL_OUTCOME_STATES,
    build_flow_controlled_trial_closure,
    controlled_trial_closure_snapshot_integrity,
    latest_controlled_trial_closure_snapshot,
)


TRIAL_CLOSURE_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

TRIAL_CLOSURE_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V145_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(
                row.to_dict()
            ).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(
            item.get(id_col)
        )

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def build_v145_trial_closure_context(
    *,
    v144_context: dict | None,
    controlled_trial_closure_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v144_context or {}
    outcome = upstream.get("outcome") or {}

    outcome_df = _ensure_cols(
        upstream.get(
            "controlled_trial_outcome_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    )

    closure_df = _ensure_cols(
        controlled_trial_closure_snapshots,
        FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    )

    closure = build_flow_controlled_trial_closure(
        outcome,
        outcome_df,
        closure_df,
    )

    latest_closure = latest_controlled_trial_closure_snapshot(
        closure_df
    )

    latest_integrity = (
        _text(
            controlled_trial_closure_snapshot_integrity(
                latest_closure
            ).get("status")
        ).upper()
        if latest_closure
        else "NONE"
    )

    return {
        "v144_context": upstream,
        "outcome": outcome,
        "controlled_trial_outcome_snapshots": outcome_df,
        "controlled_trial_closure_snapshots": closure_df,
        "closure": closure,
        "closure_integrity": _integrity_counts(
            closure_df,
            controlled_trial_closure_snapshot_integrity,
        ),
        "latest_closure": latest_closure,
        "latest_closure_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _outcome_routing_ok(
    closure: dict,
    outcome: dict,
) -> bool:
    closure_state = _text(
        closure.get("closure_state")
    ).upper()
    outcome_state = _text(
        outcome.get("outcome_state")
    ).upper()

    if outcome_state == "TRIAL_OUTCOME_NOT_REQUIRED":
        return closure_state == "TRIAL_CLOSURE_NOT_REQUIRED"

    if outcome_state not in TERMINAL_OUTCOME_STATES:
        return closure_state == "TRIAL_CLOSURE_UPSTREAM_WAIT"

    common = {
        "TRIAL_CLOSURE_OUTCOME_AUDIT_REQUIRED",
        "TRIAL_CLOSURE_SOURCE_INTEGRITY_REVIEW",
        "TRIAL_CLOSURE_SOURCE_SUPERSEDED",
    }

    if outcome_state == "TRIAL_OUTCOME_PASS_NO_PROMOTION":
        return closure_state in (
            common
            | {
                "TRIAL_CLOSURE_REVIEW_REQUIRED",
                "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
                "TRIAL_CLOSURE_REJECTED",
                "TRIAL_CLOSURE_DEFERRED",
            }
        )

    if outcome_state == "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION":
        return closure_state in (
            common
            | {
                "TRIAL_CLOSURE_REVIEW_REQUIRED",
                "TRIAL_CLOSURE_REJECTED",
                "TRIAL_CLOSURE_DEFERRED",
            }
        )

    if outcome_state in ROLLBACK_OUTCOME_STATES:
        return closure_state in (
            common
            | {
                "TRIAL_CLOSURE_ROLLBACK_REQUIRED",
                "TRIAL_CLOSURE_ROLLBACK_CLOSED",
            }
        )

    return False


def _source_mapping_ok(
    context: dict,
) -> bool:
    closure = context.get("closure") or {}
    state = _text(
        closure.get("closure_state")
    ).upper()

    source_id = _text(
        closure.get(
            "source_trial_outcome_id"
        )
    )
    source_hash = _text(
        closure.get(
            "source_trial_outcome_hash"
        )
    )

    if state in {
        "TRIAL_CLOSURE_UPSTREAM_WAIT",
        "TRIAL_CLOSURE_NOT_REQUIRED",
        "TRIAL_CLOSURE_OUTCOME_AUDIT_REQUIRED",
    }:
        return (
            not source_id
            and not source_hash
        )

    if not source_id or not source_hash:
        return False

    index, duplicates = _index_by_id(
        context.get(
            "controlled_trial_outcome_snapshots"
        ),
        "controlled_trial_outcome_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(
        source_id
    )

    return (
        bool(parent)
        and _text(
            controlled_trial_outcome_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(
            parent.get("snapshot_hash")
        )
        == source_hash
        and _text(
            parent.get("outcome_state")
        ).upper()
        in TERMINAL_OUTCOME_STATES
    )


def _decision_contract_ok(
    closure: dict,
) -> bool:
    state = _text(
        closure.get("closure_state")
    ).upper()

    if state not in {
        "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
        "TRIAL_CLOSURE_REJECTED",
        "TRIAL_CLOSURE_DEFERRED",
        "TRIAL_CLOSURE_ROLLBACK_CLOSED",
    }:
        return True

    row = closure.get(
        "latest_closure"
    ) or {}

    if not row:
        return False

    if _text(
        controlled_trial_closure_snapshot_integrity(
            row
        ).get("status")
    ).upper() != "OK":
        return False

    decision = _text(
        row.get("decision")
    ).upper()

    expected_state = {
        "ACCEPT_FOR_LIVE_CHANGE_REVIEW":
            "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
        "REJECT":
            "TRIAL_CLOSURE_REJECTED",
        "DEFER":
            "TRIAL_CLOSURE_DEFERRED",
        "ROLLBACK_CLOSED":
            "TRIAL_CLOSURE_ROLLBACK_CLOSED",
    }.get(
        decision
    )

    if (
        decision not in TRIAL_CLOSURE_DECISIONS
        or state != expected_state
    ):
        return False

    if len(
        _text(
            row.get(
                "decision_detail"
            )
        )
    ) < 40:
        return False

    common = [
        "outcome_source_reviewed",
        "trial_evidence_reviewed",
        "reversal_risk_reviewed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            row.get(field)
        )
        for field in common
    ):
        return False

    outcome_state = _text(
        row.get(
            "outcome_state"
        )
    ).upper()

    if decision == "ACCEPT_FOR_LIVE_CHANGE_REVIEW":
        return (
            outcome_state
            == "TRIAL_OUTCOME_PASS_NO_PROMOTION"
            and _bool(
                row.get(
                    "live_change_review_only_confirmed"
                )
            )
            and _text(
                row.get(
                    "live_change_review_permission"
                )
            ).upper()
            == "DESIGN_REVIEW_ONLY"
            and not _bool(
                row.get(
                    "rollback_required"
                )
            )
        )

    if decision in {
        "REJECT",
        "DEFER",
    }:
        return (
            outcome_state
            in {
                "TRIAL_OUTCOME_PASS_NO_PROMOTION",
                "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
            }
            and _text(
                row.get(
                    "live_change_review_permission"
                )
            ).upper()
            in {"", "NONE"}
        )

    if decision == "ROLLBACK_CLOSED":
        rollback_flags = [
            "rollback_completed_confirmed",
            "prior_baseline_restored_confirmed",
            "rollback_integrity_verified",
            "postmortem_reviewed",
        ]

        return (
            outcome_state
            in ROLLBACK_OUTCOME_STATES
            and _bool(
                row.get(
                    "rollback_required"
                )
            )
            and all(
                _bool(
                    row.get(field)
                )
                for field in rollback_flags
            )
            and len(
                _text(
                    row.get(
                        "rollback_detail"
                    )
                )
            ) >= 40
            and _text(
                row.get(
                    "live_change_review_permission"
                )
            ).upper()
            in {"", "NONE"}
        )

    return False


def _permission_rollback_ok(
    closure: dict,
) -> bool:
    state = _text(
        closure.get("closure_state")
    ).upper()
    permission = _text(
        closure.get(
            "live_change_review_permission"
        )
    ).upper()
    rollback = _bool(
        closure.get(
            "rollback_required"
        )
    )

    if state == "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW":
        return (
            permission == "DESIGN_REVIEW_ONLY"
            and not rollback
        )

    if state in {
        "TRIAL_CLOSURE_REJECTED",
        "TRIAL_CLOSURE_DEFERRED",
    }:
        return permission in {"", "NONE"}

    if state in {
        "TRIAL_CLOSURE_ROLLBACK_REQUIRED",
        "TRIAL_CLOSURE_ROLLBACK_CLOSED",
    }:
        return (
            rollback
            and permission in {"", "NONE"}
        )

    return permission in {"", "NONE"}


def _time_order_supersession_ok(
    context: dict,
) -> bool:
    closure = context.get("closure") or {}
    state = _text(
        closure.get("closure_state")
    ).upper()
    latest = context.get(
        "latest_closure"
    ) or {}

    if state in {
        "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
        "TRIAL_CLOSURE_REJECTED",
        "TRIAL_CLOSURE_DEFERRED",
        "TRIAL_CLOSURE_ROLLBACK_CLOSED",
    }:
        source_ts = pd.to_datetime(
            closure.get(
                "source_trial_outcome_created_at"
            ),
            errors="coerce",
            utc=True,
        )
        closure_ts = pd.to_datetime(
            latest.get(
                "created_at"
            ),
            errors="coerce",
            utc=True,
        )

        return (
            not pd.isna(source_ts)
            and not pd.isna(closure_ts)
            and closure_ts > source_ts
        )

    if state == "TRIAL_CLOSURE_SOURCE_SUPERSEDED":
        if not latest:
            return False

        return (
            _text(
                latest.get(
                    "source_trial_outcome_id"
                )
            )
            != _text(
                closure.get(
                    "source_trial_outcome_id"
                )
            )
            or _text(
                latest.get(
                    "source_trial_outcome_hash"
                )
            )
            != _text(
                closure.get(
                    "source_trial_outcome_hash"
                )
            )
        )

    return True


def _no_live_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("closure") or {},
        context.get("latest_closure") or {},
        context.get("outcome") or {},
    ]:
        for field in [
            "trial_closure_authorization",
            "live_change_review_authorization",
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "trial_design_authorization",
            "adoption_authorization",
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(
                    item.get(field)
                ).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "controlled_trial_closure_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "trial_closure_authorization",
            "live_change_review_authorization",
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )

            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v145_trial_closure_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    closure = ctx.get("closure") or {}
    outcome = ctx.get("outcome") or {}
    counts = ctx.get("closure_integrity") or {}

    state = _text(
        closure.get("closure_state")
    ).upper()
    guard = _text(
        closure.get("closure_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Controlled Trial Closure Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Closure immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Closure State / Guard Vocabulary",
            (
                state in CONTROLLED_TRIAL_CLOSURE_STATES
                and guard
                == TRIAL_CLOSURE_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {TRIAL_CLOSURE_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Trial Closure state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Outcome → Trial Closure State Invariant",
            _outcome_routing_ok(
                closure,
                outcome,
            ),
            (
                f"outcome {_text(outcome.get('outcome_state')) or 'MISSING'} · "
                f"closure {state or 'MISSING'}"
            ),
            "Terminal Trial Outcome와 Closure state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Closure → Immutable Trial Outcome Source Mapping",
            _source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source {_text(closure.get('source_trial_outcome_id')) or 'NONE'} · "
                f"integrity {_text(closure.get('source_trial_outcome_integrity')) or 'NONE'}"
            ),
            "Closure source Trial Outcome id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Closure Human Decision Contract Invariant",
            _decision_contract_ok(
                closure
            ),
            (
                f"state {state or 'MISSING'} · "
                f"decision {_text(closure.get('decision')) or 'NONE'}"
            ),
            "Human decision/rationale/confirmations/rollback closure 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Closure Rollback / Live-Change-Review Permission Invariant",
            _permission_rollback_ok(
                closure
            ),
            (
                f"state {state or 'MISSING'} · "
                f"rollback {_bool(closure.get('rollback_required'))} · "
                f"permission {_text(closure.get('live_change_review_permission')) or 'NONE'}"
            ),
            "Rollback closure와 DESIGN_REVIEW_ONLY permission 의미 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Closure Time-order / Source Supersession Invariant",
            _time_order_supersession_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"source created {_text(closure.get('source_trial_outcome_created_at')) or 'NONE'} · "
                f"latest closure {_text((ctx.get('latest_closure') or {}).get('controlled_trial_closure_id')) or 'NONE'}"
            ),
            "Closure 저장 순서와 새 Trial Outcome source supersession 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Closure No-Live-Authorization Invariant",
            _no_live_authorization_ok(
                ctx
            ),
            "NONE",
            "Closure/Live-Change Review/Trial/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "TRIAL_CLOSURE_NOT_REQUIRED",
            "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
            "TRIAL_CLOSURE_REJECTED",
            "TRIAL_CLOSURE_DEFERRED",
            "TRIAL_CLOSURE_ROLLBACK_CLOSED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Closure Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"outcome {_text(outcome.get('outcome_state')) or 'MISSING'} · "
                f"decision {_text(closure.get('decision')) or 'NONE'}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 closure wait/audit/review/rollback 상태는 Technical FAIL로 승격하지 않고 "
                    "immutable terminal Outcome 및 Human closure evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "closure_state": state,
        "outcome_state": _text(
            outcome.get("outcome_state")
        ).upper(),
        "latest_trial_closure_integrity":
            _text(
                ctx.get(
                    "latest_closure_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_CLOSURE_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _saved_contract_ok(
    row: dict,
) -> bool:
    state = _text(
        row.get("closure_state")
    ).upper()
    guard = _text(
        row.get("closure_guard")
    ).upper()
    decision = _text(
        row.get("decision")
    ).upper()
    outcome_state = _text(
        row.get("outcome_state")
    ).upper()

    expected = {
        "ACCEPT_FOR_LIVE_CHANGE_REVIEW":
            "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
        "REJECT":
            "TRIAL_CLOSURE_REJECTED",
        "DEFER":
            "TRIAL_CLOSURE_DEFERRED",
        "ROLLBACK_CLOSED":
            "TRIAL_CLOSURE_ROLLBACK_CLOSED",
    }.get(
        decision
    )

    if (
        decision not in TRIAL_CLOSURE_DECISIONS
        or state != expected
        or guard
        != TRIAL_CLOSURE_GUARD_BY_STATE.get(
            state,
            "",
        )
        or len(
            _text(
                row.get(
                    "decision_detail"
                )
            )
        ) < 40
    ):
        return False

    common = [
        "outcome_source_reviewed",
        "trial_evidence_reviewed",
        "reversal_risk_reviewed",
        "no_live_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    if not all(
        _bool(
            row.get(field)
        )
        for field in common
    ):
        return False

    if decision == "ACCEPT_FOR_LIVE_CHANGE_REVIEW":
        return (
            outcome_state
            == "TRIAL_OUTCOME_PASS_NO_PROMOTION"
            and _bool(
                row.get(
                    "live_change_review_only_confirmed"
                )
            )
            and _text(
                row.get(
                    "live_change_review_permission"
                )
            ).upper()
            == "DESIGN_REVIEW_ONLY"
            and not _bool(
                row.get(
                    "rollback_required"
                )
            )
        )

    if decision in {
        "REJECT",
        "DEFER",
    }:
        return (
            outcome_state
            in {
                "TRIAL_OUTCOME_PASS_NO_PROMOTION",
                "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
            }
            and _text(
                row.get(
                    "live_change_review_permission"
                )
            ).upper()
            in {"", "NONE"}
        )

    if decision == "ROLLBACK_CLOSED":
        rollback_flags = [
            "rollback_completed_confirmed",
            "prior_baseline_restored_confirmed",
            "rollback_integrity_verified",
            "postmortem_reviewed",
        ]

        return (
            outcome_state
            in ROLLBACK_OUTCOME_STATES
            and _bool(
                row.get(
                    "rollback_required"
                )
            )
            and all(
                _bool(
                    row.get(field)
                )
                for field in rollback_flags
            )
            and len(
                _text(
                    row.get(
                        "rollback_detail"
                    )
                )
            ) >= 40
            and _text(
                row.get(
                    "live_change_review_permission"
                )
            ).upper()
            in {"", "NONE"}
        )

    return False


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v145_trial_closure_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    closure_df = _ensure_cols(
        ctx.get(
            "controlled_trial_closure_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    )

    outcome_df = _ensure_cols(
        ctx.get(
            "controlled_trial_outcome_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        closure_df,
        controlled_trial_closure_snapshot_integrity,
    )

    outcome_index, outcome_duplicates = _index_by_id(
        outcome_df,
        "controlled_trial_outcome_id",
    )

    contract_violations = 0
    lineage_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in closure_df.iterrows():
        item = row.to_dict()

        closure_id = _text(
            item.get(
                "controlled_trial_closure_id"
            )
        )

        if closure_id:
            if closure_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(closure_id)

        if not _saved_contract_ok(
            item
        ):
            contract_violations += 1

        source_id = _text(
            item.get(
                "source_trial_outcome_id"
            )
        )
        source_hash = _text(
            item.get(
                "source_trial_outcome_hash"
            )
        )

        parent = outcome_index.get(
            source_id
        )

        if (
            not parent
            or _text(
                controlled_trial_outcome_snapshot_integrity(
                    parent
                ).get("status")
            ).upper()
            != "OK"
            or _text(
                parent.get(
                    "snapshot_hash"
                )
            )
            != source_hash
            or _text(
                parent.get(
                    "outcome_state"
                )
            ).upper()
            not in TERMINAL_OUTCOME_STATES
            or _text(
                parent.get(
                    "outcome_state"
                )
            ).upper()
            != _text(
                item.get(
                    "outcome_state"
                )
            ).upper()
        ):
            lineage_violations += 1
        else:
            source_ts = pd.to_datetime(
                parent.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )
            closure_ts = pd.to_datetime(
                item.get(
                    "created_at"
                ),
                errors="coerce",
                utc=True,
            )

            if (
                pd.isna(source_ts)
                or pd.isna(closure_ts)
                or closure_ts <= source_ts
            ):
                time_order_violations += 1

        for field in [
            "trial_closure_authorization",
            "live_change_review_authorization",
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Controlled Trial Closure Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Closure immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Closure Audit Human Decision / Rollback Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "Human decision, rollback closure, DESIGN_REVIEW_ONLY permission contract 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Closure Audit → Terminal Outcome Lineage",
            (
                lineage_violations == 0
                and outcome_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"outcome duplicate ids {outcome_duplicates}"
            ),
            "Closure source terminal Trial Outcome id/hash/state lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Closure Audit Identity / Time-order Invariant",
            (
                identity_duplicates == 0
                and time_order_violations == 0
            ),
            (
                f"duplicate closure ids {identity_duplicates} · "
                f"time-order violations {time_order_violations}"
            ),
            "Closure audit identity uniqueness 및 Trial Outcome audit 이후 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Closure Audit No-Live-Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else (
                    f"non-NONE sources "
                    f"{authorization_violations}"
                )
            ),
            "Closure/Live-Change Review/Trial/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("closure") or {}).get(
            "closure_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "TRIAL_CLOSURE_NOT_REQUIRED",
            "TRIAL_CLOSURE_ACCEPTED_FOR_LIVE_CHANGE_REVIEW",
            "TRIAL_CLOSURE_REJECTED",
            "TRIAL_CLOSURE_DEFERRED",
            "TRIAL_CLOSURE_ROLLBACK_CLOSED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Closure Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current closure {current_state or 'MISSING'} · "
                f"saved closures {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 immutable terminal Trial Outcome 이후 Human Closure 또는 rollback closure가 필요할 때만 "
                    "Closure audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_CLOSURE_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v145_release_readiness(
    *,
    v144_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    trial_closure_release_gate: str,
    trial_closure_audit_gate: str,
    trial_closure_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.44 Controlled Trial Outcome Release Baseline",
            _text(
                v144_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v144_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Closure Technical Release Gate",
            _text(
                trial_closure_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_closure_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Closure Audit Integrity Gate",
            _text(
                trial_closure_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_closure_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            trial_closure_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "CONTROLLED_TRIAL_CLOSURE_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V145_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v145_integration_crosscheck(
    *,
    integration_consistency: str,
    trial_closure_release_gate: str,
    trial_closure_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Closure Technical Gate",
            _text(
                trial_closure_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_closure_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Closure Audit Gate",
            _text(
                trial_closure_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_closure_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V145_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v145_data_crosscheck(
    *,
    csv_fail_count: int,
    trial_closure_release_gate: str,
    trial_closure_audit_gate: str,
    latest_trial_closure_integrity: str,
) -> dict:
    latest = _text(
        latest_trial_closure_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Closure Technical Gate",
            _text(
                trial_closure_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_closure_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Closure Audit Gate",
            _text(
                trial_closure_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_closure_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Controlled Trial Closure Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V145_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
