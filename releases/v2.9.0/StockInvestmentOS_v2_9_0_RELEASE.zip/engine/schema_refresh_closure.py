from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.schema_evolution_guard import (
    build_schema_snapshot,
    schema_baseline_integrity,
    latest_schema_baseline,
)
from engine.schema_migration_contract import (
    schema_contract_integrity,
    latest_schema_contract,
)


SCHEMA_REFRESH_APPROVAL_COLS = [
    "schema_refresh_approval_id",
    "created_at",
    "source_baseline_id",
    "source_baseline_record_hash",
    "source_contract_id",
    "source_contract_record_hash",
    "target_schema_snapshot_hash",
    "changed_files",
    "proof_accepted",
    "compatibility_closure_status",
    "accepted_proof_ids",
    "accepted_proof_hashes",
    "refresh_reason",
    "refresh_scope",
    "rollback_reference",
    "proof_coverage_confirmed",
    "target_schema_confirmed",
    "no_auto_refresh_confirmed",
    "no_destructive_migration_confirmed",
    "human_review_confirmed",
    "approval_gate",
    "approval_status",
    "migration_authorization",
    "issues",
    "note",
    "record_hash",
]


SCHEMA_REFRESH_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {"TRUE", "1", "YES", "Y", "PASS"}


def _int(value: Any) -> int:
    try:
        return int(float(value))
    except Exception:
        return 0


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _ts(value: Any):
    raw = _text(value)
    if not raw:
        return None
    out = pd.to_datetime(raw, errors="coerce", utc=True)
    return None if pd.isna(out) else out


def _approval_payload(row: dict) -> dict:
    bool_fields = {
        "proof_coverage_confirmed",
        "target_schema_confirmed",
        "no_auto_refresh_confirmed",
        "no_destructive_migration_confirmed",
        "human_review_confirmed",
    }

    payload = {}
    for col in SCHEMA_REFRESH_APPROVAL_COLS:
        if col == "record_hash":
            continue
        if col in bool_fields:
            payload[col] = bool(_bool(row.get(col)))
        else:
            payload[col] = _text(row.get(col))
    return payload


def schema_refresh_approval_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(record.get("record_hash"))

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(_approval_payload(record))
    return {
        "status": "OK" if stored == calculated else "MISMATCH",
        "calculated_hash": calculated,
    }


def latest_schema_refresh_approval(
    approvals: pd.DataFrame | None,
    target_schema_snapshot_hash: str = "",
) -> dict:
    if approvals is None or approvals.empty:
        return {}

    df = approvals.copy()

    if target_schema_snapshot_hash:
        if "target_schema_snapshot_hash" not in df.columns:
            return {}
        df = df.loc[
            df["target_schema_snapshot_hash"]
            .fillna("")
            .astype(str)
            .str.lower()
            .eq(_text(target_schema_snapshot_hash).lower())
        ].copy()

    if df.empty:
        return {}

    if "created_at" in df.columns:
        df["_ts"] = pd.to_datetime(
            df["created_at"],
            errors="coerce",
            utc=True,
        )
        df = df.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return df.iloc[0].drop(labels=["_ts"], errors="ignore").to_dict()


def _accepted_proof_lineage(
    closure: dict | None,
    proof_reviews: pd.DataFrame | None,
) -> dict:
    close = closure or {}
    details = close.get("details")

    if (
        not isinstance(details, pd.DataFrame)
        or details.empty
        or _text(close.get("closure_status")).upper()
        != "READY_FOR_BASELINE_REFRESH"
    ):
        return {
            "proof_ids": [],
            "proof_hashes": [],
            "files": [],
            "complete": False,
        }

    accepted = details.loc[
        details["closure_item_status"]
        .fillna("")
        .astype(str)
        .eq("PROOF_ACCEPTED")
    ].copy()

    changed_files = _int(close.get("changed_files"))

    if len(accepted) != changed_files:
        return {
            "proof_ids": [],
            "proof_hashes": [],
            "files": [],
            "complete": False,
        }

    proofs = (
        pd.DataFrame()
        if proof_reviews is None
        else proof_reviews.copy()
    )

    proof_ids = []
    proof_hashes = []
    files = []

    for _, row in accepted.iterrows():
        proof_id = _text(row.get("proof_id"))
        file_name = _text(row.get("file"))

        if not proof_id:
            return {
                "proof_ids": [],
                "proof_hashes": [],
                "files": [],
                "complete": False,
            }

        if proofs.empty or "migration_proof_id" not in proofs.columns:
            return {
                "proof_ids": [],
                "proof_hashes": [],
                "files": [],
                "complete": False,
            }

        hit = proofs.loc[
            proofs["migration_proof_id"]
            .fillna("")
            .astype(str)
            .eq(proof_id)
        ]

        if hit.empty:
            return {
                "proof_ids": [],
                "proof_hashes": [],
                "files": [],
                "complete": False,
            }

        proof_row = hit.iloc[-1].to_dict()
        proof_hash = _text(proof_row.get("record_hash"))

        if not proof_hash:
            return {
                "proof_ids": [],
                "proof_hashes": [],
                "files": [],
                "complete": False,
            }

        proof_ids.append(proof_id)
        proof_hashes.append(proof_hash)
        files.append(file_name)

    return {
        "proof_ids": proof_ids,
        "proof_hashes": proof_hashes,
        "files": files,
        "complete": True,
    }


def validate_schema_refresh_approval(
    current_scan: pd.DataFrame | None,
    source_baseline: dict | None,
    source_contract: dict | None,
    compatibility_closure: dict | None,
    proof_reviews: pd.DataFrame | None,
    existing_approval: dict | None,
    *,
    refresh_reason: str,
    refresh_scope: str,
    rollback_reference: str,
    proof_coverage_confirmed: bool,
    target_schema_confirmed: bool,
    no_auto_refresh_confirmed: bool,
    no_destructive_migration_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    baseline = source_baseline or {}
    contract = source_contract or {}
    closure = compatibility_closure or {}
    existing = existing_approval or {}
    issues = []

    target_hash = build_schema_snapshot(current_scan)["snapshot_hash"]

    if not baseline:
        issues.append("SOURCE_SCHEMA_BASELINE_REQUIRED")
    elif schema_baseline_integrity(baseline)["status"] != "OK":
        issues.append("SOURCE_SCHEMA_BASELINE_INTEGRITY_FAILED")

    if not contract:
        issues.append("SOURCE_SCHEMA_CONTRACT_REQUIRED")
    elif schema_contract_integrity(contract)["status"] != "OK":
        issues.append("SOURCE_SCHEMA_CONTRACT_INTEGRITY_FAILED")

    if _text(closure.get("closure_status")).upper() != (
        "READY_FOR_BASELINE_REFRESH"
    ):
        issues.append("COMPATIBILITY_CLOSURE_READY_REQUIRED")

    lineage = _accepted_proof_lineage(
        closure,
        proof_reviews,
    )

    if not lineage["complete"]:
        issues.append("ACCEPTED_MIGRATION_PROOF_COVERAGE_REQUIRED")

    if existing:
        if schema_refresh_approval_integrity(existing)["status"] == "OK":
            if (
                _text(existing.get("target_schema_snapshot_hash")).lower()
                == target_hash.lower()
                and _text(existing.get("approval_status")).upper()
                == "APPROVED_FOR_BASELINE_REFRESH"
            ):
                issues.append("CURRENT_REFRESH_ALREADY_APPROVED")

    for value, issue in [
        (refresh_reason, "REFRESH_REASON_REQUIRED"),
        (refresh_scope, "REFRESH_SCOPE_REQUIRED"),
        (rollback_reference, "ROLLBACK_REFERENCE_REQUIRED"),
    ]:
        if not _text(value):
            issues.append(issue)

    for passed, issue in [
        (proof_coverage_confirmed, "PROOF_COVERAGE_CONFIRMATION_REQUIRED"),
        (target_schema_confirmed, "TARGET_SCHEMA_CONFIRMATION_REQUIRED"),
        (no_auto_refresh_confirmed, "NO_AUTO_REFRESH_CONFIRMATION_REQUIRED"),
        (
            no_destructive_migration_confirmed,
            "NO_DESTRUCTIVE_MIGRATION_CONFIRMATION_REQUIRED",
        ),
        (human_review_confirmed, "HUMAN_REVIEW_CONFIRMATION_REQUIRED"),
    ]:
        if not _bool(passed):
            issues.append(issue)

    blocking = [
        issue
        for issue in issues
        if issue != "CURRENT_REFRESH_ALREADY_APPROVED"
    ]

    if (
        existing
        and "CURRENT_REFRESH_ALREADY_APPROVED" in issues
        and not blocking
    ):
        gate = "REVIEW"
        status = "ALREADY_APPROVED"
    elif not issues:
        gate = "PASS"
        status = "APPROVED_FOR_BASELINE_REFRESH"
    else:
        gate = "REVIEW"
        status = "DRAFT"

    return {
        "approval_gate": gate,
        "approval_status": status,
        "target_schema_snapshot_hash": target_hash,
        "proof_lineage": lineage,
        "migration_authorization": "NONE",
        "issues": list(dict.fromkeys(issues)),
    }


def build_schema_refresh_approval_record(
    current_scan: pd.DataFrame,
    source_baseline: dict,
    source_contract: dict,
    compatibility_closure: dict,
    validation: dict,
    *,
    refresh_reason: str,
    refresh_scope: str,
    rollback_reference: str,
    proof_coverage_confirmed: bool,
    target_schema_confirmed: bool,
    no_auto_refresh_confirmed: bool,
    no_destructive_migration_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    now = _text(created_at) or datetime.now().astimezone().isoformat()
    target_hash = _text(validation.get("target_schema_snapshot_hash"))
    lineage = validation.get("proof_lineage") or {}

    approval_id = (
        "SRA-"
        + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S")
        + "-"
        + (target_hash[:8] if target_hash else "NOHASH")
    )

    row = {
        "schema_refresh_approval_id": approval_id,
        "created_at": now,
        "source_baseline_id": _text(
            source_baseline.get("schema_baseline_id")
        ),
        "source_baseline_record_hash": _text(
            source_baseline.get("record_hash")
        ),
        "source_contract_id": _text(
            source_contract.get("schema_contract_id")
        ),
        "source_contract_record_hash": _text(
            source_contract.get("record_hash")
        ),
        "target_schema_snapshot_hash": target_hash,
        "changed_files": _int(
            compatibility_closure.get("changed_files")
        ),
        "proof_accepted": _int(
            compatibility_closure.get("proof_accepted")
        ),
        "compatibility_closure_status": _text(
            compatibility_closure.get("closure_status")
        ),
        "accepted_proof_ids": " | ".join(
            lineage.get("proof_ids", [])
        ),
        "accepted_proof_hashes": " | ".join(
            lineage.get("proof_hashes", [])
        ),
        "refresh_reason": _text(refresh_reason),
        "refresh_scope": _text(refresh_scope),
        "rollback_reference": _text(rollback_reference),
        "proof_coverage_confirmed": bool(proof_coverage_confirmed),
        "target_schema_confirmed": bool(target_schema_confirmed),
        "no_auto_refresh_confirmed": bool(no_auto_refresh_confirmed),
        "no_destructive_migration_confirmed": bool(
            no_destructive_migration_confirmed
        ),
        "human_review_confirmed": bool(human_review_confirmed),
        "approval_gate": _text(validation.get("approval_gate")),
        "approval_status": _text(validation.get("approval_status")),
        "migration_authorization": "NONE",
        "issues": " | ".join(validation.get("issues", [])),
        "note": _text(note),
        "record_hash": "",
    }

    row["record_hash"] = _hash(_approval_payload(row))
    return row


def _is_after(
    row: dict,
    approval: dict,
) -> bool:
    row_ts = _ts(row.get("created_at"))
    approval_ts = _ts(approval.get("created_at"))

    if row_ts is None or approval_ts is None:
        return False

    return row_ts >= approval_ts


def _latest_matching_baseline(
    baselines: pd.DataFrame | None,
    target_hash: str,
    approval: dict,
) -> dict:
    if baselines is None or baselines.empty:
        return {}

    if "schema_snapshot_hash" not in baselines.columns:
        return {}

    hit = baselines.loc[
        baselines["schema_snapshot_hash"]
        .fillna("")
        .astype(str)
        .str.lower()
        .eq(_text(target_hash).lower())
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit["_ts"] = pd.to_datetime(
            hit["created_at"],
            errors="coerce",
            utc=True,
        )
        hit = hit.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    for _, row in hit.iterrows():
        item = row.drop(labels=["_ts"], errors="ignore").to_dict()
        if _is_after(item, approval):
            return item

    return {}


def _latest_matching_contract(
    contracts: pd.DataFrame | None,
    target_hash: str,
    baseline: dict,
    approval: dict,
) -> dict:
    if contracts is None or contracts.empty:
        return {}

    required_cols = {
        "schema_snapshot_hash",
        "schema_baseline_id",
    }

    if not required_cols.issubset(set(contracts.columns)):
        return {}

    hit = contracts.loc[
        contracts["schema_snapshot_hash"]
        .fillna("")
        .astype(str)
        .str.lower()
        .eq(_text(target_hash).lower())
        & contracts["schema_baseline_id"]
        .fillna("")
        .astype(str)
        .eq(_text(baseline.get("schema_baseline_id")))
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit["_ts"] = pd.to_datetime(
            hit["created_at"],
            errors="coerce",
            utc=True,
        )
        hit = hit.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    for _, row in hit.iterrows():
        item = row.drop(labels=["_ts"], errors="ignore").to_dict()
        if _is_after(item, approval):
            return item

    return {}


def build_schema_refresh_closure(
    current_scan: pd.DataFrame | None,
    compatibility_closure: dict | None,
    approvals: pd.DataFrame | None,
    baselines: pd.DataFrame | None,
    contracts: pd.DataFrame | None,
) -> dict:
    close = compatibility_closure or {}
    target_hash = build_schema_snapshot(current_scan)["snapshot_hash"]
    closure_status = _text(close.get("closure_status")).upper()

    if closure_status == "NO_CHANGE":
        return {
            "refresh_status": "NOT_REQUIRED",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": "",
            "approval_integrity": "NONE",
            "refreshed_baseline_id": "",
            "refreshed_baseline_integrity": "NONE",
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": [],
        }

    if closure_status != "READY_FOR_BASELINE_REFRESH":
        return {
            "refresh_status": "PROOF_NOT_READY",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": "",
            "approval_integrity": "NONE",
            "refreshed_baseline_id": "",
            "refreshed_baseline_integrity": "NONE",
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["COMPATIBILITY_CLOSURE_NOT_READY"],
        }

    approval = latest_schema_refresh_approval(
        approvals,
        target_hash,
    )

    if not approval:
        return {
            "refresh_status": "REFRESH_APPROVAL_PENDING",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": "",
            "approval_integrity": "NONE",
            "refreshed_baseline_id": "",
            "refreshed_baseline_integrity": "NONE",
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["SCHEMA_REFRESH_APPROVAL_REQUIRED"],
        }

    approval_integrity = schema_refresh_approval_integrity(approval)["status"]

    if approval_integrity != "OK":
        return {
            "refresh_status": "INTEGRITY_REVIEW",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": _text(approval.get("schema_refresh_approval_id")),
            "approval_integrity": approval_integrity,
            "refreshed_baseline_id": "",
            "refreshed_baseline_integrity": "NONE",
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["SCHEMA_REFRESH_APPROVAL_INTEGRITY_FAILED"],
        }

    if _text(approval.get("approval_status")).upper() != (
        "APPROVED_FOR_BASELINE_REFRESH"
    ):
        return {
            "refresh_status": "REFRESH_APPROVAL_PENDING",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": _text(approval.get("schema_refresh_approval_id")),
            "approval_integrity": approval_integrity,
            "refreshed_baseline_id": "",
            "refreshed_baseline_integrity": "NONE",
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["SCHEMA_REFRESH_APPROVAL_NOT_FINAL"],
        }

    baseline = _latest_matching_baseline(
        baselines,
        target_hash,
        approval,
    )

    if not baseline:
        return {
            "refresh_status": "BASELINE_REFRESH_PENDING",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": _text(approval.get("schema_refresh_approval_id")),
            "approval_integrity": approval_integrity,
            "refreshed_baseline_id": "",
            "refreshed_baseline_integrity": "NONE",
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["NEW_SCHEMA_BASELINE_LOCK_REQUIRED"],
        }

    baseline_integrity = schema_baseline_integrity(baseline)["status"]

    if baseline_integrity != "OK":
        return {
            "refresh_status": "INTEGRITY_REVIEW",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": _text(approval.get("schema_refresh_approval_id")),
            "approval_integrity": approval_integrity,
            "refreshed_baseline_id": _text(baseline.get("schema_baseline_id")),
            "refreshed_baseline_integrity": baseline_integrity,
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["REFRESHED_BASELINE_INTEGRITY_FAILED"],
        }

    contract = _latest_matching_contract(
        contracts,
        target_hash,
        baseline,
        approval,
    )

    if not contract:
        return {
            "refresh_status": "CONTRACT_RELOCK_PENDING",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": _text(approval.get("schema_refresh_approval_id")),
            "approval_integrity": approval_integrity,
            "refreshed_baseline_id": _text(baseline.get("schema_baseline_id")),
            "refreshed_baseline_integrity": baseline_integrity,
            "relocked_contract_id": "",
            "relocked_contract_integrity": "NONE",
            "migration_authorization": "NONE",
            "issues": ["NEW_SCHEMA_CONTRACT_LOCK_REQUIRED"],
        }

    contract_integrity = schema_contract_integrity(contract)["status"]

    if contract_integrity != "OK":
        return {
            "refresh_status": "INTEGRITY_REVIEW",
            "target_schema_snapshot_hash": target_hash,
            "approval_id": _text(approval.get("schema_refresh_approval_id")),
            "approval_integrity": approval_integrity,
            "refreshed_baseline_id": _text(baseline.get("schema_baseline_id")),
            "refreshed_baseline_integrity": baseline_integrity,
            "relocked_contract_id": _text(contract.get("schema_contract_id")),
            "relocked_contract_integrity": contract_integrity,
            "migration_authorization": "NONE",
            "issues": ["RELOCKED_CONTRACT_INTEGRITY_FAILED"],
        }

    return {
        "refresh_status": "MIGRATION_CLOSED",
        "target_schema_snapshot_hash": target_hash,
        "approval_id": _text(approval.get("schema_refresh_approval_id")),
        "approval_integrity": approval_integrity,
        "refreshed_baseline_id": _text(baseline.get("schema_baseline_id")),
        "refreshed_baseline_integrity": baseline_integrity,
        "relocked_contract_id": _text(contract.get("schema_contract_id")),
        "relocked_contract_integrity": contract_integrity,
        "migration_authorization": "NONE",
        "issues": [],
    }


def build_schema_refresh_queue(
    refresh_closure: dict | None,
) -> pd.DataFrame:
    result = refresh_closure or {}
    status = _text(result.get("refresh_status")).upper()

    mapping = {
        "INTEGRITY_REVIEW": (
            "SR0",
            "BLOCKED",
            "SCHEMA_REFRESH_LINEAGE_INTEGRITY_REVIEW",
            "Approval / Baseline / Contract immutable hash를 먼저 확인",
        ),
        "REFRESH_APPROVAL_PENDING": (
            "SR1",
            "REVIEW",
            "SCHEMA_REFRESH_APPROVAL_PENDING",
            "Proof coverage와 target schema를 확인하고 Refresh Approval Human Review",
        ),
        "BASELINE_REFRESH_PENDING": (
            "SR2",
            "REVIEW",
            "NEW_SCHEMA_BASELINE_LOCK_PENDING",
            "Save Center 1I에서 현재 target schema를 새 Baseline으로 Human Review 후 Lock",
        ),
        "CONTRACT_RELOCK_PENDING": (
            "SR3",
            "REVIEW",
            "NEW_SCHEMA_CONTRACT_RELOCK_PENDING",
            "Save Center 1J에서 새 Baseline 기준 Reader-Writer Contract를 Human Review 후 Re-lock",
        ),
        "PROOF_NOT_READY": (
            "SR1",
            "REVIEW",
            "MIGRATION_PROOF_NOT_READY",
            "Migration Proposal / Proof / Compatibility Closure를 먼저 완료",
        ),
    }

    if status in {
        "NOT_REQUIRED",
        "MIGRATION_CLOSED",
    }:
        return pd.DataFrame(
            columns=SCHEMA_REFRESH_QUEUE_COLS
        )

    priority, row_status, issue, action = mapping.get(
        status,
        (
            "SR1",
            "REVIEW",
            "SCHEMA_REFRESH_REVIEW_REQUIRED",
            "Schema Refresh 상태를 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority": priority,
                "status": row_status,
                "issue": issue,
                "next_action": action,
                "go_to": "Save Center",
            }
        ],
        columns=SCHEMA_REFRESH_QUEUE_COLS,
    )
