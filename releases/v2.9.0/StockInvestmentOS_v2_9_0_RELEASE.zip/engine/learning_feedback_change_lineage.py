from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.learning_feedback_governance import (
    learning_feedback_record_integrity,
)
from engine.learning_feedback_revalidation_bridge import (
    feedback_revalidation_draft_integrity,
)
from engine.capital_productivity import (
    normalize_capital_productivity_inputs,
    normalize_calibration_drafts,
    calibration_draft_integrity,
)
from engine.capital_productivity_revalidation import (
    normalize_revalidations,
    revalidation_record_integrity,
)


FEEDBACK_CLOSURE_ACTIONS = [
    "CLOSE_SOURCE_REVIEWED",
    "KEEP_OPEN_MORE_EVIDENCE",
]


LEARNING_FEEDBACK_CHANGE_LINEAGE_COLS = [
    "change_lineage_id",
    "created_at",
    "feedback_id",
    "feedback_record_hash",
    "feedback_integrity_status",
    "bridge_id",
    "bridge_record_hash",
    "bridge_integrity_status",
    "company",
    "feedback_target",
    "change_direction",
    "proposed_delta",
    "bridge_route",
    "source_review_type",
    "source_review_id",
    "source_review_timestamp",
    "source_review_hash",
    "source_review_integrity_status",
    "source_review_gate",
    "baseline_value",
    "proposed_value",
    "source_review_value",
    "live_register_value",
    "proposal_outcome",
    "live_register_match_status",
    "source_review_result_confirmed",
    "proposal_outcome_confirmed",
    "no_auto_carry_forward_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "closure_action",
    "closure_gate",
    "closure_status",
    "execution_authorization",
    "issues",
    "note",
    "record_hash",
]


LEARNING_FEEDBACK_CLOSURE_QUEUE_COLS = [
    "priority",
    "bucket",
    "due_date",
    "days_to_due",
    "subject",
    "target",
    "direction",
    "bridge_route",
    "source_review_status",
    "proposal_outcome",
    "closure_status",
    "issue",
    "next_action",
    "go_to",
    "feedback_id",
    "bridge_id",
    "source_review_id",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _num(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        out = float(value)
    except Exception:
        return None
    return None if pd.isna(out) else out


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {
        "TRUE", "1", "YES", "Y", "PASS",
    }


def _hash(payload: Any) -> str:
    text = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def _stable_num(
    value: Any,
    places: int = 12,
) -> str | None:
    number = _num(value)
    if number is None:
        return None
    return f"{number:.{int(places)}f}"


def _same_num(
    a: Any,
    b: Any,
    tolerance: float = 1e-9,
) -> bool:
    x = _num(a)
    y = _num(b)
    if x is None or y is None:
        return False
    return abs(x - y) <= max(
        0.0,
        float(tolerance),
    )


def _timestamp(
    value: Any,
) -> pd.Timestamp | None:
    ts = pd.to_datetime(
        value,
        errors="coerce",
        utc=True,
    )
    if pd.isna(ts):
        return None
    return pd.Timestamp(ts)


def _lookup_input(
    inputs: pd.DataFrame | None,
    company: str,
) -> dict:
    df = normalize_capital_productivity_inputs(
        inputs
    )
    if df.empty:
        return {}
    hit = df.loc[
        df["name"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(company)
        )
    ]
    if hit.empty:
        return {}
    return hit.iloc[-1].to_dict()


def _target_value(
    row: dict,
    target: str,
) -> float | None:
    target = _text(
        target
    ).upper()

    if target == "FORWARD_ER":
        return _num(
            row.get(
                "forward_er"
            )
        )
    if target == "RISK_PENALTY":
        return _num(
            row.get(
                "risk_penalty"
            )
        )
    if target == "HURDLE":
        return _num(
            row.get(
                "hurdle_rate"
            )
        )
    return None


def _draft_baseline_value(
    row: dict,
    target: str,
) -> float | None:
    target = _text(
        target
    ).upper()
    mapping = {
        "FORWARD_ER":
            "current_forward_er",
        "RISK_PENALTY":
            "current_risk_penalty",
        "HURDLE":
            "current_hurdle_rate",
    }
    return _num(
        row.get(
            mapping.get(
                target,
                "",
            )
        )
    )


def _draft_proposed_value(
    row: dict,
    target: str,
) -> float | None:
    target = _text(
        target
    ).upper()
    mapping = {
        "FORWARD_ER":
            "proposed_forward_er",
        "RISK_PENALTY":
            "proposed_risk_penalty",
        "HURDLE":
            "proposed_hurdle_rate",
    }
    return _num(
        row.get(
            mapping.get(
                target,
                "",
            )
        )
    )


def _calibration_target_value(
    row: dict,
    target: str,
) -> float | None:
    target = _text(
        target
    ).upper()
    if target == "FORWARD_ER":
        return _num(
            row.get(
                "selected_forward_er"
            )
        )
    if target == "RISK_PENALTY":
        return _num(
            row.get(
                "selected_risk_penalty"
            )
        )
    if target == "HURDLE":
        return _num(
            row.get(
                "hurdle_rate"
            )
        )
    return None


def _latest_calibration_after(
    drafts: pd.DataFrame | None,
    company: str,
    after_ts: pd.Timestamp | None,
) -> dict:
    df = normalize_calibration_drafts(
        drafts
    )
    if df.empty:
        return {}

    hit = df.loc[
        df["name"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(company)
        )
        & df["approval_status"]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "APPROVED"
        )
        & df["purpose"]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "OPERATING_ASSUMPTION"
        )
    ].copy()

    if hit.empty:
        return {}

    hit["_event_ts"] = pd.to_datetime(
        hit["approved_at"],
        errors="coerce",
        utc=True,
    )

    hit = hit.dropna(
        subset=[
            "_event_ts"
        ]
    )

    if after_ts is not None:
        hit = hit.loc[
            hit[
                "_event_ts"
            ] >= after_ts
        ]

    if hit.empty:
        return {}

    hit = hit.sort_values(
        "_event_ts",
        ascending=False,
    )

    return (
        hit.iloc[0]
        .drop(
            labels=[
                "_event_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def _latest_revalidation_after(
    revalidations: pd.DataFrame | None,
    company: str,
    after_ts: pd.Timestamp | None,
) -> dict:
    df = normalize_revalidations(
        revalidations
    )
    if df.empty:
        return {}

    hit = df.loc[
        df["name"]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(company)
        )
        & df["governance_gate"]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "PASS"
        )
    ].copy()

    if hit.empty:
        return {}

    hit["_event_ts"] = pd.to_datetime(
        hit["reviewed_at"],
        errors="coerce",
        utc=True,
    )
    hit = hit.dropna(
        subset=[
            "_event_ts"
        ]
    )

    if after_ts is not None:
        hit = hit.loc[
            hit[
                "_event_ts"
            ] >= after_ts
        ]

    if hit.empty:
        return {}

    hit = hit.sort_values(
        "_event_ts",
        ascending=False,
    )

    return (
        hit.iloc[0]
        .drop(
            labels=[
                "_event_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def _proposal_outcome(
    baseline: float | None,
    proposed: float | None,
    actual: float | None,
) -> str:
    if (
        baseline is None
        or proposed is None
        or actual is None
    ):
        return "NOT_EVALUABLE"

    if _same_num(
        baseline,
        proposed,
    ):
        if _same_num(
            actual,
            baseline,
        ):
            return "NO_CHANGE_CONFIRMED"
        return "MATERIAL_CHANGE_DETECTED"

    if _same_num(
        actual,
        proposed,
    ):
        return "MATCHED_PROPOSAL"

    if _same_num(
        actual,
        baseline,
    ):
        return "NO_CHANGE_AFTER_REVIEW"

    proposal_move = (
        proposed
        - baseline
    )
    actual_move = (
        actual
        - baseline
    )

    if (
        proposal_move
        * actual_move
        > 0
    ):
        return "SAME_DIRECTION_DIFFERENT_MAGNITUDE"

    return "DIFFERENT_DIRECTION"


def build_feedback_change_context(
    bridge_draft: dict | None,
    feedback_row: dict | None,
    capital_productivity_inputs: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    revalidations: pd.DataFrame | None,
) -> dict:
    bridge = bridge_draft or {}
    feedback = feedback_row or {}

    issues = []

    bridge_integrity = feedback_revalidation_draft_integrity(
        bridge
    )
    feedback_integrity = learning_feedback_record_integrity(
        feedback
    )

    if bridge_integrity[
        "status"
    ] != "OK":
        issues.append(
            "BRIDGE_DRAFT_INTEGRITY_FAILED"
        )

    if feedback_integrity[
        "status"
    ] != "OK":
        issues.append(
            "FEEDBACK_RECORD_INTEGRITY_FAILED"
        )

    if _text(
        bridge.get(
            "draft_status"
        )
    ).upper() != "READY_FOR_SOURCE_REVIEW":
        issues.append(
            "BRIDGE_DRAFT_NOT_READY_FOR_SOURCE_REVIEW"
        )

    if _text(
        feedback.get(
            "proposal_status"
        )
    ).upper() != "APPROVED_FOR_REVALIDATION":
        issues.append(
            "FEEDBACK_NOT_APPROVED_FOR_REVALIDATION"
        )

    if _text(
        bridge.get(
            "feedback_id"
        )
    ) != _text(
        feedback.get(
            "feedback_id"
        )
    ):
        issues.append(
            "FEEDBACK_ID_MISMATCH"
        )

    if _text(
        bridge.get(
            "feedback_record_hash"
        )
    ) != _text(
        feedback.get(
            "record_hash"
        )
    ):
        issues.append(
            "FEEDBACK_HASH_SNAPSHOT_MISMATCH"
        )

    if _text(
        bridge.get(
            "execution_authorization"
        )
    ).upper() != "NONE":
        issues.append(
            "EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE"
        )

    company = _text(
        bridge.get(
            "company"
        )
    )
    target = _text(
        bridge.get(
            "feedback_target"
        )
    ).upper()
    direction = _text(
        bridge.get(
            "change_direction"
        )
    ).upper()
    route = _text(
        bridge.get(
            "bridge_route"
        )
    ).upper()

    baseline = _draft_baseline_value(
        bridge,
        target,
    )
    proposed = _draft_proposed_value(
        bridge,
        target,
    )

    live_row = _lookup_input(
        capital_productivity_inputs,
        company,
    )
    live_value = _target_value(
        live_row,
        target,
    )

    bridge_ts = _timestamp(
        bridge.get(
            "created_at"
        )
    )

    source_review = {}
    source_review_type = ""
    source_review_id = ""
    source_review_timestamp = ""
    source_review_hash = ""
    source_integrity_status = "NOT_FOUND"
    source_review_value = None

    if route == "CAPITAL_PRODUCTIVITY_CALIBRATION":
        source_review = _latest_calibration_after(
            calibration_drafts,
            company,
            bridge_ts,
        )
        source_review_type = "CALIBRATION"

        if source_review:
            source_review_id = _text(
                source_review.get(
                    "calibration_id"
                )
            )
            source_review_timestamp = _text(
                source_review.get(
                    "approved_at"
                )
            )
            source_review_hash = _text(
                source_review.get(
                    "content_hash"
                )
            )
            source_integrity_status = calibration_draft_integrity(
                source_review
            )
            source_review_value = _calibration_target_value(
                source_review,
                target,
            )
    elif route == "CAPITAL_PRODUCTIVITY_REVALIDATION":
        source_review = _latest_revalidation_after(
            revalidations,
            company,
            bridge_ts,
        )
        source_review_type = "REVALIDATION"

        if source_review:
            source_review_id = _text(
                source_review.get(
                    "revalidation_id"
                )
            )
            source_review_timestamp = _text(
                source_review.get(
                    "reviewed_at"
                )
            )
            source_review_hash = _text(
                source_review.get(
                    "content_hash"
                )
            )
            source_integrity_status = revalidation_record_integrity(
                source_review
            )
            source_review_value = _target_value(
                source_review,
                target,
            )
    else:
        issues.append(
            "UNSUPPORTED_BRIDGE_ROUTE"
        )

    if not source_review:
        issues.append(
            "SOURCE_REVIEW_NOT_FOUND_AFTER_BRIDGE"
        )
    elif source_integrity_status != "OK":
        issues.append(
            "SOURCE_REVIEW_INTEGRITY_FAILED"
        )

    live_match_status = "NOT_EVALUABLE"
    if (
        source_review_value is not None
        and live_value is not None
    ):
        live_match_status = (
            "MATCH"
            if _same_num(
                source_review_value,
                live_value,
            )
            else "MISMATCH"
        )
        if live_match_status != "MATCH":
            issues.append(
                "SOURCE_REVIEW_LIVE_REGISTER_MISMATCH"
            )
    elif source_review:
        issues.append(
            "SOURCE_REVIEW_LIVE_VALUE_NOT_EVALUABLE"
        )

    proposal_outcome = _proposal_outcome(
        baseline,
        proposed,
        live_value,
    )

    if proposal_outcome == "NOT_EVALUABLE":
        issues.append(
            "PROPOSAL_OUTCOME_NOT_EVALUABLE"
        )

    source_review_gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    if not source_review:
        closure_readiness = "SOURCE_REVIEW_PENDING"
    elif source_review_gate == "PASS":
        closure_readiness = "READY_FOR_CLOSURE"
    else:
        closure_readiness = "REVIEW"

    return {
        "feedback_id": _text(
            feedback.get(
                "feedback_id"
            )
        ),
        "feedback_record_hash": _text(
            feedback.get(
                "record_hash"
            )
        ),
        "feedback_integrity_status":
            feedback_integrity[
                "status"
            ],
        "bridge_id": _text(
            bridge.get(
                "bridge_id"
            )
        ),
        "bridge_record_hash": _text(
            bridge.get(
                "record_hash"
            )
        ),
        "bridge_integrity_status":
            bridge_integrity[
                "status"
            ],
        "company": company,
        "feedback_target": target,
        "change_direction": direction,
        "proposed_delta": _num(
            bridge.get(
                "proposed_delta"
            )
        ),
        "bridge_route": route,
        "source_review_type":
            source_review_type,
        "source_review_id":
            source_review_id,
        "source_review_timestamp":
            source_review_timestamp,
        "source_review_hash":
            source_review_hash,
        "source_review_integrity_status":
            source_integrity_status,
        "source_review_gate":
            source_review_gate,
        "baseline_value":
            baseline,
        "proposed_value":
            proposed,
        "source_review_value":
            source_review_value,
        "live_register_value":
            live_value,
        "proposal_outcome":
            proposal_outcome,
        "live_register_match_status":
            live_match_status,
        "closure_readiness":
            closure_readiness,
        "review_due_date": _text(
            bridge.get(
                "source_review_due_date"
            )
        ),
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def validate_feedback_closure(
    context: dict,
    *,
    closure_action: str,
    source_review_result_confirmed: bool,
    proposal_outcome_confirmed: bool,
    no_auto_carry_forward_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    ctx = context or {}
    issues = []

    if _text(
        ctx.get(
            "source_review_gate"
        )
    ).upper() != "PASS":
        issues.append(
            "SOURCE_REVIEW_CONTEXT_NOT_READY"
        )

    action = _text(
        closure_action
    ).upper()
    if action not in FEEDBACK_CLOSURE_ACTIONS:
        issues.append(
            "CLOSURE_ACTION_REQUIRED"
        )

    confirmations = {
        "SOURCE_REVIEW_RESULT_CONFIRMATION_REQUIRED":
            source_review_result_confirmed,
        "PROPOSAL_OUTCOME_CONFIRMATION_REQUIRED":
            proposal_outcome_confirmed,
        "NO_AUTO_CARRY_FORWARD_CONFIRMATION_REQUIRED":
            no_auto_carry_forward_confirmed,
        "NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED":
            no_execution_authorization_confirmed,
        "HUMAN_REVIEW_CONFIRMATION_REQUIRED":
            human_review_confirmed,
    }

    for issue, passed in confirmations.items():
        if not _bool(
            passed
        ):
            issues.append(
                issue
            )

    closure_gate = (
        "PASS"
        if not issues
        else "REVIEW"
    )

    if closure_gate != "PASS":
        closure_status = "DRAFT"
    elif action == "CLOSE_SOURCE_REVIEWED":
        closure_status = "CLOSED_SOURCE_REVIEWED"
    else:
        closure_status = "OPEN_MORE_EVIDENCE"

    return {
        "closure_gate":
            closure_gate,
        "closure_status":
            closure_status,
        "closure_action":
            action,
        "execution_authorization":
            "NONE",
        "issues":
            list(
                dict.fromkeys(
                    issues
                )
            ),
    }


def _record_payload(
    row: dict,
) -> dict:
    bool_fields = {
        "source_review_result_confirmed",
        "proposal_outcome_confirmed",
        "no_auto_carry_forward_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }
    numeric_fields = {
        "proposed_delta",
        "baseline_value",
        "proposed_value",
        "source_review_value",
        "live_register_value",
    }

    payload = {}
    for field in LEARNING_FEEDBACK_CHANGE_LINEAGE_COLS:
        if field == "record_hash":
            continue
        if field in bool_fields:
            payload[field] = bool(
                _bool(
                    row.get(
                        field
                    )
                )
            )
        elif field in numeric_fields:
            payload[field] = _stable_num(
                row.get(
                    field
                )
            )
        else:
            payload[field] = _text(
                row.get(
                    field
                )
            )
    return payload


def build_feedback_change_lineage_record(
    context: dict,
    closure_review: dict,
    *,
    source_review_result_confirmed: bool,
    proposal_outcome_confirmed: bool,
    no_auto_carry_forward_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    ctx = context or {}
    review = closure_review or {}

    now = (
        _text(
            created_at
        )
        or datetime.now()
        .astimezone()
        .isoformat()
    )

    lineage_id = (
        "LFC-"
        + pd.Timestamp(
            now
        ).strftime(
            "%Y%m%dT%H%M%S"
        )
        + "-"
        + hashlib.sha256(
            (
                _text(
                    ctx.get(
                        "feedback_id"
                    )
                )
                + "|"
                + _text(
                    ctx.get(
                        "source_review_id"
                    )
                )
                + "|"
                + _text(
                    review.get(
                        "closure_action"
                    )
                )
            ).encode(
                "utf-8"
            )
        ).hexdigest()[:8]
    )

    row = {
        "change_lineage_id":
            lineage_id,
        "created_at":
            now,
        "feedback_id":
            _text(
                ctx.get(
                    "feedback_id"
                )
            ),
        "feedback_record_hash":
            _text(
                ctx.get(
                    "feedback_record_hash"
                )
            ),
        "feedback_integrity_status":
            _text(
                ctx.get(
                    "feedback_integrity_status"
                )
            ),
        "bridge_id":
            _text(
                ctx.get(
                    "bridge_id"
                )
            ),
        "bridge_record_hash":
            _text(
                ctx.get(
                    "bridge_record_hash"
                )
            ),
        "bridge_integrity_status":
            _text(
                ctx.get(
                    "bridge_integrity_status"
                )
            ),
        "company":
            _text(
                ctx.get(
                    "company"
                )
            ),
        "feedback_target":
            _text(
                ctx.get(
                    "feedback_target"
                )
            ),
        "change_direction":
            _text(
                ctx.get(
                    "change_direction"
                )
            ),
        "proposed_delta":
            _num(
                ctx.get(
                    "proposed_delta"
                )
            ),
        "bridge_route":
            _text(
                ctx.get(
                    "bridge_route"
                )
            ),
        "source_review_type":
            _text(
                ctx.get(
                    "source_review_type"
                )
            ),
        "source_review_id":
            _text(
                ctx.get(
                    "source_review_id"
                )
            ),
        "source_review_timestamp":
            _text(
                ctx.get(
                    "source_review_timestamp"
                )
            ),
        "source_review_hash":
            _text(
                ctx.get(
                    "source_review_hash"
                )
            ),
        "source_review_integrity_status":
            _text(
                ctx.get(
                    "source_review_integrity_status"
                )
            ),
        "source_review_gate":
            _text(
                ctx.get(
                    "source_review_gate"
                )
            ),
        "baseline_value":
            _num(
                ctx.get(
                    "baseline_value"
                )
            ),
        "proposed_value":
            _num(
                ctx.get(
                    "proposed_value"
                )
            ),
        "source_review_value":
            _num(
                ctx.get(
                    "source_review_value"
                )
            ),
        "live_register_value":
            _num(
                ctx.get(
                    "live_register_value"
                )
            ),
        "proposal_outcome":
            _text(
                ctx.get(
                    "proposal_outcome"
                )
            ),
        "live_register_match_status":
            _text(
                ctx.get(
                    "live_register_match_status"
                )
            ),
        "source_review_result_confirmed":
            bool(
                source_review_result_confirmed
            ),
        "proposal_outcome_confirmed":
            bool(
                proposal_outcome_confirmed
            ),
        "no_auto_carry_forward_confirmed":
            bool(
                no_auto_carry_forward_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
        "closure_action":
            _text(
                review.get(
                    "closure_action"
                )
            ),
        "closure_gate":
            _text(
                review.get(
                    "closure_gate"
                )
            ),
        "closure_status":
            _text(
                review.get(
                    "closure_status"
                )
            ),
        "execution_authorization":
            "NONE",
        "issues":
            " | ".join(
                review.get(
                    "issues",
                    [],
                )
            ),
        "note":
            _text(
                note
            ),
        "record_hash":
            "",
    }

    row[
        "record_hash"
    ] = _hash(
        _record_payload(
            row
        )
    )
    return row


def feedback_change_lineage_integrity(
    row: dict | None,
) -> dict:
    record = row or {}
    stored = _text(
        record.get(
            "record_hash"
        )
    )
    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _record_payload(
            record
        )
    )

    return {
        "status":
            "OK"
            if stored
            == calculated
            else "MISMATCH",
        "calculated_hash":
            calculated,
    }


def latest_feedback_closure_record(
    closures: pd.DataFrame | None,
    feedback_id: str,
) -> dict:
    if closures is None or closures.empty:
        return {}
    if "feedback_id" not in closures.columns:
        return {}

    hit = closures.loc[
        closures[
            "feedback_id"
        ]
        .fillna("")
        .astype(str)
        .str.strip()
        .eq(
            _text(
                feedback_id
            )
        )
    ].copy()

    if hit.empty:
        return {}

    if "created_at" in hit.columns:
        hit["_ts"] = pd.to_datetime(
            hit[
                "created_at"
            ],
            errors="coerce",
            utc=True,
        )
        hit = hit.sort_values(
            "_ts",
            ascending=False,
            na_position="last",
        )

    return (
        hit.iloc[0]
        .drop(
            labels=[
                "_ts"
            ],
            errors="ignore",
        )
        .to_dict()
    )


def _bucket_for_due(
    due_value: Any,
    current_date: date,
) -> tuple[str, int | None]:
    parsed = pd.to_datetime(
        due_value,
        errors="coerce",
    )
    if pd.isna(parsed):
        return "NO DATE", None

    due = parsed.date()
    days = (
        due
        - current_date
    ).days

    if days < 0:
        return "OVERDUE", days
    if days == 0:
        return "TODAY", days
    if days <= 7:
        return "NEXT 7 DAYS", days
    if days <= 30:
        return "NEXT 30 DAYS", days
    return "FUTURE", days


def build_feedback_closure_queue(
    bridge_drafts: pd.DataFrame | None,
    feedback_proposals: pd.DataFrame | None,
    closures: pd.DataFrame | None,
    capital_productivity_inputs: pd.DataFrame | None,
    calibration_drafts: pd.DataFrame | None,
    revalidations: pd.DataFrame | None,
    *,
    today: date | None = None,
) -> pd.DataFrame:
    current_date = today or date.today()

    if bridge_drafts is None or bridge_drafts.empty:
        return pd.DataFrame(
            columns=
            LEARNING_FEEDBACK_CLOSURE_QUEUE_COLS
        )

    drafts = bridge_drafts.copy()
    for col in [
        "feedback_id",
        "bridge_id",
        "company",
        "feedback_target",
        "change_direction",
        "bridge_route",
        "draft_status",
        "source_review_due_date",
    ]:
        if col not in drafts.columns:
            drafts[
                col
            ] = ""

    feedbacks = (
        pd.DataFrame()
        if feedback_proposals is None
        else feedback_proposals.copy()
    )
    for col in [
        "feedback_id",
        "record_hash",
        "proposal_status",
    ]:
        if col not in feedbacks.columns:
            feedbacks[
                col
            ] = ""

    rows = []

    ready = drafts.loc[
        drafts[
            "draft_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq(
            "READY_FOR_SOURCE_REVIEW"
        )
    ].copy()

    for _, draft in ready.iterrows():
        d = draft.to_dict()
        feedback_id = _text(
            d.get(
                "feedback_id"
            )
        )

        fhit = feedbacks.loc[
            feedbacks[
                "feedback_id"
            ]
            .fillna("")
            .astype(str)
            .str.strip()
            .eq(
                feedback_id
            )
        ]
        feedback = (
            {}
            if fhit.empty
            else fhit.iloc[-1].to_dict()
        )

        latest_closure = latest_feedback_closure_record(
            closures,
            feedback_id,
        )

        if latest_closure:
            closure_integrity = feedback_change_lineage_integrity(
                latest_closure
            )
            closure_status = _text(
                latest_closure.get(
                    "closure_status"
                )
            ).upper()

            if (
                closure_integrity[
                    "status"
                ]
                == "OK"
                and closure_status
                == "CLOSED_SOURCE_REVIEWED"
            ):
                continue

        context = build_feedback_change_context(
            d,
            feedback,
            capital_productivity_inputs,
            calibration_drafts,
            revalidations,
        )

        bucket, days = _bucket_for_due(
            d.get(
                "source_review_due_date"
            ),
            current_date,
        )

        if latest_closure:
            closure_integrity = feedback_change_lineage_integrity(
                latest_closure
            )
            if closure_integrity[
                "status"
            ] != "OK":
                priority = "CL0"
                closure_status = "CLOSURE_INTEGRITY_REVIEW"
                issue = "CHANGE_LINEAGE_HASH_MISMATCH"
                next_action = "Change Lineage 무결성 확인"
            elif _text(
                latest_closure.get(
                    "closure_status"
                )
            ).upper() == "OPEN_MORE_EVIDENCE":
                priority = "CL3"
                closure_status = "OPEN_MORE_EVIDENCE"
                issue = "HUMAN_REQUESTED_MORE_EVIDENCE"
                next_action = "추가 Evidence/Source Review 후 다시 Closure 검토"
            else:
                priority = "CL2"
                closure_status = "CLOSURE_REVIEW"
                issue = "LATEST_CLOSURE_NOT_FINAL"
                next_action = "Source Review 결과와 Closure 상태 재검토"
        elif context[
            "closure_readiness"
        ] == "SOURCE_REVIEW_PENDING":
            priority = "CL1"
            closure_status = "SOURCE_REVIEW_PENDING"
            issue = "SOURCE_REVIEW_NOT_FOUND_AFTER_BRIDGE"
            next_action = (
                "Calibration/Revalidation 원본 Human Review 완료"
            )
        elif context[
            "closure_readiness"
        ] == "READY_FOR_CLOSURE":
            priority = "CL2"
            closure_status = "READY_FOR_CLOSURE"
            issue = "SOURCE_REVIEW_COMPLETE_CLOSURE_PENDING"
            next_action = "Proposal Outcome 대조 후 Feedback Closure 저장"
        else:
            priority = "CL0"
            closure_status = "SOURCE_REVIEW_REVIEW"
            issue = " | ".join(
                context[
                    "issues"
                ]
            )
            next_action = "Source Review / Live Register / Hash 일치 여부 확인"

        rows.append(
            {
                "priority":
                    priority,
                "bucket":
                    bucket,
                "due_date":
                    _text(
                        d.get(
                            "source_review_due_date"
                        )
                    ),
                "days_to_due":
                    days,
                "subject":
                    _text(
                        d.get(
                            "company"
                        )
                    ),
                "target":
                    _text(
                        d.get(
                            "feedback_target"
                        )
                    ),
                "direction":
                    _text(
                        d.get(
                            "change_direction"
                        )
                    ),
                "bridge_route":
                    _text(
                        d.get(
                            "bridge_route"
                        )
                    ),
                "source_review_status":
                    context[
                        "closure_readiness"
                    ],
                "proposal_outcome":
                    context[
                        "proposal_outcome"
                    ],
                "closure_status":
                    closure_status,
                "issue":
                    issue,
                "next_action":
                    next_action,
                "go_to":
                    "Capital Productivity",
                "feedback_id":
                    feedback_id,
                "bridge_id":
                    _text(
                        d.get(
                            "bridge_id"
                        )
                    ),
                "source_review_id":
                    context[
                        "source_review_id"
                    ],
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=
            LEARNING_FEEDBACK_CLOSURE_QUEUE_COLS
        )

    out = pd.DataFrame(
        rows
    )

    priority_order = {
        "CL0": 0,
        "CL1": 1,
        "CL2": 2,
        "CL3": 3,
    }
    bucket_order = {
        "OVERDUE": 0,
        "TODAY": 1,
        "NEXT 7 DAYS": 2,
        "NEXT 30 DAYS": 3,
        "FUTURE": 4,
        "NO DATE": 5,
    }

    out["_p"] = out[
        "priority"
    ].map(
        priority_order
    ).fillna(
        9
    )
    out["_b"] = out[
        "bucket"
    ].map(
        bucket_order
    ).fillna(
        9
    )

    out = out.sort_values(
        [
            "_p",
            "_b",
            "due_date",
            "subject",
        ],
        ascending=[
            True,
            True,
            True,
            True,
        ],
        na_position="last",
    ).drop(
        columns=[
            "_p",
            "_b",
        ]
    )

    return out[
        LEARNING_FEEDBACK_CLOSURE_QUEUE_COLS
    ].reset_index(
        drop=True
    )


def feedback_closure_queue_summary(
    queue: pd.DataFrame | None,
) -> dict:
    if queue is None or queue.empty:
        return {
            "total": 0,
            "integrity": 0,
            "source_pending": 0,
            "closure_ready": 0,
            "more_evidence": 0,
            "overdue": 0,
        }

    status = (
        queue[
            "closure_status"
        ]
        .fillna("")
        .astype(str)
        .str.upper()
    )

    return {
        "total":
            int(
                len(
                    queue
                )
            ),
        "integrity":
            int(
                status.isin(
                    [
                        "CLOSURE_INTEGRITY_REVIEW",
                        "SOURCE_REVIEW_REVIEW",
                    ]
                ).sum()
            ),
        "source_pending":
            int(
                status.eq(
                    "SOURCE_REVIEW_PENDING"
                ).sum()
            ),
        "closure_ready":
            int(
                status.eq(
                    "READY_FOR_CLOSURE"
                ).sum()
            ),
        "more_evidence":
            int(
                status.eq(
                    "OPEN_MORE_EVIDENCE"
                ).sum()
            ),
        "overdue":
            int(
                queue[
                    "bucket"
                ]
                .fillna("")
                .astype(str)
                .eq(
                    "OVERDUE"
                ).sum()
            ),
    }
