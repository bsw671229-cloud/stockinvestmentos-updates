from __future__ import annotations

from datetime import date, datetime
from typing import Any
import hashlib
import json
import pandas as pd

from engine.forecast_change_registry import forecast_change_plan_integrity
from engine.forecast_change_implementation import (
    forecast_implementation_integrity,
    latest_forecast_implementation,
    build_before_after_cohort,
)

EFFECT_CLASSIFICATIONS = [
    "LOWER_ERROR_SHARE_OBSERVED",
    "SAME_ERROR_SHARE_OBSERVED",
    "HIGHER_ERROR_SHARE_OBSERVED",
    "INCONCLUSIVE",
]
EFFECT_REVIEW_ACTIONS = [
    "CLOSE_PROOF_REVIEW",
    "KEEP_OPEN_MORE_EVIDENCE",
]
FORECAST_EFFECT_REVIEW_COLS = [
    "effect_review_id","created_at","change_plan_id","change_plan_record_hash",
    "implementation_id","implementation_record_hash","company","forecast_error_class",
    "change_area","proof_date","baseline_sample_size","baseline_error_count",
    "baseline_error_share","post_sample_size","post_error_count","post_error_share",
    "error_share_delta","computed_comparison","proof_snapshot_hash",
    "effect_classification","effect_interpretation","alternative_explanations",
    "second_order_learning","next_review_action","review_action",
    "proof_snapshot_confirmed","no_causal_overclaim_confirmed",
    "no_auto_carry_forward_confirmed","no_execution_authorization_confirmed",
    "human_review_confirmed","review_gate","review_status",
    "execution_authorization","issues","note","record_hash",
]
FORECAST_EFFECT_QUEUE_COLS = [
    "priority","company","forecast_error_class","change_area","proof_date",
    "comparison","baseline_error_share","post_error_share","error_share_delta",
    "effect_review_status","effect_classification","issue","next_action",
    "change_plan_id","implementation_id","effect_review_id",
]

def _text(v: Any) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except Exception:
        pass
    return str(v).strip()

def _num(v: Any):
    if v is None or v == "":
        return None
    try:
        x = float(v)
    except Exception:
        return None
    return None if pd.isna(x) else x

def _bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    return _text(v).upper() in {"TRUE","1","YES","Y","PASS"}

def _hash(payload: Any) -> str:
    s = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",",":"), default=str)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def _stable(v: Any):
    x = _num(v)
    return None if x is None else f"{x:.12f}"

def expected_effect_classification(comparison: str) -> str:
    return {
        "LOWER_ERROR_SHARE":"LOWER_ERROR_SHARE_OBSERVED",
        "SAME_ERROR_SHARE":"SAME_ERROR_SHARE_OBSERVED",
        "HIGHER_ERROR_SHARE":"HIGHER_ERROR_SHARE_OBSERVED",
    }.get(_text(comparison).upper(), "INCONCLUSIVE")

def proof_snapshot_hash(plan: dict, event: dict, ba: dict) -> str:
    payload = {
        "plan_id":_text(plan.get("change_plan_id")),
        "plan_hash":_text(plan.get("record_hash")),
        "implementation_id":_text(event.get("implementation_id")),
        "implementation_hash":_text(event.get("record_hash")),
        "status":_text(ba.get("before_after_status")),
        "baseline_n":int(_num(ba.get("baseline_sample_size")) or 0),
        "baseline_errors":int(_num(ba.get("baseline_error_count")) or 0),
        "baseline_share":_stable(ba.get("baseline_error_share")),
        "post_n":int(_num(ba.get("post_sample_size")) or 0),
        "post_errors":int(_num(ba.get("post_error_count")) or 0),
        "post_share":_stable(ba.get("post_error_share")),
        "delta":_stable(ba.get("error_share_delta")),
        "comparison":_text(ba.get("comparison")),
        "proof_date_reached":bool(ba.get("proof_date_reached",False)),
    }
    return _hash(payload)

def validate_forecast_effect_review(
    plan_row: dict|None,
    implementation_row: dict|None,
    before_after: dict|None,
    *,
    effect_classification: str,
    effect_interpretation: str,
    alternative_explanations: str,
    second_order_learning: str,
    next_review_action: str,
    review_action: str,
    proof_snapshot_confirmed: bool,
    no_causal_overclaim_confirmed: bool,
    no_auto_carry_forward_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
) -> dict:
    plan, event, ba = plan_row or {}, implementation_row or {}, before_after or {}
    issues = []
    if forecast_change_plan_integrity(plan)["status"] != "OK":
        issues.append("CHANGE_PLAN_INTEGRITY_FAILED")
    if forecast_implementation_integrity(event)["status"] != "OK":
        issues.append("IMPLEMENTATION_EVENT_INTEGRITY_FAILED")
    if _text(event.get("implementation_status")).upper() != "IMPLEMENTED_BASELINE_LOCKED":
        issues.append("IMPLEMENTED_BASELINE_LOCKED_REQUIRED")
    if _text(ba.get("before_after_status")).upper() != "PROOF_READY":
        issues.append("BEFORE_AFTER_PROOF_READY_REQUIRED")
    if _text(event.get("execution_authorization")).upper() != "NONE":
        issues.append("EXECUTION_AUTHORIZATION_MUST_REMAIN_NONE")

    chosen = _text(effect_classification).upper()
    if chosen not in EFFECT_CLASSIFICATIONS:
        issues.append("EFFECT_CLASSIFICATION_REQUIRED")
    elif chosen != "INCONCLUSIVE" and chosen != expected_effect_classification(ba.get("comparison")):
        issues.append("EFFECT_CLASSIFICATION_COMPARISON_MISMATCH")

    for value, issue in [
        (effect_interpretation,"EFFECT_INTERPRETATION_REQUIRED"),
        (alternative_explanations,"ALTERNATIVE_EXPLANATIONS_REQUIRED"),
        (second_order_learning,"SECOND_ORDER_LEARNING_REQUIRED"),
        (next_review_action,"NEXT_REVIEW_ACTION_REQUIRED"),
    ]:
        if not _text(value):
            issues.append(issue)

    action = _text(review_action).upper()
    if action not in EFFECT_REVIEW_ACTIONS:
        issues.append("REVIEW_ACTION_REQUIRED")

    for passed, issue in [
        (proof_snapshot_confirmed,"PROOF_SNAPSHOT_CONFIRMATION_REQUIRED"),
        (no_causal_overclaim_confirmed,"NO_CAUSAL_OVERCLAIM_CONFIRMATION_REQUIRED"),
        (no_auto_carry_forward_confirmed,"NO_AUTO_CARRY_FORWARD_CONFIRMATION_REQUIRED"),
        (no_execution_authorization_confirmed,"NO_EXECUTION_AUTHORIZATION_CONFIRMATION_REQUIRED"),
        (human_review_confirmed,"HUMAN_REVIEW_CONFIRMATION_REQUIRED"),
    ]:
        if not _bool(passed):
            issues.append(issue)

    gate = "PASS" if not issues else "REVIEW"
    status = "DRAFT"
    if gate == "PASS":
        status = "CLOSED_EFFECT_REVIEW" if action == "CLOSE_PROOF_REVIEW" else "OPEN_MORE_EVIDENCE"
    return {
        "review_gate":gate,
        "review_status":status,
        "execution_authorization":"NONE",
        "issues":list(dict.fromkeys(issues)),
    }

def _record_payload(row: dict) -> dict:
    out = {}
    bools = {
        "proof_snapshot_confirmed","no_causal_overclaim_confirmed",
        "no_auto_carry_forward_confirmed","no_execution_authorization_confirmed",
        "human_review_confirmed",
    }
    nums = {"baseline_error_share","post_error_share","error_share_delta"}
    for col in FORECAST_EFFECT_REVIEW_COLS:
        if col == "record_hash":
            continue
        if col in bools:
            out[col] = bool(_bool(row.get(col)))
        elif col in nums:
            out[col] = _stable(row.get(col))
        else:
            out[col] = _text(row.get(col))
    return out

def build_forecast_effect_review_record(
    plan_row: dict,
    implementation_row: dict,
    before_after: dict,
    validation: dict,
    *,
    effect_classification: str,
    effect_interpretation: str,
    alternative_explanations: str,
    second_order_learning: str,
    next_review_action: str,
    review_action: str,
    proof_snapshot_confirmed: bool,
    no_causal_overclaim_confirmed: bool,
    no_auto_carry_forward_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str|None = None,
) -> dict:
    plan, event, ba, rv = plan_row or {}, implementation_row or {}, before_after or {}, validation or {}
    now = _text(created_at) or datetime.now().astimezone().isoformat()
    proof_hash = proof_snapshot_hash(plan,event,ba)
    rid = "FCE-" + pd.Timestamp(now).strftime("%Y%m%dT%H%M%S") + "-" + proof_hash[:8]
    row = {
        "effect_review_id":rid,
        "created_at":now,
        "change_plan_id":_text(plan.get("change_plan_id")),
        "change_plan_record_hash":_text(plan.get("record_hash")),
        "implementation_id":_text(event.get("implementation_id")),
        "implementation_record_hash":_text(event.get("record_hash")),
        "company":_text(plan.get("company")),
        "forecast_error_class":_text(plan.get("forecast_error_class")),
        "change_area":_text(plan.get("change_area")),
        "proof_date":_text(plan.get("proof_date")),
        "baseline_sample_size":int(_num(ba.get("baseline_sample_size")) or 0),
        "baseline_error_count":int(_num(ba.get("baseline_error_count")) or 0),
        "baseline_error_share":float(_num(ba.get("baseline_error_share")) or 0),
        "post_sample_size":int(_num(ba.get("post_sample_size")) or 0),
        "post_error_count":int(_num(ba.get("post_error_count")) or 0),
        "post_error_share":_num(ba.get("post_error_share")),
        "error_share_delta":_num(ba.get("error_share_delta")),
        "computed_comparison":_text(ba.get("comparison")),
        "proof_snapshot_hash":proof_hash,
        "effect_classification":_text(effect_classification).upper(),
        "effect_interpretation":_text(effect_interpretation),
        "alternative_explanations":_text(alternative_explanations),
        "second_order_learning":_text(second_order_learning),
        "next_review_action":_text(next_review_action),
        "review_action":_text(review_action).upper(),
        "proof_snapshot_confirmed":bool(proof_snapshot_confirmed),
        "no_causal_overclaim_confirmed":bool(no_causal_overclaim_confirmed),
        "no_auto_carry_forward_confirmed":bool(no_auto_carry_forward_confirmed),
        "no_execution_authorization_confirmed":bool(no_execution_authorization_confirmed),
        "human_review_confirmed":bool(human_review_confirmed),
        "review_gate":_text(rv.get("review_gate")),
        "review_status":_text(rv.get("review_status")),
        "execution_authorization":"NONE",
        "issues":" | ".join(rv.get("issues",[])),
        "note":_text(note),
        "record_hash":"",
    }
    row["record_hash"] = _hash(_record_payload(row))
    return row

def forecast_effect_review_integrity(row: dict|None) -> dict:
    record = row or {}
    stored = _text(record.get("record_hash"))
    if not stored:
        return {"status":"MISSING","calculated_hash":""}
    calc = _hash(_record_payload(record))
    return {"status":"OK" if stored == calc else "MISMATCH","calculated_hash":calc}

def latest_forecast_effect_review(reviews: pd.DataFrame|None, change_plan_id: str) -> dict:
    if reviews is None or reviews.empty or "change_plan_id" not in reviews.columns:
        return {}
    hit = reviews.loc[
        reviews["change_plan_id"].fillna("").astype(str).str.strip().eq(_text(change_plan_id))
    ].copy()
    if hit.empty:
        return {}
    if "created_at" in hit.columns:
        hit["_ts"] = pd.to_datetime(hit["created_at"],errors="coerce",utc=True)
        hit = hit.sort_values("_ts",ascending=False,na_position="last")
    return hit.iloc[0].drop(labels=["_ts"],errors="ignore").to_dict()

def build_forecast_effect_queue(
    plans: pd.DataFrame|None,
    events: pd.DataFrame|None,
    reviews: pd.DataFrame|None,
    learning_lineages: pd.DataFrame|None,
    *,
    min_post_samples: int = 3,
    today: date|None = None,
) -> pd.DataFrame:
    current_date = today or date.today()
    if plans is None or plans.empty:
        return pd.DataFrame(columns=FORECAST_EFFECT_QUEUE_COLS)

    rows = []
    p = plans.copy()
    for col in ["change_plan_id","company","forecast_error_class","change_area","proof_date","plan_status","record_hash"]:
        if col not in p.columns:
            p[col] = ""

    p = p.loc[
        p["plan_status"].fillna("").astype(str).str.upper().eq("REGISTERED_FOR_IMPLEMENTATION_REVIEW")
    ]

    for _, r in p.iterrows():
        plan = r.to_dict()
        pid = _text(plan.get("change_plan_id"))
        if forecast_change_plan_integrity(plan)["status"] != "OK":
            rows.append({
                "priority":"FE0","company":_text(plan.get("company")),
                "forecast_error_class":_text(plan.get("forecast_error_class")),
                "change_area":_text(plan.get("change_area")),"proof_date":_text(plan.get("proof_date")),
                "comparison":"NOT_EVALUABLE","baseline_error_share":_num(plan.get("source_error_share")),
                "post_error_share":None,"error_share_delta":None,
                "effect_review_status":"INTEGRITY_REVIEW","effect_classification":"",
                "issue":"FORECAST_CHANGE_PLAN_HASH_MISMATCH","next_action":"Change Plan Hash 무결성 확인",
                "change_plan_id":pid,"implementation_id":"","effect_review_id":"",
            })
            continue

        event = latest_forecast_implementation(events,pid)
        if not event or _text(event.get("implementation_status")).upper() != "IMPLEMENTED_BASELINE_LOCKED":
            continue
        if forecast_implementation_integrity(event)["status"] != "OK":
            rows.append({
                "priority":"FE0","company":_text(plan.get("company")),
                "forecast_error_class":_text(plan.get("forecast_error_class")),
                "change_area":_text(plan.get("change_area")),"proof_date":_text(plan.get("proof_date")),
                "comparison":"NOT_EVALUABLE","baseline_error_share":_num(event.get("baseline_error_share")),
                "post_error_share":None,"error_share_delta":None,
                "effect_review_status":"INTEGRITY_REVIEW","effect_classification":"",
                "issue":"IMPLEMENTATION_EVENT_HASH_MISMATCH","next_action":"Implementation Event Hash 무결성 확인",
                "change_plan_id":pid,"implementation_id":_text(event.get("implementation_id")),"effect_review_id":"",
            })
            continue

        ba = build_before_after_cohort(
            plan,event,learning_lineages,min_post_samples=min_post_samples,today=current_date
        )
        if _text(ba.get("before_after_status")).upper() != "PROOF_READY":
            continue

        latest = latest_forecast_effect_review(reviews,pid)
        if latest:
            integ = forecast_effect_review_integrity(latest)["status"]
            status = _text(latest.get("review_status")).upper()
            if integ != "OK":
                priority, qstatus, issue, action = "FE0","INTEGRITY_REVIEW","EFFECT_REVIEW_HASH_MISMATCH","Effect Review Hash 무결성 확인"
            elif status == "CLOSED_EFFECT_REVIEW":
                continue
            elif status == "OPEN_MORE_EVIDENCE":
                priority, qstatus, issue, action = "FE2","OPEN_MORE_EVIDENCE","HUMAN_REQUESTED_MORE_EVIDENCE","추가 Outcome / Learning evidence 축적 후 재검토"
            else:
                priority, qstatus, issue, action = "FE1","EFFECT_REVIEW_PENDING","LATEST_EFFECT_REVIEW_NOT_FINAL","Effect Review 상태 재검토"
            cls = _text(latest.get("effect_classification"))
            rid = _text(latest.get("effect_review_id"))
        else:
            priority, qstatus, issue, action = "FE1","EFFECT_REVIEW_PENDING","PROOF_READY_EFFECT_REVIEW_NOT_RECORDED","Proof Review와 Second-order Learning 기록"
            cls, rid = "", ""

        rows.append({
            "priority":priority,"company":_text(plan.get("company")),
            "forecast_error_class":_text(plan.get("forecast_error_class")),
            "change_area":_text(plan.get("change_area")),"proof_date":_text(plan.get("proof_date")),
            "comparison":_text(ba.get("comparison")),
            "baseline_error_share":ba.get("baseline_error_share"),
            "post_error_share":ba.get("post_error_share"),
            "error_share_delta":ba.get("error_share_delta"),
            "effect_review_status":qstatus,"effect_classification":cls,
            "issue":issue,"next_action":action,"change_plan_id":pid,
            "implementation_id":_text(event.get("implementation_id")),"effect_review_id":rid,
        })

    if not rows:
        return pd.DataFrame(columns=FORECAST_EFFECT_QUEUE_COLS)

    out = pd.DataFrame(rows)
    order = {"FE0":0,"FE1":1,"FE2":2}
    out["_p"] = out["priority"].map(order).fillna(9)
    out = out.sort_values(["_p","company","forecast_error_class","proof_date"]).drop(columns=["_p"])
    return out[FORECAST_EFFECT_QUEUE_COLS].reset_index(drop=True)
