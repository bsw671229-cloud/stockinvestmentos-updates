from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import re

import pandas as pd

from updater.trusted_release_operations import (
    trusted_release_operations_status,
)


V1541_RELEASE_ZIP_SHA256 = (
    "de94e49285de03db230838a9445a4be404227f26e0f30f96ad79ab8f4f67cc80"
)
V1541_RELEASE_MANIFEST_FILE_SHA256 = (
    "ce6ad08140de039120cf2e00840153a94e5537d478da2109fd4153c4286991d6"
)
V1541_RELEASE_NOTES_FILE_SHA256 = (
    "05a599502aaf4fd998fa46a69373763f25f5e329cfbe5b15b970e9e73674c770"
)
V1541_BASELINE_PROVENANCE_REL = "release_baselines/v1_54_1.json"

V155_OPERATIONS_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V155_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b"",
        ):
            h.update(chunk)
    return h.hexdigest()


def _is_sha256(value: Any) -> bool:
    return bool(
        re.fullmatch(
            r"[0-9a-fA-F]{64}",
            _text(value),
        )
    )


def verify_v1541_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(code_root).resolve()
    provenance_path = root / V1541_BASELINE_PROVENANCE_REL

    record = {}
    record_ok = False
    detail = ""

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            detail = f"{type(exc).__name__}: {exc}"
        else:
            record_ok = (
                _text(record.get("release_version"))
                == "v1.54.1"
                and _text(
                    record.get("release_zip_sha256")
                ).lower()
                == V1541_RELEASE_ZIP_SHA256
                and _text(
                    record.get("manifest_file_sha256")
                ).lower()
                == V1541_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get("release_notes_file_sha256")
                ).lower()
                == V1541_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get("provenance_status")
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )
            detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    return {
        "status": "VERIFIED" if record_ok else "BLOCKED",
        "verified": record_ok,
        "source": "PROVENANCE_RECORD" if record_ok else "NONE",
        "record_path": str(provenance_path),
        "record_detail": detail,
        "release_version": "v1.54.1",
        "release_zip_sha256": V1541_RELEASE_ZIP_SHA256,
        "manifest_file_sha256": V1541_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256": V1541_RELEASE_NOTES_FILE_SHA256,
    }


def build_v155_trusted_release_operations_context(
    code_root: str | Path,
) -> dict:
    root = Path(code_root).resolve()
    operations = trusted_release_operations_status(
        root
    )
    return {
        "root": str(root),
        "operations": operations,
        "execution_authorization": "NONE",
    }


def build_v155_trusted_release_operations_technical_gate(
    context: dict,
) -> dict:
    operations = context.get("operations") or {}
    checks = pd.DataFrame(
        operations.get("checks") or [],
        columns=V155_OPERATIONS_CHECK_COLS,
    )

    technical = (
        checks.loc[
            checks["layer"].astype(str).str.upper().eq(
                "TECHNICAL"
            )
        ].copy()
        if not checks.empty
        else pd.DataFrame(
            columns=V155_OPERATIONS_CHECK_COLS
        )
    )

    technical_pass = int(
        technical["status"]
        .astype(str)
        .str.upper()
        .eq("PASS")
        .sum()
    ) if not technical.empty else 0

    technical_review = int(
        technical["status"]
        .astype(str)
        .str.upper()
        .eq("REVIEW")
        .sum()
    ) if not technical.empty else 0

    technical_fail = int(
        technical["status"]
        .astype(str)
        .str.upper()
        .eq("FAIL")
        .sum()
    ) if not technical.empty else 0

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": technical_pass,
        "technical_review": technical_review,
        "technical_fail": technical_fail,
        "operating_status": operations.get(
            "operating_status",
            "REVIEW",
        ),
        "feed_state_status": operations.get(
            "feed_state_status",
            "-",
        ),
        "published_version": operations.get(
            "published_version",
            "-",
        ),
        "checks": technical,
        "execution_authorization": "NONE",
    }


def build_v155_trusted_release_operations_audit_gate(
    context: dict,
) -> dict:
    operations = context.get("operations") or {}

    rows = []

    local_sha = _text(
        operations.get("local_feed_sha256")
    )
    public_sha = _text(
        operations.get(
            "last_verified_public_feed_sha256"
        )
    )

    sha_evidence_ok = (
        _is_sha256(local_sha)
        and _is_sha256(public_sha)
        and local_sha.lower() == public_sha.lower()
    )

    rows.append({
        "layer": "TECHNICAL",
        "check": "Local / Public Feed SHA Evidence",
        "status": "PASS" if sha_evidence_ok else "REVIEW",
        "detail": (
            f"local={local_sha or 'NONE'} · "
            f"public={public_sha or 'NONE'}"
        ),
        "action": (
            ""
            if sha_evidence_ok
            else "Run Live Public Feed + Client Re-check."
        ),
    })

    url = _text(
        operations.get("client_feed_url")
    )
    https_ok = url.lower().startswith(
        "https://"
    )
    rows.append({
        "layer": "TECHNICAL",
        "check": "Client Feed HTTPS Evidence",
        "status": "PASS" if https_ok else "FAIL",
        "detail": url or "NONE",
        "action": (
            ""
            if https_ok
            else "Trusted Feed must use HTTPS in production."
        ),
    })

    auth_ok = _text(
        operations.get(
            "execution_authorization",
            "NONE",
        )
    ).upper() == "NONE"
    rows.append({
        "layer": "TECHNICAL",
        "check": "Execution Authorization Boundary",
        "status": "PASS" if auth_ok else "FAIL",
        "detail": (
            f"execution_authorization="
            f"{operations.get('execution_authorization','NONE')}"
        ),
        "action": (
            ""
            if auth_ok
            else "Investment execution authorization must remain NONE."
        ),
    })

    checks = pd.DataFrame(
        rows,
        columns=V155_OPERATIONS_CHECK_COLS,
    )

    fail = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("FAIL")
        .sum()
    )
    review = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("REVIEW")
        .sum()
    )
    passed = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("PASS")
        .sum()
    )

    return {
        "release_gate": "PASS" if fail == 0 else "BLOCKED",
        "technical_pass": passed,
        "technical_review": review,
        "technical_fail": fail,
        "operating_status": (
            "PASS" if review == 0 else "REVIEW"
        ),
        "checks": checks,
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
    *,
    blocking: bool = True,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else (
            "BLOCKED" if blocking else "REVIEW"
        ),
        "detail": detail,
        "blocking": bool(
            blocking and not passed
        ),
    }


def build_v155_release_readiness(
    *,
    v154_release_status: str,
    v1541_baseline_provenance: dict,
    operations_release_gate: str,
    operations_audit_gate: str,
    operations_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str = "NONE",
) -> dict:
    rows = []

    rows.append(
        _candidate_row(
            "v1.54 Updater2 predecessor gate",
            _text(v154_release_status)
            == "READY_FOR_RELEASE_REVIEW",
            _text(v154_release_status) or "MISSING",
        )
    )

    baseline_ok = (
        (v1541_baseline_provenance or {}).get(
            "status"
        )
        == "VERIFIED"
    )
    rows.append(
        _candidate_row(
            "v1.54.1 immutable release baseline",
            baseline_ok,
            (
                (v1541_baseline_provenance or {}).get(
                    "record_detail"
                )
                or "MISSING"
            ),
        )
    )

    rows.append(
        _candidate_row(
            "Trusted Release Operations Technical Gate",
            _text(operations_release_gate)
            == "PASS",
            _text(operations_release_gate) or "MISSING",
        )
    )

    rows.append(
        _candidate_row(
            "Trusted Release Operations Audit Gate",
            _text(operations_audit_gate)
            == "PASS",
            _text(operations_audit_gate) or "MISSING",
        )
    )

    auth_ok = _text(
        execution_authorization
    ).upper() == "NONE"
    rows.append(
        _candidate_row(
            "Execution Authorization",
            auth_ok,
            _text(execution_authorization) or "MISSING",
        )
    )

    operations_review = (
        _text(operations_operating_status).upper()
        != "PASS"
    )
    rows.append({
        "check": "Operations Operating State",
        "status": (
            "REVIEW"
            if operations_review
            else "PASS"
        ),
        "detail": (
            _text(operations_operating_status)
            or "MISSING"
        ),
        "blocking": False,
    })

    audit_review = (
        _text(audit_operating_status).upper()
        != "PASS"
    )
    rows.append({
        "check": "Operations Audit Evidence Freshness",
        "status": (
            "REVIEW"
            if audit_review
            else "PASS"
        ),
        "detail": (
            _text(audit_operating_status)
            or "MISSING"
        ),
        "blocking": False,
    })

    checks = pd.DataFrame(
        rows,
        columns=V155_CANDIDATE_CHECK_COLS,
    )

    blocking = checks.loc[
        checks["blocking"].eq(True)
    ]

    blockers = [
        f"{row['check']}: {row['detail']}"
        for _, row in blocking.iterrows()
    ]

    operating_review_count = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("REVIEW")
        .sum()
    )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "operating_review_count": operating_review_count,
        "blockers": blockers,
        "checks": checks,
        "execution_authorization": "NONE",
    }
