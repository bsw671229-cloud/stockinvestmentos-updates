from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    flow_projection_snapshot_integrity,
)
from engine.operations_flow_projection_review import (
    FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    flow_projection_review_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)
from engine.operations_flow_projection_outcome_evidence import (
    FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS,
    flow_projection_outcome_evidence_snapshot_integrity,
)


FLOW_SCORECARD_INPUT_SNAPSHOT_COLS = [
    "scorecard_input_snapshot_id",
    "created_at",
    "qualification_state",
    "scorecard_guard",
    "source_projection_snapshot_id",
    "outcome_records_total",
    "valid_outcome_records",
    "invalid_outcome_records",
    "ready_evidence_audits",
    "qualified_outcomes",
    "unqualified_outcomes",
    "duplicate_outcomes",
    "lineage_mismatch_count",
    "time_order_mismatch_count",
    "latest_qualified_outcome_id",
    "latest_qualified_outcome_hash",
    "latest_qualified_endpoint_id",
    "latest_evidence_audit_id",
    "latest_evidence_audit_hash",
    "latest_review_snapshot_id",
    "latest_review_snapshot_hash",
    "latest_projection_snapshot_id",
    "latest_projection_snapshot_hash",
    "projection_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


SCORECARD_INPUT_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).upper() in {"TRUE", "1", "YES", "Y", "T"}


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _safe_json_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(x) for x in value]
    raw = _text(value)
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
    except Exception:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(x) for x in parsed]


def _normalize(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    if "created_at" in out.columns:
        out["_ts"] = pd.to_datetime(
            out["created_at"],
            errors="coerce",
            utc=True,
        )
    return out


def _valid_records(
    df: pd.DataFrame,
    integrity_fn,
) -> dict:
    if df.empty:
        return {
            "valid": df.copy(),
            "invalid": df.copy(),
        }

    valid_rows = []
    invalid_rows = []

    for _, row in df.iterrows():
        record = row.drop(labels=["_ts"], errors="ignore").to_dict()
        status = _text(
            integrity_fn(record).get("status")
        ).upper()
        if status == "OK":
            valid_rows.append(record)
        else:
            invalid_rows.append(record)

    valid = pd.DataFrame(
        valid_rows,
        columns=[
            c for c in df.columns
            if c != "_ts"
        ],
    )
    invalid = pd.DataFrame(
        invalid_rows,
        columns=[
            c for c in df.columns
            if c != "_ts"
        ],
    )

    for frame in [valid, invalid]:
        if not frame.empty:
            frame["_ts"] = pd.to_datetime(
                frame["created_at"],
                errors="coerce",
                utc=True,
            )
            frame.dropna(
                subset=["_ts"],
                inplace=True,
            )
            frame.sort_values(
                "_ts",
                inplace=True,
            )
            frame.reset_index(
                drop=True,
                inplace=True,
            )

    return {
        "valid": valid,
        "invalid": invalid,
    }


def _review_contract_complete(
    row: dict,
) -> bool:
    if _text(row.get("review_state")).upper() != "PROJECTION_REVIEW_LOCKED":
        return False

    confirmations = [
        "source_lineage_confirmed",
        "scenario_semantics_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    ]

    return all(
        _bool(row.get(field))
        for field in confirmations
    )


def _ready_evidence_audits(
    evidence_df: pd.DataFrame,
    review_df: pd.DataFrame,
    projection_df: pd.DataFrame,
) -> dict:
    evidence_checked = _valid_records(
        evidence_df,
        flow_projection_outcome_evidence_snapshot_integrity,
    )
    review_checked = _valid_records(
        review_df,
        flow_projection_review_snapshot_integrity,
    )
    projection_checked = _valid_records(
        projection_df,
        flow_projection_snapshot_integrity,
    )

    review_index = {}
    for _, row in review_checked["valid"].iterrows():
        item = row.drop(labels=["_ts"], errors="ignore").to_dict()
        rid = _text(item.get("review_snapshot_id"))
        if rid:
            review_index[rid] = item

    projection_index = {}
    for _, row in projection_checked["valid"].iterrows():
        item = row.drop(labels=["_ts"], errors="ignore").to_dict()
        pid = _text(item.get("projection_snapshot_id"))
        if pid:
            projection_index[pid] = item

    ready_rows = []
    lineage_mismatch = 0

    for _, row in evidence_checked["valid"].iterrows():
        item = row.drop(labels=["_ts"], errors="ignore").to_dict()

        if (
            _text(item.get("window_state")).upper()
            != "OUTCOME_EVIDENCE_READY"
            or _text(item.get("tracking_guard")).upper()
            != "ALLOW_OUTCOME_TRACKING"
        ):
            continue

        review_id = _text(
            item.get("review_snapshot_id")
        )
        review_hash = _text(
            item.get("review_snapshot_hash")
        )
        projection_id = _text(
            item.get("source_projection_snapshot_id")
        )
        projection_hash = _text(
            item.get("source_projection_hash")
        )

        review = review_index.get(review_id)
        projection = projection_index.get(projection_id)

        if review is None or projection is None:
            lineage_mismatch += 1
            continue

        if (
            _text(review.get("snapshot_hash"))
            != review_hash
            or not _review_contract_complete(review)
            or _text(
                review.get("source_projection_snapshot_id")
            )
            != projection_id
            or _text(
                review.get("source_projection_hash")
            )
            != projection_hash
            or _text(
                projection.get("snapshot_hash")
            )
            != projection_hash
            or _text(
                projection.get("projection_state")
            ).upper()
            != "READY_FOR_REVIEW"
        ):
            lineage_mismatch += 1
            continue

        item["_endpoint_ids"] = _safe_json_list(
            item.get("endpoint_ids_json")
        )
        item["_endpoint_hashes"] = _safe_json_list(
            item.get("endpoint_hashes_json")
        )
        item["_review"] = review
        item["_projection"] = projection
        ready_rows.append(item)

    ready = pd.DataFrame(ready_rows)
    if not ready.empty:
        ready["_ts"] = pd.to_datetime(
            ready["created_at"],
            errors="coerce",
            utc=True,
        )
        ready = (
            ready.loc[
                ready["_ts"].notna()
            ]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    return {
        "ready": ready,
        "invalid_evidence_audits":
            int(len(evidence_checked["invalid"])),
        "invalid_reviews":
            int(len(review_checked["invalid"])),
        "invalid_projections":
            int(len(projection_checked["invalid"])),
        "lineage_mismatch_count":
            lineage_mismatch,
    }


def build_flow_scorecard_input_qualification(
    outcome_snapshots: pd.DataFrame | None,
    outcome_evidence_snapshots: pd.DataFrame | None,
    review_snapshots: pd.DataFrame | None,
    projection_snapshots: pd.DataFrame | None,
) -> dict:
    outcome_df = _normalize(
        outcome_snapshots,
        FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    )
    evidence_df = _normalize(
        outcome_evidence_snapshots,
        FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS,
    )
    review_df = _normalize(
        review_snapshots,
        FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    )
    projection_df = _normalize(
        projection_snapshots,
        FLOW_PROJECTION_SNAPSHOT_COLS,
    )

    outcome_checked = _valid_records(
        outcome_df,
        flow_projection_outcome_snapshot_integrity,
    )
    valid_outcomes = outcome_checked["valid"]
    invalid_outcomes = outcome_checked["invalid"]

    audit = _ready_evidence_audits(
        evidence_df,
        review_df,
        projection_df,
    )
    ready_audits = audit["ready"]

    qualification_rows = []
    unqualified_count = 0
    lineage_mismatch_count = _int(
        audit.get("lineage_mismatch_count")
    )
    time_order_mismatch_count = 0

    if not valid_outcomes.empty:
        for _, row in valid_outcomes.iterrows():
            outcome = row.drop(
                labels=["_ts"],
                errors="ignore",
            ).to_dict()

            outcome_created = pd.to_datetime(
                outcome.get("created_at"),
                errors="coerce",
                utc=True,
            )
            source_id = _text(
                outcome.get("source_projection_snapshot_id")
            )
            source_hash = _text(
                outcome.get("source_projection_hash")
            )
            endpoint_id = _text(
                outcome.get("evidence_end_trend_snapshot_id")
            )
            endpoint_hash = _text(
                outcome.get("evidence_end_trend_hash")
            )

            candidates = []
            if not ready_audits.empty:
                for _, audit_row in ready_audits.iterrows():
                    evidence = audit_row.to_dict()

                    if (
                        _text(
                            evidence.get(
                                "source_projection_snapshot_id"
                            )
                        )
                        != source_id
                        or _text(
                            evidence.get(
                                "source_projection_hash"
                            )
                        )
                        != source_hash
                    ):
                        continue

                    endpoint_ids = list(
                        evidence.get(
                            "_endpoint_ids",
                            [],
                        )
                    )
                    endpoint_hashes = list(
                        evidence.get(
                            "_endpoint_hashes",
                            [],
                        )
                    )

                    endpoint_pairs = set(
                        zip(
                            endpoint_ids,
                            endpoint_hashes,
                        )
                    )
                    if (
                        endpoint_id,
                        endpoint_hash,
                    ) not in endpoint_pairs:
                        continue

                    evidence_created = pd.to_datetime(
                        evidence.get("created_at"),
                        errors="coerce",
                        utc=True,
                    )
                    if (
                        pd.isna(outcome_created)
                        or pd.isna(evidence_created)
                        or evidence_created > outcome_created
                    ):
                        time_order_mismatch_count += 1
                        continue

                    candidates.append(
                        evidence
                    )

            if not candidates:
                unqualified_count += 1
                continue

            candidates = sorted(
                candidates,
                key=lambda x: pd.to_datetime(
                    x.get("created_at"),
                    errors="coerce",
                    utc=True,
                ),
            )
            matched = candidates[-1]
            qualification_rows.append(
                {
                    **outcome,
                    "_matched_evidence_audit_id":
                        _text(
                            matched.get(
                                "outcome_evidence_snapshot_id"
                            )
                        ),
                    "_matched_evidence_audit_hash":
                        _text(
                            matched.get(
                                "snapshot_hash"
                            )
                        ),
                    "_matched_review_snapshot_id":
                        _text(
                            matched.get(
                                "review_snapshot_id"
                            )
                        ),
                    "_matched_review_snapshot_hash":
                        _text(
                            matched.get(
                                "review_snapshot_hash"
                            )
                        ),
                    "_matched_projection_snapshot_id":
                        _text(
                            matched.get(
                                "source_projection_snapshot_id"
                            )
                        ),
                    "_matched_projection_snapshot_hash":
                        _text(
                            matched.get(
                                "source_projection_hash"
                            )
                        ),
                }
            )

    qualified = pd.DataFrame(
        qualification_rows
    )
    duplicate_count = 0

    if not qualified.empty:
        qualified["_ts"] = pd.to_datetime(
            qualified["created_at"],
            errors="coerce",
            utc=True,
        )
        qualified = (
            qualified.loc[
                qualified["_ts"].notna()
            ]
            .sort_values("_ts")
            .reset_index(drop=True)
        )

        key_cols = [
            "source_projection_snapshot_id",
            "evidence_end_trend_snapshot_id",
        ]
        duplicate_count = int(
            qualified.duplicated(
                subset=key_cols,
                keep="last",
            ).sum()
        )
        qualified = (
            qualified.drop_duplicates(
                subset=key_cols,
                keep="last",
            )
            .sort_values("_ts")
            .reset_index(drop=True)
        )

    invalid_total = (
        int(len(invalid_outcomes))
        + _int(
            audit.get(
                "invalid_evidence_audits"
            )
        )
        + _int(
            audit.get(
                "invalid_reviews"
            )
        )
        + _int(
            audit.get(
                "invalid_projections"
            )
        )
    )

    total_outcomes = int(
        len(outcome_df)
    )
    qualified_count = int(
        len(qualified)
    )

    if invalid_total > 0:
        state = "SCORECARD_INPUT_INTEGRITY_REVIEW"
        guard = "HOLD_SCORECARD_INPUT"
    elif lineage_mismatch_count > 0:
        state = "SCORECARD_INPUT_LINEAGE_REVIEW"
        guard = "HOLD_SCORECARD_INPUT"
    elif time_order_mismatch_count > 0:
        state = "SCORECARD_INPUT_TIME_ORDER_REVIEW"
        guard = "HOLD_SCORECARD_INPUT"
    elif total_outcomes == 0:
        state = "SCORECARD_INPUT_HISTORY_REQUIRED"
        guard = "HOLD_SCORECARD_INPUT"
    elif qualified_count == 0:
        state = "SCORECARD_INPUT_EVIDENCE_AUDIT_REQUIRED"
        guard = "HOLD_SCORECARD_INPUT"
    elif unqualified_count > 0:
        state = "SCORECARD_INPUT_UNQUALIFIED_REVIEW"
        guard = "HOLD_SCORECARD_INPUT"
    else:
        state = "SCORECARD_INPUT_READY"
        guard = "ALLOW_SCORECARD_INPUT"

    if state != "SCORECARD_INPUT_READY":
        qualified_history = pd.DataFrame(
            columns=FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS
        )
    else:
        qualified_history = qualified[
            [
                col
                for col in FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS
                if col in qualified.columns
            ]
        ].copy()

    latest = (
        qualified.iloc[-1].to_dict()
        if not qualified.empty
        else {}
    )

    return {
        "qualification_state": state,
        "scorecard_guard": guard,
        "outcome_records_total": total_outcomes,
        "valid_outcome_records": int(
            len(valid_outcomes)
        ),
        "invalid_outcome_records": int(
            len(invalid_outcomes)
        ),
        "ready_evidence_audits": int(
            len(ready_audits)
        ),
        "qualified_outcomes": qualified_count,
        "unqualified_outcomes": unqualified_count,
        "duplicate_outcomes": duplicate_count,
        "lineage_mismatch_count":
            lineage_mismatch_count,
        "time_order_mismatch_count":
            time_order_mismatch_count,
        "source_projection_snapshot_id":
            _text(
                latest.get(
                    "source_projection_snapshot_id"
                )
            ),
        "latest_qualified_outcome_id":
            _text(
                latest.get(
                    "outcome_snapshot_id"
                )
            ),
        "latest_qualified_outcome_hash":
            _text(
                latest.get(
                    "snapshot_hash"
                )
            ),
        "latest_qualified_endpoint_id":
            _text(
                latest.get(
                    "evidence_end_trend_snapshot_id"
                )
            ),
        "latest_evidence_audit_id":
            _text(
                latest.get(
                    "_matched_evidence_audit_id"
                )
            ),
        "latest_evidence_audit_hash":
            _text(
                latest.get(
                    "_matched_evidence_audit_hash"
                )
            ),
        "latest_review_snapshot_id":
            _text(
                latest.get(
                    "_matched_review_snapshot_id"
                )
            ),
        "latest_review_snapshot_hash":
            _text(
                latest.get(
                    "_matched_review_snapshot_hash"
                )
            ),
        "latest_projection_snapshot_id":
            _text(
                latest.get(
                    "_matched_projection_snapshot_id"
                )
            ),
        "latest_projection_snapshot_hash":
            _text(
                latest.get(
                    "_matched_projection_snapshot_hash"
                )
            ),
        "qualified_outcome_history":
            qualified_history,
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }


def build_flow_scorecard_input_queue(
    qualification: dict | None,
) -> pd.DataFrame:
    item = qualification or {}
    state = _text(
        item.get(
            "qualification_state"
        )
    ).upper()

    mapping = {
        "SCORECARD_INPUT_HISTORY_REQUIRED": (
            "SQ2",
            "WAIT",
            "SCORECARD_INPUT_HISTORY_REQUIRED",
            "저장된 Projection Outcome Snapshot 없음",
            "Review-locked closed-session Outcome evidence가 생성될 때까지 기다림",
        ),
        "SCORECARD_INPUT_EVIDENCE_AUDIT_REQUIRED": (
            "SQ1",
            "REVIEW",
            "SCORECARD_INPUT_EVIDENCE_AUDIT_REQUIRED",
            "Outcome Snapshot은 있으나 matching Outcome Evidence Audit 없음",
            "1I-E에서 현재 Outcome Evidence Audit을 먼저 저장한 뒤 1J Outcome Snapshot 저장",
        ),
        "SCORECARD_INPUT_UNQUALIFIED_REVIEW": (
            "SQ0",
            "REVIEW",
            "SCORECARD_INPUT_UNQUALIFIED_REVIEW",
            (
                f"unqualified outcomes "
                f"{_int(item.get('unqualified_outcomes'))}"
            ),
            "legacy/unqualified Outcome을 Proof Clock에서 제외하고 audited lineage를 확인",
        ),
        "SCORECARD_INPUT_INTEGRITY_REVIEW": (
            "SQ0",
            "BLOCKED",
            "SCORECARD_INPUT_INTEGRITY_REVIEW",
            (
                f"invalid outcomes "
                f"{_int(item.get('invalid_outcome_records'))}"
            ),
            "Outcome/Evidence/Review/Projection immutable hash integrity 복구",
        ),
        "SCORECARD_INPUT_LINEAGE_REVIEW": (
            "SQ0",
            "BLOCKED",
            "SCORECARD_INPUT_LINEAGE_REVIEW",
            (
                f"lineage mismatch "
                f"{_int(item.get('lineage_mismatch_count'))}"
            ),
            "Outcome Evidence Audit parent Review/Projection lineage 확인",
        ),
        "SCORECARD_INPUT_TIME_ORDER_REVIEW": (
            "SQ0",
            "BLOCKED",
            "SCORECARD_INPUT_TIME_ORDER_REVIEW",
            (
                f"time-order mismatch "
                f"{_int(item.get('time_order_mismatch_count'))}"
            ),
            "Outcome Evidence Audit 저장 이후 Outcome Snapshot을 생성했는지 확인",
        ),
        "SCORECARD_INPUT_READY": (
            "SQ3",
            "MONITOR",
            "SCORECARD_INPUT_READY",
            (
                f"qualified outcomes "
                f"{_int(item.get('qualified_outcomes'))}"
            ),
            "Qualified Outcome만 Scorecard / Proof Clock에 사용. 자동 Recalibration/Capacity 변경 없음",
        ),
    }

    values = mapping.get(
        state,
        (
            "SQ0",
            "BLOCKED",
            "SCORECARD_INPUT_UNKNOWN_STATE",
            state or "MISSING",
            "Scorecard input qualification vocabulary 확인",
        ),
    )

    row = {
        "priority": values[0],
        "status": values[1],
        "issue": values[2],
        "detail": values[3],
        "next_action": values[4],
        "go_to": "Operations Control Tower",
    }

    return pd.DataFrame(
        [row],
        columns=SCORECARD_INPUT_QUEUE_COLS,
    )


def _snapshot_payload(
    row: dict,
) -> dict:
    int_fields = {
        "outcome_records_total",
        "valid_outcome_records",
        "invalid_outcome_records",
        "ready_evidence_audits",
        "qualified_outcomes",
        "unqualified_outcomes",
        "duplicate_outcomes",
        "lineage_mismatch_count",
        "time_order_mismatch_count",
    }

    payload = {}
    for col in FLOW_SCORECARD_INPUT_SNAPSHOT_COLS:
        if col in {
            "scorecard_input_snapshot_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def build_flow_scorecard_input_snapshot(
    qualification: dict,
    *,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    item = qualification or {}
    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    base = {
        "qualification_state":
            _text(
                item.get(
                    "qualification_state"
                )
            ),
        "scorecard_guard":
            _text(
                item.get(
                    "scorecard_guard"
                )
            ),
        "source_projection_snapshot_id":
            _text(
                item.get(
                    "source_projection_snapshot_id"
                )
            ),
        "outcome_records_total":
            _int(
                item.get(
                    "outcome_records_total"
                )
            ),
        "valid_outcome_records":
            _int(
                item.get(
                    "valid_outcome_records"
                )
            ),
        "invalid_outcome_records":
            _int(
                item.get(
                    "invalid_outcome_records"
                )
            ),
        "ready_evidence_audits":
            _int(
                item.get(
                    "ready_evidence_audits"
                )
            ),
        "qualified_outcomes":
            _int(
                item.get(
                    "qualified_outcomes"
                )
            ),
        "unqualified_outcomes":
            _int(
                item.get(
                    "unqualified_outcomes"
                )
            ),
        "duplicate_outcomes":
            _int(
                item.get(
                    "duplicate_outcomes"
                )
            ),
        "lineage_mismatch_count":
            _int(
                item.get(
                    "lineage_mismatch_count"
                )
            ),
        "time_order_mismatch_count":
            _int(
                item.get(
                    "time_order_mismatch_count"
                )
            ),
        "latest_qualified_outcome_id":
            _text(
                item.get(
                    "latest_qualified_outcome_id"
                )
            ),
        "latest_qualified_outcome_hash":
            _text(
                item.get(
                    "latest_qualified_outcome_hash"
                )
            ),
        "latest_qualified_endpoint_id":
            _text(
                item.get(
                    "latest_qualified_endpoint_id"
                )
            ),
        "latest_evidence_audit_id":
            _text(
                item.get(
                    "latest_evidence_audit_id"
                )
            ),
        "latest_evidence_audit_hash":
            _text(
                item.get(
                    "latest_evidence_audit_hash"
                )
            ),
        "latest_review_snapshot_id":
            _text(
                item.get(
                    "latest_review_snapshot_id"
                )
            ),
        "latest_review_snapshot_hash":
            _text(
                item.get(
                    "latest_review_snapshot_hash"
                )
            ),
        "latest_projection_snapshot_id":
            _text(
                item.get(
                    "latest_projection_snapshot_id"
                )
            ),
        "latest_projection_snapshot_hash":
            _text(
                item.get(
                    "latest_projection_snapshot_hash"
                )
            ),
        "projection_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    snapshot_hash = _hash(
        _snapshot_payload(base)
    )

    return {
        "scorecard_input_snapshot_id": (
            "SCI-"
            + pd.Timestamp(now).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at": now,
        **base,
        "note": _text(note),
        "snapshot_hash": snapshot_hash,
    }


def flow_scorecard_input_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )
    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _snapshot_payload(item)
    )

    return {
        "status":
            "OK"
            if stored == calculated
            else "MISMATCH",
        "calculated_hash": calculated,
    }


def latest_flow_scorecard_input_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_SCORECARD_INPUT_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )
    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(labels=["_ts"])
        .to_dict()
    )
