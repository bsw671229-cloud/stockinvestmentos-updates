from __future__ import annotations

from datetime import datetime
from typing import Any
import hashlib
import json

import pandas as pd

from engine.operations_flow_live_change_design import (
    live_change_design_snapshot_integrity,
)


FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS = [
    "live_change_apply_id",
    "created_at",
    "apply_state",
    "apply_guard",
    "source_live_change_design_id",
    "source_live_change_design_hash",
    "source_live_change_design_created_at",
    "source_live_change_design_integrity",
    "source_trial_closure_id",
    "source_trial_closure_hash",
    "source_proposal_id",
    "source_proposal_hash",
    "proposal_scope",
    "target_metric",
    "change_mode",
    "artifact_ref",
    "baseline_value",
    "candidate_value",
    "rollback_target_value",
    "design_max_scope_pct",
    "design_max_sessions",
    "design_min_post_change_outcomes",
    "design_max_relative_error_degradation_pct",
    "apply_decision",
    "permit_scope_pct",
    "permit_session_budget",
    "permit_min_post_change_outcomes",
    "permit_max_relative_error_degradation_pct",
    "apply_detail",
    "design_source_reviewed",
    "baseline_revalidated_confirmed",
    "candidate_artifact_verified",
    "canary_isolation_rechecked",
    "change_window_reviewed",
    "rollback_ready_confirmed",
    "manual_apply_only_confirmed",
    "no_auto_apply_confirmed",
    "no_auto_recalibration_confirmed",
    "no_auto_capacity_confirmed",
    "no_execution_authorization_confirmed",
    "human_review_confirmed",
    "live_change_apply_permission",
    "live_change_apply_authorization",
    "live_change_runtime_authorization",
    "recalibration_authorization",
    "capacity_authorization",
    "execution_authorization",
    "note",
    "snapshot_hash",
]


LIVE_CHANGE_APPLY_QUEUE_COLS = [
    "priority",
    "status",
    "issue",
    "detail",
    "next_action",
    "go_to",
]


LIVE_CHANGE_APPLY_STATES = {
    "LIVE_CHANGE_APPLY_UPSTREAM_WAIT",
    "LIVE_CHANGE_APPLY_NOT_REQUIRED",
    "LIVE_CHANGE_APPLY_DEFERRED",
    "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
    "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
    "LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
    "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED",
    "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
    "LIVE_CHANGE_APPLY_REJECTED",
}


LIVE_CHANGE_APPLY_GUARD_BY_STATE = {
    "LIVE_CHANGE_APPLY_UPSTREAM_WAIT": "HOLD_LIVE_CHANGE_DESIGN",
    "LIVE_CHANGE_APPLY_NOT_REQUIRED": "NO_LIVE_CHANGE_APPLY",
    "LIVE_CHANGE_APPLY_DEFERRED": "HOLD_LIVE_CHANGE_APPLY",
    "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED": "HOLD_LIVE_CHANGE_DESIGN_SOURCE",
    "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW": "HOLD_LIVE_CHANGE_APPLY_INTEGRITY",
    "LIVE_CHANGE_APPLY_REVIEW_REQUIRED": "HUMAN_LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
    "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED": "HOLD_LIVE_CHANGE_APPLY_SOURCE",
    "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY": "MANUAL_CANARY_APPLY_PERMIT_NO_AUTO_APPLY",
    "LIVE_CHANGE_APPLY_REJECTED": "LIVE_CHANGE_APPLY_REJECTED_NO_APPLY",
}


LIVE_CHANGE_APPLY_DECISIONS = {
    "ISSUE_MANUAL_CANARY_APPLY_PERMIT",
    "REJECT",
    "DEFER",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _hash(payload: Any) -> str:
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(
        raw.encode("utf-8")
    ).hexdigest()


def _apply_payload(row: dict) -> dict:
    int_fields = {
        "design_max_sessions",
        "design_min_post_change_outcomes",
        "permit_session_budget",
        "permit_min_post_change_outcomes",
    }

    float_fields = {
        "baseline_value",
        "candidate_value",
        "rollback_target_value",
        "design_max_scope_pct",
        "design_max_relative_error_degradation_pct",
        "permit_scope_pct",
        "permit_max_relative_error_degradation_pct",
    }

    bool_fields = {
        "design_source_reviewed",
        "baseline_revalidated_confirmed",
        "candidate_artifact_verified",
        "canary_isolation_rechecked",
        "change_window_reviewed",
        "rollback_ready_confirmed",
        "manual_apply_only_confirmed",
        "no_auto_apply_confirmed",
        "no_auto_recalibration_confirmed",
        "no_auto_capacity_confirmed",
        "no_execution_authorization_confirmed",
        "human_review_confirmed",
    }

    payload = {}

    for col in FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS:
        if col in {
            "live_change_apply_id",
            "created_at",
            "note",
            "snapshot_hash",
        }:
            continue

        if col in int_fields:
            payload[col] = _int(
                row.get(col)
            )
        elif col in float_fields:
            payload[col] = round(
                _float(
                    row.get(col)
                ),
                10,
            )
        elif col in bool_fields:
            payload[col] = bool(
                _bool(
                    row.get(col)
                )
            )
        else:
            payload[col] = _text(
                row.get(col)
            )

    return payload


def live_change_apply_snapshot_integrity(
    row: dict | pd.Series | None,
) -> dict:
    if row is None:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    item = (
        row.to_dict()
        if isinstance(row, pd.Series)
        else dict(row)
    )

    stored = _text(
        item.get("snapshot_hash")
    )

    if not stored:
        return {
            "status": "MISSING",
            "calculated_hash": "",
        }

    calculated = _hash(
        _apply_payload(
            item
        )
    )

    return {
        "status": (
            "OK"
            if stored == calculated
            else "MISMATCH"
        ),
        "calculated_hash": calculated,
    }


def latest_live_change_apply_snapshot(
    snapshots: pd.DataFrame | None,
) -> dict:
    df = (
        pd.DataFrame()
        if snapshots is None
        else snapshots.copy()
    )

    if df.empty:
        return {}

    for col in FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS:
        if col not in df.columns:
            df[col] = ""

    df["_ts"] = pd.to_datetime(
        df["created_at"],
        errors="coerce",
        utc=True,
    )

    valid = df.loc[
        df["_ts"].notna()
    ].sort_values("_ts")

    if valid.empty:
        return {}

    return (
        valid.iloc[-1]
        .drop(
            labels=["_ts"]
        )
        .to_dict()
    )


def _locked_design_source(
    design: dict | None,
) -> dict:
    row = design or {}

    if _text(
        row.get("design_state")
    ).upper() != "LIVE_CHANGE_DESIGN_LOCKED":
        return {}

    latest = row.get(
        "latest_design"
    ) or {}

    if not latest:
        return {}

    if _text(
        live_change_design_snapshot_integrity(
            latest
        ).get("status")
    ).upper() != "OK":
        return {}

    if _text(
        latest.get(
            "live_change_design_permission"
        )
    ).upper() != "DESIGN_LOCKED_NO_APPLY":
        return {}

    return latest


def _apply_matches_design(
    apply_row: dict,
    design_source: dict,
) -> bool:
    if not apply_row or not design_source:
        return False

    if _text(
        live_change_apply_snapshot_integrity(
            apply_row
        ).get("status")
    ).upper() != "OK":
        return False

    return (
        _text(
            apply_row.get(
                "source_live_change_design_id"
            )
        )
        == _text(
            design_source.get(
                "live_change_design_id"
            )
        )
        and _text(
            apply_row.get(
                "source_live_change_design_hash"
            )
        )
        == _text(
            design_source.get(
                "snapshot_hash"
            )
        )
    )


def _state_from_decision(
    decision: str,
) -> str:
    value = _text(
        decision
    ).upper()

    if value == "ISSUE_MANUAL_CANARY_APPLY_PERMIT":
        return "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY"

    if value == "REJECT":
        return "LIVE_CHANGE_APPLY_REJECTED"

    if value == "DEFER":
        return "LIVE_CHANGE_APPLY_DEFERRED"

    return "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW"


def build_flow_live_change_apply(
    live_change_design: dict | None,
    apply_snapshots: pd.DataFrame | None,
) -> dict:
    design = live_change_design or {}
    design_state = _text(
        design.get("design_state")
    ).upper()

    base = {
        "source_live_change_design_id": "",
        "source_live_change_design_hash": "",
        "source_live_change_design_created_at": "",
        "source_live_change_design_integrity": "NONE",
        "source_trial_closure_id": _text(
            design.get("source_trial_closure_id")
        ),
        "source_trial_closure_hash": _text(
            design.get("source_trial_closure_hash")
        ),
        "source_proposal_id": _text(
            design.get("source_proposal_id")
        ),
        "source_proposal_hash": _text(
            design.get("source_proposal_hash")
        ),
        "proposal_scope": _text(
            design.get("proposal_scope")
        ).upper(),
        "target_metric": _text(
            design.get("target_metric")
        ).upper(),
        "change_mode": _text(
            design.get("change_mode")
        ).upper() or "CANARY_DESIGN_ONLY",
        "artifact_ref": _text(
            design.get("artifact_ref")
        ),
        "baseline_value": _float(
            design.get("baseline_value")
        ),
        "candidate_value": _float(
            design.get("candidate_value")
        ),
        "rollback_target_value": _float(
            design.get("rollback_target_value")
        ),
        "design_max_scope_pct": _float(
            design.get("max_live_scope_pct")
        ),
        "design_max_sessions": _int(
            design.get("max_live_sessions")
        ),
        "design_min_post_change_outcomes": _int(
            design.get("min_post_change_outcomes")
        ),
        "design_max_relative_error_degradation_pct": _float(
            design.get(
                "max_relative_error_degradation_pct"
            )
        ),
        "apply_decision": "",
        "permit_scope_pct": 0.0,
        "permit_session_budget": 0,
        "permit_min_post_change_outcomes": 0,
        "permit_max_relative_error_degradation_pct": 0.0,
        "apply_detail": "",
        "latest_apply": {},
        "live_change_apply_permission": "NONE",
        "live_change_apply_authorization": "NONE",
        "live_change_runtime_authorization": "NONE",
        "recalibration_authorization": "NONE",
        "capacity_authorization": "NONE",
        "execution_authorization": "NONE",
    }

    if design_state in {
        "",
        "LIVE_CHANGE_DESIGN_UPSTREAM_WAIT",
        "LIVE_CHANGE_DESIGN_CLOSURE_SOURCE_REQUIRED",
        "LIVE_CHANGE_DESIGN_SOURCE_INTEGRITY_REVIEW",
        "LIVE_CHANGE_DESIGN_PROPOSAL_SOURCE_REVIEW",
        "LIVE_CHANGE_DESIGN_REQUIRED",
        "LIVE_CHANGE_DESIGN_SOURCE_SUPERSEDED",
    }:
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_UPSTREAM_WAIT",
            "apply_guard": "HOLD_LIVE_CHANGE_DESIGN",
        }

    if design_state == "LIVE_CHANGE_DESIGN_NOT_REQUIRED":
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_NOT_REQUIRED",
            "apply_guard": "NO_LIVE_CHANGE_APPLY",
        }

    if design_state == "LIVE_CHANGE_DESIGN_DEFERRED":
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_DEFERRED",
            "apply_guard": "HOLD_LIVE_CHANGE_APPLY",
        }

    if design_state != "LIVE_CHANGE_DESIGN_LOCKED":
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_UPSTREAM_WAIT",
            "apply_guard": "HOLD_LIVE_CHANGE_DESIGN",
        }

    source = _locked_design_source(
        design
    )

    if not source:
        latest_design = design.get(
            "latest_design"
        ) or {}

        if not latest_design:
            return {
                **base,
                "apply_state": "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
                "apply_guard": "HOLD_LIVE_CHANGE_DESIGN_SOURCE",
            }

        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard": "HOLD_LIVE_CHANGE_APPLY_INTEGRITY",
        }

    source_integrity = _text(
        live_change_design_snapshot_integrity(
            source
        ).get("status")
    ).upper()

    base.update(
        {
            "source_live_change_design_id":
                _text(
                    source.get(
                        "live_change_design_id"
                    )
                ),
            "source_live_change_design_hash":
                _text(
                    source.get(
                        "snapshot_hash"
                    )
                ),
            "source_live_change_design_created_at":
                _text(
                    source.get(
                        "created_at"
                    )
                ),
            "source_live_change_design_integrity":
                source_integrity,
            "source_trial_closure_id":
                _text(
                    source.get(
                        "source_trial_closure_id"
                    )
                ),
            "source_trial_closure_hash":
                _text(
                    source.get(
                        "source_trial_closure_hash"
                    )
                ),
            "source_proposal_id":
                _text(
                    source.get(
                        "source_proposal_id"
                    )
                ),
            "source_proposal_hash":
                _text(
                    source.get(
                        "source_proposal_hash"
                    )
                ),
            "proposal_scope":
                _text(
                    source.get(
                        "proposal_scope"
                    )
                ).upper(),
            "target_metric":
                _text(
                    source.get(
                        "target_metric"
                    )
                ).upper(),
            "change_mode":
                _text(
                    source.get(
                        "change_mode"
                    )
                ).upper(),
            "artifact_ref":
                _text(
                    source.get(
                        "artifact_ref"
                    )
                ),
            "baseline_value":
                _float(
                    source.get(
                        "baseline_value"
                    )
                ),
            "candidate_value":
                _float(
                    source.get(
                        "candidate_value"
                    )
                ),
            "rollback_target_value":
                _float(
                    source.get(
                        "rollback_target_value"
                    )
                ),
            "design_max_scope_pct":
                _float(
                    source.get(
                        "max_live_scope_pct"
                    )
                ),
            "design_max_sessions":
                _int(
                    source.get(
                        "max_live_sessions"
                    )
                ),
            "design_min_post_change_outcomes":
                _int(
                    source.get(
                        "min_post_change_outcomes"
                    )
                ),
            "design_max_relative_error_degradation_pct":
                _float(
                    source.get(
                        "max_relative_error_degradation_pct"
                    )
                ),
        }
    )

    if source_integrity != "OK":
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard": "HOLD_LIVE_CHANGE_APPLY_INTEGRITY",
        }

    history = (
        pd.DataFrame()
        if apply_snapshots is None
        else apply_snapshots.copy()
    )

    latest = latest_live_change_apply_snapshot(
        history
    )

    if not latest:
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
            "apply_guard": "HUMAN_LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
        }

    base[
        "latest_apply"
    ] = latest

    latest_integrity = _text(
        live_change_apply_snapshot_integrity(
            latest
        ).get("status")
    ).upper()

    if latest_integrity != "OK":
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "apply_guard": "HOLD_LIVE_CHANGE_APPLY_INTEGRITY",
        }

    if not _apply_matches_design(
        latest,
        source,
    ):
        return {
            **base,
            "apply_state": "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED",
            "apply_guard": "HOLD_LIVE_CHANGE_APPLY_SOURCE",
        }

    state = _state_from_decision(
        latest.get(
            "apply_decision"
        )
    )

    return {
        **base,
        "apply_state":
            state,
        "apply_guard":
            LIVE_CHANGE_APPLY_GUARD_BY_STATE.get(
                state,
                "HOLD_LIVE_CHANGE_APPLY_INTEGRITY",
            ),
        "apply_decision":
            _text(
                latest.get(
                    "apply_decision"
                )
            ).upper(),
        "permit_scope_pct":
            _float(
                latest.get(
                    "permit_scope_pct"
                )
            ),
        "permit_session_budget":
            _int(
                latest.get(
                    "permit_session_budget"
                )
            ),
        "permit_min_post_change_outcomes":
            _int(
                latest.get(
                    "permit_min_post_change_outcomes"
                )
            ),
        "permit_max_relative_error_degradation_pct":
            _float(
                latest.get(
                    "permit_max_relative_error_degradation_pct"
                )
            ),
        "apply_detail":
            _text(
                latest.get(
                    "apply_detail"
                )
            ),
        "live_change_apply_permission":
            _text(
                latest.get(
                    "live_change_apply_permission"
                )
            ).upper()
            or "NONE",
    }


def build_flow_live_change_apply_lock(
    apply: dict,
    *,
    apply_decision: str,
    permit_scope_pct: float,
    permit_session_budget: int,
    apply_detail: str,
    design_source_reviewed: bool,
    baseline_revalidated_confirmed: bool,
    candidate_artifact_verified: bool,
    canary_isolation_rechecked: bool,
    change_window_reviewed: bool,
    rollback_ready_confirmed: bool,
    manual_apply_only_confirmed: bool,
    no_auto_apply_confirmed: bool,
    no_auto_recalibration_confirmed: bool,
    no_auto_capacity_confirmed: bool,
    no_execution_authorization_confirmed: bool,
    human_review_confirmed: bool,
    note: str = "",
    created_at: str | None = None,
) -> dict:
    current = apply or {}

    if _text(
        current.get(
            "apply_state"
        )
    ).upper() != "LIVE_CHANGE_APPLY_REVIEW_REQUIRED":
        raise ValueError(
            "Live Change Apply Review는 LIVE_CHANGE_APPLY_REVIEW_REQUIRED 상태에서만 저장할 수 있습니다."
        )

    if _text(
        current.get(
            "source_live_change_design_integrity"
        )
    ).upper() != "OK":
        raise ValueError(
            "source Live Change Design integrity가 OK가 아닙니다."
        )

    decision = _text(
        apply_decision
    ).upper()

    if decision not in LIVE_CHANGE_APPLY_DECISIONS:
        raise ValueError(
            "Apply decision은 ISSUE_MANUAL_CANARY_APPLY_PERMIT / REJECT / DEFER 중 하나여야 합니다."
        )

    detail = _text(
        apply_detail
    )

    if len(detail) < 50:
        raise ValueError(
            "Live Change Apply rationale을 50자 이상 기록하세요."
        )

    confirmations = {
        "design_source_reviewed":
            bool(
                design_source_reviewed
            ),
        "baseline_revalidated_confirmed":
            bool(
                baseline_revalidated_confirmed
            ),
        "candidate_artifact_verified":
            bool(
                candidate_artifact_verified
            ),
        "canary_isolation_rechecked":
            bool(
                canary_isolation_rechecked
            ),
        "change_window_reviewed":
            bool(
                change_window_reviewed
            ),
        "rollback_ready_confirmed":
            bool(
                rollback_ready_confirmed
            ),
        "manual_apply_only_confirmed":
            bool(
                manual_apply_only_confirmed
            ),
        "no_auto_apply_confirmed":
            bool(
                no_auto_apply_confirmed
            ),
        "no_auto_recalibration_confirmed":
            bool(
                no_auto_recalibration_confirmed
            ),
        "no_auto_capacity_confirmed":
            bool(
                no_auto_capacity_confirmed
            ),
        "no_execution_authorization_confirmed":
            bool(
                no_execution_authorization_confirmed
            ),
        "human_review_confirmed":
            bool(
                human_review_confirmed
            ),
    }

    if not all(
        confirmations.values()
    ):
        raise ValueError(
            "Live Change Apply preflight 확인사항을 모두 검토해야 합니다."
        )

    design_scope = _float(
        current.get(
            "design_max_scope_pct"
        )
    )
    design_sessions = _int(
        current.get(
            "design_max_sessions"
        )
    )
    design_outcomes = _int(
        current.get(
            "design_min_post_change_outcomes"
        )
    )
    design_degradation = _float(
        current.get(
            "design_max_relative_error_degradation_pct"
        )
    )

    scope = float(
        permit_scope_pct
    )
    sessions = int(
        permit_session_budget
    )

    if decision == "ISSUE_MANUAL_CANARY_APPLY_PERMIT":
        if not (
            0.01
            <= scope
            <= min(
                0.05,
                design_scope,
            )
        ):
            raise ValueError(
                "Manual canary apply permit scope는 1% 이상이며 locked Design scope 이하여야 합니다."
            )

        if not (
            1
            <= sessions
            <= design_sessions
        ):
            raise ValueError(
                "Manual canary apply session budget은 1 이상이며 locked Design session cap 이하여야 합니다."
            )
    else:
        scope = 0.0
        sessions = 0

    now = _text(
        created_at
    ) or datetime.now().astimezone().isoformat()

    source_created = pd.to_datetime(
        current.get(
            "source_live_change_design_created_at"
        ),
        errors="coerce",
        utc=True,
    )
    apply_created = pd.to_datetime(
        now,
        errors="coerce",
        utc=True,
    )

    if (
        pd.isna(
            source_created
        )
        or pd.isna(
            apply_created
        )
        or apply_created <= source_created
    ):
        raise ValueError(
            "Live Change Apply Review는 source Design audit 이후에 저장되어야 합니다."
        )

    state = _state_from_decision(
        decision
    )

    permission = (
        "MANUAL_CANARY_APPLY_ONLY"
        if decision
        == "ISSUE_MANUAL_CANARY_APPLY_PERMIT"
        else "NONE"
    )

    base = {
        "apply_state":
            state,
        "apply_guard":
            LIVE_CHANGE_APPLY_GUARD_BY_STATE[
                state
            ],
        "source_live_change_design_id":
            _text(
                current.get(
                    "source_live_change_design_id"
                )
            ),
        "source_live_change_design_hash":
            _text(
                current.get(
                    "source_live_change_design_hash"
                )
            ),
        "source_live_change_design_created_at":
            _text(
                current.get(
                    "source_live_change_design_created_at"
                )
            ),
        "source_live_change_design_integrity":
            "OK",
        "source_trial_closure_id":
            _text(
                current.get(
                    "source_trial_closure_id"
                )
            ),
        "source_trial_closure_hash":
            _text(
                current.get(
                    "source_trial_closure_hash"
                )
            ),
        "source_proposal_id":
            _text(
                current.get(
                    "source_proposal_id"
                )
            ),
        "source_proposal_hash":
            _text(
                current.get(
                    "source_proposal_hash"
                )
            ),
        "proposal_scope":
            _text(
                current.get(
                    "proposal_scope"
                )
            ),
        "target_metric":
            _text(
                current.get(
                    "target_metric"
                )
            ),
        "change_mode":
            _text(
                current.get(
                    "change_mode"
                )
            ),
        "artifact_ref":
            _text(
                current.get(
                    "artifact_ref"
                )
            ),
        "baseline_value":
            _float(
                current.get(
                    "baseline_value"
                )
            ),
        "candidate_value":
            _float(
                current.get(
                    "candidate_value"
                )
            ),
        "rollback_target_value":
            _float(
                current.get(
                    "rollback_target_value"
                )
            ),
        "design_max_scope_pct":
            design_scope,
        "design_max_sessions":
            design_sessions,
        "design_min_post_change_outcomes":
            design_outcomes,
        "design_max_relative_error_degradation_pct":
            design_degradation,
        "apply_decision":
            decision,
        "permit_scope_pct":
            scope,
        "permit_session_budget":
            sessions,
        "permit_min_post_change_outcomes":
            design_outcomes,
        "permit_max_relative_error_degradation_pct":
            design_degradation,
        "apply_detail":
            detail,
        **confirmations,
        "live_change_apply_permission":
            permission,
        "live_change_apply_authorization":
            "NONE",
        "live_change_runtime_authorization":
            "NONE",
        "recalibration_authorization":
            "NONE",
        "capacity_authorization":
            "NONE",
        "execution_authorization":
            "NONE",
    }

    snapshot_hash = _hash(
        _apply_payload(
            base
        )
    )

    return {
        "live_change_apply_id": (
            "LCA-"
            + pd.Timestamp(
                now
            ).strftime(
                "%Y%m%dT%H%M%S"
            )
            + "-"
            + snapshot_hash[:8]
        ),
        "created_at":
            now,
        **base,
        "note":
            _text(
                note
            ),
        "snapshot_hash":
            snapshot_hash,
    }


def build_flow_live_change_apply_queue(
    apply: dict | None,
) -> pd.DataFrame:
    row = apply or {}
    state = _text(
        row.get(
            "apply_state"
        )
    ).upper()

    mapping = {
        "LIVE_CHANGE_APPLY_UPSTREAM_WAIT": (
            "LA2",
            "WAIT",
            "LIVE_CHANGE_APPLY_UPSTREAM_WAIT",
            "LOCKED Live Change Design이 아직 없음",
            "Trial Closure / Live Change Design evidence가 자연스럽게 성숙할 때까지 대기",
        ),
        "LIVE_CHANGE_APPLY_NOT_REQUIRED": (
            "LA3",
            "MONITOR",
            "LIVE_CHANGE_APPLY_NOT_REQUIRED",
            "현재 Live Change Design source에서는 Apply Review가 필요하지 않음",
            "새 evidence를 관찰",
        ),
        "LIVE_CHANGE_APPLY_DEFERRED": (
            "LA2",
            "WAIT",
            "LIVE_CHANGE_APPLY_DEFERRED",
            "Human Live Change Apply decision = DEFER",
            "새 evidence/운영 조건 확인 후 재검토",
        ),
        "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED": (
            "LA1",
            "REVIEW",
            "LIVE_CHANGE_APPLY_DESIGN_SOURCE_REQUIRED",
            "LIVE_CHANGE_DESIGN_LOCKED 상태지만 immutable Design source 없음",
            "Live Change Design audit을 먼저 확인",
        ),
        "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW": (
            "LA0",
            "BLOCKED",
            "LIVE_CHANGE_APPLY_SOURCE_INTEGRITY_REVIEW",
            "Live Change Design 또는 Apply audit immutable hash mismatch",
            "Design / Apply source integrity를 먼저 복구",
        ),
        "LIVE_CHANGE_APPLY_REVIEW_REQUIRED": (
            "LA1",
            "REVIEW",
            "LIVE_CHANGE_APPLY_REVIEW_REQUIRED",
            (
                f"design scope <= {float(row.get('design_max_scope_pct',0)):.1%} · "
                f"sessions <= {row.get('design_max_sessions',0)} · "
                f"rollback {row.get('rollback_target_value',0)}"
            ),
            "Baseline freshness / candidate artifact / rollback readiness 확인 후 ISSUE/REJECT/DEFER",
        ),
        "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED": (
            "LA0",
            "REVIEW",
            "LIVE_CHANGE_APPLY_SOURCE_SUPERSEDED",
            "새 Live Change Design으로 기존 Apply decision이 stale",
            "현재 immutable Design 기준으로 Apply Review 재수행",
        ),
        "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY": (
            "LA3",
            "MONITOR",
            "LIVE_CHANGE_APPLY_PERMIT_ISSUED_MANUAL_CANARY_ONLY",
            (
                f"manual canary scope {float(row.get('permit_scope_pct',0)):.1%} · "
                f"session budget {row.get('permit_session_budget',0)}"
            ),
            "자동 적용 금지; 별도 Live Change Runtime/Activation Gate가 permit을 소비해야 함",
        ),
        "LIVE_CHANGE_APPLY_REJECTED": (
            "LA3",
            "MONITOR",
            "LIVE_CHANGE_APPLY_REJECTED",
            "Human Live Change Apply decision = REJECT",
            "live change 적용 없음; 새 Design/evidence cycle까지 대기",
        ),
    }

    priority, status, issue, detail, next_action = mapping.get(
        state,
        (
            "LA0",
            "BLOCKED",
            "LIVE_CHANGE_APPLY_UNKNOWN_STATE",
            state or "MISSING",
            "Live Change Apply state vocabulary 확인",
        ),
    )

    return pd.DataFrame(
        [
            {
                "priority":
                    priority,
                "status":
                    status,
                "issue":
                    issue,
                "detail":
                    detail,
                "next_action":
                    next_action,
                "go_to":
                    "Operations Control Tower",
            }
        ],
        columns=
            LIVE_CHANGE_APPLY_QUEUE_COLS,
    )
