from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import re

import pandas as pd

from updater.release_recovery import (
    trusted_release_recovery_status,
)


V1551_RELEASE_ZIP_SHA256 = (
    "5d24c0a4f2d7aef1f7baffda7c300c04e6ca0bd43142284967a9533e16c0c35b"
)
V1551_RELEASE_MANIFEST_FILE_SHA256 = (
    "5a735216949cdb915de5ea02435c2ab533a471df056b71ac44243a953649ccf7"
)
V1551_RELEASE_NOTES_FILE_SHA256 = (
    "2a61288eb852cc9169b60b8fcf1887f8bf09a6568c4222e9d2c9015702b805ba"
)
V1551_BASELINE_PROVENANCE_REL = "release_baselines/v1_55_1.json"

V156_RECOVERY_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V156_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b"",
        ):
            h.update(chunk)
    return h.hexdigest()


def verify_v1551_release_baseline_provenance(
    code_root: str | Path,
) -> dict:
    root = Path(code_root).resolve()
    provenance_path = root / V1551_BASELINE_PROVENANCE_REL

    record = {}
    record_ok = False
    detail = ""

    if provenance_path.is_file():
        try:
            record = json.loads(
                provenance_path.read_text(
                    encoding="utf-8"
                )
            )
        except Exception as exc:
            detail = f"{type(exc).__name__}: {exc}"
        else:
            record_ok = (
                _text(record.get("release_version"))
                == "v1.55.1"
                and _text(
                    record.get("release_zip_sha256")
                ).lower()
                == V1551_RELEASE_ZIP_SHA256
                and _text(
                    record.get("manifest_file_sha256")
                ).lower()
                == V1551_RELEASE_MANIFEST_FILE_SHA256
                and _text(
                    record.get("release_notes_file_sha256")
                ).lower()
                == V1551_RELEASE_NOTES_FILE_SHA256
                and _text(
                    record.get("provenance_status")
                ).upper()
                == "VERIFIED_RELEASE_BASELINE"
            )
            detail = (
                "exact provenance record"
                if record_ok
                else "provenance record fields mismatch"
            )

    return {
        "status": "VERIFIED" if record_ok else "BLOCKED",
        "verified": record_ok,
        "source": "PROVENANCE_RECORD" if record_ok else "NONE",
        "record_path": str(provenance_path),
        "record_detail": detail,
        "release_version": "v1.55.1",
        "release_zip_sha256": V1551_RELEASE_ZIP_SHA256,
        "manifest_file_sha256": V1551_RELEASE_MANIFEST_FILE_SHA256,
        "release_notes_file_sha256": V1551_RELEASE_NOTES_FILE_SHA256,
    }


def build_v156_recovery_context(
    code_root: str | Path,
) -> dict:
    root = Path(code_root).resolve()
    recovery = trusted_release_recovery_status(root)
    return {
        "root": str(root),
        "recovery": recovery,
        "execution_authorization": "NONE",
    }


def build_v156_recovery_technical_gate(
    context: dict,
) -> dict:
    recovery = context.get("recovery") or {}

    checks = pd.DataFrame(
        recovery.get("checks") or [],
        columns=V156_RECOVERY_CHECK_COLS,
    )

    technical = (
        checks.loc[
            checks["layer"]
            .astype(str)
            .str.upper()
            .eq("TECHNICAL")
        ].copy()
        if not checks.empty
        else pd.DataFrame(
            columns=V156_RECOVERY_CHECK_COLS
        )
    )

    passed = int(
        technical["status"]
        .astype(str)
        .str.upper()
        .eq("PASS")
        .sum()
    ) if not technical.empty else 0

    review = int(
        technical["status"]
        .astype(str)
        .str.upper()
        .eq("REVIEW")
        .sum()
    ) if not technical.empty else 0

    fail = int(
        technical["status"]
        .astype(str)
        .str.upper()
        .eq("FAIL")
        .sum()
    ) if not technical.empty else 0

    return {
        "release_gate": "PASS" if fail == 0 else "BLOCKED",
        "technical_pass": passed,
        "technical_review": review,
        "technical_fail": fail,
        "recovery_status": recovery.get("status", "REVIEW"),
        "backup_integrity": recovery.get("backup_integrity", "FAIL"),
        "recovery_point_version": recovery.get(
            "recovery_point_version",
            "-",
        ),
        "checks": technical,
        "execution_authorization": "NONE",
    }


def build_v156_recovery_audit_gate(
    context: dict,
) -> dict:
    recovery = context.get("recovery") or {}
    rows = []

    backup_ok = (
        _text(
            recovery.get("backup_integrity")
        ).upper()
        == "PASS"
    )
    rows.append({
        "layer": "TECHNICAL",
        "check": "Backup Integrity Evidence",
        "status": "PASS" if backup_ok else "FAIL",
        "detail": (
            f"backup={recovery.get('backup_name','-')} · "
            f"integrity={recovery.get('backup_integrity','FAIL')}"
        ),
        "action": (
            ""
            if backup_ok
            else "Repair or recreate the transactional release backup."
        ),
    })

    drill_status = _text(
        recovery.get("last_drill_status")
    ).upper()
    drill_ok = drill_status == "RECOVERY_DRILL_PASS"
    rows.append({
        "layer": "TECHNICAL",
        "check": "Non-mutating Recovery Drill Evidence",
        "status": "PASS" if drill_ok else "REVIEW",
        "detail": drill_status or "NOT_RUN",
        "action": (
            ""
            if drill_ok
            else "Run the non-mutating recovery drill after release apply."
        ),
    })

    auth_ok = _text(
        recovery.get(
            "execution_authorization",
            "NONE",
        )
    ).upper() == "NONE"
    rows.append({
        "layer": "TECHNICAL",
        "check": "Execution Authorization Boundary",
        "status": "PASS" if auth_ok else "FAIL",
        "detail": (
            f"execution_authorization="
            f"{recovery.get('execution_authorization','NONE')}"
        ),
        "action": (
            ""
            if auth_ok
            else "Investment execution authorization must remain NONE."
        ),
    })

    checks = pd.DataFrame(
        rows,
        columns=V156_RECOVERY_CHECK_COLS,
    )

    fail = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("FAIL")
        .sum()
    )
    review = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("REVIEW")
        .sum()
    )
    passed = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("PASS")
        .sum()
    )

    return {
        "release_gate": "PASS" if fail == 0 else "BLOCKED",
        "technical_pass": passed,
        "technical_review": review,
        "technical_fail": fail,
        "operating_status": "PASS" if review == 0 else "REVIEW",
        "checks": checks,
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
    *,
    blocking: bool = True,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else (
            "BLOCKED" if blocking else "REVIEW"
        ),
        "detail": detail,
        "blocking": bool(
            blocking and not passed
        ),
    }


def build_v156_release_readiness(
    *,
    v155_release_status: str,
    v1551_baseline_provenance: dict,
    recovery_release_gate: str,
    recovery_audit_gate: str,
    recovery_status: str,
    audit_operating_status: str,
    execution_authorization: str = "NONE",
) -> dict:
    rows = []

    rows.append(
        _candidate_row(
            "v1.55 Trusted Release Operations predecessor gate",
            _text(v155_release_status)
            == "READY_FOR_RELEASE_REVIEW",
            _text(v155_release_status) or "MISSING",
        )
    )

    baseline_ok = (
        (v1551_baseline_provenance or {}).get(
            "status"
        )
        == "VERIFIED"
    )
    rows.append(
        _candidate_row(
            "v1.55.1 immutable release baseline",
            baseline_ok,
            (
                (v1551_baseline_provenance or {}).get(
                    "record_detail"
                )
                or "MISSING"
            ),
        )
    )

    rows.append(
        _candidate_row(
            "Trusted Release Recovery Technical Gate",
            _text(recovery_release_gate) == "PASS",
            _text(recovery_release_gate) or "MISSING",
        )
    )

    rows.append(
        _candidate_row(
            "Trusted Release Recovery Audit Gate",
            _text(recovery_audit_gate) == "PASS",
            _text(recovery_audit_gate) or "MISSING",
        )
    )

    auth_ok = _text(
        execution_authorization
    ).upper() == "NONE"
    rows.append(
        _candidate_row(
            "Execution Authorization",
            auth_ok,
            _text(execution_authorization) or "MISSING",
        )
    )

    recovery_review = (
        _text(recovery_status).upper()
        != "PASS"
    )
    rows.append({
        "check": "Recovery Operating State",
        "status": "REVIEW" if recovery_review else "PASS",
        "detail": _text(recovery_status) or "MISSING",
        "blocking": False,
    })

    audit_review = (
        _text(audit_operating_status).upper()
        != "PASS"
    )
    rows.append({
        "check": "Recovery Drill Evidence Freshness",
        "status": "REVIEW" if audit_review else "PASS",
        "detail": _text(audit_operating_status) or "MISSING",
        "blocking": False,
    })

    checks = pd.DataFrame(
        rows,
        columns=V156_CANDIDATE_CHECK_COLS,
    )

    blocking = checks.loc[
        checks["blocking"].eq(True)
    ]

    blockers = [
        f"{row['check']}: {row['detail']}"
        for _, row in blocking.iterrows()
    ]

    operating_review_count = int(
        checks["status"]
        .astype(str)
        .str.upper()
        .eq("REVIEW")
        .sum()
    )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "operating_review_count": operating_review_count,
        "blockers": blockers,
        "checks": checks,
        "execution_authorization": "NONE",
    }
