from __future__ import annotations

from typing import Any
import json

import pandas as pd

from engine.operations_flow_controlled_trial_runtime import (
    FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    controlled_trial_runtime_snapshot_integrity,
)
from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    recalibration_proposal_snapshot_integrity,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
)
from engine.operations_flow_controlled_trial_outcome import (
    FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    CONTROLLED_TRIAL_OUTCOME_STATES,
    TRIAL_OUTCOME_GUARD_BY_STATE,
    build_flow_controlled_trial_outcome,
    controlled_trial_outcome_snapshot_integrity,
    latest_controlled_trial_outcome_snapshot,
)


TRIAL_OUTCOME_RELEASE_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

TRIAL_OUTCOME_AUDIT_CHECK_COLS = [
    "layer",
    "check",
    "status",
    "detail",
    "action",
]

V144_CANDIDATE_CHECK_COLS = [
    "check",
    "status",
    "detail",
    "blocking",
]


ROLLBACK_STATES = {
    "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED",
}


FINAL_STATES = {
    "TRIAL_OUTCOME_PASS_NO_PROMOTION",
    "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED",
    "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
}


def _text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    return str(value).strip()


def _int(value: Any) -> int:
    try:
        if pd.isna(value):
            return 0
    except Exception:
        pass
    try:
        return int(float(value))
    except Exception:
        return 0


def _float(value: Any) -> float:
    try:
        if pd.isna(value):
            return 0.0
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return 0.0


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _text(value).lower() in {
        "1", "true", "yes", "y", "on",
    }


def _ensure_cols(
    df: pd.DataFrame | None,
    cols: list[str],
) -> pd.DataFrame:
    out = pd.DataFrame() if df is None else df.copy()
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    return out


def _integrity_counts(
    df: pd.DataFrame | None,
    integrity_fn,
) -> dict:
    if df is None or df.empty:
        return {
            "total": 0,
            "ok": 0,
            "missing": 0,
            "mismatch": 0,
        }

    total = ok = missing = mismatch = 0

    for _, row in df.iterrows():
        total += 1
        status = _text(
            integrity_fn(row.to_dict()).get("status")
        ).upper()

        if status == "OK":
            ok += 1
        elif status == "MISSING":
            missing += 1
        else:
            mismatch += 1

    return {
        "total": total,
        "ok": ok,
        "missing": missing,
        "mismatch": mismatch,
    }


def _index_by_id(
    df: pd.DataFrame | None,
    id_col: str,
) -> tuple[dict, int]:
    if df is None or df.empty:
        return {}, 0

    index = {}
    duplicates = 0

    for _, row in df.iterrows():
        item = row.to_dict()
        item_id = _text(item.get(id_col))

        if not item_id:
            continue

        if item_id in index:
            duplicates += 1

        index[item_id] = item

    return index, duplicates


def _json_list(value: Any) -> list[str]:
    raw = _text(value)
    if not raw:
        return []

    try:
        parsed = json.loads(raw)
    except Exception:
        return []

    if not isinstance(parsed, list):
        return []

    return [
        _text(x)
        for x in parsed
        if _text(x)
    ]


def build_v144_trial_outcome_context(
    *,
    v143_context: dict | None,
    recalibration_proposal_snapshots: pd.DataFrame | None,
    qualified_outcomes: pd.DataFrame | None,
    controlled_trial_outcome_snapshots: pd.DataFrame | None,
) -> dict:
    upstream = v143_context or {}
    runtime = upstream.get("runtime") or {}

    proposal_df = _ensure_cols(
        recalibration_proposal_snapshots,
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )

    qualified_df = _ensure_cols(
        qualified_outcomes,
        FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    )

    outcome_df = _ensure_cols(
        controlled_trial_outcome_snapshots,
        FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    )

    runtime_df = _ensure_cols(
        upstream.get("controlled_trial_runtime_snapshots"),
        FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    )

    outcome = build_flow_controlled_trial_outcome(
        runtime,
        runtime_df,
        proposal_df,
        qualified_df,
    )

    latest_outcome = latest_controlled_trial_outcome_snapshot(
        outcome_df
    )

    latest_integrity = (
        _text(
            controlled_trial_outcome_snapshot_integrity(
                latest_outcome
            ).get("status")
        ).upper()
        if latest_outcome
        else "NONE"
    )

    return {
        "v143_context": upstream,
        "runtime": runtime,
        "controlled_trial_runtime_snapshots": runtime_df,
        "recalibration_proposal_snapshots": proposal_df,
        "qualified_outcomes": qualified_df,
        "controlled_trial_outcome_snapshots": outcome_df,
        "outcome": outcome,
        "outcome_integrity": _integrity_counts(
            outcome_df,
            controlled_trial_outcome_snapshot_integrity,
        ),
        "latest_outcome": latest_outcome,
        "latest_outcome_integrity": latest_integrity,
        "execution_authorization": "NONE",
    }


def _technical_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def _runtime_routing_ok(
    outcome: dict,
    runtime: dict,
) -> bool:
    outcome_state = _text(
        outcome.get("outcome_state")
    ).upper()
    runtime_state = _text(
        runtime.get("runtime_state")
    ).upper()

    if runtime_state in {
        "",
        "TRIAL_RUNTIME_UPSTREAM_WAIT",
        "TRIAL_RUNTIME_PERMIT_SOURCE_REQUIRED",
    }:
        return outcome_state == "TRIAL_OUTCOME_UPSTREAM_WAIT"

    if runtime_state in {
        "TRIAL_RUNTIME_NOT_REQUIRED",
        "TRIAL_RUNTIME_DEFERRED",
    }:
        return outcome_state == "TRIAL_OUTCOME_NOT_REQUIRED"

    if runtime_state in {
        "TRIAL_RUNTIME_SOURCE_INTEGRITY_REVIEW",
        "TRIAL_RUNTIME_SOURCE_SUPERSEDED",
    }:
        return outcome_state == "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW"

    if runtime_state == "TRIAL_RUNTIME_ACTIVE":
        return outcome_state == "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT"

    if runtime_state == "TRIAL_RUNTIME_KILL_SWITCHED":
        return outcome_state == "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED"

    if runtime_state in {
        "TRIAL_RUNTIME_READY",
        "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED",
    }:
        return outcome_state in {
            "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW",
            "TRIAL_OUTCOME_MODEL_EVALUATOR_REQUIRED",
            "TRIAL_OUTCOME_EVIDENCE_MATURING",
            "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED",
            "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED",
            "TRIAL_OUTCOME_PASS_NO_PROMOTION",
            "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED",
            "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
        }

    return False


def _runtime_source_mapping_ok(
    context: dict,
) -> bool:
    outcome = context.get("outcome") or {}
    state = _text(
        outcome.get("outcome_state")
    ).upper()

    source_id = _text(
        outcome.get("source_runtime_event_id")
    )
    source_hash = _text(
        outcome.get("source_runtime_event_hash")
    )

    if state in {
        "TRIAL_OUTCOME_UPSTREAM_WAIT",
        "TRIAL_OUTCOME_NOT_REQUIRED",
    }:
        return not source_id and not source_hash

    if not source_id or not source_hash:
        # READY with no event history is a normal pre-session state.
        runtime_state = _text(
            (context.get("runtime") or {}).get("runtime_state")
        ).upper()
        return (
            runtime_state == "TRIAL_RUNTIME_READY"
            and _int(
                (context.get("runtime") or {}).get("sessions_used")
            ) == 0
        )

    index, duplicates = _index_by_id(
        context.get("controlled_trial_runtime_snapshots"),
        "controlled_trial_runtime_event_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(source_id)

    return (
        bool(parent)
        and _text(
            controlled_trial_runtime_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(parent.get("snapshot_hash"))
        == source_hash
    )


def _proposal_source_mapping_ok(
    context: dict,
) -> bool:
    outcome = context.get("outcome") or {}
    state = _text(
        outcome.get("outcome_state")
    ).upper()

    if state in {
        "TRIAL_OUTCOME_UPSTREAM_WAIT",
        "TRIAL_OUTCOME_NOT_REQUIRED",
        "TRIAL_OUTCOME_RUNTIME_ACTIVE_WAIT",
        "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED",
    }:
        return True

    proposal_id = _text(
        outcome.get("source_proposal_id")
    )
    proposal_hash = _text(
        outcome.get("source_proposal_hash")
    )

    if state == "TRIAL_OUTCOME_SOURCE_INTEGRITY_REVIEW":
        # A missing/broken proposal is a legitimate reason for this operating state.
        if not proposal_id or not proposal_hash:
            return True

    if not proposal_id or not proposal_hash:
        return False

    index, duplicates = _index_by_id(
        context.get("recalibration_proposal_snapshots"),
        "recalibration_proposal_id",
    )

    if duplicates > 0:
        return False

    parent = index.get(proposal_id)

    return (
        bool(parent)
        and _text(
            recalibration_proposal_snapshot_integrity(
                parent
            ).get("status")
        ).upper()
        == "OK"
        and _text(parent.get("snapshot_hash"))
        == proposal_hash
        and _text(parent.get("proposal_state")).upper()
        == "RECALIBRATION_PROPOSAL_LOCKED"
    )


def _evidence_invariant_ok(
    outcome: dict,
    runtime: dict,
) -> bool:
    state = _text(
        outcome.get("outcome_state")
    ).upper()
    runtime_state = _text(
        runtime.get("runtime_state")
    ).upper()

    eligible = _int(
        outcome.get("eligible_trial_outcomes")
    )
    required = _int(
        outcome.get("required_trial_outcomes")
    )
    completed = _int(
        outcome.get("completed_sessions")
    )
    budget = _int(
        outcome.get("permit_session_budget")
    )

    ids = _json_list(
        outcome.get("evidence_outcome_ids_json")
    )
    hashes = _json_list(
        outcome.get("evidence_outcome_hashes_json")
    )

    if eligible < 0:
        return False

    if len(ids) != eligible or len(hashes) != eligible:
        return False

    if len(set(ids)) != len(ids):
        return False

    if _int(
        outcome.get("duplicate_outcomes")
    ) < 0:
        return False

    if state in FINAL_STATES:
        if runtime_state != "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED":
            return False
        if budget <= 0 or completed < budget:
            return False

    if state == "TRIAL_OUTCOME_PASS_NO_PROMOTION":
        return (
            eligible >= max(3, required)
            and _float(
                outcome.get(
                    "relative_error_improvement_pct"
                )
            ) > 0.0
        )

    if state == "TRIAL_OUTCOME_FAIL_ROLLBACK_REQUIRED":
        return (
            eligible >= max(3, required)
            and _float(
                outcome.get(
                    "relative_error_improvement_pct"
                )
            )
            <= -_float(
                outcome.get(
                    "max_relative_error_degradation_pct"
                )
            )
        )

    if state == "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION":
        return runtime_state == "TRIAL_RUNTIME_SESSION_BUDGET_EXHAUSTED"

    if state == "TRIAL_OUTCOME_ASSUMPTION_DRIFT_ROLLBACK_REQUIRED":
        return _int(
            outcome.get("assumption_drift_outcomes")
        ) > 0

    if state == "TRIAL_OUTCOME_BASELINE_DRIFT_ROLLBACK_REQUIRED":
        return _int(
            outcome.get("baseline_drift_outcomes")
        ) > 0

    if state == "TRIAL_OUTCOME_KILL_SWITCH_ROLLBACK_REQUIRED":
        return (
            runtime_state == "TRIAL_RUNTIME_KILL_SWITCHED"
            and bool(
                _text(
                    outcome.get("kill_switch_trigger")
                )
            )
        )

    return True


def _rollback_no_promotion_ok(
    outcome: dict,
) -> bool:
    state = _text(
        outcome.get("outcome_state")
    ).upper()
    rollback = _bool(
        outcome.get("rollback_required")
    )

    if state in ROLLBACK_STATES and not rollback:
        return False

    if state in {
        "TRIAL_OUTCOME_PASS_NO_PROMOTION",
        "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
    } and rollback:
        return False

    return True


def _no_live_authorization_ok(
    context: dict,
) -> bool:
    violations = 0

    for item in [
        context.get("outcome") or {},
        context.get("latest_outcome") or {},
        context.get("runtime") or {},
    ]:
        for field in [
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "trial_design_authorization",
            "adoption_authorization",
            "validation_authorization",
            "proposal_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "capacity_override_authorization",
            "projection_authorization",
            "execution_authorization",
        ]:
            if (
                field in item
                and _text(item.get(field)).upper()
                not in {"", "NONE"}
            ):
                violations += 1

    history = context.get(
        "controlled_trial_outcome_snapshots"
    )

    if (
        isinstance(history, pd.DataFrame)
        and not history.empty
    ):
        for field in [
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if field not in history.columns:
                continue

            values = (
                history[field]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            violations += int(
                (~values.isin(["", "NONE"])).sum()
            )

    if _text(
        context.get("execution_authorization")
    ).upper() != "NONE":
        violations += 1

    return violations == 0


def build_v144_trial_outcome_technical_release_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}
    outcome = ctx.get("outcome") or {}
    runtime = ctx.get("runtime") or {}
    counts = ctx.get("outcome_integrity") or {}

    state = _text(
        outcome.get("outcome_state")
    ).upper()
    guard = _text(
        outcome.get("outcome_guard")
    ).upper()

    checks = []

    checks.append(
        _technical_row(
            "Controlled Trial Outcome Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Outcome immutable hash 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Outcome State / Guard Vocabulary",
            (
                state in CONTROLLED_TRIAL_OUTCOME_STATES
                and guard
                == TRIAL_OUTCOME_GUARD_BY_STATE.get(
                    state,
                    "",
                )
            ),
            (
                f"state {state or 'MISSING'} · "
                f"guard {guard or 'MISSING'} · "
                f"expected {TRIAL_OUTCOME_GUARD_BY_STATE.get(state,'UNKNOWN')}"
            ),
            "Trial Outcome state/guard vocabulary 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Runtime → Trial Outcome State Invariant",
            _runtime_routing_ok(
                outcome,
                runtime,
            ),
            (
                f"runtime {_text(runtime.get('runtime_state')) or 'MISSING'} · "
                f"outcome {state or 'MISSING'}"
            ),
            "Runtime state와 Trial Outcome state 연결 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Outcome → Runtime Source Mapping",
            _runtime_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"runtime source {_text(outcome.get('source_runtime_event_id')) or 'NONE'}"
            ),
            "Trial Outcome source Runtime event id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Outcome → Locked Proposal Source Mapping",
            _proposal_source_mapping_ok(
                ctx
            ),
            (
                f"state {state or 'MISSING'} · "
                f"proposal {_text(outcome.get('source_proposal_id')) or 'NONE'} · "
                f"integrity {_text(outcome.get('source_proposal_integrity')) or 'NONE'}"
            ),
            "Trial Outcome source locked Proposal id/hash/integrity 확인",
        )
    )

    checks.append(
        _technical_row(
            "Prospective Canary Evidence / Finalization Invariant",
            _evidence_invariant_ok(
                outcome,
                runtime,
            ),
            (
                f"eligible {_int(outcome.get('eligible_trial_outcomes'))}/"
                f"{_int(outcome.get('required_trial_outcomes'))} · "
                f"sessions {_int(outcome.get('completed_sessions'))}/"
                f"{_int(outcome.get('permit_session_budget'))} · "
                f"pre-open {_int(outcome.get('preopen_projection_outcomes'))}"
            ),
            "Prospective session window / finalization / duplicate resistance 확인",
        )
    )

    checks.append(
        _technical_row(
            "Trial Outcome Rollback / No-Promotion Invariant",
            _rollback_no_promotion_ok(
                outcome
            ),
            (
                f"state {state or 'MISSING'} · "
                f"rollback {_bool(outcome.get('rollback_required'))} · "
                f"improvement {_float(outcome.get('relative_error_improvement_pct')):.1%}"
            ),
            "Rollback-required state와 PASS no-promotion semantics 확인",
        )
    )

    checks.append(
        _technical_row(
            "Controlled Trial Outcome No-Live-Authorization Invariant",
            _no_live_authorization_ok(
                ctx
            ),
            "NONE",
            "Trial Outcome/Runtime/Start/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    operating_status = (
        "PASS"
        if state
        in {
            "TRIAL_OUTCOME_NOT_REQUIRED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Outcome Operating State",
            "status": operating_status,
            "detail": (
                f"state {state or 'MISSING'} · "
                f"eligible {_int(outcome.get('eligible_trial_outcomes'))}/"
                f"{_int(outcome.get('required_trial_outcomes'))} · "
                f"rollback {_bool(outcome.get('rollback_required'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "정상 outcome wait/pass/fail/inconclusive/rollback 상태는 Technical FAIL로 승격하지 않고 "
                    "Human Review와 rollback closure evidence를 자연스럽게 축적"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "outcome_state": state,
        "runtime_state": _text(
            runtime.get("runtime_state")
        ).upper(),
        "latest_trial_outcome_integrity":
            _text(
                ctx.get(
                    "latest_outcome_integrity"
                )
            ).upper()
            or "NONE",
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_OUTCOME_RELEASE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _audit_row(
    check: str,
    passed: bool,
    detail: str,
    action: str,
) -> dict:
    return {
        "layer": "TECHNICAL",
        "check": check,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
        "action": "" if passed else action,
    }


def build_v144_trial_outcome_audit_gate(
    context: dict | None,
) -> dict:
    ctx = context or {}

    outcome_df = _ensure_cols(
        ctx.get(
            "controlled_trial_outcome_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    )
    runtime_df = _ensure_cols(
        ctx.get(
            "controlled_trial_runtime_snapshots"
        ),
        FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    )
    proposal_df = _ensure_cols(
        ctx.get(
            "recalibration_proposal_snapshots"
        ),
        FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    )
    qualified_df = _ensure_cols(
        ctx.get(
            "qualified_outcomes"
        ),
        FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    )

    counts = _integrity_counts(
        outcome_df,
        controlled_trial_outcome_snapshot_integrity,
    )

    runtime_index, runtime_duplicates = _index_by_id(
        runtime_df,
        "controlled_trial_runtime_event_id",
    )
    proposal_index, proposal_duplicates = _index_by_id(
        proposal_df,
        "recalibration_proposal_id",
    )
    qualified_index, qualified_duplicates = _index_by_id(
        qualified_df,
        "outcome_snapshot_id",
    )

    contract_violations = 0
    lineage_violations = 0
    evidence_violations = 0
    identity_duplicates = 0
    time_order_violations = 0
    authorization_violations = 0

    seen_ids = set()

    for _, row in outcome_df.iterrows():
        item = row.to_dict()

        audit_id = _text(
            item.get(
                "controlled_trial_outcome_id"
            )
        )
        if audit_id:
            if audit_id in seen_ids:
                identity_duplicates += 1
            seen_ids.add(audit_id)

        state = _text(
            item.get("outcome_state")
        ).upper()
        guard = _text(
            item.get("outcome_guard")
        ).upper()
        rollback = _bool(
            item.get("rollback_required")
        )

        if (
            state not in CONTROLLED_TRIAL_OUTCOME_STATES
            or guard
            != TRIAL_OUTCOME_GUARD_BY_STATE.get(
                state,
                "",
            )
            or (
                state in ROLLBACK_STATES
                and not rollback
            )
            or (
                state
                in {
                    "TRIAL_OUTCOME_PASS_NO_PROMOTION",
                    "TRIAL_OUTCOME_INCONCLUSIVE_NO_PROMOTION",
                }
                and rollback
            )
        ):
            contract_violations += 1

        runtime_id = _text(
            item.get("source_runtime_event_id")
        )
        runtime_hash = _text(
            item.get("source_runtime_event_hash")
        )

        if runtime_id or runtime_hash:
            parent = runtime_index.get(
                runtime_id
            )
            if (
                not parent
                or _text(
                    controlled_trial_runtime_snapshot_integrity(
                        parent
                    ).get("status")
                ).upper()
                != "OK"
                or _text(
                    parent.get("snapshot_hash")
                )
                != runtime_hash
            ):
                lineage_violations += 1
            else:
                parent_ts = pd.to_datetime(
                    parent.get("created_at"),
                    errors="coerce",
                    utc=True,
                )
                audit_ts = pd.to_datetime(
                    item.get("created_at"),
                    errors="coerce",
                    utc=True,
                )
                if (
                    pd.isna(parent_ts)
                    or pd.isna(audit_ts)
                    or audit_ts <= parent_ts
                ):
                    time_order_violations += 1

        proposal_id = _text(
            item.get("source_proposal_id")
        )
        proposal_hash = _text(
            item.get("source_proposal_hash")
        )

        if _text(
            item.get("source_proposal_integrity")
        ).upper() == "OK":
            parent = proposal_index.get(
                proposal_id
            )
            if (
                not parent
                or _text(
                    recalibration_proposal_snapshot_integrity(
                        parent
                    ).get("status")
                ).upper()
                != "OK"
                or _text(
                    parent.get("snapshot_hash")
                )
                != proposal_hash
            ):
                lineage_violations += 1

        ids = _json_list(
            item.get("evidence_outcome_ids_json")
        )
        hashes = _json_list(
            item.get("evidence_outcome_hashes_json")
        )
        eligible = _int(
            item.get("eligible_trial_outcomes")
        )

        if (
            len(ids) != eligible
            or len(hashes) != eligible
            or len(set(ids)) != len(ids)
        ):
            evidence_violations += 1
        else:
            for evidence_id, evidence_hash in zip(
                ids,
                hashes,
            ):
                parent = qualified_index.get(
                    evidence_id
                )
                if (
                    not parent
                    or _text(
                        flow_projection_outcome_snapshot_integrity(
                            parent
                        ).get("status")
                    ).upper()
                    != "OK"
                    or _text(
                        parent.get("snapshot_hash")
                    )
                    != evidence_hash
                ):
                    evidence_violations += 1
                    break

        for field in [
            "trial_outcome_authorization",
            "trial_runtime_authorization",
            "trial_start_authorization",
            "recalibration_authorization",
            "capacity_authorization",
            "execution_authorization",
        ]:
            if _text(
                item.get(field)
            ).upper() not in {"", "NONE"}:
                authorization_violations += 1

    checks = []

    checks.append(
        _audit_row(
            "Controlled Trial Outcome Audit Snapshot Integrity",
            (
                _int(counts.get("missing")) == 0
                and _int(counts.get("mismatch")) == 0
            ),
            (
                f"records {_int(counts.get('total'))} · "
                f"OK {_int(counts.get('ok'))} · "
                f"MISSING {_int(counts.get('missing'))} · "
                f"MISMATCH {_int(counts.get('mismatch'))}"
            ),
            "Controlled Trial Outcome immutable hash 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Outcome Audit State / Rollback Contract",
            contract_violations == 0,
            f"contract violations {contract_violations}",
            "Outcome state/guard/rollback/no-promotion contract 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Outcome Audit → Runtime / Proposal Lineage",
            (
                lineage_violations == 0
                and runtime_duplicates == 0
                and proposal_duplicates == 0
            ),
            (
                f"violations {lineage_violations} · "
                f"runtime duplicate ids {runtime_duplicates} · "
                f"proposal duplicate ids {proposal_duplicates}"
            ),
            "Outcome source Runtime / Proposal id/hash lineage 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Outcome Audit Evidence / Identity / Time-order Invariant",
            (
                evidence_violations == 0
                and identity_duplicates == 0
                and time_order_violations == 0
                and qualified_duplicates == 0
            ),
            (
                f"evidence violations {evidence_violations} · "
                f"duplicate audit ids {identity_duplicates} · "
                f"time-order violations {time_order_violations} · "
                f"qualified duplicate ids {qualified_duplicates}"
            ),
            "Trial evidence id/hash, audit identity, Runtime→Outcome 저장 순서 확인",
        )
    )

    checks.append(
        _audit_row(
            "Controlled Trial Outcome Audit No-Live-Authorization Invariant",
            authorization_violations == 0,
            (
                "NONE"
                if authorization_violations == 0
                else f"non-NONE sources {authorization_violations}"
            ),
            "Trial Outcome/Runtime/Start/Recalibration/Capacity/Execution Authorization을 NONE으로 유지",
        )
    )

    technical_fail = sum(
        1
        for row in checks
        if row["status"] == "FAIL"
    )

    current_state = _text(
        (ctx.get("outcome") or {}).get(
            "outcome_state"
        )
    ).upper()

    operating_status = (
        "PASS"
        if current_state
        in {
            "TRIAL_OUTCOME_NOT_REQUIRED",
        }
        else "REVIEW"
    )

    checks.append(
        {
            "layer": "OPERATING",
            "check": "Controlled Trial Outcome Audit Operating Stage",
            "status": operating_status,
            "detail": (
                f"current outcome {current_state or 'MISSING'} · "
                f"saved outcomes {_int(counts.get('total'))}"
            ),
            "action": (
                ""
                if operating_status == "PASS"
                else (
                    "실제 completed Runtime evidence가 생긴 뒤 Trial Outcome/rollback closure가 필요할 때만 "
                    "Outcome audit history를 저장"
                )
            ),
        }
    )

    return {
        "release_gate": (
            "PASS"
            if technical_fail == 0
            else "BLOCKED"
        ),
        "technical_pass": sum(
            1
            for row in checks
            if (
                row["layer"] == "TECHNICAL"
                and row["status"] == "PASS"
            )
        ),
        "technical_fail": technical_fail,
        "operating_status": operating_status,
        "checks": pd.DataFrame(
            checks,
            columns=TRIAL_OUTCOME_AUDIT_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def _candidate_row(
    check: str,
    passed: bool,
    detail: str,
) -> dict:
    return {
        "check": check,
        "status": "PASS" if passed else "BLOCKED",
        "detail": detail,
        "blocking": "NO" if passed else "YES",
    }


def build_v144_release_readiness(
    *,
    v143_release_status: str,
    integration_consistency: str,
    csv_fail_count: int,
    trial_outcome_release_gate: str,
    trial_outcome_audit_gate: str,
    trial_outcome_operating_status: str,
    audit_operating_status: str,
    execution_authorization: str,
) -> dict:
    checks = [
        _candidate_row(
            "v1.43 Controlled Trial Runtime Release Baseline",
            _text(
                v143_release_status
            ).upper()
            == "READY_FOR_RELEASE_REVIEW",
            _text(
                v143_release_status
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Outcome Technical Release Gate",
            _text(
                trial_outcome_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_outcome_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Outcome Audit Integrity Gate",
            _text(
                trial_outcome_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_outcome_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Execution Authorization Invariant",
            _text(
                execution_authorization
            ).upper()
            == "NONE",
            _text(
                execution_authorization
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    operating_reviews = []

    if (
        _text(
            trial_outcome_operating_status
        ).upper()
        != "PASS"
        or _text(
            audit_operating_status
        ).upper()
        != "PASS"
    ):
        operating_reviews.append(
            "CONTROLLED_TRIAL_OUTCOME_REVIEW"
        )

    return {
        "status": (
            "READY_FOR_RELEASE_REVIEW"
            if not blockers
            else "BLOCKED"
        ),
        "blocking_count": len(blockers),
        "blockers": blockers,
        "operating_review_count": len(
            operating_reviews
        ),
        "operating_reviews": operating_reviews,
        "checks": pd.DataFrame(
            checks,
            columns=V144_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v144_integration_crosscheck(
    *,
    integration_consistency: str,
    trial_outcome_release_gate: str,
    trial_outcome_audit_gate: str,
) -> dict:
    checks = [
        _candidate_row(
            "System Integration Consistency",
            _text(
                integration_consistency
            ).upper()
            == "PASS",
            _text(
                integration_consistency
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Outcome Technical Gate",
            _text(
                trial_outcome_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_outcome_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Outcome Audit Gate",
            _text(
                trial_outcome_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_outcome_audit_gate
            ).upper()
            or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V144_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }


def build_v144_data_crosscheck(
    *,
    csv_fail_count: int,
    trial_outcome_release_gate: str,
    trial_outcome_audit_gate: str,
    latest_trial_outcome_integrity: str,
) -> dict:
    latest = _text(
        latest_trial_outcome_integrity
    ).upper()

    checks = [
        _candidate_row(
            "Save Center CSV Health",
            _int(csv_fail_count) == 0,
            f"CSV FAIL {_int(csv_fail_count)}",
        ),
        _candidate_row(
            "Controlled Trial Outcome Technical Gate",
            _text(
                trial_outcome_release_gate
            ).upper()
            == "PASS",
            _text(
                trial_outcome_release_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Controlled Trial Outcome Audit Gate",
            _text(
                trial_outcome_audit_gate
            ).upper()
            == "PASS",
            _text(
                trial_outcome_audit_gate
            ).upper()
            or "MISSING",
        ),
        _candidate_row(
            "Latest Controlled Trial Outcome Audit Integrity",
            latest in {
                "OK",
                "NONE",
            },
            latest or "MISSING",
        ),
    ]

    blockers = [
        row["check"]
        for row in checks
        if row["status"] != "PASS"
    ]

    return {
        "status": "PASS" if not blockers else "BLOCKED",
        "blocking_count": len(blockers),
        "checks": pd.DataFrame(
            checks,
            columns=V144_CANDIDATE_CHECK_COLS,
        ),
        "execution_authorization": "NONE",
    }
