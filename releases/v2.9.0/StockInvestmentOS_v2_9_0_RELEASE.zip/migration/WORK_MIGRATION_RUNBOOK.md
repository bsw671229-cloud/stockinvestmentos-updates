# Work-ready Project Migration Runbook

## Target layout

```text
<target-home>/
├─ work/                    <- authorize this folder to Work
│  ├─ app/                  <- canonical code root
│  │  ├─ app.py
│  │  ├─ engine/
│  │  ├─ updater/
│  │  ├─ migration/
│  │  ├─ WORK_READY_LAYOUT.json
│  │  └─ data -> ../../runtime-data
│  └─ control/
│     ├─ releases/
│     ├─ backups/
│     ├─ update_logs/
│     └─ migration/
├─ runtime-data/            <- outside Work root
├─ secrets/                 <- outside Work root
└─ run_work_ready.bat
```

The migration is copy-based and non-destructive. The existing installation
remains the immediate rollback path.

## Before migration

Stop Streamlit before the actual migration so runtime CSV files are not changing
during the integrity copy.

## Plan

```bat
python -m migration.migrate_work_ready plan
```

or:

```bat
python -m migration.migrate_work_ready plan --target D:\StockInvestmentOS_WorkReady
```

## Execute

```bat
python -m migration.migrate_work_ready migrate --target D:\StockInvestmentOS_WorkReady
```

Expected final status: `READY_FOR_WORK_CUTOVER`.

## Verify

```bat
python -m migration.migrate_work_ready verify --target D:\StockInvestmentOS_WorkReady
```

Required PASS checks:
- code_integrity
- runtime_data_integrity
- secrets_integrity
- data_compatibility_link
- data_secrets_separation
- migration_receipt

## Cutover

Do not delete the old project. Start the migrated project with:

```text
D:\StockInvestmentOS_WorkReady\run_work_ready.bat
```

Confirm Dashboard, Save Center, Stability Audit, Migration Manager and Release
Manager before treating the migrated instance as canonical.

## Work authorization

Authorize only:

```text
D:\StockInvestmentOS_WorkReady\work
```

Keep `runtime-data/` and `secrets/` outside the Work-authorized root unless a
specific task explicitly requires additional access.

## Release Manager after migration

From `<target-home>\work\app`:

```bat
python updater\update_manager.py status
python updater\update_manager.py scan
python updater\update_manager.py auto-update
```

Operational updater folders are routed to `<target-home>\work\control`.

## Rollback

Migration itself never deletes the original installation. Stop the migrated
instance and start the original project. Review/delete the target only after
confirming the original remains healthy.

Migration and software-update approval never create investment Execution
Authorization.


## Launcher Hotfix

The top-level `run_work_ready.bat` delegates to the verified
`work\app\run.bat`. It does not guess a system Python interpreter.

Repair an existing migrated installation:

```bat
python -m migration.migrate_work_ready repair-launcher --target <TARGET_HOME>
```


## Post-update Migration Integrity semantics

`MIGRATION_CODE_MANIFEST.json` is the historical code-transfer receipt from the
initial migration. It proves that an initial transfer record exists.

After a sanctioned hotfix or RELEASE, current application code is expected to
change. Current code integrity is therefore checked against the active managed
baseline:

- development: `managed_code_manifest.json`
- final RELEASE: `manifest_sha256.json`

Runtime-data and secrets keep their own independent migration integrity
receipts. A sanctioned code update must not require re-migration.


## Mutable protected roots after cutover

Migration-time runtime-data/secrets hashes are historical transfer evidence.

After cutover, runtime-data and secrets are expected to change. Normal
Migration Integrity verification therefore does not read or re-hash protected
file contents. It validates historical transfer PASS, protected-root existence,
physical separation, compatibility link, launcher, layout, and current managed
code.
