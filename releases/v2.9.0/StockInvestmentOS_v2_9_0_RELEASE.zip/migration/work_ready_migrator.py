from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any


LAYOUT_MODE = "WORK_READY_SEPARATED"
LAYOUT_FILE = "WORK_READY_LAYOUT.json"
MIGRATION_MARKER = "WORK_READY_MIGRATION_RECEIPT.json"
MANAGED_BASELINE = "managed_code_manifest.json"

CODE_EXCLUDE_TOP = {
    "data",
    "runtime-data",
    "releases",
    "backups",
    "update_logs",
    ".update_staging",
    ".git",
    ".venv",
    "venv",
    "__pycache__",
}

SECRET_NAMES = {
    ".env",
    ".env.local",
    ".env.production",
}


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_resolve(path: Path) -> Path:
    try:
        return Path(path).expanduser().resolve()
    except Exception:
        return Path(path).expanduser().absolute()


def _is_relative_to(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except Exception:
        return False


def _iter_code_files(source_root: Path):
    source_root = _safe_resolve(source_root)

    for path in source_root.rglob("*"):
        if not path.is_file():
            continue

        rel = path.relative_to(source_root)
        if not rel.parts:
            continue

        if rel.parts[0] in CODE_EXCLUDE_TOP:
            continue

        if path.name in SECRET_NAMES:
            continue

        if path.suffix.lower() == ".pyc":
            continue

        if "__pycache__" in rel.parts:
            continue

        yield path, rel


def _tree_digest(
    root: Path,
    *,
    exclude_names: set[str] | None = None,
) -> dict[str, Any]:
    root = _safe_resolve(root)
    exclude_names = exclude_names or set()

    if not root.exists():
        return {
            "exists": False,
            "files": 0,
            "bytes": 0,
            "digest": "",
            "symlink_count": 0,
        }

    if not root.is_dir():
        raise ValueError(f"Expected directory: {root}")

    h = hashlib.sha256()
    count = 0
    total = 0
    symlinks = 0

    for path in sorted(
        root.rglob("*"),
        key=lambda p: str(p.relative_to(root)).lower(),
    ):
        if path.name in exclude_names:
            continue

        if path.is_symlink():
            symlinks += 1
            continue

        if not path.is_file():
            continue

        rel = path.relative_to(root).as_posix()
        digest = _sha256_file(path)
        size = path.stat().st_size

        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(digest.encode("ascii"))
        h.update(b"\0")
        h.update(str(size).encode("ascii"))
        h.update(b"\n")

        count += 1
        total += size

    return {
        "exists": True,
        "files": count,
        "bytes": total,
        "digest": h.hexdigest(),
        "symlink_count": symlinks,
    }


def _code_digest(source_root: Path) -> dict[str, Any]:
    h = hashlib.sha256()
    count = 0
    total = 0

    for path, rel in sorted(
        _iter_code_files(source_root),
        key=lambda item: item[1].as_posix().lower(),
    ):
        digest = _sha256_file(path)
        size = path.stat().st_size

        h.update(rel.as_posix().encode("utf-8"))
        h.update(b"\0")
        h.update(digest.encode("ascii"))
        h.update(b"\0")
        h.update(str(size).encode("ascii"))
        h.update(b"\n")

        count += 1
        total += size

    return {
        "files": count,
        "bytes": total,
        "digest": h.hexdigest(),
    }


def _secrets_digest(source_root: Path) -> dict[str, Any]:
    h = hashlib.sha256()
    count = 0
    total = 0

    for name in sorted(SECRET_NAMES):
        path = source_root / name
        if not path.is_file():
            continue

        digest = _sha256_file(path)
        size = path.stat().st_size

        h.update(name.encode("utf-8"))
        h.update(b"\0")
        h.update(digest.encode("ascii"))
        h.update(b"\n")

        count += 1
        total += size

    return {
        "files": count,
        "bytes": total,
        "digest": h.hexdigest(),
    }


def _read_version(root: Path) -> str:
    path = root / "VERSION"
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8").strip()


def _read_managed_baseline(root: Path) -> dict[str, str]:
    dev = root / MANAGED_BASELINE

    if dev.is_file():
        try:
            data = json.loads(dev.read_text(encoding="utf-8"))
        except Exception:
            data = {}

        if (
            isinstance(data, dict)
            and data.get("version") == _read_version(root)
            and isinstance(data.get("files"), dict)
        ):
            return {
                str(k).replace("\\", "/"): str(v).strip().lower()
                for k, v in data["files"].items()
            }

    release_manifest = root / "manifest_sha256.json"

    if release_manifest.is_file():
        try:
            data = json.loads(release_manifest.read_text(encoding="utf-8"))
        except Exception:
            data = {}

        if isinstance(data, dict):
            return {
                str(k).replace("\\", "/"): str(v).strip().lower()
                for k, v in data.items()
            }

    return {}


def _managed_drift(root: Path) -> dict[str, Any]:
    manifest = _read_managed_baseline(root)
    missing = []
    mismatch = []

    for rel, expected in manifest.items():
        path = root / rel

        if not path.is_file():
            missing.append(rel)
            continue

        if _sha256_file(path) != expected:
            mismatch.append(rel)

    return {
        "tracked": len(manifest),
        "missing": missing,
        "mismatch": mismatch,
        "clean": bool(manifest) and not missing and not mismatch,
    }


def _target_paths(target_home: Path) -> dict[str, Path]:
    home = _safe_resolve(target_home)

    return {
        "home": home,
        "work": home / "work",
        "code": home / "work" / "app",
        "control": home / "work" / "control",
        "runtime_data": home / "runtime-data",
        "secrets": home / "secrets",
        "launcher": home / "run_work_ready.bat",
        "migration_receipt": (
            home
            / "work"
            / "control"
            / "migration"
            / MIGRATION_MARKER
        ),
        "code_manifest": (
            home
            / "work"
            / "control"
            / "migration"
            / "MIGRATION_CODE_MANIFEST.json"
        ),
    }


def default_target_home(source_root: Path) -> Path:
    source_root = _safe_resolve(source_root)
    return source_root.parent / (source_root.name + "_work_ready")


def plan_migration(
    source_root: Path,
    target_home: Path | None = None,
) -> dict[str, Any]:
    source = _safe_resolve(source_root)
    target = _safe_resolve(
        target_home or default_target_home(source)
    )
    paths = _target_paths(target)

    blockers = []
    warnings = []

    if target == source:
        blockers.append("Migration target must not equal source root.")

    if _is_relative_to(target, source):
        blockers.append("Migration target must not be inside the source project.")

    if target.exists() and any(target.iterdir()):
        blockers.append(
            "Migration target already exists and is not empty. "
            "Use a new target or verify the existing migration separately."
        )

    drift = _managed_drift(source)

    if not drift["clean"]:
        blockers.append(
            "Source managed-code baseline is not clean. "
            f"missing={drift['missing'][:10]}, mismatch={drift['mismatch'][:10]}"
        )

    data_summary = _tree_digest(source / "data")

    if data_summary["symlink_count"]:
        blockers.append(
            "Source data/ contains symlinks. Resolve them before migration."
        )

    code_summary = _code_digest(source)
    secret_summary = _secrets_digest(source)

    if secret_summary["files"] == 0:
        warnings.append(
            "No .env-style secret file was found. "
            "Migration will create an empty external secrets directory."
        )

    if (source / LAYOUT_FILE).is_file():
        warnings.append(
            "Source already contains WORK_READY_LAYOUT.json. "
            "Verify whether this is already a migrated code root."
        )

    total_bytes = (
        code_summary["bytes"]
        + data_summary["bytes"]
        + secret_summary["bytes"]
    )

    return {
        "status": "READY" if not blockers else "BLOCKED",
        "eligible": not blockers,
        "source_root": str(source),
        "source_version": _read_version(source),
        "target_home": str(target),
        "work_root": str(paths["work"]),
        "code_root": str(paths["code"]),
        "runtime_data_root": str(paths["runtime_data"]),
        "secrets_root": str(paths["secrets"]),
        "control_root": str(paths["control"]),
        "managed_code": drift,
        "code_summary": code_summary,
        "data_summary": {
            "exists": data_summary["exists"],
            "files": data_summary["files"],
            "bytes": data_summary["bytes"],
        },
        "secret_summary": {
            "files": secret_summary["files"],
            "bytes": secret_summary["bytes"],
        },
        "estimated_copy_bytes": total_bytes,
        "blockers": blockers,
        "warnings": warnings,
        "source_digests": {
            "code": code_summary["digest"],
            "data": data_summary["digest"],
            "secrets": secret_summary["digest"],
        },
    }


def _copy_code(
    source: Path,
    target_code: Path,
) -> dict[str, str]:
    manifest = {}

    for src, rel in _iter_code_files(source):
        dst = target_code / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        manifest[rel.as_posix()] = _sha256_file(dst)

    return manifest


def _copy_tree_if_exists(source: Path, target: Path) -> None:
    if not source.exists():
        return

    if source.is_symlink():
        raise ValueError(
            f"Refusing to copy symlinked source directory: {source}"
        )

    shutil.copytree(
        source,
        target,
        dirs_exist_ok=True,
        symlinks=False,
    )


def _copy_legacy_control(source: Path, control: Path) -> None:
    for src_name in ["releases", "update_logs"]:
        src = source / src_name
        if src.is_dir():
            _copy_tree_if_exists(src, control / src_name)

    legacy_release_backups = source / "backups" / "release_manager"
    if legacy_release_backups.is_dir():
        _copy_tree_if_exists(
            legacy_release_backups,
            control / "backups" / "release_manager",
        )


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        )
        + "\n",
        encoding="utf-8",
    )


def _create_directory_link(link: Path, target: Path) -> dict[str, Any]:
    link = Path(link)
    target = _safe_resolve(target)

    if link.exists() or link.is_symlink():
        raise ValueError(f"Compatibility data link already exists: {link}")

    link.parent.mkdir(parents=True, exist_ok=True)

    if os.name == "nt":
        proc = subprocess.run(
            ["cmd", "/c", "mklink", "/J", str(link), str(target)],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "Windows directory junction creation failed: "
                + (proc.stderr.strip() or proc.stdout.strip())
            )
        kind = "WINDOWS_JUNCTION"
    else:
        os.symlink(target, link, target_is_directory=True)
        kind = "DIRECTORY_SYMLINK"

    if link.resolve() != target:
        raise RuntimeError(
            f"Data link resolves to {link.resolve()}, expected {target}."
        )

    return {
        "kind": kind,
        "link": str(link),
        "target": str(target),
    }


def _launcher_text() -> str:
    return r"""@echo off
setlocal
set "STOCK_OS_WORK_READY_HOME=%~dp0"

if not exist "%~dp0work\app\run.bat" (
    echo [ERROR] work\app\run.bat was not found.
    echo Use the verified launcher inside work\app or repair the Work-ready launcher.
    endlocal & exit /b 2
)

call "%~dp0work\app\run.bat"
set ERR=%ERRORLEVEL%
endlocal & exit /b %ERR%
"""


def _write_launcher(path: Path) -> None:
    path.write_text(
        _launcher_text(),
        encoding="utf-8",
    )


def repair_work_ready_launcher(
    target_home: Path,
) -> dict[str, Any]:
    target = _safe_resolve(target_home)
    paths = _target_paths(target)
    delegated = paths["code"] / "run.bat"

    if not delegated.is_file():
        return {
            "status": "BLOCKED",
            "target_home": str(target),
            "blockers": [
                "work/app/run.bat is missing. The launcher will not guess a Python interpreter."
            ],
        }

    before_hash = (
        _sha256_file(paths["launcher"])
        if paths["launcher"].is_file()
        else ""
    )

    _write_launcher(paths["launcher"])

    content = paths["launcher"].read_text(encoding="utf-8")
    valid = (
        'call "%~dp0work\\app\\run.bat"' in content
        and "python -m streamlit" not in content.lower()
    )

    return {
        "status": "REPAIRED" if valid else "FAILED",
        "target_home": str(target),
        "launcher": str(paths["launcher"]),
        "delegated_launcher": str(delegated),
        "before_sha256": before_hash,
        "after_sha256": _sha256_file(paths["launcher"]),
        "verification": "PASS" if valid else "FAIL",
        "restart_required": False,
    }

def _harden_secret_file(path: Path) -> None:
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass


def execute_migration(
    source_root: Path,
    target_home: Path | None = None,
) -> dict[str, Any]:
    source = _safe_resolve(source_root)
    plan = plan_migration(source, target_home)

    if not plan["eligible"]:
        return {
            "status": "BLOCKED",
            "plan": plan,
            "blockers": plan["blockers"],
        }

    target = Path(plan["target_home"])
    paths = _target_paths(target)
    before = plan["source_digests"]

    try:
        paths["code"].mkdir(parents=True, exist_ok=False)
        paths["runtime_data"].mkdir(parents=True, exist_ok=False)
        paths["secrets"].mkdir(parents=True, exist_ok=False)
        paths["control"].mkdir(parents=True, exist_ok=True)

        code_manifest = _copy_code(source, paths["code"])

        if (source / "data").is_dir():
            _copy_tree_if_exists(
                source / "data",
                paths["runtime_data"],
            )

        for name in sorted(SECRET_NAMES):
            src = source / name
            if not src.is_file():
                continue
            dst = paths["secrets"] / name
            shutil.copy2(src, dst)
            _harden_secret_file(dst)

        _copy_legacy_control(source, paths["control"])

        layout = {
            "schema_version": 1,
            "mode": LAYOUT_MODE,
            "created_at": _now(),
            "source_version": plan["source_version"],
            "home_rel": "../..",
            "work_root_rel": "..",
            "runtime_data_rel": "../../runtime-data",
            "secrets_rel": "../../secrets",
            "secret_env_rel": "../../secrets/.env",
            "control_rel": "../control",
            "data_compatibility_path": "data",
            "work_authorization_recommendation": (
                "Authorize only work/ to Work. Do not authorize secrets/ "
                "unless explicitly needed."
            ),
        }

        _write_json(paths["code"] / LAYOUT_FILE, layout)
        code_manifest[LAYOUT_FILE] = _sha256_file(
            paths["code"] / LAYOUT_FILE
        )

        data_link = _create_directory_link(
            paths["code"] / "data",
            paths["runtime_data"],
        )

        _write_launcher(paths["launcher"])

        data_integrity = _tree_digest(
            paths["runtime_data"],
            exclude_names={".migration_integrity.json"},
        )
        _write_json(
            paths["runtime_data"] / ".migration_integrity.json",
            {
                "schema_version": 1,
                "created_at": _now(),
                "files": data_integrity["files"],
                "bytes": data_integrity["bytes"],
                "digest": data_integrity["digest"],
            },
        )

        secrets_integrity = _tree_digest(
            paths["secrets"],
            exclude_names={".migration_integrity.json"},
        )
        _write_json(
            paths["secrets"] / ".migration_integrity.json",
            {
                "schema_version": 1,
                "created_at": _now(),
                "files": secrets_integrity["files"],
                "bytes": secrets_integrity["bytes"],
                "digest": secrets_integrity["digest"],
            },
        )
        _harden_secret_file(
            paths["secrets"] / ".migration_integrity.json"
        )

        _write_json(
            paths["code_manifest"],
            {
                "schema_version": 1,
                "created_at": _now(),
                "files": code_manifest,
            },
        )

        for p in [
            paths["control"] / "releases" / "inbox",
            paths["control"] / "releases" / "approved",
            paths["control"] / "releases" / "archive",
            paths["control"] / "backups" / "release_manager",
            paths["control"] / "update_logs",
            paths["control"] / ".update_staging",
            paths["control"] / "migration",
        ]:
            p.mkdir(parents=True, exist_ok=True)

        after_source = {
            "code": _code_digest(source)["digest"],
            "data": _tree_digest(source / "data")["digest"],
            "secrets": _secrets_digest(source)["digest"],
        }

        source_unchanged = before == after_source

        if not source_unchanged:
            raise RuntimeError(
                "Source project changed during migration. Cutover is blocked."
            )

        if before["data"] != data_integrity["digest"]:
            raise RuntimeError("Runtime-data integrity mismatch after copy.")

        target_secret_digest = _secrets_digest(
            paths["secrets"]
        )["digest"]

        if before["secrets"] != target_secret_digest:
            raise RuntimeError("Secret-file integrity mismatch after copy.")

        receipt = {
            "schema_version": 1,
            "migration_id": (
                "MIG-"
                + datetime.now().astimezone().strftime("%Y%m%dT%H%M%S")
            ),
            "created_at": _now(),
            "status": "READY_FOR_WORK_CUTOVER",
            "source_root": str(source),
            "source_version": plan["source_version"],
            "target_home": str(target),
            "work_root": str(paths["work"]),
            "code_root": str(paths["code"]),
            "runtime_data_root": str(paths["runtime_data"]),
            "secrets_root": str(paths["secrets"]),
            "control_root": str(paths["control"]),
            "source_unchanged": source_unchanged,
            "managed_code_source_clean": plan["managed_code"]["clean"],
            "code_files": len(code_manifest),
            "runtime_data_files": data_integrity["files"],
            "secret_files": secrets_integrity["files"],
            "runtime_data_integrity": "PASS",
            "secrets_integrity": "PASS",
            "data_link": data_link,
            "launcher": str(paths["launcher"]),
            "work_authorization": (
                "Authorize work/ only. runtime-data/ and secrets/ remain "
                "outside the Work root."
            ),
            "rollback_strategy": (
                "Non-destructive migration: original source is unchanged. "
                "Rollback is launching the original source project."
            ),
        }

        _write_json(paths["migration_receipt"], receipt)

        verification = verify_migration(target)

        if verification["status"] != "READY_FOR_WORK_CUTOVER":
            raise RuntimeError(
                "Post-migration verification failed: "
                + " | ".join(verification.get("blockers", []))
            )

        return {
            "status": "READY_FOR_WORK_CUTOVER",
            "source_root": str(source),
            "target_home": str(target),
            "work_root": str(paths["work"]),
            "code_root": str(paths["code"]),
            "runtime_data_root": str(paths["runtime_data"]),
            "secrets_root": str(paths["secrets"]),
            "control_root": str(paths["control"]),
            "launcher": str(paths["launcher"]),
            "receipt": str(paths["migration_receipt"]),
            "source_unchanged": True,
            "verification": verification,
        }

    except Exception as exc:
        return {
            "status": "FAILED",
            "target_home": str(target),
            "error": f"{type(exc).__name__}: {exc}",
            "source_unchanged_expected": True,
            "recovery": (
                "Do not cut over. Continue using the original source project. "
                "Delete the incomplete target manually only after review."
            ),
        }


def _read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def verify_migration(target_home: Path) -> dict[str, Any]:
    target = _safe_resolve(target_home)
    paths = _target_paths(target)
    blockers = []
    checks = {}

    layout = _read_json(paths["code"] / LAYOUT_FILE)
    layout_ok = (
        layout.get("schema_version") == 1
        and layout.get("mode") == LAYOUT_MODE
    )
    checks["layout_config"] = "PASS" if layout_ok else "FAIL"
    if not layout_ok:
        blockers.append("WORK_READY_LAYOUT.json missing or invalid.")

    # Historical transfer receipt: proves what was copied at the original
    # migration. Legitimate updater/hotfix activity changes code afterward,
    # so the initial migration hashes must not be treated as the permanent
    # live-code baseline.
    transfer_manifest_data = _read_json(
        paths["code_manifest"]
    )
    transfer_manifest = transfer_manifest_data.get(
        "files",
        {},
    )
    transfer_receipt_ok = (
        isinstance(
            transfer_manifest,
            dict,
        )
        and bool(
            transfer_manifest
        )
    )

    checks["migration_transfer_receipt"] = (
        "PASS"
        if transfer_receipt_ok
        else "FAIL"
    )

    if not transfer_receipt_ok:
        blockers.append(
            "Historical migration code-transfer receipt is missing or invalid."
        )

    # Current code integrity follows the current managed baseline:
    # managed_code_manifest.json for development builds, or the final release
    # manifest after a final RELEASE.
    current_code = _managed_drift(
        paths["code"]
    )

    checks["code_integrity"] = (
        "PASS"
        if current_code["clean"]
        else "FAIL"
    )

    if not current_code["clean"]:
        blockers.append(
            "Current managed code integrity mismatch: "
            f"missing={current_code['missing'][:10]}, "
            f"mismatch={current_code['mismatch'][:10]}"
        )

    # runtime-data/ and secrets/ are intentionally mutable after cutover.
    # Migration-time digests are historical transfer evidence, not permanent
    # live-content locks. Current verification does not read/re-hash protected
    # file contents.
    migration_receipt_preview = _read_json(
        paths["migration_receipt"]
    )

    runtime_root_ok = (
        paths["runtime_data"].is_dir()
        and not paths["runtime_data"].is_symlink()
    )
    historical_runtime_ok = (
        migration_receipt_preview.get("runtime_data_integrity")
        == "PASS"
    )
    data_ok = (
        runtime_root_ok
        and historical_runtime_ok
    )
    checks["runtime_data_integrity"] = "PASS" if data_ok else "FAIL"
    if not data_ok:
        blockers.append(
            "Runtime-data protected-root / historical-transfer receipt check failed."
        )

    secrets_root_ok = (
        paths["secrets"].is_dir()
        and not paths["secrets"].is_symlink()
    )
    historical_secrets_ok = (
        migration_receipt_preview.get("secrets_integrity")
        == "PASS"
    )
    secrets_ok = (
        secrets_root_ok
        and historical_secrets_ok
    )
    checks["secrets_integrity"] = "PASS" if secrets_ok else "FAIL"
    if not secrets_ok:
        blockers.append(
            "Secrets protected-root / historical-transfer receipt check failed."
        )

    data_link = paths["code"] / "data"
    try:
        link_ok = (
            data_link.exists()
            and data_link.resolve() == paths["runtime_data"].resolve()
        )
    except Exception:
        link_ok = False

    checks["data_compatibility_link"] = "PASS" if link_ok else "FAIL"
    if not link_ok:
        blockers.append(
            "code/data compatibility link does not resolve to runtime-data."
        )

    secret_inside_work = any(
        (paths["work"] / name).exists()
        for name in SECRET_NAMES
    )
    secret_inside_code = any(
        (paths["code"] / name).exists()
        for name in SECRET_NAMES
    )

    separation_ok = (
        not _is_relative_to(paths["runtime_data"], paths["work"])
        and not _is_relative_to(paths["secrets"], paths["work"])
        and not secret_inside_work
        and not secret_inside_code
    )
    checks["data_secrets_separation"] = (
        "PASS" if separation_ok else "FAIL"
    )
    if not separation_ok:
        blockers.append(
            "runtime-data/secrets are not physically separated from Work root."
        )

    launcher_ok = False

    if paths["launcher"].is_file():
        try:
            launcher_text = paths["launcher"].read_text(encoding="utf-8")
            launcher_ok = (
                'call "%~dp0work\\app\\run.bat"' in launcher_text
                and "python -m streamlit" not in launcher_text.lower()
                and (paths["code"] / "run.bat").is_file()
            )
        except Exception:
            launcher_ok = False

    checks["launcher"] = "PASS" if launcher_ok else "FAIL"

    if not launcher_ok:
        blockers.append(
            "run_work_ready.bat missing or not delegated to work/app/run.bat."
        )

    receipt = _read_json(paths["migration_receipt"])
    receipt_ok = (
        receipt.get("status") == "READY_FOR_WORK_CUTOVER"
        and receipt.get("source_unchanged") is True
    )
    checks["migration_receipt"] = "PASS" if receipt_ok else "FAIL"
    if not receipt_ok:
        blockers.append("Migration receipt missing or not ready.")

    return {
        "status": (
            "READY_FOR_WORK_CUTOVER"
            if not blockers
            else "BLOCKED"
        ),
        "target_home": str(target),
        "work_root": str(paths["work"]),
        "code_root": str(paths["code"]),
        "runtime_data_root": str(paths["runtime_data"]),
        "secrets_root": str(paths["secrets"]),
        "control_root": str(paths["control"]),
        "checks": checks,
        "blockers": blockers,
        "current_managed_code": current_code,
        "migration_transfer_receipt_files": (
            len(transfer_manifest)
            if isinstance(transfer_manifest, dict)
            else 0
        ),
        "integrity_semantics": (
            "Historical migration transfer receipt is immutable history; "
            "current code integrity follows the active managed-code baseline; "
            "runtime-data/secrets are mutable protected roots and are not "
            "content-rehashed after cutover."
        ),
        "work_authorization": (
            "Grant Work access to work/ only. Keep secrets/ and runtime-data/ "
            "outside the Work-authorized root."
        ),
        "launcher": str(paths["launcher"]),
    }


def _print(data: Any) -> None:
    print(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        )
    )


def cli(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Stock Investment OS Work-ready non-destructive project migrator."
        )
    )
    parser.add_argument(
        "--source",
        default=".",
        help="Legacy/current project root. Default: current directory.",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    plan_p = sub.add_parser("plan")
    plan_p.add_argument("--target", default="")

    exec_p = sub.add_parser("migrate")
    exec_p.add_argument("--target", default="")

    verify_p = sub.add_parser("verify")
    verify_p.add_argument("--target", required=True)

    repair_p = sub.add_parser("repair-launcher")
    repair_p.add_argument("--target", required=True)

    args = parser.parse_args(argv)
    source = _safe_resolve(Path(args.source))

    if args.command == "plan":
        result = plan_migration(
            source,
            Path(args.target) if args.target else None,
        )
    elif args.command == "migrate":
        result = execute_migration(
            source,
            Path(args.target) if args.target else None,
        )
    elif args.command == "verify":
        result = verify_migration(
            Path(args.target)
        )
    else:
        result = repair_work_ready_launcher(
            Path(args.target)
        )

    _print(result)

    return (
        0
        if result.get("status")
        in {"READY", "READY_FOR_WORK_CUTOVER", "REPAIRED"}
        else 2
    )


if __name__ == "__main__":
    raise SystemExit(cli())
