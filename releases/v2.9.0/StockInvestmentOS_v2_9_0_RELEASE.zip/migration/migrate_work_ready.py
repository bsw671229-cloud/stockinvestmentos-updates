from migration.work_ready_migrator import cli

if __name__ == "__main__":
    raise SystemExit(cli())
