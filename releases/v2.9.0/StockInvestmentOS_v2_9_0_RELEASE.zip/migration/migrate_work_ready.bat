@echo off
setlocal
cd /d "%~dp0\.."
python -m migration.migrate_work_ready %*
set ERR=%ERRORLEVEL%
endlocal & exit /b %ERR%
