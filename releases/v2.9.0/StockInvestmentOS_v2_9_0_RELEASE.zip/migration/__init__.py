"""Work-ready project migration and path-resolution package."""
