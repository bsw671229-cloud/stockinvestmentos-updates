from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


LAYOUT_FILENAME = "WORK_READY_LAYOUT.json"
LAYOUT_MODE = "WORK_READY_SEPARATED"


def _resolve(code_root: Path, value: str | None) -> Path | None:
    if not value:
        return None
    path = Path(value)
    if not path.is_absolute():
        path = code_root / path
    try:
        return path.resolve()
    except Exception:
        return path.absolute()


def load_work_ready_layout(code_root: Path) -> dict[str, Any]:
    code_root = Path(code_root).resolve()
    path = code_root / LAYOUT_FILENAME

    if not path.is_file():
        return {
            "active": False,
            "mode": "LEGACY",
            "code_root": str(code_root),
            "layout_file": str(path),
        }

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {
            "active": False,
            "mode": "INVALID",
            "code_root": str(code_root),
            "layout_file": str(path),
            "error": f"{type(exc).__name__}: {exc}",
        }

    if (
        not isinstance(raw, dict)
        or raw.get("schema_version") != 1
        or raw.get("mode") != LAYOUT_MODE
    ):
        return {
            "active": False,
            "mode": "INVALID",
            "code_root": str(code_root),
            "layout_file": str(path),
            "error": "Unsupported WORK_READY_LAYOUT schema or mode.",
        }

    resolved = {
        "active": True,
        "mode": LAYOUT_MODE,
        "schema_version": 1,
        "layout_file": str(path),
        "code_root": str(code_root),
    }

    mapping = {
        "home_root": "home_rel",
        "work_root": "work_root_rel",
        "runtime_data_root": "runtime_data_rel",
        "secrets_root": "secrets_rel",
        "secret_env_path": "secret_env_rel",
        "control_root": "control_rel",
    }

    for out_key, raw_key in mapping.items():
        resolved_path = _resolve(
            code_root,
            str(raw.get(raw_key, "")),
        )
        resolved[out_key] = str(resolved_path) if resolved_path is not None else ""

    return resolved


def resolve_control_root(code_root: Path) -> Path:
    layout = load_work_ready_layout(code_root)
    if layout.get("active") and layout.get("control_root"):
        return Path(layout["control_root"])
    return Path(code_root).resolve()


def resolve_runtime_data_root(code_root: Path) -> Path | None:
    layout = load_work_ready_layout(code_root)
    if layout.get("active") and layout.get("runtime_data_root"):
        return Path(layout["runtime_data_root"])
    return None


def resolve_env_path(code_root: Path, fallback: Path) -> Path:
    explicit = os.environ.get("STOCK_OS_ENV_PATH", "").strip()
    if explicit:
        return Path(explicit).expanduser().resolve()

    layout = load_work_ready_layout(code_root)
    if layout.get("active") and layout.get("secret_env_path"):
        return Path(layout["secret_env_path"])

    return Path(fallback)


def bootstrap_work_ready_environment(code_root: Path) -> dict[str, Any]:
    code_root = Path(code_root).resolve()
    layout = load_work_ready_layout(code_root)

    if not layout.get("active"):
        return layout

    env_map = {
        "STOCK_OS_WORK_READY_HOME": layout.get("home_root", ""),
        "STOCK_OS_WORK_ROOT": layout.get("work_root", ""),
        "STOCK_OS_RUNTIME_DATA_DIR": layout.get("runtime_data_root", ""),
        "STOCK_OS_DATA_DIR": layout.get("runtime_data_root", ""),
        "STOCK_OS_SECRETS_DIR": layout.get("secrets_root", ""),
        "STOCK_OS_ENV_PATH": layout.get("secret_env_path", ""),
        "STOCK_OS_CONTROL_DIR": layout.get("control_root", ""),
    }

    for key, value in env_map.items():
        if value:
            os.environ.setdefault(key, str(value))

    return layout
