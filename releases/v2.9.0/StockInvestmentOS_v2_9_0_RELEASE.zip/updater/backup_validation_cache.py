"""Bounded in-memory reuse of successful validation of exact backup bytes."""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from threading import RLock
from typing import Any, Callable
import hashlib
import sys
import time

VALIDATOR_REVISION = 'backup-integrity-v201-1'
MAX_ENTRIES = 8
MAX_AGE_SECONDS = 600.0
_results: OrderedDict[tuple, tuple[float, dict[str, Any]]] = OrderedDict()
_lock = RLock()


def validate_backup(
    backup: Path,
    validator: Callable[[bytes], dict[str, Any]],
    *,
    allow_cached: bool = False,
) -> dict[str, Any]:
    """Always read/hash current bytes; action callers default to full validation.

    Cache contains only PASS metadata, never ZIP bytes or failure results. The
    validator receives the immutable snapshot whose digest forms the cache key.
    """
    checked_at = datetime.now().astimezone().isoformat()
    try:
        data = backup.read_bytes()
    except OSError as exc:
        return {'status': 'FAIL', 'errors': [f'backup read failed: {type(exc).__name__}: {exc}']}
    digest = hashlib.sha256(data).hexdigest()
    key = (digest, VALIDATOR_REVISION, sys.implementation.cache_tag, sys.version)
    now = time.monotonic()
    with _lock:
        for old_key, (created, _) in list(_results.items()):
            if now - created >= MAX_AGE_SECONDS:
                del _results[old_key]
        cached = _results.get(key) if allow_cached else None
        if cached is not None:
            _results.move_to_end(key)
            result = deepcopy(cached[1])
            result['verification'].update(mode='CONTENT_CACHE', checked_at=checked_at)
            return result
    try:
        result = validator(data)
    except Exception as exc:
        result = {'status': 'FAIL', 'errors': [f'backup validation failed: {type(exc).__name__}: {exc}']}
    result['verification'] = {
        'mode': 'FULL', 'sha256': digest, 'validator_revision': VALIDATOR_REVISION,
        'checked_at': checked_at, 'validated_at': datetime.now().astimezone().isoformat(),
    }
    with _lock:
        _results.pop(key, None)
        if result.get('status') == 'PASS':
            _results[key] = (time.monotonic(), deepcopy(result))
            while len(_results) > MAX_ENTRIES:
                _results.popitem(last=False)
    return result
