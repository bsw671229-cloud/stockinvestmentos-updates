# Stock Investment OS — Trusted Release Operations / E2E Health

## Goal

After the one-time Trusted Feed + Publisher + Static HTTPS Deployment bootstrap,
continuously answer:

- Is the local managed code clean?
- Is the client feed HTTPS and host-pinned?
- Does the local publisher repository exist and have a valid immutable release SHA?
- Is Git deployment connected without credentials being stored by the app?
- Does the client feed URL match the deployment public URL?
- Does the last-verified public release_feed.json match the local publisher feed?
- Do Publisher / Deployment / Client state point to the same published version?
- Are Auto Approval / Auto Apply still disabled?
- Is investment Execution Authorization still NONE?

## 0D UI

Release Manager now includes:

`0D) Trusted Release Operations / E2E Health Gate`

The normal local status is non-mutating and does not perform a network request.

`Live Public Feed + Client Re-check` performs:
1. public release_feed.json byte verification
2. Trusted Feed check
3. E2E health recomputation

The live check may refresh verification state/log files under work/control.
It does not approve or apply a software release and does not grant investment
execution authorization.

## CLI

```bat
python -m updater.update_manager operations-status
python -m updater.update_manager operations-live-check
```

## Gate semantics

Technical PASS:
- structure / URL / SHA / managed-code / authorization invariants are intact

Technical REVIEW:
- evidence is not fresh enough to prove remote/local equality; run live check

Technical FAIL:
- a safety or trust invariant is broken

Operating REVIEW:
- a human next action is required, for example:
  - UPDATE_AVAILABLE
  - SYNCED_TO_INBOX
  - Git working tree dirty after local publish
  - installed version ahead of published feed

Operating REVIEW never means automatic approval or automatic apply.

## Safety boundary

- Auto Approval = DISABLED
- Auto Apply = DISABLED
- Execution Authorization = NONE
- Git credentials are not stored by Stock Investment OS
- runtime-data / data / secrets / .env remain outside software release packages


## v1.55.1 live-refresh behavior

The live re-check updates Trusted Feed / deployment evidence during a Streamlit
button event. Because 0D metrics are rendered earlier in the same Streamlit run,
v1.55.0 could leave the pre-click REVIEW snapshot visible after a successful
live check.

v1.55.1 persists the live-check evidence in Streamlit session state and triggers
one immediate rerun. The rerun recomputes 0D from the refreshed client/deployment
state and shows the last live-check evidence in a collapsible panel.

This is a UI freshness / operator-evidence fix only. It does not change Auto
Approval, Auto Apply, release approval, release apply, or investment execution
authorization.
