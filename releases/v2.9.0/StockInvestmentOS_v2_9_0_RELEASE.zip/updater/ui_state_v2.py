"""Publish a completed finalize result with a freshly evaluated status snapshot."""
from collections.abc import Callable, MutableMapping
from typing import Any


def store_finalize_result(session: MutableMapping[str, Any], root, result: dict,
                          status_reader: Callable) -> None:
    session['_safe_update_orchestrator_finalize_result'] = result
    session.pop('_suo_status_refresh_notice',None)
    # Discard stale PASS/REVIEW even if refreshing the presentation fails.
    session.pop('_suo_status_snapshot',None)
    try:
        fresh = status_reader(root)
        if not isinstance(fresh,dict) or not fresh:
            raise ValueError('Missing refreshed status')
        session['_suo_status_snapshot'] = fresh
    except Exception:
        # Finalize's persisted result is authoritative; a UI refresh is separate.
        session['_suo_status_refresh_notice'] = '최종 점검 결과는 저장됐습니다. 상태 표시를 다시 읽어 주세요.'
