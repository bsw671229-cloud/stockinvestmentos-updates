from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
import json
import os
import shutil
import tempfile

from updater.release_manager import (
    ensure_runtime_dirs,
    find_validation_report,
    is_version_newer,
    preview_release,
    read_current_version,
    sha256_file,
    validation_report_passes,
    verify_release_package,
)


PUBLISHER_STATE_NAME = "trusted_release_publisher_state.json"
RELEASE_HISTORY_NAME = "release_history.json"
RELEASE_FEED_NAME = "release_feed.json"


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _tx_id(prefix: str = "PUBLISH") -> str:
    stamp = datetime.now().astimezone().strftime(
        "%Y%m%dT%H%M%S%f"
    )
    return f"{prefix}-{stamp}-{os.getpid()}"


def _write_json_atomic(
    path: Path,
    data: dict[str, Any] | list[Any],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fd, temp_name = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(path.parent),
    )

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8",
            newline="\n",
        ) as f:
            json.dump(
                data,
                f,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                default=str,
            )
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())

        os.replace(
            temp_name,
            path,
        )
    finally:
        try:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
        except Exception:
            pass


def _read_json(
    path: Path,
) -> dict[str, Any]:
    if not path.is_file():
        return {}

    try:
        return json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {}


def _inside(
    child: Path,
    parent: Path,
) -> bool:
    child = child.resolve()
    parent = parent.resolve()

    try:
        child.relative_to(parent)
        return True
    except Exception:
        return False


def default_repository_root(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["control"]
        / "trusted_repository"
    )


def publisher_state_path(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["logs"]
        / PUBLISHER_STATE_NAME
    )


def _normalize_public_base_url(
    value: str,
    *,
    allow_file_public_url: bool,
) -> tuple[bool, str, str]:
    text = str(
        value
        or ""
    ).strip().rstrip("/")

    if not text:
        return (
            False,
            "",
            "Public base URL is required.",
        )

    parsed = urlparse(text)

    if parsed.username or parsed.password:
        return (
            False,
            "",
            "Credentials inside public base URL are prohibited.",
        )

    scheme = (
        parsed.scheme
        or ""
    ).lower()

    if scheme == "https":
        if not parsed.hostname:
            return (
                False,
                "",
                "HTTPS public base URL has no host.",
            )

        return (
            True,
            text,
            "",
        )

    if (
        scheme == "file"
        and allow_file_public_url
    ):
        return (
            True,
            text,
            "",
        )

    return (
        False,
        "",
        "Production public base URL must use HTTPS. "
        "file:// is allowed only for controlled local testing.",
    )


def _public_url(
    public_base_url: str,
    *parts: str,
) -> str:
    clean = [
        str(x).strip("/")
        for x in parts
        if str(x).strip("/")
    ]

    return (
        public_base_url.rstrip("/")
        + "/"
        + "/".join(clean)
    )


def _candidate_source_allowed(
    root: Path,
    package: Path,
) -> bool:
    dirs = ensure_runtime_dirs(
        root.resolve()
    )

    package = package.resolve()

    return any(
        _inside(
            package,
            dirs[scope],
        )
        for scope in [
            "inbox",
            "approved",
        ]
    )


def _existing_feed(
    repository_root: Path,
) -> dict[str, Any]:
    return _read_json(
        repository_root
        / RELEASE_FEED_NAME
    )


def publisher_status(
    root: Path,
    *,
    repository_root: str | Path | None = None,
) -> dict[str, Any]:
    root = Path(root).resolve()

    repo = (
        Path(repository_root).resolve()
        if repository_root
        else default_repository_root(root)
    )

    state = _read_json(
        publisher_state_path(root)
    )

    feed = _existing_feed(repo)

    release = (
        feed.get("release")
        or {}
    )

    return {
        "status": (
            "READY"
            if repo.exists()
            else "NOT_INITIALIZED"
        ),
        "repository_root": str(repo),
        "feed_path": str(
            repo
            / RELEASE_FEED_NAME
        ),
        "latest_published_version":
            str(
                release.get(
                    "version",
                    ""
                )
            ).strip()
            or "-",
        "latest_package_sha256":
            str(
                release.get(
                    "package_sha256",
                    ""
                )
            ).strip()
            or "-",
        "last_state": state,
        "execution_authorization":
            "NONE",
    }


def preview_release_publish(
    root: Path,
    package: Path,
    *,
    repository_root: str | Path | None = None,
    public_base_url: str,
    channel: str = "stable",
    feed_id: str = "stock-investment-os-stable",
    allow_file_public_url: bool = False,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(package).resolve()

    dirs = ensure_runtime_dirs(root)

    repo = (
        Path(repository_root).resolve()
        if repository_root
        else default_repository_root(root)
    )

    blockers = []
    warnings = []

    if not _inside(
        repo,
        dirs["control"],
    ):
        blockers.append(
            "Publisher repository_root must stay inside work/control."
        )

    if not _candidate_source_allowed(
        root,
        package,
    ):
        blockers.append(
            "Publisher source package must come from Release Manager inbox/approved."
        )

    url_ok, normalized_base, url_error = _normalize_public_base_url(
        public_base_url,
        allow_file_public_url=allow_file_public_url,
    )

    if not url_ok:
        blockers.append(
            url_error
        )

    if not str(
        channel
        or ""
    ).strip():
        blockers.append(
            "Release channel is required."
        )

    if not str(
        feed_id
        or ""
    ).strip():
        blockers.append(
            "feed_id is required."
        )

    verify = verify_release_package(
        root,
        package,
        require_final_release_name=True,
        require_validation_report=True,
        require_target_newer=False,
    )

    blockers.extend(
        verify.get(
            "blockers",
            [],
        )
    )

    warnings.extend(
        verify.get(
            "warnings",
            [],
        )
    )

    preview = preview_release(
        root,
        package,
        for_auto_apply=False,
        require_target_newer=False,
    )

    if not preview.get(
        "eligible",
        False,
    ):
        blockers.extend(
            preview.get(
                "blockers",
                [],
            )
        )

    validation = find_validation_report(
        package
    )

    validation_ok = validation_report_passes(
        validation
    )

    if not validation_ok:
        blockers.append(
            "Publisher requires a sidecar validation report containing RESULT: PASS."
        )

    target_version = str(
        verify.get(
            "target_version",
            ""
        )
    ).strip()

    package_sha = str(
        verify.get(
            "package_sha256",
            ""
        )
    ).strip().lower()

    validation_sha = (
        sha256_file(validation)
        if validation
        and validation.is_file()
        else ""
    )

    existing_feed = _existing_feed(
        repo
    )

    existing_release = (
        existing_feed.get(
            "release"
        )
        or {}
    )

    existing_version = str(
        existing_release.get(
            "version",
            ""
        )
    ).strip()

    existing_sha = str(
        existing_release.get(
            "package_sha256",
            ""
        )
    ).strip().lower()

    idempotent = False

    if existing_version:
        if existing_version == target_version:
            if existing_sha == package_sha:
                idempotent = True
                warnings.append(
                    "The same version/SHA is already published; publish will be idempotent."
                )
            else:
                blockers.append(
                    "Immutable publication conflict: same version already exists with a different SHA-256."
                )
        else:
            try:
                if not is_version_newer(
                    target_version,
                    existing_version,
                ):
                    blockers.append(
                        f"Publisher target {target_version} is not newer than "
                        f"existing feed {existing_version}."
                    )
            except Exception as exc:
                blockers.append(
                    f"Existing-feed version comparison failed: {exc}"
                )

    release_subdir = (
        f"releases/{target_version}"
        if target_version
        else "releases/UNKNOWN"
    )

    package_url = (
        _public_url(
            normalized_base,
            release_subdir,
            package.name,
        )
        if normalized_base
        else ""
    )

    validation_url = (
        _public_url(
            normalized_base,
            release_subdir,
            validation.name,
        )
        if normalized_base
        and validation
        else ""
    )

    feed_url = (
        _public_url(
            normalized_base,
            RELEASE_FEED_NAME,
        )
        if normalized_base
        else ""
    )

    return {
        "status": (
            "READY_TO_PUBLISH"
            if not blockers
            else "BLOCKED"
        ),
        "eligible": not blockers,
        "blockers": blockers,
        "warnings": warnings,
        "current_version":
            read_current_version(root),
        "target_version":
            target_version,
        "package": str(package),
        "package_name":
            package.name,
        "package_sha256":
            package_sha,
        "validation_report": (
            str(validation)
            if validation
            else ""
        ),
        "validation_name": (
            validation.name
            if validation
            else ""
        ),
        "validation_sha256":
            validation_sha,
        "validation_report_pass":
            validation_ok,
        "repository_root":
            str(repo),
        "release_subdir":
            release_subdir,
        "public_base_url":
            normalized_base,
        "feed_url":
            feed_url,
        "package_url":
            package_url,
        "validation_url":
            validation_url,
        "channel":
            str(
                channel
                or "stable"
            ).strip().lower(),
        "feed_id":
            str(
                feed_id
                or "stock-investment-os-stable"
            ).strip(),
        "existing_feed_version":
            existing_version,
        "idempotent":
            idempotent,
        "preview_eligible":
            bool(
                preview.get(
                    "eligible",
                    False,
                )
            ),
        "execution_authorization":
            "NONE",
    }


def publish_release_repository(
    root: Path,
    package: Path,
    *,
    repository_root: str | Path | None = None,
    public_base_url: str,
    channel: str = "stable",
    feed_id: str = "stock-investment-os-stable",
    allow_file_public_url: bool = False,
) -> dict[str, Any]:
    root = Path(root).resolve()
    package = Path(package).resolve()

    preview = preview_release_publish(
        root,
        package,
        repository_root=repository_root,
        public_base_url=public_base_url,
        channel=channel,
        feed_id=feed_id,
        allow_file_public_url=allow_file_public_url,
    )

    if not preview.get(
        "eligible"
    ):
        return {
            **preview,
            "published": False,
        }

    repo = Path(
        preview[
            "repository_root"
        ]
    ).resolve()

    dirs = ensure_runtime_dirs(
        root
    )

    repo.mkdir(
        parents=True,
        exist_ok=True,
    )

    target_dir = (
        repo
        / preview[
            "release_subdir"
        ]
    )

    target_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    validation = Path(
        preview[
            "validation_report"
        ]
    ).resolve()

    target_package = (
        target_dir
        / preview[
            "package_name"
        ]
    )

    target_validation = (
        target_dir
        / preview[
            "validation_name"
        ]
    )

    if target_package.is_file():
        if sha256_file(
            target_package
        ) != preview[
            "package_sha256"
        ]:
            return {
                "status": "BLOCKED",
                "published": False,
                "blockers": [
                    "Repository contains a same-name package with a different SHA-256."
                ],
                "execution_authorization":
                    "NONE",
            }
    else:
        shutil.copy2(
            package,
            target_package,
        )

    if target_validation.is_file():
        if sha256_file(
            target_validation
        ) != preview[
            "validation_sha256"
        ]:
            return {
                "status": "BLOCKED",
                "published": False,
                "blockers": [
                    "Repository contains a same-name validation report with a different SHA-256."
                ],
                "execution_authorization":
                    "NONE",
            }
    else:
        shutil.copy2(
            validation,
            target_validation,
        )

    if sha256_file(
        target_package
    ) != preview[
        "package_sha256"
    ]:
        return {
            "status": "BLOCKED",
            "published": False,
            "blockers": [
                "Published package post-copy SHA-256 mismatch."
            ],
            "execution_authorization":
                "NONE",
        }

    if sha256_file(
        target_validation
    ) != preview[
        "validation_sha256"
    ]:
        return {
            "status": "BLOCKED",
            "published": False,
            "blockers": [
                "Published validation post-copy SHA-256 mismatch."
            ],
            "execution_authorization":
                "NONE",
        }

    generated_at = _now()

    feed_document = {
        "schema_version":
            1,
        "feed_id":
            preview[
                "feed_id"
            ],
        "channel":
            preview[
                "channel"
            ],
        "generated_at":
            generated_at,
        "release": {
            "version":
                preview[
                    "target_version"
                ],
            "package_name":
                preview[
                    "package_name"
                ],
            "package_url":
                preview[
                    "package_url"
                ],
            "package_sha256":
                preview[
                    "package_sha256"
                ],
            "validation_name":
                preview[
                    "validation_name"
                ],
            "validation_url":
                preview[
                    "validation_url"
                ],
            "validation_sha256":
                preview[
                    "validation_sha256"
                ],
            "published_at":
                generated_at,
        },
    }

    feed_path = (
        repo
        / RELEASE_FEED_NAME
    )

    _write_json_atomic(
        feed_path,
        feed_document,
    )

    history_path = (
        repo
        / RELEASE_HISTORY_NAME
    )

    history_doc = _read_json(
        history_path
    )

    history = list(
        history_doc.get(
            "releases",
            []
        )
        if isinstance(
            history_doc,
            dict,
        )
        else []
    )

    existing_keys = {
        (
            str(
                row.get(
                    "version",
                    ""
                )
            ),
            str(
                row.get(
                    "package_sha256",
                    ""
                )
            ).lower(),
        )
        for row in history
        if isinstance(
            row,
            dict,
        )
    }

    key = (
        preview[
            "target_version"
        ],
        preview[
            "package_sha256"
        ].lower(),
    )

    if key not in existing_keys:
        history.append(
            {
                "version":
                    preview[
                        "target_version"
                    ],
                "package_name":
                    preview[
                        "package_name"
                    ],
                "package_sha256":
                    preview[
                        "package_sha256"
                    ],
                "validation_name":
                    preview[
                        "validation_name"
                    ],
                "validation_sha256":
                    preview[
                        "validation_sha256"
                    ],
                "published_at":
                    generated_at,
            }
        )

    _write_json_atomic(
        history_path,
        {
            "schema_version":
                1,
            "feed_id":
                preview[
                    "feed_id"
                ],
            "channel":
                preview[
                    "channel"
                ],
            "updated_at":
                generated_at,
            "releases":
                history,
        },
    )

    txid = _tx_id()

    journal = {
        "txid":
            txid,
        "created_at":
            generated_at,
        "status":
            "PUBLISHED_LOCAL_REPOSITORY",
        "repository_root":
            str(repo),
        "public_base_url":
            preview[
                "public_base_url"
            ],
        "feed_url":
            preview[
                "feed_url"
            ],
        "feed_path":
            str(feed_path),
        "target_version":
            preview[
                "target_version"
            ],
        "package":
            str(target_package),
        "package_sha256":
            preview[
                "package_sha256"
            ],
        "validation_report":
            str(
                target_validation
            ),
        "validation_sha256":
            preview[
                "validation_sha256"
            ],
        "validation_report_pass":
            True,
        "feed_generated":
            True,
        "remote_upload_performed":
            False,
        "execution_authorization":
            "NONE",
    }

    journal_path = (
        dirs["logs"]
        / f"{txid}.json"
    )

    _write_json_atomic(
        journal_path,
        journal,
    )

    _write_json_atomic(
        publisher_state_path(
            root
        ),
        {
            **journal,
            "last_action":
                "PUBLISH",
        },
    )

    return {
        "status":
            "PUBLISHED_LOCAL_REPOSITORY",
        "published":
            True,
        "idempotent":
            bool(
                preview.get(
                    "idempotent"
                )
            ),
        "target_version":
            preview[
                "target_version"
            ],
        "repository_root":
            str(repo),
        "feed_path":
            str(feed_path),
        "feed_url":
            preview[
                "feed_url"
            ],
        "package":
            str(target_package),
        "package_url":
            preview[
                "package_url"
            ],
        "package_sha256":
            preview[
                "package_sha256"
            ],
        "validation_report":
            str(
                target_validation
            ),
        "validation_url":
            preview[
                "validation_url"
            ],
        "validation_sha256":
            preview[
                "validation_sha256"
            ],
        "validation_report_pass":
            True,
        "history_path":
            str(
                history_path
            ),
        "journal":
            str(
                journal_path
            ),
        "remote_upload_performed":
            False,
        "execution_authorization":
            "NONE",
    }
