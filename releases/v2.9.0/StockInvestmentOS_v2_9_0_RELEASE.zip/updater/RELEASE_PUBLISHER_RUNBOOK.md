# Stock Investment OS — Release Publisher / Feed Generator

## Purpose

Generate the static Trusted Update Repository that the Updater2 client consumes.

The publisher validates a final RELEASE already present in Release Manager
`inbox` or `approved`, copies the immutable artifacts into a repository tree,
and atomically regenerates `release_feed.json`.

## Default local repository

`work/control/trusted_repository`

This location intentionally stays inside the Work-authorized software/control
boundary.

Generated structure:

```text
work/control/trusted_repository/
├─ release_feed.json
├─ release_history.json
└─ releases/
   └─ v1.55.0/
      ├─ StockInvestmentOS_v1_55_0_RELEASE.zip
      └─ V155_RELEASE_VALIDATION_YYYYMMDD.txt
```

## Production publishing model

Set a stable HTTPS public base URL, for example:

```text
https://updates.example.com/stock-investment-os
```

The generated feed then points to:

```text
https://updates.example.com/stock-investment-os/release_feed.json
https://updates.example.com/stock-investment-os/releases/v1.55.0/...
```

The repository folder can be the working tree of any static HTTPS host
deployment, such as a private/static web host or a repository-backed static
site.

## Publisher checks

Before publish:
- source package must come from Release Manager inbox/approved
- final RELEASE filename required
- target publication order is evaluated against the existing trusted feed, not the publisher workstation's installed VERSION
- package internal manifest PASS
- validation sidecar RESULT: PASS
- Release Manager Preview eligible
- repository root must remain inside work/control
- production public base URL must use HTTPS

Immutable same-version conflict:
- same version + same package SHA: idempotent
- same version + different SHA: BLOCKED

## Feed history

`release_history.json` preserves published version/SHA history.

## CLI

```bat
python -m updater.update_manager publisher-status

python -m updater.update_manager publisher-preview ^
  --package "..\control\releases\inbox\StockInvestmentOS_v1_55_0_RELEASE.zip" ^
  --base-url "https://updates.example.com/stock-investment-os"

python -m updater.update_manager publisher-publish ^
  --package "..\control\releases\inbox\StockInvestmentOS_v1_55_0_RELEASE.zip" ^
  --base-url "https://updates.example.com/stock-investment-os"
```

## Important boundary

v1.54.1 keeps repository/feed generation local and fixes same-version publication from a workstation already running that final release.

It does not upload to an Internet host by itself and does not store hosting
credentials. A one-time static HTTPS hosting/deployment connection is still
required.

Once that hosting path is connected, future clients no longer need to manually
download/copy RELEASE ZIP/TXT files.

## Investment authorization

Publisher state and software update authorization never grant investment
execution authority.

Execution Authorization = NONE.
