# Stock Investment OS — Trusted Release Feed / Auto Inbox Sync

## Goal

Remove the repeated manual workflow:

download RELEASE ZIP
→ download validation TXT
→ copy both into work/control/releases/inbox

After one-time feed configuration, Stock Investment OS can discover and
download a newer final RELEASE automatically into the local inbox.

## Trust boundary

Normal production mode allows HTTPS only.

The configured `allowed_hosts` list is an explicit transport-host pin.
Redirects are revalidated against the same allowlist.

The feed publishes:
- final semantic version
- exact final RELEASE ZIP filename
- package HTTPS URL
- package SHA-256
- validation report HTTPS URL
- optional validation report SHA-256

Before inbox promotion, the downloader verifies:
1. feed URL and host pin
2. feed schema/channel
3. target version is newer
4. final RELEASE naming
5. package SHA-256
6. validation RESULT: PASS
7. optional validation SHA-256
8. package internal manifest
9. Release Manager Preview eligibility
10. Managed Code = CLEAN

Only then are package/report atomically promoted to:
`work/control/releases/inbox`.

## Auto-sync

With `enabled=true` and `auto_sync=true`, the application performs a bounded
feed check when the configured interval is due.

v1.54-updater2-dev1 does NOT auto-approve or auto-apply. The remaining boundary
is intentionally:

Auto discovery/download/verify/inbox sync
→ approval
→ transactional apply

## One-time configuration

Example:

python -m updater.update_manager feed-config ^
  --url "https://updates.example.com/release_feed.json" ^
  --host "updates.example.com" ^
  --channel stable ^
  --auto-sync ^
  --interval-minutes 60

Then:

python -m updater.update_manager feed-check

or:

python -m updater.update_manager feed-sync

## Local test only

`file://` is blocked by default and exists only for controlled local testing.

## Protected boundaries

Trusted Release Feed writes only under work/control and does not read or modify:
- runtime-data/
- secrets/
- .env

## Investment authorization

Software update discovery/sync is separate from investment authorization.

Execution Authorization = NONE.
