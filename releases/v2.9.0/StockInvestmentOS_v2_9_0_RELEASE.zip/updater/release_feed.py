from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen
import json
import os
import re
import shutil
import tempfile

from updater.release_manager import (
    ensure_runtime_dirs,
    is_version_newer,
    preview_release,
    read_current_version,
    sha256_file,
    status_report,
    validation_report_passes,
    verify_release_package,
)


TRUSTED_FEED_CONFIG_NAME = "trusted_release_feed.json"
TRUSTED_FEED_STATE_NAME = "trusted_release_feed_state.json"

FINAL_RELEASE_RE = re.compile(
    r"^StockInvestmentOS_v(\d+)_(\d+)_(\d+)_RELEASE\.zip$",
    re.IGNORECASE,
)

DEFAULT_CONFIG = {
    "schema_version": 1,
    "enabled": False,
    "auto_sync": False,
    "channel": "stable",
    "feed_url": "",
    "allowed_hosts": [],
    "allow_file_source": False,
    "check_interval_minutes": 60,
    "request_timeout_seconds": 15,
    "max_feed_bytes": 1024 * 1024,
    "max_validation_bytes": 4 * 1024 * 1024,
    "max_package_bytes": 512 * 1024 * 1024,
}


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _tx_id(prefix: str = "FEED") -> str:
    stamp = datetime.now().astimezone().strftime(
        "%Y%m%dT%H%M%S%f"
    )
    return f"{prefix}-{stamp}-{os.getpid()}"


def _write_json(
    path: Path,
    data: dict[str, Any],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    tmp = path.with_suffix(
        path.suffix + ".tmp"
    )

    tmp.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        ) + "\n",
        encoding="utf-8",
    )

    os.replace(
        tmp,
        path,
    )


def _load_json(
    path: Path,
) -> dict[str, Any]:
    if not path.is_file():
        return {}

    try:
        return json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {}


def trusted_feed_config_path(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["control"]
        / TRUSTED_FEED_CONFIG_NAME
    )


def trusted_feed_state_path(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["logs"]
        / TRUSTED_FEED_STATE_NAME
    )


def load_trusted_feed_config(
    root: Path,
) -> dict[str, Any]:
    path = trusted_feed_config_path(
        root
    )

    stored = _load_json(
        path
    )

    config = {
        **DEFAULT_CONFIG,
        **stored,
    }

    config["allowed_hosts"] = [
        str(x).strip().lower()
        for x in (
            config.get(
                "allowed_hosts"
            )
            or []
        )
        if str(x).strip()
    ]

    return config


def _validate_url(
    url: str,
    config: dict[str, Any],
) -> tuple[bool, str]:
    text = str(
        url
        or ""
    ).strip()

    if not text:
        return False, "URL is empty."

    parsed = urlparse(
        text
    )

    if parsed.username or parsed.password:
        return (
            False,
            "Credentials inside release-feed URLs are prohibited.",
        )

    scheme = (
        parsed.scheme
        or ""
    ).lower()

    if scheme == "https":
        host = (
            parsed.hostname
            or ""
        ).lower()

        allowed_hosts = set(
            config.get(
                "allowed_hosts"
            )
            or []
        )

        if not host:
            return (
                False,
                "HTTPS URL has no host.",
            )

        if not allowed_hosts:
            return (
                False,
                "HTTPS feed requires at least one pinned allowed host.",
            )

        if host not in allowed_hosts:
            return (
                False,
                f"Host {host!r} is not in allowed_hosts.",
            )

        return True, ""

    if (
        scheme == "file"
        and bool(
            config.get(
                "allow_file_source"
            )
        )
    ):
        return True, ""

    return (
        False,
        "Only HTTPS is allowed in normal operation. "
        "file:// is available only when allow_file_source=true for controlled local testing.",
    )


def save_trusted_feed_config(
    root: Path,
    *,
    feed_url: str,
    allowed_hosts: list[str] | None = None,
    channel: str = "stable",
    enabled: bool = True,
    auto_sync: bool = True,
    check_interval_minutes: int = 60,
    request_timeout_seconds: int = 15,
    allow_file_source: bool = False,
) -> dict[str, Any]:
    root = Path(
        root
    ).resolve()

    config = {
        **DEFAULT_CONFIG,
        "schema_version": 1,
        "enabled": bool(
            enabled
        ),
        "auto_sync": bool(
            auto_sync
        ),
        "channel": str(
            channel
            or "stable"
        ).strip().lower(),
        "feed_url": str(
            feed_url
            or ""
        ).strip(),
        "allowed_hosts": sorted(
            {
                str(x).strip().lower()
                for x in (
                    allowed_hosts
                    or []
                )
                if str(x).strip()
            }
        ),
        "allow_file_source": bool(
            allow_file_source
        ),
        "check_interval_minutes": max(
            5,
            min(
                int(
                    check_interval_minutes
                ),
                1440,
            ),
        ),
        "request_timeout_seconds": max(
            3,
            min(
                int(
                    request_timeout_seconds
                ),
                60,
            ),
        ),
    }

    if config["enabled"]:
        ok, error = _validate_url(
            config["feed_url"],
            config,
        )

        if not ok:
            return {
                "status": "BLOCKED",
                "blockers": [
                    error
                ],
            }

    path = trusted_feed_config_path(
        root
    )

    _write_json(
        path,
        config,
    )

    return {
        "status": "SAVED",
        "config_path": str(
            path
        ),
        "config": config,
    }


def _read_url_bytes(
    url: str,
    config: dict[str, Any],
    *,
    max_bytes: int,
) -> tuple[bytes, str]:
    ok, error = _validate_url(
        url,
        config,
    )

    if not ok:
        raise ValueError(
            error
        )

    request = Request(
        url,
        headers={
            "User-Agent":
                "StockInvestmentOS-TrustedReleaseFeed/1.0",
            "Accept":
                "application/json,text/plain,application/zip,application/octet-stream,*/*",
        },
    )

    timeout = int(
        config.get(
            "request_timeout_seconds",
            15,
        )
    )

    with urlopen(
        request,
        timeout=timeout,
    ) as response:
        final_url = response.geturl()

        ok, error = _validate_url(
            final_url,
            config,
        )

        if not ok:
            raise ValueError(
                "Redirect target blocked: "
                + error
            )

        content_length = response.headers.get(
            "Content-Length"
        )

        if (
            content_length
            and int(
                content_length
            )
            > max_bytes
        ):
            raise ValueError(
                f"Remote object exceeds max_bytes={max_bytes}."
            )

        data = response.read(
            max_bytes + 1
        )

        if len(data) > max_bytes:
            raise ValueError(
                f"Remote object exceeds max_bytes={max_bytes}."
            )

        return data, final_url


def _expected_release_name(
    version: str,
) -> str:
    text = str(
        version
        or ""
    ).strip()

    m = re.fullmatch(
        r"v(\d+)\.(\d+)\.(\d+)",
        text,
        re.IGNORECASE,
    )

    if not m:
        return ""

    return (
        "StockInvestmentOS_v"
        + "_".join(
            m.groups()
        )
        + "_RELEASE.zip"
    )


def _validate_feed_document(
    document: dict[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    blockers = []

    if int(
        document.get(
            "schema_version",
            0,
        )
    ) != 1:
        blockers.append(
            "Trusted release feed schema_version must be 1."
        )

    feed_id = str(
        document.get(
            "feed_id",
            ""
        )
    ).strip()

    if not feed_id:
        blockers.append(
            "feed_id is required."
        )

    channel = str(
        document.get(
            "channel",
            ""
        )
    ).strip().lower()

    if channel != str(
        config.get(
            "channel",
            "stable",
        )
    ).strip().lower():
        blockers.append(
            f"Feed channel {channel!r} does not match configured channel "
            f"{config.get('channel')!r}."
        )

    release = (
        document.get(
            "release"
        )
        or {}
    )

    version = str(
        release.get(
            "version",
            ""
        )
    ).strip()

    package_name = str(
        release.get(
            "package_name",
            ""
        )
    ).strip()

    package_url = str(
        release.get(
            "package_url",
            ""
        )
    ).strip()

    package_sha256 = str(
        release.get(
            "package_sha256",
            ""
        )
    ).strip().lower()

    validation_name = str(
        release.get(
            "validation_name",
            ""
        )
    ).strip()

    validation_url = str(
        release.get(
            "validation_url",
            ""
        )
    ).strip()

    validation_sha256 = str(
        release.get(
            "validation_sha256",
            ""
        )
    ).strip().lower()

    expected_name = _expected_release_name(
        version
    )

    if not expected_name:
        blockers.append(
            "Feed release.version must be a final semantic version such as v1.54.0."
        )
    elif package_name != expected_name:
        blockers.append(
            f"package_name must be {expected_name!r} for {version}."
        )

    if not FINAL_RELEASE_RE.fullmatch(
        package_name
    ):
        blockers.append(
            "Feed package_name is not a final RELEASE ZIP."
        )

    if not re.fullmatch(
        r"[0-9a-f]{64}",
        package_sha256,
    ):
        blockers.append(
            "Feed package_sha256 must be exactly 64 hex characters."
        )

    if not validation_name.lower().endswith(
        ".txt"
    ):
        blockers.append(
            "Feed validation_name must be a .txt report."
        )

    if (
        validation_sha256
        and not re.fullmatch(
            r"[0-9a-f]{64}",
            validation_sha256,
        )
    ):
        blockers.append(
            "validation_sha256 must be blank or exactly 64 hex characters."
        )

    for label, url in [
        (
            "package_url",
            package_url,
        ),
        (
            "validation_url",
            validation_url,
        ),
    ]:
        ok, error = _validate_url(
            url,
            config,
        )

        if not ok:
            blockers.append(
                f"{label}: {error}"
            )

    return {
        "valid": not blockers,
        "blockers": blockers,
        "feed_id": feed_id,
        "channel": channel,
        "release": {
            "version": version,
            "package_name": package_name,
            "package_url": package_url,
            "package_sha256": package_sha256,
            "validation_name": validation_name,
            "validation_url": validation_url,
            "validation_sha256": validation_sha256,
            "published_at": str(
                release.get(
                    "published_at",
                    ""
                )
            ).strip(),
        },
    }


def check_trusted_release_feed(
    root: Path,
) -> dict[str, Any]:
    root = Path(
        root
    ).resolve()

    config = load_trusted_feed_config(
        root
    )

    current_version = read_current_version(
        root
    )

    if not config.get(
        "enabled"
    ):
        return {
            "status": "DISABLED",
            "current_version": current_version,
            "config_path": str(
                trusted_feed_config_path(
                    root
                )
            ),
            "config": config,
        }

    ok, error = _validate_url(
        config.get(
            "feed_url",
            "",
        ),
        config,
    )

    if not ok:
        return {
            "status": "BLOCKED",
            "current_version": current_version,
            "blockers": [
                error
            ],
            "config": config,
        }

    try:
        raw, resolved_feed_url = _read_url_bytes(
            config["feed_url"],
            config,
            max_bytes=int(
                config.get(
                    "max_feed_bytes",
                    DEFAULT_CONFIG["max_feed_bytes"],
                )
            ),
        )

        document = json.loads(
            raw.decode(
                "utf-8"
            )
        )
    except Exception as exc:
        return {
            "status": "BLOCKED",
            "current_version": current_version,
            "blockers": [
                f"Trusted release feed fetch failed: {type(exc).__name__}: {exc}"
            ],
            "config": config,
        }

    validated = _validate_feed_document(
        document,
        config,
    )

    if not validated[
        "valid"
    ]:
        return {
            "status": "BLOCKED",
            "current_version": current_version,
            "blockers": validated[
                "blockers"
            ],
            "feed_url": resolved_feed_url,
            "feed": validated,
        }

    target_version = validated[
        "release"
    ][
        "version"
    ]

    try:
        newer = is_version_newer(
            target_version,
            current_version,
        )
    except Exception as exc:
        return {
            "status": "BLOCKED",
            "current_version": current_version,
            "target_version": target_version,
            "blockers": [
                f"Version comparison failed: {exc}"
            ],
            "feed": validated,
        }

    status = (
        "UPDATE_AVAILABLE"
        if newer
        else "UP_TO_DATE"
    )

    result = {
        "status": status,
        "current_version": current_version,
        "target_version": target_version,
        "feed_url": resolved_feed_url,
        "feed_id": validated[
            "feed_id"
        ],
        "channel": validated[
            "channel"
        ],
        "release": validated[
            "release"
        ],
        "checked_at": _now(),
        "blockers": [],
    }

    _write_json(
        trusted_feed_state_path(
            root
        ),
        {
            **result,
            "last_action":
                "CHECK",
        },
    )

    return result


def _write_bytes_atomic(
    path: Path,
    data: bytes,
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fd, temp_name = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(
            path.parent
        ),
    )

    try:
        with os.fdopen(
            fd,
            "wb",
        ) as f:
            f.write(
                data
            )
            f.flush()
            os.fsync(
                f.fileno()
            )

        os.replace(
            temp_name,
            path,
        )
    finally:
        try:
            if os.path.exists(
                temp_name
            ):
                os.unlink(
                    temp_name
                )
        except Exception:
            pass


def sync_trusted_release_to_inbox(
    root: Path,
) -> dict[str, Any]:
    root = Path(
        root
    ).resolve()

    config = load_trusted_feed_config(
        root
    )

    check = check_trusted_release_feed(
        root
    )

    if check.get(
        "status"
    ) != "UPDATE_AVAILABLE":
        return {
            **check,
            "synced": False,
        }

    manager_status = status_report(
        root
    )

    if not manager_status.get(
        "managed_code_clean"
    ):
        return {
            "status": "BLOCKED",
            "synced": False,
            "current_version": manager_status.get(
                "current_version"
            ),
            "target_version": check.get(
                "target_version"
            ),
            "blockers": [
                "Managed Code is not CLEAN; trusted feed sync is blocked."
            ],
            "execution_authorization": "NONE",
        }

    dirs = ensure_runtime_dirs(
        root
    )

    release = check[
        "release"
    ]

    txid = _tx_id(
        "FEED-SYNC"
    )

    stage_dir = (
        dirs["staging"]
        / "trusted_feed"
        / txid
    )

    stage_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    stage_package = (
        stage_dir
        / release[
            "package_name"
        ]
    )

    stage_validation = (
        stage_dir
        / release[
            "validation_name"
        ]
    )

    try:
        package_bytes, package_resolved_url = _read_url_bytes(
            release[
                "package_url"
            ],
            config,
            max_bytes=int(
                config.get(
                    "max_package_bytes",
                    DEFAULT_CONFIG[
                        "max_package_bytes"
                    ],
                )
            ),
        )

        validation_bytes, validation_resolved_url = _read_url_bytes(
            release[
                "validation_url"
            ],
            config,
            max_bytes=int(
                config.get(
                    "max_validation_bytes",
                    DEFAULT_CONFIG[
                        "max_validation_bytes"
                    ],
                )
            ),
        )

        _write_bytes_atomic(
            stage_package,
            package_bytes,
        )

        _write_bytes_atomic(
            stage_validation,
            validation_bytes,
        )

        actual_package_sha = sha256_file(
            stage_package
        )

        if actual_package_sha != release[
            "package_sha256"
        ]:
            raise ValueError(
                "Downloaded package SHA-256 mismatch. "
                f"expected={release['package_sha256']} "
                f"actual={actual_package_sha}"
            )

        expected_validation_sha = release.get(
            "validation_sha256"
        ) or ""

        actual_validation_sha = sha256_file(
            stage_validation
        )

        if (
            expected_validation_sha
            and actual_validation_sha
            != expected_validation_sha
        ):
            raise ValueError(
                "Downloaded validation SHA-256 mismatch. "
                f"expected={expected_validation_sha} "
                f"actual={actual_validation_sha}"
            )

        if not validation_report_passes(
            stage_validation
        ):
            raise ValueError(
                "Downloaded validation report does not contain RESULT: PASS."
            )

        verify = verify_release_package(
            root,
            stage_package,
            require_final_release_name=True,
            require_validation_report=False,
        )

        if verify.get(
            "blockers"
        ):
            raise ValueError(
                "Downloaded release package verification blocked: "
                + " | ".join(
                    verify[
                        "blockers"
                    ]
                )
            )

        preview = preview_release(
            root,
            stage_package,
            for_auto_apply=False,
        )

        if not preview.get(
            "eligible",
            False,
        ):
            raise ValueError(
                "Downloaded release preview is not eligible: "
                + " | ".join(
                    preview.get(
                        "blockers",
                        [],
                    )
                )
            )

        inbox_package = (
            dirs["inbox"]
            / release[
                "package_name"
            ]
        )

        inbox_validation = (
            dirs["inbox"]
            / release[
                "validation_name"
            ]
        )

        if inbox_package.exists():
            if sha256_file(
                inbox_package
            ) != actual_package_sha:
                raise ValueError(
                    "Inbox already contains a same-name package with a different SHA-256."
                )

        if inbox_validation.exists():
            if sha256_file(
                inbox_validation
            ) != actual_validation_sha:
                raise ValueError(
                    "Inbox already contains a same-name validation report with a different SHA-256."
                )

        if not inbox_package.exists():
            os.replace(
                stage_package,
                inbox_package,
            )

        if not inbox_validation.exists():
            os.replace(
                stage_validation,
                inbox_validation,
            )

        journal = {
            "txid": txid,
            "created_at": _now(),
            "status": "SYNCED_TO_INBOX",
            "feed_id": check.get(
                "feed_id"
            ),
            "channel": check.get(
                "channel"
            ),
            "feed_url": check.get(
                "feed_url"
            ),
            "current_version": check.get(
                "current_version"
            ),
            "target_version": check.get(
                "target_version"
            ),
            "package": str(
                inbox_package
            ),
            "package_sha256": actual_package_sha,
            "package_url": package_resolved_url,
            "validation_report": str(
                inbox_validation
            ),
            "validation_sha256": actual_validation_sha,
            "validation_url": validation_resolved_url,
            "validation_report_pass": True,
            "preview_eligible": True,
            "auto_approval_performed": False,
            "auto_apply_performed": False,
            "execution_authorization": "NONE",
        }

        journal_path = (
            dirs["logs"]
            / f"{txid}.json"
        )

        _write_json(
            journal_path,
            journal,
        )

        _write_json(
            trusted_feed_state_path(
                root
            ),
            {
                **journal,
                "last_action":
                    "SYNC",
            },
        )

        return {
            "status": "SYNCED_TO_INBOX",
            "synced": True,
            "current_version": check.get(
                "current_version"
            ),
            "target_version": check.get(
                "target_version"
            ),
            "package": str(
                inbox_package
            ),
            "package_sha256": actual_package_sha,
            "validation_report": str(
                inbox_validation
            ),
            "validation_report_pass": True,
            "preview_eligible": True,
            "journal": str(
                journal_path
            ),
            "auto_approval_performed": False,
            "auto_apply_performed": False,
            "execution_authorization": "NONE",
        }

    except Exception as exc:
        result = {
            "status": "BLOCKED",
            "synced": False,
            "current_version": check.get(
                "current_version"
            ),
            "target_version": check.get(
                "target_version"
            ),
            "blockers": [
                f"Trusted feed sync failed: {type(exc).__name__}: {exc}"
            ],
            "execution_authorization": "NONE",
        }

        _write_json(
            trusted_feed_state_path(
                root
            ),
            {
                **result,
                "checked_at":
                    _now(),
                "last_action":
                    "SYNC_FAILED",
            },
        )

        return result

    finally:
        shutil.rmtree(
            stage_dir,
            ignore_errors=True,
        )


def trusted_release_feed_status(
    root: Path,
) -> dict[str, Any]:
    root = Path(
        root
    ).resolve()

    config = load_trusted_feed_config(
        root
    )

    state = _load_json(
        trusted_feed_state_path(
            root
        )
    )

    return {
        "status": (
            "ENABLED"
            if config.get(
                "enabled"
            )
            else "DISABLED"
        ),
        "current_version":
            read_current_version(
                root
            ),
        "config_path": str(
            trusted_feed_config_path(
                root
            )
        ),
        "state_path": str(
            trusted_feed_state_path(
                root
            )
        ),
        "config": config,
        "last_state": state,
        "execution_authorization":
            "NONE",
    }


def maybe_auto_sync_trusted_release(
    root: Path,
) -> dict[str, Any]:
    root = Path(
        root
    ).resolve()

    config = load_trusted_feed_config(
        root
    )

    if not config.get(
        "enabled"
    ):
        return {
            "status": "DISABLED",
            "synced": False,
        }

    if not config.get(
        "auto_sync"
    ):
        return {
            "status": "AUTO_SYNC_DISABLED",
            "synced": False,
        }

    state = _load_json(
        trusted_feed_state_path(
            root
        )
    )

    last_checked = state.get(
        "checked_at"
    ) or state.get(
        "created_at"
    )

    interval_seconds = (
        int(
            config.get(
                "check_interval_minutes",
                60,
            )
        )
        * 60
    )

    if last_checked:
        try:
            previous = datetime.fromisoformat(
                str(
                    last_checked
                )
            )

            elapsed = (
                datetime.now()
                .astimezone()
                - previous
            ).total_seconds()

            if elapsed < interval_seconds:
                return {
                    "status": "NOT_DUE",
                    "synced": False,
                    "seconds_until_due": max(
                        0,
                        int(
                            interval_seconds
                            - elapsed
                        ),
                    ),
                    "last_checked": last_checked,
                }
        except Exception:
            pass

    return sync_trusted_release_to_inbox(
        root
    )
