from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen
import hashlib
import json
import os
import re
import shutil
import subprocess

from updater.release_feed import (
    check_trusted_release_feed,
    save_trusted_feed_config,
)
from updater.release_manager import (
    ensure_runtime_dirs,
    read_current_version,
    sha256_file,
)


DEPLOYMENT_CONFIG_NAME = "trusted_repository_deployment.json"
DEPLOYMENT_STATE_NAME = "trusted_repository_deployment_state.json"

DEFAULT_DEPLOYMENT_CONFIG = {
    "schema_version": 1,
    "enabled": False,
    "repository_root": "",
    "remote_name": "origin",
    "remote_url": "",
    "branch": "main",
    "public_base_url": "",
    "auto_bootstrap_client_feed": True,
    "client_check_interval_minutes": 60,
    "allow_file_remote": False,
    "allow_file_public_url": False,
}


def _now() -> str:
    return datetime.now().astimezone().isoformat()


def _write_json(
    path: Path,
    data: dict[str, Any],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    tmp = path.with_suffix(
        path.suffix + ".tmp"
    )

    tmp.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        ) + "\n",
        encoding="utf-8",
    )

    os.replace(
        tmp,
        path,
    )


def _read_json(
    path: Path,
) -> dict[str, Any]:
    if not path.is_file():
        return {}

    try:
        return json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        return {}


def _inside(
    child: Path,
    parent: Path,
) -> bool:
    child = child.resolve()
    parent = parent.resolve()

    try:
        child.relative_to(parent)
        return True
    except Exception:
        return False


def deployment_config_path(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["control"]
        / DEPLOYMENT_CONFIG_NAME
    )


def deployment_state_path(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["logs"]
        / DEPLOYMENT_STATE_NAME
    )


def default_repository_root(
    root: Path,
) -> Path:
    dirs = ensure_runtime_dirs(
        Path(root).resolve()
    )

    return (
        dirs["control"]
        / "trusted_repository"
    )


def load_deployment_config(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    stored = _read_json(
        deployment_config_path(
            root
        )
    )

    config = {
        **DEFAULT_DEPLOYMENT_CONFIG,
        **stored,
    }

    if not str(
        config.get(
            "repository_root",
            ""
        )
    ).strip():
        config[
            "repository_root"
        ] = str(
            default_repository_root(
                root
            )
        )

    return config


def _validate_public_base_url(
    value: str,
    *,
    allow_file: bool,
) -> tuple[bool, str, str]:
    text = str(
        value
        or ""
    ).strip().rstrip("/")

    if not text:
        return (
            False,
            "",
            "Public HTTPS Base URL is required.",
        )

    parsed = urlparse(
        text
    )

    if parsed.username or parsed.password:
        return (
            False,
            "",
            "Credentials inside public URL are prohibited.",
        )

    scheme = (
        parsed.scheme
        or ""
    ).lower()

    if scheme == "https":
        if not parsed.hostname:
            return (
                False,
                "",
                "HTTPS public URL has no host.",
            )

        return (
            True,
            text,
            "",
        )

    if (
        scheme == "file"
        and allow_file
    ):
        return (
            True,
            text,
            "",
        )

    return (
        False,
        "",
        "Production public URL must use HTTPS. "
        "file:// is allowed only for controlled local testing.",
    )


def _validate_remote_url(
    value: str,
    *,
    allow_file: bool,
) -> tuple[bool, str]:
    text = str(
        value
        or ""
    ).strip()

    if not text:
        return (
            False,
            "Git remote URL is required.",
        )

    if re.match(
        r"^[^/@\s]+@[^:\s]+:[^\s]+$",
        text,
    ):
        return (
            True,
            "",
        )

    parsed = urlparse(
        text
    )

    scheme = (
        parsed.scheme
        or ""
    ).lower()

    if scheme == "https":
        if (
            parsed.username
            or parsed.password
        ):
            return (
                False,
                "Credentials/tokens inside HTTPS Git remote URL are prohibited.",
            )

        if not parsed.hostname:
            return (
                False,
                "HTTPS Git remote has no host.",
            )

        return (
            True,
            "",
        )

    if scheme == "ssh":
        if not parsed.hostname:
            return (
                False,
                "SSH Git remote has no host.",
            )

        if parsed.password:
            return (
                False,
                "Password inside SSH Git remote URL is prohibited.",
            )

        return (
            True,
            "",
        )

    if (
        scheme == "file"
        and allow_file
    ):
        return (
            True,
            "",
        )

    return (
        False,
        "Production Git remote must use HTTPS or SSH. "
        "file:// is allowed only for controlled local testing.",
    )


def save_deployment_config(
    root: Path,
    *,
    repository_root: str | Path | None,
    remote_url: str,
    public_base_url: str,
    remote_name: str = "origin",
    branch: str = "main",
    enabled: bool = True,
    auto_bootstrap_client_feed: bool = True,
    client_check_interval_minutes: int = 60,
    allow_file_remote: bool = False,
    allow_file_public_url: bool = False,
) -> dict[str, Any]:
    root = Path(root).resolve()
    dirs = ensure_runtime_dirs(
        root
    )

    repo = (
        Path(repository_root).resolve()
        if repository_root
        else default_repository_root(
            root
        )
    )

    blockers = []

    if not _inside(
        repo,
        dirs["control"],
    ):
        blockers.append(
            "Deployment repository must stay inside work/control."
        )

    remote_name = str(
        remote_name
        or "origin"
    ).strip()

    branch = str(
        branch
        or "main"
    ).strip()

    if not re.fullmatch(
        r"[A-Za-z0-9._-]{1,64}",
        remote_name,
    ):
        blockers.append(
            "Git remote name contains unsupported characters."
        )

    if not re.fullmatch(
        r"[A-Za-z0-9._/-]{1,128}",
        branch,
    ):
        blockers.append(
            "Git branch contains unsupported characters."
        )

    remote_ok, remote_error = _validate_remote_url(
        remote_url,
        allow_file=allow_file_remote,
    )

    if not remote_ok:
        blockers.append(
            remote_error
        )

    public_ok, normalized_public, public_error = _validate_public_base_url(
        public_base_url,
        allow_file=allow_file_public_url,
    )

    if not public_ok:
        blockers.append(
            public_error
        )

    if blockers:
        return {
            "status": "BLOCKED",
            "blockers": blockers,
            "execution_authorization":
                "NONE",
        }

    config = {
        "schema_version":
            1,
        "enabled":
            bool(enabled),
        "repository_root":
            str(repo),
        "remote_name":
            remote_name,
        "remote_url":
            str(
                remote_url
            ).strip(),
        "branch":
            branch,
        "public_base_url":
            normalized_public,
        "auto_bootstrap_client_feed":
            bool(
                auto_bootstrap_client_feed
            ),
        "client_check_interval_minutes":
            max(
                5,
                min(
                    int(
                        client_check_interval_minutes
                    ),
                    1440,
                ),
            ),
        "allow_file_remote":
            bool(
                allow_file_remote
            ),
        "allow_file_public_url":
            bool(
                allow_file_public_url
            ),
    }

    path = deployment_config_path(
        root
    )

    _write_json(
        path,
        config,
    )

    return {
        "status":
            "SAVED",
        "config_path":
            str(path),
        "config":
            config,
        "execution_authorization":
            "NONE",
    }


def _git_available() -> tuple[bool, str]:
    git = shutil.which(
        "git"
    )

    if not git:
        return (
            False,
            "git executable was not found on PATH.",
        )

    try:
        result = subprocess.run(
            [
                git,
                "--version",
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except Exception as exc:
        return (
            False,
            f"git --version failed: {type(exc).__name__}: {exc}",
        )

    if result.returncode != 0:
        return (
            False,
            result.stderr.strip()
            or "git --version returned non-zero.",
        )

    return (
        True,
        result.stdout.strip(),
    )


def _git(
    repository_root: Path,
    args: list[str],
    *,
    timeout: int = 60,
) -> dict[str, Any]:
    git = shutil.which(
        "git"
    )

    if not git:
        return {
            "returncode":
                127,
            "stdout":
                "",
            "stderr":
                "git executable not found.",
        }

    env = dict(
        os.environ
    )

    env[
        "GIT_TERMINAL_PROMPT"
    ] = "0"

    result = subprocess.run(
        [
            git,
            *args,
        ],
        cwd=str(
            repository_root
        ),
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )

    return {
        "returncode":
            result.returncode,
        "stdout":
            result.stdout.strip(),
        "stderr":
            result.stderr.strip(),
    }


def connect_git_repository(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    config = load_deployment_config(
        root
    )

    if not config.get(
        "enabled"
    ):
        return {
            "status":
                "BLOCKED",
            "blockers": [
                "Deployment connector is disabled."
            ],
            "execution_authorization":
                "NONE",
        }

    repo = Path(
        config[
            "repository_root"
        ]
    ).resolve()

    dirs = ensure_runtime_dirs(
        root
    )

    if not _inside(
        repo,
        dirs["control"],
    ):
        return {
            "status":
                "BLOCKED",
            "blockers": [
                "Deployment repository escaped work/control."
            ],
            "execution_authorization":
                "NONE",
        }

    if not (
        repo
        / "release_feed.json"
    ).is_file():
        return {
            "status":
                "BLOCKED",
            "blockers": [
                "release_feed.json is missing. Run Release Publisher first."
            ],
            "execution_authorization":
                "NONE",
        }

    git_ok, git_detail = _git_available()

    if not git_ok:
        return {
            "status":
                "BLOCKED",
            "blockers": [
                git_detail
            ],
            "execution_authorization":
                "NONE",
        }

    repo.mkdir(
        parents=True,
        exist_ok=True,
    )

    if not (
        repo
        / ".git"
    ).exists():
        init = _git(
            repo,
            [
                "init",
                "-b",
                config[
                    "branch"
                ],
            ],
        )

        if init[
            "returncode"
        ] != 0:
            return {
                "status":
                    "BLOCKED",
                "blockers": [
                    "git init failed: "
                    + (
                        init[
                            "stderr"
                        ]
                        or init[
                            "stdout"
                        ]
                    )
                ],
                "execution_authorization":
                    "NONE",
            }

    # Local-only identity. Credentials are not stored by Stock Investment OS.
    for key, value in [
        (
            "user.name",
            "Stock Investment OS Release Publisher",
        ),
        (
            "user.email",
            "stock-investment-os@localhost",
        ),
    ]:
        current = _git(
            repo,
            [
                "config",
                "--get",
                key,
            ],
        )

        if (
            current[
                "returncode"
            ] != 0
            or not current[
                "stdout"
            ]
        ):
            _git(
                repo,
                [
                    "config",
                    key,
                    value,
                ],
            )

    remote_name = config[
        "remote_name"
    ]

    existing = _git(
        repo,
        [
            "remote",
            "get-url",
            remote_name,
        ],
    )

    if existing[
        "returncode"
    ] == 0:
        if existing[
            "stdout"
        ] != config[
            "remote_url"
        ]:
            updated = _git(
                repo,
                [
                    "remote",
                    "set-url",
                    remote_name,
                    config[
                        "remote_url"
                    ],
                ],
            )

            if updated[
                "returncode"
            ] != 0:
                return {
                    "status":
                        "BLOCKED",
                    "blockers": [
                        "git remote set-url failed: "
                        + (
                            updated[
                                "stderr"
                            ]
                            or updated[
                                "stdout"
                            ]
                        )
                    ],
                    "execution_authorization":
                        "NONE",
                }

    else:
        added = _git(
            repo,
            [
                "remote",
                "add",
                remote_name,
                config[
                    "remote_url"
                ],
            ],
        )

        if added[
            "returncode"
        ] != 0:
            return {
                "status":
                    "BLOCKED",
                "blockers": [
                    "git remote add failed: "
                    + (
                        added[
                            "stderr"
                        ]
                        or added[
                            "stdout"
                        ]
                    )
                ],
                "execution_authorization":
                    "NONE",
            }

    return {
        "status":
            "CONNECTED",
        "repository_root":
            str(repo),
        "remote_name":
            remote_name,
        "remote_url":
            config[
                "remote_url"
            ],
        "branch":
            config[
                "branch"
            ],
        "git":
            git_detail,
        "credentials_stored_by_app":
            False,
        "execution_authorization":
            "NONE",
    }


def deployment_status(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    config = load_deployment_config(
        root
    )

    repo = Path(
        config[
            "repository_root"
        ]
    ).resolve()

    state = _read_json(
        deployment_state_path(
            root
        )
    )

    git_ok, git_detail = _git_available()

    git_initialized = (
        repo
        / ".git"
    ).exists()

    remote_url = ""
    current_branch = ""
    dirty = None

    if (
        git_ok
        and git_initialized
    ):
        remote = _git(
            repo,
            [
                "remote",
                "get-url",
                config[
                    "remote_name"
                ],
            ],
        )

        if remote[
            "returncode"
        ] == 0:
            remote_url = remote[
                "stdout"
            ]

        branch = _git(
            repo,
            [
                "branch",
                "--show-current",
            ],
        )

        if branch[
            "returncode"
        ] == 0:
            current_branch = branch[
                "stdout"
            ]

        status = _git(
            repo,
            [
                "status",
                "--porcelain",
            ],
        )

        if status[
            "returncode"
        ] == 0:
            dirty = bool(
                status[
                    "stdout"
                ]
            )

    return {
        "status": (
            "CONNECTED"
            if (
                config.get(
                    "enabled"
                )
                and git_initialized
                and remote_url
            )
            else (
                "CONFIGURED"
                if config.get(
                    "enabled"
                )
                else "DISABLED"
            )
        ),
        "current_version":
            read_current_version(
                root
            ),
        "repository_root":
            str(repo),
        "feed_path":
            str(
                repo
                / "release_feed.json"
            ),
        "feed_exists":
            (
                repo
                / "release_feed.json"
            ).is_file(),
        "git_available":
            git_ok,
        "git_detail":
            git_detail,
        "git_initialized":
            git_initialized,
        "remote_name":
            config.get(
                "remote_name"
            ),
        "remote_url":
            remote_url
            or config.get(
                "remote_url"
            ),
        "branch":
            current_branch
            or config.get(
                "branch"
            ),
        "public_base_url":
            config.get(
                "public_base_url"
            ),
        "dirty":
            dirty,
        "credentials_stored_by_app":
            False,
        "config_path":
            str(
                deployment_config_path(
                    root
                )
            ),
        "state_path":
            str(
                deployment_state_path(
                    root
                )
            ),
        "last_state":
            state,
        "execution_authorization":
            "NONE",
    }


def preview_deployment(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    config = load_deployment_config(
        root
    )

    blockers = []
    warnings = []

    if not config.get(
        "enabled"
    ):
        blockers.append(
            "Deployment connector is disabled."
        )

    repo = Path(
        config[
            "repository_root"
        ]
    ).resolve()

    dirs = ensure_runtime_dirs(
        root
    )

    if not _inside(
        repo,
        dirs["control"],
    ):
        blockers.append(
            "Deployment repository escaped work/control."
        )

    feed_path = (
        repo
        / "release_feed.json"
    )

    feed = _read_json(
        feed_path
    )

    if not feed:
        blockers.append(
            "release_feed.json is missing or invalid."
        )

    release = (
        feed.get(
            "release"
        )
        or {}
    )

    version = str(
        release.get(
            "version",
            ""
        )
    ).strip()

    package_name = str(
        release.get(
            "package_name",
            ""
        )
    ).strip()

    validation_name = str(
        release.get(
            "validation_name",
            ""
        )
    ).strip()

    release_dir = (
        repo
        / "releases"
        / version
    )

    package = (
        release_dir
        / package_name
    )

    validation = (
        release_dir
        / validation_name
    )

    if not package.is_file():
        blockers.append(
            "Feed package artifact is missing from local repository."
        )

    if not validation.is_file():
        blockers.append(
            "Feed validation artifact is missing from local repository."
        )

    if package.is_file():
        actual = sha256_file(
            package
        )

        expected = str(
            release.get(
                "package_sha256",
                ""
            )
        ).strip().lower()

        if actual != expected:
            blockers.append(
                "Local repository package SHA-256 does not match release_feed.json."
            )

    if validation.is_file():
        actual = sha256_file(
            validation
        )

        expected = str(
            release.get(
                "validation_sha256",
                ""
            )
        ).strip().lower()

        if expected and actual != expected:
            blockers.append(
                "Local repository validation SHA-256 does not match release_feed.json."
            )

    remote_ok, remote_error = _validate_remote_url(
        config.get(
            "remote_url",
            ""
        ),
        allow_file=bool(
            config.get(
                "allow_file_remote"
            )
        ),
    )

    if not remote_ok:
        blockers.append(
            remote_error
        )

    public_ok, public_base, public_error = _validate_public_base_url(
        config.get(
            "public_base_url",
            ""
        ),
        allow_file=bool(
            config.get(
                "allow_file_public_url"
            )
        ),
    )

    if not public_ok:
        blockers.append(
            public_error
        )

    git_ok, git_detail = _git_available()

    if not git_ok:
        blockers.append(
            git_detail
        )

    git_initialized = (
        repo
        / ".git"
    ).exists()

    if not git_initialized:
        blockers.append(
            "Git repository is not initialized/connected."
        )

    configured_remote = ""

    if (
        git_ok
        and git_initialized
    ):
        remote = _git(
            repo,
            [
                "remote",
                "get-url",
                config[
                    "remote_name"
                ],
            ],
        )

        if remote[
            "returncode"
        ] != 0:
            blockers.append(
                "Configured Git remote is missing."
            )
        else:
            configured_remote = remote[
                "stdout"
            ]

            if configured_remote != config[
                "remote_url"
            ]:
                blockers.append(
                    "Configured Git remote URL does not match deployment config."
                )

    return {
        "status": (
            "READY_TO_DEPLOY"
            if not blockers
            else "BLOCKED"
        ),
        "eligible":
            not blockers,
        "blockers":
            blockers,
        "warnings":
            warnings,
        "repository_root":
            str(repo),
        "feed_path":
            str(feed_path),
        "feed_sha256": (
            sha256_file(
                feed_path
            )
            if feed_path.is_file()
            else ""
        ),
        "target_version":
            version,
        "remote_name":
            config.get(
                "remote_name"
            ),
        "remote_url":
            configured_remote
            or config.get(
                "remote_url"
            ),
        "branch":
            config.get(
                "branch"
            ),
        "public_base_url":
            public_base,
        "public_feed_url": (
            public_base.rstrip("/")
            + "/release_feed.json"
            if public_base
            else ""
        ),
        "git_available":
            git_ok,
        "git_detail":
            git_detail,
        "credentials_stored_by_app":
            False,
        "execution_authorization":
            "NONE",
    }


def deploy_repository(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()

    preview = preview_deployment(
        root
    )

    if not preview.get(
        "eligible"
    ):
        return {
            **preview,
            "deployed":
                False,
        }

    config = load_deployment_config(
        root
    )

    repo = Path(
        preview[
            "repository_root"
        ]
    ).resolve()

    add = _git(
        repo,
        [
            "add",
            "--",
            "release_feed.json",
            "release_history.json",
            "releases",
        ],
    )

    if add[
        "returncode"
    ] != 0:
        return {
            "status":
                "BLOCKED",
            "deployed":
                False,
            "blockers": [
                "git add failed: "
                + (
                    add[
                        "stderr"
                    ]
                    or add[
                        "stdout"
                    ]
                )
            ],
            "execution_authorization":
                "NONE",
        }

    diff = _git(
        repo,
        [
            "diff",
            "--cached",
            "--quiet",
        ],
    )

    committed = False
    commit_hash = ""

    if diff[
        "returncode"
    ] == 1:
        message = (
            "Publish "
            + (
                preview.get(
                    "target_version"
                )
                or "release"
            )
            + " "
            + (
                preview.get(
                    "feed_sha256",
                    ""
                )[
                    :12
                ]
            )
        )

        commit = _git(
            repo,
            [
                "commit",
                "-m",
                message,
            ],
            timeout=120,
        )

        if commit[
            "returncode"
        ] != 0:
            return {
                "status":
                    "BLOCKED",
                "deployed":
                    False,
                "blockers": [
                    "git commit failed: "
                    + (
                        commit[
                            "stderr"
                        ]
                        or commit[
                            "stdout"
                        ]
                    )
                ],
                "execution_authorization":
                    "NONE",
            }

        committed = True

    elif diff[
        "returncode"
    ] != 0:
        return {
            "status":
                "BLOCKED",
            "deployed":
                False,
            "blockers": [
                "git diff --cached --quiet failed."
            ],
            "execution_authorization":
                "NONE",
        }

    head = _git(
        repo,
        [
            "rev-parse",
            "HEAD",
        ],
    )

    if head[
        "returncode"
    ] == 0:
        commit_hash = head[
            "stdout"
        ]

    push = _git(
        repo,
        [
            "push",
            "--set-upstream",
            config[
                "remote_name"
            ],
            (
                "HEAD:"
                + config[
                    "branch"
                ]
            ),
        ],
        timeout=180,
    )

    if push[
        "returncode"
    ] != 0:
        return {
            "status":
                "BLOCKED",
            "deployed":
                False,
            "committed":
                committed,
            "commit_hash":
                commit_hash,
            "blockers": [
                "git push failed. Configure Git authentication outside Stock Investment OS "
                "(for example Git Credential Manager or SSH key) and retry. "
                + (
                    push[
                        "stderr"
                    ]
                    or push[
                        "stdout"
                    ]
                )
            ],
            "credentials_stored_by_app":
                False,
            "execution_authorization":
                "NONE",
        }

    state = {
        "created_at":
            _now(),
        "status":
            "DEPLOYED_TO_GIT_REMOTE",
        "target_version":
            preview.get(
                "target_version"
            ),
        "repository_root":
            str(repo),
        "remote_name":
            config[
                "remote_name"
            ],
        "remote_url":
            config[
                "remote_url"
            ],
        "branch":
            config[
                "branch"
            ],
        "public_base_url":
            config[
                "public_base_url"
            ],
        "public_feed_url":
            (
                config[
                    "public_base_url"
                ].rstrip("/")
                + "/release_feed.json"
            ),
        "feed_sha256":
            preview.get(
                "feed_sha256"
            ),
        "commit_hash":
            commit_hash,
        "committed":
            committed,
        "credentials_stored_by_app":
            False,
        "execution_authorization":
            "NONE",
    }

    _write_json(
        deployment_state_path(
            root
        ),
        state,
    )

    return {
        **state,
        "deployed":
            True,
    }


def _read_public_bytes(
    url: str,
    *,
    allow_file: bool,
    max_bytes: int = 1024 * 1024,
) -> tuple[bytes, str]:
    ok, normalized, error = _validate_public_base_url(
        url.rsplit(
            "/release_feed.json",
            1,
        )[
            0
        ],
        allow_file=allow_file,
    )

    if not ok:
        raise ValueError(
            error
        )

    request = Request(
        url,
        headers={
            "User-Agent":
                "StockInvestmentOS-DeploymentVerifier/1.0",
            "Accept":
                "application/json,*/*",
        },
    )

    with urlopen(
        request,
        timeout=20,
    ) as response:
        final_url = response.geturl()

        if final_url != url:
            # Redirects must still stay on the same configured public base.
            parsed_expected = urlparse(
                normalized
            )
            parsed_actual = urlparse(
                final_url
            )

            if (
                parsed_expected.scheme
                != parsed_actual.scheme
                or parsed_expected.hostname
                != parsed_actual.hostname
            ):
                raise ValueError(
                    "Public feed redirect escaped configured HTTPS host."
                )

        data = response.read(
            max_bytes + 1
        )

        if len(data) > max_bytes:
            raise ValueError(
                "Public feed exceeded maximum size."
            )

        return (
            data,
            final_url,
        )


def verify_public_deployment(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    config = load_deployment_config(
        root
    )

    repo = Path(
        config[
            "repository_root"
        ]
    ).resolve()

    local_feed = (
        repo
        / "release_feed.json"
    )

    if not local_feed.is_file():
        return {
            "status":
                "BLOCKED",
            "blockers": [
                "Local release_feed.json is missing."
            ],
            "execution_authorization":
                "NONE",
        }

    feed_url = (
        str(
            config.get(
                "public_base_url",
                ""
            )
        ).rstrip("/")
        + "/release_feed.json"
    )

    try:
        public_bytes, resolved = _read_public_bytes(
            feed_url,
            allow_file=bool(
                config.get(
                    "allow_file_public_url"
                )
            ),
        )
    except Exception as exc:
        return {
            "status":
                "BLOCKED",
            "public_feed_url":
                feed_url,
            "blockers": [
                f"Public feed verification failed: {type(exc).__name__}: {exc}"
            ],
            "execution_authorization":
                "NONE",
        }

    local_bytes = local_feed.read_bytes()

    local_sha = hashlib.sha256(
        local_bytes
    ).hexdigest()

    public_sha = hashlib.sha256(
        public_bytes
    ).hexdigest()

    if public_sha != local_sha:
        return {
            "status":
                "BLOCKED",
            "public_feed_url":
                feed_url,
            "resolved_url":
                resolved,
            "local_feed_sha256":
                local_sha,
            "public_feed_sha256":
                public_sha,
            "blockers": [
                "Public release_feed.json does not match the local published feed."
            ],
            "execution_authorization":
                "NONE",
        }

    try:
        document = json.loads(
            public_bytes.decode(
                "utf-8"
            )
        )
    except Exception as exc:
        return {
            "status":
                "BLOCKED",
            "blockers": [
                f"Public feed JSON parse failed: {exc}"
            ],
            "execution_authorization":
                "NONE",
        }

    release = (
        document.get(
            "release"
        )
        or {}
    )

    result = {
        "created_at":
            _now(),
        "status":
            "PUBLIC_FEED_VERIFIED",
        "public_feed_url":
            feed_url,
        "resolved_url":
            resolved,
        "local_feed_sha256":
            local_sha,
        "public_feed_sha256":
            public_sha,
        "target_version":
            str(
                release.get(
                    "version",
                    ""
                )
            ).strip(),
        "package_sha256":
            str(
                release.get(
                    "package_sha256",
                    ""
                )
            ).strip(),
        "credentials_stored_by_app":
            False,
        "execution_authorization":
            "NONE",
    }

    prior = _read_json(
        deployment_state_path(
            root
        )
    )

    _write_json(
        deployment_state_path(
            root
        ),
        {
            **prior,
            **result,
            "last_action":
                "PUBLIC_VERIFY",
        },
    )

    return result


def bootstrap_client_feed(
    root: Path,
) -> dict[str, Any]:
    root = Path(root).resolve()
    config = load_deployment_config(
        root
    )

    verification = verify_public_deployment(
        root
    )

    if verification.get(
        "status"
    ) != "PUBLIC_FEED_VERIFIED":
        return {
            "status":
                "BLOCKED",
            "blockers":
                verification.get(
                    "blockers",
                    [
                        "Public feed must be verified before bootstrap."
                    ],
                ),
            "execution_authorization":
                "NONE",
        }

    public_feed_url = verification[
        "public_feed_url"
    ]

    parsed = urlparse(
        public_feed_url
    )

    allowed_hosts = []

    allow_file_source = bool(
        config.get(
            "allow_file_public_url"
        )
    )

    if parsed.scheme == "https":
        allowed_hosts = [
            parsed.hostname
        ]

    saved = save_trusted_feed_config(
        root,
        feed_url=public_feed_url,
        allowed_hosts=allowed_hosts,
        channel="stable",
        enabled=True,
        auto_sync=True,
        check_interval_minutes=int(
            config.get(
                "client_check_interval_minutes",
                60,
            )
        ),
        allow_file_source=allow_file_source,
    )

    if saved.get(
        "status"
    ) != "SAVED":
        return {
            "status":
                "BLOCKED",
            "blockers":
                saved.get(
                    "blockers",
                    [
                        "Trusted Feed bootstrap save failed."
                    ],
                ),
            "execution_authorization":
                "NONE",
        }

    check = check_trusted_release_feed(
        root
    )

    result = {
        "created_at":
            _now(),
        "status":
            "CLIENT_FEED_BOOTSTRAPPED",
        "feed_url":
            public_feed_url,
        "auto_sync":
            True,
        "check_interval_minutes":
            int(
                config.get(
                    "client_check_interval_minutes",
                    60,
                )
            ),
        "feed_check_status":
            check.get(
                "status"
            ),
        "feed_target_version":
            check.get(
                "target_version"
            ),
        "credentials_stored_by_app":
            False,
        "execution_authorization":
            "NONE",
    }

    prior = _read_json(
        deployment_state_path(
            root
        )
    )

    _write_json(
        deployment_state_path(
            root
        ),
        {
            **prior,
            **result,
            "last_action":
                "BOOTSTRAP_CLIENT_FEED",
        },
    )

    return result
