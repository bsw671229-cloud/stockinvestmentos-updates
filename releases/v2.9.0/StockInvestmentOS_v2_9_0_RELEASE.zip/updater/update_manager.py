from updater.release_manager import cli

if __name__ == "__main__":
    raise SystemExit(cli())
