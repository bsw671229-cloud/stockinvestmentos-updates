"""Local audit projection. Never runs update, network, approval or recovery."""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

HISTORY_NAME = "safe_update_orchestrator_history.json"
MAX_EVENTS = 500


def now() -> str:
    return datetime.now().astimezone().isoformat()


def _text(value: Any) -> str:
    return str(value or "").strip()


def _time(data: dict) -> str:
    return next((_text(data.get(k)) for k in (
        "finished_at", "checked_at", "verified_at", "updated_at",
        "created_at", "published_at", "generated_at", "started_at",
    ) if data.get(k)), "")


def _safe(path: Path, control: Path) -> bool:
    # Only explicit control paths, no recursive scans or symlink traversal.
    if any(p.lower() in {"runtime-data", "secrets"} for p in path.parts):
        return False
    try:
        path.relative_to(control)
        return not any(p.is_symlink() for p in (path, *path.parents))
    except (ValueError, OSError):
        return False


def _read(path: Path, control: Path, warnings: list[str]) -> dict:
    if not _safe(path, control):
        warnings.append(f"Unsafe audit path: {path.name}")
        return {}
    try:
        if not path.exists():
            return {}
        if path.stat().st_size > 8 * 1024 * 1024:
            raise ValueError("audit file exceeds size limit")
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("expected object")
        return data
    except (OSError, ValueError) as exc:
        warnings.append(f"Unreadable audit file: {path.name} ({type(exc).__name__})")
        return {}


def record_event(control: Path, result: dict) -> dict:
    """Append one completed attempt. Audit failure never repeats an operation.

    This follows the updater's single-operator model. Keeps 500 recent events;
    authoritative publisher/install/recovery journals remain unchanged.
    """
    path = control / "update_logs" / HISTORY_NAME
    warnings: list[str] = []
    data = _read(path, control, warnings)
    events = data.get("events", [])
    if warnings or not isinstance(events, list) or (bool(data) and data.get("schema_version") != 1):
        return {"recorded": False, "warning": "Audit history needs review; existing file preserved."}
    event = {
        "event_id": uuid4().hex,
        "observed_at": now(),
        "stage": _text(result.get("stage")),
        "status": _text(result.get("status")),
        "target_version": _text(result.get("target_version") or result.get("current_version")),
        "package_sha256": _text(result.get("package_sha256")),
        "restart_required": result.get("restart_required") is True,
        "blocker_count": len(result.get("blockers") or []),
        "execution_authorization": "NONE",
    }
    # Whitelist above deliberately excludes nested results, credentials and paths.
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + "." + event["event_id"] + ".tmp")
        tmp.write_text(json.dumps({"schema_version": 1, "events": (events + [event])[-MAX_EVENTS:]},
                                  ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        if "tmp" in locals():
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
        return {"recorded": False, "warning": "Audit write failed; operation result is unchanged."}
    return {"recorded": True, "event_id": event["event_id"]}


def release_history(control: Path) -> dict:
    """Read bounded explicit audit files, without mkdir or state mutation."""
    control = Path(control).absolute()
    warnings: list[str] = []
    rows: list[dict] = []
    logs = control / "update_logs"
    history = _read(logs / HISTORY_NAME, control, warnings)
    events = history.get("events", [])
    if not isinstance(events, list) or history.get("schema_version", 1) != 1:
        warnings.append("Invalid orchestrator history schema")
        events = []
    for event in events[-MAX_EVENTS:]:
        if isinstance(event, dict):
            rows.append({"source": HISTORY_NAME, "stage": event.get("stage"),
                         "status": event.get("status"), "version": event.get("target_version"),
                         "sha256": event.get("package_sha256"), "time": event.get("observed_at"),
                         "id": event.get("event_id")})
    published = _read(control / "trusted_repository" / "release_history.json", control, warnings)
    releases = published.get("releases", [])
    if not isinstance(releases, list):
        warnings.append("Invalid publisher history schema")
        releases = []
    for event in releases[-MAX_EVENTS:]:
        if isinstance(event, dict):
            rows.append({"source": "release_history.json", "stage": "LOCAL_PUBLISH",
                         "status": "PUBLISHED", "version": event.get("version"),
                         "sha256": event.get("package_sha256"), "time": event.get("published_at"),
                         "id": event.get("package_name")})
    if _safe(logs, control) and logs.is_dir():
        # Fixed journal prefixes only. Path references in documents are never followed.
        journals = sorted({p for pattern in ("UPD-*.json", "ROLLBACK-*.json", "RECOVERY-DRILL-*.json")
                           for p in logs.glob(pattern)}, key=lambda p: p.name, reverse=True)[:MAX_EVENTS]
        for path in journals:
            event = _read(path, control, warnings)
            if event:
                rows.append({"source": path.name, "stage": "RECOVERY_DRILL" if path.name.startswith("RECOVERY-DRILL-")
                             else "ROLLBACK" if path.name.startswith("ROLLBACK-") else "INSTALL",
                             "status": event.get("status"),
                             "version": event.get("target_version") or event.get("current_version"),
                             "sha256": event.get("package_sha256"), "time": _time(event), "id": path.stem})
    def timestamp(row: dict) -> float:
        try:
            value = datetime.fromisoformat(_text(row.get("time")))
            # Timezone-less historical evidence has no reliable absolute order.
            return value.timestamp() if value.tzinfo else float("-inf")
        except (ValueError, OverflowError):
            return float("-inf")
    rows.sort(key=timestamp, reverse=True)
    return {"rows": rows[:MAX_EVENTS], "warnings": warnings, "limit": MAX_EVENTS}


def build_dashboard(manager: dict, publisher: dict, deployment: dict, feed: dict,
                    operations: dict, recovery: dict, last: dict) -> dict:
    """Pure projection of actual component results; timestamps have separate roles."""
    observed = now()
    evidence = []
    for name, status, source, checked, stored in (
        ("Current", manager.get("current_version", "UNKNOWN"), "VERSION", observed, {}),
        ("Managed Code", "CLEAN" if manager.get("managed_code_clean") is True else "DRIFT" if manager.get("managed_code_clean") is False else "UNKNOWN", "Release Manager", observed, {}),
        ("Published", publisher.get("latest_published_version", "UNKNOWN"), "Local Publisher", observed, publisher.get("last_state") or {}),
        ("Public Verify", (deployment.get("last_state") or {}).get("status", "UNKNOWN"), "Deployment verification record", "", deployment.get("last_state") or {}),
        ("E2E", operations.get("status", "UNKNOWN"), "0D operations (local + saved public evidence)", observed, {}),
        ("Recovery", recovery.get("status", "UNKNOWN"), "0E recovery readiness", observed, {}),
        ("Recovery Drill", recovery.get("last_drill_status", "NOT_RUN"), "0E saved drill result", "", {}),
    ):
        evidence.append({"item": name, "status": status or "UNKNOWN", "source": source,
                         "evaluated_at": checked or "UNKNOWN", "saved_evidence_at": _time(stored) or "UNKNOWN"})
    conflicts = []
    old_recovery = (last.get("recovery") or {}).get("status")
    old_e2e = (last.get("operations") or {}).get("status")
    for name, old, actual in (("Recovery", old_recovery, recovery.get("status")),
                              ("E2E", old_e2e, operations.get("status"))):
        if old and actual and old != actual:
            conflicts.append(f"{name}: saved finalize={old}; current detailed gate={actual}. Detailed gate takes precedence.")
    status = _text(last.get("status")) or "NOT_RUN"
    target = _text(last.get("target_version") or last.get("current_version"))
    current = _text(manager.get("current_version"))
    stale = bool(target and target != current and status in {"FINAL_PASS", "FINAL_REVIEW", "INSTALL_APPLIED_RESTART_REQUIRED"})
    if stale:
        action = "이전 버전의 기록입니다. 현재 버전의 0D/0E 상세 근거를 확인하세요."
    elif status == "INSTALL_APPLIED_RESTART_REQUIRED":
        action = "앱을 종료 후 다시 실행하고 Post-update Finalize를 실행하세요."
    elif status in {"RELEASE_READY_TO_INSTALL", "PUBLISHED_DEPLOYED_VERIFIED"}:
        action = "승인된 RELEASE의 Install Gate를 확인한 뒤 별도로 설치를 승인하세요."
    elif status == "DEPLOYED_VERIFY_PENDING":
        action = "Public Feed 반영 후 같은 RELEASE의 Verify를 재시도하세요."
    elif status == "FINAL_PASS" and not conflicts and operations.get("status") == "PASS" and recovery.get("status") == "PASS":
        action = "최종검사 기록과 현재 상세 Gate가 일치합니다. 다음 RELEASE를 기다리세요."
    elif status in {"BLOCKED", "FAILED", "ROLLED_BACK", "FINAL_REVIEW", "FINAL_PASS"}:
        action = "현재 버전을 보존하고 실패 단계와 0D/0E 상세 근거를 확인하세요."
    else:
        action = "새 RELEASE가 있으면 Inbox와 SHA-256으로 Preflight를 확인하세요."
    return {"observed_at": observed, "evidence": evidence, "last_stage": last.get("stage", "UNKNOWN"),
            "last_status": status, "last_target_version": target or "UNKNOWN", "last_evidence_at": _time(last) or "UNKNOWN",
            "next_action": action, "conflicts": conflicts, "historical_record": stale,
            "auto_approval": False, "auto_apply": False, "execution_authorization": "NONE"}
