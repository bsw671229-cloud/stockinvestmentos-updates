# Stock Investment OS — Trusted Release Recovery / Rollback Readiness

## Goal

After each transactional Release Manager apply, prove that the latest backup is
actually usable before a production rollback is needed.

The recovery gate answers:

- Is managed code currently clean?
- Does a Release Manager `UPD-*.zip` backup exist?
- Is the backup ZIP structurally safe and CRC-clean?
- Does backup metadata contain source/target lineage?
- Can every predecessor manifest entry be reconstructed with its original SHA-256?
- Do backed-up Python files compile?
- Does `update_state.json` reference the same latest backup?
- Has a non-mutating recovery drill been run for the latest backup?
- Is investment Execution Authorization still `NONE`?

## 0E UI

Release Manager includes:

`0E) Trusted Release Recovery / Rollback Readiness`

`Non-mutating Recovery Drill` reconstructs the predecessor managed-code tree in
a temporary directory under `work/control/.update_staging`, verifies hashes and
Python compilation, records evidence under `work/control/update_logs`, and then
removes the temporary directory.

It does **not** modify the live application tree and does **not** execute a
rollback.

## CLI

```bat
python -m updater.update_manager recovery-status
python -m updater.update_manager recovery-drill
```

## Gate semantics

- `PASS`: latest backup is intact, lineage matches the running release, and the
  latest non-mutating drill passed.
- `REVIEW`: backup is structurally usable, but lineage or drill evidence needs
  operator review.
- `BLOCKED`: managed-code or backup integrity failed.

## Manual rollback boundary

Actual rollback remains the existing explicit Release Manager action:

```bat
python -m updater.update_manager rollback
```

The rollback command is intentionally separate from the recovery drill.

## Safety boundary

- Auto Approval = DISABLED
- Auto Apply = DISABLED
- Rollback is never automatically executed by 0E
- Execution Authorization = NONE
- `.env`, `data/`, `secrets/`, and `runtime-data/` must not be present in the
  recovery backup
