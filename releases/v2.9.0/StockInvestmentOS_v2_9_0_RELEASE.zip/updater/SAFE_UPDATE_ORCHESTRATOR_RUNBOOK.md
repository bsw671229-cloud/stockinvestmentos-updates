# Safe Update Orchestrator Runbook — v1.57.0

## Purpose

`0A) Safe Update Orchestrator / One-Click Workflow` composes the existing
Release Manager, Publisher, Static HTTPS Deployment, E2E Health, and Recovery
controls without removing their underlying gates.

The goal is to reduce repeated operator clicks while preserving two explicit
human decisions:

1. approve/publish a release after an out-of-band SHA-256 is supplied;
2. install a publicly verified approved release.

There is no unattended software approval or apply.

## Normal workflow

### A. Intake → Approve → Publish → Deploy → Verify

1. Copy final RELEASE ZIP and `RESULT: PASS` validation TXT to
   `work/control/releases/inbox`.
2. Select the inbox release in 0A.
3. Paste the published 64-character SHA-256.
4. Preflight automatically checks:
   - managed code clean,
   - inbox source,
   - exact package SHA-256,
   - sidecar validation `RESULT: PASS`,
   - Release Manager preview eligibility,
   - Publisher preview,
   - connected deployment configuration.
5. Explicitly confirm the publish action.
6. `Approve + Publish + Deploy + Verify` performs:
   - Release Manager approval,
   - local Trusted Repository publish,
   - deployment preview,
   - Git commit/push,
   - public `release_feed.json` verification,
   - Trusted Feed state refresh.

If GitHub Pages propagation is delayed, the result can be
`DEPLOYED_VERIFY_PENDING`. Re-running the same action is idempotent for the
same version/SHA and retries public verification.

### B. Install

`Install Verified RELEASE` is enabled only when:
- approval record is valid;
- package is still Release Manager eligible;
- public feed verification status is `PUBLIC_FEED_VERIFIED`;
- public target version equals the approved package target;
- public package SHA-256 equals the approved package SHA-256.

The install still uses the existing transactional backup/apply/post-verify
logic and automatic rollback on apply failure.

The running Streamlit process is not restarted automatically.

### C. Post-restart finalize

After manually restarting Stock Investment OS:
- run `Post-update E2E + Recovery Finalize`;
- the orchestrator runs the live Trusted Release E2E re-check;
- it runs the non-mutating recovery drill;
- FINAL PASS requires E2E PASS, Operating PASS, Feed UP_TO_DATE, Recovery PASS.

## Safety boundaries

- Auto Approval = DISABLED
- Auto Apply = DISABLED
- Execution Authorization = NONE
- Git credentials are not stored by Stock Investment OS
- User data / secrets are not included in release packages
- Actual rollback remains a separate explicit action
- The non-mutating recovery drill never performs rollback

## Advanced fallback

0B through 0E remain available as detailed/manual controls. If orchestration
stops at a stage, use the evidence in the result and the corresponding
advanced section to diagnose the blocker.
