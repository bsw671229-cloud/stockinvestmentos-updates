@echo off
setlocal
cd /d "%~dp0\.."
python updater\update_manager.py %*
set ERR=%ERRORLEVEL%
endlocal & exit /b %ERR%
