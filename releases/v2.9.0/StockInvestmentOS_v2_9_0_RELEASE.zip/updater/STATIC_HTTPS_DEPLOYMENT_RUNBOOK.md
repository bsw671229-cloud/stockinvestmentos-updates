# Stock Investment OS — Static HTTPS Deployment Connector

## Goal

Connect the locally generated Trusted Repository to a stable HTTPS host without
storing hosting credentials inside Stock Investment OS.

Recommended model:

```text
work/control/trusted_repository
        ↓ git commit + push
Git remote / static-site deployment
        ↓
stable HTTPS public base URL
        ↓
release_feed.json
        ↓
Trusted Release Feed auto discovery/download/inbox sync
```

## Security model

Stock Investment OS stores:
- repository root
- Git remote URL
- branch
- public HTTPS base URL

It does NOT store:
- GitHub/GitLab password
- access token
- private key passphrase

Git authentication must be configured outside Stock Investment OS using the
system Git credential manager or SSH key.

Embedded credentials in HTTPS remote URLs are blocked.

## Production Git remote

Allowed:
- https://github.com/<user>/<repo>.git
- ssh://...
- git@github.com:<user>/<repo>.git

Controlled local file:// remotes are test-only.

## Public base URL

Production must be HTTPS, for example:

```text
https://<user>.github.io/<repo>
```

The connector verifies that the public `release_feed.json` bytes match the
local publisher feed before bootstrapping the client.

## Workflow

1. Run Release Publisher first.
2. Save deployment config.
3. Initialize/connect Git repository.
4. Deployment Preview.
5. Git commit + push.
6. Verify public release_feed.json.
7. Bootstrap Trusted Feed client.

After step 7, the client's feed URL is fixed and Auto Sync is enabled.

## GitHub Pages example

Create a repository and configure GitHub Pages to serve the deployment branch.
Then configure:

- Git remote:
  `https://github.com/<USER>/<REPO>.git`
- Branch:
  `main`
- Public base URL:
  `https://<USER>.github.io/<REPO>`

The first Git authentication is performed outside Stock Investment OS.

## Important

The connector only deploys software-update repository files under work/control.
It does not access runtime-data/ or secrets/.

Auto approval/apply remain disabled in this stage.

Execution Authorization = NONE.
