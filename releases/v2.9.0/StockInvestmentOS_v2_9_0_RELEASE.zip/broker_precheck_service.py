"""Read-only order-specific checks. Never creates an executable order record."""
from datetime import datetime, timezone
import time

from broker_inquiry_service import resolve_reference, _diagnostic
from connectors.kis_broker import BrokerError, validate_order
from engine.broker_execution import check_snapshot, validate_limits


class _ReadOnlyClient:
    """Only the three inquiry methods needed by check_snapshot are exposed."""
    def __init__(self, client):
        self.client = client
        self.stage = 'QUOTE'

    def quote(self, order):
        self.stage = 'QUOTE'
        quote = self.client.quote(order)
        price, basis = resolve_reference({'status': 'PASS', 'data': quote}, 'QUOTE',
                                         '0', order['currency'])
        return {'price': price, 'currency': order['currency'],
                'fetched_at': basis['quote_fetched_at']}

    def buying_power(self, order):
        self.stage = 'BUYING_POWER'
        return self.client.buying_power(order)

    def sellable(self, order):
        self.stage = 'SELLABLE_QUANTITY'
        return self.client.sellable(order)


def run_precheck(client, order, limits):
    """Explicit fresh inquiries after local validation; session-only result."""
    started = time.monotonic()
    client.last_diagnostic = {}
    reader = None
    result = {'status': 'CHECK_REQUIRED', 'stage': 'INPUT'}
    try:
        order = validate_order(order)
        validate_limits(order, limits)
        reader = _ReadOnlyClient(client)
        snapshot = check_snapshot(reader, order, limits)
        result = {'status': 'PASS', 'stage': 'COMPLETE', 'order': order,
                  'snapshot': snapshot}
    except BrokerError as exc:
        result['message'] = str(exc)
    except Exception:
        result['message'] = '점검을 완료하지 못했습니다. 입력값과 연결 상태를 확인한 뒤 다시 점검하세요.'
    if result['status'] != 'PASS' and reader is not None:
        result['stage'] = reader.stage
    result.update(checked_at=datetime.now(timezone.utc).isoformat(),
                  elapsed_ms=round((time.monotonic() - started) * 1000),
                  diagnostic=_diagnostic(client.last_diagnostic))
    return result
