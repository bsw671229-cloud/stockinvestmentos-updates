"""Short-lived input transfer only. No broker calls, storage or order authority."""
from datetime import datetime, timezone

from connectors.kis_broker import validate_order
from engine.broker_execution import validate_limits


LIMIT_FIELDS = ('max_notional', 'fee_buffer_pct', 'max_quote_gap_pct',
                'downside_pct', 'max_scenario_loss')


class DraftError(ValueError):
    pass


def connection_context(client):
    return (client.credentials.identity, client.credentials.mode, id(client))


def is_fresh(checked_at, now=None):
    try:
        checked = datetime.fromisoformat(checked_at)
        current = now if now is not None else datetime.now(timezone.utc)
        if checked.tzinfo is None or current.tzinfo is None:
            return False
        return 0 <= (current - checked).total_seconds() <= 60
    except (TypeError, ValueError, OverflowError):
        return False


def make_draft(result, order, limits, context, now=None):
    """Called only after submitted form values match the last checked context."""
    try:
        if result.get('status') != 'PASS' or result.get('stage') != 'COMPLETE':
            raise ValueError
        if not is_fresh(result.get('checked_at'), now):
            raise ValueError
        checked = validate_order(order)
        if checked != result.get('order'):
            raise ValueError
        validate_limits(checked, limits)
        values = {name: str(limits[name]) for name in LIMIT_FIELDS}
        if checked['side'] == 'SELL':
            values.update(downside_pct='0', max_scenario_loss='0')
        return {'context': context, 'checked_at': result['checked_at'],
                'order': dict(checked), 'limits': values}
    except Exception:
        raise DraftError('같은 연결에서 입력·조회 점검을 다시 통과한 뒤 60초 안에 가져오세요.') from None


def draft_widget_values(draft, context, now=None):
    """Validate fully before the caller changes any widget state."""
    try:
        if draft['context'] != context or not is_fresh(draft['checked_at'], now):
            raise ValueError
        order = validate_order(draft['order'])
        if order != draft['order']:
            raise ValueError
        limits = draft['limits']
        if set(limits) != set(LIMIT_FIELDS) or any(type(v) is not str for v in limits.values()):
            raise ValueError
        # Arithmetic validation only; the output always clears user attestation.
        validate_limits(order, {**limits, 'risk_attested': True})
        market = order['market']
        return {'kis_market': market, 'kis_exchange_' + market: order['exchange'],
                'kis_side': order['side'], 'kis_symbol_' + market: order['symbol'],
                'kis_quantity': order['quantity'], 'kis_price_' + market: order['limit_price'],
                'kis_cap_' + market: limits['max_notional'], 'kis_fee': limits['fee_buffer_pct'],
                'kis_gap': limits['max_quote_gap_pct'], 'kis_downside': limits['downside_pct'],
                'kis_loss_' + market: limits['max_scenario_loss'],
                'kis_risk_attested': False, 'kis_allow_live': False}
    except Exception:
        raise DraftError('점검 조건을 가져오지 못했습니다. 현재 연결에서 다시 점검하세요.') from None
