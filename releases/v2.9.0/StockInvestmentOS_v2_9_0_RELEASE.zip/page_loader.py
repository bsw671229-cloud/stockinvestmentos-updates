"""Lazy execution of allowlisted app-owned scripts in the legacy shared namespace."""
from functools import lru_cache
from pathlib import Path

PAGES = {'Decision Workbench v2': 'legacy_00.py', 'Start Here': 'legacy_01.py', 'Operations Control Tower': 'legacy_02.py', 'Decision Summary': 'legacy_03.py', 'Action Planner': 'legacy_04.py', 'Stability Audit': 'legacy_05.py', 'System Integration': 'legacy_06.py', 'Save Center': 'legacy_07.py', 'Factor Exposure': 'legacy_08.py', 'Factor Risk Repair': 'legacy_09.py', 'Portfolio Risk Repair': 'legacy_10.py', 'Dashboard': 'legacy_11.py', 'Daily Briefing': 'legacy_12.py', 'Monitoring Center': 'legacy_13.py', 'Review Queue': 'legacy_14.py', 'Thesis Monitor': 'legacy_15.py', 'KPI Monitor': 'legacy_16.py', 'Alerts': 'legacy_17.py', 'Data Quality': 'legacy_18.py', 'Reconciliation': 'legacy_19.py', 'Migration Manager': 'legacy_20.py', 'Release Manager': 'legacy_21.py', 'Auto Update': 'legacy_22.py', 'Market Universe': 'legacy_23.py', 'Quant Screener': 'legacy_24.py', 'Portfolio': 'legacy_25.py', 'ETF Look-through': 'legacy_26.py', 'Screening': 'legacy_27.py', 'Investment State': 'legacy_28.py', 'Fundamental Engine': 'legacy_29.py', 'Reverse DCF': 'legacy_30.py', 'Scenario Refresh': 'legacy_31.py', 'Scenario Reconciliation': 'legacy_32.py', 'Position Sizing': 'legacy_33.py', 'Portfolio Fit': 'legacy_34.py', 'Portfolio Risk 2.0': 'legacy_35.py', 'CAR Concentration Repair': 'legacy_36.py', 'Capital Migration': 'legacy_37.py', 'Capital Productivity': 'legacy_38.py', 'Stress Lab': 'legacy_39.py', 'Marginal Risk': 'legacy_40.py', 'Trade Planner': 'legacy_41.py', 'Rebalance Planner': 'legacy_42.py', 'Scenario Compare': 'legacy_43.py', 'Execution Checklist': 'legacy_44.py', 'Fill Reconciliation': 'legacy_45.py', 'Post-Trade Audit': 'legacy_46.py', 'Proof Clock': 'legacy_47.py', 'Decision Journal': 'legacy_48.py', 'Override Registry': 'legacy_49.py', 'Snapshot History': 'legacy_50.py', 'Reports & Scheduler': 'legacy_51.py', 'Primary Source Monitor': 'legacy_52.py', 'Evidence Batch Review': 'legacy_53.py', 'Evidence Intake': 'legacy_54.py', 'Evidence Impact Review': 'legacy_55.py', 'Evidence': 'legacy_56.py', 'OpenDART Auto': 'legacy_57.py', 'Market Data': 'legacy_58.py', 'Settings': 'legacy_59.py'}

@lru_cache(maxsize=64)
def _compiled(path: str, source: bytes):
    return compile(source, path, 'exec', dont_inherit=True)

def render_page(name: str, namespace: dict):
    filename = PAGES.get(name)
    if filename is None:
        raise ValueError('Unknown application page')
    path = Path(__file__).resolve().parent / 'app_pages' / filename
    # Read current bytes each rerun: content changes cannot reuse old compiled code.
    code = _compiled(str(path), path.read_bytes())
    exec(code, namespace)
