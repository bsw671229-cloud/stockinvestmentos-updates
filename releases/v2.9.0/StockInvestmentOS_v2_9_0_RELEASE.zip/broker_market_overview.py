"""A session-only, explicit domestic/US operational inquiry overview."""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import streamlit as st
from broker_inquiry_service import run_market_checks


def render(client, clear_results):
    st.caption('국내와 미국을 순서대로 조회합니다. 각 시장의 새 시세로 가능금액을 계산하고 잔고를 확인합니다.')
    domestic = st.text_input('국내 조회 종목코드', value='005930', key='kis_ro_both_KR').strip().upper()
    exchange = st.selectbox('미국 조회 거래소', ['NASD', 'NYSE', 'AMEX'], key='kis_ro_both_exchange')
    us_symbol = st.text_input('미국 조회 종목코드', value='AAPL', key='kis_ro_both_US').strip().upper()
    context = (client.credentials.identity, 'BOTH', domestic, exchange, us_symbol)
    if st.session_state.get('_kis_inquiry_context') != context:
        clear_results()
        st.session_state['_kis_inquiry_context'] = context
    st.caption('입력한 종목은 조회 기준입니다. 투자 추천이나 매매 지시가 아닙니다.')
    if st.button('국내·미국 한 번에 점검', key='kis_ro_both_check', type='primary'):
        st.session_state.pop('_kis_market_report', None)
        progress = st.empty()
        def update(completed, total, label):
            progress.progress(completed / total, text=label)
        report = run_market_checks(client, domestic, exchange, us_symbol,
            version=Path(__file__).with_name('VERSION').read_text(encoding='utf-8-sig').strip(),
            progress=update)
        st.session_state['_kis_market_report'] = report
        progress.empty()
    report = st.session_state.get('_kis_market_report')
    if report:
        if report['status'] == 'PASS':
            st.success('국내·미국의 시세·주문 가능금액·잔고 조회가 모두 성공했습니다.')
        else:
            st.warning('일부 항목을 확인하지 못했습니다. 시장별 결과와 진단을 확인하세요.')
        rows = []
        labels = {'quote': '시세', 'power': '주문 가능금액', 'positions': '잔고'}
        statuses = {'PASS': '조회 성공', 'CHECK_REQUIRED': '확인 필요', 'SKIPPED': '건너뜀', 'UNKNOWN': '미확인'}
        kst = timezone(timedelta(hours=9))
        for market, label in (('KR', '국내'), ('US', '미국')):
            check = report['markets'][market]
            for name, item in labels.items():
                row = check['checks'][name]
                rows.append({'시장': label, '항목': item, '결과': statuses[row['status']],
                    '소요 시간(ms)': row['elapsed_ms']})
        st.table(rows, alt='국내와 미국의 시세, 주문 가능금액, 잔고 조회 결과와 항목별 소요 시간')
        for market, label in (('KR', '국내'), ('US', '미국')):
            check = report['markets'][market]
            timestamp = datetime.fromisoformat(check['finished_at']).astimezone(kst).strftime('%Y-%m-%d %H:%M:%S KST')
            st.caption(f"{label} 완료: {timestamp} · {check['elapsed_ms']}ms")
            if check['status'] != 'PASS':
                with st.expander(label + ' 조회 진단'):
                    st.json(check['checks'])
        st.caption(f"전체 소요 시간: {report['elapsed_ms']}ms · 두 시장을 순서대로 확인한 시점별 기록입니다.")
        st.info('상세 가격·잔고·금액은 조회 범위를 ‘선택 시장’으로 바꾸어 확인하세요. 범위를 바꾸면 점검 결과를 지웁니다.')
        st.download_button('통합 점검 결과 저장', data=json.dumps(report, ensure_ascii=False, indent=2),
            file_name='StockInvestmentOS_market_checks.json', mime='application/json',
            key='kis_ro_both_report', on_click='ignore')
        st.caption('저장 파일에는 환경·상태·시각·오류 코드만 포함합니다. 키·계좌·종목·보유 내역·가격·금액은 제외합니다.')
    st.caption('자동으로 반복 조회하지 않습니다. 결과는 이 연결과 현재 입력에 대한 세션 기록이며 주문 허용·체결 확인이 아닙니다.')
