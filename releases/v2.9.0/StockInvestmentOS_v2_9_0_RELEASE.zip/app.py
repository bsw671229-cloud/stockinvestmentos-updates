
from __future__ import annotations
import io, os, hashlib
import json
from pathlib import Path
from datetime import date, timedelta, datetime

import pandas as pd
import numpy as np

# Pandas Copy-on-Write compatibility:
# engine/marginal_risk.py predates pandas CoW and mutates a DataFrame-backed
# NumPy view via np.fill_diagonal(cm.values, 1.0). Under CoW that view is
# read-only and raises "ValueError: underlying array is read-only".
# Keep legacy engine behavior writable until marginal_risk is refactored.
try:
    pd.options.mode.copy_on_write = False
except Exception:
    pass

import streamlit as st
from dotenv import load_dotenv, set_key, unset_key

from migration.work_ready_paths import (
    bootstrap_work_ready_environment,
    resolve_env_path,
    load_work_ready_layout,
)
from migration.work_ready_migrator import (
    default_target_home,
    plan_migration as work_ready_plan_migration,
    execute_migration as work_ready_execute_migration,
    verify_migration as work_ready_verify_migration,
    repair_work_ready_launcher,
)

_WORK_READY_LAYOUT = bootstrap_work_ready_environment(
    Path(__file__).resolve().parent
)

from updater.repository_deployer import (
    load_deployment_config,
    save_deployment_config,
    connect_git_repository,
    deployment_status,
    preview_deployment,
    deploy_repository,
    verify_public_deployment,
    bootstrap_client_feed,
)
from updater.release_publisher import (
    default_repository_root,
    publisher_status,
    preview_release_publish,
    publish_release_repository,
)
from updater.release_feed import (
    trusted_release_feed_status,
    save_trusted_feed_config,
    check_trusted_release_feed,
    sync_trusted_release_to_inbox,
    maybe_auto_sync_trusted_release,
)
from updater.trusted_release_operations import (
    trusted_release_operations_status,
    trusted_release_operations_live_check,
)
from updater.release_recovery import (
    trusted_release_recovery_status,
    trusted_release_recovery_drill,
)
from updater.ui_state_v2 import store_finalize_result
from decision_workbench_v2 import render as render_decision_workbench_v2

from updater.safe_update_orchestrator import (
    safe_update_orchestrator_status,
    preflight_inbox_release as safe_update_preflight_inbox_release,
    approve_publish_deploy as safe_update_approve_publish_deploy,
    install_readiness as safe_update_install_readiness,
    install_verified_release as safe_update_install_verified_release,
    finalize_after_restart as safe_update_finalize_after_restart,
)
from updater.release_manager import (
    ensure_runtime_dirs,
    status_report as release_manager_status_report,
    candidate_inventory as release_manager_scan_candidates,
    preview_release as release_manager_preview_release,
    approve_release as release_manager_approve_release,
    apply_release as release_manager_apply_release,
    retire_approved_release as release_manager_retire_approved_release,
    rollback_latest as release_manager_rollback_latest,
    acknowledge_running_version as release_manager_acknowledge_running_version,
)
from storage import (
    load_csv, save_csv, load_settings, save_settings, backup_user_data,
    verify_user_data_health, get_save_events, latest_user_backup
)
from engine.portfolio import normalize_portfolio, factor_exposure, portfolio_summary
from engine.screening import screen_candidates
from engine.valuation import dcf_value, reverse_implied_growth
from engine.market_expectations import (
    dcf_per_share,
    solve_implied_growth,
    required_fcf_per_share,
    solve_implied_fcf_margin,
    solve_implied_required_return,
    solve_implied_terminal_growth,
    capital_intensity_translation,
    anchor_integrity_status,
    build_annual_source_anchor,
    break_even_fcf_table,
    cap_gap,
    expectation_pressure_summary,
    assumption_readiness,
    scenario_values,
    scenario_driver_diagnostics,
    scenario_driver_seed,
    scenario_governance_gate,
    scenario_driver_requirements,
    scenario_template_text,
    apply_scenario_template,
    scenario_template_status,
    apply_scenario_text_inputs,
    REVERSE_SCENARIO_DRAFT_COLS,
    normalize_reverse_scenario_drafts,
    scenario_editor_from_saved_draft,
    upsert_reverse_scenario_draft,
    delete_reverse_scenario_draft,
    scenario_draft_fingerprint,
    sensitivity_matrix,
)
from engine.scenario_refresh import (
    SCENARIO_REFRESH_COLS, canonical_proxy_snapshot,
    snapshot_from_approved_record, scenario_valuation,
    scenario_refresh_comparison, latest_approved_refresh,
    scenario_refresh_record
)
from engine.scenario_reconciliation import (
    SCENARIO_RECONCILIATION_COLS, build_scenario_reconciliation,
    apply_scenario_reconciliation, reconciliation_status_for_scenario,
    reconciliation_record
)
from engine.evidence_intake import (
    EVIDENCE_PACKET_COLS, SOURCE_TIER_MAP,
    normalize_evidence_packets, source_tier_for_type,
    validate_evidence_packet, build_evidence_packet,
    enrich_evidence_packets, latest_approved_packet,
    approved_packet_summary
)
from engine.evidence_batch import (
    build_evidence_batch_queue, evidence_batch_summary,
    filter_evidence_batch_queue, company_open_candidates,
    candidate_review_guide, build_evidence_diff,
    previous_approved_packet
)
from engine.fundamentals import (
    FUNDAMENTAL_SNAPSHOT_COLS,
    normalize_fundamental_snapshots,
    latest_fundamental_snapshot,
    reviewed_snapshot_for_period,
    latest_comparable_fundamental_snapshot,
    source_period_growth_preview,
    build_source_backed_suggestions,
    build_capital_allocation_metrics,
    build_fundamental_metrics,
    build_fundamental_snapshot_record,
    append_fundamental_snapshot,
    snapshot_integrity_status,
    fundamental_snapshot_hash_report,
    repair_fundamental_snapshot_hashes,
    migrate_verified_v2_to_v3,
    remove_blocked_current_period_snapshots,
    fundamental_snapshot_duplicate_report,
    consolidate_exact_fundamental_duplicates,
)
from engine.source_monitor import (
    SOURCE_CANDIDATE_COLS, normalize_source_candidates,
    ingest_disclosures, enrich_source_candidates, open_source_candidates,
    mark_candidate_status, candidate_handoff, source_monitor_summary,
    repair_selected_candidate_from_disclosures,
    repair_candidate_with_selected_disclosure,
    duplicate_receipt_summary,
    consolidate_duplicate_receipts
)
from engine.evidence_impact import (
    IMPACT_REVIEW_COLS,
    THESIS_IMPACTS, VALUATION_ACTIONS, ADD_FREEZE_ACTIONS,
    LIFECYCLE_ACTIONS, SCENARIO_ACTIONS, PORTFOLIO_ACTIONS,
    normalize_impact_reviews, validate_impact_review,
    build_evidence_impact_review, enrich_impact_reviews,
    latest_approved_impact_review, evidence_impact_status
)
from engine.risk import final_position_max, shares_for_weight
from engine.risk_assumptions import (
    resolve_shared_risk_assumptions, sync_shared_risk_assumptions,
    save_canonical_assumptions
)
from engine.integration_audit import (
    build_global_integration_audit, company_integration_trace,
    sync_portfolio_from_watchlist, canonical_missing_queue
)
from engine.decision_summary import build_one_page_decision_summary
from engine.action_planner import (
    ACTION_PLAN_REVIEW_COLS, build_integrated_action_plan,
    action_plan_review_row
)
from engine.stability_audit import (
    package_structure_audit, csv_health_audit,
    integration_table_audit, company_runtime_audit,
    scenario_governance_audit, evidence_provenance_audit,
    evidence_impact_audit, decision_journal_audit, source_monitor_audit,
    marginal_risk_review_audit, monitoring_automation_audit,
    factor_operating_audit,
    consolidate_audits, audit_summary as stability_audit_summary
)
from engine.factor_exposure import (
    normalize_factor_loadings, upsert_factor_loading, delete_factor_loading,
    approved_profile, all_factor_exposures, portfolio_factor_exposure,
    loading_status_table
)
from engine.factor_repair import (
    factor_repair_overview, simulate_factor_repair,
    breached_factor_contexts_for_asset, factor_migration_effect
)
from engine.portfolio_repair import (
    repair_universe, simulate_portfolio_repair,
    minimum_gross_trim_benchmark, pro_rata_repair_benchmark,
    portfolio_repair_review_row, PORTFOLIO_REPAIR_REVIEW_COLS
)
from engine.portfolio_fit import portfolio_fit_review
from engine.migration import (
    net_switching_gap, portfolio_cash_krw, capital_migration_review,
    migration_review_row, MIGRATION_REVIEW_COLS
)
from engine.migration_v2 import (
    estimate_switching_costs, recipient_factor_risk_impact,
    capital_migration_review_v2, migration_v2_review_row,
    MIGRATION_V2_REVIEW_COLS
)
from engine.risk_repair_override import (
    RISK_REPAIR_OVERRIDE_COLS,
    risk_repair_eligibility,
    risk_repair_governance_gate,
    risk_repair_override_record,
)
from engine.capital_productivity import (
    CAPITAL_PRODUCTIVITY_INPUT_COLS,
    normalize_capital_productivity_inputs,
    capital_productivity_universe,
    capital_productivity_save_rows,
    capital_competition_table,
    capital_competition_summary,
    CAPITAL_PRODUCTIVITY_ASSIST_COLS,
    capital_productivity_source_assist,
    apply_capital_productivity_source_assist,
    CAPITAL_PRODUCTIVITY_REVIEW_ASSIST_COLS,
    capital_productivity_forward_risk_assist,
    validate_capital_productivity_manual_review,
    apply_reviewed_capital_productivity_assumption,
    CAPITAL_PRODUCTIVITY_CALIBRATION_COLS,
    validate_forward_risk_calibration,
    calibration_point_values,
    apply_calibrated_capital_productivity_assumption,
    capital_productivity_calibration_record,
    CAPITAL_PRODUCTIVITY_CALIBRATION_DRAFT_COLS,
    normalize_calibration_drafts,
    build_calibration_draft,
    calibration_draft_integrity,
    calibration_reference_hash,
    calibration_approval_gate,
    approve_calibration_draft,
    apply_approved_calibration_draft,
    approved_calibration_audit_record,
    CAPITAL_HOLD_REVIEW_COLS,
    capital_hold_context,
    capital_hold_governance_gate,
    capital_hold_review_row,
)
from engine.capital_productivity_monitor import (
    ASSUMPTION_HEALTH_COLS,
    build_assumption_health,
    assumption_health_summary,
    apply_assumption_health_gate,
    ASSUMPTION_REVIEW_QUEUE_COLS,
    build_capital_productivity_health_context,
    build_assumption_review_queue,
    assumption_review_queue_summary,
)

from engine.capital_productivity_revalidation import (
    REVALIDATION_COLS,
    normalize_revalidations,
    build_revalidation_context,
    validate_revalidation,
    build_revalidation_record,
    apply_revalidation,
    latest_revalidation_record,
    revalidation_record_integrity,
    revalidation_lineage_integrity,
    post_revalidation_integrity,
)

from engine.capital_migration_bridge import (
    MIGRATION_BRIDGE_REVIEW_COLS,
    build_migration_assumption_bridge,
    migration_bridge_reference,
    reconcile_migration_assumption_bridge,
    migration_bridge_review_row,
)

from engine.capital_migration_cash_repair import (
    CASH_REPAIR_REVIEW_COLS,
    build_cash_reserve_repair_plan,
    cash_repair_review_row,
    CASH_REPAIR_QUANTITY_REVIEW_COLS,
    build_cash_repair_quantity_step,
    cash_repair_quantity_review_row,
    CASH_REPAIR_SENSITIVITY_REVIEW_COLS,
    build_cash_repair_price_sensitivity,
    cash_repair_sensitivity_review_row,
    CASH_REPAIR_QUOTE_VALIDATION_COLS,
    validate_cash_repair_pretrade_quote,
    cash_repair_quote_validation_review_row,
)

from engine.pretrade_decision_packet import (
    PRETRADE_PACKET_COLS,
    PRETRADE_PACKET_FRESHNESS_COLS,
    build_pretrade_packet_context,
    validate_pretrade_packet_review,
    build_pretrade_packet_record,
    pretrade_packet_integrity,
    evaluate_pretrade_packet_freshness,
    build_pretrade_packet_freshness_record,
)

from engine.auto_update import refresh_watchlist_prices, refresh_portfolio_values
from engine.state import add_states, add_state_machine_reviews, lifecycle_transition_review
from engine.proof_clock import enrich_proof_clock
from engine.alerts import build_alerts
from engine.snapshots import save_snapshot, list_snapshots, compare_latest_two
from engine.reconcile import reconcile_portfolio, portfolio_rows_with_reconciliation
from engine.rebalance import build_rebalance_summary
from engine.reporting import write_daily_report, list_daily_reports
from engine.audit import data_quality_report, apply_audit_gate, audit_summary
from engine.overrides import OVERRIDE_COLS, validate_overrides, active_overrides
from engine.journal import JOURNAL_COLS, new_entry, journal_summary
from engine.decision_journal_v2 import (
    DECISION_RECORD_COLS, OUTCOME_REVIEW_COLS, DECISION_TYPES,
    OUTCOME_CLASSIFICATIONS, FORECAST_ERROR_CLASSES, PROCESS_ADHERENCE,
    normalize_decision_records, normalize_outcome_reviews,
    validate_decision_record, validate_outcome_review,
    build_decision_record, build_outcome_review,
    enrich_decision_records, enrich_outcome_reviews,
    latest_approved_decision, decision_journal_v2_summary
)
from engine.scenario import compare_two_repair_scenarios, scenario_summary_cards
from engine.execution import build_strict_execution_checklist, position_sizing_execution_gate
from engine.fills import FILL_COLS, preview_actual_fill, fill_log_row
from engine.pretrade_fill_lineage import (
    PRETRADE_FILL_LINEAGE_COLS,
    PRETRADE_POSTTRADE_LINEAGE_COLS,
    evaluate_pretrade_fill_link,
    build_pretrade_fill_lineage_record,
    pretrade_fill_lineage_integrity,
    build_pretrade_posttrade_lineage_record,
    pretrade_posttrade_lineage_integrity,
)
from engine.decision_learning_lineage import (
    DECISION_LEARNING_LINEAGE_COLS,
    evaluate_decision_learning_lineage,
    validate_learning_lineage_review,
    build_decision_learning_lineage_record,
    decision_learning_lineage_integrity,
)
from engine.learning_feedback_governance import (
    LEARNING_FEEDBACK_COLS,
    LEARNING_FEEDBACK_TARGETS,
    LEARNING_FEEDBACK_DIRECTIONS,
    learning_feedback_source_context,
    validate_learning_feedback_proposal,
    build_learning_feedback_record,
    learning_feedback_record_integrity,
)
from engine.learning_feedback_revalidation_bridge import (
    LEARNING_FEEDBACK_REVALIDATION_DRAFT_COLS,
    build_feedback_revalidation_context,
    validate_feedback_revalidation_draft,
    build_feedback_revalidation_draft_record,
    feedback_revalidation_draft_integrity,
    build_learning_feedback_bridge_queue,
    learning_feedback_bridge_queue_summary,
)
from engine.learning_feedback_change_lineage import (
    FEEDBACK_CLOSURE_ACTIONS,
    LEARNING_FEEDBACK_CHANGE_LINEAGE_COLS,
    build_feedback_change_context,
    validate_feedback_closure,
    build_feedback_change_lineage_record,
    feedback_change_lineage_integrity,
    latest_feedback_closure_record,
    build_feedback_closure_queue,
    feedback_closure_queue_summary,
)
from engine.learning_cycle_audit import (
    LEARNING_CYCLE_AUDIT_SNAPSHOT_COLS,
    build_learning_cycle_orphans,
    build_learning_cycle_coverage,
    learning_cycle_audit_summary,
    build_learning_cycle_audit_snapshot,
)
from engine.learning_cycle_release_gate import (
    build_learning_cycle_release_gate,
    combined_release_readiness,
)
from engine.forecast_error_recurrence import (
    FORECAST_RECURRENCE_SNAPSHOT_COLS,
    build_forecast_error_recurrence,
    build_forecast_recurrence_queue,
    build_forecast_recurrence_snapshot,
)
from engine.forecast_change_registry import (
    FORECAST_CHANGE_AREAS,
    FORECAST_CHANGE_PLAN_COLS,
    expected_change_area,
    validate_forecast_change_plan,
    build_forecast_change_plan_record,
    forecast_change_plan_integrity,
    build_forecast_change_queue,
)
from engine.forecast_change_implementation import (
    FORECAST_IMPLEMENTATION_ACTIONS,
    FORECAST_IMPLEMENTATION_COLS,
    validate_forecast_implementation_event,
    build_forecast_implementation_record,
    forecast_implementation_integrity,
    latest_forecast_implementation,
    build_before_after_cohort,
    build_forecast_implementation_queue,
)
from engine.forecast_change_effect_review import (
    EFFECT_CLASSIFICATIONS,
    EFFECT_REVIEW_ACTIONS,
    FORECAST_EFFECT_REVIEW_COLS,
    expected_effect_classification,
    validate_forecast_effect_review,
    build_forecast_effect_review_record,
    forecast_effect_review_integrity,
    latest_forecast_effect_review,
    build_forecast_effect_queue,
)
from engine.forecast_calibration_release_gate import (
    build_forecast_calibration_release_gate,
)
from engine.release_readiness_v123 import (
    build_v123_release_readiness,
    build_v123_integration_crosscheck,
    build_v123_data_crosscheck,
)
from engine.recovery_readiness import (
    RECOVERY_SNAPSHOT_COLS,
    build_recovery_readiness,
    build_recovery_queue,
    build_recovery_snapshot,
)
from engine.backup_manifest_recovery import (
    RECOVERY_POINT_LOCK_COLS,
    discover_latest_backup_folder,
    verify_backup_manifest,
    restore_dry_run,
    validate_recovery_point_lock,
    build_recovery_point_lock_record,
    recovery_point_lock_integrity,
    latest_matching_recovery_point,
    build_manifest_recovery_queue,
)
from engine.recovery_resilience import (
    RECOVERY_RESILIENCE_SNAPSHOT_COLS,
    build_recovery_point_drift,
    build_backup_rotation_plan,
    build_restore_simulation_plan,
    build_recovery_resilience_queue,
    build_recovery_resilience_snapshot,
)
from engine.recovery_release_governance import (
    DR_RUNBOOK_LOCK_COLS,
    build_recovery_release_gate,
    latest_matching_runbook_lock,
    validate_dr_runbook_lock,
    build_dr_runbook_lock_record,
    dr_runbook_lock_integrity,
    build_recovery_release_queue,
)
from engine.release_readiness_v124 import (
    build_recovery_integration_context,
    build_v124_release_readiness,
    build_v124_integration_crosscheck,
    build_v124_data_crosscheck,
)
from engine.schema_evolution_guard import (
    SCHEMA_BASELINE_LOCK_COLS,
    inspect_csv_schemas,
    schema_scan_summary,
    latest_schema_baseline,
    schema_baseline_integrity,
    compare_schema_to_baseline,
    build_schema_snapshot,
    build_schema_migration_dry_run,
    validate_schema_baseline_lock,
    build_schema_baseline_lock_record,
    build_schema_review_queue,
)
from engine.schema_migration_contract import (
    SCHEMA_MIGRATION_PROPOSAL_COLS,
    SCHEMA_CONTRACT_LOCK_COLS,
    build_schema_compatibility_matrix,
    migration_proposal_summary,
    validate_schema_migration_proposal,
    build_schema_migration_proposal_record,
    schema_migration_proposal_integrity,
    latest_schema_contract,
    schema_contract_integrity,
    assess_schema_contract,
    validate_schema_contract_lock,
    build_schema_contract_lock_record,
    build_schema_contract_queue,
)
from engine.schema_migration_proof import (
    SCHEMA_MIGRATION_PROOF_COLS,
    latest_proposal_for_file,
    latest_matching_proof,
    build_schema_contract_drift,
    validate_migration_proof,
    build_migration_proof_record,
    migration_proof_integrity,
    build_compatibility_closure,
    build_schema_proof_queue,
)
from engine.schema_refresh_closure import (
    SCHEMA_REFRESH_APPROVAL_COLS,
    schema_refresh_approval_integrity,
    latest_schema_refresh_approval,
    validate_schema_refresh_approval,
    build_schema_refresh_approval_record,
    build_schema_refresh_closure,
    build_schema_refresh_queue,
)
from engine.release_readiness_v125 import (
    build_schema_governance_context,
    build_schema_governance_release_gate,
    build_v125_release_readiness,
    build_v125_integration_crosscheck,
    build_v125_data_crosscheck,
)
from engine.operations_control_tower import (
    build_operations_control_tower,
    build_daily_operating_sequence,
    top_actions,
)
from engine.review_queue_compression import (
    compress_review_queue,
    build_session_worklist,
    group_detail,
)
from engine.operations_session import (
    OPERATIONS_SESSION_COLS,
    operations_session_integrity,
    current_open_session,
    latest_closed_session,
    build_open_session_record,
    validate_close_session,
    build_close_session_record,
)
from engine.operations_release_gate import (
    build_operations_session_release_gate,
    build_v126_release_readiness,
    build_v126_integration_crosscheck,
    build_v126_data_crosscheck,
)
from engine.operations_carry_forward import (
    CARRY_FORWARD_SNAPSHOT_COLS,
    build_carry_forward_aging,
    build_review_capacity_plan,
    build_carry_forward_queue,
    build_carry_forward_snapshot,
)
from engine.operations_recurrence import (
    RECURRENCE_SNAPSHOT_COLS,
    build_recurrence_diagnostics,
    build_capacity_rebalance_plan,
    build_recurrence_queue,
    build_recurrence_snapshot,
)
from engine.operations_sla_governance import (
    CAPACITY_OVERRIDE_COLS,
    SLA_CLOSURE_SNAPSHOT_COLS,
    capacity_override_integrity,
    validate_capacity_override,
    build_capacity_override_record,
    latest_active_override,
    effective_capacity,
    build_sla_release_gate,
    build_sla_queue,
    build_sla_closure_snapshot,
)
from engine.release_readiness_v127 import (
    build_v127_operating_context,
    build_v127_technical_release_gate,
    build_v127_release_readiness,
    build_v127_integration_crosscheck,
    build_v127_data_crosscheck,
)
from engine.operations_flow_efficiency import (
    FLOW_SNAPSHOT_COLS,
    flow_snapshot_integrity,
    latest_flow_snapshot,
    build_flow_diagnostics,
    build_flow_queue,
    build_flow_snapshot,
)
from engine.operations_flow_trend import (
    FLOW_TREND_SNAPSHOT_COLS,
    flow_trend_snapshot_integrity,
    build_flow_trend_snapshot,
    build_flow_trend,
    build_flow_trend_queue,
)
from engine.operations_flow_evidence_quality import (
    FLOW_EVIDENCE_SNAPSHOT_COLS,
    flow_evidence_snapshot_integrity,
    latest_flow_evidence_snapshot,
    build_flow_evidence_quality,
    build_flow_evidence_capture_readiness,
    build_closed_session_calibration_trend,
    apply_flow_evidence_guard,
    build_flow_evidence_queue,
    build_flow_evidence_snapshot,
)
from engine.operations_flow_calibration_promotion import (
    FLOW_CALIBRATION_PROMOTION_SNAPSHOT_COLS,
    flow_calibration_promotion_snapshot_integrity,
    latest_flow_calibration_promotion_snapshot,
    build_flow_calibration_promotion,
    apply_flow_calibration_promotion_guard,
    build_flow_calibration_promotion_queue,
    build_flow_calibration_promotion_snapshot,
)
from engine.operations_flow_calibration import (
    FLOW_CALIBRATION_SNAPSHOT_COLS,
    flow_calibration_snapshot_integrity,
    latest_flow_calibration_snapshot,
    build_flow_calibration,
    build_flow_calibration_queue,
    build_flow_calibration_snapshot,
)
from engine.operations_flow_projection_admission import (
    FLOW_PROJECTION_ADMISSION_SNAPSHOT_COLS,
    flow_projection_admission_snapshot_integrity,
    latest_flow_projection_admission_snapshot,
    build_flow_projection_admission,
    build_flow_projection_admission_queue,
    build_flow_projection_admission_snapshot,
)
from engine.operations_flow_projection import (
    FLOW_PROJECTION_SNAPSHOT_COLS,
    flow_projection_snapshot_integrity,
    latest_flow_projection_snapshot,
    build_flow_projection,
    build_flow_projection_queue,
    build_flow_projection_snapshot,
)
from engine.operations_flow_projection_review import (
    FLOW_PROJECTION_REVIEW_SNAPSHOT_COLS,
    flow_projection_review_snapshot_integrity,
    latest_flow_projection_review_snapshot,
    build_flow_projection_review_context,
    latest_reviewed_projection_source,
    build_flow_projection_review_queue,
    build_flow_projection_review_lock,
)
from engine.operations_flow_projection_outcome_evidence import (
    FLOW_PROJECTION_OUTCOME_EVIDENCE_SNAPSHOT_COLS,
    flow_projection_outcome_evidence_snapshot_integrity,
    latest_flow_projection_outcome_evidence_snapshot,
    build_guarded_flow_projection_outcome,
    build_flow_projection_outcome_evidence_queue,
    build_flow_projection_outcome_evidence_snapshot,
)
from engine.operations_flow_projection_outcome import (
    FLOW_PROJECTION_OUTCOME_SNAPSHOT_COLS,
    flow_projection_outcome_snapshot_integrity,
    latest_flow_projection_outcome_snapshot,
    latest_ready_flow_projection_snapshot,
    build_flow_projection_outcome,
    build_flow_projection_outcome_queue,
    build_flow_projection_outcome_snapshot,
)
from engine.operations_flow_scorecard_input import (
    FLOW_SCORECARD_INPUT_SNAPSHOT_COLS,
    flow_scorecard_input_snapshot_integrity,
    latest_flow_scorecard_input_snapshot,
    build_flow_scorecard_input_qualification,
    build_flow_scorecard_input_queue,
    build_flow_scorecard_input_snapshot,
)
from engine.operations_flow_permanent_change_runtime import (
    FLOW_PERMANENT_CHANGE_RUNTIME_EVENT_COLS,
    PERMANENT_CHANGE_KILL_TRIGGERS,
    permanent_change_runtime_event_integrity,
    latest_permanent_change_runtime_event,
    build_flow_permanent_change_runtime,
    build_flow_permanent_change_runtime_event,
    build_flow_permanent_change_runtime_queue,
)
from engine.operations_flow_permanent_change_apply import (
    FLOW_PERMANENT_CHANGE_APPLY_SNAPSHOT_COLS,
    permanent_change_apply_snapshot_integrity,
    latest_permanent_change_apply_snapshot,
    build_flow_permanent_change_apply,
    build_flow_permanent_change_apply_lock,
    build_flow_permanent_change_apply_queue,
)
from engine.operations_flow_permanent_change_design import (
    FLOW_PERMANENT_CHANGE_DESIGN_SNAPSHOT_COLS,
    permanent_change_design_snapshot_integrity,
    latest_permanent_change_design_snapshot,
    build_flow_permanent_change_design,
    build_flow_permanent_change_design_lock,
    build_flow_permanent_change_design_queue,
)
from engine.operations_flow_live_change_outcome_closure import (
    FLOW_LIVE_CHANGE_OUTCOME_CLOSURE_SNAPSHOT_COLS,
    live_change_outcome_closure_snapshot_integrity,
    latest_live_change_outcome_closure_snapshot,
    build_flow_live_change_outcome_closure,
    build_flow_live_change_outcome_closure_lock,
    build_flow_live_change_outcome_closure_queue,
)
from engine.operations_flow_live_change_outcome import (
    FLOW_LIVE_CHANGE_OUTCOME_SNAPSHOT_COLS,
    live_change_outcome_snapshot_integrity,
    latest_live_change_outcome_snapshot,
    build_flow_live_change_outcome,
    build_flow_live_change_outcome_snapshot,
    build_flow_live_change_outcome_queue,
)
from engine.operations_flow_live_change_runtime import (
    FLOW_LIVE_CHANGE_RUNTIME_SNAPSHOT_COLS,
    LIVE_CHANGE_RUNTIME_KILL_TRIGGERS,
    live_change_runtime_snapshot_integrity,
    latest_live_change_runtime_snapshot,
    build_flow_live_change_runtime,
    build_flow_live_change_runtime_activate,
    build_flow_live_change_runtime_close,
    build_flow_live_change_runtime_kill_switch,
    build_flow_live_change_runtime_queue,
)
from engine.operations_flow_live_change_apply import (
    FLOW_LIVE_CHANGE_APPLY_SNAPSHOT_COLS,
    live_change_apply_snapshot_integrity,
    latest_live_change_apply_snapshot,
    build_flow_live_change_apply,
    build_flow_live_change_apply_lock,
    build_flow_live_change_apply_queue,
)
from engine.operations_flow_live_change_design import (
    FLOW_LIVE_CHANGE_DESIGN_SNAPSHOT_COLS,
    live_change_design_snapshot_integrity,
    latest_live_change_design_snapshot,
    build_flow_live_change_design,
    build_flow_live_change_design_lock,
    build_flow_live_change_design_queue,
)
from engine.operations_flow_controlled_trial_closure import (
    FLOW_CONTROLLED_TRIAL_CLOSURE_SNAPSHOT_COLS,
    controlled_trial_closure_snapshot_integrity,
    latest_controlled_trial_closure_snapshot,
    build_flow_controlled_trial_closure,
    build_flow_controlled_trial_closure_lock,
    build_flow_controlled_trial_closure_queue,
)
from engine.operations_flow_controlled_trial_outcome import (
    FLOW_CONTROLLED_TRIAL_OUTCOME_SNAPSHOT_COLS,
    controlled_trial_outcome_snapshot_integrity,
    latest_controlled_trial_outcome_snapshot,
    build_flow_controlled_trial_outcome,
    build_flow_controlled_trial_outcome_snapshot,
    build_flow_controlled_trial_outcome_queue,
)
from engine.operations_flow_controlled_trial_runtime import (
    FLOW_CONTROLLED_TRIAL_RUNTIME_SNAPSHOT_COLS,
    KILL_SWITCH_TRIGGERS,
    controlled_trial_runtime_snapshot_integrity,
    latest_controlled_trial_runtime_snapshot,
    build_flow_controlled_trial_runtime,
    build_flow_controlled_trial_runtime_open,
    build_flow_controlled_trial_runtime_close,
    build_flow_controlled_trial_runtime_kill_switch,
    build_flow_controlled_trial_runtime_queue,
)
from engine.operations_flow_controlled_trial_start import (
    FLOW_CONTROLLED_TRIAL_START_SNAPSHOT_COLS,
    controlled_trial_start_snapshot_integrity,
    latest_controlled_trial_start_snapshot,
    build_flow_controlled_trial_start,
    build_flow_controlled_trial_start_lock,
    build_flow_controlled_trial_start_queue,
)
from engine.operations_flow_controlled_trial_design import (
    FLOW_CONTROLLED_TRIAL_DESIGN_SNAPSHOT_COLS,
    controlled_trial_design_snapshot_integrity,
    latest_controlled_trial_design_snapshot,
    build_flow_controlled_trial_design,
    build_flow_controlled_trial_design_lock,
    build_flow_controlled_trial_design_queue,
)
from engine.operations_flow_shadow_adoption_review import (
    FLOW_SHADOW_ADOPTION_REVIEW_SNAPSHOT_COLS,
    shadow_adoption_review_snapshot_integrity,
    latest_shadow_adoption_review_snapshot,
    build_flow_shadow_adoption_review,
    build_flow_shadow_adoption_review_lock,
    build_flow_shadow_adoption_queue,
)
from engine.operations_flow_shadow_validation_outcome import (
    FLOW_SHADOW_VALIDATION_OUTCOME_SNAPSHOT_COLS,
    shadow_validation_outcome_snapshot_integrity,
    latest_shadow_validation_outcome_snapshot,
    build_flow_shadow_validation_outcome,
    build_flow_shadow_validation_outcome_snapshot,
    build_flow_shadow_validation_outcome_queue,
)
from engine.operations_flow_shadow_validation_plan import (
    FLOW_SHADOW_VALIDATION_PLAN_SNAPSHOT_COLS,
    shadow_validation_plan_snapshot_integrity,
    latest_shadow_validation_plan_snapshot,
    build_flow_shadow_validation_plan,
    build_flow_shadow_validation_plan_lock,
    build_flow_shadow_validation_plan_queue,
)
from engine.operations_flow_recalibration_proposal import (
    FLOW_RECALIBRATION_PROPOSAL_SNAPSHOT_COLS,
    recalibration_proposal_snapshot_integrity,
    latest_recalibration_proposal_snapshot,
    build_flow_recalibration_proposal,
    build_flow_recalibration_proposal_lock,
    build_flow_recalibration_proposal_queue,
)
from engine.operations_flow_recalibration_review import (
    FLOW_RECALIBRATION_REVIEW_SNAPSHOT_COLS,
    recalibration_review_snapshot_integrity,
    latest_recalibration_review_snapshot,
    build_flow_recalibration_review,
    build_flow_recalibration_review_queue,
    build_flow_recalibration_review_lock,
)
from engine.operations_flow_projection_scorecard import (
    FLOW_PROJECTION_SCORECARD_SNAPSHOT_COLS,
    flow_projection_scorecard_snapshot_integrity,
    latest_flow_projection_scorecard_snapshot,
    build_flow_projection_scorecard,
    build_flow_projection_scorecard_queue,
    build_flow_projection_scorecard_snapshot,
)
from engine.release_readiness_v130 import (
    build_v130_evidence_context,
    build_v130_evidence_technical_release_gate,
    build_v130_evidence_lineage_gate,
    build_v130_release_readiness,
    build_v130_integration_crosscheck,
    build_v130_data_crosscheck,
)
from engine.release_readiness_v129 import (
    build_v129_projection_context,
    build_v129_projection_technical_release_gate,
    build_v129_projection_lineage_gate,
    build_v129_release_readiness,
    build_v129_integration_crosscheck,
    build_v129_data_crosscheck,
)
from engine.release_readiness_v156 import (
    build_v156_recovery_context,
    build_v156_recovery_technical_gate,
    build_v156_recovery_audit_gate,
    verify_v1551_release_baseline_provenance,
    build_v156_release_readiness,
)
from engine.release_readiness_v155 import (
    build_v155_trusted_release_operations_context,
    build_v155_trusted_release_operations_technical_gate,
    build_v155_trusted_release_operations_audit_gate,
    verify_v1541_release_baseline_provenance,
    build_v155_release_readiness,
)
from engine.release_readiness_v154 import (
    build_v154_updater2_context,
    build_v154_updater2_technical_release_gate,
    build_v154_updater2_audit_gate,
    verify_v153_release_baseline_provenance,
    build_v154_release_readiness,
    build_v154_integration_crosscheck,
    build_v154_data_crosscheck,
)
from engine.release_readiness_v153 import (
    build_v153_permanent_change_runtime_context,
    build_v153_permanent_change_runtime_technical_release_gate,
    build_v153_permanent_change_runtime_audit_gate,
    verify_v152_release_baseline_provenance,
    build_v153_release_readiness,
    build_v153_integration_crosscheck,
    build_v153_data_crosscheck,
)
from engine.release_readiness_v152 import (
    build_v152_permanent_change_apply_context,
    build_v152_permanent_change_apply_technical_release_gate,
    build_v152_permanent_change_apply_audit_gate,
    verify_v151_release_baseline_provenance,
    build_v152_release_readiness,
    build_v152_integration_crosscheck,
    build_v152_data_crosscheck,
)
from engine.release_readiness_v151 import (
    build_v151_permanent_change_design_context,
    build_v151_permanent_change_design_technical_release_gate,
    build_v151_permanent_change_design_audit_gate,
    verify_v150_release_baseline_provenance,
    build_v151_release_readiness,
    build_v151_integration_crosscheck,
    build_v151_data_crosscheck,
)
from engine.release_readiness_v150 import (
    build_v150_live_change_closure_context,
    build_v150_live_change_closure_technical_release_gate,
    build_v150_live_change_closure_audit_gate,
    build_v150_work_ready_context,
    build_v150_work_ready_release_gate,
    verify_v149_release_baseline_provenance,
    build_v150_release_readiness,
    build_v150_integration_crosscheck,
    build_v150_data_crosscheck,
)
from engine.release_readiness_v149 import (
    build_v149_live_change_outcome_context,
    build_v149_live_change_outcome_technical_release_gate,
    build_v149_live_change_outcome_audit_gate,
    build_v149_release_readiness,
    build_v149_integration_crosscheck,
    build_v149_data_crosscheck,
)
from engine.release_readiness_v148 import (
    build_v148_live_change_runtime_context,
    build_v148_live_change_runtime_technical_release_gate,
    build_v148_live_change_runtime_audit_gate,
    build_v148_release_readiness,
    build_v148_integration_crosscheck,
    build_v148_data_crosscheck,
)
from engine.release_readiness_v147 import (
    build_v147_live_change_apply_context,
    build_v147_live_change_apply_technical_release_gate,
    build_v147_live_change_apply_audit_gate,
    build_v147_release_readiness,
    build_v147_integration_crosscheck,
    build_v147_data_crosscheck,
)
from engine.release_readiness_v146 import (
    build_v146_live_change_design_context,
    build_v146_live_change_design_technical_release_gate,
    build_v146_live_change_design_audit_gate,
    build_v146_release_readiness,
    build_v146_integration_crosscheck,
    build_v146_data_crosscheck,
)
from engine.release_readiness_v145 import (
    build_v145_trial_closure_context,
    build_v145_trial_closure_technical_release_gate,
    build_v145_trial_closure_audit_gate,
    build_v145_release_readiness,
    build_v145_integration_crosscheck,
    build_v145_data_crosscheck,
)
from engine.release_readiness_v144 import (
    build_v144_trial_outcome_context,
    build_v144_trial_outcome_technical_release_gate,
    build_v144_trial_outcome_audit_gate,
    build_v144_release_readiness,
    build_v144_integration_crosscheck,
    build_v144_data_crosscheck,
)
from engine.release_readiness_v143 import (
    build_v143_trial_runtime_context,
    build_v143_trial_runtime_technical_release_gate,
    build_v143_trial_runtime_audit_gate,
    build_v143_release_readiness,
    build_v143_integration_crosscheck,
    build_v143_data_crosscheck,
)
from engine.release_readiness_v142 import (
    build_v142_trial_start_context,
    build_v142_trial_start_technical_release_gate,
    build_v142_trial_start_audit_gate,
    build_v142_release_readiness,
    build_v142_integration_crosscheck,
    build_v142_data_crosscheck,
)
from engine.release_readiness_v141 import (
    build_v141_trial_design_context,
    build_v141_trial_design_technical_release_gate,
    build_v141_trial_design_audit_gate,
    build_v141_release_readiness,
    build_v141_integration_crosscheck,
    build_v141_data_crosscheck,
)
from engine.release_readiness_v140 import (
    build_v140_adoption_context,
    build_v140_adoption_technical_release_gate,
    build_v140_adoption_audit_gate,
    build_v140_release_readiness,
    build_v140_integration_crosscheck,
    build_v140_data_crosscheck,
)
from engine.release_readiness_v139 import (
    build_v139_shadow_evaluation_context,
    build_v139_shadow_evaluation_technical_release_gate,
    build_v139_shadow_evaluation_audit_gate,
    build_v139_release_readiness,
    build_v139_integration_crosscheck,
    build_v139_data_crosscheck,
)
from engine.release_readiness_v138 import (
    build_v138_shadow_validation_context,
    build_v138_shadow_validation_technical_release_gate,
    build_v138_shadow_validation_audit_gate,
    build_v138_release_readiness,
    build_v138_integration_crosscheck,
    build_v138_data_crosscheck,
)
from engine.release_readiness_v137 import (
    build_v137_proposal_context,
    build_v137_proposal_technical_release_gate,
    build_v137_proposal_audit_gate,
    build_v137_release_readiness,
    build_v137_integration_crosscheck,
    build_v137_data_crosscheck,
)
from engine.release_readiness_v136 import (
    build_v136_recalibration_context,
    build_v136_recalibration_technical_release_gate,
    build_v136_recalibration_audit_gate,
    build_v136_release_readiness,
    build_v136_integration_crosscheck,
    build_v136_data_crosscheck,
)
from engine.release_readiness_v135 import (
    build_v135_scorecard_input_context,
    build_v135_scorecard_input_technical_release_gate,
    build_v135_scorecard_input_audit_gate,
    build_v135_release_readiness,
    build_v135_integration_crosscheck,
    build_v135_data_crosscheck,
)
from engine.release_readiness_v134 import (
    build_v134_outcome_evidence_context,
    build_v134_outcome_evidence_technical_release_gate,
    build_v134_outcome_evidence_audit_gate,
    build_v134_release_readiness,
    build_v134_integration_crosscheck,
    build_v134_data_crosscheck,
)
from engine.release_readiness_v133 import (
    build_v133_review_context,
    build_v133_review_technical_release_gate,
    build_v133_review_audit_gate,
    build_v133_release_readiness,
    build_v133_integration_crosscheck,
    build_v133_data_crosscheck,
)
from engine.release_readiness_v132 import (
    build_v132_admission_context,
    build_v132_admission_technical_release_gate,
    build_v132_admission_audit_gate,
    build_v132_release_readiness,
    build_v132_integration_crosscheck,
    build_v132_data_crosscheck,
)
from engine.release_readiness_v131 import (
    build_v131_promotion_context,
    build_v131_promotion_technical_release_gate,
    build_v131_promotion_audit_gate,
    build_v131_release_readiness,
    build_v131_integration_crosscheck,
    build_v131_data_crosscheck,
)
from engine.release_readiness_v128 import (
    build_v128_flow_context,
    build_v128_flow_release_gate,
    build_v128_release_readiness,
    build_v128_integration_crosscheck,
    build_v128_data_crosscheck,
)
from engine.posttrade import POST_TRADE_AUDIT_COLS, build_post_trade_audit
from engine.monitoring import (
    KPI_COLS, normalize_kpis, evaluate_kpis, seed_generic_kpis,
    update_from_latest_dart, build_review_queue, actionable_kpi_view
)
from engine.review_queue import (
    build_master_review_queue, review_queue_summary
)
from engine.monitoring_automation import (
    MONITORING_RUN_COLS,
    daily_review_plan,
    monitoring_coverage,
    monitoring_summary,
    build_monitoring_run_row,
)
from engine.thesis_monitor import (
    THESIS_PLAN_COLS, normalize_thesis_plans, upsert_thesis_plan,
    build_thesis_monitor, selected_company_details
)
from engine.universe import (
    UNIVERSE_COLS, CANDIDATE_COLS, ensure_universe_cols, ensure_candidate_cols,
    filter_universe, add_candidates, candidate_to_watchlist_rows, append_watchlist
)
from engine.quant_screener import (
    REPORT_LABELS, default_quant_period,
    normalize_fast_cache, pending_fast_scope, scan_fast_batch, upsert_fast_cache,
    filter_fast_results, pending_detail_from_fast,
    normalize_quant_cache, build_corp_map, filter_quant_results,
    scan_one, error_record, upsert_quant_cache
)
from engine.quality_ranker import (
    DEFAULT_QUALITY_WEIGHTS, rank_quality_candidates, shortlist_view
)
from engine.etf import ETF_HOLDING_COLS, normalize_holdings, portfolio_lookthrough, exposure_summary, underlying_concentration, pairwise_etf_overlap
from engine.stress import returns_correlation, correlated_bear_loss, apply_factor_shocks
from engine.marginal_risk import (
    MARGINAL_RISK_REVIEW_COLS,
    portfolio_stress_snapshot,
    stress_risk_contributions,
    marginal_add_review,
    marginal_risk_review_row,
)

# ------------------------------------------------------------------
# pandas / NumPy compatibility for legacy marginal_risk engine
# ------------------------------------------------------------------
# engine/marginal_risk.py uses np.fill_diagonal(cm.values, 1.0).
# In newer pandas, DataFrame.values can be a read-only NumPy view even when
# Copy-on-Write is disabled. Instead of changing NumPy globally, replace only
# engine.marginal_risk's local `np` reference with a proxy that temporarily
# makes the received view writable before delegating to NumPy.
import engine.marginal_risk as _marginal_risk_module

class _WritableDiagonalNumpyProxy:
    _stockos_writable_diagonal_proxy = True

    def __init__(self, base_np):
        self._base_np = base_np

    def __getattr__(self, name):
        return getattr(self._base_np, name)

    def fill_diagonal(self, a, val, wrap=False):
        try:
            writeable = bool(a.flags.writeable)
        except Exception:
            writeable = True

        if not writeable:
            try:
                a.setflags(write=True)
            except Exception as exc:
                raise ValueError(
                    "StockOS could not make marginal-risk correlation array writable"
                ) from exc

        return self._base_np.fill_diagonal(
            a,
            val,
            wrap=wrap,
        )

if not getattr(
    getattr(_marginal_risk_module, "np", None),
    "_stockos_writable_diagonal_proxy",
    False,
):
    _marginal_risk_module.np = _WritableDiagonalNumpyProxy(
        np
    )
from engine.portfolio_risk_v2 import (
    RISK_OVERLAY_COLS,
    normalize_risk_overlays,
    overlay_editor_rows,
    portfolio_risk_budget_snapshot,
    risk_overlay_status_table,
    risk_overlay_summary,
    direct_currency_exposure,
    top_risk_contributors,
    overlay_save_rows,
    stress_reliability_status,
    risk_concentration_status,
    currency_lookthrough_diagnostics,
    factor_policy_view,
    overlay_decision_readiness,
    portfolio_risk_decision_gate,
    ECONOMIC_FX_OVERLAY_COLS,
    normalize_economic_fx_overlays,
    economic_fx_editor_rows,
    economic_fx_status_table,
    economic_fx_summary,
    economic_fx_overlay_save_rows,
    BUSINESS_FX_OVERLAY_COLS,
    normalize_business_fx_overlays,
    business_fx_editor_rows,
    business_fx_status_table,
    business_fx_summary,
    business_fx_overlay_save_rows,
    BUSINESS_FX_EVIDENCE_COLS,
    normalize_business_fx_evidence,
    business_fx_evidence_editor_rows,
    business_fx_evidence_status_table,
    business_fx_evidence_summary,
    business_fx_evidence_save_rows,
    apply_business_fx_evidence_to_overlay,
    upsert_business_fx_evidence,
    business_fx_evidence_history_table,
    business_fx_multiperiod_summary,
    apply_business_fx_long_run_candidate,
    LIQUIDITY_OVERLAY_COLS,
    normalize_liquidity_overlays,
    liquidity_overlay_editor_rows,
    liquidity_status_table,
    liquidity_overlay_summary,
    liquidity_overlay_save_rows,
    HISTORICAL_CORRELATION_COLS,
    normalize_historical_correlation_records,
    historical_correlation_records_from_matrix,
    historical_correlation_matrix_from_records,
    historical_correlation_source_health,
    LIQUIDITY_SOURCE_ASSIST_COLS,
    normalize_liquidity_source_assist,
    liquidity_source_assist_from_history,
    liquidity_source_assist_summary,
    apply_liquidity_assist_to_overlay,
)
from engine.car_concentration_repair import (
    CAR_REPAIR_REVIEW_COLS,
    direct_car_contributions,
    car_concentration_state,
    minimum_car_concentration_repair,
    simulate_car_concentration_repair,
    car_repair_review_row,
    benchmark_fraction_ladder,
    whole_quantity_trim_ladder,
)

from engine.orders import generate_trade_plan
from connectors.etf import yfinance_top_holdings
from connectors.market import latest_price, price_history, latest_fx, multi_price_matrix
from connectors.universe import fetch_market_universe
from connectors.dart import (
    download_corp_codes, find_corp_code, full_financials,
    latest_available_financials, summarize_financials,
    recent_disclosures_for_watchlist,
    stock_total_status, summarize_share_count
)

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"
ENV_PATH = resolve_env_path(ROOT, ENV_PATH)
load_dotenv(ENV_PATH)
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip() if (ROOT/"VERSION").exists() else "0.2"

_RELEASE_RESTART_ACK = release_manager_acknowledge_running_version(
    ROOT,
    VERSION,
)

# Opt-in Trusted Release Feed auto-sync. This writes only to work/control,
# performs no approval/apply, and never accesses runtime-data/secrets.
_TRUSTED_RELEASE_FEED_AUTO_SYNC = {"status": "DEFERRED"}

st.set_page_config(page_title=f"Stock Investment OS {VERSION}", page_icon="📈", layout="wide")

WATCH_COLS = [
    "code","name","ticker","market","factor","sector","price","normalized_fcf_yield","roic","iroic",
    "refinancing_gate","bear_downside","required_return","terminal_growth",
    "fcf_confidence","evidence_quality","share_count_cagr",
    "strong_add_ceiling","core_ceiling","initial_ceiling","no_chase_ceiling",
    "thesis_status","evidence_status","assumption_status","assumption_reviewed_at",
    "price_timestamp","price_source","status"
]
PORT_COLS = [
    "name","ticker","market","asset_type","currency","quantity","manual_price",
    "current_value_krw","bear_downside","factor","sector","country","price_timestamp","price_source","note"
]
PROOF_COLS = [
    "company","proof_item","due_date","status","invalidation_signal",
    "source_url","last_checked","note"
]

def krw(v):
    try: return f"{float(v):,.0f}원"
    except Exception: return "-"

def pct(v):
    try: return f"{float(v)*100:,.1f}%"
    except Exception: return "-"

def ensure_cols(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        if c not in out.columns:
            out[c] = ""
    return out[cols + [c for c in out.columns if c not in cols]]

def get_portfolio():
    return ensure_cols(load_csv("portfolio.csv"), PORT_COLS)

def get_watchlist():
    return ensure_cols(load_csv("watchlist.csv"), WATCH_COLS)

def get_proof():
    return ensure_cols(load_csv("proof_clock.csv"), PROOF_COLS)

def get_audit_evidence_registry() -> pd.DataFrame:
    """
    Unified evidence-source view used only by Data Quality / execution audit gates.

    Compatibility:
    - Keeps legacy data/evidence.csv valid.
    - Also recognizes APPROVED Evidence Intake packets when the packet hash is OK
      and source_url is present.

    Governance:
    - This does NOT mutate watchlist.evidence_status.
    - APPROVED Evidence Packet provenance can satisfy the source-URL requirement,
      while PASS/STRONG evidence_status remains an explicit human decision.
    """
    legacy = load_csv("evidence.csv").copy()
    packet_rows = pd.DataFrame()

    try:
        packets = normalize_evidence_packets(
            load_csv("evidence_packets.csv")
        )
        if not packets.empty:
            enriched = enrich_evidence_packets(packets)

            status = (
                enriched.get(
                    "review_status",
                    pd.Series("", index=enriched.index, dtype="object"),
                )
                .fillna("")
                .astype(str)
                .str.upper()
            )
            hash_status = (
                enriched.get(
                    "hash_status",
                    pd.Series("", index=enriched.index, dtype="object"),
                )
                .fillna("")
                .astype(str)
                .str.upper()
            )
            source_url = (
                enriched.get(
                    "source_url",
                    pd.Series("", index=enriched.index, dtype="object"),
                )
                .fillna("")
                .astype(str)
                .str.strip()
            )
            company = (
                enriched.get(
                    "company",
                    pd.Series("", index=enriched.index, dtype="object"),
                )
                .fillna("")
                .astype(str)
                .str.strip()
            )

            approved = enriched.loc[
                status.eq("APPROVED")
                & hash_status.eq("OK")
                & source_url.ne("")
                & company.ne("")
            ].copy()

            if not approved.empty:
                packet_rows = pd.DataFrame({
                    "company": approved["company"].fillna("").astype(str),
                    "source_url": approved["source_url"].fillna("").astype(str),
                    "audit_evidence_source": "APPROVED_EVIDENCE_PACKET",
                })
                if "evidence_id" in approved.columns:
                    packet_rows["evidence_id"] = (
                        approved["evidence_id"].fillna("").astype(str)
                    )
                if "source_title" in approved.columns:
                    packet_rows["source_title"] = (
                        approved["source_title"].fillna("").astype(str)
                    )
                if "event_date" in approved.columns:
                    packet_rows["event_date"] = (
                        approved["event_date"].fillna("").astype(str)
                    )
    except Exception:
        # Evidence Packet parsing problems must not destroy legacy audit flow.
        # Stability/Evidence screens remain responsible for surfacing packet errors.
        packet_rows = pd.DataFrame()

    frames = []

    if not legacy.empty:
        legacy = legacy.copy()
        if "company" not in legacy.columns:
            legacy["company"] = ""
        if "source_url" not in legacy.columns:
            legacy["source_url"] = ""
        legacy["audit_evidence_source"] = "LEGACY_EVIDENCE_REGISTER"
        frames.append(legacy)

    if not packet_rows.empty:
        frames.append(packet_rows)

    if not frames:
        return pd.DataFrame(
            columns=[
                "company",
                "source_url",
                "audit_evidence_source",
            ]
        )

    return pd.concat(
        frames,
        ignore_index=True,
        sort=False,
    )

def excel_bytes(sheets):
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        for name, df in sheets.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)
    return bio.getvalue()

def verified_save_feedback(
    df: pd.DataFrame,
    filename: str,
    message: str = "저장했습니다.",
    *,
    backup: bool = True,
    rerun: bool = True,
):
    """One-click save wrapper with persistent success feedback."""
    try:
        save_csv(df, filename, backup=backup)
        st.session_state["_save_flash"] = (
            "success",
            f"{message} · 저장 검증 PASS · {datetime.now().strftime('%H:%M:%S')}"
        )
        if rerun:
            st.rerun()
        return True
    except Exception as e:
        st.error(f"저장 실패: {e}")
        return False

def _navigate(page_name: str, state_updates: dict | None = None):
    """Streamlit callback: update target page/state before the next rerun."""
    if state_updates:
        for key, value in state_updates.items():
            st.session_state[key] = value
    st.session_state["main_menu"] = page_name


def _source_candidate_handoff_callback(
    selected_candidate: dict,
    source_candidates: pd.DataFrame,
):
    """Promote a Source Candidate and navigate safely via widget callback."""
    try:
        candidate_id = str(
            selected_candidate.get("candidate_id","") or ""
        ).strip()
        updated_candidates = mark_candidate_status(
            source_candidates,
            candidate_id,
            "IN REVIEW",
        )
        save_csv(
            updated_candidates,
            "source_candidates.csv",
        )

        handoff = candidate_handoff(
            selected_candidate
        )
        company = handoff["company"]

        st.session_state["evidence_candidate_id"] = handoff[
            "candidate_id"
        ]
        st.session_state[
            "evidence_candidate_receipt_no"
        ] = handoff["receipt_no"]
        st.session_state[
            "evidence_intake_company"
        ] = company
        st.session_state[
            "evidence_intake_company_select"
        ] = company
        st.session_state[
            f"evidence_source_type::{company}"
        ] = handoff["source_type"]

        if handoff["event_date"] is not None:
            st.session_state[
                f"evidence_event_date::{company}"
            ] = handoff["event_date"]

        st.session_state[
            f"evidence_source_title::{company}"
        ] = handoff["source_title"]
        st.session_state[
            f"evidence_source_url::{company}"
        ] = handoff["source_url"]
        st.session_state[
            f"evidence_signal::{company}"
        ] = "NEUTRAL"
        st.session_state[
            f"evidence_confidence::{company}"
        ] = "MEDIUM"

        st.session_state["_evidence_handoff"] = {
            "candidate_id": handoff["candidate_id"],
            "receipt_no": handoff["receipt_no"],
            "company": company,
            "source_type": handoff["source_type"],
            "event_date": (
                handoff["event_date"].isoformat()
                if handoff["event_date"] is not None
                else ""
            ),
            "source_title": handoff["source_title"],
            "source_url": handoff["source_url"],
        }
        st.session_state["_evidence_draft_context"] = {
            "candidate_id": handoff["candidate_id"],
            "company": company,
            **candidate_review_guide(selected_candidate),
        }

        st.session_state["_save_flash"] = (
            "success",
            "Source Candidate를 IN REVIEW로 저장하고 Evidence Intake로 전달했습니다."
        )
        st.session_state["main_menu"] = "Evidence Intake"
    except Exception as e:
        st.session_state["_save_flash"] = (
            "warning",
            f"Evidence Intake handoff 실패: {e}",
        )


settings = load_settings()
portfolio = get_portfolio()
watchlist = get_watchlist()
proof = get_proof()
audit_evidence = get_audit_evidence_registry()
factor_loadings = normalize_factor_loadings(load_csv("factor_loadings.csv"))

total_assets = float(settings.get("portfolio_assets_krw",0) or 0)
loss_budget = float(settings.get("loss_budget_per_position",0.01))
single_cap = float(settings.get("single_name_cap",0.05))

st.sidebar.title("Stock Investment OS")
st.sidebar.caption(VERSION if VERSION.lower().startswith("v") else f"v{VERSION}")
_MENU_LABELS_KO = {'Start Here': '처음 시작', 'Operations Control Tower': '운영 종합 관리', 'Decision Summary': '투자 판단 요약', 'Action Planner': '실행 계획', 'Stability Audit': '안정성 점검', 'System Integration': '시스템 통합 점검', 'Save Center': '저장 관리', 'Factor Exposure': '투자 요인별 노출', 'Factor Risk Repair': '투자 요인 위험 조정', 'Portfolio Risk Repair': '포트폴리오 위험 조정', 'Dashboard': '종합 현황', 'Daily Briefing': '일일 브리핑', 'Monitoring Center': '모니터링 센터', 'Review Queue': '검토 대기 목록', 'Thesis Monitor': '투자 근거 점검', 'KPI Monitor': '핵심 지표 점검', 'Alerts': '알림', 'Data Quality': '데이터 품질', 'Reconciliation': '보유 내역 대조', 'Migration Manager': '이전 관리', 'Release Manager': '프로그램 업데이트 설치', 'Auto Update': '주가·평가액 갱신', 'Market Universe': '시장 종목 목록', 'Quant Screener': '정량 종목 검색', 'Portfolio': '포트폴리오', 'ETF Look-through': 'ETF 구성 분석', 'Screening': '종목 선별', 'Investment State': '투자 상태', 'Fundamental Engine': '기업 기초 분석', 'Reverse DCF': '현재 가격의 성장 가정 분석', 'Scenario Refresh': '시나리오 갱신', 'Scenario Reconciliation': '시나리오 일치 점검', 'Position Sizing': '투자 규모 산정', 'Portfolio Fit': '포트폴리오 적합성', 'Portfolio Risk 2.0': '포트폴리오 위험 분석 2.0', 'CAR Concentration Repair': '자본 집중 위험 조정', 'Capital Migration': '자본 이동 계획', 'Capital Productivity': '자본 효율', 'Stress Lab': '위기 상황 분석', 'Marginal Risk': '추가 투자 위험', 'Trade Planner': '매매 계획', 'Rebalance Planner': '비중 조정 계획', 'Scenario Compare': '시나리오 비교', 'Execution Checklist': '실행 전 체크리스트', 'Fill Reconciliation': '체결 내역 대조', 'Post-Trade Audit': '매매 후 점검', 'Proof Clock': '근거 유효기간', 'Decision Journal': '투자 판단 기록', 'Override Registry': '예외 판단 기록', 'Snapshot History': '저장 시점 기록', 'Reports & Scheduler': '보고서·일정 관리', 'Primary Source Monitor': '공식 원문 점검', 'Evidence Batch Review': '근거 일괄 검토', 'Evidence Intake': '근거 등록', 'Evidence Impact Review': '근거 영향 검토', 'Evidence': '근거 자료', 'OpenDART Auto': '전자공시 자동 수집', 'Market Data': '시장 데이터', 'Settings': '설정'}
_MENU_LABELS_KO["KIS Execution"] = "한국투자증권 주문·운영"
_MENU_LABELS_KO["Decision Workbench v2"] = "투자·포트폴리오 검토 v2"
page = st.sidebar.radio("메뉴", [
    "Start Here","Operations Control Tower","Decision Summary","Action Planner","Stability Audit","System Integration","Save Center","Factor Exposure","Factor Risk Repair","Portfolio Risk Repair","Dashboard","Daily Briefing","Monitoring Center","Review Queue","Thesis Monitor","KPI Monitor","Alerts","Data Quality","Reconciliation",
    "Migration Manager","Release Manager","Auto Update","Market Universe","Quant Screener","Portfolio","ETF Look-through","Screening","Investment State","Fundamental Engine",
    "Decision Workbench v2","KIS Execution","Reverse DCF","Scenario Refresh","Scenario Reconciliation","Position Sizing","Portfolio Fit","Portfolio Risk 2.0","CAR Concentration Repair","Capital Migration","Capital Productivity","Stress Lab","Marginal Risk","Trade Planner",
    "Rebalance Planner","Scenario Compare","Execution Checklist","Fill Reconciliation","Post-Trade Audit","Proof Clock","Decision Journal","Override Registry",
    "Snapshot History","Reports & Scheduler","Primary Source Monitor","Evidence Batch Review","Evidence Intake","Evidence Impact Review","Evidence","OpenDART Auto","Market Data","Settings"
], key="main_menu", format_func=lambda menu_key: _MENU_LABELS_KO.get(menu_key, menu_key))
st.sidebar.caption("증권사 주문은 별도 확인 후 전송 · 자동 주문 없음")

_flash = st.session_state.pop("_save_flash", None)
if _flash:
    _kind, _message = _flash
    if _kind == "success":
        st.success(_message)
    elif _kind == "warning":
        st.warning(_message)
    else:
        st.info(_message)


if page != "Release Manager":
    with st.spinner("Trusted Feed 동기화 확인 중"):
        _TRUSTED_RELEASE_FEED_AUTO_SYNC = maybe_auto_sync_trusted_release(ROOT)

# Exclusive page dispatch keeps Streamlit preprocessing shallow.
if page == "KIS Execution":
    from broker_workbench import render as render_broker_workbench
    render_broker_workbench(ROOT)
else:
    from page_loader import render_page
    render_page(page, globals())
