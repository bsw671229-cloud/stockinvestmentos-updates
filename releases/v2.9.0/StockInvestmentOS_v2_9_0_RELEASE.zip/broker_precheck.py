"""Explicit order precheck UI without an order journal or send controls."""
import streamlit as st
from datetime import datetime, timezone

from broker_inquiries import format_time
from broker_amount_preview import calculate_amounts, money_text
from connectors.kis_broker import BrokerError
from broker_precheck_service import run_precheck
from broker_session_status import render as render_session_status
from broker_order_draft import DraftError, connection_context, is_fresh, make_draft


def _form_inputs():
    market = st.session_state.get('kis_pc_market')
    order = dict(market=market, exchange=st.session_state.get('kis_pc_exchange_' + str(market)),
        symbol=st.session_state.get('kis_pc_symbol_' + str(market)), side=st.session_state.get('kis_pc_side'),
        quantity=st.session_state.get('kis_pc_quantity'), limit_price=st.session_state.get('kis_pc_price_' + str(market)))
    limits = dict(max_notional=st.session_state.get('kis_pc_cap_' + str(market)),
        fee_buffer_pct=st.session_state.get('kis_pc_fee'), max_quote_gap_pct=st.session_state.get('kis_pc_gap'),
        downside_pct=st.session_state.get('kis_pc_downside'), max_scenario_loss=st.session_state.get('kis_pc_loss_' + str(market)),
        risk_attested=st.session_state.get('kis_pc_attested'))
    return order, limits


def _calculate_inputs(client):
    # A calculation is never a precheck PASS or transferable draft.
    for key in ('_kis_precheck_result', '_kis_order_draft', '_kis_precheck_calculation', '_kis_precheck_copy_error'):
        st.session_state.pop(key, None)
    st.session_state['kis_pc_attested'] = False
    if st.session_state.get('_kis_client') is not client or st.session_state.get('kis_view') != 'PRECHECK':
        return
    order, limits = _form_inputs()
    preview = dict(context=(connection_context(client), tuple(order.items()), tuple(limits.items())),
                   calculated_at=datetime.now(timezone.utc).isoformat())
    try:
        preview['result'] = calculate_amounts(order, limits['fee_buffer_pct'], limits['max_notional'])
    except BrokerError as exc:
        preview['error'] = str(exc)
    except Exception:
        preview['error'] = '금액을 계산하지 못했습니다. 입력값을 확인하고 다시 계산하세요.'
    st.session_state['_kis_precheck_calculation'] = preview


def _render_calculation(preview):
    st.subheader('입력 금액 계산 결과')
    st.caption('계산 버튼을 눌렀을 때의 입력값입니다. 값을 바꾸면 다시 계산하세요. 증권사 시세·잔고 조회는 수행하지 않았습니다.')
    st.caption('계산: ' + format_time(preview['calculated_at']))
    if 'error' in preview:
        st.warning(preview['error'])
        return
    result = preview['result']; order = result['order']; currency = order['currency']
    st.write(f"{'국내' if order['market'] == 'KR' else '미국'} · {order['exchange']} · {order['symbol']} · "
             f"{'매수' if order['side'] == 'BUY' else '매도'} · {order['quantity']:,}주 × {money_text(order['limit_price'], currency)}")
    st.table([{'항목': '주문 원금 (수량 × 지정가)', '금액': money_text(result['gross'], currency)},
              {'항목': '비용 여유 (' + result['fee_buffer_pct'] + '%)', '금액': money_text(result['buffer'], currency)},
              {'항목': '상한 비교 금액 (비용 여유 포함)', '금액': money_text(result['comparison_amount'], currency)}])
    status = result['cap_status']
    if status == 'MISSING':
        st.info('상한 미입력 · 계산값을 참고해 허용할 금액 상한을 직접 입력하세요. 상한은 자동으로 채우지 않습니다.')
    elif status == 'INVALID':
        st.warning('상한 입력 확인 · ' + result['cap_message'])
    elif status == 'EXCEEDS':
        st.warning('상한 초과 · 입력한 상한 ' + money_text(result['cap'], currency)
                   + '보다 ' + money_text(result['difference'], currency) + ' 큽니다. 수량·지정가·상한을 검토하세요.')
    else:
        st.info('상한 이내 · 입력한 상한 ' + money_text(result['cap'], currency)
                + '와의 차이: ' + money_text(result['difference'], currency))
    st.caption('상한 비교 금액은 매수·매도 모두 비용 여유를 더해 계산합니다. 실제 수수료·세금이나 매도 실수령액을 뜻하지 않습니다.')
    st.info('금액 계산은 입력·조회 점검 통과가 아닙니다. 조건 확인을 체크하고 입력·조회 점검을 별도로 실행하세요.')


def _copy_checked_inputs(client):
    """Form callback receives unsent edits before validating the fixed result."""
    st.session_state.pop('_kis_order_draft', None)
    try:
        if st.session_state.get('_kis_client') is not client or st.session_state.get('kis_view') != 'PRECHECK':
            raise DraftError('연결 또는 화면이 바뀌었습니다. 다시 점검하세요.')
        order, limits = _form_inputs()
        context = (connection_context(client), tuple(order.items()), tuple(limits.items()))
        if st.session_state.get('_kis_precheck_context') != context:
            raise DraftError('점검 후 입력 조건이 바뀌었습니다. 입력·조회 점검을 다시 실행하세요.')
        draft = make_draft(st.session_state.get('_kis_precheck_result'), order, limits, connection_context(client))
        st.session_state['_kis_order_draft'] = draft
        st.session_state['kis_view'] = 'ORDERS'
    except DraftError as exc:
        st.session_state.pop('_kis_precheck_result', None)
        st.session_state['_kis_precheck_copy_error'] = str(exc)


def clear_precheck():
    for key in list(st.session_state):
        if key.startswith(('_kis_precheck', 'kis_pc_')):
            st.session_state.pop(key, None)


def render(client):
    st.subheader('주문 전 점검')
    mode = client.credentials.mode
    st.info(('실전투자 (LIVE)' if mode == 'LIVE' else '모의투자 (PAPER)')
            + ' · 조회만 수행 · 주문 전송 없음')
    st.caption('입력한 주문 조건의 금액·가정 손실·시세·현금 또는 보유 수량을 확인합니다. '
               '주문 준비 기록을 만들지 않으며, 주문 중지 상태·미확인 주문·거래시간·호가 규칙·체결 가능 여부는 이 화면의 통과 판정에 포함되지 않습니다.')
    account_context = connection_context(client)
    if st.session_state.get('_kis_precheck_account') != account_context:
        clear_precheck()
        st.session_state['_kis_precheck_account'] = account_context
    market = st.selectbox('점검 시장', ['KR', 'US'],
        format_func=lambda v: '국내 주식·ETF' if v == 'KR' else '미국 주식·ETF', key='kis_pc_market')
    exchange = st.selectbox('점검 거래소', ['KRX'] if market == 'KR' else ['NASD', 'NYSE', 'AMEX'],
                            key='kis_pc_exchange_' + market)
    render_session_status(client, market)
    side = st.radio('점검 방향', ['BUY', 'SELL'],
        format_func=lambda v: '매수' if v == 'BUY' else '매도', key='kis_pc_side', horizontal=True, index=None)
    st.caption('방향·시장을 먼저 선택한 뒤 숫자를 입력하세요. 점검 통과 후 60초 안에 아래 가져오기 버튼으로 주문 준비에 옮길 수 있습니다. 직접 화면을 떠나면 점검 입력은 초기화됩니다.')
    if side is None: st.info('매수 또는 매도를 직접 선택해 주세요.')
    else: st.info('선택한 점검 방향: ' + ('매수' if side == 'BUY' else '매도'))
    selection = (market, exchange, side)
    if st.session_state.get('_kis_precheck_selection') != selection:
        st.session_state.pop('_kis_precheck_result', None)
        st.session_state['kis_pc_attested'] = False
        st.session_state['_kis_precheck_selection'] = selection
    currency = 'KRW' if market == 'KR' else 'USD'
    with st.form('kis_precheck', enter_to_submit=False):
        st.caption('숫자 입력 예: 263000 / 1850205 / 0.5. 쉼표·원·% 기호를 넣지 마세요.')
        symbol = st.text_input('점검 종목코드', key='kis_pc_symbol_' + market,
                               placeholder='6자리 코드' if market == 'KR' else '티커')
        quantity = st.number_input('점검 수량 (주)', min_value=1, max_value=1000000,
                                    value=1, step=1, key='kis_pc_quantity')
        price = st.text_input('점검 지정가 (' + currency + ')', value='0', key='kis_pc_price_' + market)
        cap = st.text_input('금액 상한 (' + currency + ')', value='0', key='kis_pc_cap_' + market)
        fee = st.text_input('비용 여유율 (%)', value='0.5', key='kis_pc_fee')
        gap = st.text_input('조회 가격과 지정가 차이 한도 (%)', value='3', key='kis_pc_gap')
        downside = st.text_input('하락 가정 (%)', value='0', key='kis_pc_downside', disabled=side == 'SELL')
        loss = st.text_input('가정 손실 예산 (' + currency + ')', value='0',
                             key='kis_pc_loss_' + market, disabled=side == 'SELL')
        st.caption('가정 손실 = 지정가 × 수량 × 하락 가정 + 비용 여유. 실제 손실의 상한이나 손절 주문이 아닙니다. '
                   '미국 점검은 USD 기준이며 자동 환전하지 않습니다.')
        st.form_submit_button('입력 금액만 계산', key='kis_pc_calculate',
            on_click=_calculate_inputs, args=(client,), disabled=side is None)
        st.caption('상한을 정하기 전에 원금과 비용 여유를 계산할 수 있습니다. 계산 후에는 조건 확인을 다시 체크하세요.')
        attested = st.checkbox('입력한 종목·가격·수량·상한과 손실 가정을 확인했습니다', key='kis_pc_attested')
        submitted = st.form_submit_button('입력·조회 점검만 실행', disabled=side is None)
        previous = st.session_state.get('_kis_precheck_result') or {}
        st.form_submit_button('점검한 조건을 주문 준비로 가져오기', key='kis_pc_copy',
            on_click=_copy_checked_inputs, args=(client,),
            disabled=previous.get('status') != 'PASS' or not is_fresh(previous.get('checked_at')))
        st.caption('가져오기는 입력값만 옮깁니다. 입력을 바꿨거나 60초가 지났다면 다시 점검하세요. 주문 준비에서 조건 확인과 새 조회가 필요합니다.')
    order = dict(market=market, exchange=exchange, symbol=symbol, side=side,
                 quantity=quantity, limit_price=price)
    limits = dict(max_notional=cap, fee_buffer_pct=fee, max_quote_gap_pct=gap,
                  downside_pct=downside, max_scenario_loss=loss, risk_attested=attested)
    context = (account_context, tuple(order.items()), tuple(limits.items()))
    if st.session_state.get('_kis_precheck_context') != context:
        st.session_state.pop('_kis_precheck_result', None)
        st.session_state['_kis_precheck_context'] = context
    if submitted:
        st.session_state.pop('_kis_precheck_calculation', None)
        st.session_state.pop('_kis_precheck_result', None)
        with st.spinner('입력 조건과 증권사 조회값을 점검하고 있습니다…'):
            st.session_state['_kis_precheck_result'] = run_precheck(client, order, limits)
        st.rerun()
    calculation = st.session_state.get('_kis_precheck_calculation')
    if calculation is not None:
        if calculation['context'] == context:
            _render_calculation(calculation)
        else:
            st.session_state.pop('_kis_precheck_calculation', None)
    copy_error = st.session_state.pop('_kis_precheck_copy_error', None)
    if copy_error:
        st.warning(copy_error)
    result = st.session_state.get('_kis_precheck_result')
    if result is None:
        return
    st.caption('마지막으로 점검 버튼을 눌렀을 때의 기록입니다. 입력란을 편집한 뒤에는 다시 점검하세요.')
    st.caption(f"점검: {format_time(result['checked_at'])} · {result['elapsed_ms']}ms")
    if result['status'] != 'PASS':
        st.error(result['message'])
        with st.expander('점검 진단'):
            st.write({'환경': mode, '단계': result['stage'], **result['diagnostic']})
        return
    checked = result['order']; snapshot = result['snapshot']
    if is_fresh(result['checked_at']):
        st.success('입력·조회 점검 통과 (점검 당시)')
    else:
        st.warning('이전 점검 기록입니다. 현재 상태를 확인하려면 다시 점검하세요.')
    st.table([{'환경': '실전투자 (LIVE)' if mode == 'LIVE' else '모의투자 (PAPER)',
               '시장': '국내' if checked['market'] == 'KR' else '미국',
               '거래소': checked['exchange'], '종목': checked['symbol'],
               '방향': '매수' if checked['side'] == 'BUY' else '매도',
               '수량': checked['quantity'], '지정가': checked['limit_price'], '통화': checked['currency']}])
    st.write(f"증권사 조회 가격: {snapshot['quote']['price']} {currency}")
    st.caption('시세 조회: ' + format_time(snapshot['quote']['fetched_at']))
    st.write(f"비용 여유 포함 금액: {snapshot['estimated_cost']} {currency}")
    if checked['side'] == 'BUY':
        st.write(f"가정 손실: {snapshot['scenario_loss']} {currency}")
        st.write(f"조회된 주문 가능금액: {snapshot['availability']['cash']} {currency}")
    st.write(f"조회된 {'매수' if checked['side'] == 'BUY' else '매도'} 가능 수량: {snapshot['availability']['quantity']}주")
    st.info('점검 통과는 주문 허용이나 체결 보장이 아닙니다. 주문하려면 주문·체결 관리에서 별도로 준비하고 확인해야 합니다.')
