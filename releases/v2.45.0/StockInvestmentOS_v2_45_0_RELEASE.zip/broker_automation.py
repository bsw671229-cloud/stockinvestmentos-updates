"""Native UI for explicit, bounded PAPER automation in an existing connection."""
import ui_locale as _locale
from datetime import datetime
from pathlib import Path
import time
import json
import streamlit as st

from connectors.kis_broker import BrokerError
from engine.broker_execution import Journal, digest
from engine.paper_automation import Automation, paper_only, validate_rule, validate_rules, remove_rule, session_open
from engine.live_automation import LiveAutomation, live_only, LIVE_CONFIRMATION
from engine.paper_calendar import session_status, AS_OF, SOURCES
from engine.paper_recovery import history, review_stopped
from engine.paper_rehearsal import rehearse, signature
from engine.paper_fills import refresh_fills
from engine.paper_plans import PlanStore
from engine.plan_origin import describe
from broker_plan_library import library, clear_editor_confirmation, clear_plan_context

LABELS = {'WAITING': '조건 대기', 'CLAIMED': '시도 기록됨', 'PENDING': '접수·체결 확인 중',
    'FILLED': '전량 체결', 'CANCELLED': '취소 확인', 'UNKNOWN': '접수 여부 확인 필요',
    'REJECTED': '거절', 'FAILED_PRECHECK': '사전 점검 중단', 'EXPIRED': '만료', 'SKIPPED': '선행 매수 취소 · 실행 안 함'}
LABELS.update(ARMED='실행 중', STOPPED='중단됨', COMPLETE='처리 완료', REVIEW_REQUIRED='중단·결과 확인 필요',
    ALTERNATIVE_SKIPPED='다른 연결 매도 선택 · 실행 안 함',
    PREPARED='전송 전 준비', ACKNOWLEDGED='접수됨', OPEN='미체결', PARTIAL='일부 체결',
    SENDING='전송 결과 확인 필요', CANCEL_REQUESTED='취소 결과 대기', CANCEL_UNKNOWN='취소 결과 확인 필요')


def _hours():
    for col, market, label in zip(st.columns(2), ('KR','US'), ('국내','미국')):
        status = session_status(market,time.time())
        col.write('**'+label+' 거래시간 확인**')
        col.write(status['reason'])
        col.caption(status['local']+' · 정규 종료 '+status['close'])
    st.caption('미국 예정 휴장·조기 종료: 2026년만 확인. 국내 휴장, 임시 시간 변경·거래정지는 별도 확인이 필요합니다.')


def _engine(journal, mode='PAPER'):
    return LiveAutomation(journal) if mode == 'LIVE' else Automation(journal)


def _skip_monitor_tick():
    """A history action must not run an automatic cycle before its own handler."""
    if st.session_state.get('_paper_auto'):
        st.session_state['_paper_auto_skip_tick'] = True


def _history(client, journal, mode='PAPER'):
    from broker_stop_confirmation import gate
    if not gate(_engine):return
    automation = _engine(journal, mode)
    report = history(automation,client)
    summary = report['attempt_summary']
    from broker_unresolved_panel import render_unresolved
    render_unresolved(automation, client, on_read=_skip_monitor_tick)
    st.caption('실행 이력 로컬 확인 시각 (UTC): '+report['generated_at'])
    with st.expander('이전 실행·중단 결과 확인', expanded=bool(report['unresolved_attempts'])):
        st.caption('화면을 다시 열어도 기록이 남습니다. 확인 버튼은 신규 주문을 막은 뒤 기존 주문 결과만 조회하며 자동 재개하지 않습니다.')
        context = (id(client),client.credentials.identity,mode,str(journal.path.resolve()))
        saved = st.session_state.get('_recovery_review_batch')
        if saved and saved['context'] != context:
            st.session_state.pop('_recovery_review_batch',None)
            saved = None
        first = st.button('신규 주문을 막고 이전 결과 확인', key='paper_review', on_click=_capture_review_stop, args=(client,journal,mode), disabled=not report['unresolved_attempts'])
        following = st.button('남은 기록 다음 20건 확인', key='paper_review_next', on_click=_capture_review_stop, args=(client,journal,mode),
                              disabled=not(saved and saved['review'].get('next_cursor')))
        if first or following:
            cursor = saved['review']['next_cursor'] if following and not first else None
            try:
                report = review_stopped(automation,client,confirmed=True,cursor=cursor)
                saved = dict(context=context,review=report['review'])
                st.session_state['_recovery_review_batch'] = saved
                st.session_state.pop('_paper_auto',None)
                _skip_monitor_tick()
                st.rerun()
            except Exception:
                st.session_state.pop('_recovery_review_batch',None)
                st.error('이전 결과를 확인하지 못했습니다. 주문·체결 관리에서 확인하세요. 다음 검토는 처음부터 시작합니다.')
                return
        if saved:
            outcome=saved['review']
            st.info(f"최근 검토 {outcome['examined']}건 · 증권사 결과 조회 {outcome['history_checked']}건 · 전송 전 종료 확인 {outcome['pre_send_closed']}건 · 조회 실패 {outcome['check_required']}건 · 주문 결과 반영 {outcome['result_synced']}건")
            st.caption(f"검토를 시작한 범위에서 남은 기록 {outcome['remaining_in_scope']}건 · 이후 추가된 미확인 기록 {outcome['newer_unresolved']}건. 최근 버튼 실행 시점 기준입니다.")
            if outcome['next_cursor']:
                st.warning('아직 검토하지 않은 기록이 있습니다. 다음 20건 확인을 눌러 이어서 검토하세요. 앞서 미확인인 주문은 그대로 남습니다.')
            else:
                st.info('이번 범위의 검토가 끝났습니다. 모든 주문의 결과가 확정됐다는 뜻은 아닙니다. 다시 확인하려면 처음 버튼을 누르세요.')
        st.caption('한 번에 최대 20건만 검토합니다. 다음 범위는 직접 눌러 확인하며, 신규 주문 차단을 유지합니다. 주문 전송·취소·자동 재개는 하지 않습니다.')
        if summary['result_sync_pending']:
            st.info(f"주문 결과가 기록된 {summary['result_sync_pending']}건 · 자동매매 기록 반영 대기입니다. 위의 신규 주문을 막고 이전 결과 확인 버튼으로 반영하세요. 기록 반영은 신규 주문을 다시 허용하거나 자동매매를 재개하지 않습니다.")
        if summary['order_check_required']:
            st.warning(f"미확인 주문 시도 {summary['order_check_required']}건 · 미체결·일부 체결·접수 불명확 기록을 확인하세요.")
        elif summary['result_sync_pending']:
            st.caption('현재 연결의 로컬 주문 기록에는 종료 결과가 있습니다. 이번 화면 열기에서 증권사에 새로 조회한 것은 아닙니다. 체결 금액 확인 여부는 아래 별도 표시를 확인하세요.')
        elif report['runs']:
            st.info('미확인 자동 주문 시도가 없습니다. 새 실행은 조건과 예산을 확인한 뒤 직접 시작하세요.')
        else:
            st.caption('아직 저장된 자동매매 실행이 없습니다.')
        terminal = any(r['order_reference'] and r['state'] in ('FILLED','CANCELLED','REJECTED') for run in report['runs'] for r in run['rules'])
        fill_saved=st.session_state.get('_fill_review_batch')
        if fill_saved and fill_saved['context']!=context:
            st.session_state.pop('_fill_review_batch',None);fill_saved=None
        fill_first=st.button('완료 주문 체결 금액 다시 조회',key='paper_fill_refresh',on_click=_skip_monitor_tick,disabled=not terminal)
        fill_next=st.button('남은 완료 주문 다음 20건 조회',key='paper_fill_next',on_click=_skip_monitor_tick,
                            disabled=not(fill_saved and fill_saved['outcome'].get('next_cursor')))
        if fill_first or fill_next:
            try:
                cursor=fill_saved['outcome']['next_cursor'] if fill_next and not fill_first else None
                report=refresh_fills(automation,client,confirmed=True,cursor=cursor)
                accumulated=dict(fill_saved.get('items',{})) if fill_next and not fill_first else {}
                accumulated.update({item['reference']:item['outcome'] for item in report['fill_refresh']['items']})
                fill_saved=dict(context=context,outcome=report['fill_refresh'],items=accumulated)
                st.session_state['_fill_review_batch']=fill_saved
                _skip_monitor_tick()
                st.rerun()
            except Exception:
                st.session_state.pop('_fill_review_batch',None)
                st.error('완료 주문 금액을 확인하지 못했습니다. 연결과 주문 기록을 확인하고 처음부터 다시 조회하세요.')
                return
        if fill_saved:
            outcome=fill_saved['outcome']
            st.info(f"완료 주문 조회 {outcome['checked']}건 · 금액 확인 {outcome['amount_verified']}건 · 금액 추가 확인 {outcome['amount_check_required']}건 · 조회 실패 {outcome['failed']}건 · 근거 부족 {outcome['skipped']}건")
            st.caption(f"처음 선택한 완료 주문 {outcome['total_in_scope']}건 중 남은 조회 {outcome['remaining_in_scope']}건 · 최근 버튼 실행 시점 기준입니다.")
            if outcome['failed'] or outcome['skipped']:
                st.warning('조회 실패·근거 부족 주문은 이전 기록을 유지합니다. 이전에 확인한 금액도 이번 조회에서 새로 확인된 것은 아닙니다.')
            issues={ref:code for ref,code in fill_saved.get('items',{}).items() if code!='VERIFIED'}
            st.caption(f"이번 조회 범위 누적 확인 {len(fill_saved.get('items',{}))}건 · 추가 확인 필요 {len(issues)}건 · 마지막 조회 {outcome['checked_at']}")
            guidance={
                'QUERY_FAILED':('조회 실패','연결과 증권사 주문·체결 내역을 확인한 뒤 처음 버튼으로 새로 조회하세요. 원인을 확정할 수 없어 이전 기록을 유지했습니다.'),
                'EVIDENCE_MISSING':('접수번호·수량 근거 부족','증권사 주문·체결 내역과 앱의 주문 기록을 대조하세요. 근거가 없어 자동으로 결과를 확정하지 않았습니다.'),
                'STATUS_CHANGED':('완료 상태 변경','주문·체결 관리에서 현재 상태를 확인하세요. 완료 주문 금액 재조회 대상에서 제외했습니다.'),
                'AMOUNT_CHECK_REQUIRED':('체결 금액 추가 확인','체결 수량·통화·금액과 금액 확인 시각을 대조하세요. 확인되지 않은 금액을 확정 금액으로 보지 마세요.')}
            issue_rows=[{'주문 기록':ref,'확인 이유':guidance[code][0],'다음 행동':guidance[code][1]} for ref,code in issues.items()]
            if issue_rows:
                st.warning('앞선 묶음의 실패·근거 부족·금액 미확인 기록도 남아 있습니다. 아래 목록을 확인하세요.')
                _locale.dataframe(st,issue_rows,hide_index=True,width='stretch')
            st.caption('누적 점검 내역은 현재 화면 세션의 조회 범위입니다. 처음 버튼은 새 범위를 시작하며, 연결 변경·화면 새로고침 시 이 안내가 초기화될 수 있습니다. 원본 주문 기록은 보존됩니다.')
            st.download_button('체결 조회 점검 결과 저장',json.dumps(dict(schema_version=1,checked_at=outcome['checked_at'],
                scope=outcome['scope'],total_in_scope=outcome['total_in_scope'],reviewed=len(fill_saved.get('items',{})),
                remaining=outcome['remaining_in_scope'],scope_complete=outcome['scope_complete'],issues=issue_rows),ensure_ascii=False,indent=2),
                file_name=mode+'_FILL_REVIEW.json',mime='application/json',key='paper_fill_review_download')
            if outcome['scope_complete']:
                st.info('선택한 범위의 조회가 끝났습니다. 금액이 모두 확인됐다는 뜻은 아닙니다. 실패·근거 부족 항목을 확인하세요.')
        st.caption('조회 시작 시 최근 10회 실행의 완료 주문을 선택하고, 한 번에 최대 20건씩 직접 조회합니다. 이후 추가된 주문은 처음 버튼으로 새로 조회하세요. 주문 전송·취소·자동 재개·차단 해제는 하지 않습니다.')
        if not terminal:
            st.caption('다시 조회할 완료 주문이 없습니다. 이 앱의 최근 자동매매 10회에 연결된 전량 체결·취소·거절 주문이 있으면 버튼을 사용할 수 있습니다.')
        rows = []
        st.caption('실행 계획에는 시작 시 확인한 원본과 수정 여부가 남습니다. 이전 기록은 소급 추정하지 않습니다. 원본을 확인할 수 없으면 계획 이름을 표시하지 않습니다.')
        for run in report['runs']:
            for rule in run['rules']:
                rows.append({'실행':run['run_reference'][-8:], '실행 계획':describe(run.get('plan_origin')), '실행 상태':LABELS.get(run['state'],run['state']),
                    '시장':rule['market'], '종목':rule['symbol'], '방향':'매수' if rule['side']=='BUY' else '매도',
                    '조건 번호':rule['index'], '연결 매수':str(rule['after_buy_index']) if rule['after_buy_index'] is not None else '없음',
                    '선택된 매도':str(rule['selected_exit_index']) if rule['selected_exit_index'] is not None else '미선택',
                    '수량':rule['quantity'], '주문 상태':LABELS.get(rule['state'],rule['state']),
                    '주문 기록':rule['order_reference'][-8:] or '없음', **_fill_columns(rule['fill_details'])})
        if rows:
            _locale.dataframe(st, rows,hide_index=True,width='stretch')
            st.download_button('실행 확인 보고서 저장',json.dumps(report,ensure_ascii=False,indent=2),
                file_name=mode+'_RUN_REVIEW.json',mime='application/json',key='paper_review_download')
        if report['fill_totals']:
            st.write('**확인된 체결 금액 · 통화별**')
            _locale.dataframe(st, [{'통화':r['currency'],'확인된 매수 체결 금액':r['buy_gross'],'확인된 매도 체결 금액':r['sell_gross'],
                '금액 확인 주문':r['known_orders'],'금액 확인 필요':r['amount_check_required'],'체결 미조회':r['not_queried']}
                for r in report['fill_totals']],hide_index=True,width='stretch')
            if any(r['amount_check_required'] or r['not_queried'] for r in report['fill_totals']):
                st.warning('금액 미확인 주문은 합계에서 제외되어 있습니다. 표시 합계는 전체 매매 금액이 아닐 수 있습니다.')
        st.caption(report['fill_coverage']+' · 평균 체결가는 확인된 체결 금액÷수량으로 계산합니다.')
        st.caption(report['coverage']+' · 조회 실패·접수 번호 누락·이전 버전의 연결되지 않은 기록은 확인 필요 상태로 보존합니다. 접수된 주문은 취소되지 않습니다.')
        st.markdown('**실행별 중단 원인·다음 확인**')
        st.caption('저장된 안내와 현재 확인 사항을 구분합니다. 현재의 만료·연결 상태는 과거의 실제 중단 원인이나 시각을 확정하지 않습니다. 이 안내를 여는 것만으로 주문 조회·중지·재개하지 않습니다.')
        for run in report['runs']:
            with st.expander('실행 '+run['run_reference'][-8:]+' · '+LABELS.get(run['state'],run['state'])):
                st.text('실행 계획: '+describe(run.get('plan_origin')))
                st.caption('저장 상태: '+LABELS.get(run['recorded_state'],run['recorded_state'])+' · 현재 표시: '+LABELS.get(run['state'],run['state']))
                for diagnostic in run['diagnostics']:
                    basis='저장된 안내' if diagnostic['basis']=='RECORDED' else '현재 확인 사항'
                    st.text(basis+': '+diagnostic['message'])
                    st.caption('다음 확인: '+diagnostic['next_action'])


def _fill_columns(detail):
    return {'체결 수량':str(detail['quantity']) if detail['quantity'] is not None else '미조회',
        '평균 체결가':detail['average_price'] or '미확인', '체결 금액':detail['gross_amount'] if detail['gross_amount'] is not None else '미확인',
        '금액 확인':{'VERIFIED':'확인됨','ZERO_FILL':'체결 없음','NOT_QUERIED':'미조회'}.get(detail['status'],'추가 확인 필요'),
        '금액 확인 시각 (UTC)':detail.get('checked_at') or '미조회'}


def stop_session(*,owned=False):
    from broker_stop_confirmation import capture_active,retry_pending
    if owned:capture_active(owned=True)
    else:capture_active()
    st.session_state.pop('_paper_auto_draft', None)
    st.session_state.pop('_paper_auto_context', None)
    st.session_state.pop('_paper_rehearsal', None)
    clear_editor_confirmation()
    clear_plan_context()
    return retry_pending(_engine)


def _capture_review_stop(client,journal,mode):
    from broker_stop_confirmation import capture_active,capture_target
    capture_target(journal,client.credentials.identity,mode)
    capture_active()


def _rehearsal_view(client, draft, budgets, minutes, mode='PAPER'):
    saved = st.session_state.get('_paper_rehearsal')
    if not saved:
        return
    try:
        current = signature(client, draft, budgets, minutes, mode=mode)
    except Exception:
        current = None
    if current != saved['signature']:
        st.session_state.pop('_paper_rehearsal', None)
        st.info('입력 또는 연결이 바뀌었습니다. 전체 조건을 다시 점검하세요.')
        return
    report = saved['report']
    st.markdown('**전체 조건 점검 결과**')
    expired = time.time() >= datetime.fromisoformat(report['expires_at']).timestamp()
    if expired:
        st.warning('조회 후 60초가 지나 다시 점검해야 합니다. 아래 내용은 이전 조회 기록입니다.')
    elif report['blockers']:
        st.error('시작 전 수정·확인이 필요합니다.')
    elif report['status']=='WAITING':
        st.info('입력 점검 완료 · 가격·거래시간·선행 매수 체결 대기 항목을 확인하세요.')
    else:
        st.success('조회 시점의 전체 조건 점검 완료')
    for message in report['blockers']:
        st.write('• '+message)
    if report['currencies']:
        _locale.dataframe(st, [{'통화':r['currency'], '전체 매수 필요 현금':r['buy_cash_required'],
            '조회 가능 현금':r['available_cash'] if r['available_cash'] is not None else ('매수 없음' if r['buy_cash_required']=='0' else '조회 전'), '이번 비용 포함 금액':r['planned_cost'],
            '오늘 사용 금액':r['used_cost'], '하루 금액 한도':r['budget']['cost'],
            '이번 가정 손실':r['planned_loss'], '오늘 사용 가정 손실':r['used_loss'], '하루 가정 손실 한도':r['budget']['loss'],
            '이번 시도 수':r['planned_count'], '오늘 사용 시도 수':r['used_count'], '하루 시도 한도':r['budget']['count']}
            for r in report['currencies']], hide_index=True, width='stretch')
    if report['holdings']:
        _locale.dataframe(st, [{'시장':r['market'], '거래소':r['exchange'], '종목':r['symbol'],
            '방향':'매수' if r['side']=='BUY' else '매도', '합계 수량':r['required'], '조회 가능 수량':r['available']}
            for r in report['holdings']], hide_index=True, width='stretch')
    if report['rules']:
        _locale.dataframe(st, [{'순서':r['index'], '시장':r['market'], '종목':r['symbol'], '조회 가격':r['quote']['price'],
            '상태':'대기' if r['status']=='WAIT' else '조회 조건 충족', '사유':' · '.join(r['reasons']) or '조회 시점 기준'}
            for r in report['rules']], hide_index=True, width='stretch')
    st.caption('조회 시각(UTC): '+report['checked_at']+' · 조회 당시 제출한 입력 기준 · 시작 시 항상 다시 검사합니다.')
    st.caption(report['coverage'])
    st.download_button('전체 조건 점검 보고서 저장', json.dumps(report,ensure_ascii=False,indent=2),
        file_name=mode+'_PLAN_REHEARSAL.json', mime='application/json', key='paper_rehearsal_download')


def _rule_rows(rules):
    linked_counts = {r['after_buy']:sum(x.get('after_buy')==r['after_buy'] for x in rules) for r in rules if 'after_buy' in r}
    return [{'시장': r['order']['market'], '거래소': r['order']['exchange'], '종목': r['order']['symbol'],
             '방향': '매수' if r['order']['side'] == 'BUY' else '매도',
             '선행 조건': (str(r['after_buy']+1)+'번 매수 전량 체결'+(' · 두 매도 중 하나' if linked_counts[r['after_buy']]==2 else '')) if 'after_buy' in r else '없음',
             '조건': f"{r['trigger']} {'이하' if r['comparison']=='LE' else '이상'}",
             '수량': r['order']['quantity'], '지정가': r['order']['limit_price'], '통화': r['order']['currency']}
            for r in rules]


def _stop_after_monitor_error():
    from broker_stop_confirmation import render_pending
    if stop_session(owned=True):
        st.error('실행 기록을 확인하지 못해 현재 세션의 자동 실행 권한을 제거했습니다. 자동으로 재개하지 않습니다. 저장소 접근과 이전 실행·주문 결과를 직접 확인하세요.')
        st.caption('접수된 주문은 자동 취소되지 않으며 이미 전송 중인 요청은 완료될 수 있습니다. 새 실행은 기록 확인 후 직접 시작해야 합니다.')
    else:
        render_pending()


@st.fragment(run_every='10s')
def _monitor(client, journal):
    from broker_stop_confirmation import gate,render_pending,capture_active
    if not gate(_engine):return
    active = st.session_state.get('_paper_auto')
    if not active:
        try:
            if journal.halted(client.credentials.identity):
                st.warning('자동매매 중지 확인 · 현재 계좌의 신규 주문이 차단되어 있습니다. 접수된 주문의 취소와 결과 확인은 별도로 진행하세요.')
            else:
                st.warning('현재 화면의 자동 실행 권한이 없습니다. 중지 기록과 이전 주문 결과를 직접 확인하세요.')
            _history(client,journal,client.credentials.mode)
        except Exception:
            st.error('중지 후 기록을 다시 읽지 못했습니다. 현재 화면의 자동 실행 권한은 없습니다. 저장소 접근과 이전 주문 결과를 확인하세요.')
        return
    try:
        automation, permit = _engine(journal, active.get('mode','PAPER')), active['permit']
    except Exception:
        _stop_after_monitor_error();return
    skip_tick = st.session_state.pop('_paper_auto_skip_tick', False)
    if st.button('자동매매 중지 · 신규 주문 차단', key='paper_auto_stop', type='primary', on_click=capture_active):
        if stop_session():st.rerun()
        render_pending();return
    try:
        before = automation.snapshot(permit)
        if before['state'] == 'ARMED' and not skip_tick:
            automation.tick(client, permit)
        state = automation.snapshot(permit)
        st.text('실행 계획: ' + describe(state.get('plan_origin')))
        if state['state'] == 'ARMED':
            st.success(_locale.message(('실전' if automation.mode == 'LIVE' else '모의') + ' 자동매매 실행 중 · 10초마다 조건과 주문 상태 확인'))
        elif state['state'] == 'COMPLETE':
            st.success('등록한 조건의 처리 완료')
        else:
            st.warning(_locale.message(state['note']))
        st.caption('종료 예정: ' + datetime.fromtimestamp(state['expires']).strftime('%H:%M:%S') + ' (이 PC 시간)')
        _hours()
        rows = _rule_rows([r['rule'] for r in state['rules']])
        for row, item in zip(rows, state['rules']):
            row['상태'] = LABELS.get(item['state'], item['state'])
            row['대기·진행 안내'] = item['waiting_info']['message']
            row['최근 조회 가격'] = item['price'] or '—'
            row.update(_fill_columns(item['fill_details']))
        _locale.dataframe(st, rows, hide_index=True, width='stretch')
        st.caption('대기·진행 안내는 현재 로컬 기록과 등록된 거래시간 기준입니다. 최근 기록 가격은 현재 시세가 아니며 조회 시각이 저장되어 있지 않습니다. 조건 충족 표시는 주문 가능·전송·체결을 보장하지 않습니다.')
        st.caption('로컬 상태 확인 시각 (UTC): '+state['observed_at'])
        if state['totals']:
            st.write('오늘의 자동 주문 시도 누계 · 한국시간 기준')
            _locale.dataframe(st, [{'통화': c, '비용 포함 금액': v['cost'], '가정 손실': v['loss'], '시도 수': v['count']} for c, v in state['totals'].items()], hide_index=True, width='stretch')
        st.caption('접수된 주문은 중지·화면 종료로 취소되지 않습니다. 취소와 결과 확인은 주문·체결 관리에서 진행하세요. 이미 전송 중인 요청은 완료될 수 있습니다.')
        if state['state'] != 'ARMED' and st.button('실행 기록 확인 후 새 조건 작성', key='paper_auto_new'):
            st.session_state.pop('_paper_auto', None)
            st.session_state.pop('_paper_auto_draft', None)
            st.rerun()
    except Exception:
        _stop_after_monitor_error();return
    try:
        _history(client,journal,active.get('mode','PAPER'))
    except Exception:
        _stop_after_monitor_error()


def render(client, journal, *, live=False):
    from broker_stop_confirmation import gate,render_pending
    if not gate(_engine):return
    mode = 'LIVE' if live else 'PAPER'
    label = '실전' if live else '모의'
    st.subheader('국내·미국 '+label+' 자동매매')
    st.caption('가격 조건 → '+label+' 지정가 주문 → 체결 확인 | 조건별 1회 실행')
    if client.credentials.mode != mode:
        st.warning('모의투자(모의투자)에 연결한 뒤 이용하세요. 실전 자동 주문은 사용할 수 없습니다.')
        return
    try:
        (live_only if live else paper_only)(client)
    except BrokerError as exc:
        st.error(_locale.message(str(exc))); return
    context = (client.credentials.identity, id(client), mode)
    if st.session_state.get('_paper_auto_context') != context:
        if not stop_session():
            render_pending();return
        for key in list(st.session_state):
            if key.startswith(('paper_symbol_', 'paper_trigger_', 'paper_price_', 'paper_cap_', 'paper_loss_', 'paper_after_buy_')) or key in ('paper_side','paper_quantity','paper_downside','live_confirmation'):
                st.session_state.pop(key, None)
        st.session_state['_paper_auto_context'] = context
    if live:
        st.warning('실제 자금으로 주문합니다. 조건·수량·지정가·하루 한도를 직접 정하고 시작하세요. 실제 주문·체결 통합 검증은 아직 완료되지 않았습니다.')
    else:
        st.info('직접 등록한 조건으로 모의 주문을 전송합니다. 실제 증권사 모의계좌 연동 검증은 아직 필요합니다.')
    st.caption('이 화면이 연결된 동안만 확인합니다. 재실행·재연결 시 자동 재개하지 않습니다. 60초 이상 점검이 끊기면 중단하며, 장시간 무인 운영은 지원하지 않습니다.')
    st.caption('직접 시작한 뒤 실행 표의 대기·진행 안내에서 기존 주문 확인, 선행 매수, 거래시간, 최근 기록 가격 기준의 대기 사유를 확인할 수 있습니다.')
    if st.session_state.get('_paper_auto'):
        _monitor(client, journal)
        return
    _history(client,journal,mode)
    library(client, journal, mode=mode)
    _hours()
    if journal.halted(client.credentials.identity):
        st.warning('중지·신규 주문 차단 상태입니다. 접수된 주문은 자동 취소되지 않습니다. 이전 주문 기록을 확인한 뒤 해제하세요.')
        if st.button('이전 주문 확인 후 신규 주문 차단 해제', key='paper_auto_unhalt'):
            journal.set_halted(client.credentials.identity, False)
            st.rerun()
    draft = st.session_state.setdefault('_paper_auto_draft', [])
    st.markdown('**1. 자동으로 실행할 조건 등록**')
    market = st.selectbox('자동매매 시장', ['KR', 'US'], format_func=_locale.option(lambda v: '국내 주식·ETF' if v == 'KR' else '미국 주식·ETF'), key='paper_market')
    currency = 'KRW' if market == 'KR' else 'USD'
    with st.form('paper_rule_form', enter_to_submit=False):
        left, right = st.columns(2)
        exchange = left.selectbox('거래소', ['KRX'] if market == 'KR' else ['NASD', 'NYSE', 'AMEX'], key='paper_exchange_'+market)
        symbol = right.text_input('종목코드 / 티커', key='paper_symbol_'+market)
        side = left.selectbox('매매 방향', ['BUY', 'SELL'], format_func=_locale.option(lambda v: '매수' if v == 'BUY' else '매도'), index=None, key='paper_side')
        comparison = right.selectbox('가격 조건', ['LE', 'GE'], format_func=_locale.option(lambda v: '조건 가격 이하' if v == 'LE' else '조건 가격 이상'), key='paper_comparison')
        parents = {f"{i+1}. {r['order']['market']} {r['order']['symbol']} 매수": i for i,r in enumerate(draft)
                   if r['order']['side']=='BUY' and r['order']['market']==market}
        parent_choice = st.selectbox('매도 실행 전 기다릴 매수', ['연결 없음', *parents],
            key='paper_after_buy_'+digest(draft)[:16]+'_'+market)
        st.caption('매수 하나에 같은 종목의 매도를 최대 두 개 연결할 수 있습니다. 두 개는 같은 수량으로 하단 이하·상단 이상을 설정하며 하단 가격이 더 낮아야 합니다. 수량은 선행 매수 이내입니다.')
        st.caption('매수 전량 체결 후 먼저 충족된 매도 하나만 시도합니다. 선택 즉시 다른 매도는 실행하지 않습니다. 선택한 주문이 실패·취소·일부 체결되어도 다른 조건으로 자동 전환하지 않습니다. 미체결은 주문·체결 관리에서 확인하세요.')
        trigger = left.text_input('조건 가격 ('+currency+')', value='0', key='paper_trigger_'+market)
        price = right.text_input('주문 지정가 ('+currency+')', value='0', key='paper_price_'+market)
        quantity = left.number_input('주문 수량 (주)', min_value=1, max_value=1000000, step=1, key='paper_quantity')
        cap = right.text_input('건별 비용 포함 금액 상한 ('+currency+')', value='0', key='paper_cap_'+market)
        fee = left.text_input('비용 여유율 (%)', value='0.5', key='paper_fee')
        gap = right.text_input('조회 가격·지정가 차이 한도 (%)', value='3', key='paper_gap')
        downside = left.text_input('매수 하락 가정 (%)', value='0', key='paper_downside')
        loss = right.text_input('건별 매수 가정 손실 예산 ('+currency+')', value='0', key='paper_loss_'+market)
        st.caption('매도도 보유 수량 안에서 지정가로 전송합니다. 가격 조건은 체결이나 손절을 보장하지 않습니다. 매도 조건은 하락 가정·가정 손실 예산을 사용하지 않습니다.')
        if st.form_submit_button('조건 목록에 추가', disabled=len(draft) >= 10):
            try:
                rule = validate_rule(dict(order=dict(market=market, exchange=exchange, symbol=symbol.strip().upper(), side=side, quantity=quantity, limit_price=price),
                    comparison=comparison, trigger=trigger, limits=dict(max_notional=cap, fee_buffer_pct=fee, max_quote_gap_pct=gap, downside_pct=downside, max_scenario_loss=loss, risk_attested=True)))
                if parent_choice in parents:
                    rule['after_buy'] = parents[parent_choice]
                validate_rules([*draft, rule])
                draft.append(rule)
                clear_editor_confirmation()
                st.rerun()
            except (BrokerError, ValueError, KeyError):
                st.error('방향·종목·가격·수량·예산과 연결 매수를 확인하세요. 두 연결 매도는 같은 수량, 하단 이하·상단 이상이며 하단 가격이 더 낮아야 합니다. 매수 하나당 최대 두 매도입니다.')
    if draft:
        _locale.dataframe(st, _rule_rows(draft), hide_index=True, width='stretch')
        remove_options = [f"{i+1}. {r['order']['market']} {r['order']['symbol']} {'매수' if r['order']['side']=='BUY' else '매도'}" for i,r in enumerate(draft)]
        remove_key = 'paper_remove_rule_'+digest(draft)[:16]
        remove_choice = st.selectbox('삭제할 조건', remove_options, index=None, key=remove_key)
        if st.button('선택 조건 삭제', key='paper_remove_one', disabled=remove_choice is None):
            if remove_choice in remove_options:
                try:
                    st.session_state['_paper_auto_draft'] = remove_rule(draft, remove_options.index(remove_choice))
                    clear_editor_confirmation()
                    st.session_state.pop(remove_key, None)
                    st.rerun()
                except BrokerError as exc:
                    st.error(_locale.message(str(exc)))
        if st.button('등록 조건 모두 지우기', key='paper_clear'):
            clear_editor_confirmation()
            st.session_state.pop('_paper_plan_reference', None)
            st.session_state.pop('_paper_loaded_plan', None)
            st.session_state['_paper_auto_draft'] = []; st.rerun()
    st.markdown('**2. 하루 한도와 실행 시간 확인**')
    st.caption('한국시간 하루 누계이며 이전 실행의 시도도 합산합니다. 실패·거절·불명확한 시도도 차감합니다. 원화와 달러는 따로 계산하며 자동 환전하지 않습니다.')
    st.caption('시작 전 전체 점검은 연결 매도 두 개도 각각 합산해 보수적으로 한도를 검사합니다. 실행 누계에는 실제 선택하여 시도한 주문만 반영합니다.')
    with st.form('paper_start_form', enter_to_submit=False):
        budgets = {}
        for c in sorted({r['order']['currency'] for r in draft}):
            st.write(c + ' 하루 자동 주문 시도 한도')
            a, b, d = st.columns(3)
            budgets[c] = dict(cost=a.text_input('비용 포함 금액 ('+c+')', value='0', key='paper_daily_cost_'+c),
                loss=b.text_input('매수 가정 손실 ('+c+')', value='0', key='paper_daily_loss_'+c),
                count=d.number_input('최대 시도 수 ('+c+')', min_value=1, max_value=10, value=1, key='paper_daily_count_'+c))
        minutes = st.number_input('이번 실행 시간 (분)', min_value=1, max_value=60, value=10, key='paper_minutes')
        st.caption('가정 손실 = 매수 금액 × 하락 가정 + 비용 여유. 실제 손익이나 최대손실 보장이 아닙니다. 한국시간 날짜가 바뀌면 중단합니다.')
        plan_name = st.text_input('저장할 계획 이름', max_chars=60, key='paper_plan_name')
        save_plan = st.form_submit_button('새 계획으로 저장 · 주문 없음', disabled=not draft)
        compare_plan = st.form_submit_button('현재 한도 입력을 비교에 반영 · 주문 없음', disabled=not draft)
        check = st.form_submit_button('조회만 하여 전체 조건 점검', disabled=not draft)
        live_confirmation = st.text_input('시작 확인 문구: '+LIVE_CONFIRMATION, key='live_confirmation') if live else ''
        attested = st.checkbox('등록 조건과 예산을 확인했고 '+label+' 주문의 자동 전송을 시작합니다', key='paper_attested')
        start = st.form_submit_button('확인한 조건으로 '+label+' 자동매매 시작', type='primary', disabled=not draft or journal.halted(client.credentials.identity))
    if compare_plan:
        clear_editor_confirmation()
        st.session_state['_paper_plan_notice'] = '한도 입력과 실행 시간을 비교에 반영했습니다. 위의 저장한 자동매매 계획에서 변경 항목을 확인하세요.'
        st.rerun()
    if save_plan:
        try:
            PlanStore(journal, mode=mode).save(client, plan_name, draft, budgets, minutes)
            clear_editor_confirmation()
            st.session_state['_paper_plan_notice'] = '계획을 저장했습니다. 재시작 후 위의 저장한 자동매매 계획에서 불러올 수 있습니다.'
            st.rerun()
        except Exception:
            st.error('계획을 저장하지 못했습니다. 이름 중복·20개 제한·조건과 하루 한도를 확인하세요.')
    if check or start:
        st.session_state.pop('_paper_rehearsal', None)
        try:
            if start and attested is not True:
                raise BrokerError('등록 조건과 예산을 확인한 뒤 시작 확인란을 선택하세요.')
            if start and live and live_confirmation != LIVE_CONFIRMATION:
                raise BrokerError('실전 시작 확인 문구를 직접 입력하세요.')
            binding = signature(client, draft, budgets, minutes, mode=mode)
            with st.spinner('전체 조건의 금액·수량과 기존 주문 기록을 점검하고 있습니다…'):
                report = rehearse(client, journal, draft, budgets, minutes, mode=mode)
            st.session_state['_paper_rehearsal'] = dict(signature=binding, report=report)
            if start and not report['blockers'] and report['status'] in ('CHECKED','WAITING'):
                permit = _engine(journal,mode).arm(client, draft, budgets, minutes, confirmed=attested,
                    plan_reference=st.session_state.get('_paper_plan_reference'),
                    **({'live_confirmation':live_confirmation} if live else {}))
                st.session_state['_paper_auto'] = dict(permit=permit, path=str(journal.path), mode=mode)
                st.session_state.pop('paper_attested', None)
                st.session_state.pop('live_confirmation', None)
                st.session_state.pop('_paper_rehearsal', None)
                st.rerun()
        except (BrokerError, ValueError, KeyError, TypeError):
            st.error('조건·하루 한도·실행 시간과 시작 확인란·실전 확인 문구를 확인하세요.')
    _rehearsal_view(client, draft, budgets, minutes, mode)
    with st.expander('작동 범위와 확인할 점'):
        st.write('국내 KRX, 미국 NASDAQ·NYSE·AMEX의 정수 수량·현금 지정가 주문입니다. 미국 서머타임과 2026년 예정 휴장·조기 종료를 반영합니다. 2026년 밖의 미국 자동 주문은 달력 갱신 전까지 차단합니다. 실전 국내 주문은 한국투자증권 개장일 조회를 추가 확인합니다. 임시 거래시간 변경·거래정지는 별도 확인이 필요합니다.')
        st.caption('공식 일정 확인일: '+AS_OF)
        st.markdown('[NYSE 일정]('+SOURCES[0]+') · [NASDAQ 일정]('+SOURCES[1]+')')
        st.write('시세 응답을 새로 받아 조회 시점을 확인합니다. 거래소 원천 시세의 지연 여부는 보장하지 않습니다. 조건이 전송 점검 중 바뀌거나 잔고·예산이 부족하면 중단합니다.')
        st.write('조건별 시도는 한 번입니다. 재전송·재시작 후 자동 재개·시장가·자동 환전은 없습니다. 미완료 주문은 한 건씩 확인하며 불명확한 결과는 주문·체결 관리에서 확인하세요.')
