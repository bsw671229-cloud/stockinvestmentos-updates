"""Session-only, explicit KIS inquiries. No order engine or journal dependency."""
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import time
import streamlit as st
from connectors.kis_broker import BrokerError, number

KST = timezone(timedelta(hours=9))
STATE_KEYS = ('_kis_inquiry_context', '_kis_inquiry_results', '_kis_inquiry_basis')


def clear_results():
    for key in STATE_KEYS:
        st.session_state.pop(key, None)


def format_time(value):
    return datetime.fromisoformat(value).astimezone(KST).strftime('%Y-%m-%d %H:%M:%S KST')


def resolve_reference(record, method, manual_price, currency, now=None):
    if method == 'MANUAL':
        return str(number(manual_price, positive=True)), {'kind': 'MANUAL', 'label': '사용자 입력 계산가격 · 최신 시세 아님'}
    if not record or record.get('status') != 'PASS':
        raise BrokerError('먼저 시세를 조회하거나 계산가격 입력을 선택하세요')
    quote = record['data']
    if quote.get('currency') != currency:
        raise BrokerError('시세와 조회 통화가 일치하지 않습니다')
    try:
        fetched = datetime.fromisoformat(quote['fetched_at'])
        if fetched.tzinfo is None: raise ValueError()
        age = ((now or datetime.now(timezone.utc)) - fetched).total_seconds()
    except (ValueError, TypeError, KeyError):
        raise BrokerError('시세 조회시각을 확인할 수 없습니다') from None
    if not 0 <= age <= 60:
        raise BrokerError('조회 가격이 60초를 지났습니다. 시세를 다시 조회하거나 계산가격을 직접 입력하세요')
    return str(number(quote['price'], positive=True)), {
        'kind': 'QUOTE', 'label': '최근 API 조회 가격', 'quote_fetched_at': quote['fetched_at']}


def _run(client, action):
    client.last_diagnostic = {}
    start = time.monotonic()
    try:
        data = action()
        result = {'status': 'PASS', 'data': data}
    except BrokerError as exc:
        result = {'status': 'CHECK_REQUIRED', 'message': str(exc)}
    except Exception:
        result = {'status': 'CHECK_REQUIRED', 'message': '조회 결과를 확인하지 못했습니다. 해당 항목을 다시 점검하세요.'}
    result.update(checked_at=datetime.now(timezone.utc).isoformat(),
        elapsed_ms=round((time.monotonic() - start) * 1000), diagnostic=dict(client.last_diagnostic))
    return result


def _status(record):
    if record['status'] == 'PASS':
        st.success('조회 성공')
    else:
        st.error(record['message'])
    st.caption(f"확인: {format_time(record['checked_at'])} · {record['elapsed_ms']}ms")
    diagnostic = record.get('diagnostic', {})
    if diagnostic.get('attempts', 1) > 1:
        st.caption('일시 오류 후 조회를 1회 다시 확인했습니다.')
    if record['status'] != 'PASS' or diagnostic.get('first_error'):
        with st.expander('조회 진단'):
            st.write(diagnostic or {'안내': '증권사 요청 전 입력값 점검에서 중단되었습니다.'})
            st.caption('오류 코드와 요청 상태만 표시합니다. 서버 원문·키·계좌번호는 표시하지 않습니다.')


def render(client):
    st.subheader('시세·잔고·주문 가능금액 조회')
    st.caption('현재 연결을 함께 사용합니다. 버튼을 누른 항목만 조회하며 주문 기록을 만들지 않습니다.')
    market = st.selectbox('조회 시장', ['KR', 'US'], format_func=lambda value: '국내 주식·ETF' if value == 'KR' else '미국 주식·ETF', key='kis_ro_market')
    exchange = st.selectbox('조회 거래소', ['KRX'] if market == 'KR' else ['NASD', 'NYSE', 'AMEX'], key='kis_ro_exchange_' + market)
    symbol = st.text_input('조회 종목코드', value='005930' if market == 'KR' else 'AAPL', key='kis_ro_symbol_' + market).strip().upper()
    currency = 'KRW' if market == 'KR' else 'USD'
    context = (client.credentials.identity, market, exchange, symbol)
    if st.session_state.get('_kis_inquiry_context') != context:
        clear_results()
        st.session_state['_kis_inquiry_context'] = context
    results = st.session_state.setdefault('_kis_inquiry_results', {})
    with st.container(border=True):
        st.markdown('**시세**')
        if st.button('시세 새로 조회', key='kis_ro_quote'):
            results['quote'] = _run(client, lambda: client.inquire_quote(market, exchange, symbol))
            if st.session_state.get('kis_ro_reference', 'QUOTE') == 'QUOTE':
                results.pop('power', None)
        quote = results.get('quote')
        if quote:
            _status(quote)
            if quote['status'] == 'PASS':
                st.metric('증권사 조회 가격', f"{Decimal(quote['data']['price']):,.2f} {currency}")
                st.caption('API 조회시각이며 거래소 체결시각은 아닙니다. 실시간 체결 가격을 보장하지 않습니다.')
    with st.container(border=True):
        st.markdown('**보유 주식 잔고**')
        if market == 'US' and exchange == 'NASD' and client.credentials.mode == 'LIVE':
            st.caption('실전 NASD 잔고 조회는 미국 전체 거래소를 포함합니다.')
        if st.button('잔고 새로 조회', key='kis_ro_positions'):
            results['positions'] = _run(client, lambda: client.positions(market, exchange))
        positions = results.get('positions')
        if positions:
            _status(positions)
            if positions['status'] == 'PASS':
                data = positions['data']
                st.caption(f"조회 범위: {data['scope']} · 연속조회 완료")
                rows = [{'종목': p['symbol'], '거래소': p['exchange'], '보유 수량': p['quantity'],
                    '매도 가능 수량': p['sellable_quantity'], '통화': p['currency']} for p in data['positions']]
                if rows: st.dataframe(rows, hide_index=True, alt='증권사 보유 주식 수량과 매도 가능 수량')
                else: st.info('조회된 보유 주식이 없습니다.')
    with st.container(border=True):
        st.markdown('**주문 가능금액**')
        method = st.radio('금액 조회 계산가격', ['QUOTE', 'MANUAL'],
            format_func=lambda value: '최근 조회 가격 (60초 이내)' if value == 'QUOTE' else '계산가격 직접 입력',
            key='kis_ro_reference', horizontal=True)
        manual = st.text_input('계산가격 (' + currency + ')', value='0', key='kis_ro_manual_' + market, disabled=method != 'MANUAL')
        basis = (method, manual if method == 'MANUAL' else results.get('quote', {}).get('checked_at'))
        if st.session_state.get('_kis_inquiry_basis') != basis:
            results.pop('power', None)
            st.session_state['_kis_inquiry_basis'] = basis
        if method == 'MANUAL': st.caption('입력한 가격에 따른 가능금액·수량만 계산합니다. 최신 시세 조회 성공으로 처리하지 않습니다.')
        st.caption('국내: 미수 없는 매수금액 · 미국: 주문 가능 외화금액(USD). 수수료 포함 실제 주문 가능 여부는 전송 전 별도 점검합니다.')
        if st.button('주문 가능금액 조회', key='kis_ro_power'):
            def lookup():
                price, reference = resolve_reference(results.get('quote'), method, manual, currency)
                return {**client.inquire_buying_power(market, exchange, symbol, price), 'basis': reference}
            results['power'] = _run(client, lookup)
        power = results.get('power')
        if power:
            _status(power)
            if power['status'] == 'PASS':
                data = power['data']
                st.metric('주문 가능금액', f"{Decimal(data['cash']):,.2f} {data['currency']}")
                st.write(f"{symbol} 조회 가능수량: {data['quantity']}주")
                st.caption(f"계산 기준: {data['basis']['label']} · {data['reference_price']} {currency}")
                if data['basis'].get('quote_fetched_at'):
                    st.caption('기준 가격 조회: ' + format_time(data['basis']['quote_fetched_at']))
                if data['quantity'] == 0: st.info('조회는 정상이며, 이 종목·계산가격의 가능수량은 0주입니다.')
    st.caption('조회 결과는 현재 브라우저 세션에만 보관됩니다. 연결을 끊거나 새로 연결하면 조회 결과를 지웁니다.')
